#include "3C/Effect/KGNiagaraUpdateContext.h"

#include "3C/Core/C7ActorInterface.h"
#include "Manager/KGCppAssetManager.h"
#include "3C/Effect/KGEffectManager.h"
#include "3C/Core/KGUEActorManager.h"
#include "Landscape.h"
#include "NiagaraComponent.h"
#include "NiagaraFunctionLibrary.h"
#include "NiagaraSystemInstanceController.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskSetNiagaraMeshComponentInfo.h"
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskUpdateParamByCurve.h"
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskUpdateParticleColorScale.h"
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskUpdateParticleColorScaleLinearSample.h"
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskConstantNiagaraParams.h"
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskFaceToActor.h"
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskFaceToLocation.h"
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskFollowActorLocation.h"
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskFollowCameraArmLength.h"
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskFollowCameraFOV.h"
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskUpdateParamByLinearSample.h"
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskUpdatePositionWithArcParams.h"
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskUpdateSplineParams.h"
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskSetEffectAudio.h"
#include "3C/Component/AddMeshComponent.h"
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskFollowActorRotation.h"
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskStickOnGround.h"
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskUpdateParamByHeightDiff.h"
#include "GameFramework/Character.h"
#include "Managers/KGDataCacheManager.h"
#include "3C/Material/KGMaterialCommon.h"
#include "3C/Util/KGActorUtil.h"
#include "3C/Util/KGUtils.h"

int32 GForceNiagaraShadingRate = -1;
static FAutoConsoleVariableRef CVarForceNiagaraShadingRate(
	TEXT("gp.ForceNiagaraShadingRate"),
	GForceNiagaraShadingRate,
	TEXT("ForceNiagaraShadingRate."),
	ECVF_Default
);

bool GbEnableBattleEffectShadingRate = true;
static FAutoConsoleVariableRef CVarbEnableBattleEffectShadingRate(
	TEXT("gp.bEnableBattleEffectShadingRate"),
	GbEnableBattleEffectShadingRate,
	TEXT("EnableBattleEffectShadingRate"),
	ECVF_Default
);

void FKGNiagaraUpdateContext::OnNiagaraSystemActivate()
{
	if (!NiagaraComponent)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::ActivateAllUpdateTasks, NiagaraComponent is null, %s"), *ToString());
		return;
	}
	
	RefreshNiagaraHiddenStateOnActivate();
	
	// 先将存量的task Init完成后, 再设置新的update task, 否则会出现Init重入的问题
	for (const auto& TaskPair : NiagaraUpdateTasks)
	{
		auto& TaskPtr = TaskPair.Value;
		check(TaskPtr.IsValid());
		TaskPtr->DoTaskInit(this);
	}

	UpdateNiagaraPlayRate();

	if (PlayNiagaraParams.bFollowCameraFOV)
	{
		SetNiagaraFollowCameraFOV();
	}

	if (PlayNiagaraParams.NeedAttach())
	{
		auto& AttachedSpawnInfo = PlayNiagaraParams.GetAttachedSpawnInfoChecked();
		const bool bAbsoluteScaleUsed = bForceUseAbsoluteScale || AttachedSpawnInfo.bAbsoluteScale;
		NiagaraComponent->SetAbsolute(AttachedSpawnInfo.bAbsolutePosition, AttachedSpawnInfo.bAbsoluteRotation, bAbsoluteScaleUsed);	
	}

	if (PlayNiagaraParams.BlendInTimeSeconds > 0.0)
	{
		SetLinearSampleParticleColorScaleUpdateTask(true, PlayNiagaraParams.BlendInTimeSeconds, true);
	}

	EMaterialShadingRate ShadingRate = MSR_1x1;

	// @xuyunhan:影视级和极高，配1x1就行，相当于没开。高和以下开2x2
	if (GbEnableBattleEffectShadingRate && PlayNiagaraParams.EffectTags.Contains(EKGNiagaraEffectTag::BATTLE) && FNiagaraPlatformSet::GetQualityLevel() <= 2)
	{
		ShadingRate = MSR_2x2;
	}
	
#if !UE_BUILD_SHIPPING
	if (GForceNiagaraShadingRate >= MSR_1x1 && GForceNiagaraShadingRate < MSR_Count)
	{
		ShadingRate = static_cast<EMaterialShadingRate>(GForceNiagaraShadingRate);
	}
#endif
	NiagaraComponent->SetShadingRate(ShadingRate);

	if (this->bNeedDetachDeferred)
	{
		this->DetachNiagaraEffect();
		this->bNeedDetachDeferred = false;
	}
	
	RefreshTransparencyScale();

	CheckGroundOnActivate();
}

void FKGNiagaraUpdateContext::OnNiagaraSystemDestroyed()
{
	this->RemoveAllUpdateTasks();

	if (bNeedUnCacheNiagaraParamOnDestroy)
	{
		if (AActor* SpawnerActor = KGUtils::GetActorByID(PlayNiagaraParams.SpawnerID))
		{
			if (UAddMeshComponent* AddMeshComp = SpawnerActor->FindComponentByClass<UAddMeshComponent>())
			{
				AddMeshComp->UnCacheNiagaraParamBefore(PlayNiagaraParams.AttachComponentName);
			}
			else
			{
				UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateContext::OnNiagaraSystemDestroyed: AddMeshComponent not found on SpawnerActor: %s"), *ToString());
			}
		}
		else
		{
			UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateContext::OnNiagaraSystemDestroyed: SpawnerActor is invalid: %s"), *ToString());
		}
	}
}

void FKGNiagaraUpdateContext::DetachNiagaraEffect()
{
	if (!this->PlayNiagaraParams.NeedAttach())
	{
		UE_LOG(LogEM, Warning,
			TEXT("FKGNiagaraUpdateContext::DetachNiagaraEffect: Niagara do not need attach: %s"),
			*this->ToString());
		return;
	}

	if (this->NiagaraComponent == nullptr)
	{
		UE_LOG(LogEM, Warning,
			TEXT("UKGEffectManager::InternalDetachNiagaraEffect, NiagaraComponent is invalid: %s"),
			*this->ToString());
		return;
	}
	
	FKGUnattachedNiagaraSpawnInfo UnattachedSpawnInfo;
	UnattachedSpawnInfo.SearchSpawnLocationType = EKGNiagaraSearchSpawnLocationType::UseCustomSpawnTrans;
	
	// Niagara Component 已经被创建，AttachComponent 就一定更先创建了，所以这里总是为 True，if 判断只为容错。
	if (this->AttachComponent.IsValid())
	{
		const auto& AttachSpawnInfo = this->PlayNiagaraParams.GetAttachedSpawnInfoChecked();
		const auto& ParentTransform = this->AttachComponent->GetSocketTransform(AttachSpawnInfo.AttachPointName);
		const auto& RelativeTransform = this->NewWorldSpaceOrRelativeSpawnTrans;
		UnattachedSpawnInfo.WorldOrRelativeTrans = RelativeTransform * ParentTransform;
	}
	else
	{
		UE_LOG(LogEM, Warning,
			TEXT("UKGEffectManager::InternalDetachNiagaraEffect, AttachComponent is invalid: %s"),
			*this->ToString());
	}

	this->PlayNiagaraParams.SetUnattachedSpawnInfo(UnattachedSpawnInfo);
	this->NiagaraComponent->DetachFromComponent(FDetachmentTransformRules::KeepWorldTransform);
}

void FKGNiagaraUpdateContext::UpdateNiagaraFloatParam(const FName& ParamName, float InVal)
{
	if (FMath::IsNaN(InVal))
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::UpdateNiagaraFloatParam: InVal is NaN, ParamName: %s, %s"), *ParamName.ToString(), *ToString());
		return;
	}
	
	if (NiagaraComponent)
	{
		NiagaraComponent->SetVariableFloat(ParamName, InVal);
	}
	else
	{
		TSharedPtr<FKGNiagaraUpdateTaskConstantNiagaraParams> TaskPtr = GetOrCreateUpdateTask<FKGNiagaraUpdateTaskConstantNiagaraParams>(EKGNiagaraUpdateTaskType::ConstantNiagaraParams);
		check(TaskPtr.IsValid());
		TaskPtr->UserVals_Float.Add(ParamName, InVal);
	}
}

void FKGNiagaraUpdateContext::UpdateNiagaraVec2Param(const FName& ParamName, float InX, float InY)
{
	FVector2D Vec2(InX, InY);
	if (Vec2.ContainsNaN())
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::UpdateNiagaraVec2Param: Vec2 is NaN, ParamName: %s, %s"), *ParamName.ToString(), *ToString());
		return;
	}
	
	if (NiagaraComponent)
	{
		NiagaraComponent->SetVariableVec2(ParamName, Vec2);
	}
	else
	{
		TSharedPtr<FKGNiagaraUpdateTaskConstantNiagaraParams> TaskPtr = GetOrCreateUpdateTask<FKGNiagaraUpdateTaskConstantNiagaraParams>(EKGNiagaraUpdateTaskType::ConstantNiagaraParams);
		check(TaskPtr.IsValid());
		TaskPtr->UserVals_Vec2.Add(ParamName, Vec2);
	}
}

void FKGNiagaraUpdateContext::UpdateNiagaraVec3Param(const FName& ParamName, float InX, float InY, float InZ)
{
	FVector Vec3(InX, InY, InZ);
	if (Vec3.ContainsNaN())
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::UpdateNiagaraVec3Param: Vec3 is NaN, ParamName: %s, %s"), *ParamName.ToString(), *ToString());
		return;
	}

	if (NiagaraComponent)
	{
		NiagaraComponent->SetVariableVec3(ParamName, Vec3);
	}
	else
	{
		TSharedPtr<FKGNiagaraUpdateTaskConstantNiagaraParams> TaskPtr = GetOrCreateUpdateTask<FKGNiagaraUpdateTaskConstantNiagaraParams>(EKGNiagaraUpdateTaskType::ConstantNiagaraParams);
		check(TaskPtr.IsValid());
		TaskPtr->UserVals_Vec3.Add(ParamName, Vec3);
	}
}

void FKGNiagaraUpdateContext::UpdateNiagaraLinearColorParam(const FName& ParamName, float InR, float InG, float InB, float InA)
{
	FLinearColor LinearColor(InR, InG, InB, InA);
	if (FVector4(LinearColor).ContainsNaN())
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::UpdateNiagaraLinearColorParam: LinearColor is NaN, ParamName: %s, %s"), *ParamName.ToString(), *ToString());
		return;
	}

	if (NiagaraComponent)
	{
		NiagaraComponent->SetVariableLinearColor(ParamName, LinearColor);
	}
	else
	{
		TSharedPtr<FKGNiagaraUpdateTaskConstantNiagaraParams> TaskPtr = GetOrCreateUpdateTask<FKGNiagaraUpdateTaskConstantNiagaraParams>(EKGNiagaraUpdateTaskType::ConstantNiagaraParams);
		check(TaskPtr.IsValid());
		TaskPtr->UserVals_LinearColor.Add(ParamName, LinearColor);
	}
}

void FKGNiagaraUpdateContext::UpdateNiagaraTextureParam(const FName& ParamName, const FString& TexturePath)
{
	TSharedPtr<FKGNiagaraUpdateTaskConstantNiagaraParams> TaskPtr = GetOrCreateUpdateTask<FKGNiagaraUpdateTaskConstantNiagaraParams>(EKGNiagaraUpdateTaskType::ConstantNiagaraParams);
	check(TaskPtr.IsValid());

	TaskPtr->SetTextureParam(ParamName, TexturePath);
}

void FKGNiagaraUpdateContext::RemoveNiagaraTextureParam(const FName& ParamName)
{
	TSharedPtr<FKGNiagaraUpdateTaskConstantNiagaraParams> TaskPtr = GetOrCreateUpdateTask<FKGNiagaraUpdateTaskConstantNiagaraParams>(EKGNiagaraUpdateTaskType::ConstantNiagaraParams);
	check(TaskPtr.IsValid());

	TaskPtr->RemoveTextureParam(ParamName);
}

void FKGNiagaraUpdateContext::UpdateSystemUserVariableMeshComponent(
	const FString& ParamName, KGObjectID MeshCompID, const TArray<FName>& SkeletalMeshFilterBones, bool bUseCloneMeshCompOnSystemUserVariableMeshComponent, bool bUseNiagaraComponentTransform)
{
	TSharedPtr<FKGNiagaraUpdateTaskSetNiagaraMeshComponentInfo> TaskPtr = CreateUpdateTask<FKGNiagaraUpdateTaskSetNiagaraMeshComponentInfo>();
	check(TaskPtr.IsValid());
	TaskPtr->ParamName = ParamName;
	TaskPtr->MeshComponentInfo.ComponentID = MeshCompID;
	TaskPtr->MeshComponentInfo.bUseCloneMesh = bUseCloneMeshCompOnSystemUserVariableMeshComponent;
	TaskPtr->MeshComponentInfo.bUseNiagaraComponentTransform = bUseNiagaraComponentTransform;
	TaskPtr->MeshComponentInfo.SkeletalMeshFilterBones = SkeletalMeshFilterBones;
	if (NiagaraComponent)
	{
		TaskPtr->DoTaskInit(this);
	}
}

void FKGNiagaraUpdateContext::SetNiagaraComponentTags(const TArray<FName>& Tags)
{
	if (NiagaraComponent)
	{
		NiagaraComponent->ComponentTags = Tags;
	}
	else
	{
		TSharedPtr<FKGNiagaraUpdateTaskConstantNiagaraParams> TaskPtr = GetOrCreateUpdateTask<FKGNiagaraUpdateTaskConstantNiagaraParams>(EKGNiagaraUpdateTaskType::ConstantNiagaraParams);
		check(TaskPtr.IsValid());
		TaskPtr->ComponentTags = Tags;
	}
}

void FKGNiagaraUpdateContext::InheritOwnerCustomDepthInfo()
{
	auto Spawner = KGUtils::GetActorByID(PlayNiagaraParams.SpawnerID);
	if (!Spawner)
	{
		// 部分特效并不一定跟随spawner销毁, 例如子弹的销毁特效, 这里延迟到activate阶段才执行效果继承, 确实可能找不到spawner, 是合理的
		UE_LOG(LogEM, Log, TEXT("FKGNiagaraUpdateContext::InheritOwnerCustomDepthInfo, cannot find spawner with ID %lld, %d"),
			PlayNiagaraParams.SpawnerID, PlayNiagaraParams.bDestroyWhenSpawnerExitWorld);
		return;
	}

	IC7ActorInterface* C7ActorInterface = Cast<IC7ActorInterface>(Spawner);
	if (!C7ActorInterface)
	{
		return;
	}
	
	if (UKGUEActorManager* UEActorManager = UKGUEActorManager::GetInstance(Spawner))
	{
		if (auto* Entity = UEActorManager->GetLuaEntity(C7ActorInterface->GetEntityUID()))
		{
			bool bRenderCustomDepth = false;
			int32 CustomDepthStencilValue = 0;
			bool bNiagaraRenderCustomDepth = false;
			if (Entity->GetCurrentCustomDepthInfo(
				bRenderCustomDepth, CustomDepthStencilValue, bNiagaraRenderCustomDepth) && bNiagaraRenderCustomDepth)
			{
				SetForceCustomDepthInfo(bNiagaraRenderCustomDepth, CustomDepthStencilValue);
			}
		}
	}
}

void FKGNiagaraUpdateContext::SetCustomDepthInfo(bool bEnableCustomDepth, int32 CustomDepthStencilValue)
{
	TSharedPtr<FKGNiagaraUpdateTaskConstantNiagaraParams> TaskPtr = GetOrCreateUpdateTask<FKGNiagaraUpdateTaskConstantNiagaraParams>(EKGNiagaraUpdateTaskType::ConstantNiagaraParams);
	check(TaskPtr.IsValid());
	TaskPtr->SetCustomDepthInfo(bEnableCustomDepth, CustomDepthStencilValue);
}

void FKGNiagaraUpdateContext::SetForceCustomDepthInfo(bool bEnableCustomDepth, int32 CustomDepthStencilValue)
{
	TSharedPtr<FKGNiagaraUpdateTaskConstantNiagaraParams> TaskPtr = GetOrCreateUpdateTask<FKGNiagaraUpdateTaskConstantNiagaraParams>(EKGNiagaraUpdateTaskType::ConstantNiagaraParams);
	check(TaskPtr.IsValid());
	TaskPtr->SetForceCustomDepthInfo(bEnableCustomDepth, CustomDepthStencilValue);
}

void FKGNiagaraUpdateContext::RevertForceCustomDepthInfo()
{
	TSharedPtr<FKGNiagaraUpdateTaskConstantNiagaraParams> TaskPtr = GetOrCreateUpdateTask<FKGNiagaraUpdateTaskConstantNiagaraParams>(EKGNiagaraUpdateTaskType::ConstantNiagaraParams);
	check(TaskPtr.IsValid());
	TaskPtr->RevertForceCustomDepthInfo();
}

void FKGNiagaraUpdateContext::SetNiagaraRenderInMainPass(bool bRenderInMainPass)
{
	if (NiagaraComponent)
	{
		NiagaraComponent->SetRenderInMainPass(bRenderInMainPass);
	}
	else
	{
		TSharedPtr<FKGNiagaraUpdateTaskConstantNiagaraParams> TaskPtr = GetOrCreateUpdateTask<FKGNiagaraUpdateTaskConstantNiagaraParams>(EKGNiagaraUpdateTaskType::ConstantNiagaraParams);
		check(TaskPtr.IsValid());
		TaskPtr->bRenderInMainPass = bRenderInMainPass;
	}
}

void FKGNiagaraUpdateContext::SetNiagaraTranslucentSortPriority(int32 TranslucencySortPriority)
{
	if (NiagaraComponent)
	{
		NiagaraComponent->SetTranslucentSortPriority(TranslucencySortPriority);
	}
	else
	{
		TSharedPtr<FKGNiagaraUpdateTaskConstantNiagaraParams> TaskPtr = GetOrCreateUpdateTask<FKGNiagaraUpdateTaskConstantNiagaraParams>(EKGNiagaraUpdateTaskType::ConstantNiagaraParams);
		check(TaskPtr.IsValid());
		TaskPtr->TranslucencySortPriority = TranslucencySortPriority;
	}
}

void FKGNiagaraUpdateContext::SetNiagaraTranslucencySortDistanceOffset(int32 TranslucencySortDistanceOffset)
{
	if (NiagaraComponent)
	{
		NiagaraComponent->SetTranslucencySortDistanceOffset(TranslucencySortDistanceOffset);
	}
	else
	{
		TSharedPtr<FKGNiagaraUpdateTaskConstantNiagaraParams> TaskPtr = GetOrCreateUpdateTask<FKGNiagaraUpdateTaskConstantNiagaraParams>(EKGNiagaraUpdateTaskType::ConstantNiagaraParams);
		check(TaskPtr.IsValid());
		TaskPtr->TranslucencySortDistanceOffset = TranslucencySortDistanceOffset;
	}
}

void FKGNiagaraUpdateContext::UpdateNiagaraHiddenState(bool bHidden, uint8 HiddenReason, bool bInitHiddenState)
{
	if (HiddenReason >= KG_NIAGARA_MAX_HIDDEN_REASONS)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::UpdateNiagaraHiddenState, invalid HiddenReason %d, %s"),
			HiddenReason, *ToString());
		return;
	}

	const bool bOldNiagaraHidden = HiddenMask != 0;
	uint64 OldHiddenMask = HiddenMask;
	const uint64 CurHiddenMask = 1LL << HiddenReason;
	if (bHidden)
	{
		HiddenMask |= CurHiddenMask;
	}
	else
	{
		HiddenMask &= ~CurHiddenMask;
	}
	UE_LOG(LogEM, Log, TEXT("FKGNiagaraUpdateContext::UpdateNiagaraHiddenState, bHidden %d, HiddenReason %d, OldHiddenMask %lld, NewHiddenMask %lld, %s"),
		bHidden, HiddenReason, OldHiddenMask, HiddenMask, *ToString());
	const bool bNewNiagaraHidden = HiddenMask != 0;
	if ((bInitHiddenState && bNewNiagaraHidden) || (!bInitHiddenState && bOldNiagaraHidden != bNewNiagaraHidden))
	{
		InternalSetNiagaraComponentHiddenState(bNewNiagaraHidden);
	}
}

void FKGNiagaraUpdateContext::RefreshNiagaraHiddenStateOnActivate()
{
	if (!EffectManager.IsValid())
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::UpdateNiagaraHiddenStateOnActivate, invalid effect manager, %s"), *ToString());
		return;
	}

	if (!NiagaraComponent)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::UpdateNiagaraHiddenStateOnActivate, invalid niagara component %s"), *ToString());
		return;
	}
	
	bool bHasSetNiagaraHidden = false;
	if (PlayNiagaraParams.bFollowHidden && bFollowSpawnerHiddenState)
	{
		bool bOwnerVisible = true;
		if (AActor* Spawner = KGUtils::GetActorByID(PlayNiagaraParams.SpawnerID))
		{
			bOwnerVisible = !Spawner->IsHidden();
		}
		
		if (!bOwnerVisible)
		{
			UE_LOG(LogEM, Log, TEXT("UKGEffectManager::UpdateNiagaraHiddenStateOnActivate, set niagara hidden[follow owner hidden state] %s"), *ToString());
			UpdateNiagaraHiddenState(true, static_cast<uint8>(EKGNiagaraHiddenReason::OWNER_SET_HIDDEN), true);
			bHasSetNiagaraHidden = true;
		}
	}
	
	if (PlayNiagaraParams.bFollowHidden)
	{
		bool bAttachCompVisible = true;
		if (UMeshComponent* AttachComp = Cast<UMeshComponent>(NiagaraComponent->GetAttachParent()))
		{
			bAttachCompVisible = AttachComp->IsVisible();
		}
		
		if (!bAttachCompVisible)
		{
			UE_LOG(LogEM, Log, TEXT("UKGEffectManager::UpdateNiagaraHiddenStateOnActivate, set niagara hidden[follow attach component hidden state] %s"), *ToString());
			UpdateNiagaraHiddenState(true, static_cast<uint8>(EKGNiagaraHiddenReason::ATTACH_COMPONENT_HIDDEN), true);
			bHasSetNiagaraHidden = true;
		}
	}

	for (const auto& EffectTag : PlayNiagaraParams.EffectTags)
	{
		TBitArray<> HiddenMaskBitArray;
		if (EffectManager->GetEffectTagMask(EffectTag, HiddenMaskBitArray))
		{
			for (TConstSetBitIterator<> It(HiddenMaskBitArray); It; ++It)
			{
				UE_LOG(LogEM, Log, TEXT("UKGEffectManager::UpdateNiagaraHiddenStateOnActivate, set niagara hidden[effect tag mask] %s, EffectTag: %d, HiddenReason: %d"),
					*ToString(), static_cast<int32>(EffectTag), It.GetIndex());
				UpdateNiagaraHiddenState(true, It.GetIndex(), true);
				bHasSetNiagaraHidden = true;
			}	
		}
	}

	if (!bHasSetNiagaraHidden && HiddenMask > 0)
	{
		InternalSetNiagaraComponentHiddenState(true);
	}
}

void FKGNiagaraUpdateContext::CheckGroundOnActivate()
{
	if (!NiagaraComponent)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::CheckGroundOnActivate, NiagaraComponent is null, %s"), *ToString());
		return;
	}
	
	if (!EffectManager.IsValid())
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::CheckGroundOnActivate, invalid effect manager, %s"), *ToString());
		return;
	}

	AActor* Spawner = KGUtils::GetActorByID(PlayNiagaraParams.SpawnerID);
	if (!IsValid(Spawner))
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateContext::CheckGroundOnActivate, invalid spawner %lld, %s"),
			PlayNiagaraParams.SpawnerID, *PlayNiagaraParams.NiagaraEffectPath);
		return;
	}
	
	if (PlayNiagaraParams.StickGroundType == EKGNiagaraStickGroundType::StickToGround)
	{
		const auto& NiagaraLocation = NiagaraComponent->GetComponentLocation();
		FVector GroundLocation = NiagaraLocation;
		EffectManager->CheckGroundLocation(Spawner, true, GroundLocation);
		UE_LOG(LogEM, Log, TEXT("FKGNiagaraUpdateContext::OnNiagaraSystemActivate, Fit ground location: %s -> %s, NiagaraEffectPath: %s"),
			*NiagaraLocation.ToString(), *GroundLocation.ToString(), *PlayNiagaraParams.NiagaraEffectPath);
		// 只要传入的不是世界空间坐标, 那么都需要贴地后重新叠加Z轴偏移
		bool bNeedAddZOffset = false;
		if (PlayNiagaraParams.bUseSkillNiagaraSpawnInfo)
		{
			bNeedAddZOffset = PlayNiagaraParams.PositionMode != EKGNiagaraPositionMode::World;
		}
		else if (!PlayNiagaraParams.NeedAttach())
		{
			auto& UnattachedSpawnInfo = PlayNiagaraParams.GetUnattachedSpawnInfoChecked();
			bNeedAddZOffset = UnattachedSpawnInfo.SearchSpawnLocationType != EKGNiagaraSearchSpawnLocationType::UseCustomSpawnTrans;
		}

		if (bNeedAddZOffset)
		{
			if (PlayNiagaraParams.NeedAttach())
			{
				GroundLocation.Z += PlayNiagaraParams.GetAttachedSpawnInfoChecked().RelativeTrans.GetLocation().Z;
			}
			else
			{
				GroundLocation.Z += PlayNiagaraParams.GetUnattachedSpawnInfoChecked().WorldOrRelativeTrans.GetLocation().Z;
			}
		}

		NiagaraComponent->SetWorldLocation(GroundLocation);
	}
	else if (PlayNiagaraParams.StickGroundType == EKGNiagaraStickGroundType::StickToWaterSurface)
	{
		ACharacter* Character = Cast<ACharacter>(Spawner);
		if (!Character)
		{
			UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateContext::CheckGroundOnActivate, spawner is not character %s, %s"),
				*Spawner->GetName(), *PlayNiagaraParams.NiagaraEffectPath);
			return;
		}

		UMeshComponent* MainMesh = Character->GetMesh();
		if (!MainMesh)
		{
			UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateContext::CheckGroundOnActivate, main mesh is not valid %s, %s"),
				*Spawner->GetName(), *PlayNiagaraParams.NiagaraEffectPath);
			return;
		}
		
		URoleMovementComponent* RMComponent = Cast<URoleMovementComponent>(Character->GetComponentByClass(URoleMovementComponent::StaticClass()));
		if (!RMComponent)
		{
			UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateContext::CheckGroundOnActivate, cannot find RoleMovementComponent on spawner %s"),
				*Spawner->GetName());
			return;
		}
		
		FVector NiagaraLocation = NiagaraComponent->GetComponentLocation();
		const FVector& MeshLocation = MainMesh->GetComponentLocation();
		const bool bIsInWater = RMComponent->GetIsInWater();
		FVector GroundPos;
		if (bIsInWater)
		{
			NiagaraLocation.Z = MeshLocation.Z - RMComponent->GetCurDistToWaterSurface() + EffectManager->GetInWaterEffectOffset();
		}
		else if (RMComponent->GetIsGroundDetected() && RMComponent->GetCurGroundSurfacePosition(GroundPos))
		{
			NiagaraLocation.Z = GroundPos.Z;
		}

		NiagaraComponent->SetWorldLocation(NiagaraLocation);
	}
}

void FKGNiagaraUpdateContext::SetSpiritualVisionColor(bool bInSpiritualVision, const FLinearColor& InSpiritualVisionMeshColor)
{
	TSharedPtr<FKGNiagaraUpdateTaskConstantNiagaraParams> TaskPtr = GetOrCreateUpdateTask<FKGNiagaraUpdateTaskConstantNiagaraParams>(EKGNiagaraUpdateTaskType::ConstantNiagaraParams);
	check(TaskPtr.IsValid());
	TaskPtr->SetSpiritualVisionColor(bInSpiritualVision, InSpiritualVisionMeshColor);
}

void FKGNiagaraUpdateContext::UpdateSpiritualVisionColorParams(const FName& ParamName, bool bEnableSpiritualVision)
{
	TSharedPtr<FKGNiagaraUpdateTaskConstantNiagaraParams> TaskPtr = GetOrCreateUpdateTask<FKGNiagaraUpdateTaskConstantNiagaraParams>(EKGNiagaraUpdateTaskType::ConstantNiagaraParams);
	check(TaskPtr.IsValid());
	TaskPtr->UpdateSpiritualVisionColorParams(ParamName, bEnableSpiritualVision);
}

bool FKGNiagaraUpdateContext::RefreshAttachComponentOrSpawnTrans()
{
	SCOPED_NAMED_EVENT(FKGNiagaraUpdateContext_RefreshAttachComponentOrSpawnTrans, FColor::Red);
	
	if (PlayNiagaraParams.bUseSkillNiagaraSpawnInfo)
	{
		const bool bResult = RefreshAttachComponentOrSpawnTrans_SkillInfo();
		UE_CLOG(!bResult, LogEM, Error,
			TEXT("FKGNiagaraUpdateContext::RefreshAttachComponentOrSpawnTransOnCreateNiagara, unsupported RotationMode %d with PositionMode %d"),
			PlayNiagaraParams.RotationMode, PlayNiagaraParams.PositionMode);
		return bResult;
	}

	return RefreshAttachComponentOrSpawnTrans_Default();
}

bool FKGNiagaraUpdateContext::RefreshAttachComponentOrSpawnTrans_Default()
{
	AActor* Spawner = KGUtils::GetActorByID(PlayNiagaraParams.SpawnerID);
	if (!IsValid(Spawner))
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateContext::RefreshAttachComponentOrSpawnTrans_Default, invalid spawner %lld, %s"),
			PlayNiagaraParams.SpawnerID, *PlayNiagaraParams.NiagaraEffectPath);
		return false;
	}
	
	if (PlayNiagaraParams.NeedAttach())
	{
		auto& AttachedSpawnInfo = PlayNiagaraParams.GetAttachedSpawnInfoChecked();
		bool bFailImmediately = true;
		RefreshAttachComponent(bFailImmediately);
		if (!AttachComponent.IsValid())
		{
			return !bFailImmediately;
		}

		NewWorldSpaceOrRelativeSpawnTrans = AttachedSpawnInfo.RelativeTrans;
	}
	else
	{
		auto& UnattachedSpawnInfo = PlayNiagaraParams.GetUnattachedSpawnInfoChecked();
		const auto SearchSpawnLocationType = UnattachedSpawnInfo.SearchSpawnLocationType;
		if (SearchSpawnLocationType == EKGNiagaraSearchSpawnLocationType::UseCustomSpawnTrans)
		{
			NewWorldSpaceOrRelativeSpawnTrans = UnattachedSpawnInfo.WorldOrRelativeTrans;
		}
		else
		{
			FTransform ActorTransform = FTransform::Identity;
			if (SearchSpawnLocationType == EKGNiagaraSearchSpawnLocationType::UseAttachSocketTransform)
			{
				USceneComponent* Component = nullptr;
				if (!PlayNiagaraParams.AttachComponentName.IsNone())
				{
					// 没找到add mesh component, 直接返回
					bRequiresAttachComponent = true;
					AttachComponent = GetAttachComponentByComponentName();
					if (!AttachComponent.IsValid())
					{
						return true;
					}
					Component = AttachComponent.Get();
				}
				else
				{
					Component = UKGActorUtil::GetComponentBySocket(Spawner, UnattachedSpawnInfo.AttachPointName);
				}
				
				if (!Component)
				{
					ActorTransform = Spawner->GetActorTransform();
				}
				else
				{
					ActorTransform = Component->GetSocketTransform(UnattachedSpawnInfo.AttachPointName);
				}
			}
			else if (SearchSpawnLocationType == EKGNiagaraSearchSpawnLocationType::UseActorTransform)
			{
				ActorTransform = Spawner->GetActorTransform();
			}

			NewWorldSpaceOrRelativeSpawnTrans = UnattachedSpawnInfo.WorldOrRelativeTrans * ActorTransform;
		}
	}

	return true;
}

bool FKGNiagaraUpdateContext::RefreshAttachComponentOrSpawnTrans_SkillInfo()
{
	AActor* Spawner = KGUtils::GetActorByID(PlayNiagaraParams.SpawnerID);
	if (!IsValid(Spawner))
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateContext::RefreshAttachComponentOrSpawnTrans_SkillInfo, invalid spawner %lld, %s"),
			PlayNiagaraParams.SpawnerID, *PlayNiagaraParams.NiagaraEffectPath);
		return false;
	}

	const auto PositionMode = PlayNiagaraParams.PositionMode;
	const auto RotationMode = PlayNiagaraParams.RotationMode;
	
	if (PlayNiagaraParams.NeedAttach())
	{
		auto& AttachedSpawnInfo = PlayNiagaraParams.GetAttachedSpawnInfoChecked();
		bool bFailImmediately = true;
		RefreshAttachComponent(bFailImmediately);
		if (!AttachComponent.IsValid())
		{
			return !bFailImmediately;
		}

		NewWorldSpaceOrRelativeSpawnTrans = AttachedSpawnInfo.RelativeTrans;

		// position mode == EKGNiagaraPositionMode::Follow or rotation mode == EKGNiagaraRotationMode::Follow
		if (PositionMode == EKGNiagaraPositionMode::Follow)
		{
			if (RotationMode == EKGNiagaraRotationMode::Follow)
			{
				return true;
			}

			AttachedSpawnInfo.bAbsoluteRotation = true;
			if (RotationMode == EKGNiagaraRotationMode::World || RotationMode == EKGNiagaraRotationMode::ToCameraYaw)
			{
				return true;
			}
			
			FQuat OverrideQuat = FQuat::Identity;
			if (RotationMode == EKGNiagaraRotationMode::SocketInit)
			{
				FTransform SocketTransform;
				if (CalculateTransform_GetSocketTransform(Spawner, AttachComponent.Get(), AttachedSpawnInfo.AttachPointName, AttachedSpawnInfo.bAbsoluteScale, SocketTransform))
				{
					OverrideQuat = SocketTransform.GetRotation();
				}
			}
			else if (RotationMode == EKGNiagaraRotationMode::SelfInit)
			{
				OverrideQuat = Spawner->GetActorRotation().Quaternion();
			}
			else if (RotationMode == EKGNiagaraRotationMode::ToTimelinePlayer)
			{
				CalculateTransform_GetRotationToTimelinePlayer(Spawner, false, FVector::ZeroVector, OverrideQuat);
			}
			else
			{
				return false;
			}
			
			NewWorldSpaceOrRelativeSpawnTrans.SetRotation(NewWorldSpaceOrRelativeSpawnTrans.GetRotation() * OverrideQuat);
			return true;
		}
		
		if (RotationMode == EKGNiagaraRotationMode::Follow)
		{
			AttachedSpawnInfo.bAbsolutePosition = true;
			if (PositionMode == EKGNiagaraPositionMode::World)
			{
				return true;
			}

			if (PositionMode == EKGNiagaraPositionMode::SocketInit)
			{
				AttachedSpawnInfo.bAbsolutePosition = true;
				FTransform SocketTransform;
				if (CalculateTransform_GetSocketTransform(Spawner, AttachComponent.Get(), AttachedSpawnInfo.AttachPointName, AttachedSpawnInfo.bAbsoluteScale, SocketTransform))
				{
					FTransform RelativeTransNoScale(NewWorldSpaceOrRelativeSpawnTrans.GetRotation(), NewWorldSpaceOrRelativeSpawnTrans.GetLocation(), FVector::OneVector);
					NewWorldSpaceOrRelativeSpawnTrans.SetLocation((RelativeTransNoScale * SocketTransform).GetLocation());
				}
				return true;
			}
		}
		
		return false;
	}

	auto& UnattachedSpawnInfo = PlayNiagaraParams.GetUnattachedSpawnInfoChecked();
	NewWorldSpaceOrRelativeSpawnTrans = UnattachedSpawnInfo.WorldOrRelativeTrans;
	
	if (!PlayNiagaraParams.AttachComponentName.IsNone())
	{
		bRequiresAttachComponent = true;
		AttachComponent = GetAttachComponentByComponentName();
		if (!AttachComponent.IsValid())
		{
			return true;
		}
	}
	
	if (PositionMode == EKGNiagaraPositionMode::SocketInit)
	{
		FTransform SocketTransform;
		if (!CalculateTransform_GetSocketTransform(Spawner, AttachComponent.Get(), UnattachedSpawnInfo.AttachPointName, UnattachedSpawnInfo.bAbsoluteScale, SocketTransform))
		{
			return false;
		}
		
		if (RotationMode == EKGNiagaraRotationMode::SocketInit || RotationMode == EKGNiagaraRotationMode::ToCameraYaw)
		{
			NewWorldSpaceOrRelativeSpawnTrans = UnattachedSpawnInfo.WorldOrRelativeTrans * SocketTransform;
			return true;
		}

		SocketTransform.SetScale3D(FVector::OneVector);
		FQuat OverrideQuat = FQuat::Identity;
		if (RotationMode == EKGNiagaraRotationMode::World)
		{
			OverrideQuat = UnattachedSpawnInfo.WorldOrRelativeTrans.GetRotation();
		}
		else if (RotationMode == EKGNiagaraRotationMode::SelfInit)
		{
			OverrideQuat = Spawner->GetActorRotation().Quaternion();
		}
		else if (RotationMode == EKGNiagaraRotationMode::ToTimelinePlayer)
		{
			CalculateTransform_GetRotationToTimelinePlayer(Spawner, false, FVector::ZeroVector, OverrideQuat);
		}
		else
		{
			return false;
		}

		SocketTransform.SetRotation(OverrideQuat);
		NewWorldSpaceOrRelativeSpawnTrans = UnattachedSpawnInfo.WorldOrRelativeTrans * SocketTransform;
		return true;
	}

	if (PositionMode == EKGNiagaraPositionMode::World)
	{
		if (RotationMode == EKGNiagaraRotationMode::World || RotationMode == EKGNiagaraRotationMode::ToCameraYaw)
		{
			return true;
		}
		
		FQuat OverrideQuat = FQuat::Identity;
		if (RotationMode == EKGNiagaraRotationMode::SocketInit)
		{
			FTransform SocketTransform;
			if (CalculateTransform_GetSocketTransform(Spawner, AttachComponent.Get(), UnattachedSpawnInfo.AttachPointName, UnattachedSpawnInfo.bAbsoluteScale, SocketTransform))
			{
				OverrideQuat = SocketTransform.GetRotation();
			}
		}
		else if (RotationMode == EKGNiagaraRotationMode::SelfInit)
		{
			OverrideQuat = Spawner->GetActorRotation().Quaternion();
		}
		else if (RotationMode == EKGNiagaraRotationMode::ToTimelinePlayer)
		{
			CalculateTransform_GetRotationToTimelinePlayer(Spawner, true, NewWorldSpaceOrRelativeSpawnTrans.GetLocation(), OverrideQuat);
		}
		else
		{
			return false;
		}

		NewWorldSpaceOrRelativeSpawnTrans.SetRotation(NewWorldSpaceOrRelativeSpawnTrans.GetRotation() * OverrideQuat);
		return true;
	}

	return false;
}

bool FKGNiagaraUpdateContext::RefreshAttachComponent(bool& bOutFailImmediately)
{
	AActor* Spawner = KGUtils::GetActorByID(PlayNiagaraParams.SpawnerID);
	if (!IsValid(Spawner))
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateContext::RefreshAttachComponent, invalid spawner %lld, %s"),
			PlayNiagaraParams.SpawnerID, *PlayNiagaraParams.NiagaraEffectPath);
		return false;
	}
	
	if (!PlayNiagaraParams.NeedAttach())
	{
		return false;
	}
	
	// 通常来说找不到attach component特效应该播放失败, 但是目前技能特效会在dynamic mesh component上播放, dynamic mesh component需要异步加载创建
	// 如果在这个时候就去找attach component, 可能会导致attach component还没有创建出来, 导致特效播放失败
	// 所以这里允许attach component为nullptr, 并在dynamic mesh component创建完成后再去刷新attach component
	auto& AttachedSpawnInfo = PlayNiagaraParams.GetAttachedSpawnInfoChecked();
	const auto SearchComponentType = AttachedSpawnInfo.SearchAttachComponentType;
	if (SearchComponentType == EKGNiagaraSearchAttachComponentType::UseRootComponent)
	{
		AttachComponent = Spawner->GetRootComponent();
	}
	else if (SearchComponentType == EKGNiagaraSearchAttachComponentType::UseMainMeshComponent)
	{
		if (ACharacter* Character = Cast<ACharacter>(Spawner))
		{
			AttachComponent = Character->GetMesh();
		}
		else
		{
			AttachComponent = Spawner->GetComponentByClass<UMeshComponent>();
		}
	}
	else if (SearchComponentType == EKGNiagaraSearchAttachComponentType::UseCameraRootComponent)
	{
		if (APlayerCameraManager* CameraManager = UGameplayStatics::GetPlayerCameraManager(Spawner->GetWorld(), 0))
		{
			AttachComponent = CameraManager->GetRootComponent();
		}
	}
	else if (SearchComponentType == EKGNiagaraSearchAttachComponentType::FindComponentByComponentClassType)
	{
		if (AttachedSpawnInfo.ComponentClass.IsValid())
		{
			AttachComponent = Cast<USceneComponent>(Spawner->GetComponentByClass(AttachedSpawnInfo.ComponentClass.Get()));	
		}
	}
	else if (SearchComponentType == EKGNiagaraSearchAttachComponentType::FindComponentByComponentName)
	{
		bRequiresAttachComponent = true;
		bOutFailImmediately = false;
		AttachComponent = GetAttachComponentByComponentName();
	}
	else if (SearchComponentType == EKGNiagaraSearchAttachComponentType::FindComponentBySocketName)
	{
		AttachComponent = UKGActorUtil::GetComponentBySocket(Spawner, AttachedSpawnInfo.AttachPointName);
	}
	else if (SearchComponentType == EKGNiagaraSearchAttachComponentType::UseCustomAttachComponent)
	{
		AttachComponent = AttachedSpawnInfo.CustomAttachComponent.Get();
	}
	else if (SearchComponentType == EKGNiagaraSearchAttachComponentType::UseMainMeshOrRootComponent)
	{
		if (ACharacter* Character = Cast<ACharacter>(Spawner))
		{
			AttachComponent = Character->GetMesh();
		}
		else
		{
			AttachComponent = Spawner->GetComponentByClass<UMeshComponent>();
		}

		if (!AttachComponent.IsValid())
		{
			AttachComponent = Spawner->GetRootComponent();
		}
	}
	else if (SearchComponentType == EKGNiagaraSearchAttachComponentType::FindComponentByComponentTypeAndTag)
	{
		if (AttachedSpawnInfo.ComponentClass.IsValid())
		{
			TArray<USceneComponent*> Components;
			Spawner->GetComponents<USceneComponent>(Components);
			for (USceneComponent* Component : Components)
			{
				if (Component->IsA(AttachedSpawnInfo.ComponentClass.Get()) && Component->ComponentHasTag(AttachedSpawnInfo.ComponentTag))
				{
					AttachComponent = Component;
					break;
				}
			}
		}
	}

	UE_LOG(LogEM, Log,
		TEXT("FKGNiagaraUpdateContext::RefreshAttachComponent, found attach component, SearchComponentType: %d, AttachComponent: %s, NiagaraEffectPath: %s"),
		SearchComponentType, AttachComponent.IsValid() ? *AttachComponent->GetName() : TEXT("nullptr"), *PlayNiagaraParams.NiagaraEffectPath);

	return AttachComponent.IsValid();
}

void FKGNiagaraUpdateContext::RefreshNiagaraCommonTags()
{
	if (PlayNiagaraParams.bFollowCameraFOV)
	{
		PlayNiagaraParams.EffectTags.Add(EKGNiagaraEffectTag::CAMERA);
	}
	
	auto SpawnerEntityID = PlayNiagaraParams.InstigatorEntityID != KG_INVALID_ENTITY_ID ? PlayNiagaraParams.InstigatorEntityID : PlayNiagaraParams.SpawnerEntityID;
	if (SpawnerEntityID == KG_INVALID_ENTITY_ID)
	{
		if (IC7ActorInterface* C7ActorInterface = Cast<IC7ActorInterface>(KGUtils::GetActorByID(PlayNiagaraParams.SpawnerID)))
		{
			SpawnerEntityID = C7ActorInterface->GetEntityUID();
		}
	}
	
	if (SpawnerEntityID == KG_INVALID_ENTITY_ID)
	{
		return;
	}
	
	auto* SpawnerEntity = UKGUEActorManager::GetLuaEntity(EffectManager.Get(), SpawnerEntityID);
	if (!SpawnerEntity)
	{
		return;
	}

	const auto& EntityData = SpawnerEntity->GetEntityData();
	if (EntityData.FinalOwnerID == KG_INVALID_ENTITY_ID)
	{
		return;
	}

	auto* OwnerEntity = UKGUEActorManager::GetLuaEntity(EffectManager.Get(), EntityData.FinalOwnerID);
	if (!OwnerEntity)
	{
		return;
	}
	
	if (OwnerEntity->GetIsMainPlayer())
	{
		PlayNiagaraParams.EffectTags.Add(EKGNiagaraEffectTag::MAIN_PLAYER);
	}
	else if (OwnerEntity->GetIsAvatar())
	{
		PlayNiagaraParams.EffectTags.Add(EKGNiagaraEffectTag::OTHER_PLAYER);
	}
}

void FKGNiagaraUpdateContext::RefreshQualityLevelAndTransparencyScale()
{
	if (!EffectManager.IsValid())
	{
		return;
	}
	
	if (EffectManager->IsDisableQualityLevelOffsetAndTransparencyScale())
	{
		return;
	}
	
	if (PlayNiagaraParams.EffectTags.Contains(EKGNiagaraEffectTag::MAIN_PLAYER))
	{
		QualityLevel = static_cast<int8>(EffectManager->GetPlayerNiagaraQualityLevel());
		TransparencyScaleBySettings = EffectManager->GetPlayerTransparencyScaleFactor();
		UE_LOG(LogEM, Log, TEXT("FKGNiagaraUpdateContext::RefreshQualityLevelAndTransparencyScale, main player effect, %s, %d, %f"), 
			*ToString(), QualityLevel.GetValue(), TransparencyScaleBySettings);
	}
	else if (PlayNiagaraParams.EffectTags.Contains(EKGNiagaraEffectTag::OTHER_PLAYER))
	{
		QualityLevel = static_cast<int8>(EffectManager->GetOtherPlayerNiagaraQualityLevel());
		TransparencyScaleBySettings = EffectManager->GetOtherPlayerTransparencyScaleFactor();
		UE_LOG(LogEM, Log, TEXT("FKGNiagaraUpdateContext::RefreshQualityLevelAndTransparencyScale, other player effect, %s, %d, %f"), 
			*ToString(), QualityLevel.GetValue(), TransparencyScaleBySettings);
		
		if (NiagaraSystem)
		{
			uint32 NiagaraPriority = PlayNiagaraParams.NiagaraBusinessPriority >= 0 ? PlayNiagaraParams.NiagaraBusinessPriority : NiagaraSystem->GetPriority();
			if (NiagaraPriority < EffectManager->GetOtherPlayerNiagaraPriorityThresholdIgnoreHidden())
			{
				EffectManager->AppendNiagaraExtraEffectTag(NiagaraEffectId, static_cast<int32>(EKGNiagaraEffectTag::OTHER_PLAYER_LOW_QUALITY));
			}
		}
	}
	else if (EffectManager->IsEnvNiagaraEffect(NiagaraComponent))
	{
		QualityLevel = static_cast<int8>(EffectManager->GetEnvNiagaraQualityLevel());
		TransparencyScaleBySettings = EffectManager->GetEnvTransparencyScaleFactor();
		EffectManager->AppendNiagaraExtraEffectTag(NiagaraEffectId, static_cast<int32>(EKGNiagaraEffectTag::ENV));
		UE_LOG(LogEM, Log, TEXT("FKGNiagaraUpdateContext::RefreshQualityLevelAndTransparencyScale, env effect, %s, %d, %f"), 
			*ToString(), QualityLevel.GetValue(), TransparencyScaleBySettings);
	}
}

bool FKGNiagaraUpdateContext::CalculateTransform_GetSocketTransform(AActor* Spawner, USceneComponent* SocketComponent, const FName& SocketName, bool bAbsoluteScale, FTransform& OutSocketTransform)
{
	if (!IsValid(Spawner))
	{
		return false;
	}

	if (SocketComponent == nullptr)
	{
		SocketComponent = UKGActorUtil::GetComponentBySocket(Spawner, SocketName);
	}
	
	if (SocketComponent)
	{
		OutSocketTransform = SocketComponent->GetSocketTransform(SocketName);
		if (bAbsoluteScale)
		{
			OutSocketTransform.SetScale3D(FVector::OneVector);
		}
		return true;
	}

	UE_LOG(LogEM, Warning,
		TEXT("FKGNiagaraUpdateContext::CalculateTransform_GetSocketTransform, cannot find socket %s on spawner %s"),
		*SocketName.ToString(), *Spawner->GetName());
	return false;
}

bool FKGNiagaraUpdateContext::CalculateTransform_GetRotationToTimelinePlayer(
	AActor* Spawner, bool bUseLineStartWorldPos, const FVector& LineStartWorldPos, FQuat& OutQuat)
{
	auto* TargetEntity = UKGUEActorManager::GetLuaEntity(Spawner, PlayNiagaraParams.RotationTargetEntityID);
	auto* TargetActor = (TargetEntity && TargetEntity->GetLuaEntityBase()) ? TargetEntity->GetLuaEntityBase()->GetActor() : nullptr;
	if (TargetActor)
	{
		if (bUseLineStartWorldPos)
		{
			OutQuat = (TargetActor->GetActorLocation() - LineStartWorldPos).GetSafeNormal2D().ToOrientationQuat();
			return true;
		}
		
		if (Spawner != TargetActor)
		{
			OutQuat = (TargetActor->GetActorLocation() - Spawner->GetActorLocation()).GetSafeNormal2D().ToOrientationQuat();
			return true;
		}
	}
	
	UE_LOG(LogEM, Warning,
		TEXT("FKGNiagaraUpdateContext::CalculateTransform_GetRotationToTimelinePlayer, cannot find rotation target actor with entity ID %lld, %s"),
		PlayNiagaraParams.RotationTargetEntityID, *ToString());
	return false;
}

USceneComponent* FKGNiagaraUpdateContext::GetAttachComponentByComponentName()
{
	AActor* Spawner = KGUtils::GetActorByID(PlayNiagaraParams.SpawnerID);
	if (!IsValid(Spawner))
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateContext::GetAttachComponentByComponentName, invalid spawner %lld, %s"),
			PlayNiagaraParams.SpawnerID, *PlayNiagaraParams.NiagaraEffectPath);
		return nullptr;
	}
	
	if (PlayNiagaraParams.AttachComponentName.IsNone())
	{
		return nullptr;
	}
	
	USceneComponent* Component = UKGActorUtil::GetComponentByNameAndClass(Spawner, PlayNiagaraParams.AttachComponentName, USceneComponent::StaticClass());
	if (!Component)
	{
		UAddMeshComponent* AddMeshComponent = Spawner->FindComponentByClass<UAddMeshComponent>();
		if (AddMeshComponent == nullptr)
		{
			AddMeshComponent = NewObject<UAddMeshComponent>(Spawner, UAddMeshComponent::StaticClass());
			check(AddMeshComponent);
			AddMeshComponent->RegisterComponent();
		}
				
		// add mesh component目前是按需创建的
		UE_LOG(LogEM, Log,
			TEXT("FKGNiagaraUpdateContext::GetAttachComponentByComponentName, cannot find attach component %s, try to cache niagara param, NiagaraEffectPath: %d, %s"),
			*PlayNiagaraParams.AttachComponentName.ToString(), NiagaraEffectId, *PlayNiagaraParams.NiagaraEffectPath);
		AddMeshComponent->CacheNiagaraParamBefore(NiagaraEffectId, PlayNiagaraParams.AttachComponentName, PlayNiagaraParams.bCacheEvenIfDynamicMeshCtxNotFound);
		bNeedUnCacheNiagaraParamOnDestroy = PlayNiagaraParams.bCacheEvenIfDynamicMeshCtxNotFound;
	}
	
	return Component;
}

void FKGNiagaraUpdateContext::UpdateNiagaraFollowActor(const FName& ParamName, KGObjectID FollowActorId, bool bAbsoluteNiagaraRotationInFollow)
{
	RemoveUpdateTasksByType(EKGNiagaraUpdateTaskType::FollowActorLocation);
	
	AActor* Target = Cast<AActor>(KGUtils::GetObjectByID(FollowActorId));
	if (!IsValid(Target))
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::UpdateNiagaraFollowActor, invalid target %s"), *ToString());
		return;
	}
	
	TSharedPtr<FKGNiagaraUpdateTaskFollowActorLocation> TaskPtr = CreateUpdateTask<FKGNiagaraUpdateTaskFollowActorLocation>();
	check(TaskPtr.IsValid());
	TaskPtr->FollowingTargetParamName = ParamName;
	TaskPtr->FollowingTargetActor = Target;
	TaskPtr->bAbsoluteRotation = bAbsoluteNiagaraRotationInFollow;
	if (NiagaraComponent)
	{
		TaskPtr->DoTaskInit(this);
	}
}

int32 FKGNiagaraUpdateContext::SetNiagaraSplineLink(
	const FString& SplineBPPath, const FString& SplineUserVarName, const FKGNiagaraUpdateSplineTargetParams& TargetParams)
{
	// 有可能是不同的user var name, 这里不应该删掉同类型的task
	auto TaskPtr = this->CreateUpdateTask<FKGNiagaraUpdateTaskUpdateSplineParams>();
	if (!TaskPtr.IsValid())
	{
		return KG_INVALID_UPDATE_TASK_ID;
	}
	
	TaskPtr->SplineBPPath = SplineBPPath;
	TaskPtr->SplineUserVarName = SplineUserVarName;
	TaskPtr->TargetParams = TargetParams;
	if (NiagaraComponent)
	{
		TaskPtr->DoTaskInit(this);
	}
	
	return TaskPtr->GetTaskID();
}

int32 FKGNiagaraUpdateContext::SetNiagaraSplineLinkTargetLocation(int32 InTaskId, float Yaw, const FVector& InTargetLocation)
{
	auto TaskPtr = this->GetUpdateTask<FKGNiagaraUpdateTaskUpdateSplineParams>(InTaskId);
	if (!TaskPtr.IsValid())
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateContext::SetNiagaraSplineLinkTargetLocation, cannot find update task by id %d, %s"),
			InTaskId, *ToString());
		return KG_INVALID_UPDATE_TASK_ID;
	}
	
	if (TaskPtr->TargetParams.Method != EKGNiagaraUpdateSplineTargetMethod::BindToLocation &&
		TaskPtr->TargetParams.Method != EKGNiagaraUpdateSplineTargetMethod::BindToLocationOnGround)
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateContext::SetNiagaraSplineLinkTargetLocation, cannot update target location to BindToTargetTask %d, %s"),
			InTaskId, *ToString());
		return KG_INVALID_UPDATE_TASK_ID;
	}

	TaskPtr->TargetParams.RelativeYaw = Yaw;
	TaskPtr->TargetParams.TargetLocation = InTargetLocation;

	return TaskPtr->GetTaskID();
}

bool FKGNiagaraUpdateContext::UpdateNiagaraSplineLinkTargetComponent(int32 InTaskId, KGObjectID TargetComponentId, FName TargetSocketName)
{
	auto TaskPtr = this->GetUpdateTask<FKGNiagaraUpdateTaskUpdateSplineParams>(InTaskId);
	if (!TaskPtr.IsValid())
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateContext::UpdateNiagaraSplineLinkTargetComponent, cannot find update task by id %d, %s"),
			InTaskId, *ToString());
		return false;
	}

	if (TaskPtr->TargetParams.Method != EKGNiagaraUpdateSplineTargetMethod::BindToTargetComponent)
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateContext::SetNiagaraSplineLinkTargetLocation, cannot update target component to BindToLocationTask %d, %s"),
			InTaskId, *ToString());
		return false;
	}

	if (!TaskPtr->UpdateTargetComponent(*this, TargetComponentId, TargetSocketName))
	{
		return false;
	}

	TaskPtr->TargetParams.TargetComponentId = TargetComponentId;
	TaskPtr->TargetParams.TargetSocketName = TargetSocketName;
	return true;
}

void FKGNiagaraUpdateContext::UpdateNiagaraCameraArmLengthParam(const FName& ParamName)
{
	TSharedPtr<FKGNiagaraUpdateTaskFollowCameraArmLength> TaskPtr = CreateUpdateTask<FKGNiagaraUpdateTaskFollowCameraArmLength>();
	check(TaskPtr.IsValid());
	TaskPtr->CameraArmLengthParamName = ParamName;
	if (NiagaraComponent)
	{
		TaskPtr->DoTaskInit(this);
	}
}

void FKGNiagaraUpdateContext::SetNiagaraFollowCameraFOV()
{
	if (HasTaskByTaskType(EKGNiagaraUpdateTaskType::FollowCameraFOV))
	{
		return;		
	}
	
	TSharedPtr<FKGNiagaraUpdateTaskFollowCameraFOV> TaskPtr = CreateUpdateTask<FKGNiagaraUpdateTaskFollowCameraFOV>();
	check(TaskPtr.IsValid());
	if (NiagaraComponent)
	{
		TaskPtr->DoTaskInit(this);
	}
}

void FKGNiagaraUpdateContext::UpdateNiagaraPlayRate()
{
	AActor* Spawner = KGUtils::GetActorByID(PlayNiagaraParams.SpawnerID);
	if (!IsValid(Spawner))
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateContext::UpdateNiagaraPlayRate, invalid spawner %lld, %s"),
			PlayNiagaraParams.SpawnerID, *PlayNiagaraParams.NiagaraEffectPath);
		return;
	}
	
	float NewPlayRate = PlayNiagaraParams.EffectPlayRate;
	if (PlayNiagaraParams.bFollowSlomo)
	{
		NewPlayRate *= Spawner->CustomTimeDilation;
	}
	
	if (FMath::IsNearlyEqual(NewPlayRate, DynamicPlayRate))
	{
		return;
	}
	
	DynamicPlayRate = NewPlayRate;
	
	if (NiagaraComponent && NiagaraComponent->GetSystemInstanceController())
	{
		if (FNiagaraSystemInstance* SI = NiagaraComponent->GetSystemInstanceController()->GetSystemInstance_Unsafe())
		{
			SI->SetCustomTimeDilation(NewPlayRate);
		}
	}
}

void FKGNiagaraUpdateContext::SetNiagaraFaceToActor(AActor* Actor, EKGNiagaraFaceToActorRotationType RotationType)
{
	RemoveAllParticleRotationTasks();
	
	if (!Actor)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::SetNiagaraFaceToActor, invalid target actor, %s"), *ToString());
		return;
	}
	
	TSharedPtr<FKGNiagaraUpdateTaskFaceToActor> TaskPtr = CreateUpdateTask<FKGNiagaraUpdateTaskFaceToActor>();
	check(TaskPtr.IsValid());
	TaskPtr->FacingTargetActor = Actor;
	TaskPtr->RotationType = RotationType;
	if (NiagaraComponent)
	{
		TaskPtr->DoTaskInit(this);
	}
}

void FKGNiagaraUpdateContext::SetNiagaraFaceToLocation(float InLocationX, float InLocationY)
{
	RemoveAllParticleRotationTasks();
	
	TSharedPtr<FKGNiagaraUpdateTaskFaceToLocation> TaskPtr = CreateUpdateTask<FKGNiagaraUpdateTaskFaceToLocation>();
	check(TaskPtr.IsValid());
	TaskPtr->FacingTargetLocation.X = InLocationX;
	TaskPtr->FacingTargetLocation.Y = InLocationY;
	if (NiagaraComponent)
	{
		TaskPtr->DoTaskInit(this);
	}
}

void FKGNiagaraUpdateContext::AddLinearSampleVectorParams(
	const FName& ParamName, float StartX, float StartY, float StartZ, float EndX, float EndY, float EndZ, float Duration, bool bUseNiagaraAccumulatedTime)
{
	if (Duration < UE_KINDA_SMALL_NUMBER)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::AddLinearSampleVectorParams, invalid duration %f, %s"),
			Duration, *ToString());
		return;
	}
	
	FVector StartVal(StartX, StartY, StartZ);
	if (StartVal.ContainsNaN())
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::AddLinearSampleVectorParams, invalid start value %s, %s"),
			*StartVal.ToString(), *ToString());
		return;
	}

	FVector EndVal(EndX, EndY, EndZ);
	if (EndVal.ContainsNaN())
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::AddLinearSampleVectorParams, invalid EndVal value %s, %s"),
			*EndVal.ToString(), *ToString());
		return;
	}

	TSharedPtr<FKGNiagaraUpdateTaskUpdateParamByLinearSample> TaskPtr = CreateUpdateTask<FKGNiagaraUpdateTaskUpdateParamByLinearSample>();
	check(TaskPtr.IsValid());
	TaskPtr->ParamName = ParamName;
	TaskPtr->ValueType = EFKGNiagaraParamLinearSampleValueType::Vector;
	TaskPtr->StartVal.SetSubtype<FVector>(StartVal);
	TaskPtr->EndVal.SetSubtype<FVector>(EndVal);
	TaskPtr->Duration = Duration;
	TaskPtr->bUseNiagaraAccumulatedTime = bUseNiagaraAccumulatedTime;
	if (NiagaraComponent)
	{
		TaskPtr->DoTaskInit(this);
	}
}

void FKGNiagaraUpdateContext::AddLinearSampleFloatParams(
	const FName& ParamName, float StartVal, float EndVal, float Duration, bool bUseNiagaraAccumulatedTime)
{
	if (Duration < UE_KINDA_SMALL_NUMBER)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::AddLinearSampleFloatParams, invalid duration %f, %s"),
			Duration, *ToString());
		return;
	}
	
	UE_LOG(LogEM, Log, TEXT("FKGNiagaraUpdateContext::AddLinearSampleFloatParams, %s, %s, %f, %f, %f"), *ParamName.ToString(), *ToString(), StartVal, EndVal, Duration);

	TSharedPtr<FKGNiagaraUpdateTaskUpdateParamByLinearSample> TaskPtr = CreateUpdateTask<FKGNiagaraUpdateTaskUpdateParamByLinearSample>();
	check(TaskPtr.IsValid());
	TaskPtr->ParamName = ParamName;
	TaskPtr->ValueType = EFKGNiagaraParamLinearSampleValueType::Scalar;
	TaskPtr->OriginStartVal.SetSubtype<float>(StartVal);
	TaskPtr->StartVal.SetSubtype<float>(StartVal);
	TaskPtr->OriginEndVal.SetSubtype<float>(EndVal);
	TaskPtr->EndVal.SetSubtype<float>(EndVal);
	TaskPtr->OriginDuration = Duration;
	TaskPtr->Duration = Duration;
	TaskPtr->bUseNiagaraAccumulatedTime = bUseNiagaraAccumulatedTime;
	// 由于需要支持随时更新目标值, 因此task不能在更新结束时自行删除, 否则会丢失原始开始和结束值
	TaskPtr->SetAutoDestroyWhenFinished(false);
	
	if (NiagaraComponent)
	{
		TaskPtr->DoTaskInit(this);
	}
}

void FKGNiagaraUpdateContext::UpdatePositionWithArcParams(
	const FName& ParamName, float Radius, float StartRelativeYaw, float RotateAngle, float Duration)
{
	if (Duration < UE_KINDA_SMALL_NUMBER)
	{
		UE_LOG(LogEM, Error, TEXT("UpdatePositionWithArcParams::SetNiagaraUpdatePositionWithArcParams, invalid duration %f, %s"),
			Duration, *ToString());
		return;
	}

	if (Radius < UE_KINDA_SMALL_NUMBER)
	{
		UE_LOG(LogEM, Error, TEXT("UpdatePositionWithArcParams::SetNiagaraUpdatePositionWithArcParams, invalid radius %f, %s"),
			Radius, *ToString());
		return;
	}

	if (FMath::IsNearlyZero(RotateAngle))
	{
		UE_LOG(LogEM, Error, TEXT("UpdatePositionWithArcParams::SetNiagaraUpdatePositionWithArcParams, invalid RotateAngle %f, %s"),
			RotateAngle, *ToString());
		return;
	}

	TSharedPtr<FKGNiagaraUpdateTaskUpdatePositionWithArcParams> TaskPtr = CreateUpdateTask<FKGNiagaraUpdateTaskUpdatePositionWithArcParams>();
	check(TaskPtr.IsValid());
	TaskPtr->StartRelativeYaw = StartRelativeYaw;
	TaskPtr->RotateAngle = RotateAngle;
	TaskPtr->ParamName = ParamName;
	TaskPtr->Duration = Duration;
	TaskPtr->Radius = Radius;
	if (NiagaraComponent)
	{
		TaskPtr->DoTaskInit(this);
	}
}

void FKGNiagaraUpdateContext::AddFloatCurveParams(
	FName ParamName, const FString& CurvePath, bool bNeedRemap, float RemapTime, bool bUseNiagaraAccumulatedTime, bool bDestroyNiagaraOnCurveEvalFinished)
{
	TSharedPtr<FKGNiagaraUpdateTaskUpdateParamByCurve> TaskPtr = CreateUpdateTask<FKGNiagaraUpdateTaskUpdateParamByCurve>();
	check(TaskPtr.IsValid());
	TaskPtr->ParamName = ParamName;
	TaskPtr->bUseNiagaraAccumulatedTime = bUseNiagaraAccumulatedTime;
	TaskPtr->CurveParams.CurvePath = CurvePath;
	TaskPtr->CurveParams.bNeedRemap = bNeedRemap;
	TaskPtr->CurveParams.RemapTime = RemapTime;
	TaskPtr->bDestroyNiagaraOnCurveEvalFinished = bDestroyNiagaraOnCurveEvalFinished;
	if (NiagaraComponent)
	{
		TaskPtr->DoTaskInit(this);
	}
}

void FKGNiagaraUpdateContext::SetParticleColorScaleUpdateCurve(const FString& CurvePath, float Duration)
{
	RemoveAllParticleColorScaleUpdateTasks();
	
	TSharedPtr<FKGNiagaraUpdateTaskUpdateParticleColorScale> TaskPtr = CreateUpdateTask<FKGNiagaraUpdateTaskUpdateParticleColorScale>();
	check(TaskPtr.IsValid());
	TaskPtr->bUseNiagaraAccumulatedTime = false;
	TaskPtr->ParticleColorScaleCurveTime = Duration;
	TaskPtr->ParticleColorScaleUpdateCurve = CurvePath;
	if (NiagaraComponent)
	{
		TaskPtr->DoTaskInit(this);
	}
}

void FKGNiagaraUpdateContext::SetLinearSampleParticleColorScaleUpdateTask(bool bBlendIn, float Duration, bool bInitBlendIn)
{
	RemoveAllParticleColorScaleUpdateTasks();

	TSharedPtr<FKGNiagaraUpdateTaskUpdateParticleColorScaleLinearSample> TaskPtr = CreateUpdateTask<FKGNiagaraUpdateTaskUpdateParticleColorScaleLinearSample>();
	check(TaskPtr.IsValid());
	if (bBlendIn && bInitBlendIn)
	{
		TaskPtr->StartVal = KG_NIAGARA_MIN_PARTICLE_COLOR_SCALE;
	}
	// 不能依赖particle color scale来做特效的隐藏逻辑, 否则会导致额外的渲染开销, 所以blend out只能搭着销毁或者特效隐藏逻辑来实现
	// 这里需要限制下blend out过程中不能设置particle color scale到0.0f, 否则会增加特效的渲染开销
	TaskPtr->EndVal = bBlendIn ? 1.0f : KG_NIAGARA_MIN_PARTICLE_COLOR_SCALE;
	TaskPtr->Duration = Duration;
	if (NiagaraComponent)
	{
		TaskPtr->DoTaskInit(this);
	}
}

void FKGNiagaraUpdateContext::BlendOutNiagaraByNiagaraParam(const FString& CurvePath, const FName& ParamName, float StartVal, float EndVal, float Duration)
{
	if (CurvePath.IsEmpty())
	{
		AddLinearSampleFloatParams(ParamName, StartVal, EndVal, Duration, false);
		if (EffectManager.IsValid())
		{
			EffectManager->SetNiagaraLifeTimeTimer(NiagaraEffectId, EKGNiagaraTimeoutState::Deactivate, Duration);
		}
	}
	else
	{
		AddFloatCurveParams(ParamName, CurvePath, false, 0.0f, false, true);
	}
}

void FKGNiagaraUpdateContext::SetNiagaraFollowActorRotation()
{
	// 修改特效朝向为当前spawner的面向
	TSharedPtr<FKGNiagaraUpdateTaskFollowActorRotation> TaskPtr = CreateUpdateTask<FKGNiagaraUpdateTaskFollowActorRotation>();
	check(TaskPtr.IsValid());
	if (NiagaraComponent)
	{
		TaskPtr->DoTaskInit(this);
	}
}

void FKGNiagaraUpdateContext::UpdateParamByHeightDiff(const FString& CurvePath, const FName& ParamName, float VisibilityChangeBlendTime, float HeightDiffHalfLifeTime)
{
	if (CurvePath.IsEmpty())
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateContext::UpdateParamByHeightDiff, empty curve path, %s"), *ToString());
		return;
	}

	if (ParamName.IsNone())
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateContext::UpdateParamByHeightDiff, invalid param name, %s"), *ToString());
		return;
	}
	
	TSharedPtr<FKGNiagaraUpdateTaskUpdateParamByHeightDiff> TaskPtr = CreateUpdateTask<FKGNiagaraUpdateTaskUpdateParamByHeightDiff>();
	check(TaskPtr.IsValid());
	TaskPtr->ParamName = ParamName;
	TaskPtr->CurvePath = CurvePath;
	TaskPtr->VisibilityChangeBlendTime = VisibilityChangeBlendTime;
	TaskPtr->HeightDiffHalfLifeTime = HeightDiffHalfLifeTime;
	if (NiagaraComponent)
	{
		TaskPtr->DoTaskInit(this);
	}
}

void FKGNiagaraUpdateContext::SetNiagaraStickOnGround(float UpCheckDistance, float DownCheckDistance, bool bUseNiagaraAsPivotPos)
{
	if (UpCheckDistance < -UE_KINDA_SMALL_NUMBER || DownCheckDistance < -UE_KINDA_SMALL_NUMBER)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::SetNiagaraStickOnGround, invalid check distances, UpCheckDistance: %f, DownCheckDistance: %f, %s"),
			UpCheckDistance, DownCheckDistance, *ToString());
		return;
	}

	TSharedPtr<FKGNiagaraUpdateTaskStickOnGround> TaskPtr = CreateUpdateTask<FKGNiagaraUpdateTaskStickOnGround>();
	check(TaskPtr.IsValid());
	TaskPtr->GroundCheckUpDistance = UpCheckDistance;
	TaskPtr->GroundCheckDownDistance = DownCheckDistance;
	TaskPtr->bUseNiagaraAsPivotPos = bUseNiagaraAsPivotPos;
	if (NiagaraComponent)
	{
		TaskPtr->DoTaskInit(this);
	}
}

void FKGNiagaraUpdateContext::SetNiagaraParamByEffectID(uint32 ParamID)
{
	UKGDataCacheManager* DataCacheManager = UKGDataCacheManager::GetInstance(EffectManager.Get());
	if (!DataCacheManager)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::SetNiagaraParamsByParamID, invalid data cache manager"));
		return;
	}
	
	auto* NiagaraParamData = DataCacheManager->GetNiagaraParamsData(ParamID);
	if (!NiagaraParamData)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::SetNiagaraParamsByParamID, invalid NiagaraParamData %d"), ParamID);
		return;
	}
	
	for (const auto& Kvp : NiagaraParamData->ScalarParams)
	{
		UpdateNiagaraFloatParam(Kvp.Key, Kvp.Value);
	}
	
	for (const auto& Kvp : NiagaraParamData->LinearSampleScalarParams)
	{
		AddLinearSampleFloatParams(Kvp.Key, Kvp.Value.StartVal, Kvp.Value.EndVal, Kvp.Value.Duration, false);
	}
	
	for (const auto& Kvp : NiagaraParamData->CurveParams)
	{
		AddFloatCurveParams(Kvp.Key, Kvp.Value.CurvePath, Kvp.Value.bNeedRemap, Kvp.Value.RemapTime, false, false);
	}
}

void FKGNiagaraUpdateContext::ChangeAttachSocket(const FName& NewSocketName)
{
	if (!PlayNiagaraParams.NeedAttach())
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateContext::ChangeAttachSocket, niagara effect not attach, %s"), *ToString());
		return;
	}
	
	AActor* Spawner = KGUtils::GetActorByID(PlayNiagaraParams.SpawnerID);
	if (!IsValid(Spawner))
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateContext::ChangeAttachSocket, invalid spawner, %s"), *ToString());
		return;
	}
	
	// 目前socket name用的地方
	// 1, 用于挂接特效的挂接点
	// 2, 对于技能特效来说, 提供SocketInit的初始位置或者朝向
	// 3, 对于非挂接特效来说, 提供创建的世界空间位置以及朝向
	// 4, 用于确定挂接特效的attach component
	// 就目前的使用case而言, 2,3,4都是创建阶段就定好的, 暂不需要支持修改, 这里只支持1
	
	auto& AttachedSpawnInfo = PlayNiagaraParams.GetAttachedSpawnInfoChecked();
	AttachedSpawnInfo.AttachPointName = NewSocketName;
	if (!NiagaraComponent)
	{
		return;
	}
	
	// 此时需要重新找attach component
	auto* AttachParent = NiagaraComponent->GetAttachParent();
	if (AttachedSpawnInfo.SearchAttachComponentType == EKGNiagaraSearchAttachComponentType::FindComponentBySocketName)
	{
		AttachParent = UKGActorUtil::GetComponentBySocket(Spawner, AttachedSpawnInfo.AttachPointName);
	}
	
	if (!AttachParent)
	{
		// 外部自己销毁了特效的挂接actor但是没有通知销毁或者detach特效时会走到这里
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateContext::ChangeAttachSocket, invalid attach parent found for attached niagara %s"), *ToString());
		return;
	}
	
	AttachComponent = AttachParent;
	NiagaraComponent->AttachToComponent(AttachParent, FAttachmentTransformRules::KeepRelativeTransform, NewSocketName);
}

void FKGNiagaraUpdateContext::SetForceUseAbsoluteScale(bool bInForceUseAbsoluteScale)
{
	if (bForceUseAbsoluteScale == bInForceUseAbsoluteScale)
	{
		return;
	}
	const bool bOldForceUseAbsoluteScale = bForceUseAbsoluteScale;
	bForceUseAbsoluteScale = bInForceUseAbsoluteScale;
	
	if (!NiagaraComponent)
	{
		return;
	}
	
	if (PlayNiagaraParams.NeedAttach())
	{
		auto& AttachedSpawnInfo = PlayNiagaraParams.GetAttachedSpawnInfoChecked();
		bool bOldAbsoluteScale = AttachedSpawnInfo.bAbsoluteScale || bOldForceUseAbsoluteScale;
		bool bNewAbsoluteScale = AttachedSpawnInfo.bAbsoluteScale || bForceUseAbsoluteScale;
		if (bOldAbsoluteScale != bNewAbsoluteScale)
		{
			NiagaraComponent->SetUsingAbsoluteScale(bNewAbsoluteScale);
		}
		return;
	}

	auto& UnattachedSpawnInfo = PlayNiagaraParams.GetUnattachedSpawnInfoChecked();
	bool bOldAbsoluteScale = UnattachedSpawnInfo.bAbsoluteScale || bOldForceUseAbsoluteScale;
	bool bNewAbsoluteScale = UnattachedSpawnInfo.bAbsoluteScale || bForceUseAbsoluteScale;
	if (bOldAbsoluteScale == bNewAbsoluteScale)
	{
		return;
	}
	
	if (bNewAbsoluteScale)
	{
		UE_LOG(LogEM, Log, TEXT("FKGNiagaraUpdateContext::SetForceUseAbsoluteScale, change to absolute scale, %s, %s -> %s"), 
			*ToString(), *NiagaraComponent->GetComponentScale().ToString(), 
			*UnattachedSpawnInfo.WorldOrRelativeTrans.GetScale3D().ToString());
		NiagaraComponent->SetRelativeScale3D(UnattachedSpawnInfo.WorldOrRelativeTrans.GetScale3D());
	}
	else
	{
		UE_LOG(LogEM, Log, TEXT("FKGNiagaraUpdateContext::SetForceUseAbsoluteScale, change to attached scale, %s, %s -> %s"), 
			*ToString(), *NiagaraComponent->GetComponentScale().ToString(), 
			*NewWorldSpaceOrRelativeSpawnTrans.ToString());
		NiagaraComponent->SetRelativeScale3D(NewWorldSpaceOrRelativeSpawnTrans.GetScale3D());
	}
}

void FKGNiagaraUpdateContext::SetNiagaraFollowSpawnerHiddenState(bool bInFollowSpawnerHiddenState)
{
	if (bFollowSpawnerHiddenState == bInFollowSpawnerHiddenState)
	{
		return;
	}
	const bool bOldFollowSpawnerHidden = bFollowSpawnerHiddenState && PlayNiagaraParams.bFollowHidden;
	bFollowSpawnerHiddenState = bInFollowSpawnerHiddenState;
	const bool bNewFollowSpawnerHidden = bFollowSpawnerHiddenState && PlayNiagaraParams.bFollowHidden;
	if (bOldFollowSpawnerHidden == bNewFollowSpawnerHidden)
	{
		return;
	}
	
	const bool bHasOwnerHiddenReason = HiddenMask & (1LL << static_cast<uint64>(EKGNiagaraHiddenReason::OWNER_SET_HIDDEN));
	bool bOwnerVisible = true;
	if (AActor* Spawner = KGUtils::GetActorByID(PlayNiagaraParams.SpawnerID))
	{
		bOwnerVisible = !Spawner->IsHidden();
	}
	
	if (bNewFollowSpawnerHidden && !bOwnerVisible)
	{
		UE_LOG(LogEM, Log, TEXT("FKGNiagaraUpdateContext::SetNiagaraFollowSpawnerHiddenState, set niagara hidden %s"), *ToString());
		UpdateNiagaraHiddenState(true, static_cast<uint8>(EKGNiagaraHiddenReason::OWNER_SET_HIDDEN), false);
	}
	else if (!bNewFollowSpawnerHidden && bHasOwnerHiddenReason)
	{
		UE_LOG(LogEM, Log, TEXT("FKGNiagaraUpdateContext::SetNiagaraFollowSpawnerHiddenState, set niagara visible %s"), *ToString());
		UpdateNiagaraHiddenState(false, static_cast<uint8>(EKGNiagaraHiddenReason::OWNER_SET_HIDDEN), false);
	}
}

bool FKGNiagaraUpdateContext::UpdateLinearSampleParamTargetValue(const FName& ParamName, float TargetVal, bool bUseNewDuration, float InNewDuration)
{
	TSharedPtr<FKGNiagaraUpdateTaskUpdateParamByLinearSample> LinearSampleParamPtr = GetFloatLinearSampleUpdateTask(ParamName);
	if (!LinearSampleParamPtr.IsValid())
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateContext::UpdateLinearSampleParamTargetValue, invalid param name %s, %s"),
			*ParamName.ToString(), *ToString());
		return false;
	}
	
	UE_LOG(LogEM, Log, TEXT("FKGNiagaraUpdateContext::UpdateLinearSampleParamTargetValue, %s, %s, %f, %d, %f"), 
		*ParamName.ToString(), *ToString(), TargetVal, bUseNewDuration, InNewDuration);

	const float OriginStartVal = LinearSampleParamPtr->OriginStartVal.GetSubtype<float>();
	const float OriginEndVal = LinearSampleParamPtr->OriginEndVal.GetSubtype<float>();
	const float OriginDuration = LinearSampleParamPtr->OriginDuration;
	
	const float CurVal = LinearSampleParamPtr->CurVal.HasSubtype<float>() ? LinearSampleParamPtr->CurVal.GetSubtype<float>() : OriginStartVal;
	float NewDuration;
	if (FMath::IsNearlyEqual(OriginStartVal, OriginEndVal))
	{
		NewDuration = 0.0f;
	}
	else
	{
		NewDuration = bUseNewDuration ? InNewDuration : (FMath::Abs((TargetVal - CurVal) / (OriginEndVal - OriginStartVal)) * OriginDuration);
	}
		
	LinearSampleParamPtr->StartVal = LinearSampleParamPtr->CurVal;
	LinearSampleParamPtr->EndVal.SetSubtype<float>(TargetVal);
	LinearSampleParamPtr->ResetAccumulatedTime();
	LinearSampleParamPtr->bFinished = false;
	// 有可能这里设置TargetVal为CurVal, 实际只需要再tick一次就可以了, 此时NewDuration为0是合理的
	LinearSampleParamPtr->Duration = NewDuration;

	return true;
}

void FKGNiagaraUpdateContext::AddOrUpdateLinearSampleParamTargetValue(
	const FName& ParamName, float StartValue, float TargetValue, bool bUseNewDuration, float NewDuration)
{
	TSharedPtr<FKGNiagaraUpdateTaskUpdateParamByLinearSample> LinearSampleParamPtr = GetFloatLinearSampleUpdateTask(ParamName);
	if (!LinearSampleParamPtr.IsValid())
	{
		AddLinearSampleFloatParams(ParamName, StartValue, TargetValue, NewDuration, false);
		return;
	}
	
	UpdateLinearSampleParamTargetValue(ParamName, TargetValue, bUseNewDuration, NewDuration);
}

void FKGNiagaraUpdateContext::FinishLinearSampleParamTask(const FName& ParamName)
{
	TSharedPtr<FKGNiagaraUpdateTaskUpdateParamByLinearSample> LinearSampleParamPtr = GetFloatLinearSampleUpdateTask(ParamName);
	if (!LinearSampleParamPtr.IsValid())
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateContext::FinishLinearSampleParamTask, invalid param name %s, %s"),
			*ParamName.ToString(), *ToString());
		return;
	}
	
	LinearSampleParamPtr->bFinished = true;
}

// Effect Audio
void FKGNiagaraUpdateContext::SetEffectAudio(const FString& AudioName)
{
	auto TaskPtr = CreateUpdateTask<FKGNiagaraUpdateTaskSetEffectAudio>();
	check(TaskPtr.IsValid());
	TaskPtr->AudioName = AudioName;
	TaskPtr->AudioId = 0;
	if (this->NiagaraComponent != nullptr)
	{
		TaskPtr->DoTaskInit(this);
	}
}

void FKGNiagaraUpdateContext::RemoveAllParticleColorScaleUpdateTasks()
{
	RemoveUpdateTasksByType(EKGNiagaraUpdateTaskType::UpdateParticleColorScaleByCurve);
	RemoveUpdateTasksByType(EKGNiagaraUpdateTaskType::UpdateParticleColorScaleLinearSample);
}

void FKGNiagaraUpdateContext::RemoveAllParticleRotationTasks()
{
	RemoveUpdateTasksByType(EKGNiagaraUpdateTaskType::FaceToActor);
	RemoveUpdateTasksByType(EKGNiagaraUpdateTaskType::FaceToLocation);
}

TSharedPtr<FKGNiagaraUpdateTaskUpdateParamByLinearSample> FKGNiagaraUpdateContext::GetFloatLinearSampleUpdateTask(const FName& ParamName)
{
	auto* TaskIDsPtr = TaskIDsByType.Find(EKGNiagaraUpdateTaskType::UpdateParamByLinearSample);
	if (TaskIDsPtr == nullptr || TaskIDsPtr->Num() == 0)
	{
		return nullptr;
	}

	for (const auto TaskID : *TaskIDsPtr)
	{
		auto* TaskPtr = NiagaraUpdateTasks.Find(TaskID);
		if (TaskPtr == nullptr)
		{
			continue;
		}
		
		auto& Task = *TaskPtr;
		if (!Task.IsValid())
		{
			UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::GetFloatLinearSampleUpdateTask, invalid task ptr found, TaskID: %d, %s"), TaskID, *ToString());
			continue;
		}
		
		if (Task->GetTaskType() != EKGNiagaraUpdateTaskType::UpdateParamByLinearSample)
		{
			UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::GetFloatLinearSampleUpdateTask, task type mismatch for task id %d, expected %d, actual %d, %s"),
				TaskID, static_cast<int32>(EKGNiagaraUpdateTaskType::UpdateParamByLinearSample), static_cast<int32>(Task->GetTaskType()), *ToString());
			continue;
		}
		
		auto LinearSampleTaskPtr = StaticCastSharedPtr<FKGNiagaraUpdateTaskUpdateParamByLinearSample>(Task);
		if (LinearSampleTaskPtr->ParamName == ParamName && LinearSampleTaskPtr->ValueType == EFKGNiagaraParamLinearSampleValueType::Scalar)
		{
			return LinearSampleTaskPtr;
		}
	}

	return nullptr;
}

void FKGNiagaraUpdateContext::RefreshTransparencyScale()
{
	if (!NiagaraComponent)
	{
		return;
	}
	
	if (!HasTaskByTaskType(EKGNiagaraUpdateTaskType::UpdateParticleColorScaleByCurve) &&
		!HasTaskByTaskType(EKGNiagaraUpdateTaskType::UpdateParticleColorScaleLinearSample))
	{
		NiagaraComponent->SetParticleColorScale(GetBaseTransparencyScaleFactor());
	}
}

void FKGNiagaraUpdateContext::TickUpdateTasks(float DeltaTime)
{
	TArray<uint32, TInlineAllocator<2>> TaskIDsToRemove;
	// 这里是为了避免Task在Update阶段触发新的Task导致边迭代边修改的问题
	TSet<uint32> TempTaskIDs = TickableNiagaraUpdateTaskIDs;
	FKGNiagaraUpdateTaskTarget TaskTarget(this);
	const bool bIsHidden = IsHidden();
	for (const auto TaskID : TempTaskIDs)
	{
		auto* TaskPtr = NiagaraUpdateTasks.Find(TaskID);
		if (TaskPtr != nullptr)
		{
			auto& Task = *TaskPtr;
			if (!Task.IsValid())
			{
				UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::TickUpdateTasks, invalid task ptr found, TaskID: %d, %s"), TaskID, *ToString());
				TaskIDsToRemove.Add(TaskID);	
				continue;
			}
			
			if (bIsHidden && Task->GetTickBehavior() != EKGNiagaraTickBehavior::ForceEveryFrame)
			{
				Task->AdvanceAccumulatedTime(DeltaTime);
			}
			else
			{
				Task->DoTaskUpdate(DeltaTime, TaskTarget);
			}

			if (Task->IsFinished() && Task->ShouldAutoDestroyWhenFinished())
			{
				TaskIDsToRemove.Add(TaskID);	
			}
		}
	}

	for (const auto TaskID : TaskIDsToRemove)
	{
		RemoveUpdateTask(TaskID);
	}
}

void FKGNiagaraUpdateContext::RemoveUpdateTask(uint32 TaskID)
{
	if (!NiagaraUpdateTasks.Contains(TaskID))
	{
		return;
	}

	auto& TaskPtr = NiagaraUpdateTasks[TaskID];
	TaskPtr->DoTaskDestroy(this);
	const auto TaskType = TaskPtr->GetTaskType();
	check(TaskIDsByType.Contains(TaskType));
	TaskIDsByType[TaskType].Remove(TaskID);
	TickableNiagaraUpdateTaskIDs.Remove(TaskID);
	NiagaraUpdateTasks.Remove(TaskID);
}

void FKGNiagaraUpdateContext::RemoveUpdateTasksByType(EKGNiagaraUpdateTaskType TaskType)
{
	if (!TaskIDsByType.Contains(TaskType))
	{
		return;
	}

	TArray<uint32> TaskIDsCopy = TaskIDsByType[TaskType];
	for (const auto TaskID : TaskIDsCopy)
	{
		RemoveUpdateTask(TaskID);
	}
}

void FKGNiagaraUpdateContext::RemoveAllUpdateTasks()
{
	for (const auto& TaskPair : NiagaraUpdateTasks)
	{
		TaskPair.Value->DoTaskDestroy(this);
	}
	NiagaraUpdateTasks.Empty();
	TaskIDsByType.Empty();
	TickableNiagaraUpdateTaskIDs.Empty();
}

void FKGNiagaraUpdateContext::InternalSetNiagaraComponentHiddenState(bool bHidden)
{
	if (NiagaraComponent)
	{
		NiagaraComponent->SetHiddenInGame(bHidden);
		NiagaraComponent->SetVisibility(!bHidden);
	}
}
