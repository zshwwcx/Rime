#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskSetEffectAudio.h"
#include "3C/Effect/KGNiagaraUpdateContext.h"
#include "AkComponent.h"
#include "Manager/KGAkAudioManager.h"
#include "NiagaraComponent.h"
#include "3C/Effect/KGEffectManager.h"

bool FKGNiagaraUpdateTaskSetEffectAudio::OnTaskInit(const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	auto* NiagaraComponent = InTaskTarget.GetNiagaraComponent();
	if (!NiagaraComponent)
	{
		return false;
	}
	
	AActor* OwnerActor = InTaskTarget.GetSpawnerActor();
	if (!OwnerActor)
	{
		return false;
	}
	
	UKGAkAudioManager* AudioManager = UKGAkAudioManager::GetInstance(OwnerActor);
	if (AudioManager == nullptr)
	{
		return false;
	}
	
	// Stop Current Audio
	if (this->AudioId != 0)
	{
		AudioManager->InnerStopEventByPlayingID(this->AudioId);
		this->AudioId = 0;
	}

	// Create AkComponent, 这个不能用角色原生的AkComponent, 因为这里要attach到特效位置上
	// 这里使用很少, 后续用得多的话要补对象池
	BindNiagaraAkComponent = NewObject<UAkComponent>(OwnerActor, UAkComponent::StaticClass());
	BindNiagaraAkComponent->AttachToComponent(NiagaraComponent, FAttachmentTransformRules::SnapToTargetIncludingScale);
	BindNiagaraAkComponent->RegisterComponent();
	BindNiagaraAkComponent->StopWhenOwnerDestroyed = false;

	// Play Audio
	this->AudioId = AudioManager->InnerPostEventOnAkComp(this->AudioName, BindNiagaraAkComponent.Get());
	
	return true;
}

bool FKGNiagaraUpdateTaskSetEffectAudio::OnTaskDestroy(const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	this->AudioName = TEXT("");
	if (this->AudioId != 0)
	{
		UKGAkAudioManager* AkAudioManager = UKGAkAudioManager::GetInstance(EffectManager.Get());
		if (AkAudioManager != nullptr)
		{
			AkAudioManager->InnerStopEventByPlayingID(this->AudioId, 500);
		}
		
		if (BindNiagaraAkComponent.IsValid())
		{
			BindNiagaraAkComponent->DestroyComponent();
		}
		
		this->AudioId = 0;
	}
	
	return FKGNiagaraUpdateTaskBase::OnTaskDestroy(InTaskTarget);
}
