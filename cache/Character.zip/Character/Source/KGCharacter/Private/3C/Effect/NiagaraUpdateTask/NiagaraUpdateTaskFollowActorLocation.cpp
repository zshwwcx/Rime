﻿#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskFollowActorLocation.h"

#include "3C/Effect/KGNiagaraUpdateContext.h"
#include "NiagaraComponent.h"
#include "GameFramework/Actor.h"

bool FKGNiagaraUpdateTaskFollowActorLocation::OnTaskUpdate(float DeltaTime, const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	UNiagaraComponent* NiagaraComponent = InTaskTarget.GetNiagaraComponent();
	if (!NiagaraComponent)
	{
		return false;
	}
	
	if (!FollowingTargetActor.IsValid()) 
	{
		return false;
	}

	const FVector& ActorLocation = FollowingTargetActor->GetActorLocation();
	if (bAbsoluteRotation)
	{
		const FVector& RelativeLocation = NiagaraComponent->GetComponentLocation() - ActorLocation;
		NiagaraComponent->SetVectorParameter(FollowingTargetParamName, RelativeLocation);	
	}
	else
	{
		const FVector& RelativeLocation = NiagaraComponent->GetComponentTransform().InverseTransformPosition(ActorLocation);
		NiagaraComponent->SetVectorParameter(FollowingTargetParamName, RelativeLocation);
	}

	return true;
}
