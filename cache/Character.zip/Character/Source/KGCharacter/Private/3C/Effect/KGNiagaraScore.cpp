#include "3C/Effect/KGNiagaraScore.h"

#include "3C/Camera/CameraManager.h"
#include "3C/Camera/KgCameraMode.h"
#include "Manager/KGCppAssetManager.h"
#include "3C/Effect/KGEffectmanager.h"
#include "Engine/DataTable.h"
#include "Engine/EngineBaseTypes.h"
#include "NiagaraSystemInstance.h"
#include "NiagaraComponent.h"
#include "NiagaraSystemInstanceController.h"
#include "GameFramework/Pawn.h"
#include "UnrealEngine.h"

// UE_DISABLE_OPTIMIZATION

static int GBattleEffectScoreControlForceEnabled = 0;
static FAutoConsoleVariableRef CVarBattleEffectScoreControlForceEnabled(
	TEXT("game.NiagaraScore.BattleEffect.ForceEnabled"),
	GBattleEffectScoreControlForceEnabled,
	TEXT("Get/Set Niagara Score BattleEffect Control force enabled. 1 enable, -1 disable, 0 use default."),
	ECVF_Default);

static int GEnvEffectSlowTickForceEnabled = 0;
static FAutoConsoleVariableRef CVarEnvEffectScoreControlForceEnabled(
	TEXT("game.NiagaraScore.EnvEffect.ForceEnabled"),
	GEnvEffectSlowTickForceEnabled,
	TEXT("Get/Set Niagara EnvEffect SlowTick force enabled. 1 enable, -1 disable, 0 use default."),
	ECVF_Default);

static int GbBattleEffectSlowTickForceEnabled = 0;
static FAutoConsoleVariableRef CVarbBattleEffectSlowTickForceEnabled(
	TEXT("game.NiagaraScore.BattleEffectSlowTick.ForceEnabled"),
	GbBattleEffectSlowTickForceEnabled,
	TEXT("Get/Set Niagara BattleEffect SlowTick force enabled. 1 enable, -1 disable, 0 use default."),
	ECVF_Default);

static bool GbBattleEffectSlowTickDistanceCheckEnabled = true;
static FAutoConsoleVariableRef CVarbBattleEffectSlowTickDistanceCheckEnabled(
	TEXT("game.NiagaraScore.BattleEffectSlowTick.Distance.bEnabled"),
	GbBattleEffectSlowTickDistanceCheckEnabled,
	TEXT("Get/Set Niagara BattleEffect SlowTick Distance Check enabled. True/False."),
	ECVF_Default);

static bool GbNiagaraScoreDebugEnabled = true;
static FAutoConsoleVariableRef CVarbNiagaraScoreDebugEnabled(
	TEXT("game.NiagaraScore.bNiagaraScoreDebugEnabled"),
	GbNiagaraScoreDebugEnabled,
	TEXT("Get/Set Niagara Score Debug Enabled. True/False."),
	ECVF_Default);

static int GBattleEffectIgnorePriority4 = 1;
static FAutoConsoleVariableRef CVarBattleEffectIgnorePriority4(
	TEXT("game.NiagaraScore.BattleEffect.IgnorePriority4"),
	GBattleEffectIgnorePriority4,
	TEXT("Get/Set Niagara Score BattleEffect IgnorePriority4. >0 enable, <=0 disable"),
	ECVF_Default);

static float GNiagaraScoreFpsSmoothness = 0.99f;
static FAutoConsoleVariableRef CVarNiagaraScoreFpsSmoothness(
	TEXT("game.NiagaraScore.FpsSmoothness"),
	GNiagaraScoreFpsSmoothness,
	TEXT("Get/Set Niagara score fps smoothness (0.0 - 1.0),")
	TEXT(" SmoothedFPS = SmoothedFPS * FpsSmoothness + CurrentFPS * (1.0 - FpsSmoothness)."),
	ECVF_Default);

static float GNiagaraScoreTickInterval = 0.2f;
static FAutoConsoleVariableRef CVarNiagaraScoreTickInterval(
	TEXT("game.NiagaraScore.TickInterval"),
	GNiagaraScoreTickInterval,
	TEXT("Get/Set Niagara score tick interval time (seconds)."),
	ECVF_Default);

static float GNiagaraScoreDirectCapacity = -1;
static FAutoConsoleVariableRef CVarNiagaraScoreDirectCapacity(
	TEXT("game.NiagaraScore.DirectCapacity"),
	GNiagaraScoreDirectCapacity,
	TEXT("Get/Set Niagara score direct capacity and it is only valid when greater than 0."),
	ECVF_Default);

static float GNiagaraScoreMaxCapacity = 8192.0f;
static FAutoConsoleVariableRef CVarNiagaraScoreMaxCapacity(
	TEXT("game.NiagaraScore.MaxCapacity"),
	GNiagaraScoreMaxCapacity,
	TEXT("Get/Set Niagara score max capacity."),
	ECVF_Default);

class FSmoothFPS
{
public:
	static FSmoothFPS& Get()
	{
		static FSmoothFPS Instance;
		return Instance;
	}

	FSmoothFPS()
	{
		this->SmoothFPS = this->GetRealFPS();
	}

	void Tick(float DeltaTime)
	{
		float RealFPS = 1.0f / DeltaTime;
		float Smoothness = FMath::Clamp(GNiagaraScoreFpsSmoothness, 0.0f, 0.999f);
		SmoothFPS = SmoothFPS * Smoothness + RealFPS * (1.0f - Smoothness);
	}
	
	double GetRealFPS() const
	{
		const double CurrentTime = FApp::GetCurrentTime();
		const double DeltaTime = CurrentTime - FApp::GetLastTime();
		const double RawFrameTime = DeltaTime * 1000.0;
		double FrameTime = FMath::Max(RawFrameTime, 0.00001f);
		double FPS = 1000.0f / FrameTime;
		return FPS;
	}

	double GetSmoothFPS() const
	{
		return SmoothFPS;
	}

private:
	double SmoothFPS;
};

float FKGNiagaraScoreCapacitySettings::GetTotalCapacity() const
{
	if (GNiagaraScoreDirectCapacity > 0)
	{
		return FMath::Clamp(GNiagaraScoreDirectCapacity, 0, GNiagaraScoreMaxCapacity);
	}
	
	if (FMath::IsNearlyEqual(FpsRange.X, FpsRange.Y))
	{
		return FMath::Max(CapacityRange.Y, 0);
	}
	
	float FPS = FSmoothFPS::Get().GetSmoothFPS();
	float Lerp = FMath::Clamp((FPS - FpsRange.X) / (FpsRange.Y - FpsRange.X), 0.0f, 1.0f);;
	float Capacity = FMath::Lerp(CapacityRange.X, CapacityRange.Y, Lerp);
	return FMath::Clamp(Capacity, 0, GNiagaraScoreMaxCapacity);
}

float FKGNiagaraScoreCapacitySettings::GetSumCapacity(int32 InPriority) const
{
	float Capacity = this->GetTotalCapacity();

	float Percentage = 0;
	for (int32 Index = 0; Index < (InPriority + 1) && Index < PriorityCapacityPercentages.Num(); Index++)
	{
		Percentage += PriorityCapacityPercentages[Index];
	}
	Percentage = FMath::Clamp(Percentage, 0.0f, 1.0f);

	float PriorityCapacity = Capacity * Percentage;

	return PriorityCapacity;
}

float FKGNiagaraScoreCapacitySettings::GetCapacity(int32 InPriority) const
{
	if (InPriority < 0 || InPriority >= PriorityCapacityPercentages.Num())
	{
		UE_LOG(LogTemp, Error, TEXT("GetCapacity, InPriority=%d is out of range."), InPriority);
		return 0;
	}
	
	float Capacity = this->GetTotalCapacity();
	float Percentage = FMath::Clamp(PriorityCapacityPercentages[InPriority], 0.0f, 1.0f);

	float PriorityCapacity = Capacity * Percentage;
	return PriorityCapacity;
}

const FKGNiagaraScoreCapacitySettings* FKGNiagaraScorePoolSettings::GetCapacitySettingsForQualityLevel(int32 InQualityLevel) const
{
	switch (InQualityLevel)
	{
	case 0: return &QualityLevel0;
	case 1: return &QualityLevel1;
	case 2: return &QualityLevel2;
	case 3: return &QualityLevel3;
	case 4: return &QualityLevel4;
	default: return nullptr;
	}
}

void FKGNiagaraScorePoolSettings::SetCapacitySettings(int32 InQualityLevel, const FKGNiagaraScoreCapacitySettings& InCapacitySettings)
{
	switch (InQualityLevel)
	{
	case 0: QualityLevel0 = InCapacitySettings; break;
	case 1: QualityLevel1 = InCapacitySettings; break;
	case 2: QualityLevel2 = InCapacitySettings; break;
	case 3: QualityLevel3 = InCapacitySettings; break;
	case 4: QualityLevel4 = InCapacitySettings; break;
	default: break;
	}	
}

uint8 FKGNiagaraScoreData::GetNiagaraScoreValue(int32 InQualityLevel, float InDistance) const
{
	switch (InQualityLevel)
	{
	case 4:
		if (InDistance <= 200.0f) return Score_QL4_200;
		if (InDistance <= 500.0f) return Score_QL4_500;
		if (InDistance <= 1000.0f) return Score_QL4_1000;
		if (InDistance <= 2000.0f) return Score_QL4_2000;
		if (InDistance <= 4000.0f) return Score_QL4_4000;
		return Score_QL4_8000;
	case 3:
		if (InDistance <= 200.0f) return Score_QL3_200;
		if (InDistance <= 500.0f) return Score_QL3_500;
		if (InDistance <= 1000.0f) return Score_QL3_1000;
		if (InDistance <= 2000.0f) return Score_QL3_2000;
		if (InDistance <= 4000.0f) return Score_QL3_4000;
		return Score_QL3_8000;
	case 2:
		if (InDistance <= 200.0f) return Score_QL2_200;
		if (InDistance <= 500.0f) return Score_QL2_500;
		if (InDistance <= 1000.0f) return Score_QL2_1000;
		if (InDistance <= 2000.0f) return Score_QL2_2000;
		if (InDistance <= 4000.0f) return Score_QL2_4000;
		return Score_QL2_8000;
	case 1:
		if (InDistance <= 200.0f) return Score_QL1_200;
		if (InDistance <= 500.0f) return Score_QL1_500;
		if (InDistance <= 1000.0f) return Score_QL1_1000;
		if (InDistance <= 2000.0f) return Score_QL1_2000;
		if (InDistance <= 4000.0f) return Score_QL1_4000;
		return Score_QL1_8000;
	case 0:
		if (InDistance <= 200.0f) return Score_QL0_200;
		if (InDistance <= 500.0f) return Score_QL0_500;
		if (InDistance <= 1000.0f) return Score_QL0_1000;
		if (InDistance <= 2000.0f) return Score_QL0_2000;
		if (InDistance <= 4000.0f) return Score_QL0_4000;
		return Score_QL0_8000;
	default:
		return 0;
	}
}

void FKGNiagaraScoreManager::Init(UObject* InWorldContextObject)
{
	this->AssetManager = UKGCppAssetManager::GetInstance(InWorldContextObject);
	this->EffectManager = UKGEffectManager::GetInstance(InWorldContextObject);

	this->bShouldLoadSettings = true;

	if (!this->HandleForNiagaraSystemInstanceAllocated.IsValid())
	{
		this->HandleForNiagaraSystemInstanceAllocated = FNiagaraSystemInstance::OnNiagaraSystemInstanceAllocated.AddRaw(this,
			&FKGNiagaraScoreManager::OnNiagaraSystemInstanceAllocated);
	}

	if (!this->HandleForEffectManagerNiagaraComponentActive.IsValid())
	{
		this->HandleForEffectManagerNiagaraComponentActive = UKGEffectManager::OnNiagaraComponentActive.AddRaw(this,
			&FKGNiagaraScoreManager::OnEffectManagerNiagaraComponentActive);
	}

	if (!this->HandleForEffectManagerNiagaraComponentDeActive.IsValid())
	{
		this->HandleForEffectManagerNiagaraComponentDeActive = UKGEffectManager::OnNiagaraComponentDeActive.AddRaw(this,
			&FKGNiagaraScoreManager::OnEffectManagerNiagaraComponentDeActive);
	}
}

void FKGNiagaraScoreManager::Quit()
{
	if (this->HandleForNiagaraSystemInstanceAllocated.IsValid())
	{
		FNiagaraSystemInstance::OnNiagaraSystemInstanceAllocated.Remove(this->HandleForNiagaraSystemInstanceAllocated);
		this->HandleForNiagaraSystemInstanceAllocated.Reset();
	}

	if (this->HandleForEffectManagerNiagaraComponentActive.IsValid())
	{
		UKGEffectManager::OnNiagaraComponentActive.Remove(this->HandleForEffectManagerNiagaraComponentActive);
		this->HandleForEffectManagerNiagaraComponentActive.Reset();
	}

	if (this->HandleForEffectManagerNiagaraComponentDeActive.IsValid())
	{
		UKGEffectManager::OnNiagaraComponentDeActive.Remove(this->HandleForEffectManagerNiagaraComponentDeActive);
		this->HandleForEffectManagerNiagaraComponentDeActive.Reset();
	}
	
	if (this->NiagaraScoreSettingsLoadingId != 0)
	{
		if (this->AssetManager.IsValid())
		{
			this->AssetManager->CancelAsyncLoadByLoadID(this->NiagaraScoreSettingsLoadingId);
		}
	}
}

void FKGNiagaraScoreManager::Tick(float InDeltaTime)
{
	if (this->bShouldLoadSettings)
	{
		this->bShouldLoadSettings = false;
		this->LoadScoreSettings();
	}

	if (this->IsBattleEffectScoreControlEnabled())
	{
		FSmoothFPS::Get().Tick(InDeltaTime);
	}

	if (this->IsEnvEffectSlowTickEnabled())
	{
		if (this->EnvEffectAccumTickTime > this->EnvEffectIntervalCheckTime)
		{
			ControlAllEnvEffectsSlowTick();

			this->EnvEffectAccumTickTime = 0;
		}
		this->EnvEffectAccumTickTime += InDeltaTime;
	}
}

bool FKGNiagaraScoreManager::IsBattleEffectScoreControlEnabled() const
{
	if (GBattleEffectScoreControlForceEnabled == 0)
	{
		return bIsBattleScoreControlEnable;
	}
	
	return GBattleEffectScoreControlForceEnabled > 0;
}

bool FKGNiagaraScoreManager::IsEnvEffectSlowTickEnabled() const
{
	if (GEnvEffectSlowTickForceEnabled == 0)
	{
		return bIsEnvSlowTickEnable;
	}
	
	return GEnvEffectSlowTickForceEnabled > 0;
}

bool FKGNiagaraScoreManager::IsBattleEffectSlowTickEnabled() const
{
	if (GbBattleEffectSlowTickForceEnabled == 0)
	{
		return bIsBattleSlowTickEnable;
	}
	
	return GbBattleEffectSlowTickForceEnabled > 0;
}

// 1 enable, -1 disable, 0 use default
void FKGNiagaraScoreManager::SetBattleEffectScoreControlForceEnabled(int Value)
{
	GBattleEffectScoreControlForceEnabled = Value;

	UE_LOG(LogTemp, Log, TEXT("FKGNiagaraScoreManager::SetBattleEffectScoreControlForceEnabled. BattleEffectScoreControlForceEnabled=%d, bIsBattleScoreControlEnable=%d"),
		GBattleEffectScoreControlForceEnabled, bIsBattleScoreControlEnable);
}

// 1 enable, -1 disable, 0 use default
void FKGNiagaraScoreManager::SetEnvEffectSlowTickForceEnabled(int Value)
{
	GEnvEffectSlowTickForceEnabled = Value;

	UE_LOG(LogTemp, Log, TEXT("FKGNiagaraScoreManager::SetEnvEffectSlowTickEnabled. EnvEffectSlowTickForceEnabled=%d, bIsEnvSlowTickEnable=%d"),
		GEnvEffectSlowTickForceEnabled, bIsEnvSlowTickEnable);

	// 立刻设置一次
	ControlAllEnvEffectsSlowTick();
}

void FKGNiagaraScoreManager::SetBattleEffectScoreControlEnabled(bool bEnabled)
{
	bIsBattleScoreControlEnable = bEnabled;

	UE_LOG(LogTemp, Log, TEXT("FKGNiagaraScoreManager::SetBattleEffectScoreControlEnabled. BattleEffectScoreControlForceEnabled=%d, bIsBattleScoreControlEnable=%d"),
		GBattleEffectScoreControlForceEnabled, bIsBattleScoreControlEnable);
}

void FKGNiagaraScoreManager::SetEnvEffectSlowTickEnabled(bool bEnabled)
{
	bIsEnvSlowTickEnable = bEnabled;

	UE_LOG(LogTemp, Log, TEXT("FKGNiagaraScoreManager::SetEnvEffectSlowTickEnabled. EnvEffectSlowTickForceEnabled=%d, bIsEnvSlowTickEnable=%d"),
		GEnvEffectSlowTickForceEnabled, bIsEnvSlowTickEnable);

	// 立刻设置一次
	ControlAllEnvEffectsSlowTick();
}

void FKGNiagaraScoreManager::SetBattleEffectIgnorePriority4(int Value)
{
	GBattleEffectIgnorePriority4 = Value;

	UE_LOG(LogTemp, Log, TEXT("FKGNiagaraScoreManager::SetBattleEffectIgnorePriority4. GBattleEffectIgnorePriority4=%d"),
		GBattleEffectIgnorePriority4);
}

void FKGNiagaraScoreManager::SetNiagaraScoreCapacitySettings(int32 InQualityLevel, const FKGNiagaraScoreCapacitySettings& InCapacitySettings)
{
	this->NiagaraScorePoolSettings.SetCapacitySettings(InQualityLevel, InCapacitySettings);
}

void FKGNiagaraScoreManager::SetNiagaraScoreData(const FName& InNiagaraSystemPath, const FKGNiagaraScoreData& InNiagaraScoreData)
{
	FKGNiagaraScoreData& DataRef = this->NiagaraScoreDataMap.FindOrAdd(InNiagaraSystemPath);
	DataRef = InNiagaraScoreData;
}

bool FKGNiagaraScoreManager::CheckScorePoolAvailable(const UNiagaraSystem* NiagaraSystem, const FName& NiagaraSystemPath, int32 InNiagaraPriority, float& OutScoreToRelease, float& OutMaxRequiredScore)
{
	if (!this->IsBattleEffectScoreControlEnabled())
	{
		return true;
	}

	SCOPED_NAMED_EVENT(FKGNiagaraScoreManager_CheckScorePoolAvailable, FColor::Red);

	if (!IsValid(NiagaraSystem))
	{
		return false;
	}
	
	if (InNiagaraPriority < 0)
    {
    	InNiagaraPriority = FMath::Clamp(NiagaraSystem->GetPriority(), 0, FKGNiagaraScoreManager::MaxPriority);
    }

	this->EnsureUpdateAllBattleEffectInfo();
	
	// 预估该特效需要的分数，以最近距离+系统当前的质量
	OutMaxRequiredScore = this->GetRequiredScore(NiagaraSystemPath, FNiagaraPlatformSet::GetQualityLevel(), FKGNiagaraScoreManager::MinSpawnDistance);

	if (OutMaxRequiredScore <= 0)
	{
		OutScoreToRelease = 0;
		return true;
	}

	// 当前资源优先级最多能利用的空间
	float AvailableCapacity = this->GetSumScoreCapacity(InNiagaraPriority);

	// 当前资源优先级不可动的空间
	float FixedScore = this->GetFixedUsedScore(InNiagaraPriority);

	// 当前资源优先级已用的空间
	float UsedScore = this->GetUsedScore(InNiagaraPriority);

	// 总容量去掉不可动空间，剩下都是可用空间（虽然后续可能会因为距离因素创建完之后又被销毁
	bool bCanSpawn = (AvailableCapacity - FixedScore) >= OutMaxRequiredScore; 
	
	OutScoreToRelease = FMath::Max(OutMaxRequiredScore - FMath::Max(AvailableCapacity - FixedScore - UsedScore, 0), 0.0f);

#if !UE_BUILD_SHIPPING && !UE_BUILD_TEST
	if (GbNiagaraScoreDebugEnabled)
	{
		UE_LOG(LogTemp, Log, TEXT("FKGNiagaraScoreManager::CheckScorePoolAvailable Success. SystemPath=%s, Priority=%d, OutScoreRequired=%.1f, AvailableCapacity=%.1f, FixedScore = %.1f, UsedScore = %.1f, OutScoreToRelease = %.1f"),
	*NiagaraSystemPath.ToString(), InNiagaraPriority, OutMaxRequiredScore, AvailableCapacity, FixedScore, UsedScore, OutScoreToRelease);
	}
#endif
	
	if (GBattleEffectIgnorePriority4 > 0 && InNiagaraPriority == FKGNiagaraScoreManager::MaxPriority)
	{
		bCanSpawn = true;
	}
	
	return bCanSpawn;
}

bool FKGNiagaraScoreManager::PrepareNiagaraActivation(const TWeakObjectPtr<UNiagaraComponent>& InNiagaraComponent, const FName& NiagaraSystemPath,
	int32 InNiagaraPriority, float InScoreToRelease, float InMaxRequiredScore)
{
	if (!this->IsBattleEffectScoreControlEnabled())
	{
		return true;
	}
	
	SCOPED_NAMED_EVENT(FKGNiagaraScoreManager_PrepareNiagaraActivation, FColor::Red);

	if (!InNiagaraComponent.IsValid())
	{
		return false;
	}

	UNiagaraSystem* NiagaraSystem = InNiagaraComponent->GetAsset();
	if (NiagaraSystem == nullptr)
	{
		return false;
	}

	if (InNiagaraPriority < 0)
	{
		InNiagaraPriority = FMath::Clamp(NiagaraSystem->GetPriority(), 0, FKGNiagaraScoreManager::MaxPriority);
	}

	// 相机/主角信息获取失败，那就先不工作了，直接通过
	if (!this->GetCachedViewCenterLocation(InNiagaraComponent->GetWorld()) || !this->GetCachedCameraLocation(InNiagaraComponent->GetWorld()))
	{
		return true;
	}

	auto ComponentLocation = InNiagaraComponent->GetComponentLocation();
	
	if (InScoreToRelease > 0)
	{
		auto Distance2ViewCenter = FVector::Distance(ComponentLocation, CachedViewCenterLocation);
		if(!this->TryFreeSpace(InNiagaraPriority, InScoreToRelease, Distance2ViewCenter))
		{
			// 也可能失败，例如没有比当前特效距离远的特效了
			return false;
		}
	}

	// 根据距离算出来的真实分数
	auto Distance2Camera = FVector::Distance(ComponentLocation, CachedCameraLocation);
	auto RealRequireScore = this->GetRequiredScore(NiagaraSystemPath, this->GetQualityLevelOfComponent(InNiagaraComponent), Distance2Camera);

	// 当前要创建的特效申请预算成功，分数加入统计，但是当帧就不加入到距离排序中了，减少计算开销同时避免又被其他特效关掉
	this->BattleEffectPriority2ScoreMap.FindOrAdd(InNiagaraPriority) += FMath::Min(RealRequireScore, InMaxRequiredScore);

#if !UE_BUILD_SHIPPING && !UE_BUILD_TEST
	if (GbNiagaraScoreDebugEnabled)
	{
		UE_LOG(LogTemp, Log, TEXT("FKGNiagaraScoreManager::PrepareNiagaraActivation success. SystemPath=%s, Priority=%d, InScoreToRelease=%.1f, RealRequireScore=%.1f, InMaxRequiredScore=%.1f, Distance2Camera=%.1f"),
			*NiagaraSystem->GetPathName(), InNiagaraPriority, InScoreToRelease, RealRequireScore, InMaxRequiredScore, Distance2Camera);
	}
#endif
	
	return true;
}

void FKGNiagaraScoreManager::SetBattleEffectTickingRate(const TWeakObjectPtr<UNiagaraComponent>& InNiagaraComponent)
{
	SCOPED_NAMED_EVENT(FKGNiagaraScoreManager_SetBattleEffectTickingRate, FColor::Red);

	if (!InNiagaraComponent.IsValid())
	{
		return;
	}

	bool bIsSlowTick = true;

	if (!IsBattleEffectSlowTickEnabled())
	{
		bIsSlowTick = false;
	}
	else
	{
		if (GbBattleEffectSlowTickDistanceCheckEnabled)
		{
			auto ComponentLocation = InNiagaraComponent->GetComponentLocation();
			if (!this->GetCachedViewCenterLocation(InNiagaraComponent->GetWorld()) || !this->GetCachedCameraLocation(InNiagaraComponent->GetWorld()))
			{
				bIsSlowTick = false;
			}
			else
			{
				auto Distance2ViewCenter = FVector::Distance(ComponentLocation, CachedViewCenterLocation);
				auto Distance2Camera = FVector::Distance(ComponentLocation, CachedCameraLocation);

				bIsSlowTick = Distance2Camera > BattleEffectSlowTickDistance && Distance2ViewCenter > BattleEffectSlowTickDistance;
			}
		}
	}

	this->SetTickingRate(InNiagaraComponent, bIsSlowTick);
}

bool FKGNiagaraScoreManager::TryFreeSpace(const int32& InPriority, const int32& InScoreToRelease, const float& InCurrentDistance)
{
	SCOPED_NAMED_EVENT(FKGNiagaraScoreManager_TryFreeSpace, FColor::Red);

	// 最高优先级的都需要保留
	bool bIsKeepAllPriority = GBattleEffectIgnorePriority4 > 0 && InPriority == FKGNiagaraScoreManager::MaxPriority;

#if !UE_BUILD_SHIPPING && !UE_BUILD_TEST
	if (GbNiagaraScoreDebugEnabled)
	{
		// debug部分
		UE_LOG(LogTemp, Log, TEXT("FKGNiagaraScoreManager::TryFreeSpace, SCORE DUMP--------------------------------"));
		for (auto kv : BattleEffectPriority2ComponentsMap)
		{
			if (kv.Value.Num() > 0 && BattleEffectPriority2ScoreMap.Contains(kv.Key))
			{
				UE_LOG(LogTemp, Log, TEXT("FKGNiagaraScoreManager::Dump, priority=%d, count=%d, score=%f"), kv.Key, kv.Value.Num(), BattleEffectPriority2ScoreMap[kv.Key]);
			}
		}
	}
#endif
	
	float CurScoreSum = 0;

	bool bEnoughScore = false;
	TArray<FNiagaraScoreInstanceInfo> Instance2Remove;
	Instance2Remove.Reserve(8);
	
	for (int32 Priority = 0; Priority < InPriority; Priority++)
	{
		auto ComponentPtrList = this->BattleEffectPriority2ComponentsMap.Find(Priority);

		if (ComponentPtrList != nullptr && ComponentPtrList->Num() > 0)
		{
			for (auto& InstanceInfo : *ComponentPtrList)
			{
				if (!InstanceInfo.ComponentPtr.IsValid())
					continue;

				auto InstanceController = InstanceInfo.ComponentPtr->GetSystemInstanceController();
			
				if (InstanceController.IsValid() && InstanceController->GetActualExecutionState() == ENiagaraExecutionState::Active)
				{
					Instance2Remove.Add(InstanceInfo);
					CurScoreSum += InstanceInfo.Score;
					
					// 匀出来的分数已经足够创建新特效了
					if (CurScoreSum >= InScoreToRelease)
					{
						bEnoughScore = true;
						break;
					}
				}
			}

			if (bEnoughScore)
			{
				break;
			}
		}
	}

	if (!bEnoughScore && !bIsKeepAllPriority)
	{
		// 再比较同一优先级距离更近的；问过策划了，优先级相同的特效也可以按照距离顺序被隐藏
		auto ComponentPtrList = this->BattleEffectPriority2ComponentsMap.Find(InPriority);
		if (ComponentPtrList != nullptr && ComponentPtrList->Num() > 0)
		{
			for (auto& InstanceInfo : *ComponentPtrList)
			{
				if (!InstanceInfo.ComponentPtr.IsValid())
					continue;

				auto InstanceController = InstanceInfo.ComponentPtr->GetSystemInstanceController();
				if (InstanceController.IsValid() && InstanceController->GetActualExecutionState() == ENiagaraExecutionState::Active)
				{
					// 因为是已经排好序的，遇到第一个更近的特效就可以break了
					if(InstanceInfo.Distance2ViewCenter < InCurrentDistance)
					{
						break;
					}

					Instance2Remove.Add(InstanceInfo);
					CurScoreSum += InstanceInfo.Score;
					// 匀出来的分数已经足够创建新特效了
					if (CurScoreSum >= InScoreToRelease)
					{
						bEnoughScore = true;
						break;
					}
				}
			}
		}
	}

	// 释放的空间足够，或者当前优先级的特效全部保留
	bool bIsFree = bEnoughScore || bIsKeepAllPriority;

#if !UE_BUILD_SHIPPING && !UE_BUILD_TEST
	if (GbNiagaraScoreDebugEnabled)
	{
		UE_LOG(LogTemp, Log, TEXT("FKGNiagaraScoreManager::TryFreeSpace, bIsFree = %d, InPriority = %d, CurScoreSum = %f, InScoreToRelease = %d, InCurrentDistance = %f"),
			bIsFree, InPriority, CurScoreSum, InScoreToRelease, InCurrentDistance);
	}
#endif
	
	if (bIsFree)
	{
		for (auto& InstanceInfo : Instance2Remove)
		{
			this->FreeLowerInstance(InstanceInfo, InPriority);
		}
	}
	
	return bIsFree;
}

bool FKGNiagaraScoreManager::FreeLowerInstance(const FNiagaraScoreInstanceInfo& InInstanceInfo, const int32 InPriority)
{
	if (!InInstanceInfo.ComponentPtr.IsValid())
	{
		return false;
	}

	if (auto Ptr = InInstanceInfo.ComponentPtr.Get())
	{
		auto InstancePtr = Ptr->GetSystemInstanceController();

		if (!InstancePtr.IsValid())
		{
			return false;
		}
	
		InstancePtr->Deactivate(true);

		// 预算池中减去这部分分数
		float& PriorityScore = this->BattleEffectPriority2ScoreMap.FindOrAdd(InInstanceInfo.Priority);
		float NewScore = FMath::Max(0.0f, PriorityScore - InInstanceInfo.Score);

#if !UE_BUILD_SHIPPING && !UE_BUILD_TEST
		if (GbNiagaraScoreDebugEnabled)
		{
			if (auto Asset = Ptr->GetAsset())
			{
				UE_LOG(LogTemp, Warning, TEXT("FKGNiagaraScoreManager::FreeLowerInstance, Deactivate: %s, Priority: %d/%d, Score: %f->%f"), 
				*Asset->GetFullName(), InInstanceInfo.Priority, InPriority, PriorityScore, NewScore);
			}
		}
#endif
		
		PriorityScore = NewScore;

		return true;
	}
	else
	{
		return false;
	}
}

float FKGNiagaraScoreManager::GetSumScoreCapacity(int32 InPriority) const
{
	SCOPED_NAMED_EVENT(FKGNiagaraScoreManager_GetSumScoreCapacity, FColor::Red);
	
	int32 QualityLevel = FNiagaraPlatformSet::GetQualityLevel();
	auto* CapacitySettingsPtr = this->NiagaraScorePoolSettings.GetCapacitySettingsForQualityLevel(QualityLevel);
	if (CapacitySettingsPtr == nullptr)
		return GNiagaraScoreMaxCapacity;
	return CapacitySettingsPtr->GetSumCapacity(InPriority);
}

float FKGNiagaraScoreManager::GetScoreCapacity(int32 InPriority) const
{
	SCOPED_NAMED_EVENT(FKGNiagaraScoreManager_GetScoreCapacity, FColor::Red);
	
	int32 QualityLevel = FNiagaraPlatformSet::GetQualityLevel();
	auto* CapacitySettingsPtr = this->NiagaraScorePoolSettings.GetCapacitySettingsForQualityLevel(QualityLevel);
	if (CapacitySettingsPtr == nullptr)
		return GNiagaraScoreMaxCapacity;
	return CapacitySettingsPtr->GetCapacity(InPriority);
}

float FKGNiagaraScoreManager::GetUsedScore(int32 InPriority) const
{
	SCOPED_NAMED_EVENT(FKGNiagaraScoreManager_GetUsedScore, FColor::Red);
	
	// 已经创建了 Instance 的特效分数
	float PriorityScoreSum = 0;
	
	for (int32 PriorityIndex = 0; PriorityIndex <= InPriority; PriorityIndex++)
	{
		const float* PriorityScorePtr = this->BattleEffectPriority2ScoreMap.Find(PriorityIndex);
		float PriorityScoreValue = PriorityScorePtr != nullptr ? *PriorityScorePtr : 0;
		PriorityScoreSum += PriorityScoreValue;
	}
	
	return PriorityScoreSum;
}

// 不可动的分数部分，即比当前更高优先级的特效用了多少下层空间
float FKGNiagaraScoreManager::GetFixedUsedScore(int32 InNiagaraPriority) const
{
	if (InNiagaraPriority >= FKGNiagaraScoreManager::MaxPriority)
	{
		return 0;
	}
	
	float SumUsed = 0;
	float SumCapacity = 0;
	
	for (int32 PriorityIndex = InNiagaraPriority + 1; PriorityIndex <= FKGNiagaraScoreManager::MaxPriority; PriorityIndex++)
	{
		const float* PriorityScorePtr = this->BattleEffectPriority2ScoreMap.Find(PriorityIndex);
		float PriorityScoreValue = PriorityScorePtr != nullptr ? *PriorityScorePtr : 0;
		
		SumUsed += PriorityScoreValue;
		SumCapacity += this->GetScoreCapacity(PriorityIndex);
	}

	return FMath::Max(SumUsed - SumCapacity, 0);
}

float FKGNiagaraScoreManager::GetRequiredScore(const FName& InNiagaraSystemPath, int32 InQualityLevel, float InDistance) const
{
	SCOPED_NAMED_EVENT(FKGNiagaraScoreManager_GetRequiredScore, FColor::Red);
	
	const FKGNiagaraScoreData* NiagaraScoreData = this->GetNiagaraScoreData(InNiagaraSystemPath);
	if (NiagaraScoreData == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("FKGNiagaraScoreManager::GetNiagaraScoreValue: The niagara is not found in score table, SystemPath=%s"),
			*InNiagaraSystemPath.ToString());
		return DefaultScore;
	}
	
	return NiagaraScoreData->GetNiagaraScoreValue(InQualityLevel, InDistance);
}

bool FKGNiagaraScoreManager::LoadScoreSettings()
{
	// Get Asset Paths from lua
	if (!this->AssetManager.IsValid() || !this->EffectManager.IsValid())
	{
		UE_LOG(LogTemp, Error, TEXT("FKGNiagaraScoreManager::LoadScoreSettings: AssetManager or EffectManager is invalid."));
		return false;
	}

	// Load Pool Settings
	this->EffectManager->CallLuaFunction<slua::LuaVar>("KCB_GetNiagaraScorePool");

	// Load Score Table
	this->NiagaraScoreTablePath = this->EffectManager->CallLuaFunction<FString>("KCB_GetNiagaraScoreTablePath");
	UE_LOG(LogTemp, Log, TEXT("FKGNiagaraScoreManager::LoadScoreSettings: NiagaraScoreTablePath=%s"),
		*(this->NiagaraScoreTablePath));
	if (this->NiagaraScoreTablePath.IsEmpty())
	{
		UE_LOG(LogTemp, Error, TEXT("FKGNiagaraScoreManager::LoadScoreSettings: NiagaraScoreTablePath is empty."));
		return false;
	}
	
	if (this->NiagaraScoreSettingsLoadingId != 0)
	{
		this->AssetManager->CancelAsyncLoadByLoadID(this->NiagaraScoreSettingsLoadingId);
	}
	this->NiagaraScoreSettingsLoadingId = this->AssetManager->AsyncLoadAsset(
    		this->NiagaraScoreTablePath,
    		FAsyncLoadCompleteDelegate::CreateRaw(this, &FKGNiagaraScoreManager::OnScoreTableLoaded));
    
    return true;
}

void FKGNiagaraScoreManager::OnScoreTableLoaded(int32 InLoadingId, UObject* InLoadedObject)
{
	this->NiagaraScoreSettingsLoadingId = 0;
	
	TObjectPtr<UDataTable> DataTable = Cast<UDataTable>(InLoadedObject);
	if (IsValid(DataTable))
	{
		const TMap<FName, uint8*>& RowMap = DataTable->GetRowMap();
		for (auto& ScoreRow : RowMap)
		{
			FKGNiagaraScoreData& NiagaraScoreRef = this->NiagaraScoreDataMap.FindOrAdd(ScoreRow.Key);
			NiagaraScoreRef = *reinterpret_cast<FKGNiagaraScoreData*>(ScoreRow.Value);			
		}

		UE_LOG(LogTemp, Log, TEXT("FKGNiagaraScoreManager::OnScoreTableLoaded: Load NiagaraScoreTable Succ, RowCount=%d"), 
			RowMap.Num());
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("FKGNiagaraScoreManager::OnScoreTableLoaded: Load NiagaraScoreTable failed."));
	}
	
	// Load Data(Override) from Lua
	if (this->EffectManager != nullptr)
	{
		this->EffectManager->CallLuaFunction("KCB_GetNiagaraScoreDataOverride");
	}
}

const FKGNiagaraScoreData* FKGNiagaraScoreManager::GetNiagaraScoreData(const FName& InNiagaraSystemPath) const
{
	return this->NiagaraScoreDataMap.Find(InNiagaraSystemPath);
}

void FKGNiagaraScoreManager::EnsureUpdateAllBattleEffectInfo()
{
    if (BattleEffectInfoUpdateFrameCount == GFrameCounter)
    {
    	return;
    }
    BattleEffectInfoUpdateFrameCount = GFrameCounter;
	
    SCOPED_NAMED_EVENT(FKGNiagaraScoreManager_EnsureSortAllEffects, FColor::Red);

	UWorld* FoundWorld = EffectManager->GetWorld();
	bool bHaveViewCenter = this->GetCachedViewCenterLocation(FoundWorld);
	bool bHaveCameraLoc = this->GetCachedCameraLocation(FoundWorld);
	const FVector ViewCenterCopy = CachedViewCenterLocation;
	const FVector CameraLocCopy = CachedCameraLocation;

	for (auto& Pair : BattleEffectPriority2ComponentsMap)
	{
		Pair.Value.Reset();
	}
	BattleEffectPriority2ScoreMap.Reset();
	
	for (auto It = ActiveBattleEffectMap.CreateIterator(); It; ++It)
	{
		if (auto ComponentPtr = Cast<UNiagaraComponent>(It.Key().ResolveObjectPtr()))
		{
			auto& BasicInfo = It.Value();

			FNiagaraScoreInstanceInfo TempInfo(ComponentPtr, BasicInfo, this->GetQualityLevelOfComponent(ComponentPtr));
			TempInfo.Location = ComponentPtr->GetComponentLocation();

			if (bHaveViewCenter)
			{
				TempInfo.Distance2ViewCenter = FVector::Distance(TempInfo.Location, ViewCenterCopy);
			}

			if (bHaveCameraLoc)
			{
				TempInfo.Distance2Camera = FVector::Distance(TempInfo.Location, CameraLocCopy);
				TempInfo.Score = BasicInfo.ScoreData != nullptr ? BasicInfo.ScoreData->GetNiagaraScoreValue(TempInfo.QualityLevel, TempInfo.Distance2Camera) : FKGNiagaraScoreManager::DefaultScore;
			}

			if (!BattleEffectPriority2ScoreMap.Contains(TempInfo.Priority))
			{
				BattleEffectPriority2ScoreMap.Add(TempInfo.Priority, 0.0f);
			}
			BattleEffectPriority2ScoreMap[TempInfo.Priority] += TempInfo.Score;
    	
			if (!BattleEffectPriority2ComponentsMap.Contains(TempInfo.Priority))
			{
				BattleEffectPriority2ComponentsMap.Add(TempInfo.Priority, TArray<FNiagaraScoreInstanceInfo>());
			}
			BattleEffectPriority2ComponentsMap[TempInfo.Priority].Add(MoveTemp(TempInfo));
		}
		else
		{
			It.RemoveCurrent();
		}
    }

	for (auto& kv : BattleEffectPriority2ComponentsMap)
	{
		kv.Value.Sort([](const FNiagaraScoreInstanceInfo& A, const FNiagaraScoreInstanceInfo& B)
		{
			if (A.Distance2ViewCenter == B.Distance2ViewCenter)
			{
				if (A.Score == B.Score)
				{
					return A.ComponentPtr.Get() < B.ComponentPtr.Get();
				}
				
				return A.Score > B.Score;
			}
			
			return A.Distance2ViewCenter > B.Distance2ViewCenter; 
		});
	}
}

bool FKGNiagaraScoreManager::GetCachedViewCenterLocation(const UWorld* World)
{
	bool bIsGetCacheViewCenterLocation = false;
	
	// 每帧距离要重新算，但是当帧的重复计算还是加上缓存
	if (this->Distance2MainViewCheckFrameCount != GFrameCounter)
	{
		if (World == nullptr)
		{
			return false;
		}
		
		this->Distance2MainViewCheckFrameCount = GFrameCounter;

		if (ACameraManager* CameraManagerActor = Cast<ACameraManager>(UGameplayStatics::GetPlayerCameraManager(World, 0)))
		{
			if(UKgCameraMode* Mode = CameraManagerActor->GetCurCameraMode())
			{
				if(UCameraArmComponent* Arm = Mode->GetCameraArmComponent())
				{
					auto LookAtActor = Arm->LookAtTarget.Get();

					AActor* FirstPlayer = World->GetFirstPlayerController()->GetPawn();
		
					// 只有相机lookAt当前玩家，此时才用玩家位置作为视野中心位置，否则就用相机位置
					if (LookAtActor != nullptr && FirstPlayer == LookAtActor)
					{
						CachedViewCenterLocation = LookAtActor->GetActorLocation();
					}
					else
					{
						CachedViewCenterLocation = CameraManagerActor->GetCameraLocation();
					}

					bIsGetCacheViewCenterLocation = true;
				}
			}
		}
	}
	else
	{
		bIsGetCacheViewCenterLocation = true;
	}

	return bIsGetCacheViewCenterLocation;
}

bool FKGNiagaraScoreManager::GetCachedCameraLocation(const UWorld* World)
{
	bool bIsGetCacheCameraLocation = false;

	// 每帧距离要重新算，但是当帧的重复计算还是加上缓存
	if (this->Distance2CameraCheckFrameCount != GFrameCounter)
	{
		if (World == nullptr)
		{
			return false;
		}
		
		this->Distance2CameraCheckFrameCount = GFrameCounter;

		APlayerCameraManager* CameraManager = UGameplayStatics::GetPlayerCameraManager(World, 0);
		if (CameraManager != nullptr)
		{
			CachedCameraLocation = CameraManager->GetCameraLocation();
			bIsGetCacheCameraLocation = true;
		}
	}
	else
	{
		bIsGetCacheCameraLocation = true;
	}

	return bIsGetCacheCameraLocation;
}

void FKGNiagaraScoreManager::OnNiagaraSystemInstanceAllocated(FNiagaraSystemInstancePtr& InNiagaraSystemInstancePtr)
{
	SCOPED_NAMED_EVENT(FKGNiagaraScoreManager_OnNiagaraSystemInstanceAllocated, FColor::Red);

	if (!InNiagaraSystemInstancePtr.IsValid())
		return;

	auto ComponentPtr = Cast<UNiagaraComponent>(InNiagaraSystemInstancePtr->GetAttachComponent());
	
	if (IsEnvEffectSlowTickEnabled())
	{
		ProcessPendingNiagaraComponent(ComponentPtr);
	}
	else
	{
		AllocatedEffectPendingList.Add(ComponentPtr);
	}
}

void FKGNiagaraScoreManager::OnEffectManagerNiagaraComponentActive(UNiagaraComponent* ComponentPtr, const FKGPlayNiagaraParams& Params)
{
	if (ComponentPtr)
	{
		if (auto NiagaraAsset = ComponentPtr->GetAsset())
		{
			if(UNiagaraEffectType* EffectType = NiagaraAsset->GetEffectType())
			{
				if(EffectType->GetName().Contains("_UI"))
				{
					return;
				}
			}
			
			bool bIsBattle = Params.EffectTags.Contains(EKGNiagaraEffectTag::BATTLE);

			// 只处理战斗特效
			if (!bIsBattle)
			{
				return;
			}
			
			FName NiagaraSystemPath = FName(Params.NiagaraEffectPath);
			int32 Priority = Params.NiagaraBusinessPriority >= 0 ? Params.NiagaraBusinessPriority : ComponentPtr->GetPriority();

			if (ActiveBattleEffectMap.Contains(ComponentPtr))
			{
				auto& Info = ActiveBattleEffectMap[ComponentPtr];
				Info.Priority = FMath::Clamp(Priority, 0, FKGNiagaraScoreManager::MaxPriority);
			}
			else
			{
				FNiagaraComponentBasicInfo Info;
				Info.ScoreData = GetNiagaraScoreData(NiagaraSystemPath);
				Info.Priority = FMath::Clamp(Priority, 0, FKGNiagaraScoreManager::MaxPriority);

				ActiveBattleEffectMap.Add(ComponentPtr, MoveTemp(Info));
			}
		}
	}
}

void FKGNiagaraScoreManager::OnEffectManagerNiagaraComponentDeActive(UNiagaraComponent* ComponentPtr, const FKGPlayNiagaraParams& Params)
{
	if (!ComponentPtr)
	{
		return;
	}
	
	ActiveBattleEffectMap.Remove(ComponentPtr);
}

void FKGNiagaraScoreManager::ProcessPendingNiagaraComponent(UNiagaraComponent* ComponentPtr)
{
	if (ComponentPtr)
	{
		if (auto NiagaraAsset = ComponentPtr->GetAsset())
		{
			if(UNiagaraEffectType* EffectType = NiagaraAsset->GetEffectType())
			{
				if(EffectType->GetName().Contains("_UI"))
				{
					return;
				}
			}
			
			bool bIsBattle = false;
			FName NiagaraSystemPath;
			int32 Priority;

			FKGPlayNiagaraParams Params;
			if (this->EffectManager->GetPlayNiagaraParams(ComponentPtr, Params))
			{
				bIsBattle = Params.EffectTags.Contains(EKGNiagaraEffectTag::BATTLE);
				NiagaraSystemPath = FName(Params.NiagaraEffectPath);
				Priority = Params.NiagaraBusinessPriority >= 0 ? Params.NiagaraBusinessPriority : ComponentPtr->GetPriority();
			}
			else
			{
				NiagaraSystemPath = FName(NiagaraAsset->GetFullName());
				Priority = ComponentPtr->GetPriority();
			}

			// 战斗/最高优先级的特效不纳入管理
			if (bIsBattle || Priority >= FKGNiagaraScoreManager::MaxPriority)
			{
				return;
			}
			
			FNiagaraComponentBasicInfo Info;
			Info.ScoreData = GetNiagaraScoreData(NiagaraSystemPath);
			Info.Priority = FMath::Clamp(Priority, 0, FKGNiagaraScoreManager::MaxPriority);
			ActiveEnvEffectMap.Add(ComponentPtr, MoveTemp(Info));
		}
	}
}

void FKGNiagaraScoreManager::SetEnvEffectConfig(float InCheckInterval, float InDistance)
{
	this->EnvEffectIntervalCheckTime = InCheckInterval;
	this->EnvEffectSlowTickDistance = InDistance;
}

void FKGNiagaraScoreManager::SetBattleEffectSlowTickForceEnabled(int Value, bool bIsDistanceCheckEnable)
{
	GbBattleEffectSlowTickForceEnabled = Value;
	GbBattleEffectSlowTickDistanceCheckEnabled = bIsDistanceCheckEnable;

	UE_LOG(LogTemp, Log, TEXT("FKGNiagaraScoreManager::SetBattleEffectSlowTickForceEnabled. GbBattleEffectSlowTickEnabled=%d, GbBattleEffectSlowTickDistanceCheckEnabled=%d, bIsBattleSlowTickEnable=%d"),
	GbBattleEffectSlowTickForceEnabled, GbBattleEffectSlowTickDistanceCheckEnabled, bIsBattleSlowTickEnable);
}

void FKGNiagaraScoreManager::SetBattleEffectSlowTickEnabled(bool bIsEnable)
{
	bIsBattleSlowTickEnable = bIsEnable;

	UE_LOG(LogTemp, Log, TEXT("FKGNiagaraScoreManager::SetBattleEffectSlowTickForceEnabled. GbBattleEffectSlowTickEnabled=%d, GbBattleEffectSlowTickDistanceCheckEnabled=%d, bIsBattleSlowTickEnable=%d"),
	GbBattleEffectSlowTickForceEnabled, GbBattleEffectSlowTickDistanceCheckEnabled, bIsBattleSlowTickEnable);
}

void FKGNiagaraScoreManager::SetBattleEffectSlowTickConfig(float InDistance)
{
	this->BattleEffectSlowTickDistance = InDistance;

	UE_LOG(LogTemp, Log, TEXT("FKGNiagaraScoreManager::SetBattleEffectSlowTickConfig. Distance=%f"), InDistance);
}

void FKGNiagaraScoreManager::SetSlowTickRate(int InSlowTickRate, bool bIsForce)
{
	if (bIsForce || !this->SlowTickRate.IsSet())
	{
		this->SlowTickRate = static_cast<ETickingRate>(InSlowTickRate);

		UE_LOG(LogTemp, Log, TEXT("FKGNiagaraScoreManager::SetSlowTickRate. SlowTickRate=%d"), InSlowTickRate);
	}
}

void FKGNiagaraScoreManager::EnsureUpdateAllEnvEffectInfo()
{
	if (EnvEffectInfoUpdateFrameCount == GFrameCounter)
	{
		return;
	}
	EnvEffectInfoUpdateFrameCount = GFrameCounter;
	
	SCOPED_NAMED_EVENT(FKGNiagaraScoreManager_EnsureUpdateAllEnvEffectInfo, FColor::Red);

	if (AllocatedEffectPendingList.Num() > 0)
	{
		for (auto& ObjectKey : AllocatedEffectPendingList)
		{
			if (auto ComponentPtr = Cast<UNiagaraComponent>(ObjectKey.ResolveObjectPtr()))
			{
				ProcessPendingNiagaraComponent(ComponentPtr);
			}
		}

		AllocatedEffectPendingList.Reset();
	}

	EnvEffectArray.Reset(ActiveEnvEffectMap.Num());

	UWorld* FoundWorld = EffectManager->GetWorld();
	bool bHaveViewCenter = this->GetCachedViewCenterLocation(FoundWorld);
	bool bHaveCameraLoc = this->GetCachedCameraLocation(FoundWorld);

	for (auto It = ActiveEnvEffectMap.CreateIterator(); It; ++It)
	{
		if (auto ComponentPtr = Cast<UNiagaraComponent>(It.Key().ResolveObjectPtr()))
		{
			auto& BasicInfo = It.Value();
		
			FNiagaraScoreInstanceInfo TempInfo(ComponentPtr, BasicInfo, this->GetQualityLevelOfComponent(ComponentPtr));
			TempInfo.Location = ComponentPtr->GetComponentLocation();
		
			if (bHaveViewCenter)
			{
				TempInfo.Distance2ViewCenter = FVector::Distance(TempInfo.Location, CachedViewCenterLocation);
			}

			if (bHaveCameraLoc)
			{
				TempInfo.Distance2Camera = FVector::Distance(TempInfo.Location, CachedCameraLocation);
				TempInfo.Score = BasicInfo.ScoreData != nullptr ? BasicInfo.ScoreData->GetNiagaraScoreValue(TempInfo.QualityLevel, TempInfo.Distance2Camera) : FKGNiagaraScoreManager::DefaultScore;
			}
		
			EnvEffectArray.Add(MoveTemp(TempInfo));
		}
		else
		{
			It.RemoveCurrent();
		}
	}
}

void FKGNiagaraScoreManager::ControlAllEnvEffectsSlowTick()
{
    SCOPED_NAMED_EVENT(FKGNiagaraScoreManager_ControlAllEnvEffectsSlowTick, FColor::Red);

	this->EnsureUpdateAllEnvEffectInfo();

	const int32 Num = EnvEffectArray.Num();

    for (int32 i = Num - 1; i >= 0; i--)
    {
        FNiagaraScoreInstanceInfo& Info = EnvEffectArray[i];
        TWeakObjectPtr<UNiagaraComponent> CompPtr = Info.ComponentPtr;

    	if (CompPtr.IsValid())
    	{
    		auto InstanceController = CompPtr->GetSystemInstanceController();
    		if (InstanceController.IsValid() && InstanceController->GetActualExecutionState() == ENiagaraExecutionState::Active)
    		{
    			bool bIsSlowTick = Info.Distance2Camera > this->EnvEffectSlowTickDistance && Info.Distance2ViewCenter > this->EnvEffectSlowTickDistance;
    			SetTickingRate(CompPtr, bIsSlowTick);
    		}
    	}
    }
}

int32 FKGNiagaraScoreManager::GetQualityLevelOfComponent(const TWeakObjectPtr<UNiagaraComponent>& InNiagaraComponent)
{
	if(InNiagaraComponent.IsValid())
	{
		auto ComponentQualityLevel = InNiagaraComponent->GetComponentQualityLevel();
		if (ComponentQualityLevel != INDEX_NONE)
		{
			return ComponentQualityLevel;
		}
	}
	
	return FNiagaraPlatformSet::GetQualityLevel();
}

void FKGNiagaraScoreManager::SetTickingRate(const TWeakObjectPtr<UNiagaraComponent>& InNiagaraComponent, bool bIsSlowTick)
{
	if (!InNiagaraComponent.IsValid())
	{
		return;
	}
	
	if (!SlowTickRate.IsSet())
	{
		SlowTickRate = ETickingRate::TR_Half;

		if (GEngine)
		{
			auto MaxFps = GEngine->GetMaxFPS();
			if (MaxFps == 0 || MaxFps > 30)
			{
				SlowTickRate = ETickingRate::TR_Half;
			}
			else
			{
				SlowTickRate = ETickingRate::TR_Quarter;
			}

			UE_LOG(LogTemp, Log, TEXT("FKGNiagaraScoreManager::SlowTickRate Init. MaxFps=%f, SlowTickRate=%d"), MaxFps, static_cast<int>(SlowTickRate.GetValue()));
		}
		else
		{
			UE_LOG(LogTemp, Log, TEXT("FKGNiagaraScoreManager::SlowTickRate Init. GEngine is null? SlowTickRate=%d"), static_cast<int>(SlowTickRate.GetValue()));
		}
	}
	
	ETickingRate CurrentTickingRate = bIsSlowTick ? SlowTickRate.GetValue(): ETickingRate::TR_Full;
#if !UE_BUILD_SHIPPING && !UE_BUILD_TEST
	if (CurrentTickingRate != InNiagaraComponent->GetTickingRate())
	{
		if (GbNiagaraScoreDebugEnabled && InNiagaraComponent->GetAsset() != nullptr)
		{
			UE_LOG(LogTemp, Log, TEXT("FKGNiagaraScoreManager::SetSlowTickRate SetTickingRate, path:%s, TickingRate=%d"),
		*(InNiagaraComponent->GetAsset()->GetPathName()), CurrentTickingRate);
		}
	}
#endif
	InNiagaraComponent->SetTickingRate(CurrentTickingRate);
}

// UE_ENABLE_OPTIMIZATION