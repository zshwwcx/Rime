// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Audio/C7AnimNotifyState_AkEvent.h"

#include "AkAudioBank.h"
#include "AkAudioEvent.h"
#include "AkComponent.h"
#include "AkGameplayStatics.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Character/C7Actor.h"
#include "Manager/KGAkAudioManager.h"
#include "3C/Audio/KGAudioNotifyHelper.h"
#include "Components/SkeletalMeshComponent.h"


void UC7AnimNotifyState_AkEvent::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UC7AnimNotifyState_AkEvent::NotifyBegin");
	
	Super::NotifyBegin(MeshComp, Animation, TotalDuration, EventReference);

	if (!MeshComp || !BeginAkEvent)
	{
		return;
	}
	
	const FString EventName = BeginAkEvent->GetName();

	switch (FKGAudioNotifyHelper::GetPostType(MeshComp))
	{
	case ENotifyAkEventPostType::Forbid:
		break;

	case ENotifyAkEventPostType::EditorPreview:
		BeginAkEvent->PostOnActor(MeshComp->GetOwner(), nullptr, nullptr, nullptr, (AkCallbackType)0, nullptr, true);
		break;
		
	case ENotifyAkEventPostType::PureSkeletal:
		BeginAkEvent->PostOnActor(MeshComp->GetOwner(), nullptr, nullptr, nullptr, (AkCallbackType)0, nullptr, true);
		if (UKGAkAudioManager* AudioMgr = UKGAkAudioManager::GetInstance(MeshComp))
		{
			AudioMgr->CacheEventAsset(BeginAkEvent);
			AudioMgr->CacheEventAsset(EndAkEvent);
		}
		break;

	case ENotifyAkEventPostType::LuaEntity:
		PostNotifyStateEventOnLuaEntity(MeshComp, EventName, false);
		break;
	}
}

void UC7AnimNotifyState_AkEvent::NotifyTick(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float FrameDeltaTime, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UC7AnimNotifyState_AkEvent::NotifyTick");
	
	Super::NotifyTick(MeshComp, Animation, FrameDeltaTime, EventReference);
	if (!bDetectTerrain || !MeshComp || !BeginAkEvent)
	{
		return;
	}

	if (UWorld* World = MeshComp->GetWorld())
	{
		// 控制Tick频率
		double TimeSeconds = World->GetTimeSeconds();
		if (TimeSeconds - LastTickTime < 0.2f)
		{
			return;
		}
		LastTickTime = TimeSeconds;

		switch (FKGAudioNotifyHelper::GetPostType(MeshComp))
		{
		case ENotifyAkEventPostType::Forbid:
		case ENotifyAkEventPostType::EditorPreview:
		case ENotifyAkEventPostType::PureSkeletal:
			// 编辑态不响应该逻辑
			break;
		case ENotifyAkEventPostType::LuaEntity:
			PostNotifyStateEventOnLuaEntity(MeshComp, BeginAkEvent->GetName(), true);
			break;
		}
	}
}

void UC7AnimNotifyState_AkEvent::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UC7AnimNotifyState_AkEvent::NotifyEnd");
	
	Super::NotifyEnd(MeshComp, Animation, EventReference);
	LastTickTime = 0.f;
	if (!MeshComp || !BeginAkEvent)
	{
		return;
	}

	const ENotifyAkEventPostType PostType = FKGAudioNotifyHelper::GetPostType(MeshComp);

	if (bStopOnEnd)
	{
		switch (PostType)
		{
		case ENotifyAkEventPostType::Forbid:
			break;

		case ENotifyAkEventPostType::EditorPreview:
		case ENotifyAkEventPostType::PureSkeletal:
			BeginAkEvent->ExecuteAction(AkActionOnEventType::Stop, nullptr, PlayingID, StopBlend * 1000);
			break;

		case ENotifyAkEventPostType::LuaEntity:
			AActor* Actor = MeshComp->GetOwner();
			ICppEntityInterface* LuaEntity = UKGUEActorManager::GetLuaEntityByActor(Actor);
			if (!LuaEntity)
			{
				UE_LOG(LogAudioNotify, Warning, TEXT("NotifyEnd: %s get lua script entity failed"), *Actor->GetName());
				break;
			}

			UKGAkAudioManager* AudioMgr = UKGAkAudioManager::GetInstance(Actor);
			if (!AudioMgr)
			{
				UE_LOG(LogAudioNotify, Warning, TEXT("NotifyEnd: %lld get audio manager failed"), LuaEntity->GetLuaEntityBase()->GetEntityID());
				break;
			}

			AudioMgr->InnerStopEventByPlayingID(PlayingID, StopBlend * 1000);
			break;
		}
	}
	else if (EndAkEvent)
	{
		FString EventName = EndAkEvent->GetName();
		switch (PostType)
		{
		case ENotifyAkEventPostType::Forbid:
			break;

		case ENotifyAkEventPostType::EditorPreview:
		case ENotifyAkEventPostType::PureSkeletal:
			EndAkEvent->PostOnActor(MeshComp->GetOwner(), nullptr, nullptr, nullptr, (AkCallbackType)0, nullptr, true);
			break;

		case ENotifyAkEventPostType::LuaEntity:
			AActor* Actor = MeshComp->GetOwner();
			ICppEntityInterface* LuaEntity = UKGUEActorManager::GetLuaEntityByActor(Actor);
			if (!LuaEntity)
			{
				UE_LOG(LogAudioNotify, Warning, TEXT("NotifyState::End: %s get lua script entity failed"), *Actor->GetName());
				break;
			}

			UKGAkAudioManager* AudioMgr = UKGAkAudioManager::GetInstance(Actor);
			if (!AudioMgr)
			{
				UE_LOG(LogAudioNotify, Warning, TEXT("NotifyState::End: %lld get audio manager failed"), LuaEntity->GetLuaEntityBase()->GetEntityID());
				break;
			}

			UAkComponent* AkComp = Actor->GetComponentByClass<UAkComponent>();
			if (!AkComp)
			{
				UE_LOG(LogAudioNotify, Warning, TEXT("NotifyState::End: %lld no ak component"), LuaEntity->GetLuaEntityBase()->GetEntityID());
				break;
			}

			if (LuaEntity->GetIsUnderMainPlayerControl())
			{
				EventName.Append(FKGAudioNotifyHelper::MainPlayerSuffix);
			}

			AudioMgr->InnerPostEventOnAkComp(EventName, AkComp);
			break;
		}
	}
}

void UC7AnimNotifyState_AkEvent::PostNotifyStateEventOnLuaEntity(USkeletalMeshComponent* MeshComp, const FString& EventName, bool bFromTick)
{
	AActor* Actor = MeshComp->GetOwner();
	ICppEntityInterface* LuaEntity = UKGUEActorManager::GetLuaEntityByActor(Actor);
	if (!LuaEntity)
	{
		UE_LOG(LogAudioNotify, Warning, TEXT("PostNotifyStateEventOnLuaEntity: %s get lua script entity failed"), *Actor->GetName());
		return;
	}

	UKGAkAudioManager* AudioMgr = UKGAkAudioManager::GetInstance(Actor);
	if (!AudioMgr)
	{
		UE_LOG(LogAudioNotify, Warning, TEXT("PostNotifyStateEventOnLuaEntity: %lld get audio manager failed"), LuaEntity->GetLuaEntityBase()->GetEntityID());
		return;
	}

	UAkComponent* AkComp = Actor->GetComponentByClass<UAkComponent>();
	if (!AkComp)
	{
		UE_LOG(LogAudioNotify, Warning, TEXT("PostNotifyStateEventOnLuaEntity: %lld no ak component"), LuaEntity->GetLuaEntityBase()->GetEntityID());
		return;
	}

	FString FinalEventName = EventName;

	FString TerrainName = bDetectTerrain ? FKGAudioNotifyHelper::GetTerrainName(AudioMgr, LuaEntity) : TEXT("");

	// tick过程中如果检测到材质一致,不做处理直接返回
	if (bFromTick && bDetectTerrain && CurTerrainName.Equals(TerrainName))
	{
		return;
	}

	CurTerrainName = TerrainName;
	if (!TerrainName.IsEmpty())
	{
		FinalEventName.Append(FString::Format(TEXT("_{0}"), {TerrainName}));
	}

	if (!AudioMgr->IsValidEvent(FinalEventName))
	{
		FinalEventName = EventName;
	}

	if (LuaEntity->GetIsUnderMainPlayerControl())
	{
		FinalEventName.Append(FKGAudioNotifyHelper::MainPlayerSuffix);

		if (AudioMgr->IsEnablePrintTerrainName())
		{
			UKismetSystemLibrary::PrintString(AudioMgr, FString::Format(TEXT("{0} --- {1}"), {TerrainName, FinalEventName}));
		}
	}

	// tick过程中材质发声变化,需要停掉之前的声音
	if (bFromTick && EndAkEvent)
	{
		FString EndEventName = EndAkEvent->GetName();
		if (LuaEntity->GetIsUnderMainPlayerControl())
		{
			EndEventName.Append(FKGAudioNotifyHelper::MainPlayerSuffix);
		}

		AudioMgr->InnerPostEventOnAkComp(EndEventName, AkComp);
	}

	PlayingID = AudioMgr->InnerPostEventOnAkComp(FinalEventName, AkComp);
}
