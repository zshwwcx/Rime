// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Audio/C7AnimNotify_VoiceAkEvent.h"

#include "AkAudioBank.h"
#include "AkAudioEvent.h"
#include "AkComponent.h"
#include "AkGameplayStatics.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Character/C7Actor.h"
#include "Manager/KGAkAudioManager.h"
#include "3C/Audio/KGAudioNotifyHelper.h"
#include "Components/SkeletalMeshComponent.h"


static const FString ActorTypeSuffix_Player = "_Player";
static const FString ActorTypeSuffix_Monster = TEXT("_Monster");


void UC7AnimNotify_VoiceAkEvent::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UC7AnimNotify_VoiceAkEvent::Notify");
	
	Super::Notify(MeshComp, Animation, EventReference);
	
	if (!MeshComp || !AkEvent)
	{
		return;
	}
	
	const FString EventName = AkEvent->GetName();

	ENotifyAkEventPostType PostType = FKGAudioNotifyHelper::GetPostType(MeshComp);
	switch (PostType)
	{
	case ENotifyAkEventPostType::Forbid:
		break;
		
	case ENotifyAkEventPostType::EditorPreview:
		AkEvent->PostOnActor(MeshComp->GetOwner(), nullptr, nullptr, nullptr, (AkCallbackType)0, nullptr, true);
		break;
		
	case ENotifyAkEventPostType::PureSkeletal:
		AkEvent->PostOnActor(MeshComp->GetOwner(), nullptr, nullptr, nullptr, (AkCallbackType)0, nullptr, true);
		if (UKGAkAudioManager* AudioMgr = UKGAkAudioManager::GetInstance(MeshComp))
		{
			AudioMgr->CacheEventAsset(AkEvent);
		}
		break;
		
	case ENotifyAkEventPostType::LuaEntity:
		AActor* Actor = MeshComp->GetOwner();
		ICppEntityInterface* LuaEntity = UKGUEActorManager::GetLuaEntityByActor(Actor);
		if (!LuaEntity)
		{
			UE_LOG(LogAudioNotify, Warning, TEXT("ActionAkEvent::Notify: %s get lua script entity failed"), *Actor->GetName());
			break;
		}

		if (bMainPlayerOnly && !LuaEntity->GetIsUnderMainPlayerControl())
		{
			break;
		}

		UKGAkAudioManager* AudioMgr = UKGAkAudioManager::GetInstance(Actor);
		if (!AudioMgr)
		{
			UE_LOG(LogAudioNotify, Warning, TEXT("ActionAkEvent::Notify: %lld get audio manager failed"), LuaEntity->GetLuaEntityBase()->GetEntityID());
			break;
		}

		UAkComponent* AkComp = Actor->GetComponentByClass<UAkComponent>();
		if (!AkComp)
		{
			UE_LOG(LogAudioNotify, Warning, TEXT("ActionAkEvent::Notify: %lld no ak component"), LuaEntity->GetLuaEntityBase()->GetEntityID());
			break;
		}

		FString FinalEventName = EventName;

		if (bNeedSplice)
		{
			if (!LuaEntity->GetVoiceType().IsEmpty())
			{
				FinalEventName.Append(FString::Format(TEXT("_{0}"), {LuaEntity->GetVoiceType()}));
			}
			else
			{
				if (LuaEntity->GetIsAvatar())
				{
					FinalEventName.Append(FString::Format(TEXT("_{0}"), {ActorTypeSuffix_Player}));
				}
				else
				{
					FinalEventName.Append(FString::Format(TEXT("_{0}"), {ActorTypeSuffix_Monster}));
				}
			}	
		}

		if (!bMainPlayerOnly && LuaEntity->GetIsUnderMainPlayerControl())
		{
			FinalEventName.Append(FKGAudioNotifyHelper::MainPlayerSuffix);
		}

		int32 PlayingID = AudioMgr->InnerPostEventOnAkComp(FinalEventName, AkComp);
		double EventDuration = AudioMgr->GetEventDuration(FinalEventName);
		AudioMgr->AddNotifyEventRecord(PlayingID, EventDuration, LuaEntity->GetIsAvatar());
		break;
	}
}
