// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Audio/C7AnimNotify_FootStepAkEvent.h"

#include "AkAudioBank.h"
#include "AkAudioEvent.h"
#include "AkComponent.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Audio/C7AnimNotify_ActionAkEvent.h"
#include "3C/Character/C7Actor.h"
#include "Manager/KGAkAudioManager.h"
#include "Manager/KGPlatformScalabilitySettings.h"
#include "Misc/KGPlatformUtils.h"
#include "3C/Audio/KGAudioNotifyHelper.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "3C/Interactor/WorldManager.h"
#include "Components/CapsuleComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "3C/Effect/KGEffectManager.h"
#include "Managers/KGCombatUnitManager.h"
#include "Managers/KGDataCacheManager.h"
#include "TypeDefines/CacheDataTypes.h"
#include "3C/Util/KGUtils.h"

void UC7AnimNotify_FootStepAkEvent::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UC7AnimNotify_FootStepAkEvent::Notify");
	
	Super::Notify(MeshComp, Animation, EventReference);
	if (!MeshComp)
	{
		return;
	}

	AActor* OwnerActor = MeshComp->GetOwner();
	if (!OwnerActor)
	{
		return;
	}

	ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(OwnerActor);
	if (BaseCharacter && BaseCharacter->IsCrowdNpc())
	{
		return;	
	}
	
	if (BaseCharacter && !KGPlatformUtils::IsInLevelPreviewWorld(MeshComp))
	{
		if (UKGPlatformScalabilitySettings* PlatformScalabilitySettings = UKGPlatformScalabilitySettings::GetInstance(MeshComp))
		{
			if (!PlatformScalabilitySettings->GetScalabilityLodValue<bool>(BaseCharacter->GetActorLOD(), "LocoPerformance", "LocoPerformanceLODControl"))
			{
				return;
			}		
		}
	}
	
	TriggerFootStepAudio(MeshComp);
	TriggerActionAudio(MeshComp);
	TriggerNiagara(MeshComp);
}

void UC7AnimNotify_FootStepAkEvent::TriggerFootStepAudio(USkeletalMeshComponent* MeshComp)
{
	if (!MeshComp || !AkEvent)
	{
		return;
	}
	
	const FString EventName = AkEvent->GetName();

	ENotifyAkEventPostType PostType = FKGAudioNotifyHelper::GetPostType(MeshComp);
	switch (PostType)
	{
	case ENotifyAkEventPostType::Forbid:
		break;
		
	case ENotifyAkEventPostType::EditorPreview:
		AkEvent->PostOnActor(MeshComp->GetOwner(), nullptr, nullptr, nullptr, (AkCallbackType)0, nullptr, true);
		break;
		
	case ENotifyAkEventPostType::PureSkeletal:
		AkEvent->PostOnActor(MeshComp->GetOwner(), nullptr, nullptr, nullptr, (AkCallbackType)0, nullptr, true);
		if (UKGAkAudioManager* AudioMgr = UKGAkAudioManager::GetInstance(MeshComp))
		{
			AudioMgr->CacheEventAsset(AkEvent);
		}
		break;
		
	case ENotifyAkEventPostType::LuaEntity:
		AActor* Actor = MeshComp->GetOwner();
		ICppEntityInterface* LuaEntity = UKGUEActorManager::GetLuaEntityByActor(Actor);
		if (!LuaEntity)
		{
			UE_LOG(LogAudioNotify, Warning, TEXT("FootStepAkEvent::Notify: %s get lua script entity failed"), *Actor->GetName());
			break;
		}

		UKGAkAudioManager* AudioMgr = UKGAkAudioManager::GetInstance(Actor);
		if (!AudioMgr)
		{
			UE_LOG(LogAudioNotify, Warning, TEXT("FootStepAkEvent::Notify: %lld get audio manager failed"), LuaEntity->GetLuaEntityBase()->GetEntityID());
			break;
		}

		UAkComponent* AkComp = Actor->GetComponentByClass<UAkComponent>();
		if (!AkComp)
		{
			UE_LOG(LogAudioNotify, Warning, TEXT("FootStepAkEvent::Notify: %lld no ak component"), LuaEntity->GetLuaEntityBase()->GetEntityID());
			break;
		}

		if (!bNeedSplice)
		{
			AudioMgr->InnerPostEventOnAkComp(EventName, AkComp);
			break;
		}

		FString FinalEventName = EventName;
		
		FString FashionShoesMaterial = LuaEntity->GetShoesAudioMaterial();
		if (!FashionShoesMaterial.IsEmpty())
		{
			FinalEventName.Append(FString::Format(TEXT("_{0}"), {FashionShoesMaterial}));
		}

		FString TerrainName = FKGAudioNotifyHelper::GetTerrainName(AudioMgr, LuaEntity);
		if (!TerrainName.IsEmpty())
		{
			FinalEventName.Append(FString::Format(TEXT("_{0}"), {TerrainName}));
		}

		if (TerrainName == UWorldManager::TerrainNameInWater)
		{
			if (URoleMovementComponent* MovementComponent = Actor->GetComponentByClass<URoleMovementComponent>())
			{
				AudioMgr->SetRtpcValueOnAkGameObject(AkComp, UKGAkAudioManager::WaterDepthRtpcName, MovementComponent->GetCurWaterDepth());
			}
		}
  
		// 保底,但要区分1/3P
		if (!AudioMgr->IsValidEvent(FinalEventName))
		{
			FinalEventName = EventName;
		}

		if (LuaEntity->GetIsUnderMainPlayerControl())
		{
			FinalEventName.Append(FKGAudioNotifyHelper::MainPlayerSuffix);

			if (AudioMgr->IsEnablePrintTerrainName())
			{
				UKismetSystemLibrary::PrintString(AudioMgr, FString::Format(TEXT("{0} --- {1}"), {TerrainName, FinalEventName}));
			}
		}

		int32 PlayingID = AudioMgr->InnerPostEventOnAkComp(FinalEventName, AkComp);
		double EventDuration = AudioMgr->GetEventDuration(FinalEventName);
		AudioMgr->AddNotifyEventRecord(PlayingID, EventDuration, LuaEntity->GetIsAvatar());
		break;
	}
}

void UC7AnimNotify_FootStepAkEvent::TriggerActionAudio(USkeletalMeshComponent* MeshComp)
{
	UC7AnimNotify_ActionAkEvent::RealPostActionAkEvent(MeshComp, ActionAkEvent, bMainPlayerOnly, bSplitFashion);
}

void UC7AnimNotify_FootStepAkEvent::TriggerNiagara(USkeletalMeshComponent* MeshComp)
{
	if (!MeshComp)
	{
		return;
	}

	AActor* OwnerActor = MeshComp->GetOwner();
	if (!OwnerActor)
	{
		return;
	}

	URoleMovementComponent* RoleMovementComp = OwnerActor->GetComponentByClass<URoleMovementComponent>();
	if (!RoleMovementComp)
	{
		return;
	}

	UWorldManager* WorldManager = UWorldManager::GetInstance(OwnerActor);
	if (!WorldManager)
	{
		return;
	}

	FString TerrainName = GetNiagaraTerrainName(OwnerActor);

	// 触发脚印
	TriggerFootprint(MeshComp, RoleMovementComp, TerrainName, NiagaraBaseSocket);
	// UE_LOG(LogTemp, Log, TEXT("[TriggerFootprint] TerrainName=%s, LastTerrainName=%s"), *TerrainName, *RoleMovementComp->GetLastFootStepTerrainName());
	RoleMovementComp->RecordFootStepTerrain(TerrainName);
	
	if (TerrainName.IsEmpty())
	{
		return;
	}
	
	// 水深检测
	if (RoleMovementComp->GetIsInWater() && !WorldManager->IsInLegalWaterDepth(RoleMovementComp->GetCurWaterDepth()))
	{
		return;
	}
	
	FString NiagaraPath = WorldManager->GetNiagaraPathByTerrainName(TerrainName);
	if (NiagaraPath.IsEmpty())
	{
		return;
	}

	UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(OwnerActor);
	if (!EffectManager)
	{
		return;
	}

	FKGPlayNiagaraParams PlayNiagaraParams;
	PlayNiagaraParams.NiagaraEffectPath = NiagaraPath;
	PlayNiagaraParams.SpawnerID = KGUtils::GetIDByObject(OwnerActor);
	PlayNiagaraParams.StickGroundType = EKGNiagaraStickGroundType::StickToWaterSurface;
	if (!bNiagaraAttach)
	{
		FKGUnattachedNiagaraSpawnInfo UnattachedNiagaraSpawnInfo;
		UnattachedNiagaraSpawnInfo.SearchSpawnLocationType = EKGNiagaraSearchSpawnLocationType::UseCustomSpawnTrans;
		UnattachedNiagaraSpawnInfo.WorldOrRelativeTrans = NiagaraTransform * MeshComp->GetSocketTransform(NiagaraBaseSocket, RTS_World);
		PlayNiagaraParams.SetUnattachedSpawnInfo(UnattachedNiagaraSpawnInfo);
	}
	else
	{
		FKGAttachedNiagaraSpawnInfo AttachedNiagaraSpawnInfo;
		AttachedNiagaraSpawnInfo.RelativeTrans = NiagaraTransform;
		AttachedNiagaraSpawnInfo.SearchAttachComponentType = EKGNiagaraSearchAttachComponentType::UseMainMeshComponent;
		AttachedNiagaraSpawnInfo.AttachPointName = NiagaraBaseSocket;
		AttachedNiagaraSpawnInfo.bAbsoluteRotation = bNiagaraUseAbsoluteRotation;
		PlayNiagaraParams.SetAttachedSpawnInfo(AttachedNiagaraSpawnInfo);
	}

	EffectManager->CreateNiagaraSystem(PlayNiagaraParams);
}

void UC7AnimNotify_FootStepAkEvent::TriggerFootprint(const USkeletalMeshComponent* MeshComp, const URoleMovementComponent* RoleMovementComp, const FString& CurrentTerrainName, const FName& FootprintSocket)
{
	if (!RoleMovementComp || !MeshComp)
	{
		return;
	}

	AActor* OwnerActor = MeshComp->GetOwner();
	if (!OwnerActor)
	{
		return;
	}

	UWorld* World = RoleMovementComp->GetWorld();
	if (!World)
	{
		UE_LOG(LogTemp, Warning, TEXT("[TriggerFootprint] get World failed"));
		return;
	}

	UKGDataCacheManager* DataCacheMgr = UKGDataCacheManager::GetInstance(World);
	if (!DataCacheMgr)
	{
		UE_LOG(LogTemp, Warning, TEXT("[TriggerFootprint] get UKGDataCacheManager failed"));
		return;
	}
	
	UKGCombatUnitManager* CombatUnitMgr = UKGCombatUnitManager::GetInstance(World);
	if (!CombatUnitMgr)
	{
		UE_LOG(LogTemp, Warning, TEXT("[TriggerFootprint] get UKGCombatUnitManager failed"));
		return;
	}
	
	// 当前材质需要触发
	FTerrainFootprintData* CurrentFootprintData = DataCacheMgr->GetTerrainFootprintData(CurrentTerrainName);
	if (CurrentFootprintData && !CurrentFootprintData->bTriggerOnLeave)
	{
		FVector FootprintLocation = OwnerActor->GetActorLocation();
		int32 BoneIndex = MeshComp->GetBoneIndex(FootprintSocket);
		if (BoneIndex != INDEX_NONE)
		{
			FootprintLocation = MeshComp->GetBoneLocation(FootprintSocket);
		}
		
		FKGSimpleDecalSpawnParams DecalSpawnParams;
		DecalSpawnParams.SpawnerActor = OwnerActor;
		DecalSpawnParams.MaterialPath = CurrentFootprintData->DecalMaterialPath;
		DecalSpawnParams.DecalSize = CurrentFootprintData->DecalSize;
		DecalSpawnParams.Transform.SetLocation(FootprintLocation);
		DecalSpawnParams.Transform.SetRotation(OwnerActor->GetActorQuat());
		DecalSpawnParams.PosMode = EDecalPositionMode::World;
		DecalSpawnParams.RotMode = EDecalRotationMode::World;
		DecalSpawnParams.bNeedCheckGround = true;
		DecalSpawnParams.FadeInTimeSeconds = 0.f;
		DecalSpawnParams.FadeOutTimeSeconds = CurrentFootprintData->FadeOutTime;
		DecalSpawnParams.LifeTimeSeconds = CurrentFootprintData->LifeTime;
		
		CombatUnitMgr->SpawnDecalSimple(DecalSpawnParams);
		return;
	}
	
	// 前后一致,不处理
	const FString LastFootStepTerrainName = RoleMovementComp->GetLastFootStepTerrainName();
	if (CurrentTerrainName == LastFootStepTerrainName)
	{
		return;
	}

	// 被记录的材质需要触发
	FTerrainFootprintData* LastFootprintData = DataCacheMgr->GetTerrainFootprintData(LastFootStepTerrainName);
	if (LastFootprintData && LastFootprintData->bTriggerOnLeave)
	{
		// 视同效果的地形名称列表,离开地形后的新地形在这个列表中,则不会触发脚印
		if (LastFootprintData->SameEffectTerrainList.Contains(CurrentTerrainName))
		{
			return;
		}

		float DeltaTime = World->GetTimeSeconds() - RoleMovementComp->GetLastFootStepRecordTime();
		if (DeltaTime > LastFootprintData->RemainTime)
		{
			return;
		}

		FVector FootprintLocation = OwnerActor->GetActorLocation();
		int32 BoneIndex = MeshComp->GetBoneIndex(FootprintSocket);
		if (BoneIndex != INDEX_NONE)
		{
			FootprintLocation = MeshComp->GetBoneLocation(FootprintSocket);
		}
	
		// 时间衰减系数
		float Alpha = 1 - DeltaTime / LastFootprintData->RemainTime;

		FKGSimpleDecalSpawnParams DecalSpawnParams;
		DecalSpawnParams.SpawnerActor = OwnerActor;
		DecalSpawnParams.MaterialPath = LastFootprintData->DecalMaterialPath;
		DecalSpawnParams.DecalSize = LastFootprintData->DecalSize;
		DecalSpawnParams.Transform.SetLocation(FootprintLocation);
		DecalSpawnParams.Transform.SetRotation(OwnerActor->GetActorQuat());
		DecalSpawnParams.PosMode = EDecalPositionMode::World;
		DecalSpawnParams.RotMode = EDecalRotationMode::World;
		DecalSpawnParams.bNeedCheckGround = true;
		DecalSpawnParams.FadeInTimeSeconds = 0.f;
		DecalSpawnParams.FadeOutTimeSeconds = LastFootprintData->FadeOutTime * Alpha;
		DecalSpawnParams.LifeTimeSeconds = LastFootprintData->LifeTime;
		DecalSpawnParams.OpacityEndVal = Alpha;

		CombatUnitMgr->SpawnDecalSimple(DecalSpawnParams);
	}
}

FString UC7AnimNotify_FootStepAkEvent::GetNiagaraTerrainName(AActor* InActor)
{
	if (!InActor)
	{
		return TEXT("");
	}

	URoleMovementComponent* RoleMovementComp = InActor->GetComponentByClass<URoleMovementComponent>();
	if (!RoleMovementComp)
	{
		return TEXT("");
	}

	UWorldManager* WorldManager = UWorldManager::GetInstance(InActor);
	if (!WorldManager)
	{
		return TEXT("");
	}

	if (RoleMovementComp->GetIsInWater() || RoleMovementComp->GetIsInWaterWalk())
	{
		return WorldManager->GetTerrainNameByWaterDepth(RoleMovementComp->GetCurWaterDepth());
	}

	UCapsuleComponent* CapsuleComp = InActor->GetComponentByClass<UCapsuleComponent>();
	if (!CapsuleComp)
	{
		return TEXT("");
	}
	
	FVector QueryLocation = InActor->GetActorLocation();
	double QueryDepth = CapsuleComp->GetScaledCapsuleHalfHeight() * 2;
	return WorldManager->QueryTerrainName(QueryLocation, QueryDepth);
}
