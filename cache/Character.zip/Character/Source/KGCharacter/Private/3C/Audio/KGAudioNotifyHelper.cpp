#include "3C/Audio/KGAudioNotifyHelper.h"

#include "3C/Character/BaseCharacter.h"
#include "3C/Character/C7Actor.h"
#include "Manager/KGAkAudioManager.h"
#include "Misc/KGPlatformUtils.h"
#include "3C/Interactor/WorldManager.h"
#include "PhysicalMaterials/PhysicalMaterial.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/SkeletalMeshComponent.h"


DEFINE_LOG_CATEGORY(LogAudioNotify)

const FString FKGAudioNotifyHelper::MainPlayerSuffix = TEXT("_1P");

ENotifyAkEventPostType FKGAudioNotifyHelper::GetPostType(USkeletalMeshComponent* SkComp)
{
	AActor* Actor = SkComp->GetOwner();
	if (!Actor || Actor->IsHidden())
	{
		return ENotifyAkEventPostType::Forbid;
	}

	ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(Actor);
	if (BaseCharacter && BaseCharacter->IsCrowdNpc())
	{
		return ENotifyAkEventPostType::Forbid;
	}

	UWorld* World = Actor->GetWorld();
	if (!World)
	{
		UE_LOG(LogAudioNotify, Warning, TEXT("FKGAudioNotifyHelper::GetPostType: %s no world"), *Actor->GetName());
		return ENotifyAkEventPostType::Forbid;
	}

	if (!World->IsGameWorld())
	{
#if WITH_EDITOR
		return ENotifyAkEventPostType::EditorPreview;
#else
		return ENotifyAkEventPostType::Forbid;
#endif
	}

	if (KGPlatformUtils::IsInLevelPreviewWorld(SkComp))
	{
		return ENotifyAkEventPostType::EditorPreview;
	}
	
	if (!Actor->IsA(ABaseCharacter::StaticClass()) && !Actor->IsA(AC7Actor::StaticClass()))
	{
		return ENotifyAkEventPostType::PureSkeletal;
	}

	UKGAkAudioManager* AudioMgr = UKGAkAudioManager::GetInstance(Actor);
	if (!AudioMgr)
	{
		UE_LOG(LogAudioNotify, Warning, TEXT("FKGAudioNotifyHelper::GetPostType: %s get audio manager failed"), *Actor->GetName());
		return ENotifyAkEventPostType::Forbid;
	}

	ICppEntityInterface* LuaEntity = UKGUEActorManager::GetLuaEntityByActor(Actor);
	if (!LuaEntity)
	{
		UE_LOG(LogAudioNotify, Warning, TEXT("FKGAudioNotifyHelper::GetPostType: %s get lua entity failed"), *Actor->GetName());
		return ENotifyAkEventPostType::Forbid;
	}

	if (IsMajorUnit(LuaEntity))
	{
		return ENotifyAkEventPostType::LuaEntity;
	}

	if (!AudioMgr->CanPostNotifyEvent(LuaEntity->GetIsAvatar()))
	{
		return ENotifyAkEventPostType::Forbid;
	}

	return ENotifyAkEventPostType::LuaEntity;
}

bool FKGAudioNotifyHelper::IsMajorUnit(class ICppEntityInterface* LuaEntity)
{
	if (!LuaEntity)
	{
		return false;
	}

	AActor* Actor = LuaEntity->GetLuaEntityBase()->GetActor();
	if (!Actor)
	{
		return false;
	}

	UKGAkAudioManager* AudioMgr = UKGAkAudioManager::GetInstance(Actor);
	if (!AudioMgr)
	{
		return false;
	}

	bool bIsUnderMainPlayerControl = LuaEntity->GetIsUnderMainPlayerControl();
	bool bIsBoss = LuaEntity->GetIsBoos();
	bool bIsLockTarget = LuaEntity->GetLuaEntityBase()->GetEntityID() == AudioMgr->GetLockTargetUID();

	return bIsUnderMainPlayerControl || bIsBoss || bIsLockTarget;
}

static const FString TerrainName_Water = TEXT("Water");

FString FKGAudioNotifyHelper::GetTerrainName(UKGAkAudioManager* AudioMgr, ICppEntityInterface* LuaEntity)
{
	FString TerrainName;
	UWorldManager* WorldManager = UWorldManager::GetInstance(AudioMgr);
	if (!WorldManager || !AudioMgr || !LuaEntity)
	{
		return FString();
	}

	AActor* BoundActor = LuaEntity->GetLuaEntityBase()->GetActor();
	if (!BoundActor)
	{
		return FString();
	}

	// 如果在水中,统一返回水体
	if (URoleMovementComponent* MovementComponent = BoundActor->GetComponentByClass<URoleMovementComponent>())
	{
		if (MovementComponent->GetIsInWater() || MovementComponent->GetIsInWaterWalk())
		{
			return UWorldManager::TerrainNameInWater;
		}
	}

	// 主角需要射线检测查询地表
	if (LuaEntity->GetIsUnderMainPlayerControl())
	{
		if (UCapsuleComponent* CapsuleComp = BoundActor->GetComponentByClass<UCapsuleComponent>())
		{
			FVector QueryLocation = BoundActor->GetActorLocation();
			double QueryDepth = CapsuleComp->GetScaledCapsuleHalfHeight() * 2;
			return WorldManager->QueryTerrainName(QueryLocation, QueryDepth, AudioMgr->IsEnablePrintTerrainName());
		}
	}
	else
	{
		if (UCharacterMovementComponent* CharacterMovementComp = BoundActor->GetComponentByClass<UCharacterMovementComponent>())
		{
			TWeakObjectPtr<UPhysicalMaterial> PhysMaterial = CharacterMovementComp->CurrentFloor.HitResult.PhysMaterial;
			if (PhysMaterial.IsValid())
			{
				const FString& MaterialName = PhysMaterial.Get()->GetName();
				return WorldManager->GetTerrainNameByMaterialName(MaterialName);
			}
		}
	}

	return FString();
}
