// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Audio/C7AnimNotify_ActionAkEvent.h"

#include "AkAudioBank.h"
#include "AkAudioEvent.h"
#include "AkComponent.h"
#include "AkGameplayStatics.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Character/C7Actor.h"
#include "Manager/KGAkAudioManager.h"
#include "3C/Audio/KGAudioNotifyHelper.h"
#include "Components/SkeletalMeshComponent.h"


void UC7AnimNotify_ActionAkEvent::RealPostActionAkEvent(USkeletalMeshComponent* MeshComp, class UAkAudioEvent* AkEvent, bool bMainPlayerOnly, bool bSplitFashion)
{
	if (!MeshComp || !AkEvent)
	{
		return;
	}
	
	const FString EventName = AkEvent->GetName();

	ENotifyAkEventPostType PostType = FKGAudioNotifyHelper::GetPostType(MeshComp);
	switch (PostType)
	{
	case ENotifyAkEventPostType::Forbid:
		break;
		
	case ENotifyAkEventPostType::EditorPreview:
		AkEvent->PostOnActor(MeshComp->GetOwner(), nullptr, nullptr, nullptr, (AkCallbackType)0, nullptr, true);
		break;
		
	case ENotifyAkEventPostType::PureSkeletal:
		AkEvent->PostOnActor(MeshComp->GetOwner(), nullptr, nullptr, nullptr, (AkCallbackType)0, nullptr, true);
		if (UKGAkAudioManager* AudioMgr = UKGAkAudioManager::GetInstance(MeshComp))
		{
			AudioMgr->CacheEventAsset(AkEvent);
		}
		break;
		
	case ENotifyAkEventPostType::LuaEntity:
		AActor* Actor = MeshComp->GetOwner();
		ICppEntityInterface* LuaEntity = UKGUEActorManager::GetLuaEntityByActor(Actor);
		if (!LuaEntity)
		{
			UE_LOG(LogAudioNotify, Warning, TEXT("ActionAkEvent::Notify: %s get lua script entity failed"), *Actor->GetName());
			break;
		}

		if (!LuaEntity->GetIsUnderMainPlayerControl() && bMainPlayerOnly)
		{
			break;
		}

		UKGAkAudioManager* AudioMgr = UKGAkAudioManager::GetInstance(Actor);
		if (!AudioMgr)
		{
			UE_LOG(LogAudioNotify, Warning, TEXT("ActionAkEvent::Notify: %lld get audio manager failed"), LuaEntity->GetLuaEntityBase()->GetEntityID());
			break;
		}

		UAkComponent* AkComp = Actor->GetComponentByClass<UAkComponent>();
		if (!AkComp)
		{
			UE_LOG(LogAudioNotify, Warning, TEXT("ActionAkEvent::Notify: %lld no ak component"), LuaEntity->GetLuaEntityBase()->GetEntityID());
			break;
		}

		FString FinalEventName = EventName;

		FString FashionAudioMaterial = LuaEntity->GetFashionAudioMaterial();
		if (bSplitFashion && !bMainPlayerOnly && !FashionAudioMaterial.IsEmpty())
		{
			FinalEventName.Append(FString::Format(TEXT("_{0}"), {FashionAudioMaterial}));
		}

		if (LuaEntity->GetIsUnderMainPlayerControl() && !bMainPlayerOnly)
		{
			FinalEventName.Append(FKGAudioNotifyHelper::MainPlayerSuffix);
		}

		int32 PlayingID = AudioMgr->InnerPostEventOnAkComp(FinalEventName, AkComp);
		double EventDuration = AudioMgr->GetEventDuration(FinalEventName);
		AudioMgr->AddNotifyEventRecord(PlayingID, EventDuration, LuaEntity->GetIsAvatar());
		break;
	}
}

void UC7AnimNotify_ActionAkEvent::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UC7AnimNotify_ActionAkEvent::Notify");
	Super::Notify(MeshComp, Animation, EventReference);
	RealPostActionAkEvent(MeshComp, AkEvent, bMainPlayerOnly, bSplitFashion);
}
