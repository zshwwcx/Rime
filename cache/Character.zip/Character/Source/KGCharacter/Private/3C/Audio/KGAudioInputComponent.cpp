// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Audio/KGAudioInputComponent.h"

#include "Audio.h"
#include "Manager/KGAkAudioManager.h"
#include "Misc/FileHelper.h"
#include "3C/Util/KGUtils.h"

#define WAV_HEADER_SIZE 44

int32 UKGAudioInputComponent::PlayAudioInputEvent(const TArray<uint8>& WavData)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("PlayAudioInputEvent")

	// Component存续期间播放新的
	if (bPlaying)
	{
		Stop();
		bPlaying = false;
	}

	if (WavData.IsEmpty())
	{
		UE_LOG(LogAkAudio, Warning, TEXT("[PlayAudioInputEvent] WavData is empty"));
		return AK_INVALID_PLAYING_ID;
	}

	auto* AudioMgr = UKGAkAudioManager::GetInstance(this);
	if (!AudioMgr)
	{
		UE_LOG(LogAkAudio, Warning, TEXT("[PlayAudioInputEvent] get UKGAkAudioManager failed"));
		return AK_INVALID_PLAYING_ID;
	}

	UAkAudioEvent* AudioInputEvent = AudioMgr->GetAudioInputEvent();
	if (!AudioInputEvent)
	{
		UE_LOG(LogAkAudio, Warning, TEXT("[PlayAudioInputEvent] get audio input event failed"));
		return AK_INVALID_PLAYING_ID;
	}

	FWaveModInfo WaveModInfo;
	if (!WaveModInfo.ReadWaveInfo(WavData.GetData(), WavData.Num()))
	{
		UE_LOG(LogAkAudio, Warning, TEXT("[PostAudioInputEvent] wav file read failed"));
		return AK_INVALID_PLAYING_ID;
	}

	AkAudioEvent = AudioInputEvent;

	SrcSampleRate = *WaveModInfo.pSamplesPerSec;
	if (SrcSampleRate == 0)
	{
		UE_LOG(LogAkAudio, Warning, TEXT("[PostAudioInputEvent] invalid sample rate %u"), SrcNumChannels);
		return AK_INVALID_PLAYING_ID;
	}
	
	SrcNumChannels = *WaveModInfo.pChannels;
	if (SrcNumChannels == 0)
	{
		UE_LOG(LogAkAudio, Warning, TEXT("[PostAudioInputEvent] invalid channels %d"), SrcNumChannels);
		return AK_INVALID_PLAYING_ID;
	}
	
	int32 BitsPerSample = *WaveModInfo.pBitsPerSample;
	const uint8* PCMData = WaveModInfo.SampleDataStart;
	SrcNumSamples = WaveModInfo.SampleDataSize / (BitsPerSample / 8) / SrcNumChannels;

	TArray<float> InterleavedFloatData;
	InterleavedFloatData.SetNumUninitialized(SrcNumSamples * SrcNumChannels);

	if (BitsPerSample == 16)
	{
		const int16* PCM16 = reinterpret_cast<const int16*>(PCMData);
		for (uint32 i = 0; i < SrcNumSamples * SrcNumChannels; ++i)
		{
			InterleavedFloatData[i] = PCM16[i] / 32768.0f; // 16-bit PCM 的最大负数范围
		}
	}
	else if (BitsPerSample == 32 && *WaveModInfo.pFormatTag == FWaveModInfo::WAVE_INFO_FORMAT_IEEE_FLOAT)
	{
		const float* PCM32 = reinterpret_cast<const float*>(PCMData);
		for (uint32 Idx = 0; Idx < SrcNumSamples * SrcNumChannels; ++Idx)
		{
			InterleavedFloatData[Idx] = PCM32[Idx];
		}
	}
	else
	{
		UE_LOG(LogAkAudio, Warning, TEXT("[PostAudioInputEvent] invalid wav format BitsPerSample:%d, Format:%d"), BitsPerSample, *WaveModInfo.pFormatTag);
		return AK_INVALID_PLAYING_ID;
	}

	UE_LOG(LogAkAudio, Log, TEXT("[PostAudioInputEvent] NumChannels=%d, NumSamplesPerChannel=%u"), SrcNumChannels, SrcNumSamples);

	NonInterleavedData.Empty();
	NonInterleavedData.SetNum(SrcNumChannels);

	for (int32 Idx = 0; Idx < SrcNumChannels; ++Idx)
	{
		NonInterleavedData[Idx].SetNum(SrcNumSamples);
	}

	for (int32 Ch = 0; Ch < SrcNumChannels; ++Ch)
	{
		for (uint32 SampleIdx = 0; SampleIdx < SrcNumSamples; ++SampleIdx)
		{
			NonInterleavedData[Ch][SampleIdx] = InterleavedFloatData[SampleIdx * SrcNumChannels + Ch];
		}
	}

	bPlaying = true;
	bPause = false;
	FileOffset = 0;
	return PostAssociatedAudioInputEvent();
}

void UKGAudioInputComponent::PauseAudioInputEvent(bool InPause)
{
	UE_LOG(LogAkAudio, Warning, TEXT("[PauseAudioInputEvent] %d"), InPause);
	bPause = InPause;
}

void UKGAudioInputComponent::StopAudioInputEvent()
{
	UE_LOG(LogAkAudio, Log, TEXT("[StopAudioInputEvent]"));
	Stop();
	DestroyComponent();
}

bool UKGAudioInputComponent::FillSamplesBuffer(uint32 NumChannels, uint32 NumSamples, float** BufferToFill)
{
	if (bPause)
	{
		return true;
	}

	if (NumChannels != NonInterleavedData.Num())
	{
		// wav的通道数和回调的通道不一致?
		UE_LOG(LogAkAudio, Error, TEXT("[FillSamplesBuffer] NumChannelsInCallback=%d, NumChannelsInWav=%d"), NumChannels, NonInterleavedData.Num());
	}

	for (uint32 Ch = 0; Ch < NumChannels; ++Ch)
	{
		for (uint32 SampleIdx = 0; SampleIdx < NumSamples; ++SampleIdx)
		{
			if (FileOffset + SampleIdx < SrcNumSamples)
			{
				BufferToFill[Ch][SampleIdx] = NonInterleavedData[Ch][FileOffset + SampleIdx];
			}
			else
			{
				BufferToFill[Ch][SampleIdx] = 0.f; // 超过 WAV 长度，填 0
			}
		}
	}

	// 如果组件请求的通道比 WAV 少，用 0 填充
	for (uint32 Ch = NumChannels; Ch < NumChannels; ++Ch)
	{
		FMemory::Memset(BufferToFill[Ch], 0, sizeof(float) * NumChannels);
	}

	// 更新播放位置
	FileOffset += NumSamples;
	if (FileOffset >= SrcNumSamples)
	{
		UE_LOG(LogAkAudio, Log, TEXT("[FillSamplesBuffer] audio input event end on %u"), FileOffset);
		bPlaying = false;
		bPause = false;
		Stop();
		return false;
	}

	return true;
}

void UKGAudioInputComponent::GetChannelConfig(AkAudioFormat& AudioFormat)
{
	AudioFormat.uSampleRate = SrcSampleRate;
	if (SrcNumChannels == 1)
	{
		AudioFormat.channelConfig.SetStandard(AK_SPEAKER_SETUP_MONO);
	}
	else if (SrcNumChannels == 2)
	{
		AudioFormat.channelConfig.SetStandard(AK_SPEAKER_SETUP_STEREO);
	}
	else
	{
		UE_LOG(LogAkAudio, Warning, TEXT("[GetChannelConfig] unsupported channels %d, default to use AK_SPEAKER_SETUP_STEREO"), SrcNumChannels);
		AudioFormat.channelConfig.SetStandard(AK_SPEAKER_SETUP_STEREO);
	}

	UE_LOG(LogAkAudio, Log, TEXT("[GetChannelConfig] SampleRate=%u, NumChannels=%u"), SrcSampleRate, AudioFormat.GetNumChannels());
}
