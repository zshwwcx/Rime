// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Core/TrackSplineComponent.h"
#include "Kismet/KismetMathLibrary.h"

void UTrackSplineComponent::OnRegister()
{
	ClearSplinePoints(true);
	RefreshTrackEnable();
	
	Super::OnRegister();
}
void UTrackSplineComponent::OnComponentDestroyed(bool bDestroyingHierarchy)
{
	UE_LOG(LogTemp, Log, TEXT("UTrackSplineComponent::OnComponentDestroyed"));
	Super::OnComponentDestroyed(bDestroyingHierarchy);
}

// Called when the game starts
void UTrackSplineComponent::BeginPlay()
{
	Super::BeginPlay();
	
}

void UTrackSplineComponent::SetTrackEnabled(bool bEnabled)
{
	if (bIsTrackEnabled == bEnabled)
	{
		return;
	}
	bIsTrackEnabled = bEnabled;
	RefreshTrackEnable();
}

void UTrackSplineComponent::RefreshTrackEnable()
{
	if (AActor* Owner = GetOwner())
	{
		Owner->SetActorHiddenInGame(!bIsTrackEnabled);
	}
	// SetVisibility(bIsTrackEnabled, true);
	if (!bIsTrackEnabled)
	{
		ClearSplinePoints(true);
		if (!CachedTrackPath.IsEmpty())
		{
			CachedTrackPath.Empty();
		}
	}
}

bool UTrackSplineComponent::IsSameStartAndEnd(const FVector &StartPos, const FVector &EndPos)
{
	if (CachedTrackPath.Num() <= 1)
	{
		return false;
	}
	if (UKismetMathLibrary::Vector_Distance2DSquared(CachedTrackPath[0], StartPos) > PosOffsetErrorSquared)
	{
		return false;
	}
	const int32 RealNum = CachedTrackPath.Num();
	if (UKismetMathLibrary::Vector_Distance2DSquared(CachedTrackPath[RealNum-1], EndPos) > PosOffsetErrorSquared)
	{
		return false;
	}
	return true;

}

bool UTrackSplineComponent::IsSameTrackFromCached(TArray<FVector> &Points)
{
	const int32 RealNum = Points.Num();
	if (CachedTrackPath.Num() != RealNum)
	{
		return false;
	}
	return IsSameStartAndEnd(Points[0], Points[RealNum-1]);
}

void UTrackSplineComponent::UpdateTrackByPath(TArray<FVector> &Points, bool bForceUpdate)
{
	if (Points.IsEmpty() || Points.Num() <= 1)
	{
		SetTrackEnabled(false);
		return;
	}
	if (!bForceUpdate && IsSameTrackFromCached(Points))
	{
		return;
	}
	DoUpdateTrack(Points);
}

void UTrackSplineComponent::CacheCurPath(TArray<FVector> &Path)
{
	if (!CachedTrackPath.IsEmpty())
	{
		CachedTrackPath.Empty();
	}
	for (int32 Idx=0; Idx<Path.Num(); Idx++)
	{
		CachedTrackPath.Add(Path[Idx]);
	}
}

void UTrackSplineComponent::TryCutPath(TArray<FVector>& Points, TArray<FVector>& CutPoints)
{
	float AccumulatedDistance = 0.0;
	CutPoints.Add(Points[0]);
	for (int32 Idx=1; Idx<Points.Num(); Idx++)
	{
		const FVector &LastPos = Points[Idx-1];
		const FVector &CurPos = Points[Idx];
		FVector Direction = CurPos - LastPos;
		const float Distance = Direction.Size();
		if (AccumulatedDistance + Distance < PathMaxLength)
		{
			CutPoints.Add(Points[Idx]);
		}
		else
		{
			if (Direction.Normalize())
			{
				const float LeftDistance = FMath::Max(PathMaxLength - AccumulatedDistance, 1.0);
				CutPoints.Add(LastPos + LeftDistance * Direction);
			}
			break;
		}
		AccumulatedDistance += Distance;
	}
}


void UTrackSplineComponent::DoUpdateTrack(TArray<FVector> &Points)
{
	if (Points.IsEmpty())
	{
		return;
	}
	
	TArray<FVector> CutPoints;
	TryCutPath(Points, CutPoints);
	ClearSplinePoints(false);
	SetWorldLocation(CutPoints[0], false, nullptr, TeleportFlagToEnum(false));
	for (FVector &PathPoint: CutPoints)
	{
		AddSplinePoint(PathPoint, ESplineCoordinateSpace::World, false);
	}
	UpdateSpline();
	CacheCurPath(Points);
	
}

