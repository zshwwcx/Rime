#include "3C/Core/AttachFloatComponent.h"

#include "3C/Animation/BaseAnimInstance.h"
#include "Components/SkeletalMeshComponent.h"



UAttachFloatComponent::UAttachFloatComponent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryComponentTick.bCanEverTick = true;
}


void UAttachFloatComponent::OnRegister()
{
	Super::OnRegister();
	
	
}

void UAttachFloatComponent::PostLoad()
{
	Super::PostLoad();
}

void UAttachFloatComponent::TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAttachJointComponent_TickComponent");
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);



	CurTime = CurTime+ DeltaTime;
	if (CurTime > FloatTime )
	{
		CurTime = CurTime - FloatTime;
		bCurIsUpward = !bCurIsUpward;
	}
	
	float CurZDelta = FMath::InterpEaseInOut(bCurIsUpward ? OriginLoc.Z : OriginLoc.Z + MaxDeltaHeight,
										bCurIsUpward ? OriginLoc.Z + MaxDeltaHeight : OriginLoc.Z,
										CurTime/FloatTime, EaseExp);

	SetRelativeLocation(OriginLoc + FVector(0,0,CurZDelta) );

}
