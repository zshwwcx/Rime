#include "3C/Core/KGUEActorLoader.h"
#include "Misc/LowLevelFunctions.h"
#include "Engine/AssetManager.h"
#include "Engine/StreamableManager.h"
#include "3C/Core/KGUEActorManager.h"

UE_DISABLE_OPTIMIZATION_SHIP

DEFINE_LOG_CATEGORY_STATIC(KGUEActorLoaderLog, Log, All);


UKGUEActorLoader::UKGUEActorLoader()
{
}

void UKGUEActorLoader::Init(UKGUEActorManager* InManager)
{
	ActorManager = InManager;
}

void UKGUEActorLoader::AddLoadTask(KGEntityID EntID, const FString& ClassPath, const FTransform& Transform,
	bool Preload, bool SyncLoad)
{
	int32 ClassType = GetClassType(ClassPath);

	UEActorLoadData& NewBuildTaskData = GetFreeBuildTaskData();
	NewBuildTaskData.ClassType = ClassType;
	NewBuildTaskData.bAddToActorPool = Preload;
	NewBuildTaskData.bSyncLoad = SyncLoad;
	NewBuildTaskData.Transform = Transform;
	NewBuildTaskData.EntityID = EntID;

	ActorLoadClassQueue.Push(NewBuildTaskData.BuildTaskID);
	if (SyncLoad) {
		Tick(0.0f);
	}
}

void UKGUEActorLoader::Tick(float DeltaTime)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGUEActorManager_Tick");

	if(bEnableFrameLimit)
	{
		ProcessClassLoadingQueue(DeltaTime);
		ProcessActorSpawningQueue(DeltaTime);
	}
	else
	{
		for (int32 Index(ActorLoadClassQueue.Num() - 1); Index >= 0; --Index) {
			if (UEActorLoadData* LoadData = ActorLoadDataMap.Find(ActorLoadClassQueue[Index])) {
				LoadClassAsset(*LoadData);
			}
			ActorLoadClassQueue.RemoveAt(Index);
		}

		for (int32 Index(ActorSpawnQueue.Num() - 1); Index >= 0; --Index) {
			CurActorSpawnQueue.Add(ActorSpawnQueue[Index]);
			ActorSpawnQueue.RemoveAt(Index);
		}

		if (CurActorSpawnQueue.Num() > 0) {
			for (int32 Index(CurActorSpawnQueue.Num() - 1); Index >= 0; --Index) { SpawnActor(CurActorSpawnQueue[Index]); }
			CurActorSpawnQueue.Reset();
		}
	}
}

void UKGUEActorLoader::ProcessClassLoadingQueue(float DeltaTime)
{
	if(ActorLoadClassQueue.Num()==0)
	{
		return;
	}
	
	const float MaxTimePerFrame = ClassLoadTimeBudgetPerFrame > 0 ? ClassLoadTimeBudgetPerFrame : 0.016f;
	const double StartTime = FPlatformTime::Seconds();
    
	while (ActorLoadClassQueue.Num() > 0)
	{
		if (UEActorLoadData* LoadData = ActorLoadDataMap.Find(ActorLoadClassQueue[0]))
		{
			LoadClassAsset(*LoadData);
		}
		ActorLoadClassQueue.RemoveAt(0);
		
		if ((FPlatformTime::Seconds() - StartTime) >= MaxTimePerFrame)
		{
			break;
		}
	}
}

void UKGUEActorLoader::ProcessActorSpawningQueue(float DeltaTime)
{
	const int32 ItemsToMove = FMath::Min(
		ActorSpawnQueue.Num(),
		MaxActorsToSpawnPerFrame > 0 ? MaxActorsToSpawnPerFrame : INT_MAX
	);

	if(ItemsToMove>0)
	{
		for (int32 i = 0; i < ItemsToMove; ++i)
		{
			CurActorSpawnQueue.Add(ActorSpawnQueue[i]);
		}
		ActorSpawnQueue.RemoveAt(0, ItemsToMove);
	}

	if(CurActorSpawnQueue.Num()==0)
	{
		return;
	}
	
	const float MaxTimePerFrame = SpawnTimeBudgetPerFrame > 0 ? SpawnTimeBudgetPerFrame : 0.016f;
	const double StartTime = FPlatformTime::Seconds();

	int Count = 0;
	while (CurActorSpawnQueue.Num() > 0)
	{
		const KGActorBuildID TaskID = CurActorSpawnQueue[0];
		CurActorSpawnQueue.RemoveAt(0);
        
		SpawnActor(TaskID);
		Count++;
		
		if (Count >= MinActorsToSpawnPerFrame && 
			(FPlatformTime::Seconds() - StartTime) >= MaxTimePerFrame)
		{
			break;
		}
	}
}

void UKGUEActorLoader::ClearClassMap()
{
	ActorLoadClassQueue.Empty();
	ActorSpawnQueue.Empty();
	CurActorSpawnQueue.Empty();
	ClassMap.Empty();
	for (TMap<KGActorBuildID, UEActorLoadData>::TIterator MapIt = ActorLoadDataMap.CreateIterator(); MapIt; ++MapIt) {
		if (!MapIt.Value().bFree) {
			KGActorBuildID BuildTaskID  = MapIt.Value().BuildTaskID;
			RemoveBuildTask(BuildTaskID);
		}
	}
}

void UKGUEActorLoader::CancelLoadTask(KGEntityID EntityID)
{
	for (TMap<KGActorBuildID, UEActorLoadData>::TIterator MapIt = ActorLoadDataMap.CreateIterator(); MapIt; ++MapIt) {
		if (!MapIt.Value().bFree && MapIt.Value().EntityID == EntityID) {
			KGActorBuildID BuildTaskID  = MapIt.Value().BuildTaskID;
			RemoveBuildTask(BuildTaskID);
			ActorLoadClassQueue.Remove(BuildTaskID);
			ActorSpawnQueue.Remove(BuildTaskID);
			CurActorSpawnQueue.Remove(BuildTaskID);
		}
	}
}

void UKGUEActorLoader::RemoveBuildTask(KGActorBuildID BuildTaskID) 
{ 
	if (UEActorLoadData* TaskLoadData = ActorLoadDataMap.Find(BuildTaskID)) {
		if (TaskLoadData->LoadHandle.IsValid()) {
			TaskLoadData->LoadHandle.Pin()->CancelHandle();
		}

		if (!TaskLoadData->bFree) {
			ActorBuildFreeIDs.Push(BuildTaskID);
			TaskLoadData->LoadHandle = nullptr;
			TaskLoadData->bFree = true;
		}
	}
}

UEActorLoadData& UKGUEActorLoader::GetFreeBuildTaskData()
{
	if (ActorBuildFreeIDs.Num() > 0) {
		KGActorBuildID FreeID = ActorBuildFreeIDs.Pop();
		if (UEActorLoadData* TaskLoadData = ActorLoadDataMap.Find(FreeID)) {
			TaskLoadData->bFree = false;
			return *TaskLoadData;
		}
	}

	int64 NewTaskID = ULowLevelFunctions::GetGlobalUniqueID();
	UEActorLoadData& NewLoadData = ActorLoadDataMap.FindOrAdd(NewTaskID);
	NewLoadData.BuildTaskID = NewTaskID;

	return NewLoadData;
}

const UEActorLoadData* UKGUEActorLoader::GetBuildTaskData(KGActorBuildID BuildTaskID)
{
	if (const UEActorLoadData* LoadData = ActorLoadDataMap.Find(BuildTaskID)) {
		if (LoadData->bFree) {
			return nullptr;
		}

		return LoadData;
	}

	return nullptr;
}

KGActorClassType UKGUEActorLoader::GetClassType(const FString& ClassPath)
{
	if (KGActorClassType* ID = ClassTypeMap.Find(ClassPath)) {
		return *ID;
	}

	KGActorClassType NewID = static_cast<KGActorClassType>(GetTypeHash(ClassPath));
	ClassTypeMap.Add(ClassPath, NewID);

	FString ClassRealPath = FString::Format(TEXT("Blueprint'{0}'"), { ClassPath });

	ClassPathMap.Add(NewID, ClassRealPath);
	return NewID;
}

const FString* UKGUEActorLoader::GetClassPath(KGActorClassType ClassType) { return ClassPathMap.Find(ClassType); }

UClass* UKGUEActorLoader::GetClassFromType(KGActorClassType ClassType)
{
	if (UClass** ClassPtr = ClassMap.Find(ClassType)) {
		return *ClassPtr;
	}

	return nullptr;
}

void UKGUEActorLoader::LoadClassAsset(UEActorLoadData& LoadData)
{
	if (const UClass* ActorClass = GetClassFromType(LoadData.ClassType)) {
		AddSpawnQueue(LoadData.BuildTaskID);
	}
	else {
		if (const FString* ClassPath = GetClassPath(LoadData.ClassType)) {
			FStreamableManager& Streamable = UAssetManager::GetStreamableManager();
			FSoftObjectPath ClassObjPath(*ClassPath);

			if (LoadData.bSyncLoad) {
				Streamable.RequestSyncLoad(ClassObjPath);
				OnClassAssetLoaded(ClassObjPath, LoadData.BuildTaskID);
			}
			else {
				LoadData.LoadHandle = Streamable.RequestAsyncLoad(
					ClassObjPath, FStreamableDelegate::CreateUObject(this, &UKGUEActorLoader::OnClassAssetLoaded,
						ClassObjPath, LoadData.BuildTaskID));
			}
		}
	}
}

void UKGUEActorLoader::OnClassAssetLoaded(FSoftObjectPath ClassObjPath, KGActorBuildID BuildTaskID)
{
	const UEActorLoadData* LoadData = GetBuildTaskData(BuildTaskID);
	if (!LoadData)
		return;

	FSoftObjectPtr SoftObj(ClassObjPath);

	UClass* Class(nullptr);
	if (UObject* Obj = SoftObj.Get()) {
		Class = Cast<UClass>(Obj);
	}

	if (Class == nullptr) {
		// 走到这里说明有问题，加个日志提醒一下业务
		const FString ClassPathStr = ClassObjPath.IsValid() ? ClassObjPath.ToString() : TEXT("<Invalid Path>");
		UE_LOG(KGUEActorLoaderLog, Warning, TEXT("[UKGUEActorManager::OnClassAssetLoaded] Cannot find UClass: %s, please check path valid!!!"), *ClassPathStr);

		RemoveBuildTask(BuildTaskID);
		return;
	}

	if (!ClassMap.Find(LoadData->ClassType)) {
		ClassMap.Add(LoadData->ClassType, Class);
	}

	AddSpawnQueue(BuildTaskID);
}

void UKGUEActorLoader::AddSpawnQueue(KGActorBuildID BuildTaskID)
{
	ActorSpawnQueue.Push(BuildTaskID);
}

class UWorld* UKGUEActorLoader::GetSpawnActorWorld()
{
	if (!ActorManager.IsValid()) {
		return nullptr;
	}

	return ActorManager->GetSpawnActorWorld();
}

void UKGUEActorLoader::SpawnActor(KGActorBuildID BuildTaskID)
{
	const UEActorLoadData* LoadData = GetBuildTaskData(BuildTaskID);
	if (!LoadData) {
		return;
	}

	UClass* Class = GetClassFromType(LoadData->ClassType);
	if (!Class) {
		UE_LOG(KGUEActorLoaderLog, Error, TEXT("[UKGUEActorManager::SpawnActor]  can not find UClass:%d EntityID:%d" ), LoadData->ClassType, LoadData->EntityID);
		RemoveBuildTask(BuildTaskID);
		return;
	}

	if (!IsValid(Class)) {
		UE_LOG(KGUEActorLoaderLog, Error, TEXT("[UKGUEActorManager::SpawnActor]  UClass is invalid UClass:%d EntityID:%d" ), LoadData->ClassType, LoadData->EntityID);
		RemoveBuildTask(BuildTaskID);
		return;
	}

	UWorld* World = GetSpawnActorWorld();
	if (World == nullptr || IsValid(World) == false)
	{
		UE_LOG(KGUEActorLoaderLog, Warning, TEXT("KGSpawnActor InWorld is invalid UClass:%d EntityID:%d" ), LoadData->ClassType, LoadData->EntityID);
		RemoveBuildTask(BuildTaskID);
		return;
	}

	if (!ActorManager.IsValid()) {
		UE_LOG(KGUEActorLoaderLog, Warning, TEXT("KGSpawnActor KGActorManager is invalid UClass:%d EntityID:%d" ), LoadData->ClassType, LoadData->EntityID);
		RemoveBuildTask(BuildTaskID);
		return;
	}

	SCOPED_NAMED_EVENT_FSTRING(FString::Printf(TEXT("UKGUEActorLoader_SpawnActor_%s"), *Class->GetName()), FColor::Red);

	KGEntityID EntID = LoadData->EntityID;
	FVector Loca = LoadData->Transform.GetLocation();
	FRotator Rot(LoadData->Transform.GetRotation());
	AActor* NewActor = World->SpawnActor(Class, &Loca, &Rot, ActorManager->GetActorSpawnParameters());
	RemoveBuildTask(BuildTaskID);

	ActorManager->OnActorLoaded(EntID, NewActor);
}

UE_ENABLE_OPTIMIZATION_SHIP