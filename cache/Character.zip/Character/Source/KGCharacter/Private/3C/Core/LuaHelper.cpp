#include "3C/Core/LuaHelper.h"
#include "Kismet/KismetSystemLibrary.h"

//#include "LuaCore.h"
//#include "UnLua.h"
//#include "LuaDynamicBinding.h"
#include "3C/Character/BaseCharacter.h"
#include "Components/MeshComponent.h"
#include "Engine/SkeletalMesh.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/GameModeBase.h"
#include "Engine/GameInstance.h"
#include "Engine/World.h"

UObject* ULuaHelper::NewObjectWithBindLua(UClass* Class, UObject* Outer, const FString& LuaPath, FName Name/* = NAME_None*/)
{
	/*
	* TODO: 支持升级slua add by sk
	lua_State* L = UnLua::GetState();
	if (!L)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s: Invalid lua_State!"), ANSI_TO_TCHAR(__FUNCTION__));
		return nullptr;
	}
	if (!Class)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s: Invalid class!"), ANSI_TO_TCHAR(__FUNCTION__));
		return 0;
	}

	if (!Outer)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s: Invalid outer!"), ANSI_TO_TCHAR(__FUNCTION__));
		return 0;
	}

	int32 TableRef = INDEX_NONE;
	FScopedLuaDynamicBinding Binding(L, Class, *LuaPath, TableRef);
#if ENGINE_MAJOR_VERSION <= 4 && ENGINE_MINOR_VERSION < 26
	UObject* Object = StaticConstructObject_Internal(Class, Outer, Name);
#else
	FStaticConstructObjectParameters ObjParams(Class);
	ObjParams.Outer = Outer;
	ObjParams.Name = Name;
	UObject* Object = StaticConstructObject_Internal(ObjParams);
#endif

	if (!Object)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s: Invalid outer!"), ANSI_TO_TCHAR(__FUNCTION__));
	}
		
	return Object;
	*/
	return nullptr;
}

AActor* ULuaHelper::GetActorByID(int32 UniqueID)
{
	if (UniqueID < 0)
	{
		return nullptr;
	}

	UObjectBase* FoundObj = FIndexToObject::IndexToObject(UniqueID, false);
	if (FoundObj)
	{
		if (UObject* CastedObj = static_cast<UObject*>(FoundObj))
		{
			AActor* CastedActor = Cast<AActor>(CastedObj);

			return CastedActor;
		}
	}

	return nullptr;
}


FString ULuaHelper::GetNewEntityGUID()
{
	return FGuid::NewGuid().ToString();
}

bool ULuaHelper::GetFloorPos(FVector StartPos, FVector EndPos, FVector& OutPos, const UObject* WorldContextObject)
{
	if (!UKismetSystemLibrary::IsValid(WorldContextObject))
		return false;

	TArray<AActor*> IgnoredActors;
	TArray<FHitResult> OutHits;

	if (bool bHit = UKismetSystemLibrary::LineTraceMulti(WorldContextObject, StartPos, EndPos,
	                                                     ETraceTypeQuery::TraceTypeQuery1, false, IgnoredActors,
	                                                     EDrawDebugTrace::Type::None, OutHits, true))
	{
		const auto& Elem = OutHits.Last();
		if (Elem.HitObjectHandle.FetchActor()
			&& (Elem.HitObjectHandle.FetchActor()->IsA<ABaseCharacter>()))
		{
			return false;
		}

		OutPos = Elem.ImpactPoint;
		return true;
	}

	return false;
}

bool ULuaHelper::GetFloorPosByCapsule(FVector StartPos, FVector EndPos, float Radius, TArray<AActor*>& IgnoreActors,
                                      FVector& OutPos, const UObject* WorldContextObject)
{
	if (!UKismetSystemLibrary::IsValid(WorldContextObject))
		return false;

	TArray<FHitResult> OutHits;

	if (bool bHit = UKismetSystemLibrary::SphereTraceMulti(WorldContextObject, StartPos, EndPos, Radius,
	                                                       ETraceTypeQuery::TraceTypeQuery1, false, IgnoreActors,
	                                                       EDrawDebugTrace::Type::None, OutHits, true))
	{
		const auto& Elem = OutHits.Last();
		if (Elem.HitObjectHandle.FetchActor()
			&& (Elem.HitObjectHandle.FetchActor()->IsA<ABaseCharacter>()))
		{
			return false;
		}

		OutPos = Elem.ImpactPoint;
		return true;
	}
	return false;
}

void ULuaHelper::SetRootComponent(AActor* InActor, USceneComponent* RootCom)
{
	if (!UKismetSystemLibrary::IsValid(InActor) || !UKismetSystemLibrary::IsValid(RootCom))
		return;

	InActor->SetRootComponent(RootCom);
}


void ULuaHelper::ExPropertyDes(FProperty* Prop, const void* AddRess, TArray<FString>& InProps)
{
	FString PropName = Prop->GetName();
	FString PropValue;

	if (FStrProperty* StrProp = CastField<FStrProperty>(Prop))
	{
		FString* Str = (FString*)(AddRess);
		PropValue = *Str;
	}
	else if (FNameProperty* NameProp = CastField<FNameProperty>(Prop))
	{
		FName* Name = (FName*)(AddRess);
		PropValue = Name->ToString();
	}
	else if (FBoolProperty* BoolProp = CastField<FBoolProperty>(Prop))
	{
		bool* Value = (bool*)(AddRess);
		PropValue = FString::FromInt((int32)(*Value));
	}
	else if (FFloatProperty* FloatProp = CastField<FFloatProperty>(Prop))
	{
		float* Value = (float*)(AddRess);
		PropValue = FString::Format(TEXT("{0}"), { *Value });
	}
	else if (FDoubleProperty* DoubleProp = CastField<FDoubleProperty>(Prop))
	{
		double* Value = (double*)(AddRess);
		PropValue = FString::Format(TEXT("{0}"), { *Value });
	}
	else if (FEnumProperty* EnumProp = CastField<FEnumProperty>(Prop))
	{
		PropValue = EnumProp->GetFName().ToString();
	}
	else if (Prop->IsA<FByteProperty>())
	{
		FByteProperty* ByteP = CastField<FByteProperty>(Prop);
		if (ByteP)
		{
			if (ByteP->Enum)
			{
				int8* Value = (int8*)AddRess;
				PropValue = ByteP->Enum->GetDisplayNameTextByValue(*Value).ToString();
			}
		}
	}
	else if (FObjectProperty* ObjProp = CastField<FObjectProperty>(Prop))
	{
		UObject* Obj = (UObject*)(AddRess);
		ULuaHelper::ExUObjectValueStr(Obj, InProps);
	}
	else if (FStructProperty* StructProp = CastField<FStructProperty>(Prop))
	{
		if (Prop->GetCPPType() == "FVector")
		{
			FVector* Vector = (FVector*)(AddRess);
			PropValue = Vector->ToString();
		}
		else if (Prop->GetCPPType() == "FTransform")
		{
			FTransform* Trans = (FTransform*)(AddRess);
			PropValue = Trans->ToString();
		}
		else if (Prop->GetCPPType() == "FColor")
		{
			FColor* Color = (FColor*)AddRess;
			PropValue = Color->ToString();
		}
		else
		{
			ULuaHelper::ExStructValueStr(StructProp->Struct, AddRess, InProps);
		}
	}
	else if (FArrayProperty* ArrayProp = CastField<FArrayProperty>(Prop))
	{
		FScriptArrayHelper ArrayHelper(ArrayProp, AddRess);

		FProperty* ElemProp = ArrayProp->Inner;
		FObjectProperty* ObjectProp = CastField<FObjectProperty>(ElemProp);

		int32 ArrayNum = ArrayHelper.Num();
		for (int32 i = 0; i < ArrayNum; ++i)
		{
			void* PropAddress = ArrayHelper.GetRawPtr(i);
			if (ObjectProp)
			{
				PropAddress = ObjectProp->GetObjectPropertyValue(PropAddress);
			}

			ULuaHelper::ExPropertyDes(ElemProp, PropAddress, InProps);
		}
	}
	else if (FMapProperty* MapProp = CastField<FMapProperty>(Prop))
	{
		FScriptMapHelper MapHelper(MapProp, AddRess);

		FProperty* KeyProp = MapHelper.GetKeyProperty();
		FProperty* ValueProp = MapHelper.GetValueProperty();
		FObjectProperty* ObjectProp = CastField<FObjectProperty>(ValueProp);
		int32 MapNum = MapHelper.Num();
		for (int32 i = 0; i < MapNum; ++i)
		{
			if (!MapHelper.IsValidIndex(i))
			{
				continue;
			}

			void* KeyAddress = MapHelper.GetKeyPtr(i);
			FString Key;
			if (FStrProperty* KeyFStr = CastField<FStrProperty>(KeyProp))
			{
				Key = *(FString*)(KeyAddress);
			}
			if (FNameProperty* KeyFName = CastField<FNameProperty>(KeyProp))
			{
				Key = ((FName*)KeyAddress)->ToString();
			}
			if (FIntProperty* KeyInt32 = CastField<FIntProperty>(KeyProp))
			{
				int32* IntKey = (int32*)(KeyAddress);
				Key = FString::FromInt(*IntKey);
			}

			void* ValueAddress = MapHelper.GetValuePtr(i);

			if (ObjectProp)
			{
				ValueAddress = ObjectProp->GetObjectPropertyValue(ValueAddress);
			}

			if (!Key.IsEmpty())
			{
				ULuaHelper::ExPropertyDes(ValueProp, ValueAddress, InProps);
			}
		}

	}

	FString Des = PropName;
	Des.Append(FString(": "));
	Des.Append(PropValue);
	InProps.Push(Des);
}

void ULuaHelper::ExStructValueStr(UScriptStruct* Struct, const void* AddRess, TArray<FString>& InProps)
{
	if (!Struct)
		return ;

	for (TFieldIterator<FProperty> PropIt(Struct); PropIt; ++PropIt)
	{
		const void* PropAddress = (*PropIt)->ContainerPtrToValuePtr<void>(AddRess);
		if (FObjectProperty* ObjProp = CastField<FObjectProperty>((*PropIt)))
		{
			UObject* Object = ObjProp->GetObjectPropertyValue(PropAddress);
			ULuaHelper::ExUObjectValueStr(Object, InProps);
		}
		else
		{
			ULuaHelper::ExPropertyDes(*PropIt, PropAddress, InProps);
		}
	}
}


void ULuaHelper::ExUObjectValueStr(UObject* InObj, TArray<FString>& InProps)
{
	if (!InObj)
		return ;

	UClass* Class = InObj->GetClass();

	for (TFieldIterator<FProperty> PropIt(Class); PropIt; ++PropIt)
	{
		const void* PropAddress = (*PropIt)->ContainerPtrToValuePtr<void>(InObj);
		if (FObjectProperty* ObjProp = CastField<FObjectProperty>((*PropIt)))
		{
			UObject* Object = ObjProp->GetObjectPropertyValue(PropAddress);
			if (Object)
			{
				ULuaHelper::ExUObjectValueStr(Object, InProps);
			}
		}
		else
		{
			ULuaHelper::ExPropertyDes(*PropIt, PropAddress, InProps);
		}
	}
}

FString ULuaHelper::GetUObjectValueStr(UObject* InObj)
{
	if (!InObj)
		return "";

	TArray<FString> InProps;
	ULuaHelper::ExUObjectValueStr(InObj, InProps);

	FString Result;
	for (auto& Elem : InProps)
	{
		Result.Append(Elem);
		Result.Append("\r\n");
	} 

	return Result;
}

void ULuaHelper::RegisterComponent(UActorComponent* InCom)
{
	if(InCom)
		InCom->RegisterComponent();
}

void ULuaHelper::UnregisterComponent(UActorComponent* InCom)
{
	if(InCom)
		InCom->UnregisterComponent();
}

void ULuaHelper::MarkMeshRenderStateDirty(class UMeshComponent* InCom)
{
	if (InCom)
	{
		InCom->MarkRenderStateDirty();
	}
}

void ULuaHelper::SetActorComponentTickEnabled(AActor* InActor, TSubclassOf<UActorComponent> Class, bool bEnable)
{
	if(!UKismetSystemLibrary::IsValid(InActor))
		return ;

	TArray<UActorComponent*> ActorList = InActor->K2_GetComponentsByClass(Class);
	for (auto& Elem : ActorList)
	{
		Elem->SetComponentTickEnabled(bEnable);
	}
}

void ULuaHelper::DestoryChildComponent(USceneComponent* InParentCom, TSubclassOf<USceneComponent> FilterClass)
{
	if (!UKismetSystemLibrary::IsValid(InParentCom))
		return;
	


	TArray<USceneComponent*> ActorList;
	InParentCom->GetChildrenComponents(false, ActorList);
	for (auto& Elem : ActorList)
	{
		if (Elem->IsA(FilterClass))
		{
			Elem->K2_DestroyComponent(Elem);
		}
	}
}

void ULuaHelper::ActorTagsAddUnique(AActor* InActor, FName InTag)
{
	if (UKismetSystemLibrary::IsValid(InActor))
	{
		InActor->Tags.AddUnique(InTag);
	}
}

void ULuaHelper::ActorTagsRemoveItem(AActor* InActor, FName InTag)
{
	if (UKismetSystemLibrary::IsValid(InActor))
	{
		InActor->Tags.Remove(InTag);
	}
}




void ULuaHelper::SetMeshPositiveBoundsExtension(USkeletalMesh* InMesh, FVector NewPositiveBoundsExtension)
{
	if (InMesh)
	{
		InMesh->SetPositiveBoundsExtension(NewPositiveBoundsExtension);
	}
}

void ULuaHelper::SetMeshNegativeBoundsExtension(USkeletalMesh* InMesh, FVector NewPositiveBoundsExtension)
{
	if (InMesh)
	{
		InMesh->SetNegativeBoundsExtension(NewPositiveBoundsExtension);
	}
}


FString ULuaHelper::GetObjectUClassName(UObject* Object)
{
	if( Object == NULL )
	{
		return TEXT("None");
	}
	if (UClass *ObjectClass = Object->GetClass())
	{
		return ObjectClass->GetName();
	}
	return TEXT("None");
}

void ULuaHelper::SetSceneComponentVisibleFlag(USceneComponent* InCom, bool bVisible)
{
	if (InCom)
	{
		InCom->SetVisibleFlag(bVisible);
	}
}

void ULuaHelper::SetPlayerControllerClass(UGameInstance* InGI, TSubclassOf<class APlayerController> InClass, TSubclassOf<class APawn> InPawn)
{
	if(!InGI)
		return ;

	if (UWorld* World = InGI->GetWorld())
	{
		AGameModeBase* _GameMode = UGameplayStatics::GetGameMode(World);
		_GameMode->PlayerControllerClass = InClass;
		_GameMode->DefaultPawnClass = InPawn;
	}
}
