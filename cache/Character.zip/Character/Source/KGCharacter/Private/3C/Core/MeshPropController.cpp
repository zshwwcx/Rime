#include "3C/Core/MeshPropController.h"

#include "3C/Core/C7ActorInterface.h"
#include "3C/Material/KGMaterialCommon.h"
#include "3C/Core/KGUEActorManager.h"
#include "3C/Util/KGUtils.h"
#include "TimerManager.h"
#include "Components/MeshComponent.h"
#include "3C/Effect/KGEffectManager.h"
#include "GameFramework/Actor.h"

static uint32 InnerSequenceID = 0;

void FKGCustomDepthPriorityQueue::BindActor(AActor* InActor, ICppEntityInterface* InBindEntity)
{
	Actor = InActor;
	BindEntity = InBindEntity;
	ActorID = KGUtils::GetIDByObject(InActor);

	if (InActor)
	{
		BindWorld = InActor->GetWorld();
	}
	
	if (InActor && Items.Num() > 0)
	{
		UE_LOG(LogKGMaterial, Log, TEXT("FKGCustomDepthPriorityQueue::BindActor, refresh mesh props on bind actor"));
		RefreshMeshOriginalCustomDepthInfo();
		check(Items.Num() > 0);
		RefreshMeshCustomDepthInfo(Items[0].CustomDepthInfo);

		for (const auto& Item : Items)
		{
			if (Item.bAutoRevert)
			{
				AddAutoRevertTimer(Item.LogicType, Item.AutoRevertTimeSeconds);
			}
		}
	}
}

void FKGCustomDepthPriorityQueue::UnBindActor()
{
	if (Items.Num() == 0)
	{
		return;
	}
	
	if (AutoRevertTimerHandles.Num() > 0)
	{
		TArray<int32> LogicTypes;
		AutoRevertTimerHandles.GenerateKeyArray(LogicTypes);

		for (const auto LogicType : LogicTypes)
		{
			ClearAutoRevertTimer(LogicType);
		}	
	}
	
	Items.Empty();
	RevertMeshCustomDepthInfo();
}

void FKGCustomDepthPriorityQueue::SetCustomDepthInfo(
	int32 LogicType, int32 Priority, bool bRenderCustomDepth, int32 CustomDepthStencilValue, bool bNiagaraRenderCustomDepth,
	bool bAutoRevert, float AutoRevertTimeSeconds, bool bInherited)
{
	UE_LOG(LogKGMaterial, Log, TEXT("FKGCustomDepthPriorityQueue::SetCustomDepthInfo, %s, %d, %d, %d, %d"),
		*GetNameSafe(Actor.Get()), LogicType, bRenderCustomDepth, CustomDepthStencilValue, bNiagaraRenderCustomDepth);

	if (bAutoRevert)
	{
		if (FMath::IsNearlyZero(AutoRevertTimeSeconds))
		{
			UE_LOG(LogKGMaterial, Error, TEXT("FKGCustomDepthPriorityQueue::SetCustomDepthInfo, invalid auto revert time, %s, %d"), 
				*GetNameSafe(Actor.Get()), LogicType);
		}
		else
		{
			AddAutoRevertTimer(LogicType, AutoRevertTimeSeconds);
		}
	}
	
	for (int32 i = 0; i < Items.Num(); ++i)
	{
		if (Items[i].LogicType == LogicType)
		{
			UE_LOG(LogKGMaterial, Log, TEXT("FKGCustomDepthPriorityQueue::SetCustomDepthInfo, found existing item, %s, %d, %d, %d, %d"),
				*GetNameSafe(Actor.Get()), LogicType,
				Items[i].CustomDepthInfo.bRenderCustomDepth,
				Items[i].CustomDepthInfo.CustomDepthStencilValue,
				Items[i].CustomDepthInfo.bNiagaraRenderCustomDepth);
			RemoveCustomDepthInfo(LogicType);
			break;
		}
	}
	
	if (Items.Num() == 0)
	{
		RefreshMeshOriginalCustomDepthInfo();
	}

	int32 OldActiveCustomDepthInfo = GetActiveLogicType();
	
	FKGCustomDepthPriorityItem NewItem(
		bRenderCustomDepth, CustomDepthStencilValue, bNiagaraRenderCustomDepth, LogicType, Priority,
		KGMaterialUtils::GenerateIncId(InnerSequenceID), bAutoRevert, AutoRevertTimeSeconds, bInherited);
	Items.HeapPush(NewItem);

	int32 NewActiveCustomDepthInfo = GetActiveLogicType();
	if (OldActiveCustomDepthInfo != NewActiveCustomDepthInfo)
	{
		check(Items.Num() > 0);
		RefreshMeshCustomDepthInfo(Items[0].CustomDepthInfo);
	}

	if (!bInherited)
	{
		RefreshAttachEntityCustomDepthInfo();	
	}
}

void FKGCustomDepthPriorityQueue::RemoveCustomDepthInfo(int32 LogicType)
{
	UE_LOG(LogKGMaterial, Log, TEXT("FKGCustomDepthPriorityQueue::RemoveCustomDepthInfo, %s, %d"),
		*GetNameSafe(Actor.Get()), LogicType);
	
	if (Items.Num() == 0)
	{
		return;
	}

	ClearAutoRevertTimer(LogicType);

	bool bIsInherited = false;
	int32 OldActiveCustomDepthInfo = GetActiveLogicType();
	for (int32 i = 0; i < Items.Num(); ++i)
	{
		if (Items[i].LogicType == LogicType)
		{
			bIsInherited = Items[i].bInherited;
			Items.HeapRemoveAt(i);
			break;
		}
	}

	int32 NewActiveCustomDepthInfo = GetActiveLogicType();
	if (OldActiveCustomDepthInfo != NewActiveCustomDepthInfo)
	{
		if (NewActiveCustomDepthInfo != KG_INVALID_CUSTOM_DEPTH_PRIORITY_TYPE)
		{
			RefreshMeshCustomDepthInfo(Items[0].CustomDepthInfo);
		}
		else
		{
			RevertMeshCustomDepthInfo();
		}
	}

	if (!bIsInherited)
	{
		RefreshAttachEntityCustomDepthInfo();	
	}
}

void FKGCustomDepthPriorityQueue::RefreshMeshCustomDepthInfo(const FKGCustomDepthInfo& CustomDepthInfo)
{
	UE_LOG(LogKGMaterial, Log, TEXT("FKGCustomDepthPriorityQueue::RefreshMeshCustomDepthInfo, refresh mesh custom depth info, %s, %d, %d, %d"), 
		*GetNameSafe(Actor.Get()), CustomDepthInfo.bRenderCustomDepth, CustomDepthInfo.CustomDepthStencilValue, CustomDepthInfo.bNiagaraRenderCustomDepth);

	if (!Actor.IsValid())
	{
		UE_LOG(LogKGMaterial, Log, TEXT("FKGCustomDepthPriorityQueue::RefreshMeshCustomDepthInfo, invalid bind actor"));
		return;
	}
	
	TArray<UMeshComponent*> MeshComponents;
	Actor->GetComponents(MeshComponents);

	for (const auto MeshComponent : MeshComponents)
	{
		MeshComponent->SetRenderCustomDepth(CustomDepthInfo.bRenderCustomDepth);
		MeshComponent->CustomDepthStencilValue = CustomDepthInfo.CustomDepthStencilValue;
	}

	if (UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(Actor.Get()))
	{
		if (CustomDepthInfo.bNiagaraRenderCustomDepth)
		{
			EffectManager->ForceSetNiagaraRenderCustomDepthBySpawnerId(
				ActorID, CustomDepthInfo.bNiagaraRenderCustomDepth, CustomDepthInfo.CustomDepthStencilValue);
		}
		else
		{
			EffectManager->RevertForceNiagaraCustomDepthControlBySpawnerId(ActorID);
		}
	}
}

void FKGCustomDepthPriorityQueue::RefreshMeshOriginalCustomDepthInfo()
{
	if (!Actor.IsValid())
	{
		UE_LOG(LogKGMaterial, Log, TEXT("FKGCustomDepthPriorityQueue::RefreshMeshOriginalCustomDepthInfo, invalid bind actor"));
		return;
	}

	UE_LOG(LogKGMaterial, Log, TEXT("FKGCustomDepthPriorityQueue::RefreshMeshOriginalCustomDepthInfo, %s"),
		*GetNameSafe(Actor.Get()));
	
	TArray<UMeshComponent*> MeshComponents;
	Actor->GetComponents(MeshComponents);

	OriginalCustomDepthInfo.Empty(MeshComponents.Num());
	
	for (const auto MeshComponent : MeshComponents)
	{
		if (!MeshComponent)
		{
			UE_LOG(LogKGMaterial, Error, TEXT("FKGCustomDepthPriorityQueue::RefreshMeshOriginalCustomDepthInfo, invalid mesh component, %s"), *Actor->GetName());
			continue;
		}

		FKGCustomDepthInfo MeshCustomDepthInfo(MeshComponent->bRenderCustomDepth, MeshComponent->CustomDepthStencilValue, false);
		OriginalCustomDepthInfo.Add(MeshComponent, MeshCustomDepthInfo);
	}
}

// 接口本身支持在 actor已经清理的情况下调用, 对应mesh component的render custom depth不做恢复此时也没有问题, 但是对应创建的特效因为有独立的生命周期, 所以还是需要恢复的
void FKGCustomDepthPriorityQueue::RevertMeshCustomDepthInfo()
{
	UE_LOG(LogKGMaterial, Log, TEXT("FKGCustomDepthPriorityQueue::RevertMeshCustomDepthInfo %s"), *GetNameSafe(Actor.Get()));
	
	for (auto& Kvp : OriginalCustomDepthInfo)
	{
		auto MeshComponent = Kvp.Key;
		if (!MeshComponent.IsValid())
		{
			continue;
		}

		MeshComponent->SetRenderCustomDepth(Kvp.Value.bRenderCustomDepth);
		MeshComponent->CustomDepthStencilValue = Kvp.Value.CustomDepthStencilValue;
	}
	OriginalCustomDepthInfo.Empty();

	if (Actor.IsValid())
	{
		if (UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(Actor.Get()))
		{
			// 所有特效默认都是不渲染深度的
			EffectManager->RevertForceNiagaraCustomDepthControlBySpawnerId(ActorID);
		}	
	}
}

void FKGCustomDepthPriorityQueue::RefreshOnMeshComponentChanged()
{
	// 没有任何控制的情况下无需刷新
	if (Items.Num() == 0 || !Actor.IsValid())
	{
		return;
	}

	UE_LOG(LogKGMaterial, Log, TEXT("FKGCustomDepthPriorityQueue::RefreshOnMeshComponentChanged, %s"), *GetNameSafe(Actor.Get()));
	
	// 先全部回退 然后全部应用一遍
	auto TempItems = Items;
	for (auto& TempItem : TempItems)
	{
		RemoveCustomDepthInfo(TempItem.LogicType);
	}

	for (auto& TempItem : TempItems)
	{
		SetCustomDepthInfo(
			TempItem.LogicType, TempItem.Priority, TempItem.CustomDepthInfo.bRenderCustomDepth, TempItem.CustomDepthInfo.CustomDepthStencilValue,
			TempItem.CustomDepthInfo.bNiagaraRenderCustomDepth, TempItem.bAutoRevert, TempItem.AutoRevertTimeSeconds);
	}
}

void FKGCustomDepthPriorityQueue::SyncCustomDepthInfo(const FKGCustomDepthPriorityQueue& OtherCustomDepthPriorityQueue)
{
	UE_LOG(LogKGMaterial, Log, TEXT("FKGCustomDepthPriorityQueue::SyncCustomDepthInfo, %s"), *GetNameSafe(Actor.Get()));

	// 同时会控制custom depth的业务数量很少, refresh先做全量的回退&重新应用处理
	auto TempItems = Items;
	for (auto& TempItem : TempItems)
	{
		if (TempItem.bInherited)
		{
			RemoveCustomDepthInfo(TempItem.LogicType);
		}
	}

	for (const auto& Info : OtherCustomDepthPriorityQueue.Items)
	{
		// 对于 inherited 的custom depth, 生命周期跟着parent走, 这里不独立设置auto revert timer
		SetCustomDepthInfo(
			Info.LogicType, Info.Priority, Info.CustomDepthInfo.bRenderCustomDepth, Info.CustomDepthInfo.CustomDepthStencilValue,
			Info.CustomDepthInfo.bNiagaraRenderCustomDepth, false, Info.AutoRevertTimeSeconds, true);
	}
}

void FKGCustomDepthPriorityQueue::RefreshAttachEntityCustomDepthInfo()
{
	UE_LOG(LogKGMaterial, Log, TEXT("FKGCustomDepthPriorityQueue::RefreshAttachEntityCustomDepthInfo, %s"), *GetNameSafe(Actor.Get()));
	
	if (BindEntity.IsValid())
	{
		BindEntity->SyncCustomDepthToAttachEntities();
	}
}

void FKGCustomDepthPriorityQueue::AddAutoRevertTimer(int32 LogicType, float AutoRevertTimeSeconds)
{
	UWorld* World = BindWorld.Get();
	if (!World)
	{
		UE_LOG(LogKGMaterial, Log, TEXT("FKGCustomDepthPriorityQueue::AddAutoRevertTimer: world is invalid."));
		return;
	}

	ClearAutoRevertTimer(LogicType);
	
	UE_LOG(LogKGMaterial, Log, TEXT("FKGCustomDepthPriorityQueue::AddAutoRevertTimer, %s, %d, %.2f"), 
		*GetNameSafe(Actor.Get()), LogicType, AutoRevertTimeSeconds);

	auto& NewTimer = AutoRevertTimerHandles.FindOrAdd(LogicType);
	World->GetTimerManager().SetTimer(
		NewTimer, FTimerDelegate::CreateRaw(this, &FKGCustomDepthPriorityQueue::OnAutoRevertTimeExpired, LogicType),
		AutoRevertTimeSeconds, false);
}

void FKGCustomDepthPriorityQueue::ClearAutoRevertTimer(int32 LogicType)
{
	UWorld* World = BindWorld.Get();
	if (!World)
	{
		UE_LOG(LogKGMaterial, Log, TEXT("FKGCustomDepthPriorityQueue::ClearAutoRevertTimer: world is invalid."));
		return;
	}

	UE_LOG(LogKGMaterial, Log, TEXT("FKGCustomDepthPriorityQueue::ClearAutoRevertTimer, %s, %d"), 
		*GetNameSafe(Actor.Get()), LogicType);
	
	if (AutoRevertTimerHandles.Contains(LogicType))
	{
		FTimerHandle& TimerHandle = AutoRevertTimerHandles[LogicType];
		if (TimerHandle.IsValid())
		{
			World->GetTimerManager().ClearTimer(TimerHandle);
		}
		AutoRevertTimerHandles.Remove(LogicType);
	}
}

void FKGCustomDepthPriorityQueue::OnAutoRevertTimeExpired(int32 LogicType)
{
	UE_LOG(LogKGMaterial, Log, TEXT("FKGCustomDepthPriorityQueue::OnAutoRevertTimeExpired, %s, %d"), 
		*GetNameSafe(Actor.Get()), LogicType);

	RemoveCustomDepthInfo(LogicType);
}


void FKGMeshPropController::OverrideCustomDepth(
	int32 LogicType, int32 Priority, bool bRenderCustomDepth, int32 CustomDepthStencilValue, bool bNiagaraRenderCustomDepth, bool bAutoRevert, float AutoRevertTimeSeconds)
{
	CustomDepthPriorityQueue.SetCustomDepthInfo(LogicType, Priority, bRenderCustomDepth, CustomDepthStencilValue, bNiagaraRenderCustomDepth, bAutoRevert, AutoRevertTimeSeconds);
}

void FKGMeshPropController::RevertCustomDepth(int32 LogicType)
{
	CustomDepthPriorityQueue.RemoveCustomDepthInfo(LogicType);
}

bool FKGMeshPropController::GetCurrentActiveCustomDepthInfo(bool& bOutRenderCustomDepth, int32& OutCustomDepthStencilValue, bool& bOutNiagaraRenderCustomDepth)
{
	if (CustomDepthPriorityQueue.Items.Num() == 0)
	{
		return false;
	}

	auto& DepthInfo = CustomDepthPriorityQueue.Items[0].CustomDepthInfo;
	bOutRenderCustomDepth = DepthInfo.bRenderCustomDepth;
	OutCustomDepthStencilValue = DepthInfo.CustomDepthStencilValue;
	bOutNiagaraRenderCustomDepth = DepthInfo.bNiagaraRenderCustomDepth;
	return true;
}

void FKGMeshPropController::SyncCustomDepthInfo(const FKGMeshPropController& OtherController)
{
	CustomDepthPriorityQueue.SyncCustomDepthInfo(OtherController.CustomDepthPriorityQueue);
}

void FKGMeshPropController::BindActor(AActor* InActor, ICppEntityInterface* InBindEntity)
{
	CustomDepthPriorityQueue.BindActor(InActor, InBindEntity);
}

void FKGMeshPropController::UnBindActor()
{
	CustomDepthPriorityQueue.UnBindActor();
}

void FKGMeshPropController::OnMeshComponentChanged()
{
	CustomDepthPriorityQueue.RefreshOnMeshComponentChanged();
}
