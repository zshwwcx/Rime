#include "3C/Core/AutoRotateComponent.h"

#include "GameFramework/Actor.h"
const FName UAutoRotateComponent::SocketName(TEXT("AttachJointEndpoint"));

UAutoRotateComponent::UAutoRotateComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UAutoRotateComponent::TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction *ThisTickFunction)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAutoRotateComponent_TickComponent");
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if(GetAttachChildren().Num() == 0)
	{
		return;
	}
	
	SocketRot.Yaw +=  RotateSpeed * DeltaTime ;
	SocketRot.Yaw = FMath::Fmod(SocketRot.Yaw , 360.f);
	UpdateChildTransforms();
};

bool UAutoRotateComponent::HasAnySockets() const
{
	return true;
}

void UAutoRotateComponent::QuerySupportedSockets(TArray<FComponentSocketDescription>& OutSockets) const
{
	new (OutSockets) FComponentSocketDescription(SocketName, EComponentSocketType::Socket);
}

FTransform UAutoRotateComponent::GetSocketTransform(FName InSocketName, ERelativeTransformSpace TransformSpace) const
{
	FTransform RelativeTransform(SocketRot, SocketLoc);

	switch(TransformSpace)
	{
	case RTS_World:
		{
			return RelativeTransform * GetComponentTransform();
			break;
		}
	case RTS_Actor:
		{
			if( const AActor* Actor = GetOwner() )
			{
				FTransform SocketTransform = RelativeTransform * GetComponentTransform();
				return SocketTransform.GetRelativeTransform(Actor->GetTransform());
			}
			break;
		}
	case RTS_Component:
		{
			return RelativeTransform;
		}
	}
	return RelativeTransform;
}
