// #pragma once

#include "3C/Core/AttachJointHelper.h"
#include "DrawDebugHelpers.h"
#include "Kismet/KismetSystemLibrary.h"



void AttachJointHelper::DoAutoRotate(const float& RotateRoundTime,const float& CurrenTime,FRotator& OutRotation)
{
	if ( RotateRoundTime > 0)
	{
		float Alpha = FMath::Fmod(CurrenTime,RotateRoundTime) / RotateRoundTime;
		OutRotation.Yaw += Alpha * 360;
	}
}

void AttachJointHelper::DoInterpLag(const FVector& DesiredLocation,const FVector& PreviousInterpLoc,
	const float& DeltaTime ,const float& AttachLagSpeed,const float& AttachLagMaxDistance,
										FVector& OutInterpLoc,	FVector& OutDesiredLocation)
{

	OutInterpLoc = FMath::VInterpTo(PreviousInterpLoc, DesiredLocation, DeltaTime, AttachLagSpeed);
	FVector Dist =  OutInterpLoc - DesiredLocation;
	if (Dist.Size() > AttachLagMaxDistance)
	{
		OutDesiredLocation = DesiredLocation  + Dist.GetSafeNormal() * AttachLagMaxDistance;
	}else
	{
		OutDesiredLocation = OutInterpLoc;
	}
}


void AttachJointHelper::DoBezierLag(const FVector& DesiredLocation,const FVector& PreviousDesiredLoc,const FRotator& PreviousDesiredRot, const float& DeltaTime ,const float& BezierStep,
	const float& BezierStepMaxDist,const float & BezierSpeedAlpha,const float& BezierLagSpeed, const float& BezierDirectionMultiplier,const float& LastSpeed ,const FVector LastVelocity,
								 const bool& bDoDebugDraw, const UWorld* DebugDrawWorld,	FVector& OutDesiredLocation)
{
	float TargetZ = FMath::FInterpTo(PreviousDesiredLoc.Z, DesiredLocation.Z, DeltaTime, BezierLagSpeed);
		
	FVector P0 = PreviousDesiredLoc;
	P0.Z = 0;
	FVector P2 = DesiredLocation;
	P2.Z = 0;
	FVector TargetDir = (P2 - P0);
	float Dist = FMath::Min(BezierStepMaxDist, TargetDir.Size()) * BezierDirectionMultiplier;
	FVector Dir;
	float V = LastSpeed;
	if (V > 0)
	{
		float DotResult = FVector::DotProduct(TargetDir.GetSafeNormal(),LastVelocity.GetSafeNormal());
		//方向系数，速度方向越朝向目的地，则alpha更高
		float Alpha = DotResult > 0 ? DotResult : 0;
		Alpha = FMath::Max(Alpha,0.1);

		//速度系数，速度越快则，alpha更高
		if ( BezierSpeedAlpha> 0)
		{
			Alpha *= FMath::Min(V, BezierSpeedAlpha) / BezierSpeedAlpha;
		}
		Dist = Dist * Alpha;

		//alpha越高 则P1点越接近速度方向，反之则越接近目标点方向
		Dir = LastVelocity.GetSafeNormal() * Alpha + TargetDir.GetSafeNormal() * (1 - Alpha);
	}
	else
	{
		Dir = PreviousDesiredRot.Vector();
	}
	FVector P1 = P0 + Dir * Dist;
	P1.Z = 0;
	float t = DeltaTime > 0 ? FMath::Clamp(BezierStep * DeltaTime,0,1) : 0;
	OutDesiredLocation = FMath::Pow(1 - t, 2) * P0 + 2 * t * (1 - t) * P1 + FMath::Pow(t, 2) * P2;
	OutDesiredLocation.Z = TargetZ;

#if !(UE_BUILD_SHIPPING || UE_BUILD_TEST)
	if (bDoDebugDraw)
	{
		DrawDebugSphere(DebugDrawWorld, P2 + FVector(0,0, PreviousDesiredLoc.Z), 3.f, 8, FColor::Blue);
		DrawDebugSphere(DebugDrawWorld, P1 + FVector(0,0, PreviousDesiredLoc.Z), 3.f, 8, FColor::Blue);
		DrawDebugSphere(DebugDrawWorld, P0 + FVector(0,0, PreviousDesiredLoc.Z), 3.f, 8, FColor::Blue);

		for (int i = 0; i <= 10; i++)
		{
			float t2 = (float)i / 10.f;
			FVector P = FMath::Pow(1 - t2, 2) * P0 + 2 * t2 * (1 - t2) * P1 + FMath::Pow(t2, 2) * P2;
			DrawDebugPoint(DebugDrawWorld, P + FVector(0,0, PreviousDesiredLoc.Z), 1.f, FColor::Cyan, false, DeltaTime);
		}
	}
			
#endif
}

void AttachJointHelper::DoRangeInterpLag(const FVector& DesiredLocation,const FVector& CenterLocation, const FVector& LastLagLocation,const float& DeltaTime,
	const float& InCircleLagSpeed,const float& InCircleLagTolerance,
	const bool& bDoDebugDraw, const UWorld* DebugDrawWorld,
	FVector& OutDesiredLocation)
{
	FVector OutLocation = FMath::VInterpTo(LastLagLocation, DesiredLocation, DeltaTime, InCircleLagSpeed);
	
	FVector TargetDir = OutLocation - CenterLocation;
	TargetDir.Z = 0;
	FVector ArmDir = DesiredLocation - CenterLocation;
	ArmDir.Z = 0;
	float ArmLen = ArmDir.Size() + InCircleLagTolerance;
#if !(UE_BUILD_SHIPPING || UE_BUILD_TEST)
	if (bDoDebugDraw)
	{
		DrawDebugCircle(DebugDrawWorld, CenterLocation,  ArmDir.Size(), 20,FColor::Yellow, false,
			-1.f, SDPG_World, 1, FVector::YAxisVector, FVector::XAxisVector, false);
		DrawDebugCircle(DebugDrawWorld, CenterLocation,  ArmLen , 20,FColor::Yellow, false,
			-1.f, SDPG_World, 1, FVector::YAxisVector, FVector::XAxisVector, false);
		DrawDebugSphere(DebugDrawWorld, DesiredLocation, 3.f, 8, FColor::Yellow);
	}
#endif

	if (TargetDir.Size() > (ArmLen))
	{
		OutLocation =  CenterLocation + (ArmLen) * TargetDir.GetSafeNormal() ;
		OutLocation.Z = DesiredLocation.Z;
	}
	OutDesiredLocation = OutLocation;
	
}


void AttachJointHelper::DoFloat(const FVector& DesiredLocation,  const float& CurrentTime,const float& FloatTime,
                                       const float& FloatMinHeight,const float& FloatMaxHeight, const float& FloatEaseExp, FVector& OutDesiredLocation)
{

	if (FloatTime > 0)
	{
		int Round = CurrentTime/FloatTime;
		bool bIsUpward = Round % 2 == 0;

		float RemainTime = FMath::Fmod(CurrentTime,FloatTime);
	
		float CurZDelta = FMath::InterpEaseInOut(
			bIsUpward ?  FloatMinHeight : FloatMaxHeight,
			bIsUpward ?  FloatMaxHeight : FloatMinHeight,
			RemainTime/FloatTime, FloatEaseExp);
		OutDesiredLocation = DesiredLocation;
		OutDesiredLocation.Z += CurZDelta;
	}
	else
	{
		OutDesiredLocation = DesiredLocation;
	}
}

void AttachJointHelper::DoRotationLag(const FRotator& DesiredRotation, const FRotator& PreviousDesiredRot, const float& DeltaTime, const float& AttachRotationLagSpeed,
	const bool& bClampPitch,const float& PitchClampAngleMin, const float& PitchClampAngleMax, FRotator& OutDesiredRotation)
{
	
	OutDesiredRotation = DesiredRotation;
	
	
	if (bClampPitch)
	{
		OutDesiredRotation.Pitch = FMath::Clamp(OutDesiredRotation.Pitch ,PitchClampAngleMin, PitchClampAngleMax);
	}
	OutDesiredRotation = FMath::RInterpTo(PreviousDesiredRot, OutDesiredRotation, DeltaTime, AttachRotationLagSpeed);
}

void AttachJointHelper::DoFaceToMoveDirRotationLag(const FRotator& DesiredRotation, const FRotator& PreviousDesiredRot,const float& LastSpeed,const FVector& LastVelocity,const float& DeltaTime,
	const float& AttachRotationLagSpeed,const float& FaceToMoveDirectionTolerance,const bool& bClampPitch,const float& PitchClampAngleMin, const float& PitchClampAngleMax, FRotator& OutDesiredRotation)
{
	OutDesiredRotation = DesiredRotation;
	if (LastSpeed > FaceToMoveDirectionTolerance)
	{
		OutDesiredRotation.Pitch = LastVelocity.Rotation().Pitch;
		// if (FMath::IsNearlyZero(LastVelocity.X, 0.01) && FMath::IsNearlyZero(LastVelocity.Y, 0.01))
		// {
		// 	OutDesiredRotation.Pitch = LastVelocity.Rotation().Pitch;
		// }
		// else
		// {
		// 	OutDesiredRotation = LastVelocity.Rotation();
		// }
	}
	
	DoRotationLag(OutDesiredRotation, PreviousDesiredRot, DeltaTime,AttachRotationLagSpeed,bClampPitch,PitchClampAngleMin,  PitchClampAngleMax, OutDesiredRotation);
}
