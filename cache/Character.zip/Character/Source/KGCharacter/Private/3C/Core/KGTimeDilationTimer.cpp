﻿#include "3C/Core/KGTimeDilationTimer.h"

#include "KGCharacterModule.h"
#include "Engine/World.h"
#include "GameFramework/Actor.h"

void FKGTimeDilationTimer::SetOwnerActor(TWeakObjectPtr<AActor> InOwnerActor)
{
	if (!InOwnerActor.IsValid())
	{
		UE_LOG(LogKGCombat, Error, TEXT("FKGTimeDilationTimer::SetOwnerActor, invalid InOwnerActor"));
		return;
	}
	
	OwnerActor = InOwnerActor;
	OwnerWorld = InOwnerActor->GetWorld();
}

void FKGTimeDilationTimer::InitOnceTimer(float InRateSeconds, const FTimerDelegate& InTimerDelegate, bool bUseTimerManager)
{
	if (!OwnerWorld.IsValid())
	{
		UE_LOG(LogKGCombat, Error, TEXT("FKGTimeDilationTimer::InitOnceTimer, invalid OwnerWorld"));
		return;
	}

	if (TimerState != EKGTimeDilationTimerState::UnInit)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("FKGTimeDilationTimer::InitOnceTimer, Timer already initialized"));
		return;
	}

	TimerDelegate = InTimerDelegate;
	TimerInitTimeSeconds = FPlatformTime::Seconds();

	if (bUseTimerManager)
	{
		if (FMath::IsNearlyZero(InRateSeconds))
		{
			UE_LOG(LogKGCombat, Error, TEXT("FKGTimeDilationTimer::InitOnceTimer, InRateSeconds is zero"));
		}
		else
		{
			TimerDelayTime = InRateSeconds;
			OwnerWorld->GetTimerManager().SetTimer(TimerHandle, InTimerDelegate, InRateSeconds, false);
			TimerState = EKGTimeDilationTimerState::UseTimerManager;
		}
	}
	else
	{
		TimerState = EKGTimeDilationTimerState::UseTimeDilationTick;
	}
}

void FKGTimeDilationTimer::ClearTimer()
{
	if (TimerState != EKGTimeDilationTimerState::UseTimerManager)
	{
		UE_LOG(LogKGCombat, Log, TEXT("FKGTimeDilationTimer::ClearTimer, no need to clear, TimerState: %d"), TimerState);
		return;
	}

	if (!OwnerWorld.IsValid())
	{
		UE_LOG(LogKGCombat, Error, TEXT("FKGTimeDilationTimer::ClearTimer, invalid OwnerWorld"));
		return;
	}

	OwnerWorld->GetTimerManager().ClearTimer(TimerHandle);
	TimerState = EKGTimeDilationTimerState::UnInit;
}

void FKGTimeDilationTimer::ChangeTimerMode(bool bUseTimeDilation)
{
	if (TimerState == EKGTimeDilationTimerState::UnInit)
	{
		return;
	}
	
	if (bUseTimeDilation && TimerState == EKGTimeDilationTimerState::UseTimerManager)
	{
		// 从TimerManager切换到TimeDilationTick
		ClearTimer();
		AccumulatedTimeSeconds = FPlatformTime::Seconds() - TimerInitTimeSeconds;
		UE_LOG(LogKGCombat, Log, TEXT("FKGTimeDilationTimer::ChangeTimerMode, switch to TimeDilationTick, AccumulatedTimeSeconds: %f, TimerDelayTime: %f"),
			AccumulatedTimeSeconds, TimerDelayTime);
		// 理论此时已经执行过callback
		if (AccumulatedTimeSeconds >= TimerDelayTime)
		{
			TimerState = EKGTimeDilationTimerState::UnInit;
		}
		else
		{
			TimerState = EKGTimeDilationTimerState::UseTimeDilationTick;	
		}
	}
	else if (!bUseTimeDilation && TimerState == EKGTimeDilationTimerState::UseTimeDilationTick)
	{
		// 从TimeDilationTick切换到TimerManager
		if (!OwnerWorld.IsValid())
		{
			UE_LOG(LogKGCombat, Error, TEXT("FKGTimeDilationTimer::ChangeTimerMode, invalid OwnerWorld"));
			return;
		}

		float TimeLeftSeconds = TimerDelayTime - AccumulatedTimeSeconds;
		UE_LOG(LogKGCombat, Log, TEXT("FKGTimeDilationTimer::ChangeTimerMode, switch to TimeDilationTick, TimeLeftSeconds: %f, TimerDelayTime: %f"),
			TimeLeftSeconds, TimerDelayTime);
		if (TimeLeftSeconds > UE_KINDA_SMALL_NUMBER)
		{
			OwnerWorld->GetTimerManager().SetTimer(
				TimerHandle, TimerDelegate, TimeLeftSeconds, false);
			TimerState = EKGTimeDilationTimerState::UseTimerManager;
		}
		else
		{
			// 时间已经到达, 直接执行回调
			if (TimerDelegate.IsBound())
			{
				TimerDelegate.Execute();
			}
			TimerState = EKGTimeDilationTimerState::UnInit;
		}
	}
}

void FKGTimeDilationTimer::UpdateTickTimer(float DeltaTimeSeconds)
{
	if (TimerState != EKGTimeDilationTimerState::UseTimeDilationTick)
	{
		return;
	}

	if (!OwnerActor.IsValid())
	{
		UE_LOG(LogKGCombat, Error, TEXT("FKGTimeDilationTimer::UpdateTickTimer, invalid OwnerActor"));
		return;
	}

	AccumulatedTimeSeconds += DeltaTimeSeconds * OwnerActor->CustomTimeDilation;
	if (AccumulatedTimeSeconds >= TimerDelayTime)
	{
		if (TimerDelegate.IsBound())
		{
			TimerDelegate.Execute();
		}
		TimerState = EKGTimeDilationTimerState::UnInit;
	}
}
