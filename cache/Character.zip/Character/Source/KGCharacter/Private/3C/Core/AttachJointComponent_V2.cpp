#include "3C/Core/AttachJointComponent_V2.h"

#include "3C/Animation/BaseAnimInstance.h"
#include "GameFramework/Pawn.h"
#include "3C/Core/AttachJointHelper.h"
#include "Engine/World.h"
#include "DrawDebugHelpers.h"
#include "Components/SkeletalMeshComponent.h"


UAttachJointComponent_V2::UAttachJointComponent_V2(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.TickGroup = TG_PostUpdateWork;	//需要在移动修正Mesh位置后再计算，否DuringPhysics 获取mesh位置移动时会有抖动
	
	bAutoActivate = true;
	bTickInEditor = true;
}

void UAttachJointComponent_V2::PostLoad()
{
	Super::PostLoad();
}

void UAttachJointComponent_V2::TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAttachJointComponent_V2_TickComponent");
	QUICK_SCOPE_CYCLE_COUNTER(STAT_AttachJointComponent_V2_TickComponent);
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	SharedCurrentTime += DeltaTime;
	
	UpdateAttachSockets(DeltaTime);
}


void UAttachJointComponent_V2::UpdateLocationAndRotation(const FAttachSocketData& InData,FAttachSocketRunningData& OutRunningData, const float& DeltaTime)
{
	if (InData.LocationLagMode == ELocationUpdateMode::Bezier)
	{
		AttachJointHelper::DoBezierLag(OutRunningData.DesiredLocation,OutRunningData.PreviousDesiredLoc,OutRunningData.PreviousDesiredRot,DeltaTime ,InData.BezierStep,InData.BezierStepMaxDist,
			InData.BezierSpeedAlpha,InData.BezierLagSpeed, InData.BezierDirectionMultiplier,OutRunningData.Speed ,OutRunningData.Velocity,bEnableDebugDraw, GetWorld(),
			OutRunningData.DesiredLocation);
	}
	else if (InData.LocationLagMode == ELocationUpdateMode::Bezier_WithInCircleLag)
	{
		AttachJointHelper::DoRangeInterpLag(OutRunningData.DesiredLocation, OutRunningData.SourceLocation, OutRunningData.PreviouseInCircleLoc, DeltaTime, InData.InCircleLagSpeed,
												InData.InCircleLagTolerance, bEnableDebugDraw, GetWorld(), OutRunningData.DesiredLocation);
		
		OutRunningData.PreviouseInCircleLoc = OutRunningData.DesiredLocation;
		
		AttachJointHelper::DoBezierLag(OutRunningData.DesiredLocation,OutRunningData.PreviousDesiredLoc,OutRunningData.PreviousDesiredRot,DeltaTime ,InData.BezierStep,InData.BezierStepMaxDist,
			InData.BezierSpeedAlpha,InData.BezierLagSpeed, InData.BezierDirectionMultiplier,OutRunningData.Speed ,OutRunningData.Velocity,bEnableDebugDraw, GetWorld(),
			OutRunningData.DesiredLocation);
	}
	else if (InData.LocationLagMode == ELocationUpdateMode::Interp)
	{
		AttachJointHelper::DoInterpLag(OutRunningData.DesiredLocation,OutRunningData.PreviousInterpLoc,
			DeltaTime,InData.AttachLagSpeed,InData.AttachLagMaxDistance,OutRunningData.PreviousInterpLoc,OutRunningData.DesiredLocation);
	}
	else if  (InData.LocationLagMode == ELocationUpdateMode::FloatUpDown)
	{
		AttachJointHelper::DoFloat(OutRunningData.DesiredLocation,  SharedCurrentTime, InData.FloatTime,
			InData.FloatMinHeight,InData.FloatMaxHeight, InData.FloatEaseExp, OutRunningData.DesiredLocation);
	}
	
	
	if (InData.bEnableAttachRotationLag)
	{
		if (InData.RotationUpdateMode == ERotationUpdateMode::FaceToMoveDir)
		{
			AttachJointHelper::DoFaceToMoveDirRotationLag(OutRunningData.DesiredRotation, OutRunningData.PreviousDesiredRot,OutRunningData.Speed,OutRunningData.Velocity,DeltaTime,
			InData.AttachRotationLagSpeed,InData.FaceToMoveDirectionTolerance,InData.bClampPitch,InData.PitchClampAngle.X, InData.PitchClampAngle.Y,
			OutRunningData.DesiredRotation);
		}
		else if (InData.RotationUpdateMode == ERotationUpdateMode::AutoRotate)
		{
			AttachJointHelper::DoAutoRotate(InData.RotateRoundTime,SharedCurrentTime,OutRunningData.DesiredRotation);
		}
		else if (InData.RotationUpdateMode == ERotationUpdateMode::UseDesiredRot)
		{
			AttachJointHelper::DoRotationLag(OutRunningData.DesiredRotation,OutRunningData.PreviousDesiredRot, DeltaTime,InData.AttachRotationLagSpeed,InData.bClampPitch,
				InData.PitchClampAngle.X, InData.PitchClampAngle.Y,  OutRunningData.DesiredRotation);
		}
		else if (InData.RotationUpdateMode == ERotationUpdateMode::UseOwnerRot)
		{
			AActor* Owner = GetOwner();
			if (Owner)
			{
				OutRunningData.DesiredRotation = Owner->GetActorRotation();
			}
		}
	}
	
	OutRunningData.Velocity = (OutRunningData.DesiredLocation - OutRunningData.PreviousDesiredLoc);
	OutRunningData.Speed  = DeltaTime > 0 ? OutRunningData.Velocity.Size() / DeltaTime : 0;
	FVector FinalTrans = OutRunningData.DesiredLocation;
	

	OutRunningData.FinalWorldTrans = FTransform(OutRunningData.DesiredRotation, FinalTrans);


#if !(UE_BUILD_SHIPPING || UE_BUILD_TEST)
	if (bEnableDebugDraw)
	{
		DrawDebugSphere(GetWorld(),FinalTrans, 5.f, 8, FColor::Red);
	}
#endif
}



void UAttachJointComponent_V2::PreUpdateLocationAndRotation(const FAttachSocketData& InData,FAttachSocketRunningData& OutRunningData,const float& DeltaTime)
{
	if (!OutRunningData.bFirstUpdate)
	{
		OutRunningData.PreviousDesiredLoc = OutRunningData.DesiredLocation;
		OutRunningData.PreviousDesiredRot = OutRunningData.DesiredRotation;
	}
	
	if (!OutRunningData.CachedComp.IsValid())
	{
		//尝试查找Component
		if (AActor* Owner = GetOwner())
		{
			if (!InData.CompTag.IsNone())
			{
				OutRunningData.CachedComp = Owner->FindComponentByTag<USceneComponent>(InData.CompTag);
			}
			else
			{
				OutRunningData.CachedComp = Owner->FindComponentByClass<USkeletalMeshComponent>();
			}
		}

		if(!OutRunningData.CachedComp.IsValid())
		{
			//实在找不到,以自身为挂点
			if (AActor* Onwer = GetOwner())
			{
				OutRunningData.CachedComp = Onwer->GetRootComponent();
			}
		}
	}
	
	if(OutRunningData.CachedComp.IsValid())
	{
		if (InData.AttachSocket.IsNone())
		{
			OutRunningData.DesiredLocation = OutRunningData.CachedComp->GetComponentLocation() + InData.AttachPointOffset;
			if (!InData.bAbsoluteRotate)
			{
				OutRunningData.DesiredRotation = OutRunningData.CachedComp->GetComponentRotation() + InData.AttachPointRotation;
			}
			else
			{
				OutRunningData.DesiredRotation = InData.AttachPointRotation;
			}
		}
		else
		{
			OutRunningData.DesiredLocation =  OutRunningData.CachedComp->GetSocketLocation(InData.AttachSocket) + InData.AttachPointOffset;
			if (!InData.bAbsoluteRotate)
			{
				OutRunningData.DesiredRotation = OutRunningData.CachedComp->GetSocketRotation(InData.AttachSocket) + InData.AttachPointRotation;
			}
			else
			{
				OutRunningData.DesiredRotation = InData.AttachPointRotation;
			}
		}
	}


	if (InData.bEnableStabilize)
	{
		if (OutRunningData.bFirstUpdate)
		{
			OutRunningData.PreviousStabilizeLoc = OutRunningData.DesiredLocation;
		}
		FVector StabilizeCenter = OutRunningData.DesiredLocation;

		if(OutRunningData.CachedComp.IsValid())
		{
			StabilizeCenter = OutRunningData.CachedComp->GetSocketLocation(InData.StabilizePointBoneName);
			StabilizeCenter += FRotationMatrix( OutRunningData.CachedComp->GetSocketRotation(InData.StabilizePointBoneName)).TransformVector(InData.StabilizePointOffset);
		}
		
		FVector StabilizedLoc = OutRunningData.DesiredLocation - StabilizeCenter;
		float bInRange = StabilizedLoc.Size() < InData.StabilizeTolerance;
		float TargetAlpha = bInRange ?  1.f : 0.f ;

		if (OutRunningData.PreviousStabilizeBlendAlpha!= TargetAlpha)
		{
			OutRunningData.PreviousStabilizeBlendAlpha += DeltaTime * (bInRange ? InData.StabilizeInterpSpeed  : - 1 * InData.StabilizeInterpOutSpeed );
			OutRunningData.PreviousStabilizeBlendAlpha = FMath::Clamp(OutRunningData.PreviousStabilizeBlendAlpha,0,1);
			StabilizedLoc = FMath::InterpEaseOut(OutRunningData.DesiredLocation, StabilizeCenter, OutRunningData.PreviousStabilizeBlendAlpha, 3);
		}
		else
		{
			StabilizedLoc = bInRange ? StabilizeCenter : OutRunningData.DesiredLocation;
		}


		
		OutRunningData.PreviousStabilizeLoc = StabilizedLoc;
		OutRunningData.DesiredLocation = StabilizedLoc;
		OutRunningData.SourceLocation = StabilizedLoc;

		
#if !(UE_BUILD_SHIPPING || UE_BUILD_TEST)
		if (bEnableDebugDraw)
		{
			DrawDebugPoint(GetWorld(), StabilizeCenter, 1.f, FColor::Emerald, false, DeltaTime);
			DrawDebugPoint(GetWorld(), StabilizedLoc, 1.f, FColor::White, false, DeltaTime);
			DrawDebugSphere(GetWorld(),	StabilizeCenter, InData.StabilizeTolerance, 16,FColor::Emerald);
		}
#endif
	}
	else
	{
		OutRunningData.SourceLocation = OutRunningData.DesiredLocation;
	}
	
	OutRunningData.SourceLocation = OutRunningData.DesiredLocation;
	
	OutRunningData.DesiredLocation += FRotationMatrix(OutRunningData.DesiredRotation).TransformVector(InData.SocketRelativeOffset);
	OutRunningData.DesiredRotation += InData.SocketRelativeRotation;

	if (OutRunningData.bFirstUpdate)
	{
		OutRunningData.PreviousDesiredLoc = OutRunningData.DesiredLocation;
		OutRunningData.PreviousDesiredRot = OutRunningData.DesiredRotation;
		OutRunningData.PreviousInterpLoc = OutRunningData.DesiredLocation;
		OutRunningData.bFirstUpdate = false;
	}

	if (InData.bDoCollisionTest && bLodEnableCollision)
	{
		UKismetSystemLibrary::SphereTraceSingleForObjects(GetWorld(),
			OutRunningData.SourceLocation,
			OutRunningData.DesiredLocation,
			InData.ProbeSize,
			InData.CollisionChannels,
			false,
			TArray<AActor*>(),
			EDrawDebugTrace::None,
			HitResultCache,
			true);
		if (HitResultCache.bBlockingHit)
		{
			OutRunningData.DesiredLocation = HitResultCache.Location;
		}
	}


#if !(UE_BUILD_SHIPPING || UE_BUILD_TEST)
	if (bEnableDebugDraw)
	{
		DrawDebugSphere(GetWorld(),	OutRunningData.SourceLocation, 5.f, 8, FColor::Blue);
		DrawDebugSphere(GetWorld(),OutRunningData.DesiredLocation, 5.f, 8, FColor::Green);
		DrawDebugDirectionalArrow(GetWorld(),
		OutRunningData.SourceLocation,
			OutRunningData.DesiredLocation,
			7.5f,
			FColor::Blue);
		DrawDebugDirectionalArrow(GetWorld(),
			OutRunningData.DesiredLocation,
			OutRunningData.DesiredLocation + OutRunningData.DesiredRotation.Vector() * 20.0f,
			7.5f,
			FColor::Green);
	}
#endif
}



void UAttachJointComponent_V2::UpdateAttachSockets(const float& DeltaTime)
{
	ActiveSockets.Reset();
	PendingRemoveIdx.Reset();
	
	//收集有效的挂接点
	for (auto& Child: AttachChildren)
	{
		if(Child.Value.Comp.IsValid() && !Child.Value.bMarkRemove)
		{
			ActiveSockets.Add(Child.Value.SocketID);
		}
	}

	//计算Socket位置
	for (auto& Data:SocketData)
	{
		if (ActiveSockets.Contains(Data.Key) or !Data.Value.bPauseOnNoAttached)
		{
			FAttachSocketRunningData& RunningData = SocketRunningData.FindOrAdd(Data.Key);
			PreUpdateLocationAndRotation(Data.Value, RunningData, DeltaTime);
			UpdateLocationAndRotation(Data.Value, RunningData, DeltaTime);
		}
	}

	//更新child位置
	for (auto& Child: AttachChildren)
	{
		FAttachChildData& AttachData = Child.Value;
		if(AttachData.Comp.IsValid() && !AttachData.bMarkRemove)
		{
			const FAttachSocketRunningData* RunningData = SocketRunningData.Find(AttachData.SocketID);
			if (RunningData != nullptr)
			{
				FTransform FinalTrans = AttachData.AttachTransform * RunningData->FinalWorldTrans;
				Child.Value.Comp->SetWorldLocationAndRotation(FinalTrans.GetLocation(), FinalTrans.GetRotation(), false,nullptr,ETeleportType::None);
			}
		}
		else
		{
			//失效的component直接移除
			PendingRemoveIdx.Add(Child.Key);
		}
	}

	//移除挂接
	for(int64& IDx:PendingRemoveIdx)
	{
		AttachChildren.Remove(IDx);
	}
	PendingRemoveIdx.Reset();
}


void UAttachJointComponent_V2::ApplyWorldOffset(const FVector & InOffset, bool bWorldShift)
{
	Super::ApplyWorldOffset(InOffset, bWorldShift);
}


void UAttachJointComponent_V2::RemoveAttachment(int64 AttachID)
{
	if (FAttachChildData* FoundAttach = AttachChildren.Find(AttachID))
	{
		FoundAttach->bMarkRemove = true;
	}
}

int64 UAttachJointComponent_V2::AddAttachActor(AActor* AttachActor, int64 SocketID,  const FTransform& Trans)
{
	if(AttachActor)
	{
		return AddAttachComponent(AttachActor->GetRootComponent(),  SocketID,  Trans);
	}
	return -1;
}

int64 UAttachJointComponent_V2::AddAttachComponent(USceneComponent* AttachComp,int64 SocketID,const FTransform& Trans)
{
	if (AttachComp)
	{
		FAttachChildData NewAttach;
		NewAttach.UniqueID = ULowLevelFunctions::GetGlobalUniqueID();
		NewAttach.Comp = AttachComp;
		NewAttach.SocketID = SocketID;
		NewAttach.AttachTransform = Trans;

		AttachChildren.Add(NewAttach.UniqueID,NewAttach);
		return 	NewAttach.UniqueID;
	}
	return -1;
}

bool UAttachJointComponent_V2::AddAttachSocketByID(int64 SocketID,FName AttachBoneSocket,FName CompTag,
		const FVector& BindOffset,const FRotator& BindRotation,const FVector& SocketOffset,const FRotator& Rotation, bool bAbsoluteRotate)
{
	if (SocketData.Find(SocketID))
	{
		return false;
	}
	
	FAttachSocketData NewData;

	NewData.SocketID = SocketID;

	NewData.AttachSocket = AttachBoneSocket;
	NewData.CompTag = CompTag;
	NewData.AttachPointOffset = BindOffset;
	NewData.AttachPointRotation = BindRotation;
	NewData.SocketRelativeOffset = SocketOffset;
	NewData.SocketRelativeRotation =Rotation;
	NewData.bAbsoluteRotate = bAbsoluteRotate;
	SocketData.Add(NewData.SocketID,NewData);
	return true;
}

int64 UAttachJointComponent_V2::AddAttachSocket(FName AttachBoneSocket, FName CompTag,const FVector& BindOffset,
	const FRotator& BindRotation,const FVector& SocketOffset,const FRotator& Rotation)
{
	FAttachSocketData NewData;

	NewData.SocketID = ULowLevelFunctions::GetGlobalUniqueID();

	NewData.AttachSocket = AttachBoneSocket;
	NewData.CompTag = CompTag;
	NewData.AttachPointOffset = BindOffset;
	NewData.AttachPointRotation = BindRotation;
	NewData.SocketRelativeOffset = SocketOffset;
	NewData.SocketRelativeRotation =Rotation;
	SocketData.Add(NewData.SocketID,NewData);
	return NewData.SocketID;
}

bool UAttachJointComponent_V2::ForceSocketUpdate(int64 SocketID, bool bEnableForceUpdate)
{
	if(FAttachSocketData* Data = SocketData.Find(SocketID))
	{
		Data->bPauseOnNoAttached = !bEnableForceUpdate;
		return true;
	}
	return false;
}


bool UAttachJointComponent_V2::GetVirtualSocketLocation(int64 SocketID, FVector& OutLocation)
{
	if (FAttachSocketRunningData* RunningData = SocketRunningData.Find(SocketID))
	{
		OutLocation = RunningData->DesiredLocation;
		return true;
	}
	return false;
}


bool UAttachJointComponent_V2::RemoveAttachSocket(int64 SocketID)
{
	SocketData.Remove(SocketID);
	SocketRunningData.Remove(SocketID);
	return true;
}

bool UAttachJointComponent_V2::ModifyAttachSocket(int64 SocketID, FName AttachBoneSocket, FName CompTag,
	const FVector& BindOffset, const FRotator& BindRotation,const FVector& SocketOffset,const FRotator& Rotation)
{
	if(FAttachSocketData* Data = SocketData.Find(SocketID))
	{
		Data->AttachSocket = AttachBoneSocket;
		Data->CompTag = CompTag;
		Data->AttachPointOffset = BindOffset;
		Data->AttachPointRotation = BindRotation;
		Data->SocketRelativeOffset = SocketOffset;
		Data->SocketRelativeRotation =Rotation;
		return true;
	}
	return false;
}

bool UAttachJointComponent_V2::EnableAttachSocketCollisionTest(int64 SocketID, float ProbeSize,const TArray<int>& CollisionChannels)
{
	if(FAttachSocketData* Data = SocketData.Find(SocketID))
	{
		Data->bDoCollisionTest = true;
		Data->ProbeSize = ProbeSize;

		Data->CollisionChannels.Empty();
		for (auto TypeQuerry : CollisionChannels)
		{
			Data->CollisionChannels.Push(static_cast<EObjectTypeQuery>(TypeQuerry));
		}
		return true;
	}
	return false;
}

bool UAttachJointComponent_V2::DisableAttachSocketCollisionTest(int64 SocketID)
{
	if(FAttachSocketData* Data = SocketData.Find(SocketID))
	{
		Data->bDoCollisionTest = false;
		return true;
	}
	return false;
}

bool UAttachJointComponent_V2::EnableLocationStabilize(int64 SocketID, float StabilizeTolerance,
	float StabilizeInterpSpeed,float StabilizeInterpOutSpeed,const FName& StabilizePointBoneName,const FVector& StabilizePointOffset)
{
	if(FAttachSocketData* Data = SocketData.Find(SocketID))
	{
		Data->bEnableStabilize = true;
		Data->StabilizeInterpSpeed = StabilizeInterpSpeed;
		Data->StabilizeInterpOutSpeed = StabilizeInterpOutSpeed;
		Data->StabilizeTolerance = StabilizeTolerance;
		Data->StabilizePointBoneName = StabilizePointBoneName;
		Data->StabilizePointOffset = StabilizePointOffset;
		return true;
	}
	return false;
}

bool UAttachJointComponent_V2::DisableLocationStabilize(int64 SocketID)
{
	if(FAttachSocketData* Data = SocketData.Find(SocketID))
	{
		Data->bEnableStabilize = false;
		return true;
	}
	return false;
}


bool UAttachJointComponent_V2::EnableAttachSocketLocationLagByFloat(int64 SocketID, float FloatTime, float FloatMaxHeight, float FloatMinHeight, float FloatEaseExp)
{
	if(FAttachSocketData* Data = SocketData.Find(SocketID))
	{
		Data->LocationLagMode = ELocationUpdateMode::FloatUpDown ;
		Data->FloatTime = FloatTime;
		Data->FloatMaxHeight = FloatMaxHeight;
		Data->FloatMinHeight = FloatMinHeight;
		Data->FloatEaseExp = FloatEaseExp;
		return true;
	}
	return false;
}

bool UAttachJointComponent_V2::EnableAttachSocketLocationLagByInterp(int64 SocketID, float AttachLagSpeed, float AttachLagMaxDistance)
{
	if(FAttachSocketData* Data = SocketData.Find(SocketID))
	{
		Data->LocationLagMode = ELocationUpdateMode::Interp ;
		Data->AttachLagSpeed = AttachLagSpeed;
		Data->AttachLagMaxDistance = AttachLagMaxDistance;

		if (FAttachSocketRunningData* RunningData = SocketRunningData.Find(SocketID))
		{
			RunningData->PreviousInterpLoc = RunningData->PreviousDesiredLoc;
		}
		return true;
	}
	return false;
}


bool UAttachJointComponent_V2::EnableAttachSocketLocationLagByBezier(int64 SocketID, float BezierStep,
	float BezierStepMaxDist, float BezierSpeedAlpha,float BezierLagSpeed,float BezierDirectionMultiplier)
{
	if(FAttachSocketData* Data = SocketData.Find(SocketID))
	{
		Data->LocationLagMode = ELocationUpdateMode::Bezier ;
		Data->BezierStep = BezierStep;
		Data->BezierStepMaxDist = BezierStepMaxDist;
		Data->BezierSpeedAlpha = BezierSpeedAlpha;
		Data->BezierLagSpeed = BezierLagSpeed;
		Data->BezierDirectionMultiplier = BezierDirectionMultiplier;
		return true;
	}
	return false;
}

bool UAttachJointComponent_V2::EnableAttachSocketLocationLagByBezierWithInCircleLag(int64 SocketID,
	float BezierStep, float BezierStepMaxDist, float BezierSpeedAlpha, float BezierLagSpeed,
	float BezierDirectionMultiplier, float InCircleLagSpeed, float InCircleLagTolerance)
{
	if(FAttachSocketData* Data = SocketData.Find(SocketID))
	{
		Data->LocationLagMode = ELocationUpdateMode::Bezier_WithInCircleLag ;
		Data->BezierStep = BezierStep;
		Data->BezierStepMaxDist = BezierStepMaxDist;
		Data->BezierSpeedAlpha = BezierSpeedAlpha;
		Data->BezierLagSpeed = BezierLagSpeed;
		Data->BezierDirectionMultiplier = BezierDirectionMultiplier;
		Data->InCircleLagSpeed = InCircleLagSpeed;
		Data->InCircleLagTolerance = InCircleLagTolerance;
		return true;
	}
	return false;
}

bool UAttachJointComponent_V2::DisableAttachSocketLocationLag(int64 SocketID)
{
	if(FAttachSocketData* Data = SocketData.Find(SocketID))
	{
		Data->LocationLagMode = ELocationUpdateMode::None ;
		return true;
	}
	return false;
}

bool UAttachJointComponent_V2::EnableAttachSocketAttachRotationLag(int64 SocketID, float AttachRotationLagSpeed,
	bool bClampPitch, float PitchClampAngleMin,float PitchClampAngleMax,
	ERotationUpdateMode RotationUpdateMode, float FaceToMoveDirectionTolerance,float RotateRoundTime)
{
	if(FAttachSocketData* Data = SocketData.Find(SocketID))
	{
		Data->bEnableAttachRotationLag = true ;
		Data->AttachRotationLagSpeed = AttachRotationLagSpeed ;
		Data->bClampPitch = bClampPitch ;
		Data->PitchClampAngle = FVector2D(PitchClampAngleMin, PitchClampAngleMax) ;
		Data->RotationUpdateMode = RotationUpdateMode ;
		Data->FaceToMoveDirectionTolerance = FaceToMoveDirectionTolerance ;
		Data->RotateRoundTime = RotateRoundTime;
		return true;
	}
	return false;
}

bool UAttachJointComponent_V2::DisableAttachSocketAttachRotationLag(int64 SocketID)
{
	if(FAttachSocketData* Data = SocketData.Find(SocketID))
	{
		Data->bEnableAttachRotationLag = false ;
		return true;
	}
	return false;
}

void UAttachJointComponent_V2::OnRegister()
{
	Super::OnRegister();
}

void UAttachJointComponent_V2::UpdateAttachSocketRelLocation(int64 SocketID, FVector RelLoc)
{
	if(FAttachSocketData* Data = SocketData.Find(SocketID))
	{
		Data->SocketRelativeOffset = RelLoc ;
	}
}

void UAttachJointComponent_V2::UpdateIsLodEnableCollision(bool bEnableCollision)
{
	bLodEnableCollision = bEnableCollision;
}

void UAttachJointComponent_V2::ResetToDefaultsForCache()
{
	SharedCurrentTime = 0;

	SocketData.Empty();
	SocketRunningData.Empty();
	AttachChildren.Empty();
}
