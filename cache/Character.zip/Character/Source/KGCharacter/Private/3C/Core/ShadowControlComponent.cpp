#include "3C/Core/ShadowControlComponent.h"
#include "Components/MeshComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/World.h"
#include "GameFramework/Character.h"
#include "Kismet/GameplayStatics.h"


UShadowControlComponent::UShadowControlComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UShadowControlComponent::EnableInsetShadow(bool bEnable)
{
	bEnableInsetShadow = bEnable;
}

void UShadowControlComponent::RemoveComponent()
{
	AActor* BoundActor = GetOwner();
	if (ACharacter* Char = Cast<ACharacter>(BoundActor))
	{
		if (USkeletalMeshComponent* mesh = Char->GetMesh())
		{
			mesh->bCastInsetShadow = false;
		}
	}
	DestroyComponent();
}

void UShadowControlComponent::BeginPlay()
{
	Super::BeginPlay();
}

void UShadowControlComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UShadowControlComponent_TickComponent");
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	AActor* BoundActor = GetOwner();

	if (ACharacter* Char = Cast<ACharacter>(BoundActor))
	{
		if (USkeletalMeshComponent* mesh = Char->GetMesh())
		{
			bool ViewChanged = false;
			mesh->bCastInsetShadow = bEnableInsetShadow;

			if (BoundingConfig.Num() > 0 && bEnableInsetShadow && bEnableBoundConfig)
			{
				int LastBoundIdx = CurrentBoundIdx;
				CurrentBoundIdx = -1;

				if (APlayerCameraManager* CM = Cast<APlayerCameraManager>(UGameplayStatics::GetPlayerCameraManager(GetWorld(), 0)))
				{
					FMinimalViewInfo POV = CM->GetCameraCacheView();

					ViewChanged |= !(POV.Equals(CM->GetLastFrameCameraCacheView()));
					
					float Dist = (POV.Location - BoundActor->GetActorLocation()).Size();

					for (int i = 0; i < BoundingConfig.Num(); i++)
					{
						if ((CurrentBoundIdx < 0 || BoundingConfig[i].Distance < BoundingConfig[CurrentBoundIdx].Distance) && (BoundingConfig[i].Distance > Dist))
						{
							CurrentBoundIdx = i;
						}
					}
				}
				
				ViewChanged |= (CurrentBoundIdx != LastBoundIdx);
				ViewChanged |= mesh->K2_GetComponentLocation() != LastActorLocation;
				ViewChanged |= mesh->K2_GetComponentRotation() != LastActorRotation;

				LastActorLocation = mesh->K2_GetComponentLocation();
				LastActorRotation = mesh->K2_GetComponentRotation();

				if (CurrentBoundIdx >= 0)
				{
					// if (ViewChanged)
					// {
						mesh->bComputeBoundsOnceForGame = false;
						mesh->UpdateBounds();
						FBoxSphereBounds LocalBounds = mesh->GetLocalBounds();
						LocalBounds = LocalBounds.TransformBy(FScaleRotationTranslationMatrix(	BoundingConfig[CurrentBoundIdx].BoundingScale, FRotator::ZeroRotator, BoundingConfig[CurrentBoundIdx].BoundingLocation));
						mesh->bComputeBoundsOnceForGame = true;
						mesh->UpdateBounds();
						mesh->Bounds = LocalBounds.TransformBy(mesh->GetComponentTransform());
						mesh->MarkRenderTransformDirty();
					// }
				}
				else if (mesh->bComputeBoundsOnceForGame != false)
				{
					mesh->bComputeBoundsOnceForGame = false;
					mesh->UpdateBounds();
					mesh->MarkRenderTransformDirty();
				}
			}
			else if (mesh->bComputeBoundsOnceForGame != false)
			{
				mesh->bComputeBoundsOnceForGame = false;
				mesh->UpdateBounds();
				mesh->MarkRenderTransformDirty();
			}
			
			if (bEnableInsetShadow && bEnableDebugDraw)
			{
				UKismetSystemLibrary::DrawDebugBox(GetWorld(), mesh->Bounds.Origin, mesh->Bounds.BoxExtent, FLinearColor::Blue, FRotator::ZeroRotator, DeltaTime, 2);
			}
		}
	}
}