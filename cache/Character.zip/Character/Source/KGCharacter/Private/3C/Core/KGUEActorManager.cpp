#include "3C/Core/KGUEActorManager.h"
#include "AkComponent.h"
#include "3C/Core/AttachJointComponent_V2.h"
#include "3C/Character/BaseCharacter.h"
#include "ClimateInteractionComponent.h"
#include "Runtime/FaceControlComponent.h"
#include "DrawDebugHelpers.h"
#include "Misc/LowLevelFunctions.h"
#include "Engine/Engine.h"
#include "Engine/AssetManager.h"
#include "Engine/StreamableManager.h"
#include "Misc/KGGameInstanceBase.h"
#include "Manager/KGObjectActorManager.h"
#include "ICppEntity.h"
#include "ICppEntityModule.h"
#include "3C/Core/InteractiveTriggerComponent.h"
#include "3C/RoleComposite/RoleCompositeManager.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "SkeletalMeshComponentBudgeted.h"
#include "MassAgentComponent.h"
#include "3C/Util/KGUtils.h"
#include "3C/Component/AddMeshComponent.h"
#include "Components/MeshComponent.h"
#include "Components/WorldPartitionStreamingSourceComponent.h"
#include "Managers/KGCombatUnitManager.h"
#include "3C/Material/KGMaterialManager.h"

using namespace NS_SLUA;

DEFINE_LOG_CATEGORY_STATIC(UKGUEActorManagerLog, Log, All);

bool GEnableKGUEActorManagerStat = false;
static FAutoConsoleVariableRef CVarEnableKGUEActorManagerStat(
	TEXT("c7.Character.EnableKGUEActorManagerStat"),
	GEnableKGUEActorManagerStat,
	TEXT("EnableKGUEActorManagerStat"),
	ECVF_Default
);

void UKGUEActorManager::NativeInit()
{
	Super::NativeInit();

	ActorLoader = NewObject<UKGUEActorLoader>();
	ActorLoader->Init(this);

	SpawnActorParameters.bNoFail = true;
	SpawnActorParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	SpawnActorParameters.ObjectFlags |= RF_Transient;

	//为了确保正确工作，设置一个默认的池大小
	SetCppEntityPoolSize(CPP_ENTITY_POOL_INIT_SIZE);

	bMgrInit = true;

	ICppEntityModule* LuaScriptAPIModule = FModuleManager::GetModulePtr<ICppEntityModule>("KGCppEntity");
	if (!LuaScriptAPIModule)
	{
		UE_LOG(UKGUEActorManagerLog,Fatal,TEXT("Fatal Error, Get ICppEntityModule failed!"));
		return;
	}
	LuaScriptAPIModule->InitMetatable(GetLuaState());

	REG_EXTENSION_METHOD_IMP(UKGUEActorManager, "CreateActorAndCppEntity", {
		CheckUD(UKGUEActorManager, L, 1);
		return UD->CreateActorAndCppEntity(L);
		});
	REG_EXTENSION_METHOD_IMP(UKGUEActorManager, "DestroyActorAndCppEntity", {
		CheckUD(UKGUEActorManager, L, 1);
		return UD->DestroyActorAndCppEntity(L);
		});

	REG_EXTENSION_METHOD_IMP(UKGUEActorManager, "CreateCppEntityForBindActorLater", {
		CheckUD(UKGUEActorManager, L, 1);
		return UD->CreateCppEntityForBindActorLater(L);
		});

	REG_EXTENSION_METHOD_IMP(UKGUEActorManager, "CreateActorBindedToExistedCppEntity", {
		CheckUD(UKGUEActorManager, L, 1);
		return UD->CreateActorBindedToExistedCppEntity(L);
		});

	REG_EXTENSION_METHOD_IMP(UKGUEActorManager, "UnbindAndDestroyActor", {
		CheckUD(UKGUEActorManager, L, 1);
		return UD->UnbindAndDestroyActor(L);
		});

	REG_EXTENSION_METHOD_IMP(UKGUEActorManager, "BindLevelSpawnedActorWithCppEntity", {
		CheckUD(UKGUEActorManager, L, 1);
		return UD->BindLevelSpawnedActorWithCppEntity(L);
		});
	REG_EXTENSION_METHOD_IMP(UKGUEActorManager, "CreateCppEntityAndBindLevelSpawnedActor", {
		CheckUD(UKGUEActorManager, L, 1);
		return UD->CreateCppEntityAndBindLevelSpawnedActor(L);
		});
	REG_EXTENSION_METHOD_IMP(UKGUEActorManager, "UnbindLevelSpawnedActorAndDestroyCppEntity", {
		CheckUD(UKGUEActorManager, L, 1);
		return UD->UnbindLevelSpawnedActorAndDestroyCppEntity(L);
		});
	REG_EXTENSION_METHOD_IMP(UKGUEActorManager, "UnbindLevelSpawnedActor", {
		CheckUD(UKGUEActorManager, L, 1);
		return UD->UnbindLevelSpawnedActor(L);
		});
	REG_EXTENSION_METHOD_IMP(UKGUEActorManager, "CreateActorWithBPClassAndBindToExistedCppEntity", {
		CheckUD(UKGUEActorManager, L, 1);
		return UD->CreateActorWithBPClassAndBindToExistedCppEntity(L);
		});
	REG_EXTENSION_METHOD_IMP(UKGUEActorManager, "CreateActorWithBPClassIDAndBindToExistedCppEntity", {
		CheckUD(UKGUEActorManager, L, 1);
		return UD->CreateActorWithBPClassIDAndBindToExistedCppEntity(L);
		});
	REG_EXTENSION_METHOD_IMP(UKGUEActorManager, "SpawnActorAndCppEntity", {
		CheckUD(UKGUEActorManager, L, 1);
		return UD->SpawnActorAndCppEntity(L);
	});
	REG_EXTENSION_METHOD_IMP(UKGUEActorManager, "GetLuaEntityByActorID", {
		CheckUD(UKGUEActorManager, L, 1);
		KGActorID InActorID = luaL_checkinteger(L, 2);
		ICppEntityInterface* LuaEntity = UD->GetLuaEntityByActorID(InActorID);
		if (LuaEntity == nullptr)
		{
			UE_LOG(LogTemp, Warning, TEXT("GetLuaEntityByActorID: can not get LueScriptEntity by ActorID[%lld]"), InActorID);
			return 0;
		}
		NS_SLUA::LuaVar& selfTable = LuaEntity->GetLuaEntityBase()->GetSelfTable();
		if (selfTable.isValid() == false)
		{
			UE_LOG(LogTemp, Warning, TEXT("GetLuaEntityByActorID: selfTable is not valid. ActorID[%d]"), InActorID);
			return 0;
		}

		selfTable.push(L);
		return 1;
	});

	REG_EXTENSION_METHOD(UKGUEActorManager, "ClearLoaderClassMap", &UKGUEActorManager::ClearLoaderClassMap);
	REG_EXTENSION_METHOD(UKGUEActorManager, "DestoryActor", &UKGUEActorManager::DestoryActorByEntityID);
	REG_EXTENSION_METHOD(UKGUEActorManager, "ManuallyRegisterActorOnDestroyed", &UKGUEActorManager::ManuallyRegisterActorOnDestroyed);

	REG_EXTENSION_METHOD(UKGUEActorManager, "KAPI_GetClassObjectIDByClassPath", &UKGUEActorManager::KAPI_GetClassObjectIDByClassPath);
	REG_EXTENSION_METHOD(UKGUEActorManager, "KAPI_UnCacheClass", &UKGUEActorManager::KAPI_UnCacheClass);
	REG_EXTENSION_METHOD(UKGUEActorManager, "KAPI_UnCacheAllClass", &UKGUEActorManager::KAPI_UnCacheAllClass);

	REG_EXTENSION_METHOD(UKGUEActorManager, "EnableFrameLimit", &UKGUEActorManager::EnableFrameLimit);
	REG_EXTENSION_METHOD(UKGUEActorManager, "SetFrameLimitParam", &UKGUEActorManager::SetFrameLimitParam);

	REG_EXTENSION_METHOD(UKGUEActorManager, "SetCppEntityPoolSize", &UKGUEActorManager::SetCppEntityPoolSize);
	
	REG_EXTENSION_METHOD(UKGUEActorManager, "SetEnableUEActorCache", &UKGUEActorManager::SetEnableUEActorCache);
	REG_EXTENSION_METHOD(UKGUEActorManager, "ClearUEActorCache", &UKGUEActorManager::ClearUEActorCache);
	REG_EXTENSION_METHOD(UKGUEActorManager, "SetMainPlayerControlledEntityID", &UKGUEActorManager::SetMainPlayerControlledEntityID);
}

UKGUEActorManager* UKGUEActorManager::GetInstance(UObject* InContext)
{
	return Cast<UKGUEActorManager>(GetManagerByType(InContext, EManagerType::EMT_UEActorManager));
}

void UKGUEActorManager::LoadActor(KGEntityID EntID, const FString& ClassPath, float X, float Y, float Z, float Pitch,
	float Yaw, float Roll, bool Preload, bool SyncLoad)
{
	if (!LuaEntityMap.Contains(EntID)) {
		UE_LOG(UKGUEActorManagerLog, Error, TEXT("[UKGUEActorManager::LoadActor] load actor failed, can not find entity -> %lld"), EntID);
		return;
	}

	if (Entity2Actor.Contains(EntID)) {
		UE_LOG(UKGUEActorManagerLog, Error, TEXT("[UKGUEActorManager::LoadActor] load actor failed, actor already existed -> %lld"), EntID);
		return;
	}

	FTransform Transform;
	Transform.SetRotation(FRotator(Pitch, Yaw, Roll).Quaternion());
	Transform.SetLocation(FVector(X, Y, Z));
	
	if(!TryUseUEActorCache(EntID, Transform))
	{
		ActorLoader->AddLoadTask(EntID, ClassPath, Transform, Preload, SyncLoad);
	}
}

void UKGUEActorManager::OnActorLoaded(KGEntityID EntID, AActor* InActor, bool CachedUEActor)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGUEActorManager::OnActorLoaded");
	if (!InActor) {
		UE_LOG(UKGUEActorManagerLog, Error, TEXT("[UKGUEActorManager::OnActorLoaded] Spawn Actor failed! EntityID -> %lld"), EntID);
		return;
	}

	if (!BindActorToEntity(EntID, InActor, true)) {
		UE_LOG(UKGUEActorManagerLog, Error, TEXT("[UKGUEActorManager::OnActorLoaded] bind actor to entity failed -> %lld"), EntID);
		return;
	}

	InActor->OnDestroyed.AddDynamic(this, &UKGUEActorManager::OnActorDestoryByUE);
	KGActorID ActorID = GetIDByActor(InActor);
	ActorMap.Add(ActorID, InActor);
	
	CallLuaFunction("KCB_OnCreateActor", EntID, ActorID, CachedUEActor);
	
	GetOnActorLoadedDelegate().Broadcast(EntID, InActor);
}


KGActorID UKGUEActorManager::GetIDByActor(AActor* InActor)
{
	return KGUtils::GetIDByObject(InActor);
}

void UKGUEActorManager::DestoryActorByEntityID(KGEntityID EntID)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGUEActorManager::DestoryActorByEntityID");
	if (Entity2Actor.Contains(EntID)) {
		KGActorID ActorID = Entity2Actor[EntID];
		if (!ActorMap.Contains(ActorID)) {
			UE_LOG(UKGUEActorManagerLog, Error, TEXT("[UKGUEActorManager::DestoryActor] can not find Actor for Entity -> %lld"), EntID);
			return;
		}
		AActor* Actor = ActorMap[ActorID];
		if (IsValid(Actor)) {
			InnerRemoveActor(Actor);
			if(TryPushUEActorCache(EntID, Actor))
			{
				CallLuaFunction("KCB_OnActorDestory", EntID, ActorID, true);
			}
			else
			{
				//放到这里清理材质是因为PushUEActorCache需要清理材质bFallbackToDefaultMaterial，不能提前 hujianglong@kuaishou.com
				if (UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(Actor))
				{
					MaterialManager->RevertMaterialAndMaterialParamsOnActorDestroy(ActorID);
				}
				
				CallLuaFunction("KCB_OnActorDestory", EntID, ActorID);
				DestroyUEActor(Actor);
			}
		}
	}
	else {
		UE_LOG(UKGUEActorManagerLog, Log, TEXT("cancel load task destory actor by entity -> %lld"), EntID);
		ActorLoader->CancelLoadTask(EntID);
	}
}

#pragma region UEActorCache
void UKGUEActorManager::SetEnableUEActorCache(bool Enable, bool EnableMainPlayer, bool EnableAOIPlayer, bool EnableNPCPlayer, bool EnableGhostClone,
	float InAvatarPlayerLruCacheTime, float InTickActorCacheIntervalTime)
{
	EnableUEActorCache = Enable;
	EnableUEActorMainPlayerCache = EnableMainPlayer;
	EnableUEActorAOIPlayerCache = EnableAOIPlayer;
	EnableUEActorNPCCache = EnableNPCPlayer;
	EnableUEActorGhostCloneCache = EnableGhostClone;
	AvatarPlayerLruCacheTime = InAvatarPlayerLruCacheTime;
	TickActorCacheIntervalTime = InTickActorCacheIntervalTime;
}

void UKGUEActorManager::ClearUEActorCache(int AvatarPlayerCacheCapacity)
{
	if (IsValid(MainPlayerCache))
	{
		IC7ActorInterface* C7ActorInterface = Cast<IC7ActorInterface>(MainPlayerCache);
		if (C7ActorInterface)
		{
			int64 EntID = C7ActorInterface->GetEntityUID();
			int64 ActorID = KGUtils::GetIDByObject(MainPlayerCache);
			CallLuaFunction("KCB_OnActorDestoryByUEActorCache", EntID, ActorID);
		}
		DestroyUEActor(MainPlayerCache);
		MainPlayerCache = nullptr;
	}
	ResetUEActorCacheCapacity(AvatarPlayerCacheCapacity);
}

bool UKGUEActorManager::HandlePushCachedUEActor(AActor* UEActor, bool SetPos)
{
	ABaseCharacter* TargetCharacter = Cast<ABaseCharacter>(UEActor);
	if (IsValid(TargetCharacter))
	{
		ResetCachedUEActor(TargetCharacter, false);
		if (SetPos)
		{
			TargetCharacter->SetActorLocation(FVector(0,0,-100000000));
		}
		return true;
	}
	return false;
}

bool UKGUEActorManager::HandlePopCachedUEActor(AActor* UEActor, const FTransform& Transform)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGUEActorManager::HandlePopCachedUEActor");
	if(!IsValid(UEActor))
	{
		return false;
	}
	
	ABaseCharacter* TargetCharacter = Cast<ABaseCharacter>(UEActor);
	if (IsValid(TargetCharacter))
	{
		ResetCachedUEActor(TargetCharacter, true);
		TargetCharacter->SetActorTransform(Transform);
        return true;
	}

	DestroyUEActor(UEActor);
	return false;
}

void UKGUEActorManager::ResetCachedUEActor(ABaseCharacter* TargetCharacter, bool Visible)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGUEActorManager::ResetCachedUEActor");
	if(!TargetCharacter)
	{
		return;
	}
	
	TargetCharacter->ResetToDefaultsForCache();
	TargetCharacter->SetActorEnableCollision(Visible);
	TargetCharacter->SetActorTickEnabled(Visible);
	TargetCharacter->SetActorHiddenInGame(!Visible);

	TSet<UActorComponent*> ActorComponents = TargetCharacter->GetComponents();
	for (UActorComponent* ActorComponent : ActorComponents)
	{
		if (ActorComponent->ComponentTags.Contains(URoleCompositeMgr::IgnoreTagForComTickSetByVisible))
		{
			continue;
		}
		ActorComponent->SetComponentTickEnabled(Visible);
	}

	TArray<UWorldPartitionStreamingSourceComponent*> WpStreamingSourceComponents;
	TargetCharacter->GetComponents<UWorldPartitionStreamingSourceComponent>(WpStreamingSourceComponents);
	for (UWorldPartitionStreamingSourceComponent* Component : WpStreamingSourceComponents)
	{
		if(Visible)
		{
			Component->EnableStreamingSource();
		}
		else
		{
			Component->DisableStreamingSource();
		}
	}

	TArray<UMassAgentComponent*> MassAgentComponents;
	TargetCharacter->GetComponents<UMassAgentComponent>(MassAgentComponents);
	for (UMassAgentComponent* Component : MassAgentComponents)
	{
		if(Visible)
		{
			Component->Enable();
		}
		else
		{
			Component->Disable();
		}
	}

	TArray<USkeletalMeshComponentBudgeted*> SkeletalMeshComponentBudgetedComponents;
	TargetCharacter->GetComponents<USkeletalMeshComponentBudgeted>(SkeletalMeshComponentBudgetedComponents);
	for (USkeletalMeshComponentBudgeted* Component : SkeletalMeshComponentBudgetedComponents)
	{
		if(!Visible)
		{
			Component->UnregisterFromAllocatorBudget();
		}
	}

	//ResetToDefaultsForCache
	TArray<UActorComponent*> ResetActorComponents;
	TargetCharacter->GetComponents<UActorComponent>(ResetActorComponents);
	for (UActorComponent* Component : ResetActorComponents)
	{
		if(!Visible)
		{
			Component->ResetToDefaultsForCache();
		}
	}

	// 动画恢复
	if (USkeletalMeshComponent* MainMesh = TargetCharacter->GetMainMesh())
	{
		if (UBaseAnimInstance* AnimInstance = Cast<UBaseAnimInstance>(MainMesh->GetAnimInstance()))
		{
			AnimInstance->ResetToDefaultsForCache();	
		}
	}
	
	
	//材质恢复
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGUEActorManager::ResetCachedUEActor RevertMaterial");
	if (UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(TargetCharacter))
	{
		if(!Visible)
		{
			MaterialManager->RevertMaterialAndMaterialParamsOnActorDestroy(KGUtils::GetIDByObject(TargetCharacter), true);
		}
	}
}

bool UKGUEActorManager::TryUseUEActorCache(KGEntityID EntID, const FTransform& Transform)
{
	if(EnableUEActorCache)
	{
		if (ICppEntityInterface* ExistedLuaEntity = GetLuaEntity(EntID))
		{
			TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGUEActorManager::TryUseUEActorCache");
			bool IsInMorph = ExistedLuaEntity->GetIsInMorph();
			if(IsInMorph)
			{
				UE_LOG(UKGUEActorManagerLog, Log, TEXT("TryUseUEActorCache failed EntityID: %lld because IsInMorph!"), EntID);
				return false;
			}
			int32 AppearanceChangeCount = ExistedLuaEntity->GetAppearanceChangeCount();
			if(EnableUEActorMainPlayerCache && ExistedLuaEntity->GetIsMainPlayer())
			{
				ABaseCharacter* TargetCharacter = Cast<ABaseCharacter>(MainPlayerCache);
				if (IsValid(TargetCharacter) && TargetCharacter->GetAppearanceChangeCount() == AppearanceChangeCount)
				{
					if(HandlePopCachedUEActor(MainPlayerCache, Transform))
					{
						OnActorLoaded(EntID, MainPlayerCache, true);
						MainPlayerCache = nullptr;
						return true;
					}
				}
			}
			else if(EnableUEActorAOIPlayerCache && ExistedLuaEntity->GetIsAvatar())
			{
				AActor* CachedAvatar = TryGetCachedAvatarPlayer(EntID, AppearanceChangeCount);
				if(HandlePopCachedUEActor(CachedAvatar, Transform))
				{
					OnActorLoaded(EntID, CachedAvatar, true);
					return true;
				}
			}
			else if(EnableUEActorNPCCache && ExistedLuaEntity->GetIsNpc() && !ExistedLuaEntity->GetIsBoos() && !ExistedLuaEntity->GetIsNpcGhostClone())
			{
				AActor* CachedAvatar = TryGetCachedAvatarPlayer(EntID, AppearanceChangeCount);
				if(HandlePopCachedUEActor(CachedAvatar, Transform))
				{
					OnActorLoaded(EntID, CachedAvatar, true);
					return true;
				}
			}
			else if(EnableUEActorGhostCloneCache && ExistedLuaEntity->GetIsNpc() && ExistedLuaEntity->GetIsNpcGhostClone())
			{
				//NpcGhostClone是服务器创建的NPC每次释放都是新的EntityID，所以特殊处理
				if (ICppEntityInterface* OwnerLuaEntity = GetLuaEntity(ExistedLuaEntity->GetEntityData().FinalOwnerID))
				{
					if (ABaseCharacter* BindedActor = Cast<ABaseCharacter>(OwnerLuaEntity->GetBindedActor()))
					{
						//Owner变身了，还使用分身技能
						IsInMorph = OwnerLuaEntity->GetIsInMorph();
						if(IsInMorph)
						{
							return false;
						}

						//Owner的外观变化
						AppearanceChangeCount = ExistedLuaEntity->GetAppearanceChangeCount();
						if(AActor* GhostCloneCache = BindedActor->GetGhostCloneCache(AppearanceChangeCount))
						{
							if(HandlePopCachedUEActor(GhostCloneCache, Transform))
							{
								OnActorLoaded(EntID, GhostCloneCache, true);
								return true;
							}
						}
					}
				}
			}
		}
	}
	return false;
}

//Push到缓存池,如果失败要销毁
bool UKGUEActorManager::TryPushUEActorCache(KGEntityID EntID, AActor* Actor)
{
	if(EnableUEActorCache)
	{
		
		if (ICppEntityInterface* ExistedLuaEntity = GetLuaEntity(EntID))
		{
			TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGUEActorManager::TryPushUEActorCache");
			const bool AppearanceDone = ExistedLuaEntity->GetIsAppearanceDone();
			const bool IsInMorph = ExistedLuaEntity->GetIsInMorph();
			const bool CacheMainPlayer = EnableUEActorMainPlayerCache && ExistedLuaEntity->GetIsMainPlayer();
			const bool CacheAOI = EnableUEActorAOIPlayerCache && ExistedLuaEntity->GetIsAvatar();
			//Boos比较重要，也不太需要缓存
			const bool CacheNPC = EnableUEActorNPCCache && ExistedLuaEntity->GetIsNpc() && !ExistedLuaEntity->GetIsBoos() && !ExistedLuaEntity->GetIsNpcGhostClone();
			//NpcGhostClone是服务器创建的NPC每次释放都是新的EntityID，所以特殊处理
			const bool CacheGhostClone = EnableUEActorGhostCloneCache && ExistedLuaEntity->GetIsNpc() && ExistedLuaEntity->GetIsNpcGhostClone();

			if(!AppearanceDone || IsInMorph)
			{
				return false;
			}
			
			if(CacheMainPlayer)
			{
				if (ABaseCharacter* TargetCharacter = Cast<ABaseCharacter>(Actor))
				{
					// 确保之前的缓存被正确清理
					if (IsValid(MainPlayerCache) && MainPlayerCache != TargetCharacter)
					{
						DestroyUEActor(MainPlayerCache);
						MainPlayerCache = nullptr;
					}

					// 缓存当前Actor但不立即销毁
					if(HandlePushCachedUEActor(TargetCharacter, false))
					{
						MainPlayerCache = TargetCharacter;
						return true;
					}
				}
			}
			else if( CacheAOI || CacheNPC)
			{
				AActor* AvatarPlayerUEActor = nullptr;
				if(AvatarPlayerCacheMap.Contains(EntID))
				{
					AvatarPlayerUEActor = AvatarPlayerCacheMap[EntID];
				}

				if (ABaseCharacter* TargetCharacter = Cast<ABaseCharacter>(Actor))
				{
					// 确保之前的缓存被正确清理
					if (IsValid(AvatarPlayerUEActor) && AvatarPlayerUEActor!= TargetCharacter)
					{
						DestroyUEActor(TargetCharacter);
					}
					// 缓存当前Actor但不立即销毁
					if(HandlePushCachedUEActor(TargetCharacter))
					{
						AddAvatarPlayerCache(EntID,TargetCharacter);
						return true;
					}
				}
			}
			else if(CacheGhostClone)
			{
				if (ICppEntityInterface* OwnerLuaEntity = GetLuaEntity(ExistedLuaEntity->GetEntityData().FinalOwnerID))
				{
					if (ABaseCharacter* BindedActor = Cast<ABaseCharacter>(OwnerLuaEntity->GetBindedActor()))
					{
						// 缓存当前Actor但不立即销毁
						if(HandlePushCachedUEActor(Actor) && BindedActor->AddGhostCloneCache(Actor,ExistedLuaEntity->GetAppearanceChangeCount()))
						{
							return true;
						}
					}
				}
			}
		}
	}
	return false;
}

void UKGUEActorManager::ResetUEActorCacheCapacity(int Capacity)
{
	if(Capacity<=0)
	{
		Capacity = 1;
	}
	EntityIDToAvatarPlayerLruCache.Empty(Capacity);
	UpdateAvatarPlayerLruCache();
	AvatarPlayerCacheHitCount = 0;
	AvatarPlayerCacheMissCount = 0;
}

void UKGUEActorManager::UpdateAvatarPlayerLruCache()
{
	float CurrentTime = 0.0F;
	if (UWorld* InWorld = GetSpawnActorWorld())
	{
		CurrentTime = InWorld->GetTimeSeconds();
	}

	for (TLruCache<int64, double>::TIterator Iter{EntityIDToAvatarPlayerLruCache}; Iter; ++Iter)
	{
		if(CurrentTime - Iter.Value() > AvatarPlayerLruCacheTime)
		{
			Iter.RemoveCurrentAndIncrement();
			break;
		}
	}
	
	for (auto It = AvatarPlayerCacheMap.CreateIterator(); It; ++It)
	{
		auto& Key = It.Key();
		if (!EntityIDToAvatarPlayerLruCache.Contains(Key))
		{
			AActor* AvatarActor = It.Value();
			if (IsValid(AvatarActor))
			{
				IC7ActorInterface* C7ActorInterface = Cast<IC7ActorInterface>(AvatarActor);
				if (C7ActorInterface)
				{
					int64 EntID = C7ActorInterface->GetEntityUID();
					int64 ActorID = KGUtils::GetIDByObject(AvatarActor);
					CallLuaFunction("KCB_OnActorDestoryByUEActorCache", EntID, ActorID);
				}
				DestroyUEActor(AvatarActor);
			}
			It.RemoveCurrent();
		}
	}

	UE_LOG(UKGUEActorManagerLog, Log, TEXT("[UKGUEActorManager::UpdateAvatarPlayerLruCache] AvatarPlayerCacheMap : %d "), AvatarPlayerCacheMap.Num());
}
	
void UKGUEActorManager::AddAvatarPlayerCache(KGEntityID EntityID, AActor* AvatarPlayerActor)
{
	AvatarPlayerCacheMap.Emplace(EntityID, AvatarPlayerActor);
	int64 ActorID = KGUtils::GetIDByObject(AvatarPlayerActor);
	UE_LOG(UKGUEActorManagerLog, Log, TEXT("Add AvatarPlayerCache EntityID: %lld ActorID: %lld"), EntityID, ActorID);
	float CacheStartTime = 0.0F;
	if (UWorld* InWorld = GetSpawnActorWorld())
	{
		CacheStartTime = InWorld->GetTimeSeconds();
	}
	EntityIDToAvatarPlayerLruCache.Add(EntityID,CacheStartTime);
	UpdateAvatarPlayerLruCache();
}

AActor* UKGUEActorManager::TryGetCachedAvatarPlayer(KGEntityID EntityID,int32 AppearanceChangeCount)
{
	if(AvatarPlayerCacheMap.Contains(EntityID))
	{
		auto& actor = AvatarPlayerCacheMap[EntityID];

		ABaseCharacter* TargetCharacter = Cast<ABaseCharacter>(actor);
		//如果失效就不处理，等待缓存池的自动回收机制
		if (IsValid(TargetCharacter) && TargetCharacter->GetAppearanceChangeCount() != AppearanceChangeCount)
		{
			AvatarPlayerCacheMissCount++;
			return nullptr;
		}

		AvatarPlayerCacheHitCount ++;
		AvatarPlayerCacheMap.Remove(EntityID);
		EntityIDToAvatarPlayerLruCache.Remove(EntityID);
		int64 ActorID = KGUtils::GetIDByObject(actor);
		UE_LOG(UKGUEActorManagerLog, Log, TEXT("Get CachedAvatarPlayer EntityID: %lld ActorID: %lld"), EntityID, ActorID);
		return actor;
	}
	AvatarPlayerCacheMissCount++;
	return nullptr;
}

#pragma endregion

void UKGUEActorManager::NativeUninit()
{
	bMgrInit = false;
	Super::NativeUninit();
}

void UKGUEActorManager::OnPostLoadMapWithWorld(UWorld* World)
{
	if(World == nullptr || World->PersistentLevel == nullptr)
	{
		return;
	}
	TickFunction.UnRegisterTickFunction();
	TickFunction.Manager = this;
	TickFunction.TickGroup = ETickingGroup::TG_PrePhysics;
	TickFunction.RegisterTickFunction(World->PersistentLevel);
	TickFunction.SetPriorityIncludingPrerequisites(true);
}

void UKGUEActorManager::Tick(float DeltaTime)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGUEActorManager_Tick");
	QUICK_SCOPE_CYCLE_COUNTER(UKGUEActorManager_Tick);
	
	ActorLoader->Tick(DeltaTime);

	TickActorCacheTime += DeltaTime;
	if(TickActorCacheTime > TickActorCacheIntervalTime)
	{
		TickActorCacheTime = 0.0F;
		UpdateAvatarPlayerLruCache();
	}

#if !UE_BUILD_SHIPPING
	if (GEnableKGUEActorManagerStat)
	{
		FString MsgActorLoader = FString::Printf(TEXT("ActorLoader : EnableFrameLimit[%s], ClassMap Num[%d], ActorLoadClassQueue Num[%d], ActorSpawnQueue Num[%d]"),
			ActorLoader->bEnableFrameLimit ? TEXT("True") : TEXT("False"), ActorLoader->ClassMap.Num(),
			ActorLoader->ActorLoadClassQueue.Num(), ActorLoader->ActorSpawnQueue.Num());
		GEngine->AddOnScreenDebugMessage(INDEX_NONE, .0f, FColor::Green, MsgActorLoader);

		int Sum = AvatarPlayerCacheHitCount+AvatarPlayerCacheMissCount;
		float hitRate = 0.0F;
		if(Sum > 0)
		{
			hitRate = static_cast<float>(AvatarPlayerCacheHitCount) / Sum;
		}
		FString MsgUEActorCache = FString::Printf(TEXT("UEActorCache : HitRate[%2f] EnableUEActorCache[%s][%s][%s][%s][%s], AvatarPlayerCacheMap Num[%d], EntityIDToAvatarPlayerLruCache Num[%d]"),
			hitRate, EnableUEActorCache ? TEXT("True") : TEXT("False"), EnableUEActorMainPlayerCache ? TEXT("True") : TEXT("False"), EnableUEActorAOIPlayerCache ? TEXT("True") : TEXT("False"),
			EnableUEActorNPCCache ? TEXT("True") : TEXT("False"), EnableUEActorGhostCloneCache ? TEXT("True") : TEXT("False"),
			AvatarPlayerCacheMap.Num(), EntityIDToAvatarPlayerLruCache.Num());
		GEngine->AddOnScreenDebugMessage(INDEX_NONE, .0f, FColor::Green, MsgUEActorCache);
	}
#endif
}

void UKGUEActorManager::EnableFrameLimit(bool Enable)
{
	if(ActorLoader)
	{
		ActorLoader->EnableFrameLimit(Enable);
	}
};

void UKGUEActorManager::SetFrameLimitParam(float LoadTimeBudget, float SpawnTimeBudget, int32 MaxActorsToSpawn, int32 MinActorsToSpawn)
{
	if(ActorLoader)
	{
		ActorLoader->SetFrameLimitParam(LoadTimeBudget, SpawnTimeBudget, MaxActorsToSpawn, MinActorsToSpawn);
	}
};

bool UKGUEActorManager::BindActorToEntity(KGEntityID InEntID, AActor* InActor, bool IsOwnSpawned)
{
	if (!LuaEntityMap.Contains(InEntID)) {
		UE_LOG(UKGUEActorManagerLog, Error, TEXT("[UKGUEActorManager::BindActorToEntity] can not find entity -> %lld"), InEntID);
		return false;
	}

	KGActorID ActorID = GetIDByActor(InActor);
	if (Entity2Actor.Contains(InEntID)) {
		UE_LOG(UKGUEActorManagerLog, Error, TEXT("[UKGUEActorManager::BindActorToEntity] Entity Already Bind To Actor -> %lld %lld"), InEntID, ActorID);
		return false;
	}
	
	if (Actor2Entity.Contains(ActorID)) {
		UE_LOG(UKGUEActorManagerLog, Error, TEXT("[UKGUEActorManager::BindActorToEntity] Actor Already Bind To Entity -> %lld %lld,  Bound Entity:%lld"), InEntID, ActorID, Actor2Entity[ActorID]);
		return false;
	}

	//UE_LOG(UKGUEActorManagerLog, Log, TEXT("[UKGUEActorManager::BindActorToEntity] Bind Actor: %lld   to EntityId:%lld"), ActorID, InEntID);
	Entity2Actor.Add(InEntID, ActorID);
	Actor2Entity.Add(ActorID, InEntID);
	auto Ent = Cast<ICppEntityInterface>(LuaEntityMap[InEntID]);
	if (IsOwnSpawned) {
		Ent->GetLuaEntityBase()->BindActorByOwnSpawned(InActor);
	}
	else {
		Ent->GetLuaEntityBase()->BindActorByLevelSpawned(InActor);
	}

	return true;
}

void UKGUEActorManager::UnbindActorFromEntity(KGEntityID InEntID)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGUEActorManager::UnbindActorFromEntity");
	KGActorID ActorID = KG_INVALID_ACTOR_ID;
	if (Entity2Actor.Contains(InEntID)) {
		ActorID = Entity2Actor[InEntID];
		Actor2Entity.Remove(ActorID);
		Entity2Actor.Remove(InEntID);
	}
	
	if (LuaEntityMap.Contains(InEntID)) {
		auto Ent = Cast<ICppEntityInterface>(LuaEntityMap[InEntID]);
		Ent->GetLuaEntityBase()->UnbindActor();
		Ent->ResetValuesInUEActor();
	}

	//UE_LOG(UKGUEActorManagerLog, Log, TEXT("unbind actor from entity -> %lld,  ActorId -> %lld"), InEntID, ActorID);
}

void UKGUEActorManager::BeforeUnbindActorFromEntity(KGEntityID InEntID)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGUEActorManager::BeforeUnbindActorFromEntity");
	//UE_LOG(UKGUEActorManagerLog, Log, TEXT("before unbind actor from entity -> %lld"), InEntID);
	
	if (LuaEntityMap.Contains(InEntID))
	{
		auto Ent = Cast<ICppEntityInterface>(LuaEntityMap[InEntID]);
		Ent->BeforeUnbindActor();
	}
}

bool UKGUEActorManager::IsLuaEntityExist(KGEntityID InEntID) {
	return LuaEntityMap.Contains(InEntID);
}

ICppEntityInterface* UKGUEActorManager::GetLuaEntity(KGEntityID InEntID) {
	if (!LuaEntityMap.Contains(InEntID)) {
		return nullptr;
	}
	return Cast<ICppEntityInterface>(LuaEntityMap[InEntID]);
}

ICppEntityInterface* UKGUEActorManager::GetLuaEntityByActorID(KGActorID ActorID) {
	if (!Actor2Entity.Contains(ActorID)) {
		return nullptr;
	}
	 
	return GetLuaEntity(Actor2Entity[ActorID]);
}

KGEntityID UKGUEActorManager::GetLuaEntityIDByActorID(KGActorID ActorID)
{
	if (!Actor2Entity.Contains(ActorID)) {
		return 0;
	}

	return Actor2Entity[ActorID];
}

ICppEntityInterface* UKGUEActorManager::GetLuaEntity(UObject* InContext, KGEntityID InEntID)
{
	auto ActorManager = GetInstance(InContext);
	if (!ActorManager)
	{
		UE_LOG(LogTemp, Warning, TEXT("[GetLuaEntity] get ActorManager failed"));
		return nullptr;
	}
	return ActorManager->GetLuaEntity(InEntID);
}

ICppEntityInterface* UKGUEActorManager::GetLuaEntityByActor(AActor* Actor) {
	if (!Actor) {
		return nullptr;
	}

	auto ActorManager = GetInstance(Actor);
	if (!ActorManager)
	{
		UE_LOG(LogTemp, Warning, TEXT("[GetLuaEntityByActor] get ActorManager failed"));
		return nullptr;
	}
	
	return ActorManager->GetLuaEntityByActorID(ActorManager->GetIDByActor(Actor));
}

KGEntityID UKGUEActorManager::GetLuaEntityIDByActor(AActor* Actor)
{
	if (!Actor) {
		return 0;
	}

	auto ActorManager = GetInstance(Actor);
	if (!ActorManager)
	{
		UE_LOG(LogTemp, Warning, TEXT("[GetLuaEntityIDByActor] get ActorManager failed"));
		return 0;
	}
	
	return ActorManager->GetLuaEntityIDByActorID(ActorManager->GetIDByActor(Actor));
}

void UKGUEActorManager::OnActorDestoryByUE(AActor* Actor)
{
	KGActorID ActorID = GetIDByActor(Actor);
	KGEntityID* EntID = Actor2Entity.Find(ActorID);
	if (EntID) {
		UE_LOG(UKGUEActorManagerLog, Warning, TEXT("[UKGUEActorManager::OnActorDestoryByUE]ActorDestoryByUE Before Entity Unbind! ActorName:%s, EntityID:%lld, ActorID:%lld"), *Actor->GetName(), EntID, ActorID);
		BeforeUnbindActorFromEntity(*EntID);
		UnbindActorFromEntity(*EntID);
		CallLuaFunction("KCB_OnActorDestory", *EntID, ActorID);
	}

	InnerRemoveActor(Actor);
}

void UKGUEActorManager::ClearLoaderClassMap()
{
	if (IsValid(ActorLoader)) {
		ActorLoader->ClearClassMap();
	}
}
KGActorID UKGUEActorManager::GetActorIDByEntityID(KGEntityID InEntID)
{
	if(Entity2Actor.Contains(InEntID))
		return Entity2Actor[InEntID];
	return KG_INVALID_ACTOR_ID;
}

AActor* UKGUEActorManager::GetActorByEntityID(KGEntityID InEntityID)
{
	KGActorID* AID = Entity2Actor.Find(InEntityID);
	if (AID == nullptr) 
	{
		UE_LOG(UKGUEActorManagerLog, Error, TEXT("[UKGUEActorManager::GetActorByEntityID] EntityID -> %lld not found in Entity2Actor map"), InEntityID);
		return nullptr;
	}

	if (!IS_VALID_ACTOR_ID(*AID)) 
	{
		UE_LOG(UKGUEActorManagerLog, Error, TEXT("[UKGUEActorManager::GetActorByEntityID] Invalid ActorID -> %lld for EntityID -> %lld"), AID, InEntityID);
		return nullptr;
	}

	AActor** Actor = ActorMap.Find(*AID);
	if (!Actor || !IsValid(*Actor)) 
	{
		UE_LOG(UKGUEActorManagerLog, Error, TEXT("[UKGUEActorManager::GetActorByEntityID] Actor not found for EntityID -> %lld"), InEntityID);
		return nullptr;
	}

	return *Actor;
}


void UKGUEActorManager::InnerRemoveActor(AActor* Actor)
{
	if (!Actor || !IsValid(Actor)) {
		UE_LOG(UKGUEActorManagerLog, Error, TEXT("[UKGUEActorManager::InnerRemoveActor]  actor is invalid !!"));
		return;
	}

	Actor->OnDestroyed.RemoveDynamic(this, &UKGUEActorManager::OnActorDestoryByUE);

	KGActorID ActorID = GetIDByActor(Actor);
	if (!IS_VALID_ACTOR_ID(ActorID)) {
		UE_LOG(UKGUEActorManagerLog, Error, TEXT("[UKGUEActorManager::InnerRemoveActor]  Invalid ActorID -> %lld"), ActorID);
		return;
	}

	ActorMap.Remove(ActorID);
}

UWorld* UKGUEActorManager::GetSpawnActorWorld()
{
#if WITH_EDITOR
	if (OverrideWorld.IsValid())
		return OverrideWorld.Get();
#endif
	return Super::GetWorld();
}

#pragma region LuaApi
// Self, Entity, EntityID, EntityType, ClassPath, X, Y, Z, Pitch, Roll, Yaw
bool UKGUEActorManager::CreateEntity(lua_State* L, KGEntityID EntityID, float X, float Y, float Z, float Pitch, float Yaw, float Roll)
{
	KGEntityID EntID = EntityID;
	if (LuaEntityMap.Contains(EntID)) {
		UE_LOG(UKGUEActorManagerLog, Error, TEXT("duplicate create lua script entity -> %lld"), EntID);
		return false;
	}


	UObject* EntityObject = GetOrCreateCppEntityObject();
	if (EntityObject == nullptr)
	{
		//不大可能出现这种情况，如果出现了，打印日志，并返回失败，需要人工确认
		UE_LOG(UKGUEActorManagerLog, Error, TEXT("create cpp entity object failed -> %lld"), EntID);
		return false;
	}
	ICppEntityInterface* Ent = Cast<ICppEntityInterface>(EntityObject);
	if (Ent == nullptr)
	{
		//不大可能出现这种情况，如果出现了，打印日志，并返回失败，需要人工确认
		UE_LOG(UKGUEActorManagerLog, Error, TEXT("create cpp entity object cast to ICppEntityInterface failed -> %lld"), EntID);
		return false;
	}

	Ent->Init(EntID, FVector(X, Y, Z), FRotator(Pitch, Yaw, Roll));
	if (!Ent->GetLuaEntityBase()->InitLua(L)) {
		UE_LOG(UKGUEActorManagerLog, Error, TEXT("init lua entity failed -> %lld"), EntID);
		return false;
	}

	Ent->SetEntityManager(this);
	LuaEntityMap.Add(EntID, EntityObject);
	
	KGLuaObjectUtils::push(L, "UKGCppEntity", EntityObject);
	Ent->GetLuaEntityBase()->RefSelf(L, lua_gettop(L));
	Ent->GetLuaEntityBase()->BindLuaObject(L, 2);
	return true;
}

// self, EntityID
void UKGUEActorManager::DestroyEntity(lua_State* L, KGEntityID InEntID)
{
	//TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGUEActorManager::DestroyEntity");
	if (!LuaEntityMap.Contains(InEntID)) {
		UE_LOG(UKGUEActorManagerLog, Error, TEXT("destroy actor error, can not find actor for entity -> %lld"), InEntID);
		return;
	}

	//UE_LOG(UKGUEActorManagerLog, Log, TEXT("destroy entity -> %lld"), InEntID);
	UObject* Obj = LuaEntityMap[InEntID];
	auto Ent = Cast<ICppEntityInterface>(Obj);
	if (Ent == nullptr)
	{
		UE_LOG(UKGUEActorManagerLog, Error, TEXT("DestroyEntity error, entity cast to ICppEntityInterface failed -> %lld"), InEntID);
		return;
	}

	LuaEntityMap.Remove(InEntID);
	Ent->GetLuaEntityBase()->FiniLua(L);
	ReleaseCppEntityObject(Obj);
}

void UKGUEActorManager::DestroyUEActor(AActor* Actor)
{
	if (!IsValid(Actor))
	{
		return;
	}
	if (UWorld* World = Actor->GetWorld())
	{
		World->DestroyActor(Actor);
	}
}

// 如果对象池中有可用的对象，则直接返回，否则创建新的对象返回
UObject* UKGUEActorManager::GetOrCreateCppEntityObject()
{
	int num = CppEntityPool.Num();
	if (num > 0)
	{
		UObject* EntityObject = CppEntityPool.Pop(EAllowShrinking::No);

		if (EntityObject == nullptr)
		{
			//理论不会出现这个情况，如果出现了，先打印日志日志，并继续创建新的对象不从对象池中取
			UE_LOG(UKGUEActorManagerLog, Warning, TEXT("GetOrCreateCppEntityObject : Pop CppEntityPool return nullptr . CppEntityPool Num[%d] "), CppEntityPool.Num());
		}
		else
		{
			return EntityObject;
		}
	}

	ICppEntityModule* LuaScriptAPIModule = FModuleManager::GetModulePtr<ICppEntityModule>("KGCppEntity");
	checkf(LuaScriptAPIModule, TEXT("Fata Error, Get ICppEntityModule failed!"));
	auto EntityObject = LuaScriptAPIModule->CreateCppEntity();

	return EntityObject;
}

void UKGUEActorManager::ReleaseCppEntityObject(UObject* InObject)
{
	if (InObject == nullptr)
	{
		UE_LOG(UKGUEActorManagerLog, Warning, TEXT("ReleaseCppEntityObject : InObject is nullptr"));
		return;
	}

	if (CppEntityPoolSize <= 0)
	{
		UE_LOG(UKGUEActorManagerLog, Warning, TEXT("ReleaseCppEntityObject : CppEntityPoolSize is 0, not initialized, check!"));
		return;
	}

	// 超过期望大小上限， 打印异常日志，不做回收优化，待人工确认合理性
	int num = CppEntityPool.Num();
	if (num >= CppEntityPoolSize)
	{
		UE_LOG(UKGUEActorManagerLog, Warning, TEXT("ReleaseCppEntityObject : CppEntityPool is full, just ignore this object"));
		return;
	}

	CppEntityPool.Push(InObject);
}

// Self, Entity, EntityID, EntityType, ClassPath, X, Y, Z, Pitch, Roll, Yaw
int UKGUEActorManager::CreateActorAndCppEntity(lua_State* L)
{
	if (!lua_istable(L, 2)) {
		UE_LOG(UKGUEActorManagerLog, Error, TEXT("create entity arg 2 must be entity table"));
		return 0;
	}

	KGEntityID EntID = luaL_checkinteger(L, 3);
	FString ClassPath = (FString)luaL_checkstring(L, 4);

	float X = luaL_checknumber(L, 5);
	float Y = luaL_checknumber(L, 6);
	float Z = luaL_checknumber(L, 7);
	float Pitch = luaL_checknumber(L, 8);
	float Yaw = luaL_checknumber(L, 9);
	float Roll = luaL_checknumber(L, 10);

	bool NeedPreload = (bool)luaL_checkinteger(L, 11);
	bool NeedSyncLoad = (bool)luaL_checkinteger(L, 12);

	if (!CreateEntity(L, EntID, X, Y, Z, Pitch, Yaw, Roll)) {
		return 0;
	}

	LoadActor(EntID, ClassPath, X, Y, Z, Pitch, Yaw, Roll, NeedPreload, NeedSyncLoad);
	return 1;
}

// Self, EntityID
int UKGUEActorManager::DestroyActorAndCppEntity(lua_State* L)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGUEActorManager::DestroyActorAndCppEntity");
	KGEntityID EntID = luaL_checkinteger(L, 2);

	BeforeUnbindActorFromEntity(EntID);
	DestoryActorByEntityID(EntID);
	UnbindActorFromEntity(EntID);
	DestroyEntity(L, EntID);
	return 0;
}

int UKGUEActorManager::CreateCppEntityForBindActorLater(lua_State* L)
{
	KGEntityID EntID = luaL_checkinteger(L, 3);
	float X = luaL_checknumber(L, 4);
	float Y = luaL_checknumber(L, 5);
	float Z = luaL_checknumber(L, 6);
	float Pitch = luaL_checknumber(L, 7);
	float Yaw = luaL_checknumber(L, 8);
	float Roll = luaL_checknumber(L, 9);

	if (!CreateEntity(L, EntID, X, Y, Z, Pitch, Yaw, Roll)) {
		return 0;
	}

	return 1;
}

int UKGUEActorManager::BindLevelSpawnedActorWithCppEntity(lua_State* L)
{
	KGEntityID EntID = luaL_checkinteger(L, 2);
	KGActorID ActorID = luaL_checkinteger(L, 3);
	AActor* ToBindActor = KGUtils::GetActorByID(ActorID);
	if (!ToBindActor) {
		UE_LOG(UKGUEActorManagerLog, Error,
			TEXT("[BindLevelSpawnedActorWithCppEntity]  Invalid Actor Arg When Binding, UID: %lld."), EntID);
		return 0;
	}
	
	BindActorToEntity(EntID, ToBindActor, false);
	return 0;
}

int UKGUEActorManager::CreateCppEntityAndBindLevelSpawnedActor(lua_State* L)
{
	KGEntityID EntID = luaL_checkinteger(L, 3);

	KGActorID ActorID = luaL_checkinteger(L, 4);
	AActor* ToBindActor = KGUtils::GetActorByID(ActorID);
	if (!ToBindActor) {
		UE_LOG(UKGUEActorManagerLog, Error,
			TEXT("[CreateCppEntityAndBindLevelSpawnedActor]  Invalid Actor Arg When Binding, UID: %lld."), EntID);
		return 0;
	}

	FTransform Transform = ToBindActor->GetTransform();
	FVector Location = Transform.GetLocation();
	FRotator Rotator = Transform.GetRotation().Rotator();

	if (!CreateEntity(L, EntID, Location.X, Location.Y, Location.Z, Rotator.Pitch, Rotator.Yaw, Rotator.Roll)) {
		UE_LOG(UKGUEActorManagerLog, Error,
			TEXT("[CreateCppEntityAndBindLevelSpawnedActor]  Cannot Create UKGCppEntity, UID: %lld."), EntID);
		return 0;
	}

	BindActorToEntity(EntID, ToBindActor, false);
	return 1;
}

int UKGUEActorManager::CreateActorBindedToExistedCppEntity(lua_State* L)
{
	KGEntityID EntID = luaL_checkinteger(L, 2);
	ICppEntityInterface* ExistedLuaEntity = GetLuaEntity(EntID);
	if (!ExistedLuaEntity) {
		UE_LOG(UKGUEActorManagerLog, Error,
			TEXT("[CreateActorBindedToExistedCppEntity]  Cannot Find LuaEntity, UID:%lld."), EntID);
		return 0;
	}

	FString ClassPath = (FString)luaL_checkstring(L, 3);
	const FVector& Location = ExistedLuaEntity->GetLocation();
	const FRotator& Rotator = ExistedLuaEntity->GetRotation();

	bool NeedPreload = (bool)luaL_checkinteger(L, 4);
	bool NeedSyncLoad = (bool)luaL_checkinteger(L, 5);

	LoadActor(EntID, ClassPath, Location.X, Location.Y, Location.Z, Rotator.Pitch, Rotator.Yaw, Rotator.Roll,
		NeedPreload, NeedSyncLoad);
	return 0;
}

int UKGUEActorManager::UnbindAndDestroyActor(lua_State* L)
{
	KGEntityID EntID = luaL_checkinteger(L, 2);
	BeforeUnbindActorFromEntity(EntID);
	DestoryActorByEntityID(EntID);
	UnbindActorFromEntity(EntID);
	return 0;
}

// Self, EntityID
int UKGUEActorManager::UnbindLevelSpawnedActorAndDestroyCppEntity(lua_State* L)
{
	KGEntityID EntID = luaL_checkinteger(L, 2);
	BeforeUnbindActorFromEntity(EntID);
	// Do not Destroy The Actor
	UnbindActorFromEntity(EntID);
	DestroyEntity(L, EntID);
	return 0;
}


int UKGUEActorManager::UnbindLevelSpawnedActor(lua_State* L)
{
	KGEntityID EntID = luaL_checkinteger(L, 2);
	BeforeUnbindActorFromEntity(EntID);
	UnbindActorFromEntity(EntID);
	
	if (Entity2Actor.Contains(EntID))
	{
		KGActorID ActorID = Entity2Actor[EntID];
		if (!ActorMap.Contains(ActorID))
		{
			UE_LOG(UKGUEActorManagerLog, Error, TEXT("[UKGUEActorManager::UnbindLevelSpawnedActor] can not find Actor for Entity -> %lld"), EntID);
			return 0;
		}
		AActor* Actor = ActorMap[ActorID];
		if (IsValid(Actor))
		{
			InnerRemoveActor(Actor);
		}
	}
	return 1;
}

// todo 等class ID版本脚本全部修正掉 ，  去除掉class 类传入作为参数的接口
// self, Entity, EntityID, InClass, X, Y, Z, Pitch, Yaw, Roll
int UKGUEActorManager::CreateActorWithBPClassAndBindToExistedCppEntity(lua_State* L)
{
	KGEntityID EntID = luaL_checkinteger(L, 2);

	ICppEntityInterface* ExistedLuaEntity = GetLuaEntity(EntID);
	if (!ExistedLuaEntity) {
		UE_LOG(UKGUEActorManagerLog, Error,
			TEXT("[CreateActorWithBPClassAndBindToExistedCppEntity]  Cannot Find LuaEntity, UID:%lld."), EntID);
		return 0;
	}

	int ClsIdx = 3;
	CheckUD(UClass, L, ClsIdx);
	UClass* InClass = UD;

	UWorld* InWorld = GetSpawnActorWorld();
	if (InWorld == nullptr || IsValid(InWorld) == false)
	{
		UE_LOG(LogTemp, Warning, TEXT("CreateActorWithBPClassAndBindToExistedCppEntity InWorld is valid"));
		return 0;
	}

	if (InClass == nullptr || IsValid(InClass) == false)
	{
		UE_LOG(LogTemp, Warning, TEXT("CreateActorWithBPClassAndBindToExistedCppEntity InClass is valid"));
		return 0;
	}
	FVector Location = ExistedLuaEntity->GetLocation();
	FRotator Rotator = ExistedLuaEntity->GetRotation();
	AActor* NewActor = InWorld->SpawnActor(InClass, &Location, &Rotator, SpawnActorParameters);
	if (NewActor == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("CreateActorWithBPClassAndBindToExistedCppEntity  KGSpawnActor Spawn Actor Failed InClass[%s], InWorld[%s]"),
			*(InClass->GetPathName()), *(InWorld->GetPathName()));
		return 0;
	}

	if (!BindActorToEntity(EntID, NewActor, true)) {
		UE_LOG(UKGUEActorManagerLog, Error, TEXT("[UKGUEActorManager::CreateActorWithBPClassAndBindToExistedCppEntity] bind actor to entity failed -> %lld"), EntID);
		DestroyEntity(L, EntID);
		return 0;
	}

	NewActor->OnDestroyed.AddDynamic(this, &UKGUEActorManager::OnActorDestoryByUE);
	KGActorID ActorID = GetIDByActor(NewActor);
	ActorMap.Add(ActorID, NewActor);

	return 1;
}

// self, Entity, EntityID, InClassID, X, Y, Z, Pitch, Yaw, Roll
int UKGUEActorManager::CreateActorWithBPClassIDAndBindToExistedCppEntity(lua_State* L)
{
	KGEntityID EntID = luaL_checkinteger(L, 2);

	ICppEntityInterface* ExistedLuaEntity = GetLuaEntity(EntID);
	if (!ExistedLuaEntity) {
		UE_LOG(UKGUEActorManagerLog, Error,
			TEXT("[CreateActorWithBPClassIDAndBindToExistedCppEntity]  Cannot Find LuaEntity, UID:%lld."), EntID);
		return 0;
	}

	KGEntityID ClassID = luaL_checkinteger(L, 3);
	UClass* InClass = KGUtils::GetClassByID(ClassID);

	UWorld* InWorld = GetSpawnActorWorld();
	if (InWorld == nullptr || IsValid(InWorld) == false)
	{
		UE_LOG(LogTemp, Warning, TEXT("CreateActorWithBPClassIDAndBindToExistedCppEntity InWorld is valid"));
		return 0;
	}

	if (InClass == nullptr || IsValid(InClass) == false)
	{
		UE_LOG(LogTemp, Warning, TEXT("CreateActorWithBPClassIDAndBindToExistedCppEntity InClass is valid"));
		return 0;
	}
	FVector Location = ExistedLuaEntity->GetLocation();
	FRotator Rotator = ExistedLuaEntity->GetRotation();

	// 新增一个日志, 排查NaN的问题
	UE_LOG(UKGUEActorManagerLog, Log,
		TEXT("[CreateActorWithBPClassIDAndBindToExistedCppEntity]  Cannot Find LuaEntity, UID:%lld.  Pos NaN:%d  Rotate Nan:%d "),
		EntID, Location.ContainsNaN(), Rotator.ContainsNaN());
	
	AActor* NewActor = InWorld->SpawnActor(InClass, &Location, &Rotator, SpawnActorParameters);
	if (NewActor == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("CreateActorWithBPClassIDAndBindToExistedCppEntity  KGSpawnActor Spawn Actor Failed InClass[%s], InWorld[%s]"),
			*(InClass->GetPathName()), *(InWorld->GetPathName()));
		return 0;
	}

	if (!BindActorToEntity(EntID, NewActor, true)) {
		UE_LOG(UKGUEActorManagerLog, Error, TEXT("[UKGUEActorManager::CreateActorWithBPClassIDAndBindToExistedCppEntity] bind actor to entity failed -> %lld"), EntID);
		DestroyEntity(L, EntID);
		return 0;
	}

	NewActor->OnDestroyed.AddDynamic(this, &UKGUEActorManager::OnActorDestoryByUE);
	KGActorID ActorID = GetIDByActor(NewActor);
	ActorMap.Add(ActorID, NewActor);

	return 1;
}

// Self, ClassID, X, Y, Z, Pitch, Roll, Yaw
int UKGUEActorManager::SpawnActorAndCppEntity(lua_State* L)
{
	KGObjectID ClassID = luaL_checkinteger(L, 2);
	UClass* InClass = KGUtils::GetClassByID(ClassID);
	if (InClass == nullptr || IsValid(InClass) == false)
	{
		UE_LOG(LogTemp, Warning, TEXT("SpawnActor InClass is valid"));
		return 0;
	}

	UWorld* InWorld = GetSpawnActorWorld();
	if (InWorld == nullptr || IsValid(InWorld) == false)
	{
		UE_LOG(LogTemp, Warning, TEXT("SpawnActor InWorld is valid"));
		return 0;
	}

	float X = luaL_checknumber(L, 3);
	float Y = luaL_checknumber(L, 4);
	float Z = luaL_checknumber(L, 5);
	float Pitch = luaL_checknumber(L, 6);
	float Yaw = luaL_checknumber(L, 7);
	float Roll = luaL_checknumber(L, 8);
	FVector Location(X, Y, Z);
	FRotator Rotator(Pitch, Yaw, Roll);
	AActor* NewActor = InWorld->SpawnActor(InClass, &Location, &Rotator, SpawnActorParameters);
	if (NewActor == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("SpawnActor Failed InClass[%s], InWorld[%s]"),
			*(InClass->GetPathName()), *(InWorld->GetPathName()));
		return 0;
	}

	KGActorID ActorID = KGUtils::GetIDByObject(NewActor);
	KGEntityID EntID = ActorID;
	auto EntityObject = GetOrCreateCppEntityObject();
	auto Ent = Cast<ICppEntityInterface>(EntityObject);
	Ent->Init(EntID, FVector(X, Y, Z), FRotator(Pitch, Yaw, Roll));
	if (!Ent->GetLuaEntityBase()->InitLua(L)) {
		UE_LOG(UKGUEActorManagerLog, Error, TEXT("init lua entity failed -> %lld"), EntID);
		return false;
	}

	Ent->SetEntityManager(this);
	LuaEntityMap.Add(EntID, EntityObject);

	BindActorToEntity(EntID, NewActor, false);
	KGLuaObjectUtils::push(L, "UKGCppEntity", EntityObject);
	Ent->GetLuaEntityBase()->RefSelf(L, lua_gettop(L));
	
	ActorMap.Add(ActorID, NewActor);
	return 1;
}

void UKGUEActorManager::SetCppEntityPoolSize(int32 InSize)
{
	if (InSize < CPP_ENTITY_POOL_INIT_SIZE)
	{
		UE_LOG(UKGUEActorManagerLog, Warning, TEXT("SetCppEntityPoolSize : InSize[%d] < CPP_ENTITY_POOL_SIZE[%d] , just ignore this request"), InSize, CPP_ENTITY_POOL_INIT_SIZE);
		return;
	}

	if (InSize < CppEntityPool.Num())
	{
		UE_LOG(UKGUEActorManagerLog, Warning, TEXT("SetCppEntityPoolSize : InSize[%d] < CppEntityPool.Num[%d] , just ignore this request"), InSize, CppEntityPool.Num());
		return;
	}

	if (InSize == CppEntityPoolSize)
	{
		UE_LOG(UKGUEActorManagerLog, Log, TEXT("SetCppEntityPoolSize : InSize[%d] == CppEntityPoolSize[%d] , just ignore this request"), InSize, CppEntityPoolSize);
		return;
	}

	CppEntityPoolSize = InSize;
	CppEntityPool.Reserve(CppEntityPoolSize);
	UE_LOG(UKGUEActorManagerLog, Log, TEXT("SetCppEntityPoolSize : CppEntityPoolSize = %d"), CppEntityPoolSize);
}

KGObjectID UKGUEActorManager::KAPI_GetClassObjectIDByClassPath(const FString& ClassPath, bool bCacheClass)
{
	//内部会先尝试从内存种查找，就不自己重复查找了
	UClass* cls = LoadClass<UObject>(NULL, *ClassPath);
	if (IsValid(cls) == false)
	{
		UE_LOG(UKGUEActorManagerLog, Error, TEXT("KAPI_GetClassObjectIDByClassPath: can not find or load class : %s"), *ClassPath);
		return 0;
	}

	if (bCacheClass)
	{
		ClassList.AddUnique(cls);
	}

	return KGUtils::GetIDByObject(cls);
}

void UKGUEActorManager::KAPI_UnCacheClass(KGObjectID InClassObjectID)
{
	UClass* cls = KGUtils::GetClassByID(InClassObjectID);
	if (cls)
	{
		ClassList.RemoveSwap(cls);
	}
}

void UKGUEActorManager::KAPI_UnCacheAllClass()
{
	ClassList.Reset();
}

void UKGUEActorManager::NotifyLevelSpawnedActorDestroyedByUE(AActor* Actor)
{
	KGActorID ActorID = GetIDByActor(Actor);
	if (KGEntityID* EntityID = Actor2Entity.Find(ActorID)) {
		CallLuaFunction("KCB_OnLevelSpawnedActorDestroyedByUE", *EntityID, ActorID);
	}
}

bool UKGUEActorManager::ManuallyRegisterActorOnDestroyed(KGObjectID InActor)
{
	AActor* TargetActor = Cast<AActor>(KGUtils::GetObjectByID(InActor));
	if (TargetActor == nullptr)
	{
		return false;
	}

	if (!TargetActor->OnDestroyed.IsAlreadyBound(this, &UKGUEActorManager::NotifyLevelSpawnedActorDestroyedByUE))
	{
		TargetActor->OnDestroyed.AddDynamic(this, &UKGUEActorManager::NotifyLevelSpawnedActorDestroyedByUE);
	}
	
	if (TargetActor->OnDestroyed.IsAlreadyBound(this, &UKGUEActorManager::OnActorDestoryByUE))
	{
		TargetActor->OnDestroyed.RemoveDynamic(this, &UKGUEActorManager::OnActorDestoryByUE);
		TargetActor->OnDestroyed.AddDynamic(this, &UKGUEActorManager::OnActorDestoryByUE);
	}
	
	return true;
}

#pragma endregion LuaApi
