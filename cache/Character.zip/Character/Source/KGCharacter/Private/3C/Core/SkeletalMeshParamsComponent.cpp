// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Core/SkeletalMeshParamsComponent.h"


USkeletalMeshParamsComponent::USkeletalMeshParamsComponent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryComponentTick.bCanEverTick = false;
	bAutoActivate = false;
}

void USkeletalMeshParamsComponent::BeginPlay()
{
	Super::BeginPlay();
	
	// TSet<FString> ShouldCopyCategories;
	// const FName CategoryKey = TEXT("Category");
	// ShouldCopyCategories.Add(FString(L"Lighting"));
	// ShouldCopyCategories.Add(FString(L"Channels"));
	// ShouldCopyCategories.Add(FString(L"Rendering"));
	
	if (const UClass* MyClass = GetClass())
	{
		const USkeletalMeshParamsComponent* DefaultInstance = CastChecked<USkeletalMeshParamsComponent>(MyClass->GetDefaultObject());
		for(const FProperty* Property = MyClass->PropertyLink; Property != nullptr; Property = Property->PropertyLinkNext )
		{
			const bool bIsTransient = !!( Property->PropertyFlags & CPF_Transient );
			const bool bIsIdentical = Property->Identical_InContainer(this, DefaultInstance);
			const bool bIsComponent = !!(Property->PropertyFlags & (CPF_InstancedReference | CPF_ContainsInstancedReference));
			const bool bIsSafeToCopy = Property->HasAnyPropertyFlags(CPF_Edit);
			if(!bIsTransient && !bIsIdentical && !bIsComponent && bIsSafeToCopy)
			{
				ModifiedProperties.Add(Property->GetName());
			}
			
			// if (Property->GetMetaDataMap())
			// {
			// 	const FString *CategoryName = Property->GetMetaDataMap()->Find(CategoryKey);
			// 	if (!CategoryName)
			// 	{
			// 		continue;
			// 	}
			// 	if (ShouldCopyCategories.Find(*CategoryName))
			// 	{
			// 		const bool bIsTransient = !!( Property->PropertyFlags & CPF_Transient );
			// 		const bool bIsIdentical = Property->Identical_InContainer(this, DefaultInstance);
			// 		const bool bIsComponent = !!(Property->PropertyFlags & (CPF_InstancedReference | CPF_ContainsInstancedReference));
			// 		const bool bIsSafeToCopy = Property->HasAnyPropertyFlags(CPF_Edit);
			//
			// 		if(!bIsTransient && !bIsIdentical && !bIsComponent && bIsSafeToCopy)
			// 		{
			// 			ModifiedProperties.Add(Property->GetName());
			// 		}
			// 	}
			// }
		}
	}
}

// #if WITH_EDITOR
//
// void USkeletalMeshParamsComponent::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
// {
// 	Super::PostEditChangeProperty(PropertyChangedEvent);
// 	AActor* Owner = GetOwner();
// 	if (!Owner)
// 	{
// 		return;
// 	}
// 	
// 	FProperty *Property = PropertyChangedEvent.Property;
// 	if (Property && PropertyChangedEvent.ChangeType == EPropertyChangeType::ValueSet)
// 	{
// 		if (Property->GetMetaDataMap())
// 		{
// 			const FString *CategoryName = Property->GetMetaDataMap()->Find(CategoryKey);
// 			if (!CategoryName)
// 			{
// 				return;
// 			}
// 			if (ShouldCopyCategories.Find(*CategoryName))
// 			{
// 				for (UActorComponent* Component: Owner->GetComponents())
// 				{
// 					USceneComponent* SkeletalMeshComp = ExactCast<USkeletalMeshComponent>(Component);
// 					if (SkeletalMeshComp)
// 					{
// 						const bool bIsTransient = !!( Property->PropertyFlags & CPF_Transient );
// 						const bool bIsIdentical = Property->Identical_InContainer( this, SkeletalMeshComp );
// 						const bool bIsComponent = !!( Property->PropertyFlags & ( CPF_InstancedReference | CPF_ContainsInstancedReference ) );
// 						if( bIsTransient || bIsIdentical || bIsComponent)
// 						{
// 							continue;
// 						}
// 						SkeletalMeshComp->PreEditChange(Property);
// 						EditorUtilities::CopySingleProperty(this, SkeletalMeshComp, Property);
// 						FPropertyChangedEvent NewPropertyChangedEvent(PropertyChangedEvent.Property, PropertyChangedEvent.ChangeType);
// 						SkeletalMeshComp->PostEditChangeProperty(PropertyChangedEvent);
// 					}
// 				}
// 			}
// 		}
// 	}
// }
// #endif