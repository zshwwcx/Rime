#include "3C/Core/ResizeBoundsScaleComponent.h"
#include "Rendering/SkeletalMeshRenderData.h"
#include "Animation/SkeletalMeshActor.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/SkeletalMesh.h"
#include "Engine/SkinnedAsset.h"
#include "GameFramework/Character.h"

UResizeBoundsScaleComponent::UResizeBoundsScaleComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.TickGroup = TG_PrePhysics;
}

void UResizeBoundsScaleComponent::BeginPlay()
{
	Super::BeginPlay();
	Initialize();
}

void UResizeBoundsScaleComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Deinitialize();
	Super::EndPlay(EndPlayReason);
}

void UResizeBoundsScaleComponent::InitializeWithSkeletalMeshActor()
{
	if (ASkeletalMeshActor* SkeletalMeshActor = Cast<ASkeletalMeshActor>(GetOwner()))
	{
		MeshComponents.Add(SkeletalMeshActor->GetSkeletalMeshComponent());
		LeaderMeshComponent = SkeletalMeshActor->GetSkeletalMeshComponent();
		if (LeaderMeshComponent.IsValid())
		{
			OriginalBoundsScale = LeaderMeshComponent->BoundsScale;
			if (LeaderMeshComponent->GetSkinnedAsset())
			{
				OriginalBoundsExtent = LeaderMeshComponent->GetSkinnedAsset()->GetBounds().BoxExtent;
			}
			else
			{
				UE_LOG(LogTemp, Error, TEXT("ResizeBoundsScaleComponent: Mesh has no skinned asset"));
				OriginalBoundsExtent = FVector::ZeroVector;
			}
		}
		GetDefaultBoneName();
	}
}

void UResizeBoundsScaleComponent::GetDefaultBoneName()
{
	if (LeaderMeshComponent.IsValid())
	{
		USkeletalMesh* SkeletalMesh = LeaderMeshComponent->GetSkeletalMeshAsset();
		if (!SkeletalMesh)
		{
			UE_LOG(LogTemp, Error, TEXT("ResizeBoundsScaleComponent: SkeletalMesh is null"));
			return;
		}
		const FReferenceSkeleton& RefSkeleton = SkeletalMesh->GetRefSkeleton();
		const FSkeletalMeshRenderData* RenderData = SkeletalMesh->GetResourceForRendering();
		if (!RenderData || RenderData->LODRenderData.Num() == 0)
		{
			UE_LOG(LogTemp, Error, TEXT("ResizeBoundsScaleComponent: RenderData is null or LODRenderData is empty"));
			return;
		}
		const FSkeletalMeshLODRenderData& LODData = RenderData->LODRenderData.Last();
		const TArray<FBoneIndexType>& SkinnedBoneIndices = LODData.ActiveBoneIndices;
		for (int32 i = 0; i < SkinnedBoneIndices.Num(); i++)
		{
			const FBoneIndexType& BoneIndex = SkinnedBoneIndices[i];
			int32 Index = LODData.RequiredBones.Find(BoneIndex);
			if (Index != INDEX_NONE)
			{
				const TArray<FMeshBoneInfo>& RefBoneInfo = RefSkeleton.GetRefBoneInfo();
				if (RefBoneInfo[BoneIndex].ParentIndex != INDEX_NONE)
				{
					BoneName = RefBoneInfo[BoneIndex].Name;
					return;
				}
			}
		}
	}
}

void UResizeBoundsScaleComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (!LeaderMeshComponent.IsValid() || !LeaderMeshComponent->bComponentUseFixedSkelBounds && LeaderMeshComponent->GetPhysicsAsset())
	{
		return;
	}

	FVector PelvisBonePosition = LeaderMeshComponent->GetBoneLocation(BoneName, EBoneSpaces::ComponentSpace);
	FBox CheckInsideBoundsBox = FBox(LeaderMeshComponent->RootBoneTranslation - OriginalBoundsExtent * Threshold, LeaderMeshComponent->RootBoneTranslation + OriginalBoundsExtent * Threshold);
	if (CheckInsideBoundsBox.IsInside(PelvisBonePosition))
	{
		if (bNeedResetScale)
		{
			for (auto MeshComponent : MeshComponents)
			{
				if (MeshComponent.IsValid())
				{
					MeshComponent->SetBoundsScale(OriginalBoundsScale);
				}
			}
			bNeedResetScale = false;
		}
		return;
	}

	FVector Distance = PelvisBonePosition - LeaderMeshComponent->RootBoneTranslation;
	FVector RequiredRange = FVector(
		FMath::Abs(Distance.X) + OriginalBoundsExtent.X * 2,
		FMath::Abs(Distance.Y) + OriginalBoundsExtent.Y * 2,
		FMath::Abs(Distance.Z) + OriginalBoundsExtent.Z * 2);
	
	FVector ScaleFactor = RequiredRange / (OriginalBoundsExtent * .5f);
	float AdditiveBoundsScale = FMath::Max3(ScaleFactor.X, ScaleFactor.Y, ScaleFactor.Z);
	bNeedResetScale = true;

	for (auto MeshComponent : MeshComponents)
	{
		if (MeshComponent.IsValid())
		{
			MeshComponent->SetBoundsScale(AdditiveBoundsScale);
		}
	}
}

void UResizeBoundsScaleComponent::InitializeParameters(FName InBoneName, float InThreshold)
{
	Threshold = InThreshold;
	if (LeaderMeshComponent.IsValid())
	{
		if (LeaderMeshComponent->GetBoneIndex(InBoneName) != INDEX_NONE)
		{
			BoneName = InBoneName;
		}
	}
}

void UResizeBoundsScaleComponent::Initialize()
{
	ACharacter* Owner = Cast<ACharacter>(GetOwner());
	if (!Owner)
	{
		InitializeWithSkeletalMeshActor();
		return;
	}

	TArray<UActorComponent*> Components;
	Owner->GetComponents(USkeletalMeshComponent::StaticClass(), Components);
	for (UActorComponent* Component : Components)
	{
		if (USkeletalMeshComponent* SkeletalMeshComponent = Cast<USkeletalMeshComponent>(Component))
		{
			MeshComponents.Add(SkeletalMeshComponent);
		}
	}

	LeaderMeshComponent = Owner->GetMesh();
	
	if (LeaderMeshComponent.IsValid())
	{
		OriginalBoundsScale = LeaderMeshComponent->BoundsScale;
		if (LeaderMeshComponent->GetSkinnedAsset())
		{
			OriginalBoundsExtent = LeaderMeshComponent->GetSkinnedAsset()->GetBounds().BoxExtent;
		}
		else
		{
			UE_LOG(LogTemp, Error, TEXT("ResizeBoundsScaleComponent: Mesh has no skinned asset"));
			OriginalBoundsExtent = FVector::ZeroVector;
		}
	}
	GetDefaultBoneName();
}

void UResizeBoundsScaleComponent::Deinitialize()
{
	for (auto MeshComponent : MeshComponents)
	{
		if (MeshComponent.IsValid())
		{
			MeshComponent->SetBoundsScale(OriginalBoundsScale);
		}
	}
}
