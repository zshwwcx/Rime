#include "3C/Core/AttachJointComponent.h"

#include "3C/Animation/BaseAnimInstance.h"
#include "GameFramework/Pawn.h"
#include "CollisionQueryParams.h"
#include "WorldCollision.h"
#include "Engine/World.h"
#include "DrawDebugHelpers.h"
#include "Components/SkeletalMeshComponent.h"


const FName UAttachJointComponent::SocketName(TEXT("AttachJointEndpoint"));

UAttachJointComponent::UAttachJointComponent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.TickGroup = TG_PostPhysics;
	
	bAutoActivate = true;
	bTickInEditor = true;
	bDoCollisionTest = true;

	bInheritPitch = true;
	bInheritYaw = true;
	bInheritRoll = true;

	TargetArmLength = 300.0f;
	ProbeSize = 12.0f;
	ProbeChannel = ECC_Camera;

	RelativeSocketRotation = FQuat::Identity;

	bUseCameraLagSubstepping = true;
	CameraLagSpeed = 10.f;
	CameraRotationLagSpeed = 10.f;
	CameraLagMaxTimeStep = 1.f / 60.f;
	CameraLagMaxDistance = 0.f;

 	UnfixedCameraPosition = FVector::ZeroVector;
}

FRotator UAttachJointComponent::GetDesiredRotation() const
{
	return GetComponentRotation();
}

FRotator UAttachJointComponent::GetTargetRotation() const
{
	FRotator DesiredRot = GetDesiredRotation();

	// If inheriting rotation, check options for which components to inherit
	if (!IsUsingAbsoluteRotation())
	{
		const FRotator LocalRelativeRotation = GetRelativeRotation();
		if (!bInheritPitch)
		{
			DesiredRot.Pitch = LocalRelativeRotation.Pitch;
		}

		if (!bInheritYaw)
		{
			DesiredRot.Yaw = LocalRelativeRotation.Yaw;
		}

		if (!bInheritRoll)
		{
			DesiredRot.Roll = LocalRelativeRotation.Roll;
		}
	}

	return DesiredRot;
}

void UAttachJointComponent::UpdateDesiredArmLocation(bool bDoTrace, bool bDoLocationLag, bool bDoRotationLag, float DeltaTime)
{
	FRotator DesiredRot = GetTargetRotation();

	// Apply 'lag' to rotation if desired
	if(bDoRotationLag)
	{
		if (bUseCameraLagSubstepping && DeltaTime > CameraLagMaxTimeStep && CameraRotationLagSpeed > 0.f)
		{
			const FRotator ArmRotStep = (DesiredRot - PreviousDesiredRot).GetNormalized() * (1.f / DeltaTime);
			FRotator LerpTarget = PreviousDesiredRot;
			float RemainingTime = DeltaTime;
			while (RemainingTime > KINDA_SMALL_NUMBER)
			{
				const float LerpAmount = FMath::Min(CameraLagMaxTimeStep, RemainingTime);
				LerpTarget += ArmRotStep * LerpAmount;
				RemainingTime -= LerpAmount;

				DesiredRot = FRotator(FMath::QInterpTo(FQuat(PreviousDesiredRot), FQuat(LerpTarget), LerpAmount, CameraRotationLagSpeed));
				PreviousDesiredRot = DesiredRot;
			}
		}
		else
		{
			DesiredRot = FRotator(FMath::QInterpTo(FQuat(PreviousDesiredRot), FQuat(DesiredRot), DeltaTime, CameraRotationLagSpeed));
		}
	}
	PreviousDesiredRot = DesiredRot;

	// Get the spring arm 'origin', the target we want to look at
	FVector ArmOrigin = GetComponentLocation() + TargetOffset;
	// We lag the target, not the actual camera position, so rotating the camera around does not have lag
	FVector DesiredLoc = ArmOrigin;




	// Now offset camera position back along our rotation
	DesiredLoc -= DesiredRot.Vector() * TargetArmLength;
	// Add socket offset in local space
	DesiredLoc += FRotationMatrix(DesiredRot).TransformVector(SocketOffset);


	// Do a sweep to ensure we are not penetrating the world
	FVector TargetDesiredLoc = DesiredLoc;
	if (bDoTrace && (TargetArmLength != 0.0f) && JointAttachActor.IsValid())
	{
		bIsCameraFixed = true;
		FCollisionQueryParams QueryParams(SCENE_QUERY_STAT(CameraArm), false);
		for (TWeakObjectPtr<AActor> WeakActor : IgnoredActors)
		{
			QueryParams.AddIgnoredActor(WeakActor.Get());
		}

		FHitResult Result;
		GetWorld()->SweepSingleByChannel(Result, ArmOrigin, DesiredLoc, FQuat::Identity, ProbeChannel, FCollisionShape::MakeSphere(ProbeSize), QueryParams);
		
		UnfixedCameraPosition = DesiredLoc;

		TargetDesiredLoc = BlendLocations(DesiredLoc, Result.Location, Result.bBlockingHit, DeltaTime);

		if (TargetDesiredLoc == DesiredLoc) 
		{	
			bIsCameraFixed = false;
		}
	}
	else
	{
		TargetDesiredLoc = DesiredLoc;
		bIsCameraFixed = false;
		UnfixedCameraPosition = TargetDesiredLoc;
	}



	


#if !(UE_BUILD_SHIPPING || UE_BUILD_TEST)
	if (bDrawDebugLagMarkers)
	{
		DrawDebugSphere(GetWorld(), ArmOrigin, 5.f, 8, FColor::Green);
	}
#endif
	
	if (bDoLocationLag)
	{
		if (bUseCameraLagSubstepping && DeltaTime > CameraLagMaxTimeStep && CameraLagSpeed > 0.f)
		{
			const FVector ArmMovementStep = (TargetDesiredLoc - PreviousDesiredLoc) * (1.f / DeltaTime);
			FVector LerpTarget = PreviousDesiredLoc;

			float RemainingTime = DeltaTime;
			while (RemainingTime > KINDA_SMALL_NUMBER)
			{
				const float LerpAmount = FMath::Min(CameraLagMaxTimeStep, RemainingTime);
				LerpTarget += ArmMovementStep * LerpAmount;
				RemainingTime -= LerpAmount;

				DesiredLoc = FMath::VInterpTo(PreviousDesiredLoc, LerpTarget, LerpAmount, CameraLagSpeed);
			}
		}
		else if(bUseBezier)
		{
		
			if (FMath::IsNearlyEqual(PreviousResultLoc.X,DesiredLoc.X, 10)  && FMath::IsNearlyEqual( PreviousResultLoc.Y,DesiredLoc.Y , 10) )
			{
				TargetDesiredLoc.Z = FMath::FInterpTo(PreviousDesiredLoc.Z, DesiredLoc.Z, DeltaTime, CameraLagSpeed);
			}
			else
			{
				FVector P0 =	PreviousDesiredLoc;
				FVector P2 =	DesiredLoc;
				float Dist = FMath::Min(BezierMaxDist,(P0 - P2).Size()) / 2;
			
				FVector P1 = P0 + ((Velocity.Size() == 0 )? DesiredRot.Vector() :Velocity.GetSafeNormal()) * Dist;
				float t = BezierStep;
				TargetDesiredLoc = FMath::Pow(1-t,2) * P0 + 2 * t * (1-t) * P1 +   FMath::Pow(t,2) * P2;
				if (bDrawDebugLagMarkers)
				{
					DrawDebugSphere(GetWorld(), P2, 3.f, 8, FColor::Black);
					DrawDebugSphere(GetWorld(), P1, 3.f, 8, FColor::Yellow);
					DrawDebugSphere(GetWorld(), P0, 3.f, 8, FColor::Purple);
					DrawDebugSphere(GetWorld(), TargetDesiredLoc, 3.f, 8, FColor::Purple);
				}
			}
			
			
			DesiredLoc = FMath::VInterpTo(PreviousDesiredLoc, TargetDesiredLoc, DeltaTime, CameraLagSpeed);
		}
		else
		{
			DesiredLoc = FMath::VInterpTo(PreviousDesiredLoc, TargetDesiredLoc, DeltaTime, CameraLagSpeed);
		}

		// Clamp distance if requested
		bool bClampedDist = false;
		if (CameraLagMaxDistance > 0.f)
		{
			const FVector FromOrigin = DesiredLoc - TargetDesiredLoc;
			if (FromOrigin.SizeSquared() > FMath::Square(CameraLagMaxDistance))
			{
				DesiredLoc = TargetDesiredLoc + FromOrigin.GetClampedToMaxSize(CameraLagMaxDistance);
				bClampedDist = true;
			}
		}		

#if !(UE_BUILD_SHIPPING || UE_BUILD_TEST)
		if (bDrawDebugLagMarkers)
		{
			DrawDebugSphere(GetWorld(), TargetDesiredLoc, 5.f, 8, FColor::Blue);
			
			const FVector ToOrigin = TargetDesiredLoc - DesiredLoc;
			DrawDebugDirectionalArrow(GetWorld(), DesiredLoc, DesiredLoc + ToOrigin * 0.5f, 7.5f, bClampedDist ? FColor::Red : FColor::Green);
			DrawDebugDirectionalArrow(GetWorld(), DesiredLoc + ToOrigin * 0.5f, TargetDesiredLoc,  7.5f, bClampedDist ? FColor::Red : FColor::Green);
		}
#endif
	}

	PreviousArmOrigin = ArmOrigin;
	PreviousDesiredLoc = DesiredLoc;

	if (DeltaTime !=0)
	{
		Velocity = (DesiredLoc - PreviousResultLoc) * (1/DeltaTime);
	}

	FRotator ResultRot = DesiredRot;

	if (bFaceToMoveDirection)
	{
		if(bUseBezier)
		{
			if (FMath::IsNearlyEqual(PreviousResultLoc.X,DesiredLoc.X, 1.e-2f)  && FMath::IsNearlyEqual( PreviousResultLoc.Y,DesiredLoc.Y , 1.e-2f) )
			{
				ResultRot = PreviousDesiredRot;
				ResultRot.Pitch = 0;
				ResultRot.Roll = 0;
				ResultRot = FRotator(FMath::QInterpTo(FQuat(PreviousResultRot), FQuat(ResultRot), DeltaTime, SocketRotSpeed));
			}
			else
			{
				ResultRot = FRotator(FMath::QInterpTo(FQuat(PreviousResultRot), FQuat(Velocity.Size()> 100 ? Velocity.ToOrientationRotator() : DesiredRot), DeltaTime, SocketRotSpeed));
			}


		}
		else
		{
			FVector RelativeLocWithOffset = TargetDesiredLoc - DesiredLoc;
			if (FaceToMoveDirectionTolerance > 0 && RelativeLocWithOffset.Size() > FaceToMoveDirectionTolerance)
			{
				FRotator SocketTargetRot = (RelativeLocWithOffset).ToOrientationRotator();
				ResultRot = FRotator(FMath::QInterpTo(FQuat(PreviousResultRot), FQuat(SocketTargetRot), DeltaTime, SocketRotSpeed));
			}
			else
			{
				ResultRot = FRotator(FMath::QInterpTo(FQuat(PreviousResultRot), FQuat(DesiredRot), DeltaTime, SocketRotSpeed));
			}
		}
	}
	else
	{
		ResultRot = FRotator(FMath::QInterpTo(FQuat(PreviousResultRot), FQuat(DesiredRot), DeltaTime, SocketRotSpeed));
	}

	if (bClampPitch){
		ResultRot.Pitch = FMath::Clamp(ResultRot.Pitch,PitchClampAngle.X,PitchClampAngle.Y);
	}

	
	PreviousResultLoc = DesiredLoc;
	PreviousResultRot = ResultRot;

	// Form a transform for new world transform for camera
	FTransform WorldCamTM(DesiredRot, DesiredLoc);
	// Convert to relative to component
	FTransform RelCamTM = WorldCamTM.GetRelativeTransform(GetComponentTransform());

	

	// Update socket location/rotation
	RelativeSocketLocation = RelCamTM.GetLocation();
	RelativeSocketRotation = RelCamTM.GetRotation();
	
	if (bDrawDebugLagMarkers)
	{
		DrawDebugSphere(GetWorld(), WorldCamTM.GetLocation(), 5.f, 8, FColor::Red);
	}

	
	// UpdateChildTransforms();

	//TODO：0810 Temporary @daiwei
	// if (JointAttachActor.IsValid())
	// {
	// 	JointAttachActor->SetActorLocationAndRotation(DesiredLoc,ResultRot);
	//
	// 	UActorComponent* Mesh =  JointAttachActor->GetComponentByClass(USkeletalMeshComponent::StaticClass());
	// 	if (USkeletalMeshComponent* SKMesh = Cast<USkeletalMeshComponent>(Mesh))
	// 	{
	// 		UAnimInstance* AnimIns = SKMesh->GetAnimInstance();
	// 		if(UBaseAnimInstance* BaseAnimIns = Cast<UBaseAnimInstance>(AnimIns))
	// 		{
	// 			BaseAnimIns->VelocityValue = Velocity.Size();
	// 		}
	// 	}
	// }
	
}


void UAttachJointComponent::UpdateChildTransforms(EUpdateTransformFlags UpdateTransformFlags, ETeleportType Teleport)
{
	Super::UpdateChildTransforms( UpdateTransformFlags,  Teleport);
}

FVector UAttachJointComponent::BlendLocations(const FVector& DesiredArmLocation, const FVector& TraceHitLocation, bool bHitSomething, float DeltaTime)
{
	return bHitSomething ? TraceHitLocation : DesiredArmLocation;
}

void UAttachJointComponent::ApplyWorldOffset(const FVector & InOffset, bool bWorldShift)
{
	Super::ApplyWorldOffset(InOffset, bWorldShift);
	PreviousDesiredLoc += InOffset;
	PreviousArmOrigin += InOffset;
}

void UAttachJointComponent::OnRegister()
{
	Super::OnRegister();

	// enforce reasonable limits to avoid potential div-by-zero
	CameraLagMaxTimeStep = FMath::Max(CameraLagMaxTimeStep, 1.f / 200.f);
	CameraLagSpeed = FMath::Max(CameraLagSpeed, 0.f);

	// Set initial location (without lag).
	UpdateDesiredArmLocation(false, false, false, 0.f);
}

void UAttachJointComponent::PostLoad()
{
	Super::PostLoad();
}

void UAttachJointComponent::TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAttachJointComponent_TickComponent");
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	UpdateDesiredArmLocation(bDoCollisionTest, bEnableCameraLag, bEnableCameraRotationLag, DeltaTime);
}

FTransform UAttachJointComponent::GetSocketTransform(FName InSocketName, ERelativeTransformSpace TransformSpace) const
{
	FTransform RelativeTransform(RelativeSocketRotation, RelativeSocketLocation);

	switch(TransformSpace)
	{
		case RTS_World:
		{
			return RelativeTransform * GetComponentTransform();
			break;
		}
		case RTS_Actor:
		{
			if( const AActor* Actor = JointAttachActor.Get() )
			{
				FTransform SocketTransform = RelativeTransform * GetComponentTransform();
				return SocketTransform.GetRelativeTransform(Actor->GetTransform());
			}
			break;
		}
		case RTS_Component:
		{
			return RelativeTransform;
		}
	}
	return RelativeTransform;
}

bool UAttachJointComponent::HasAnySockets() const
{
	return true;
}

void UAttachJointComponent::QuerySupportedSockets(TArray<FComponentSocketDescription>& OutSockets) const
{
	new (OutSockets) FComponentSocketDescription(SocketName, EComponentSocketType::Socket);
}

FVector UAttachJointComponent::GetUnfixedCameraPosition() const
{
	return UnfixedCameraPosition;
}

bool UAttachJointComponent::IsCollisionFixApplied() const
{
	return bIsCameraFixed;
}

void UAttachJointComponent::SetIgnoreActor(TArray<AActor*> InIgnoredActors)
{
	IgnoredActors.Empty();
	for (AActor* Actor : InIgnoredActors)
	{
		TWeakObjectPtr<AActor> WeakActor(Actor);
		IgnoredActors.Add(WeakActor);
	}
}

void UAttachJointComponent::SetAttachActor(AActor* InActor)
{
	JointAttachActor = InActor;
}

void UAttachJointComponent::ClearAttachActor()
{
	JointAttachActor = nullptr;
}
