#include "3C/Core/InteractiveTriggerComponent.h"
#include "Components/ModelComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Components/SceneComponent.h"
#include "Components/SphereComponent.h"
#include "Logging/LogMacros.h"
#include "Engine/World.h"
#include "Engine/OverlapResult.h"
#include "Engine/StaticMesh.h"
#include "Components/StaticMeshComponent.h"
#include "GameFramework/WorldSettings.h"
#include "GameFramework/Character.h"
#include "Stats/Stats2.h"
#include "3C/Core/KGUEActorManager.h"
#include "NavigationSystem.h"
#include "NavMesh/RecastNavMesh.h"

#include "3C/Character/BaseCharacter.h"
#include "Navigation/PathFollowingComponent.h"
#include "Components/SplineMeshComponent.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "NiagaraComponent.h"
#include "3C/Effect/KGEffectManager.h"
#include "3C/Util/KGUtils.h"
#include "TimerManager.h"

#include "BlockoutToolsParent.h"
#include "Components/SplineComponent.h"

#if UE_BUILD_DEVELOPMENT
#include "DrawDebugHelpers.h"
#endif

UInteractiveTriggerComponent::UInteractiveTriggerComponent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.TickInterval = 0.2f;

	SetComponentTickEnabled(false);
}

void UInteractiveTriggerComponent::BeginPlay()
{
	Super::BeginPlay();

	OwnerActor = Cast<AActor>(GetOwner());
	if (!OwnerActor.IsValid())
		return;

	if (OwnerActor->GetRootComponent())
	{
		if (UCapsuleComponent* Capsule = Cast<UCapsuleComponent>(OwnerActor->GetRootComponent()))
		{
			OwnerCapsuleHalfHeight = Capsule->GetScaledCapsuleHalfHeight();
			OwnerCapsuleRadius = Capsule->GetScaledCapsuleRadius();
		}

	}

	AutoAttachRoot();
}

void UInteractiveTriggerComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	DeActivateScreenNiagara();

	Super::EndPlay(EndPlayReason);
}

void UInteractiveTriggerComponent::ResetToDefaultsForCache()
{
	DetectDistanceMonitors.Empty();
	EnterScopeActorMap.Empty();
	InRangeElementsByToken.Empty();
	CustomElementsByToken.Empty();
	bCurFrameUseSweepDetect = false;
}

void UInteractiveTriggerComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	QUICK_SCOPE_CYCLE_COUNTER(InteractiveTriggerComponent_Tick);
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UInteractiveTriggerComponent_TickComponent");

	if (OwnerActor.IsValid())
	{
		if (!DetectDistanceMonitors.IsEmpty())
		{
			CheckDetectDistanceMonitor();
		}
		
		if (IndoorDetectParams.bEnableIndoorFieldDetect || bEnableInterActiveForDetect || bAllowNewAirWallLogic)
		{
			DoInteractableComponentsDetection(DeltaTime);

			if (IndoorDetectParams.bEnableIndoorFieldDetect)
			{
				CheckDetectIndoorFiled();
			}
			
			if (bEnableInterActiveForDetect)
			{
				CheckDetectInteractable();

				CheckDetectCustomInteractable();
			}

			if (bAllowNewAirWallLogic)
			{
				UpdateNewAirWallData(DeltaTime);
			}
		}
	}

	DetectedInteractableHitResults.Empty();

	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
}

void UInteractiveTriggerComponent::AutoAttachRoot()
{
	if (!OwnerActor.IsValid() || !OwnerActor->GetRootComponent())
		return ;

	this->AttachToComponent(OwnerActor->GetRootComponent(), FAttachmentTransformRules::SnapToTargetNotIncludingScale);
	
	ResetTriggerSize(TriggerHalfHeight, TriggerRadius);
	
}

bool UInteractiveTriggerComponent::GetLocViewInfo(FVector& OutPos)
{
	APlayerController* Player = UGameplayStatics::GetPlayerController(this, 0);
	if (!Player || !Player->GetPawn())
		return false;

	OutPos = Player->GetPawn()->GetActorLocation();
	//FRotator out_Rotation;
	//Player->GetPlayerViewPoint(OutPos, out_Rotation);

	return true;
}

void UInteractiveTriggerComponent::InitAsDetect(int64 InOwnerUID, float TickInterval, TArray<int32> InDetectObjectTypes, TArray<int32> InLineTraceObjectTypes)
{
	DetectObjectTypes.Empty();
	for (int32 ObjectTypeInt: InDetectObjectTypes)
	{
		DetectObjectTypes.Add(TEnumAsByte<EObjectTypeQuery>(ObjectTypeInt));
	}

	LineTraceObjectTypes.Empty();
	for (int32 ObjectTypeInt: InLineTraceObjectTypes)
	{
		LineTraceObjectTypes.Add(TEnumAsByte<EObjectTypeQuery>(ObjectTypeInt));
	}
	
	SetOwnerIntUID(InOwnerUID);
	SetComponentTickInterval(TickInterval);
	EnableInterActiveForDetect(true);
}

void UInteractiveTriggerComponent::DoInteractableComponentsDetection(const float& DeltaTime)
{
	QUICK_SCOPE_CYCLE_COUNTER(InteractiveTriggerComponent_DoInteractableComponentsDetection);
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UInteractiveTriggerComponent_DoInteractableComponentsDetection");
	if (DetectObjectTypes.IsEmpty())
	{
		return;
	}

	TArray<AActor*> ActorsToIgnore;
	TArray<FHitResult> OutHits;

	DetectedInteractablePos = OwnerActor->GetActorLocation();
	float MaxMoveDistance = DeltaTime * MaxSpeedPerSeconds;
	bCurFrameUseSweepDetect = bEnableSweepDetect;
	if (bCurFrameUseSweepDetect)
	{
		if (!bLastDetectLocationSet)
		{
			bCurFrameUseSweepDetect = false;
		}
		else
		{
			float CurMoveDistance = (LastDetectLocation - DetectedInteractablePos).Size();
			// 走得太远了
			if (CurMoveDistance > MaxMoveDistance)
			{
				bCurFrameUseSweepDetect = false;
				float AverageSpeed = DeltaTime > UE_SMALL_NUMBER ? CurMoveDistance / DeltaTime : CurMoveDistance / 0.01;
				UE_LOG(LogTemp, Warning, TEXT("detected a large distance delta %f, delta time %f, average speed %f, sweep detect will not effect"), CurMoveDistance, DeltaTime, AverageSpeed);
			}
		}
	}

	UKismetSystemLibrary::CapsuleTraceMultiForObjects(
		GetWorld(),
		bCurFrameUseSweepDetect ? LastDetectLocation : DetectedInteractablePos,
		DetectedInteractablePos,
		TriggerRadius,
		TriggerHalfHeight,
		DetectObjectTypes,
		false,
		ActorsToIgnore,
		EDrawDebugTrace::None,
		OutHits,
		true
	);

	for (auto& HitResult : OutHits)
	{
		if (HitResult.Component.IsValid())
		{
			DetectedInteractableHitResults.Add(HitResult);
		}
	}
}

void UInteractiveTriggerComponent::CheckDetectInteractable()
{
	QUICK_SCOPE_CYCLE_COUNTER(InteractiveTriggerComponent_CheckDetectInteractable);
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UInteractiveTriggerComponent_CheckDetectInteractable");
	TArray<int64> RemoveKey;
	TMap<int64, TWeakObjectPtr<UPrimitiveComponent>> ComponentsToAdd;
	TMap<int64, TWeakObjectPtr<UPrimitiveComponent>> ComponentsToRemove;
	TMap<int64, TWeakObjectPtr<UPrimitiveComponent>> CurOverlappingComponents;
	
	for (int32 i = DetectedInteractableHitResults.Num() - 1; i >= 0; i--)
	{
		auto PrimitiveComponent = DetectedInteractableHitResults[i].Component.Get();
		const TWeakObjectPtr<AActor> Other = PrimitiveComponent->GetOwner();
		int64 OwnerUID = 0;

		if (UC7ShapeCollisionComponent* ShapeComponent = Cast<UC7ShapeCollisionComponent>(PrimitiveComponent))
		{
			OwnerUID = ShapeComponent->OwnerIntUID;
		}

		if (OwnerUID == 0)
		{
			continue;
		}
		if (!Other.IsValid())
		{
			RemoveKey.Push(OwnerUID);
			continue;
		}
		CurOverlappingComponents.Add(OwnerUID, PrimitiveComponent);

		bool Enter = CheckEnterCustomScope(Other.Get(), PrimitiveComponent);

		if (Enter)
		{
			if (!EnterScopeActorMap.Contains(OwnerUID))
			{
				ComponentsToAdd.Add(OwnerUID, PrimitiveComponent);
			}
		}
		else
		{
			if (EnterScopeActorMap.Contains(OwnerUID))
			{
				ComponentsToRemove.Add(OwnerUID, PrimitiveComponent);
			}
		}

	}

	for (auto& Elem : EnterScopeActorMap)
	{
		int64 OwnerUID = Elem.Key;
		if (!Elem.Value.IsValid())
		{
			RemoveKey.Push(OwnerUID);
			continue;
		}
		if (!CurOverlappingComponents.Contains(OwnerUID))
		{
			AActor* Owner = Elem.Value.Get();
			UPrimitiveComponent* RemoveComponent = Cast<UPrimitiveComponent>(Owner->GetComponentByClass(UC7ShapeCollisionComponent::StaticClass()));
			if (!RemoveComponent)
			{
				RemoveComponent = Cast<UPrimitiveComponent>(Owner->GetComponentByClass(UInteractiveTriggerComponent::StaticClass()));
			}
			ComponentsToRemove.Add(OwnerUID, RemoveComponent);
		}
	}

	FVector Location = GetComponentLocation();
	FName CollisionTag = NAME_None;
	float TriggerYaw = GetComponentRotation().Yaw;
	for (auto& Elem : ComponentsToAdd)
	{
		int64 OtherUID = Elem.Key;
		auto PrimitiveComponent = Elem.Value;
		if (PrimitiveComponent.IsValid())
		{
			EnterScopeActorMap.Add(OtherUID, PrimitiveComponent->GetOwner());
			if (UC7ShapeCollisionComponent* ShapeComponent = Cast<UC7ShapeCollisionComponent>(PrimitiveComponent))
			{
				ShapeComponent->EnterInteractiveTrigger(OwnerActor.Get(), Location);
				CollisionTag = ShapeComponent->GetCollisionTag();
				TriggerYaw = ShapeComponent->GetComponentRotation().Yaw;
			}
		}
		DetectEnterTrigger_MD.Broadcast(Elem.Key, Location, TriggerYaw, CollisionTag);
		CollisionTag = NAME_None;
	}

	for (auto& Elem : ComponentsToRemove)
	{
		int64 OtherUID = Elem.Key;
		auto PrimitiveComponent = Elem.Value;
		EnterScopeActorMap.Remove(OtherUID);
		if (PrimitiveComponent.IsValid())
		{
			if (UC7ShapeCollisionComponent* ShapeComponent = Cast<UC7ShapeCollisionComponent>(PrimitiveComponent.Get()))
			{
				ShapeComponent->LeaveInteractiveTrigger(OwnerActor.Get(), Location);
				CollisionTag = ShapeComponent->GetCollisionTag();
			}
		}
		DetectLeaveTrigger_MD.Broadcast(OtherUID, Location, CollisionTag);
		CollisionTag = NAME_None;
	}

	for (auto& Key : RemoveKey)
	{
		if (EnterScopeActorMap.Contains(Key))
		{
			EnterScopeActorMap.Remove(Key);
		}
	}

	bLastDetectLocationSet = true;
	LastDetectLocation = DetectedInteractablePos;
}

void UInteractiveTriggerComponent::CheckDetectIndoorFiled()
{
	QUICK_SCOPE_CYCLE_COUNTER(InteractiveTriggerComponent_CheckDetectIndoorFiled);
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UInteractiveTriggerComponent_CheckDetectIndoorFiled");
	if (IndoorDetectParams.IndoorObjectType == EObjectTypeQuery::ObjectTypeQuery_MAX)
	{
		return;
	}
	
	// 新版室内探测方法
	// 1. 非传送和出生的情况，只检测美术布置进出门Box的Tag（一进一出两个Box）
	// 2. 传送和出生的情况，向上和向下各打一条射线（WorldStatic）找室内建筑，室内建筑的RootComponent会带有专属的ComponentTag
	bool bCurIndoorDetected = false;
	bool bNeedUpdateInDoorStates = false;
	if (bCurFrameUseSweepDetect)
	{
		TOptional<float> NearestIndoorEntryDistance;
		for (int32 i = DetectedInteractableHitResults.Num() - 1; i >= 0; i--)
		{
			auto& HitResult = DetectedInteractableHitResults[i];
			auto PrimitiveComponent = DetectedInteractableHitResults[i].Component.Get();
			if ( PrimitiveComponent->GetCollisionObjectType() == UEngineTypes::ConvertToCollisionChannel(IndoorDetectParams.IndoorObjectType))
			{
				EIndoorVolumeDetectTag DetectTag = EIndoorVolumeDetectTag::Enter;
				if (IsIndoorFieldEntry(PrimitiveComponent, DetectTag))
				{
					float CurDistance = FVector::DistSquaredXY(DetectedInteractablePos, HitResult.ImpactPoint);
					if (!NearestIndoorEntryDistance.IsSet() || NearestIndoorEntryDistance.GetValue() > CurDistance)
					{
						if (DetectTag == EIndoorVolumeDetectTag::Enter)
						{
							bCurIndoorDetected = true;
							bNeedUpdateInDoorStates = true;
							if (!IndoorDetectParams.bIndoor)
							{
								UE_LOG(LogTemp, Display, TEXT("UInteractiveTriggerComponent Indoor Enter found, ImpactPoint(%f,%f,%f), Distance:%f"), HitResult.ImpactPoint.X, HitResult.ImpactPoint.Y, HitResult.ImpactPoint.Z, CurDistance);
							}
						}
						else if (DetectTag == EIndoorVolumeDetectTag::Exit)
						{
							bCurIndoorDetected = false;
							bNeedUpdateInDoorStates = true;
							if (IndoorDetectParams.bIndoor)
							{
								UE_LOG(LogTemp, Display, TEXT("UInteractiveTriggerComponent Indoor Exit found, ImpactPoint(%f,%f,%f), Distance:%f"), HitResult.ImpactPoint.X, HitResult.ImpactPoint.Y, HitResult.ImpactPoint.Z, CurDistance);
							}
						}
					}
					NearestIndoorEntryDistance = CurDistance;
				}
			}
		}
	}
	// 出生或传送的情况，作射线检测
	else
	{
		bCurIndoorDetected = DetermineIndoorFieldByLineTrace();
		bNeedUpdateInDoorStates = true;
	}
	
	if (bNeedUpdateInDoorStates && bCurIndoorDetected != IndoorDetectParams.bIndoor)
	{
		IndoorDetectParams.bIndoor = bCurIndoorDetected;
		DetectIndoorChanged_MD.Broadcast(IndoorDetectParams.bIndoor);
	}
	
}

bool UInteractiveTriggerComponent::CheckEnterCustomScope(AActor* Other, UPrimitiveComponent* InteractableComponent)
{
	if(!Other || !OwnerActor.IsValid())
	{
		return false;
	}
	bool bActivate = false;
	FC7InteractableCustomScopeParams Params;
	if (UC7ShapeCollisionComponent* ShapeComponent = Cast<UC7ShapeCollisionComponent>(InteractableComponent))
	{
		bActivate = ShapeComponent->IsActivateForDetect();
		ShapeComponent->GetCustomScopeParams(Params);
	}
	
	if (!bActivate)
	{
		return false;
	}

	FVector OtherPos = Other->GetActorLocation();
	FVector DetectPos = OwnerActor->GetActorLocation();
	const double DistanceXY = FVector::DistXY(DetectPos, OtherPos);
	
	// 外圈限制
	if (Params.MaxRadius > 0 && DistanceXY > Params.MaxRadius + Params.OwnerCapsuleRadius)
	{
		return false;
	}
	// 内圈限制
	if (Params.InnerRadius > 0 && DistanceXY < Params.InnerRadius + Params.OwnerCapsuleRadius)
	{
		return false;
	}
	
	// 高度差限制
	if (Params.OwnerCapsuleHalfHeight > 0 && (OtherPos.Z > (DetectPos.Z + Params.OwnerCapsuleHalfHeight) || OtherPos.Z < (DetectPos.Z - Params.OwnerCapsuleHalfHeight)))
	{
		return false;
	}

	// 角度限制
	FQuat OtherQuat = Other->GetActorRotation().Quaternion();
	FQuat OtherFinalQuat = FMath::Abs(Params.LimitAngleYawOffset) > UE_SMALL_NUMBER ? OtherQuat * FRotator(0, Params.LimitAngleYawOffset, 0).Quaternion() : OtherQuat;
	FVector OtherDir = OtherFinalQuat.Vector().GetSafeNormal();
	FVector SelfToTargetV = DetectPos - OtherPos;
	SelfToTargetV.Z = 0;
	SelfToTargetV = SelfToTargetV.GetSafeNormal();
	const float Dot = OtherDir | SelfToTargetV;
	const float CurAngle = FMath::RadiansToDegrees(FMath::Acos(Dot));
	if (Params.HalfMinAngle > CurAngle || Params.HalfMaxAngle < CurAngle)
	{
		return false;
	}
	
	if (LineTraceObjectTypes.IsEmpty())
	{
		return true;
	}
	
    OtherPos.Z += 20;
	float Distance = (DetectPos - OtherPos).Size();
	if (Params.bCheckLineTracePlayer && (Params.LineTracePlayerMinDistance <= 0 || Distance < Params.LineTracePlayerMinDistance))
	{
		if (IsBlockedAlongLineForDetect(Other, OtherPos, DetectPos))
		{
			return false;
		}
	}
	
	if (Params.bCheckLineTraceCamera && (Params.LineTraceCameraMinDistance <= 0 || Distance < Params.LineTraceCameraMinDistance))
	{
		if (APlayerCameraManager* CM = Cast<APlayerCameraManager>(UGameplayStatics::GetPlayerCameraManager(GetWorld(), 0)))
		{
			FMinimalViewInfo POV = CM->GetCameraCacheView();
			if (IsBlockedAlongLineForDetect(Other, OtherPos, POV.Location))
			{
				return false;
			}
		}
	}
	return true;
}

bool UInteractiveTriggerComponent::IsBlockedAlongLineForDetect(AActor* Other, const FVector& StartPos, const FVector& EndPos)
{
	TArray<FHitResult> OutHits;
	TArray<AActor*> IgnoredActors;
	IgnoredActors.Add(GetOwner());
	IgnoredActors.Add(Other);
	const bool bHit = UKismetSystemLibrary::LineTraceMultiForObjects(
		GetWorld(),
		StartPos,
		EndPos,
		LineTraceObjectTypes,
		true,
		IgnoredActors,
		// EDrawDebugTrace::ForDuration,
		EDrawDebugTrace::None,
		OutHits,
		true
		);

	if (!bHit)
	{
		return false;
	}
	for (auto& Elem : OutHits)
	{
		if (!Elem.HitObjectHandle.FetchActor())
		{
			continue;
		}
		return true;
	}
	return false;
}

bool UInteractiveTriggerComponent::IsIndoorFieldEntry(UActorComponent* InComponent, EIndoorVolumeDetectTag& OutDetectTag) const
{
	if (UStaticMeshComponent* StaticMeshComponent = Cast<UStaticMeshComponent>(InComponent))
	{
		if (UStaticMesh* StaticMesh = StaticMeshComponent->GetStaticMesh())
		{
			if(const TArray<UAssetUserData*>* UserDataArray = StaticMesh->GetAssetUserDataArray())
			{
				for(const UAssetUserData* UserData : *UserDataArray)
				{
					if (const UIndoorDetectAssetUserData* InDoorUserData = Cast<UIndoorDetectAssetUserData>(UserData))
					{
						OutDetectTag = InDoorUserData->AssetTag;
						return true;
					}
				}
			}
		}
	}

	return false;
}

bool UInteractiveTriggerComponent::IsIndoorFieldObject(UPrimitiveComponent* InComponent) const
{
	if (AActor* Actor = InComponent->GetOwner())
	{
		if (UActorComponent* Component = Actor->GetRootComponent())
		{
			return Component->ComponentHasTag(IndoorDetectParams.InDoorObjectRootTag);
		}
	}
	return false;
}

bool UInteractiveTriggerComponent::GetLastIndoorFiledLocation(const TArray<FHitResult>& HitResults, FVector& ImpactLocation)
{
	for (auto& Elem : HitResults)
	{
		if (Elem.Component.IsValid())
		{
			UPrimitiveComponent* Component = Elem.Component.Get();
			if (!IsIndoorFieldObject(Component))
			{
				continue;
			}
			ImpactLocation = Elem.ImpactPoint;
			return true;
		}
	}
	return false;
}

bool UInteractiveTriggerComponent::DetermineIndoorFieldByLineTrace()
{
	FVector DetectPos = OwnerActor->GetActorLocation();
	TArray< FHitResult > OutHitsLine;
	TArray<AActor*> IgnoredActors;
	TArray<TEnumAsByte<EObjectTypeQuery> > TraceObjectType;
	TraceObjectType.Add(IndoorDetectParams.IndoorTraceObjectType);
	UKismetSystemLibrary::LineTraceMultiForObjects(
		GetWorld(),
		DetectPos + FVector(0, 0, IndoorDetectParams.IndoorMaxTraceDistance),
		DetectPos,
		TraceObjectType,
		true,
		IgnoredActors,
		EDrawDebugTrace::None,
		OutHitsLine,
		true
		);
		
	if (OutHitsLine.Num() > 0)
	{
		FVector HighestHitLocation;
		if (GetLastIndoorFiledLocation(OutHitsLine, HighestHitLocation) && HighestHitLocation.Z > DetectPos.Z + TriggerHalfHeight)
		{
			OutHitsLine.Empty();
			UKismetSystemLibrary::LineTraceMultiForObjects(
				GetWorld(),
				DetectPos + FVector(0, 0, -IndoorDetectParams.IndoorMaxTraceDistance),
				DetectPos,
				TraceObjectType,
				true,
				IgnoredActors,
				EDrawDebugTrace::None,
				OutHitsLine,
				true
				);
			
			FVector LowestHitLocation;
			if (GetLastIndoorFiledLocation(OutHitsLine, LowestHitLocation))
			{
				return LowestHitLocation.Z < DetectPos.Z - TriggerHalfHeight;
			}
		}
	}
	
	return false;
}

void UInteractiveTriggerComponent::EnableInterActiveForDetect(bool bEnable)
{
	bEnableInterActiveForDetect = bEnable;
	UpdateComponentTickEnabled();
	if (!bEnable)
	{
		FVector ComponentLocation = GetComponentLocation();
		FName CollisionTag = NAME_None;
		if (GetOwner())
		{
			for (auto& Elem : EnterScopeActorMap)
			{
				if (Elem.Value.IsValid())
				{
					if (AActor* Other = Elem.Value.Get())
					{
						if (UC7ShapeCollisionComponent* ShapeComponent = Cast<UC7ShapeCollisionComponent>(Other->GetComponentByClass(UC7ShapeCollisionComponent::StaticClass())))
						{
							ShapeComponent->LeaveInteractiveTrigger(OwnerActor.Get(), ComponentLocation);
							CollisionTag = ShapeComponent->GetCollisionTag();
						}
						DetectLeaveTrigger_MD.Broadcast(Elem.Key, ComponentLocation, CollisionTag);
						CollisionTag = NAME_None;
					}
				}
			}
			EnterScopeActorMap.Empty();

			for (auto &Token: InRangeElementsByToken)
			{
				NotifyInteractableElementEnterOrLeave(Token, false);
			}
			InRangeElementsByToken.Empty();
		}
	}
}

void UInteractiveTriggerComponent::CheckDetectDistanceMonitor()
{
	const int32 MonitorNum = DetectDistanceMonitors.Num();
	if (MonitorNum <= 0)
	{
		return;
	}

	FVector DetectPos = OwnerActor->GetActorLocation();
	
	TArray<KGEntityID> ToRemoves;
	ToRemoves.Reserve(MonitorNum);
	TArray<TTuple<KGEntityID, float>> ToUpdates;
	ToUpdates.Reserve(MonitorNum);
	for (auto &Elem: DetectDistanceMonitors)
	{
		KGEntityID OwnerUID = Elem.Key;
		if (!Elem.Value.TargetActor.IsValid())
		{
			ToRemoves.Add(OwnerUID);
			continue;
		}
		AActor* Actor = Elem.Value.TargetActor.Get();
		auto& MonitorInfo = Elem.Value;
		float CurDistance = MonitorInfo.CurDistance;
		float MaxDistance = MonitorInfo.MaxDistance;
		
		float Distance = FVector::Distance(DetectPos, Actor->GetActorLocation());
		bool bNeedUpdate = CurDistance < 0 || FMath::Abs(CurDistance - Distance) > 5;
		MonitorInfo.CurDistance = Distance;
		if (bNeedUpdate)
		{
			if (Distance <= MaxDistance)
			{
				MonitorInfo.bEverOutRange = false;
				ToUpdates.Add(TTuple<KGEntityID, float>(OwnerUID, Distance));
			}
			// 首次超出最大距离，给一个回调
			else if (!MonitorInfo.bEverOutRange)
			{
				MonitorInfo.bEverOutRange = true;
				ToUpdates.Add(TTuple<KGEntityID, float>(OwnerUID, Distance));
			}
		}
	}

	for (const auto &Elem : ToUpdates)
	{
		DetectPlayerDistanceChanged_MD.Broadcast(Elem.Key, Elem.Value);
	}
	
	for (KGEntityID OwnerUID: ToRemoves)
	{
		UnRegisterDetectDistanceMonitor(OwnerUID);
	}
}

void UInteractiveTriggerComponent::RegisterDetectDistanceMonitor(int64 InOwnerUID, float MaxDistance)
{
	auto Entity = UKGUEActorManager::GetLuaEntity(GetWorld(), InOwnerUID);
	if (!Entity)
	{
		UE_LOG(LogTemp, Error, TEXT("UInteractiveTriggerComponent::RegisterDetectDistanceMonitor get Entity failed, EntityId[%lld]"), InOwnerUID);
		return;
	}
	AActor* BindActor = Entity->GetLuaEntityBase()->GetActor();
	if (!BindActor)
	{
		UE_LOG(LogTemp, Error, TEXT("UInteractiveTriggerComponent::RegisterDetectDistanceMonitor get Actor failed, EntityId[%lld]"), InOwnerUID);
		return;
	}

	if (!DetectDistanceMonitors.Contains(InOwnerUID))
	{
		DetectDistanceMonitors.Add(InOwnerUID, FDistanceMonitorInfo(MaxDistance, BindActor));
	}
	else
	{
		auto &CurInfo = DetectDistanceMonitors[InOwnerUID];
		CurInfo.MaxDistance = MaxDistance;
		CurInfo.TargetActor = BindActor;
	}

	UpdateComponentTickEnabled();
}

void UInteractiveTriggerComponent::UnRegisterDetectDistanceMonitor(int64 InOwnerEntityID)
{
	if (DetectDistanceMonitors.Contains(InOwnerEntityID))
	{
		DetectDistanceMonitors.Remove(InOwnerEntityID);
	}
}

bool UInteractiveTriggerComponent::IsEntityEnteredScope(int64 InUID)
{
	if (!EnterScopeActorMap.Contains(InUID))
	{
		return false;
	}
	return EnterScopeActorMap[InUID].IsValid();
}

void UInteractiveTriggerComponent::EnableSweepDetect(bool bInEnable, float InMaxSpeedPerSeconds)
{
	bEnableSweepDetect = bInEnable;
	MaxSpeedPerSeconds = InMaxSpeedPerSeconds;
	ClearDetectState();
}

void UInteractiveTriggerComponent::ClearDetectState()
{
	bLastDetectLocationSet = false;
}

void UInteractiveTriggerComponent::EnableIndoorFiledDetect(bool bInEnable, EObjectTypeQuery InIndoorQueryObjectType, EObjectTypeQuery InIndoorTraceObjectType, FName InInDoorObjectRootTag, float InIndoorMaxTraceDistance)
{
	IndoorDetectParams.bEnableIndoorFieldDetect = bInEnable;
	IndoorDetectParams.IndoorMaxTraceDistance = InIndoorMaxTraceDistance;
	IndoorDetectParams.InDoorObjectRootTag = InInDoorObjectRootTag;
	IndoorDetectParams.IndoorObjectType = InIndoorQueryObjectType;
	DetectObjectTypes.AddUnique(InIndoorQueryObjectType);
	IndoorDetectParams.IndoorTraceObjectType = InIndoorTraceObjectType;
}

void UInteractiveTriggerComponent::SetOwnerIntUID(int64 InOwnerUID)
{
	OwnerIntUID = InOwnerUID;
}

void UInteractiveTriggerComponent::ResetTriggerSize(float InTriggerHalfHeight, float InTriggerRadius)
{
	TriggerHalfHeight = InTriggerHalfHeight;
	TriggerRadius = InTriggerRadius;

	//先用胶囊体前期用
	SetCapsuleSize(TriggerRadius, TriggerHalfHeight);
}

void UInteractiveTriggerComponent::AddPlayerDistanceMonitor(bool bEnable, float MaxDis, bool bWithTickCheck)
{
	if (MaxDis > PlayerDistanceMax)
		PlayerDistanceMax = MaxDis;

	PlayerDistanceMax = bEnable ? PlayerDistanceMax : -1.0f;
	if (bWithTickCheck)
	{
		bPlayerDistanceMonitorWithTickCheck = PlayerDistanceMax > 0.0f;
		UpdateComponentTickEnabled();
	}
}
#pragma region CustomInteractive

void UInteractiveTriggerComponent::CheckDetectCustomInteractable()
{
	QUICK_SCOPE_CYCLE_COUNTER(InteractiveTriggerComponent_CheckDetectCustomInteractable);
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UInteractiveTriggerComponent_CheckDetectCustomInteractable");
	// 自定义可交互元素
	if (CustomElementsByToken.IsEmpty())
	{
		return;
	}

	UKGUEActorManager* ActorManager = nullptr;
	if (OwnerActor.IsValid())
	{
		ActorManager = UKGUEActorManager::GetInstance(OwnerActor.Get());
	}
	if (ActorManager == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("CheckDetectCustomInteractable can not found actor manager : %lld"), OwnerIntUID);
		return;
	}
	
	FVector OwnerLocation = OwnerActor->GetActorLocation();
	TSet<int32> CurInRangeElements;
	for (auto It = CustomElementsByToken.CreateIterator(); It; ++It)
	{
		int32 Token = It->Key;
		bool bElementValid = true;
		if (CheckElementIntersect(ActorManager, It->Value, OwnerLocation, bElementValid) && It->Value.bEnableInteract)
		{
			CurInRangeElements.Add(Token);
		}
		if (!bElementValid)
		{
			It.RemoveCurrent();
		}
	}
	
	for (auto& Token: InRangeElementsByToken)
	{
		if (!CurInRangeElements.Contains(Token))
		{
			NotifyInteractableElementEnterOrLeave(Token, false);
		}
	}
	
	for (auto& Token: CurInRangeElements)
	{
		if (!InRangeElementsByToken.Contains(Token))
		{
			NotifyInteractableElementEnterOrLeave(Token, true);
		}
	}

	InRangeElementsByToken = MoveTemp(CurInRangeElements);
}

bool UInteractiveTriggerComponent::CheckElementIntersect(class UKGUEActorManager* ActorManager, const FCustomInteractableElement& Element, const FVector& DetectPos, bool& OutElementValid) const
{
	bool bIntersect = false;
	ICppEntityInterface* ScriptEntity = ActorManager->GetLuaEntity(Element.BindEntityID);
	AActor* ElementBindActor = (ScriptEntity && ScriptEntity->GetLuaEntityBase()) ? ScriptEntity->GetLuaEntityBase()->GetActor() : nullptr;
	if (ElementBindActor == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("CheckElementIntersect can not found bind actor EntityID:[%lld]"), Element.BindEntityID)
		OutElementValid = false;
		return bIntersect;
	}

	FVector ElementLocation = Element.Location;
	FQuat ElementRotation = Element.Rotation;
	if (Element.TransformType == ECustomInteractableTransformType::ActorSpace)
	{
		FTransform ElementActorToWorld = ElementBindActor->GetTransform();
		ElementLocation = ElementActorToWorld.TransformPosition(ElementLocation);
		ElementRotation = ElementActorToWorld.TransformRotation(ElementRotation);
	}
	
	float AbsZOffset = FMath::Abs(ElementLocation.Z - DetectPos.Z);
	if (Element.ShapeType == EC7ShapeCollisionType::Sphere)
	{
		float ElemRadius = Element.ShapeParam.X;
		// 先比Z的差距，如果通过直接计算2d的就好了
		if (AbsZOffset > ElemRadius + TriggerHalfHeight)
		{
			bIntersect = false;
		}
		else
		{
			float Distance2DSquared = (DetectPos - ElementLocation).SizeSquared2D();
			bIntersect = Distance2DSquared <= (ElemRadius + TriggerRadius) * (ElemRadius + TriggerRadius);
		}
#if UE_BUILD_DEVELOPMENT
		if (bDebugDrawCustomInteractable)
		DrawDebugSphere(GetWorld(), ElementLocation, ElemRadius, 16, bIntersect ? FColor::Red : FColor::Green, false, GetComponentTickInterval(), 0, 8);
#endif
	}
	else if (Element.ShapeType == EC7ShapeCollisionType::Box)
	{
		// 先比Z的差距，如果通过直接计算2d的就好了
		if (AbsZOffset > Element.ShapeParam.Z + TriggerHalfHeight)
		{
			bIntersect = false;
		}
		else
		{
			FVector2d CircleCenter = FVector2d(DetectPos.X, DetectPos.Y);
			FVector2d OBBCenter = FVector2d(ElementLocation.X, ElementLocation.Y);
			FVector2D OBBHalfExtents = FVector2d(Element.ShapeParam.X, Element.ShapeParam.Y);
			float YawAngle = FMath::DegreesToRadians(ElementRotation.Rotator().Yaw);
			
			// 1. 计算圆心到OBB中心的向量
			FVector2D WorldOffset = CircleCenter - OBBCenter;
    
			// 2. 构建反向旋转矩阵（将世界坐标变换到OBB局部坐标）
			float CosAngle = FMath::Cos(-YawAngle);
			float SinAngle = FMath::Sin(-YawAngle);
    
			// 3. 将偏移向量变换到OBB局部坐标系
			FVector2D LocalOffset;
			LocalOffset.X = WorldOffset.X * CosAngle - WorldOffset.Y * SinAngle;
			LocalOffset.Y = WorldOffset.X * SinAngle + WorldOffset.Y * CosAngle;
    
			// 4. 在局部坐标系中，OBB现在是轴对齐的
			// 找到OBB上距离圆心最近的点
			FVector2D ClosestPoint;
			ClosestPoint.X = FMath::Clamp(LocalOffset.X, -OBBHalfExtents.X, OBBHalfExtents.X);
			ClosestPoint.Y = FMath::Clamp(LocalOffset.Y, -OBBHalfExtents.Y, OBBHalfExtents.Y);
    
			// 5. 计算最近点到圆心的距离平方
			FVector2D Difference = LocalOffset - ClosestPoint;
			float DistanceSquared = Difference.SizeSquared();
			bIntersect = DistanceSquared <= (TriggerRadius * TriggerRadius);
		}
		
#if UE_BUILD_DEVELOPMENT
		if (bDebugDrawCustomInteractable)
		DrawDebugBox(GetWorld(), ElementLocation, Element.ShapeParam, ElementRotation, bIntersect ? FColor::Red : FColor::Green, false, GetComponentTickInterval(), 0, 8);
#endif
	}
	return bIntersect;
}

void UInteractiveTriggerComponent::RegisterBoxInteractableElement(float X, float Y, float Z, float Yaw, float BoxExtentX, float BoxExtentY, float BoxExtentZ, int64 EntityID, int32 Token, ECustomInteractableTransformType TransformType)
{
	if (CustomElementsByToken.Contains(Token))
	{
		UE_LOG(LogTemp, Error, TEXT("RegisterBoxInteractableElement found exist token:%d"), Token)
		return;
	}
	FCustomInteractableElement Element;
	Element.Location = FVector(X, Y, Z);
	Element.Rotation = FRotator(0, Yaw, 0).Quaternion();
	Element.ShapeType = EC7ShapeCollisionType::Box;
	Element.ShapeParam = FVector(BoxExtentX, BoxExtentY, BoxExtentZ);
	Element.BindEntityID = EntityID;
	Element.Token = Token;
	Element.TransformType = TransformType;
	RegisterSingleInteractableElement(Element);
}

void UInteractiveTriggerComponent::RegisterSphereInteractableElement(float X, float Y, float Z, float Radius, int64 EntityID, int32 Token, ECustomInteractableTransformType TransformType)
{
	if (CustomElementsByToken.Contains(Token))
	{
		UE_LOG(LogTemp, Error, TEXT("RegisterSphereInteractableElement found exist token:%d"), Token)
		return;
	}
	FCustomInteractableElement Element;
	Element.Location = FVector(X, Y, Z);
	Element.Rotation = FQuat::Identity;
	Element.ShapeType = EC7ShapeCollisionType::Sphere;
	Element.ShapeParam.X = Radius;
	Element.BindEntityID = EntityID;
	Element.Token = Token;
	Element.TransformType = TransformType;
	RegisterSingleInteractableElement(Element);
}

void UInteractiveTriggerComponent::RegisterSingleInteractableElement(const FCustomInteractableElement& Element)
{
	if (!CustomElementsByToken.Contains(Element.Token))
	{
		CustomElementsByToken.Add(Element.Token, Element);
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("RegisterElement found exist token:%d"), Element.Token)
	}
}

void UInteractiveTriggerComponent::UnRegisterSingleInteractableElement(int32 ElementToken)
{
	if (CustomElementsByToken.Contains(ElementToken))
	{
		CustomElementsByToken.Remove(ElementToken);
	}
}


void UInteractiveTriggerComponent::EnableInteractiveForElement(int32 ElementToken, bool bEnable)
{
	if (CustomElementsByToken.Contains(ElementToken))
	{
		auto& Element = CustomElementsByToken[ElementToken];
		Element.bEnableInteract = bEnable;
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("EnableInteractiveForElement can not found token:%d"), ElementToken)
	}
}

void UInteractiveTriggerComponent::NotifyInteractableElementEnterOrLeave(const int32& Token, bool bEnter)
{
	if (CustomElementsByToken.Contains(Token))
	{
		if (ABaseCharacter* Character = Cast<ABaseCharacter>(GetOwner()))
		{
			ACTOR_CALL_LUA_ENTITY(Character, "KCB_NotifyInteractableElementEnterOrLeave", CustomElementsByToken[Token].BindEntityID, Token, bEnter);
		}
	}

}

#pragma endregion CustomInteractive

#pragma region NewAirWall
void UInteractiveTriggerComponent::UpdateNewAirWallData(const float& InDeltaTime)
{
	QUICK_SCOPE_CYCLE_COUNTER(InteractiveTriggerComponent_UpdateNewAirWallInfo);
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UInteractiveTriggerComponent_UpdateNewAirWallInfo");

	bool bInSoftAirWall = false;
	bool bInForceLeaveArea = false;
	
	// 这里检查是否要触发强制离开逻辑
	if (CurAirWallAreaState == ENewAirWallAreaState::ENAWAS_InSoftAirWall)
	{
		SoftAirWallForceLeaveCountDuration += InDeltaTime;
#if UE_BUILD_DEVELOPMENT
		if(bNeedShowNewAirWallDebugInfo){ UE_LOG(LogTemp, Warning, TEXT("[NewAirWall]软空气墙, SoftAirWallForceLeaveCountDuration:%f"), SoftAirWallForceLeaveCountDuration); }
#endif
		if (SoftAirWallForceLeaveCountDuration > SoftAirWallMaxDuration)
		{
#if UE_BUILD_DEVELOPMENT
			if (bNeedShowNewAirWallDebugInfo) { UE_LOG(LogTemp, Warning, TEXT("[NewAirWall]Enter 强制撤离 from 软空气墙!")); }
#endif
			// 触发强制离开逻辑
			CheckDetectedInteractableHitResultsForAirWall(true, bInSoftAirWall, bInForceLeaveArea);
			StartForceLeaving();
			return;
		}
	}
	else if (CurAirWallAreaState == ENewAirWallAreaState::ENAWAS_InForceLeaveArea)
	{
		SoftAirWallForceLeaveCountDuration += InDeltaTime;
		ForceLeaveAreaForceLeaveCountDuration += InDeltaTime;
#if UE_BUILD_DEVELOPMENT
		if (bNeedShowNewAirWallDebugInfo) {UE_LOG(LogTemp, Warning, TEXT("[NewAirWall]强制撤离区域中, SoftAirWallForceLeaveCountDuration:%f, ForceLeaveAreaForceLeaveCountDuration:%f"),
				SoftAirWallForceLeaveCountDuration, ForceLeaveAreaForceLeaveCountDuration);}
#endif
		if (SoftAirWallForceLeaveCountDuration > SoftAirWallMaxDuration || ForceLeaveAreaForceLeaveCountDuration > ForceLeaveAreaMaxDuration)
		{
#if UE_BUILD_DEVELOPMENT
			if (bNeedShowNewAirWallDebugInfo) { UE_LOG(LogTemp, Warning, TEXT("[NewAirWall]Enter 强制撤离 from 强制撤离区域!")); }
#endif
			// 触发强制离开逻辑
			CheckDetectedInteractableHitResultsForAirWall(true, bInSoftAirWall, bInForceLeaveArea);
			StartForceLeaving();
			return;
		}
	}
	
	// 检查DetectedInteractableHitResults的Tag信息
	CheckDetectedInteractableHitResultsForAirWall(false, bInSoftAirWall, bInForceLeaveArea);

	// 如果处于强制撤离逻辑中，优先处理离开逻辑
	if (CurAirWallAreaState == ENewAirWallAreaState::ENAWAS_ForceLeaving)
	{
		if (!bInSoftAirWall && !bInForceLeaveArea)
		{
#if UE_BUILD_DEVELOPMENT
			if (bNeedShowNewAirWallDebugInfo) {UE_LOG(LogTemp, Warning, TEXT("[NewAirWall]Enter ENAWAS_None from 强制撤离!"));}
#endif
			// Todo:成功撤离空气墙?
			StopForceLeaving();
		}

		return;
	}

	// 没有触发强制撤离逻辑，则检查内部状态流转
	if (bInForceLeaveArea)
	{
		if (CurAirWallAreaState != ENewAirWallAreaState::ENAWAS_InForceLeaveArea)
		{
			// 触发进入强制撤离区域
			if (CurAirWallAreaState == ENewAirWallAreaState::ENAWAS_None)
			{
				// 从None直接到强制撤离区域时，还需要重置软空气墙的计时
				SoftAirWallForceLeaveCountDuration = 0.0f;
			}
#if UE_BUILD_DEVELOPMENT
			if (bNeedShowNewAirWallDebugInfo) {UE_LOG(LogTemp, Warning, TEXT("[NewAirWall]Enter 强制撤离区域!"));}
#endif
			SetCurAirWallAreaState(ENewAirWallAreaState::ENAWAS_InForceLeaveArea);
			ForceLeaveAreaForceLeaveCountDuration = 0.0f;
		}
	}
	else if (bInSoftAirWall)
	{
		if (CurAirWallAreaState == ENewAirWallAreaState::ENAWAS_InForceLeaveArea)
		{
			// 触发强制撤离区域回到软空气墙
			SetCurAirWallAreaState(ENewAirWallAreaState::ENAWAS_InSoftAirWall);
			ForceLeaveAreaForceLeaveCountDuration = 0.0f;
#if UE_BUILD_DEVELOPMENT
			if (bNeedShowNewAirWallDebugInfo) {UE_LOG(LogTemp, Warning, TEXT("[NewAirWall]Enter 软空气墙 from 强制撤离!"));}
#endif
		}
		else if (CurAirWallAreaState == ENewAirWallAreaState::ENAWAS_None)
		{
			// 触发None到软空气墙
			SetCurAirWallAreaState(ENewAirWallAreaState::ENAWAS_InSoftAirWall);
			SoftAirWallForceLeaveCountDuration = 0.0f;
			ForceLeaveAreaForceLeaveCountDuration = 0.0f;
#if UE_BUILD_DEVELOPMENT
			if (bNeedShowNewAirWallDebugInfo) {UE_LOG(LogTemp, Warning, TEXT("[NewAirWall]Enter 软空气墙 from ENAWAS_None!"));}
#endif
		}
	}
	else if(CurAirWallAreaState != ENewAirWallAreaState::ENAWAS_None)
	{
		// 触发软空气墙/强制撤离区域回到None
		SetCurAirWallAreaState(ENewAirWallAreaState::ENAWAS_None);
		SoftAirWallForceLeaveCountDuration = 0.0f;
		ForceLeaveAreaForceLeaveCountDuration = 0.0f;
#if UE_BUILD_DEVELOPMENT
		if (bNeedShowNewAirWallDebugInfo) {UE_LOG(LogTemp, Warning, TEXT("[NewAirWall]Enter ENAWAS_None!"));}
#endif
		bHasValidLeavingAreaTargetLoc = false;
	}
}

void UInteractiveTriggerComponent::StartForceLeaving()
{
	SetCurAirWallAreaState(ENewAirWallAreaState::ENAWAS_ForceLeaving);
	if (bHasValidLeavingAreaTargetLoc)
	{
		if (ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(OwnerActor.Get()))
		{
			ACTOR_CALL_LUA_ENTITY(BaseCharacter, "KCB_OnStartForceLeaving", LeavingAreaTargetLoc);
		}
#if UE_BUILD_DEVELOPMENT
		else if (bNeedShowNewAirWallDebugInfo) {
			UE_LOG(LogTemp, Warning, TEXT("[NewAirWall] Failed to StartForceLeaving! OwnerActor is not ABaseCharacter!"));
		}
#endif
	}
#if UE_BUILD_DEVELOPMENT
	else if (bNeedShowNewAirWallDebugInfo) {
		UE_LOG(LogTemp, Warning, TEXT("[NewAirWall] Failed to StartForceLeaving! No Valid LeavingAreaTargetLoc!"));
	}
#endif
}

void UInteractiveTriggerComponent::CheckDetectedInteractableHitResultsForAirWall(bool InNeedCalculateLeavingAreaTargetLoc, bool& OutbInSoftAirWall, bool& OutbInForceLeaveArea)
{
	// 检查DetectedInteractableHitResults的Tag信息
	OutbInSoftAirWall = false;
	OutbInForceLeaveArea = false;
	for (const FHitResult& SingleHitResult : DetectedInteractableHitResults)
	{
		if (OutbInForceLeaveArea && (!InNeedCalculateLeavingAreaTargetLoc || (InNeedCalculateLeavingAreaTargetLoc && bHasValidLeavingAreaTargetLoc)))
		{
			// 如果确定处于强制撤离区域，并且“已经找到撤离点/不需要找撤离点”，就不用再遍历剩余的HitRes了
			break;
		}

		if (UPrimitiveComponent* SingleCompPtr = SingleHitResult.Component.Get())
		{
			if (SingleCompPtr->ComponentHasTag(SoftAirWallTag))
			{
				OutbInSoftAirWall = true;
				if (InNeedCalculateLeavingAreaTargetLoc)
				{
					if (!CalculateLeavingAreaTargetLocBySpline(SingleHitResult))
					{
						CalculateLeavingAreaTargetLocInSoftAirWall(SingleHitResult);
					}
				}
			}
			else if (SingleCompPtr->ComponentHasTag(ForceLeaveAreaTag))
			{
				OutbInForceLeaveArea = true;
				if (InNeedCalculateLeavingAreaTargetLoc)
				{
					if (!CalculateLeavingAreaTargetLocBySpline(SingleHitResult))
					{
						CalculateLeavingAreaTargetLocInForceLeaveArea(SingleHitResult);
					}
				}
			}
		}
	}
}

void UInteractiveTriggerComponent::StopForceLeaving()
{
	SetCurAirWallAreaState(ENewAirWallAreaState::ENAWAS_None);
	SoftAirWallForceLeaveCountDuration = 0.0f;
	ForceLeaveAreaForceLeaveCountDuration = 0.0f;
	bHasValidLeavingAreaTargetLoc = false;
	if (ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(OwnerActor.Get()))
	{
		ACTOR_CALL_LUA_ENTITY(BaseCharacter, "KCB_StopForceLeaving");
	}
}

void UInteractiveTriggerComponent::SetCurAirWallAreaState(ENewAirWallAreaState InNewAirWallAreaState)
{
	if (CurAirWallAreaState == InNewAirWallAreaState) 
	{ 
		// 相同的State忽略
		return; 
	}

	if (CurAirWallAreaState == ENewAirWallAreaState::ENAWAS_None)
	{
		// 从区域外进入空气墙，开启特效/重新过渡Alpha回1
		if (ScreenNiagaraID <= 0)
		{
			ActivateScreenNiagara(InNewAirWallAreaState == ENewAirWallAreaState::ENAWAS_InSoftAirWall ? SoftAirWallMaxDuration : ForceLeaveAreaMaxDuration);
		}
	}

	CurAirWallAreaState = InNewAirWallAreaState;

	if (CurAirWallAreaState == ENewAirWallAreaState::ENAWAS_None)
	{
		// 从区域内离开空气墙，开始过渡Alpha到0
		SetTargetScreenNiagaraBlendTime(0.0f, ScreenNiagaraBlendOutDuration);
	}
	else if (CurAirWallAreaState == ENewAirWallAreaState::ENAWAS_ForceLeaving)
	{
		// 进入强制离开，暂停过渡
		StopScreenNiagaraBlend();
	}
	else if (CurAirWallAreaState == ENewAirWallAreaState::ENAWAS_InSoftAirWall)
	{
		// 进入软空气墙或强制撤离区域，更新Blend时间
		SetTargetScreenNiagaraBlendTime(1.0f, SoftAirWallMaxDuration - SoftAirWallForceLeaveCountDuration);
	}
	else if (CurAirWallAreaState == ENewAirWallAreaState::ENAWAS_InForceLeaveArea)
	{
		SetTargetScreenNiagaraBlendTime(1.0f, FMath::Min(SoftAirWallMaxDuration - SoftAirWallForceLeaveCountDuration, ForceLeaveAreaMaxDuration - ForceLeaveAreaForceLeaveCountDuration));
	}
}

void UInteractiveTriggerComponent::ActivateScreenNiagara(float InBlendDuration)
{
	if (OwnerActor.IsValid())
	{
		if (UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(OwnerActor.Get()))
		{
			if (ScreenNiagaraID <= 0)
			{
				FKGPlayNiagaraParams PlayNiagaraParams;
				PlayNiagaraParams.NiagaraEffectPath = NewAirWallScreenNiagaraPath;
				PlayNiagaraParams.SpawnerID = KGUtils::GetIDByObject(OwnerActor.Get());
				PlayNiagaraParams.bFollowCameraFOV = true;

				FKGAttachedNiagaraSpawnInfo AttachedNiagaraSpawnInfo;
				AttachedNiagaraSpawnInfo.SearchAttachComponentType = EKGNiagaraSearchAttachComponentType::UseCameraRootComponent;
				PlayNiagaraParams.SetAttachedSpawnInfo(AttachedNiagaraSpawnInfo);

				ScreenNiagaraID = EffectManager->CreateNiagaraSystem(PlayNiagaraParams);
			}

			if (ScreenNiagaraID > 0)
			{
				EffectManager->AddLinearSampleFloatParams(ScreenNiagaraID, ScreenNiagaraAlphaParamName, 0.0f, 1.0f, InBlendDuration, false);
#if UE_BUILD_DEVELOPMENT
				if (bNeedShowNewAirWallDebugInfo) { UE_LOG(LogTemp, Warning, TEXT("[NewAirWall]ActivateScreenNiagara! BlendDuration:%f"), InBlendDuration); }
#endif
			}
		}
	}
}

void UInteractiveTriggerComponent::DeActivateScreenNiagara()
{
	if (ScreenNiagaraID > 0)
	{
		if (UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(this))
		{
			EffectManager->DestroyNiagaraSystem(ScreenNiagaraID);
			ScreenNiagaraID = -1;
#if UE_BUILD_DEVELOPMENT
			if (bNeedShowNewAirWallDebugInfo) { UE_LOG(LogTemp, Warning, TEXT("[NewAirWall]DestroyNiagaraSystem!")); }
#endif
		}
	}

	if (ScreenNiagaraDeleteTimeHandle.IsValid())
	{
		if (UWorld* World = GetWorld())
		{
			World->GetTimerManager().ClearTimer(ScreenNiagaraDeleteTimeHandle);
		}
	}
}

void UInteractiveTriggerComponent::SetTargetScreenNiagaraBlendTime(float InTime, float InBlendDuration)
{
	if (ScreenNiagaraID > 0)
	{
		if (UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(this))
		{
			EffectManager->UpdateLinearSampleParamTargetValue(ScreenNiagaraID, ScreenNiagaraAlphaParamName, InTime, true, InBlendDuration);
#if UE_BUILD_DEVELOPMENT
			if (bNeedShowNewAirWallDebugInfo) { UE_LOG(LogTemp, Warning, TEXT("[NewAirWall]UpdateScreenNiagara! TargetAlpha:%f, BlendDuration:%f"), InTime, InBlendDuration); }
#endif

			// 重新开启往非0做blend，关闭ScreenNiagaraDeleteTimeHandle
			if (InTime > 0.0f && ScreenNiagaraDeleteTimeHandle.IsValid())
			{
				if (UWorld* World = GetWorld())
				{
					World->GetTimerManager().ClearTimer(ScreenNiagaraDeleteTimeHandle);
				}
			}
			else if (InTime <= 0.0f)
			{
				SetTimerToDeActivateScreenNiagara();
			}
		}
	}
}

void UInteractiveTriggerComponent::StopScreenNiagaraBlend()
{
	if (ScreenNiagaraID > 0)
	{
		if (UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(this))
		{
			EffectManager->FinishLinearSampleParamTask(ScreenNiagaraID, ScreenNiagaraAlphaParamName);
		}
	}
}

void UInteractiveTriggerComponent::SetTimerToDeActivateScreenNiagara()
{
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(ScreenNiagaraDeleteTimeHandle);
		World->GetTimerManager().SetTimer(
			ScreenNiagaraDeleteTimeHandle,
			FTimerDelegate::CreateUObject(this, &UInteractiveTriggerComponent::DeActivateScreenNiagara),
			ScreenNiagaraBlendOutDuration, false);
	}
}

bool UInteractiveTriggerComponent::CalculateLeavingAreaTargetLocBySpline(const FHitResult& InHitRes)
{
	if (bHasValidLeavingAreaTargetLoc)
	{
		// 已经有撤离点，不再重复寻找
		return true;
	}
	
	if (IsValid(InHitRes.Component.Get()))
	{
		if (USplineMeshComponent* SplineMeshComp = Cast<USplineMeshComponent>(InHitRes.Component.Get()))
		{
			if (ABlockoutToolsParent* HitCompOwner = Cast<ABlockoutToolsParent>(SplineMeshComp->GetOwner()))
			{
				TArray<USplineComponent*> Components;
				HitCompOwner->GetComponents(USplineComponent::StaticClass(), Components);
				if (Components.Num() > 0)
				{
					bool HasValidSplineRes = false;
					float MinDist = BIG_NUMBER;
					FVector NearestLoc = FVector::ZeroVector;
					FVector Tangent = FVector::ZeroVector;
					for (const USplineComponent* TempSpline : Components)
					{
						if (TempSpline->ComponentHasTag(ForceLeaveSplineTag))
						{
							float TempFloat = TempSpline->FindInputKeyClosestToWorldLocation(InHitRes.Location);
							FVector TempLoc = TempSpline->GetLocationAtSplineInputKey(TempFloat, ESplineCoordinateSpace::World);
							FVector TempTangent = TempSpline->GetTangentAtSplineInputKey(TempFloat, ESplineCoordinateSpace::World);
							TempFloat = (TempLoc - InHitRes.Location).Size2D();
							if (TempFloat < MinDist)
							{
								NearestLoc = TempLoc;
								Tangent.Set(TempTangent.X, TempTangent.Y, 0.0f);
								MinDist = TempFloat;
								HasValidSplineRes = true;
							}
						}
					}
					if (!HasValidSplineRes)
					{
						UE_LOG(LogTemp, Warning, TEXT("[NewAirWall]No Force Leaving Spline!"));
						return false;
					}
					
					//NearestLoc.Z = InHitRes.Location.Z;
#if UE_BUILD_DEVELOPMENT
					if (bNeedShowNewAirWallDebugInfo) {
						UKismetSystemLibrary::DrawDebugSphere(this, NearestLoc, 30.0f, 12, FLinearColor::Yellow, 5.0f, 3.0f);
						UKismetSystemLibrary::DrawDebugSphere(this, InHitRes.Location, 30.0f, 12, FLinearColor::Blue, 5.0f, 3.0f);
					}
#endif
					// NearestLoc往角色反方向外延3m
					FVector DeltaLocToImpactPoint2D = NearestLoc - InHitRes.ImpactPoint; DeltaLocToImpactPoint2D.Z = 0.0f;
					FVector OutWallDir = Tangent.RotateAngleAxis(90.0f, FVector(0.0f, 0.0f, 1.0f));
					if (OutWallDir.Dot(DeltaLocToImpactPoint2D) < 0.0f) {
						OutWallDir = Tangent.RotateAngleAxis(-90.0f, FVector(0.0f, 0.0f, 1.0f));
					}
					NearestLoc = NearestLoc + 300.0f * OutWallDir.GetSafeNormal2D();
#if UE_BUILD_DEVELOPMENT
					if (bNeedShowNewAirWallDebugInfo) {
						UKismetSystemLibrary::DrawDebugSphere(this, NearestLoc, 30.0f, 12, FLinearColor::Green, 5.0f, 3.0f);
					}
#endif
					return SetOnGroundLeavingAreaTargetLoc(NearestLoc);
				}
			}
		}
	}

	return false;
}

void UInteractiveTriggerComponent::CalculateLeavingAreaTargetLocInForceLeaveArea(const FHitResult& InHitRes)
{
	if (bHasValidLeavingAreaTargetLoc)
	{
		// 已经有撤离点，不再重复寻找
		return;
	}

	if (USplineMeshComponent* SplineMeshComp = Cast<USplineMeshComponent>(InHitRes.Component.Get()))
	{
		FVector WallVerticleNormal2D = SplineMeshComp->GetStartTangent(); WallVerticleNormal2D.Z = 0.0f;
		FVector StartTangent2DNormal = WallVerticleNormal2D.GetSafeNormal2D();
		WallVerticleNormal2D = SplineMeshComp->GetEndTangent(); WallVerticleNormal2D.Z = 0.0f;
		FVector EndTangent2DNormal = WallVerticleNormal2D.GetSafeNormal2D();

		WallVerticleNormal2D = StartTangent2DNormal + EndTangent2DNormal;
		if (WallVerticleNormal2D.IsNearlyZero())
		{
			WallVerticleNormal2D = StartTangent2DNormal.RotateAngleAxis(90.0f, FVector(0.0f, 0.0f, 1.0f));
		}
		else
		{
			WallVerticleNormal2D = WallVerticleNormal2D.GetSafeNormal2D();
			WallVerticleNormal2D = WallVerticleNormal2D.RotateAngleAxis(90.0f, FVector(0.0f, 0.0f, 1.0f));
		}

		FTransform ComponentToWorldTransform = SplineMeshComp->GetComponentTransform();
		FBoxSphereBounds CalculatedBounds = SplineMeshComp->CalcBounds(ComponentToWorldTransform);
		FVector ForceLeaveAreaCenterWithActorHeight = CalculatedBounds.Origin; ForceLeaveAreaCenterWithActorHeight.Z = InHitRes.Location.Z;
		float DetectLength = CalculatedBounds.BoxExtent.Size2D();

		TArray<FHitResult> HitReses;
		TArray<AActor*> ActorsToIgnore;

		FVector ValidLocationInForceLeaveArea = ForceLeaveAreaCenterWithActorHeight - InHitRes.ImpactPoint; ValidLocationInForceLeaveArea.Z = 0.0f;
		if (ValidLocationInForceLeaveArea.IsNearlyZero())
		{
			ValidLocationInForceLeaveArea = InHitRes.ImpactPoint;
		}
		else
		{
			float Length = FMath::Min(ValidLocationInForceLeaveArea.Size2D(), 10.0f);
			ValidLocationInForceLeaveArea = InHitRes.ImpactPoint + Length * ValidLocationInForceLeaveArea.GetSafeNormal2D();
		}

		UKismetSystemLibrary::LineTraceMultiForObjects(GetWorld(), ValidLocationInForceLeaveArea, ForceLeaveAreaCenterWithActorHeight + DetectLength * WallVerticleNormal2D,
			DetectObjectTypes, false, ActorsToIgnore, EDrawDebugTrace::None, HitReses, true);
		for (const FHitResult& SingleHit : HitReses)
		{
			if (UPrimitiveComponent* HitComp = SingleHit.Component.Get())
			{
				if (HitComp->ComponentHasTag(SoftAirWallTag))
				{
					CalculateLeavingAreaTargetLocInSoftAirWall(SingleHit);
					return;
				}
			}
		}

		// 反向再找一次
		WallVerticleNormal2D = WallVerticleNormal2D.RotateAngleAxis(180.0f, FVector(0.0f, 0.0f, 1.0f));
		UKismetSystemLibrary::LineTraceMultiForObjects(GetWorld(), ValidLocationInForceLeaveArea, ForceLeaveAreaCenterWithActorHeight + DetectLength * WallVerticleNormal2D,
			DetectObjectTypes, false, ActorsToIgnore, EDrawDebugTrace::None, HitReses, true);
		for (const FHitResult& SingleHit : HitReses)
		{
			if (UPrimitiveComponent* HitComp = SingleHit.Component.Get())
			{
				if (HitComp->ComponentHasTag(SoftAirWallTag))
				{
					CalculateLeavingAreaTargetLocInSoftAirWall(SingleHit);
					return;
				}
			}
		}
	}
	else
	{
		SetOnGroundLeavingAreaTargetLoc(OwnerActor->GetActorLocation() + InHitRes.Normal.GetSafeNormal2D() * 300.0f);
	}
}

void UInteractiveTriggerComponent::CalculateLeavingAreaTargetLocInSoftAirWall(const FHitResult& InHitRes)
{
	if (bHasValidLeavingAreaTargetLoc)
	{
		// 已经有撤离点，不再重复寻找
		return;
	}

	if (USplineMeshComponent* SplineMeshComp = Cast<USplineMeshComponent>(InHitRes.Component.Get()))
	{
		FVector WallVerticleNormal2D = SplineMeshComp->GetStartTangent(); WallVerticleNormal2D.Z = 0.0f;
		FVector StartTangent2DNormal = WallVerticleNormal2D.GetSafeNormal2D();
		WallVerticleNormal2D = SplineMeshComp->GetEndTangent(); WallVerticleNormal2D.Z = 0.0f;
		FVector EndTangent2DNormal = WallVerticleNormal2D.GetSafeNormal2D();

		WallVerticleNormal2D = StartTangent2DNormal + EndTangent2DNormal;
		if (WallVerticleNormal2D.IsNearlyZero())
		{
			WallVerticleNormal2D = StartTangent2DNormal.RotateAngleAxis(90.0f, FVector(0.0f, 0.0f, 1.0f));
		}
		else
		{
			WallVerticleNormal2D = WallVerticleNormal2D.GetSafeNormal2D();
			WallVerticleNormal2D = WallVerticleNormal2D.RotateAngleAxis(90.0f, FVector(0.0f, 0.0f, 1.0f));
		}
		
		FTransform ComponentToWorldTransform = SplineMeshComp->GetComponentTransform();
		FBoxSphereBounds CalculatedBounds = SplineMeshComp->CalcBounds(ComponentToWorldTransform);
		FVector SoftWallCenterWithActorHeight = CalculatedBounds.Origin; SoftWallCenterWithActorHeight.Z = InHitRes.Location.Z;
		float DetectLength = CalculatedBounds.BoxExtent.Size2D();

		if (InnerCalculateLeavingAreaTargetLocInSoftAirWall(InHitRes, WallVerticleNormal2D, SoftWallCenterWithActorHeight, DetectLength))
		{
			// 成功
			return;
		}
		else
		{
			// 反向再找一次
			WallVerticleNormal2D = WallVerticleNormal2D.RotateAngleAxis(180.0f, FVector(0.0f, 0.0f, 1.0f));
			if (InnerCalculateLeavingAreaTargetLocInSoftAirWall(InHitRes, WallVerticleNormal2D, SoftWallCenterWithActorHeight, DetectLength))
			{
				// 成功
				return;
			}
			else
			{
				// 还是找不到，有问题，先不处理下一帧再找找看
				UE_LOG(LogTemp, Warning, TEXT("[NewAirWall]Failed to CalculateLeavingAreaTargetLocInSoftAirWall! Location:%s"), *InHitRes.Location.ToString());
			}
		}
	}
	else
	{
		SetOnGroundLeavingAreaTargetLoc(OwnerActor->GetActorLocation() + InHitRes.Normal.GetSafeNormal2D() * 300.0f);
	}
}

bool UInteractiveTriggerComponent::InnerCalculateLeavingAreaTargetLocInSoftAirWall(const FHitResult& InHitRes, const FVector& InWallVerticleNormal2D, const FVector& InSoftWallCenterWithActorHeight, const float& InDetectLength)
{
	TArray<FHitResult> HitReses;
	TArray<AActor*> ActorsToIgnore;
	FHitResult SoftAirWallHitRes, ForceLeaveAreaAirWallHitRes;
	bool HasValidSoftAirWallHitRes = false;
	bool HasValidForceLeaveAreaAirWallHitRes = false;

	FVector ValidLocationInSoftAirWall = InSoftWallCenterWithActorHeight - InHitRes.ImpactPoint; ValidLocationInSoftAirWall.Z = 0.0f;
	if (ValidLocationInSoftAirWall.IsNearlyZero())
	{
		ValidLocationInSoftAirWall = InHitRes.ImpactPoint;
	}
	else
	{
		float Length = FMath::Min(ValidLocationInSoftAirWall.Size2D(), 10.0f);
		ValidLocationInSoftAirWall = InHitRes.ImpactPoint + Length * ValidLocationInSoftAirWall.GetSafeNormal2D();
	}

	UKismetSystemLibrary::LineTraceMultiForObjects(GetWorld(), InSoftWallCenterWithActorHeight + InDetectLength * InWallVerticleNormal2D, ValidLocationInSoftAirWall,
		DetectObjectTypes, false, ActorsToIgnore, EDrawDebugTrace::None, HitReses, true);
	for (const FHitResult& SingleHit : HitReses)
	{
		if (UPrimitiveComponent* HitComp = SingleHit.Component.Get())
		{
			if (HitComp == InHitRes.Component.Get())
			{
				SoftAirWallHitRes = SingleHit;
				HasValidSoftAirWallHitRes = true;
			}
			else if (HitComp->ComponentHasTag(ForceLeaveAreaTag))
			{
				ForceLeaveAreaAirWallHitRes = SingleHit;
				HasValidForceLeaveAreaAirWallHitRes = true;
			}
		}
	}

	if (HasValidSoftAirWallHitRes)
	{
		if (HasValidForceLeaveAreaAirWallHitRes)
		{
			UKismetSystemLibrary::LineTraceMultiForObjects(GetWorld(), ValidLocationInSoftAirWall, SoftAirWallHitRes.ImpactPoint + InWallVerticleNormal2D,
				DetectObjectTypes, false, ActorsToIgnore, EDrawDebugTrace::None, HitReses, true);
			for (const FHitResult& SingleHit : HitReses)
			{
				if (UPrimitiveComponent* HitComp = SingleHit.Component.Get())
				{
					if (HitComp->ComponentHasTag(ForceLeaveAreaTag))
					{
						return false;
					}
				}
			}
		}
		// 1.没有找到ForceLeaveArea，只有SoftAirWall，就是可信结果
		// 2.碰到了对面的ForceLeaveArea，SoftAirWall延长1cm出去找不到紧贴的ForceLeaveArea，也是可信结果
		return SetOnGroundLeavingAreaTargetLoc(SoftAirWallHitRes.ImpactPoint + SoftAirWallHitRes.Normal * 300.0f);
	}

	return false;
}

bool UInteractiveTriggerComponent::SetOnGroundLeavingAreaTargetLoc(const FVector& InLeavingAreaTargetLoc)
{
	if (ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(OwnerActor.Get()))
	{
		LeavingAreaTargetLoc = InLeavingAreaTargetLoc;

//		if (UNavigationSystemV1* NavSys = FNavigationSystem::GetCurrent<UNavigationSystemV1>(GetWorld()))
//		{
//			FNavLocation OutNewAgentNavLocation;
//			if (NavSys->ProjectPointToNavigation(InLeavingAreaTargetLoc + FVector(0.0f, 0.0f, 500.0f), OutNewAgentNavLocation, FVector(500.0f, 500.0f, 2000.0f))) {
//				LeavingAreaTargetLoc = OutNewAgentNavLocation.Location;
//#if UE_BUILD_DEVELOPMENT
//				if (bNeedShowNewAirWallDebugInfo) { 
//					UKismetSystemLibrary::DrawDebugSphere(this, LeavingAreaTargetLoc, 30.0f, 12, FLinearColor::White, 5.0f, 3.0f); 
//					UKismetSystemLibrary::DrawDebugSphere(this, InLeavingAreaTargetLoc + FVector(0.0f, 0.0f, 500.0f), 30.0f, 12, FLinearColor::Gray, 5.0f, 3.0f);
//				}
//#endif
//			}
//			else{
//				UE_LOG(LogTemp, Warning, TEXT("[NewAirWall]No Nearby NavMesh Found at %s"), *InLeavingAreaTargetLoc.ToString());
//				return false;
//			}
//		}
//		else {
//			UE_LOG(LogTemp, Warning, TEXT("[NewAirWall]No NavigationSystem!"));
//			return false;
//		}

		if (FindNearestNavLoc(InLeavingAreaTargetLoc + FVector(0.0f, 0.0f, 500.0f), FVector(500.0f, 500.0f, 2000.0f), LeavingAreaTargetLoc))
		{
#if UE_BUILD_DEVELOPMENT
			if (bNeedShowNewAirWallDebugInfo) {
				UKismetSystemLibrary::DrawDebugSphere(this, LeavingAreaTargetLoc, 30.0f, 12, FLinearColor::White, 5.0f, 3.0f);
				UKismetSystemLibrary::DrawDebugSphere(this, InLeavingAreaTargetLoc + FVector(0.0f, 0.0f, 500.0f), 30.0f, 12, FLinearColor::Gray, 5.0f, 3.0f);
			}
#endif
		}
		else {
			UE_LOG(LogTemp, Warning, TEXT("[NewAirWall]No Nearby NavMesh Found at %s"), *InLeavingAreaTargetLoc.ToString());
			return false;
		}

		if (!BaseCharacter->GetAndCheckStickGroundLocationFromSpecificLocationCheckDistance(LeavingAreaTargetLoc, LeavingAreaTargetLoc, 1000.0f)) {
			UE_LOG(LogTemp, Warning, TEXT("[NewAirWall]StickGround Failed at %s"), *LeavingAreaTargetLoc.ToString());
			return false;
		}
	}
#if UE_BUILD_DEVELOPMENT
	if (bNeedShowNewAirWallDebugInfo) { UKismetSystemLibrary::DrawDebugSphere(this, LeavingAreaTargetLoc, 30.0f, 12, FLinearColor::Red, 5.0f, 3.0f); }
#endif
	bHasValidLeavingAreaTargetLoc = true;
	return true;
}

void UInteractiveTriggerComponent::SetAllowNewAirWallLogic(bool InAllow)
{
	bAllowNewAirWallLogic = InAllow; 
	if (!bAllowNewAirWallLogic)
	{
		DeActivateScreenNiagara();
	}
	UpdateComponentTickEnabled();
}

bool UInteractiveTriggerComponent::FindNearestNavLoc(const FVector& InLoc, const FVector& InExtent, FVector& OutLoc) const
{
	if (UNavigationSystemV1* NavSys = FNavigationSystem::GetCurrent<UNavigationSystemV1>(GetWorld()))
	{
		if (ANavigationData* NavigationData = NavSys->GetDefaultNavDataInstance())
		{
			if (const ARecastNavMesh* NavMesh = Cast<ARecastNavMesh>(NavigationData))
			{
				NavNodeRef NavNode = NavMesh->FindNearestPoly(InLoc, InExtent);
				if (NavNode != INVALID_NAVNODEREF)
				{
					if (NavMesh->GetClosestPointOnPoly(NavNode, InLoc, OutLoc))
					{
						return true;
					}
				}
			}
		}
	}

	return false;
}
#pragma endregion NewAirWall