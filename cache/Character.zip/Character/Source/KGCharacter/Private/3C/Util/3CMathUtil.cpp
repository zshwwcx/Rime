#include "3C/Util/3CMathUtil.h"

float U3CMathUtil::CalculateDirection(const FVector& Velocity, const FRotator& BaseRotation)
{
	if (!Velocity.IsNearlyZero())
	{
		FMatrix RotMatrix = FRotationMatrix(BaseRotation);
		FVector ForwardVector = RotMatrix.GetScaledAxis(EAxis::X);
		FVector RightVector = RotMatrix.GetScaledAxis(EAxis::Y);
		FVector NormalizedVel = Velocity.GetSafeNormal2D();

		// get a cos(alpha) of forward vector vs velocity
		float ForwardCosAngle = FVector::DotProduct(ForwardVector, NormalizedVel);
		// now get the alpha and convert to degree
		float ForwardDeltaDegree = FMath::RadiansToDegrees(FMath::Acos(ForwardCosAngle));

		// depending on where right vector is, flip it
		float RightCosAngle = FVector::DotProduct(RightVector, NormalizedVel);
		if (RightCosAngle < 0)
		{
			ForwardDeltaDegree *= -1;
		}

		return ForwardDeltaDegree;
	}

	return 0.f;
}

float U3CMathUtil::GetAngleBetweenRotator(const FRotator& RA, const FRotator& RB)
{
	const FQuat DeltaRotation = FQuat::FindBetweenVectors(RA.Vector(), RB.Vector());

	if (!DeltaRotation.IsIdentity())
	{
		return FMath::RadiansToDegrees(DeltaRotation.GetAngle());
	}

	return 0;
}