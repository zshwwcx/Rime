#include "3C/Util/AbilityCollisionUtil.h"

#include "KGCharacterModule.h"
#include "Landscape.h"
#include "Engine/HitResult.h"
#include "Components/SphereComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/LineBatchComponent.h"
#include "Components/BoxComponent.h"
#include "Misc/LowLevelFunctions.h"
#include "Engine/World.h"
#include "Engine/OverlapResult.h"
#include "Kismet/KismetSystemLibrary.h"
#include "3C/Character/BaseCharacterInternal.h"
#include "Kismet/KismetMathLibrary.h"
#include "3C/Util/KGActorUtil.h"

#if WITH_EDITOR
#include "DrawDebugHelpers.h"
#endif

#pragma region DrawDebug
#if WITH_EDITOR
void UAbilityCollisionUtil::DrawDebugBoxInEditor(UObject* WorldContextObject, const FVector Center, FVector Extent, FLinearColor LineColor, const FRotator Rotation, float Duration, float Thickness)
{
	UWorld* QueryWorld = WorldContextObject->GetWorld();
	if (!QueryWorld)
		return;

#if ENABLE_DRAW_DEBUG
	if (Rotation == FRotator::ZeroRotator)
		DrawDebugBox(QueryWorld, Center, Extent, LineColor.ToFColor(true), false, Duration, SDPG_World, Thickness);
	else
		DrawDebugBox(QueryWorld, Center, Extent, Rotation.Quaternion(), LineColor.ToFColor(true), false, Duration, SDPG_World, Thickness);
#endif
}

void UAbilityCollisionUtil::DrawDebugSphereInEditor(UObject* WorldContextObject, const FVector Center, float Radius, int32 Segments, FLinearColor LineColor, float Duration, float Thickness)
{
	UWorld* QueryWorld = WorldContextObject->GetWorld();
	if (!QueryWorld)
		return;

#if ENABLE_DRAW_DEBUG
	DrawDebugSphere(QueryWorld, Center, Radius, Segments, LineColor.ToFColor(true), false, Duration, SDPG_World, Thickness);
#endif
}

void UAbilityCollisionUtil::DrawDebugSweepSphereInEditor(const UWorld* InWorld, FVector const& Start, FVector const& End, float Radius, FColor const& Color, bool bPersistentLines, float LifeTime, uint8 DepthPriority)
{
#if ENABLE_DRAW_DEBUG
	FVector const TraceVec = End - Start;
	float const Dist = TraceVec.Size();

	FVector const Center = Start + TraceVec * 0.5f;
	float const HalfHeight = (Dist * 0.5f) + Radius;

	FQuat const CapsuleRot = FRotationMatrix::MakeFromZ(TraceVec).ToQuat();
	DrawDebugCapsule(InWorld, Center, HalfHeight, Radius, CapsuleRot, Color, bPersistentLines, LifeTime, DepthPriority);
#endif
}

void UAbilityCollisionUtil::DrawDebugSweepCapsuleInEditor(const UWorld* InWorld, FVector const& Start, FVector const& End, float HalfHeight, float Radius, FColor const& Color, bool bPersistentLines, float LifeTime, uint8 DepthPriority)
{
#if ENABLE_DRAW_DEBUG
	DrawDebugCapsule(InWorld, Start, HalfHeight, Radius, FQuat::Identity, Color, bPersistentLines, LifeTime);
	DrawDebugCapsule(InWorld, End, HalfHeight, Radius, FQuat::Identity, Color, bPersistentLines, LifeTime);
	DrawDebugLine(InWorld, Start, End, Color, bPersistentLines, LifeTime);
#endif
}
#endif
#pragma endregion DrawDebug

bool UAbilityCollisionUtil::SphereCheck(AActor* InActor, float SphereSize, const FVector& StartPosition, const TArray<int32>& ExtraTypes, TArray<AActor*>& OutActors, bool bIgnoreSelf)
{
	OutActors.Empty();
	
	if (SphereSize <= UE_KINDA_SMALL_NUMBER)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UAbilityCollisionUtil::SphereCheck, invalid params, %f"), SphereSize);
		return false;
	}
	
	if (!IsValid(InActor))
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UAbilityCollisionUtil::SphereCheck, invalid Actor"));
		return false;
	}
	
	UWorld* QueryWorld = InActor->GetWorld();
	if (!QueryWorld)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UAbilityCollisionUtil::SphereCheck, invalid World"));
		return false;
	}
	
	TArray<TEnumAsByte<EObjectTypeQuery>> ObjectTypes;
	ObjectTypes.Append(ExtraTypes);
	
	FCollisionObjectQueryParams ObjectQueryParams(ObjectTypes);
	if (!ObjectQueryParams.IsValid())
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UAbilityCollisionUtil::SphereCheck, invalid ObjectQueryParams"));
		return false;
	}
	
	FCollisionQueryParams CollisionQueryParams;
	if (bIgnoreSelf)
	{
		CollisionQueryParams.AddIgnoredActor(InActor);	
	}
	
	FCollisionShape Sphere = FCollisionShape::MakeSphere(SphereSize);
	TArray<FOverlapResult> OverlapResults;
	QueryWorld->OverlapMultiByObjectType(OverlapResults, StartPosition, FQuat::Identity, ObjectQueryParams, Sphere, CollisionQueryParams);

	for (int32 i = 0; i < OverlapResults.Num(); ++i)
	{
		AActor* HitActor = OverlapResults[i].GetActor();
		if (!HitActor)
		{
			continue;
		}
			
		OutActors.Add(HitActor);
	}
	return true;
}

bool UAbilityCollisionUtil::BoxCheck(AActor* InActor, const FVector& BoxHalfExtent, const FVector& StartPosition, float Yaw,
    const TArray<int32>& ExtraTypes, TArray<AActor*>& OutActors, bool bIgnoreSelf)
{
	OutActors.Empty();
	
	if (BoxHalfExtent.X <= UE_KINDA_SMALL_NUMBER || BoxHalfExtent.Y <= UE_KINDA_SMALL_NUMBER || BoxHalfExtent.Z <= UE_KINDA_SMALL_NUMBER)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UAbilityCollisionUtil::BoxCheck, invalid params, %s"), *BoxHalfExtent.ToString());
		return false;
	}
	
	if (!IsValid(InActor))
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UAbilityCollisionUtil::BoxCheck, invalid Actor"));
		return false;
	}
	
	UWorld* QueryWorld = InActor->GetWorld();
	if (!QueryWorld)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UAbilityCollisionUtil::BoxCheck, invalid World"));
		return false;
	}
	
	TArray<TEnumAsByte<EObjectTypeQuery>> ObjectTypes;
	ObjectTypes.Append(ExtraTypes);
	
	FCollisionObjectQueryParams ObjectQueryParams(ObjectTypes);
	if (!ObjectQueryParams.IsValid())
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UAbilityCollisionUtil::BoxCheck, invalid ObjectQueryParams"));
		return false;
	}
	
	FCollisionQueryParams CollisionQueryParams;
	if (bIgnoreSelf)
	{
		CollisionQueryParams.AddIgnoredActor(InActor);	
	}
	
	const FCollisionShape& Box = FCollisionShape::MakeBox(BoxHalfExtent);
	TArray<FOverlapResult> OverlapResults;
	QueryWorld->OverlapMultiByObjectType(OverlapResults, StartPosition, FRotator(0.0f, Yaw, 0.0f).Quaternion(), ObjectQueryParams, Box, CollisionQueryParams);

	for (int32 i = 0; i < OverlapResults.Num(); ++i)
	{
		AActor* HitActor = OverlapResults[i].GetActor();
		if (!HitActor)
		{
			continue;
		}
			
		OutActors.Add(HitActor);
	}

	return true;
}

bool UAbilityCollisionUtil::CapsuleCheck(AActor* InActor, float CapsuleHalfHeight, float CapsuleRadius, const FVector& StartPosition, 
	const TArray<int32>& ExtraTypes, TArray<AActor*>& OutActors, bool bIgnoreSelf)
{
	OutActors.Empty();
	
	if (CapsuleHalfHeight <= UE_KINDA_SMALL_NUMBER || CapsuleRadius <= UE_KINDA_SMALL_NUMBER)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UAbilityCollisionUtil::CapsuleCheck, invalid params, %f, %f"), CapsuleHalfHeight, CapsuleRadius);
		return false;
	}
	
	if (!IsValid(InActor))
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UAbilityCollisionUtil::CapsuleCheck, invalid Actor"));
		return false;
	}
	
	UWorld* QueryWorld = InActor->GetWorld();
	if (!QueryWorld)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UAbilityCollisionUtil::CapsuleCheck, invalid QueryWorld"));
		return false;
	}
	
	TArray<TEnumAsByte<EObjectTypeQuery>> ObjectTypes;
	ObjectTypes.Append(ExtraTypes);
	
	FCollisionObjectQueryParams ObjectQueryParams(ObjectTypes);
	if (!ObjectQueryParams.IsValid())
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UAbilityCollisionUtil::CapsuleCheck, invalid ObjectQueryParams"));
		return false;
	}
	
	FCollisionQueryParams CollisionQueryParams;
	if (bIgnoreSelf)
	{
		CollisionQueryParams.AddIgnoredActor(InActor);	
	}

	const FCollisionShape& Capsule = FCollisionShape::MakeCapsule(CapsuleRadius, CapsuleHalfHeight);
	TArray<FOverlapResult> OverlapResults;
	QueryWorld->OverlapMultiByObjectType(OverlapResults, StartPosition, FQuat::Identity, ObjectQueryParams, Capsule, CollisionQueryParams);

	const float StartLocationZ = StartPosition.Z;
	
	for (int32 i = 0; i < OverlapResults.Num(); ++i)
	{
		AActor* HitActor = OverlapResults[i].GetActor();
		if (!HitActor)
		{
			continue;
		}
			
		// 策划需求的是圆柱体, 这里用胶囊体近似, 筛选完成后还需要剔除上下两个半球中的数据
		float HitActorHalfHeight;
		const float ActorLocationZ = HitActor->GetActorLocation().Z;
		UCapsuleComponent* CapsuleComponent;
		if (ACharacter* Character = Cast<ACharacter>(HitActor))
		{
			CapsuleComponent = Character->GetCapsuleComponent();
		}
		else
		{
			CapsuleComponent = HitActor->FindComponentByClass<UCapsuleComponent>();
		}
		
		if (CapsuleComponent)
		{
			HitActorHalfHeight = CapsuleComponent->GetScaledCapsuleHalfHeight();
		}
		else
		{
			HitActorHalfHeight = (HitActor->GetActorBounds().GetExtent().Z);
		}
		
		const bool bIntersect = 
			(ActorLocationZ + HitActorHalfHeight) >= (StartLocationZ - CapsuleHalfHeight) &&
			(ActorLocationZ - HitActorHalfHeight) <= (StartLocationZ + CapsuleHalfHeight);
		
		if (bIntersect)
		{
			OutActors.Add(HitActor);	
		}
	}

	return true;
}

bool UAbilityCollisionUtil::FanCheck(AActor* InActor, float InnerRadius, float OuterRadius, float Height, float Angle,
	const FVector& StartPosition, float Yaw, const TArray<int32>& ExtraTypes, TArray<AActor*>& OutActors, bool bIgnoreSelf)
{
	if (Angle <= UE_KINDA_SMALL_NUMBER || Height <= UE_KINDA_SMALL_NUMBER || OuterRadius <= UE_KINDA_SMALL_NUMBER || OuterRadius <= InnerRadius)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UAbilityCollisionUtil::FanCheck, invalid params, %f, %f, %f, %f"), InnerRadius, OuterRadius, Height, Angle);
		return false;
	}
	
	// 先用outer radius的capsule粗筛一次
	if (!CapsuleCheck(InActor, Height * 0.5f, OuterRadius, StartPosition, ExtraTypes, OutActors, bIgnoreSelf))
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UAbilityCollisionUtil::FanCheck, CapsuleCheck failed"));
		return false;
	}

	const float HalfAngleRadians = FMath::DegreesToRadians(Angle * 0.5f);
	float CosHalfAngle = FMath::Cos(HalfAngleRadians);
	FVector ForwardVec = FRotator(0.0f, Yaw, 0.0f).Vector();
	ForwardVec.Z = 0.0f;
	ForwardVec.Normalize();
	
	for (int32 i = OutActors.Num() - 1; i >= 0; --i)
	{
		AActor* HitActor = OutActors[i];
		if (!HitActor)
		{
			OutActors.RemoveAtSwap(i, EAllowShrinking::No);
			continue;
		}
		
		float HitActorRadius;
		UCapsuleComponent* CapsuleComponent;
		if (ACharacter* Character = Cast<ACharacter>(HitActor))
		{
			CapsuleComponent = Character->GetCapsuleComponent();
		}
		else
		{
			CapsuleComponent = HitActor->FindComponentByClass<UCapsuleComponent>();
		}
		
		if (CapsuleComponent)
		{
			HitActorRadius = CapsuleComponent->GetScaledCapsuleRadius();
		}
		else
		{
			HitActorRadius = HitActor->GetActorBounds().GetExtent().Size2D();
		}
		
		FVector ToActor = HitActor->GetActorLocation() - StartPosition;
		ToActor.Z = 0.0f;
		float Dist2D = ToActor.Size2D();
		if (Dist2D + HitActorRadius < InnerRadius)
		{
			OutActors.RemoveAtSwap(i, EAllowShrinking::No);
			continue;
		}
		
		ToActor.Normalize();
		float Dot = FVector::DotProduct(ForwardVec, ToActor);
		if (Dot < CosHalfAngle)
		{
			// 有可能此时Actor比较靠近扇形边缘，加上Actor的半径后可能就进入扇形范围了, 此时需要进一步计算
			// 将角度计算换位圆弧周长的计算, 可以近似得到较为准确的结果, 且额外开销比较低
			const float AngleToActor = FMath::Acos(Dot);
			const float ArcLength = AngleToActor * Dist2D;
			const float HalfFanArcLength = HalfAngleRadians * Dist2D;
			if (ArcLength - HitActorRadius > HalfFanArcLength)
			{
				OutActors.RemoveAtSwap(i, EAllowShrinking::No);	
			}
		}
	}
	
	return true;
}

bool UAbilityCollisionUtil::FindGroundLocation(
	const UObject* InWorldContext, const FVector& OriginLocation, const TArray<TEnumAsByte<EObjectTypeQuery>>& InObjectTypes,
	FVector& OutLocation, const FVector& InOffset, const FVector& GravityDirection, AActor* InActor)
{
	OutLocation = OriginLocation;

	if (!InWorldContext)
	{
		return false;
	}
	
	if (InActor)
	{
		FVector PlaneNormal = InActor->GetActorUpVector();
		FVector PlanePoint = UKGActorUtil::V2GetActorBottomLocation(InActor);
		FVector TestPlanePoint = UKismetMathLibrary::ProjectPointOnToPlane(OriginLocation, PlanePoint, PlaneNormal);
		OutLocation = TestPlanePoint;
	}

	// 接下来根据该寻路网格点向下做射线检查，找到模型表面
	TArray<FHitResult> HitResults;
	bool bSuccess = UKismetSystemLibrary::LineTraceMultiForObjects(
		InWorldContext, OutLocation + GravityDirection * InOffset.X, OutLocation + GravityDirection * InOffset.Y, InObjectTypes, true, {},
		EDrawDebugTrace::None, HitResults, true, FLinearColor::Red, FLinearColor::Green, 0.0f);
	
	if (bSuccess)
	{
		int32 FindResultIndex = -1;

		// 从近到远排序
		HitResults.Sort(
			[](const FHitResult& A, const FHitResult& B)
			{
				return A.Distance < B.Distance;
			}
		);

		ECollisionChannel CheckChannel = ECC_WorldStatic;
		if (InActor)
		{
			CheckChannel = InActor->GetRootComponent()->GetCollisionObjectType();
		}

		// 进行筛选
		for (int32 i = 0; i < HitResults.Num(); ++i)
		{
			FHitResult& HitResult = HitResults[i];
			AActor* HitActor = HitResult.GetActor();
			UPrimitiveComponent* HitComponent = HitResult.GetComponent();

			if (!HitComponent)
			{
				continue;
			}

			// 如果查到LandScape，则不再继续查询
			if (HitActor && HitActor->IsA<ALandscape>())
			{
				FindResultIndex = i;
				break;
			}

			// 检查是否与请求者阻挡
			if (HitComponent->GetCollisionResponseToChannel(CheckChannel) != ECollisionResponse::ECR_Block)
			{
				continue;
			}

			// 判断法线方向
			float CurDot = FVector::DotProduct(HitResult.ImpactNormal.GetSafeNormal(), GravityDirection.GetSafeNormal());
			if (CurDot > -0.86f)
			{
				continue;
			}

			FindResultIndex = i;
			break;
		}

		if (FindResultIndex >= 0)
		{
			OutLocation = HitResults[FindResultIndex].ImpactPoint;
		}
	}

	OutLocation = OutLocation - GravityDirection * InOffset.Z;

	return true;
}
