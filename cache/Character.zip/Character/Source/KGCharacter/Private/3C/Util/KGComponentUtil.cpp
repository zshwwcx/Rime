#include "3C/Util/KGComponentUtil.h"

#include "NiagaraComponent.h"
#include "Components/ActorComponent.h"
#include "Components/DecalComponent.h"
#include "Components/SkinnedMeshComponent.h"
#include "3C/Effect/KGEffectManager.h"


void UKGComponentUtil::GetComponentTags(UActorComponent* ActorComponent, TArray<FName>& OutTags)
{
	if (!IsValid(ActorComponent))
	{
		UE_LOG(LogTemp, Error, TEXT("UKGActorUtil::GetComponentTags, invalid component"));
		return;
	}

	OutTags = ActorComponent->ComponentTags;
}

void UKGComponentUtil::SetComponentTags(UActorComponent* ActorComponent, const TArray<FName>& InTags)
{
	if (!IsValid(ActorComponent))
	{
		UE_LOG(LogTemp, Error, TEXT("UKGActorUtil::SetComponentTags, invalid component"));
		return;
	}

	ActorComponent->ComponentTags = InTags;
}

void UKGComponentUtil::ClearComponentTags(UActorComponent* ActorComponent)
{
	if (!IsValid(ActorComponent))
	{
		UE_LOG(LogTemp, Error, TEXT("UKGActorUtil::ClearComponentTags, invalid component"));
		return;
	}

	ActorComponent->ComponentTags.Empty();
}


EVisibilityBasedAnimTickOption UKGComponentUtil::GetMeshVisibilityBasedAnimTickOption(USkinnedMeshComponent* Comp)
{
	if (!IsValid(Comp))
	{
		UE_LOG(LogTemp, Error, TEXT("UKGActorUtil::GetVisibilityBasedAnimTickOption, invalid component,Return Default Value AlwaysTickPoseAndRefreshBones"));
		return EVisibilityBasedAnimTickOption::AlwaysTickPoseAndRefreshBones;
	}

	return Comp->VisibilityBasedAnimTickOption;
}


bool UKGComponentUtil::SetMeshVisibilityBasedAnimTickOption(USkinnedMeshComponent* Comp,const EVisibilityBasedAnimTickOption& InVisibilityBasedAnimTickOption)
{
	if (!IsValid(Comp))
	{
		UE_LOG(LogTemp, Error, TEXT("UKGActorUtil::GetVisibilityBasedAnimTickOption, invalid component"));
		return false;
	}
	Comp->VisibilityBasedAnimTickOption = InVisibilityBasedAnimTickOption;
	return true;
}

void UKGComponentUtil::SetDecalSize(UDecalComponent* InDecalComponent, const FVector& InDecalSize)
{
	if (!IsValid(InDecalComponent))
	{
		return;
	}

	InDecalComponent->DecalSize = InDecalSize;
}

void UKGComponentUtil::SetMeshUseFixedSkelBounds(class USkinnedMeshComponent* MeshComponent, bool bUse)
{
	if (!IsValid(MeshComponent))
	{
		return;
	}

	MeshComponent->bComponentUseFixedSkelBounds = bUse;
}

void UKGComponentUtil::SetComponentUseAttachParentBound(class USceneComponent* SceneComponent, bool bUse)
{
	if (!IsValid(SceneComponent))
	{
		return;
	}

	SceneComponent->bUseAttachParentBound = bUse;	
}

void UKGComponentUtil::AddSplinePoints(
	USplineComponent* SplineComp, const TArray<FVector>& Points, const TArray<FRotator>& Rotations, float Tension, bool bStationaryEndpoints, ESplinePointType::Type PointType)
{
	if (!IsValid(SplineComp))
	{
		UE_LOG(LogTemp, Error, TEXT("UKGComponentUtil::AddSplinePoints, invalid SplineComponent"));
		return;
	}
	
	const int32 NumPoints = Points.Num();
	const int32 LastPoint = NumPoints - 1;
	const bool bCalcCurveCustomTangent = PointType == ESplinePointType::Type::CurveCustomTangent;
	
	for (int32 PointIndex = 0; PointIndex < NumPoints; PointIndex++)
	{
		SplineComp->AddSplinePoint(Points[PointIndex], ESplineCoordinateSpace::Type::World, false);
		SplineComp->SetSplinePointType(PointIndex, PointType, false);

		// NOTE: 这段计算切线的逻辑不知道为什么会存在，本质上也是抄的 ESplinePointType::CurveClamped，但是抄漏了环线的情况
		// NOTE: 因为游戏运行时曲线移动用的是CurveAuto，编辑器下也改成CurveAuto，如果真的有CustomTangent的逻辑再启动下面的逻辑
		if (bCalcCurveCustomTangent)
		{
			const int32 PrevIndex = (PointIndex == 0) ? 0 : (PointIndex - 1);
			const int32 NextIndex = (PointIndex == LastPoint) ? LastPoint : (PointIndex + 1);

			auto& ThisPoint = SplineComp->SplineCurves.Position.Points[PointIndex];
			const auto& PrevPoint = SplineComp->SplineCurves.Position.Points[PrevIndex];
			const auto& NextPoint = SplineComp->GetComponentTransform().InverseTransformPosition(Points[NextIndex]);

			if (bStationaryEndpoints && (PointIndex == 0 || PointIndex == LastPoint))
			{
				// Start and end points get zero tangents if bStationaryEndpoints is true
				ThisPoint.ArriveTangent = FVector::ZeroVector;
				ThisPoint.LeaveTangent = FVector::ZeroVector;
			}
			else
			{
				FVector Tangent;
				ComputeCurveTangent(
					PrevPoint.InVal,
					PrevPoint.OutVal,
					ThisPoint.InVal,
					ThisPoint.OutVal,
					NextIndex,
					NextPoint,
					Tension,
					false,
					Tangent);
		
				FVector NewTangent = SplineComp->GetComponentTransform().GetRotation().RotateVector(Tangent);
				NewTangent = Rotations[PointIndex].RotateVector(NewTangent);
				NewTangent = SplineComp->GetComponentTransform().GetRotation().Inverse().RotateVector(NewTangent);
			
				ThisPoint.ArriveTangent = NewTangent;
				ThisPoint.LeaveTangent = NewTangent;
			}
		}
	}
	SplineComp->UpdateSpline();
}

void UKGComponentUtil::SetComponentHiddenInGame(USceneComponent* SceneComponent, bool bNewHiddenGame, bool bPropagateToChildren)
{
	if (!IsValid(SceneComponent))
	{
		UE_LOG(LogTemp, Error, TEXT("UKGComponentUtil::SetComponentHiddenInGame, invalid SceneComponent"));
		return;
	}
	
	const bool bHiddenInGame = SceneComponent->bHiddenInGame;
	if (bNewHiddenGame != bHiddenInGame)
	{
		SceneComponent->SetHiddenInGame(bNewHiddenGame, false);
	}

	if (!bPropagateToChildren)
	{
		return;
	}
	
	UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(SceneComponent);
	if (!EffectManager)
	{
		UE_LOG(LogTemp, Error, TEXT("UKGComponentUtil::SetComponentHiddenInGame, invalid effect manager"));
		return;
	}
	
	const TArray<USceneComponent*>& AttachedChildren = SceneComponent->GetAttachChildren();
	if (AttachedChildren.Num() > 0)
	{
		// fully traverse down the attachment tree
		// we do it entirely inline here instead of recursing in case a primitivecomponent is a child of a non-primitivecomponent
		TInlineComponentArray<USceneComponent*, NumInlinedActorComponents> ComponentStack;

		// prime the pump
		ComponentStack.Append(AttachedChildren);

		while (ComponentStack.Num() > 0)
		{
			USceneComponent* const CurrentComp = ComponentStack.Pop(EAllowShrinking::No);
			if (!CurrentComp)
			{
				continue;
			}
			
			ComponentStack.Append(CurrentComp->GetAttachChildren());
			
			UNiagaraComponent* NiagaraComponent = Cast<UNiagaraComponent>(CurrentComp);
			int32 NiagaraEffectID = 0;
			if (NiagaraComponent && EffectManager->GetNiagaraEffectIdByNiagaraComponent(NiagaraComponent, NiagaraEffectID))
			{
				EffectManager->UpdateNiagaraHiddenState(
					NiagaraEffectID, bNewHiddenGame, static_cast<uint8>(EKGNiagaraHiddenReason::ATTACH_COMPONENT_HIDDEN),
					false, 0.0f);;
			}
			else
			{
				CurrentComp->SetHiddenInGame(bNewHiddenGame, false);
			}
			
			// Render state must be dirtied if any parent component's visibility has changed. Since we can't easily track whether 
			// any parent in the hierarchy was dirtied, we have to mark dirty always.
			CurrentComp->MarkRenderStateDirty();
		}
	}
}

void UKGComponentUtil::SetComponentVisibility(USceneComponent* SceneComponent, bool bNewVisibility, bool bPropagateToChildren)
{
	if (!IsValid(SceneComponent))
	{
		UE_LOG(LogTemp, Error, TEXT("UKGComponentUtil::SetComponentHiddenInGame, invalid SceneComponent"));
		return;
	}
	
	const bool bVisible = SceneComponent->GetVisibleFlag();
	if (bNewVisibility != bVisible)
	{
		SceneComponent->SetVisibility(bNewVisibility, false);
	}

	if (!bPropagateToChildren)
	{
		return;
	}
	
	UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(SceneComponent);
	if (!EffectManager)
	{
		UE_LOG(LogTemp, Error, TEXT("UKGComponentUtil::SetComponentVisibility, invalid effect manager"));
		return;
	}
	
	const TArray<USceneComponent*>& AttachedChildren = SceneComponent->GetAttachChildren();
	if (AttachedChildren.Num() > 0)
	{
		// fully traverse down the attachment tree
		// we do it entirely inline here instead of recursing in case a primitivecomponent is a child of a non-primitivecomponent
		TInlineComponentArray<USceneComponent*, NumInlinedActorComponents> ComponentStack;

		// prime the pump
		ComponentStack.Append(AttachedChildren);

		while (ComponentStack.Num() > 0)
		{
			USceneComponent* const CurrentComp = ComponentStack.Pop(EAllowShrinking::No);
			if (!CurrentComp)
			{
				continue;
			}
			
			ComponentStack.Append(CurrentComp->GetAttachChildren());
			
			UNiagaraComponent* NiagaraComponent = Cast<UNiagaraComponent>(CurrentComp);
			int32 NiagaraEffectID = 0;
			if (NiagaraComponent && EffectManager->GetNiagaraEffectIdByNiagaraComponent(NiagaraComponent, NiagaraEffectID))
			{
				EffectManager->UpdateNiagaraHiddenState(
					NiagaraEffectID, !bNewVisibility, static_cast<uint8>(EKGNiagaraHiddenReason::ATTACH_COMPONENT_HIDDEN),
					false, 0.0f);;
			}
			else
			{
				CurrentComp->SetVisibility(bNewVisibility, false);
			}
			
			// Render state must be dirtied if any parent component's visibility has changed. Since we can't easily track whether 
			// any parent in the hierarchy was dirtied, we have to mark dirty always.
			CurrentComp->MarkRenderStateDirty();
		}
	}
}
