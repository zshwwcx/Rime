#include "3C/Controller/PressAnyKeyInputProcessor.h"
#include "Input/Events.h"
#include "Engine/EngineBaseTypes.h"


void FPressAnyKeyInputProcessor::Tick(const float DeltaTime, FSlateApplication& SlateApp, TSharedRef<ICursor> Cursor)
{
}

bool FPressAnyKeyInputProcessor::HandleKeyDownEvent(FSlateApplication& SlateApp, const FKeyEvent& InKeyEvent)
{
	HandleKey(InKeyEvent.GetKey(), IE_Pressed);
	return IInputProcessor::HandleKeyDownEvent(SlateApp, InKeyEvent);
}

bool FPressAnyKeyInputProcessor::HandleKeyUpEvent(FSlateApplication& SlateApp, const FKeyEvent& InKeyEvent)
{
	HandleKey(InKeyEvent.GetKey(), IE_Released);
	return IInputProcessor::HandleKeyUpEvent(SlateApp, InKeyEvent);
}

bool FPressAnyKeyInputProcessor::HandleMouseButtonDownEvent(FSlateApplication& SlateApp, const FPointerEvent& MouseEvent)
{
	HandleKey(MouseEvent.GetEffectingButton(), IE_Pressed);
	return IInputProcessor::HandleMouseButtonDownEvent(SlateApp, MouseEvent);
}

bool FPressAnyKeyInputProcessor::HandleMouseButtonUpEvent(FSlateApplication& SlateApp, const FPointerEvent& MouseEvent)
{
	HandleKey(MouseEvent.GetEffectingButton(), IE_Released);
	if (MouseEvent.GetEffectingButton() == EKeys::LeftMouseButton)
	{
		// 鼠标左键抬起的时候，吞掉事件，防止改键的同时触发UI的点击事件
		return true;
	}
	return IInputProcessor::HandleMouseButtonUpEvent(SlateApp, MouseEvent);
}

bool FPressAnyKeyInputProcessor::HandleMouseButtonDoubleClickEvent(FSlateApplication& SlateApp, const FPointerEvent& MouseEvent)
{
	HandleKey(MouseEvent.GetEffectingButton(), IE_DoubleClick);
	return IInputProcessor::HandleMouseButtonDoubleClickEvent(SlateApp, MouseEvent);
}

bool FPressAnyKeyInputProcessor::HandleMouseWheelOrGestureEvent(FSlateApplication& SlateApp, const FPointerEvent& InWheelEvent, const FPointerEvent* InGestureEvent)
{
	if (InWheelEvent.GetWheelDelta() != 0)
	{
		const FKey Key = InWheelEvent.GetWheelDelta() < 0 ? EKeys::MouseScrollDown : EKeys::MouseScrollUp;
		HandleKey(Key, IE_Axis);
	}
	return IInputProcessor::HandleMouseWheelOrGestureEvent(SlateApp, InWheelEvent, InGestureEvent);
}

void FPressAnyKeyInputProcessor::HandleKey(const FKey& Key, const EInputEvent EventType) const
{
	if (Key == EKeys::LeftCommand || Key == EKeys::RightCommand)
	{
		// Ignore COMMAND key.
	}
	else if (Key == EKeys::Escape || Key.IsTouch() || Key.IsGamepadKey())
	{
		// Cancel this process if it's Escape, Touch, or a gamepad key.
		if (OnKeySelectionCanceled.IsBound())
		{
			OnKeySelectionCanceled.Execute();
		}
	}
	else
	{
		if (OnKeySelected.IsBound())
		{
			OnKeySelected.Execute(Key, EventType);
		}
	}
}
