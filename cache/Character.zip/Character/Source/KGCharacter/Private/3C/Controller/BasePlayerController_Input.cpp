#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "InputMappingContext.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "3C/Controller/BasePlayerController.h"
#include "3C/Controller/PressAnyKeyInputProcessor.h"
#include "Components/InputComponent.h"
#include "Engine/HitResult.h"
#include "Engine/LocalPlayer.h"
#include "Framework/Application/SlateApplication.h"
#include "GameFramework/InputSettings.h"
#include "GameFramework/Pawn.h"
#include "Kismet/KismetInputLibrary.h"
#include "UserSettings/EnhancedInputUserSettings.h"


void ABasePlayerController::InitInputSystem()
{
	Super::InitInputSystem();
	if (UEnhancedInputLocalPlayerSubsystem* Subsystem = ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(this->GetLocalPlayer()))
	{
		RuntimeMappingContext = DuplicateObject<UInputMappingContext>(DefaultMappingContext, GetTransientPackage(), "RuntimeMappingContext");
		
		FModifyContextOptions FModifyContextOptions;
		FModifyContextOptions.bNotifyUserSettings = true;
		Subsystem->AddMappingContext(RuntimeMappingContext, 0, FModifyContextOptions);
	}
	
	OnInitInputSystem();
}

#if WITH_EDITOR
void ABasePlayerController::PostProcessInput(const float DeltaTime, const bool bGamePaused)
{
	Super::PostProcessInput(DeltaTime, bGamePaused);

	if (IsInputKeyDown(FKey("LeftMouseButton")) && IsInputKeyDown(FKey("LeftControl")))
	{
		TArray<TEnumAsByte<EObjectTypeQuery> > ObjectTypes;
		ObjectTypes.Add(EObjectTypeQuery::ObjectTypeQuery3);
		ObjectTypes.Add(EObjectTypeQuery::ObjectTypeQuery8);

		FHitResult HitResult;
		if (GetHitResultUnderCursorForObjects(ObjectTypes,true, HitResult))
		{
			OnLeftMouseSelectActor(HitResult.GetActor());
		}
	}

	if (IsInputKeyDown(FKey("C")) && IsInputKeyDown(FKey("LeftAlt")))
	{
		ExecuteCustomCommand("KillNpc", "");
	}
}
#endif

void ABasePlayerController::EnabledTickMouseMove(const bool bEnabled)
{
	if (bEnabledTickMouseMove == bEnabled)
	{
		return;
	}
	bEnabledTickMouseMove = bEnabled;
	LastMousePosition = FSlateApplication::Get().GetCursorPos();
}

void ABasePlayerController::TickMouseMove(float DeltaTime)
{
	if (!bEnabledTickMouseMove)
	{
		return;
	}
	const FVector2d CurMousePosition = FSlateApplication::Get().GetCursorPos();
	const FVector2d MouseOffset = CurMousePosition - LastMousePosition;
	if (MouseOffset.Length() > 0.01)
	{
		OnMouseMoved(MouseOffset);
	}
	LastMousePosition = CurMousePosition;
}

void ABasePlayerController::InputMoveAxis2D(const float X, const float Y)
{
	const auto OwnedPawn = GetPawn();
	if (!OwnedPawn) {
		return;
	}

	OwnedPawn->AddMovementInput(FVector::ForwardVector, Y);
	OwnedPawn->AddMovementInput(FVector::RightVector, X);
	bHasRawLocoInput = FMath::Abs(X) > SMALL_NUMBER || FMath::Abs(Y) > SMALL_NUMBER;
}

void ABasePlayerController::InputMoveAxis_X(const float X)
{
	const auto OwnedPawn = GetPawn();
	if (!OwnedPawn) {
		return;
	}

	OwnedPawn->AddMovementInput(FVector::ForwardVector, X);
	bHasRawLocoInput = FMath::Abs(X) > SMALL_NUMBER;
}

void ABasePlayerController::InputMoveAxis_Y(const float Y)
{
	const auto OwnedPawn = GetPawn();
	if (!OwnedPawn) {
		return;
	}

	OwnedPawn->AddMovementInput(FVector::RightVector, Y);
	bHasRawLocoInput = FMath::Abs(Y) > SMALL_NUMBER;
}

bool ABasePlayerController::HasMoveAxisInput() const
{
	const auto OwnedPawn = GetPawn();
	if (!OwnedPawn) {
		return false;
	}
	URoleMovementComponent* URoleMCPtr = Cast<URoleMovementComponent>(OwnedPawn->GetMovementComponent());
	if (!URoleMCPtr) {
		return false;
	}
	
	return URoleMCPtr->HasLocoInput();
}

bool ABasePlayerController::K2_IsInputKeyDown(const FString Key) const
{
	return IsInputKeyDown(FKey(*Key));
}

bool ABasePlayerController::IsPressed(const FName& KeyName) const
{
	if (PlayerInput)
	{
		return PlayerInput->IsPressed(KeyName);
	}
	return false;
}

bool ABasePlayerController::Key_IsMouseButton(const FName& KeyName) const
{
	return UKismetInputLibrary::Key_IsMouseButton(KeyName);
}

bool ABasePlayerController::Key_IsKeyboardKey(const FName& KeyName) const
{
	return UKismetInputLibrary::Key_IsKeyboardKey(KeyName);
}

// 禁用系统默认的DebugExec绑定F1-F12
void ABasePlayerController::SetDebugExecEnabled(const bool bEnabled)
{
#if !UE_BUILD_SHIPPING
	if (PlayerInput == nullptr) return;
	
	if (bEnabled)
	{
		if (CacheDebugExecBindings.Num() > 0)
		{
			PlayerInput->DebugExecBindings = CacheDebugExecBindings;
		}
	}
	else
	{
		if (CacheDebugExecBindings.Num() == 0)
		{
			CacheDebugExecBindings = PlayerInput->DebugExecBindings;
		}
		PlayerInput->DebugExecBindings.Empty();
	}
#endif
}


#pragma region 输入绑定和监听

void ABasePlayerController::BindAction(const FName& ActionName, int ActionIndex, const ETriggerEvent TriggerEvent)
{
	if (InputComponent == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("ABasePlayerController.BindAction : MISSING InputComponent"));
		return;
	}
	
	if (UEnhancedInputComponent* EnhancedInputComponent = Cast<UEnhancedInputComponent>(InputComponent))
	{
		if (RuntimeMappingContext)
		{
			for (const FEnhancedActionKeyMapping& KeyMapping : RuntimeMappingContext.Get()->GetMappings())
			{
				if (KeyMapping.Action.GetFName() == ActionName)
				{
					TWeakObjectPtr LocalThis(this);
					const FEnhancedInputActionEventBinding& Handle = EnhancedInputComponent->BindActionInstanceLambda(KeyMapping.Action, TriggerEvent, [LocalThis, ActionIndex](const FInputActionInstance& ActionInstance)
						 {
							if(LocalThis.IsValid())
							{
								const FVector2D AxisVector = ActionInstance.GetValue().Get<FVector2D>();
								LocalThis->ReceiveAction(ActionIndex, ActionInstance.GetTriggerEvent(), AxisVector.X, AxisVector.Y);
							}
						 });
					
					if (!BindActionMap.Contains(ActionName))
					{
						BindActionMap.Add(ActionName, TMap<ETriggerEvent, uint32>());
					}
					BindActionMap[ActionName].Add(TriggerEvent, Handle.GetHandle());
					return;
				}
			}
			
			UE_LOG(LogTemp, Warning, TEXT("ABasePlayerController.BindAction : MISSING ACTION %s"), *ActionName.ToString());
		}
	}
}

void ABasePlayerController::UnBindAction(const FName& ActionName, const ETriggerEvent TriggerEvent)
{
	if (InputComponent == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("ABasePlayerController.UnBindAction : MISSING InputComponent"));
		return;
	}
	
	if (UEnhancedInputComponent* EnhancedInputComponent = Cast<UEnhancedInputComponent>(InputComponent))
	{
		if (BindActionMap.Contains(ActionName))
		{
			if (BindActionMap[ActionName].Contains(TriggerEvent))
			{
				EnhancedInputComponent->RemoveBindingByHandle(BindActionMap[ActionName][TriggerEvent]);
				BindActionMap[ActionName].Remove(TriggerEvent);
			}
		}
	}
}

// 运行时bind按键
void ABasePlayerController::BindKey(const FName& ActionName, const FName& KeyName, const EInputActionValueType Type, int ChordActionIndex)
{
	if (RuntimeMappingContext)
	{
		const UInputAction* InputAction = nullptr;
		
		for (const FEnhancedActionKeyMapping& KeyMapping : RuntimeMappingContext.Get()->GetMappings())
		{
			auto Action = KeyMapping.Action;
			if (Action.GetFName() == ActionName)
			{
				InputAction = Action.Get();
				const auto OldKeyName = KeyMapping.Key.GetFName();
				RuntimeMappingContext->UnmapKey(Action.Get(), KeyMapping.Key);
				UE_LOG(LogTemp, Log, TEXT("ABasePlayerController.BindKey : hasAction %s, Key %s ===> %s"), *ActionName.ToString(), *OldKeyName.ToString(), *KeyName.ToString());
				break;
			}
		}

		if (InputAction == nullptr)
		{
			// 没有就新增一个
			UInputAction* NewInputAction = NewObject<UInputAction>(this, ActionName);
			NewInputAction->ValueType = Type;
			InputAction = NewInputAction;
		}
		
		RuntimeMappingContext->MapKey(InputAction, FKey(KeyName));

		// Add ChordAction
		if (ChordActionIndex > 0 and ChordActionIndex <= ChordActionIAArray.Num())
		{
			if (RuntimeMappingContext)
			{
				const auto MappingIdx = RuntimeMappingContext->GetMappings().IndexOfByPredicate([&ActionName](const FEnhancedActionKeyMapping& Mapping)
				{
					return Mapping.Action->GetFName() == ActionName;
				});
				if (MappingIdx != INDEX_NONE)
				{
					RuntimeMappingContext->GetMapping(MappingIdx).Triggers.Reset();
					UInputTriggerChordAction* Trigger = NewObject<UInputTriggerChordAction>();
					Trigger->ChordAction = ChordActionIAArray[ChordActionIndex - 1];
					RuntimeMappingContext->GetMapping(MappingIdx).Triggers.Add(Trigger);
				}
			}
		}
	}
}

// 运行时Unbind按键
void ABasePlayerController::UnBindKey(const FName& ActionName, const FName& KeyName) const
{
	if (RuntimeMappingContext)
	{
		for (const FEnhancedActionKeyMapping& KeyMapping : RuntimeMappingContext.Get()->GetMappings())
		{
			if (KeyMapping.Action.GetFName() == ActionName)
			{
				RuntimeMappingContext->UnmapKey(KeyMapping.Action.Get(), FKey(KeyName));
				return;
			}
		}
	}
}

void ABasePlayerController::UnmapAllKeysFromAction(const FName& ActionName) const
{
	if (RuntimeMappingContext)
	{
		for (const FEnhancedActionKeyMapping& KeyMapping : RuntimeMappingContext.Get()->GetMappings())
		{
			if (KeyMapping.Action.GetFName() == ActionName)
			{
				RuntimeMappingContext->UnmapAllKeysFromAction(KeyMapping.Action.Get());
				return;
			}
		}
	}
}

void ABasePlayerController::RequestRebuildControlMappings() const
{
	if (UEnhancedInputLocalPlayerSubsystem* Subsystem = ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(GetLocalPlayer()))
	{
		FModifyContextOptions Options;
		Options.bForceImmediately = true;
		Subsystem->RequestRebuildControlMappings(Options);
	}
}

void ABasePlayerController::ActivePressAnyKey()
{
	if (InputProcessor == nullptr)
	{
		InputProcessor = MakeShared<FPressAnyKeyInputProcessor>();
		if (InputProcessor.IsValid())
		{
			InputProcessor->OnKeySelected.BindUObject(this, &ThisClass::HandleKeySelected);
			InputProcessor->OnKeySelectionCanceled.BindUObject(this, &ThisClass::HandleKeySelectionCanceled);
		}
	}

	if (InputProcessor.IsValid())
	{
		FSlateApplication::Get().RegisterInputPreProcessor(InputProcessor, 0);
	}
}

void ABasePlayerController::DeactivePressAnyKey() const
{
	if (InputProcessor.IsValid())
	{
		if (FSlateApplication::IsInitialized())
		{
			FSlateApplication::Get().UnregisterInputPreProcessor(InputProcessor);
		}
	}
}

void ABasePlayerController::HandleKeySelected(const FKey& InKey, const EInputEvent EventType)
{
	OnHandleKeySelected(InKey.GetFName(), EventType);
}

void ABasePlayerController::HandleKeySelectionCanceled() const
{
	OnHandleKeySelectionCanceled();
}

#pragma endregion 输入绑定和监听