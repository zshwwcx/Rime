#include "3C/Controller/BasePlayerController.h"

#include "AkComponent.h"
#include "3C/Camera/BaseCamera.h"
#include "3C/Camera/KgCameraMode.h"
#include "3C/Camera/CameraManager.h"
#include "3C/Character/BaseCharacter.h"
#include "Manager/KGAkAudioManager.h"
#include "GameFramework/PlayerState.h"
#include "GameFramework/PawnMovementComponent.h"
#include "Components/InputComponent.h"
#include "NavigationSystem.h"
#include "Misc/ObjCrashCollector.h"
#include "Kismet/KismetSystemLibrary.h"
#include "HUD/Joystick/SKGVirtualJoystick.h"
#include "HUD/Joystick/KGTouchInterface.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "Engine/GameViewportClient.h"
#include "Engine/LocalPlayer.h"
#include "GameFramework/Pawn.h"
#include "3C/Util/KGUtils.h"
#include "GameFramework/InputSettings.h"


FPlayerControllerRequestVirtualJoystickInitVisible ABasePlayerController::OnRequestVirtualJoystickInitVisible;

ABasePlayerController::ABasePlayerController(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	AudioListenerMode = EAudioListenerMode::Camera;
	PlayerCameraManagerClass = ACameraManager::StaticClass();

	PathFollowingComponent = CreateDefaultSubobject<UPathFollowingComponent>(TEXT("PathFollowingComponent"));
	PathFollowingComponent->OnRequestFinished.AddUObject(this, &ABasePlayerController::OnMoveCompleted);
}

void ABasePlayerController::TickActor(float DeltaTime, enum ELevelTick TickType, FActorTickFunction& ThisTickFunction)
{
	QUICK_SCOPE_CYCLE_COUNTER(BasePlayerController_TickActor);

	PreTickActor(DeltaTime, TickType);

	if (PlayerCameraManager)
	{
		if (ACameraManager* CameraMgr = Cast<ACameraManager>(PlayerCameraManager))
		{
			CameraMgr->Update(DeltaTime);
		}
	}
	
	TickMouseMove(DeltaTime);
	
	if (bLastHasRawLocoInput != bHasRawLocoInput)
	{
		if (ABaseCharacter* ControledBaseCharacter = Cast<ABaseCharacter>(GetPawn()))
		{
			ACTOR_CALL_LUA_ENTITY(ControledBaseCharacter, "KCB_NotifyRawLocoInputChanged", bHasRawLocoInput);
		}
	}
	
	bLastHasRawLocoInput = bHasRawLocoInput;
	bHasRawLocoInput = false;

	Super::TickActor(DeltaTime, TickType, ThisTickFunction);
	
}


void ABasePlayerController::CreateTouchInterface()
{
	ULocalPlayer* LocalPlayer = Cast<ULocalPlayer>(Player);

	// do we want to show virtual joysticks?
	if (LocalPlayer && LocalPlayer->ViewportClient && SKGVirtualJoystick::ShouldDisplayTouchInterface(this))
	{
		// in case we already had one, remove it
		if (VirtualJoystick.IsValid())
		{
			Cast<ULocalPlayer>(Player)->ViewportClient->RemoveViewportWidgetContent(VirtualJoystick.ToSharedRef());
		}

		if (CurrentTouchInterface == nullptr)
		{
			// load what the game wants to show at startup
			FSoftObjectPath DefaultTouchInterfaceName = GetDefault<UInputSettings>()->DefaultTouchInterface;

			if (DefaultTouchInterfaceName.IsValid())
			{
				// activate this interface if we have it
				CurrentTouchInterface = LoadObject<UKGTouchInterface>(NULL, *DefaultTouchInterfaceName.ToString());
			}
		}

		if (CurrentTouchInterface)
		{
			// create the joystick 
			VirtualJoystick = CreateVirtualJoystick();

			// add it to the player's viewport
			LocalPlayer->ViewportClient->AddViewportWidgetContent(VirtualJoystick.ToSharedRef());

			ActivateTouchInterface(CurrentTouchInterface);
		}
	}
}

TSharedPtr<class SVirtualJoystick> ABasePlayerController::CreateVirtualJoystick()
{
    if (OnRequestVirtualJoystickInitVisible.IsBound())
    {
        bVirtualJoystickVisible = OnRequestVirtualJoystickInitVisible.Execute();
    }
    
	KGVirtualJoystick = SNew(SKGVirtualJoystick);
    KGVirtualJoystick->SetOwnerPlayerController(this);
    KGVirtualJoystick->SetJoystickVisibility(bVirtualJoystickVisible, false);
	return KGVirtualJoystick;
}

void ABasePlayerController::CleanupGameViewport()
{
	if (KGVirtualJoystick.IsValid())
	{
		KGVirtualJoystick.Reset();
	}
		
	Super::CleanupGameViewport();
}

void ABasePlayerController::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (KGVirtualJoystick.IsValid())
	{
		KGVirtualJoystick.Reset();
	}

	FDebug::DumpStackTraceToLog(ELogVerbosity::Warning);
	
	Super::EndPlay(EndPlayReason);
}

void ABasePlayerController::PostInitializeComponents()
{
	Super::PostInitializeComponents();

	OnPostInitializeComponents();
}

void ABasePlayerController::AutoManageActiveCameraTarget(AActor* SuggestedTarget)
{
	if (PlayerCameraManager)
	{
		ACameraManager* CameraMgr = Cast<ACameraManager>(PlayerCameraManager);
		if (CameraMgr)
		{
			CameraMgr->OnAutoManageActiveCameraTarget(SuggestedTarget);
		}
	}
}

void ABasePlayerController::SetViewTargetWithBlendByID(int64 NewViewTargetID, float BlendTime,
                                                             EViewTargetBlendFunction BlendFunc, float BlendExp,
                                                             bool bLockOutgoing)
{
	if(AActor* NewViewTarget = KGUtils::GetActorByID(NewViewTargetID))
	{
		this->SetViewTargetWithBlend(NewViewTarget, BlendTime, BlendFunc, BlendExp, bLockOutgoing);
	}
}


FQuat ABasePlayerController::GetLocoInputDirectionAsQuat()
{
	auto ownedPawn = GetPawn();
	if (!ownedPawn) {
		return FQuat::Identity;
	}

	URoleMovementComponent* uRoleMCPtr = Cast<URoleMovementComponent>(ownedPawn->GetMovementComponent());
	if (!uRoleMCPtr) {
		return FQuat::Identity;
	}

	auto& locoInputVec = uRoleMCPtr->GetLocoInputVector();

	FRotator locoRotator = locoInputVec.Rotation();
	return locoRotator.Quaternion();

}

FVector ABasePlayerController::GetLocoInputDirectionAsVec() {
	auto ownedPawn = GetPawn();
	if (!ownedPawn) {
		return FVector::ZeroVector;
	}

	URoleMovementComponent* uRoleMCPtr = Cast<URoleMovementComponent>(ownedPawn->GetMovementComponent());
	if (!uRoleMCPtr) {
		return FVector::ZeroVector;
	}

	return uRoleMCPtr->GetLocoInputVector();

}


int64 ABasePlayerController::GetControlledPawnObjectID() {
	return KGUtils::GetIDByObject(GetPawn());
}

void ABasePlayerController::SetVirtualJoystickVisibility(bool bVisible)
{
    if (bVirtualJoystickVisible != bVisible)
    {
        UE_LOG(LogInit, Log, TEXT("[GameStage][SetVirtualJoystickVisibility] %s PC:%s"),
            bVisible ? TEXT("true") : TEXT("false"), *GetFullName());
        bVirtualJoystickVisible = bVisible;
        Super::SetVirtualJoystickVisibility(bVisible);
    }
}


bool ABasePlayerController::PossessWithActorID(int64 ActorID)  {
	AActor* Actor = KGUtils::GetActorByID(ActorID);
	if (APawn *PossessPawn = Cast<APawn>(Actor)) {
		Possess(PossessPawn);
		return true;
	}

	return false;
}

void ABasePlayerController::AutoActiveCameraTarget(AActor* SuggestedTarget)
{
	Super::AutoManageActiveCameraTarget(SuggestedTarget);
}



#pragma region PathFollow
void ABasePlayerController::OnMoveCompleted(FAIRequestID RequestID, const FPathFollowingResult& Result)
{
	ReceiveMoveCompleted.Broadcast(RequestID, Result.Code);
}

EPathFollowingRequestResult::Type ABasePlayerController::MoveToActor(FAIRequestID& RequestID, AActor* Goal, float AcceptanceRadius, TSubclassOf<UNavigationQueryFilter> FilterClass, bool bStopOnOverlap, bool bUsePathfinding, bool bCanStrafe, bool bAllowPartialPaths, float MultiHalfHeight)
{
	if (PathFollowingComponent)
	{
		PathFollowingComponent->SetPreciseReachThreshold(1.1f, MultiHalfHeight);
		if (PathFollowingComponent->GetStatus() != EPathFollowingStatus::Idle)
		{
			PathFollowingComponent->AbortMove(*this, FPathFollowingResultFlags::ForcedScript | FPathFollowingResultFlags::NewRequest, FAIRequestID::CurrentRequest, EPathFollowingVelocityMode::Keep);
		}
	}

	FAIMoveRequest MoveReq(Goal);
	MoveReq.SetUsePathfinding(bUsePathfinding);
	MoveReq.SetAllowPartialPath(bAllowPartialPaths);
	MoveReq.SetNavigationFilter(FilterClass);
	MoveReq.SetAcceptanceRadius(AcceptanceRadius);
	MoveReq.SetReachTestIncludesAgentRadius(bStopOnOverlap);
	MoveReq.SetCanStrafe(bCanStrafe);

	const FPathFollowingRequestResult& ResultData = MoveTo(MoveReq);
	RequestID = ResultData.MoveId;
	return ResultData;
}

bool ABasePlayerController::IsValidMoveRequestID(const FAIRequestID& RequestID)
{
	return RequestID.IsValid();
}

EPathFollowingRequestResult::Type ABasePlayerController::MoveToLocation(FAIRequestID& RequestID, const FVector& Dest, float AcceptanceRadius, TSubclassOf<UNavigationQueryFilter> FilterClass, bool bStopOnOverlap, bool bUsePathfinding, bool bProjectDestinationToNavigation, bool bCanStrafe, bool bAllowPartialPaths, float MultiHalfHeight)
{
	if (PathFollowingComponent)
	{
		PathFollowingComponent->SetPreciseReachThreshold(1.1f, MultiHalfHeight);
		if (PathFollowingComponent->GetStatus() != EPathFollowingStatus::Idle)
		{
			PathFollowingComponent->AbortMove(*this, FPathFollowingResultFlags::ForcedScript | FPathFollowingResultFlags::NewRequest, FAIRequestID::CurrentRequest, EPathFollowingVelocityMode::Keep);
		}
	}


	FAIMoveRequest MoveReq(Dest);
	MoveReq.SetUsePathfinding(bUsePathfinding);
	MoveReq.SetAllowPartialPath(bAllowPartialPaths);
	MoveReq.SetProjectGoalLocation(bProjectDestinationToNavigation);
	MoveReq.SetNavigationFilter(FilterClass);
	MoveReq.SetAcceptanceRadius(AcceptanceRadius);
	MoveReq.SetReachTestIncludesAgentRadius(bStopOnOverlap);
	MoveReq.SetCanStrafe(bCanStrafe);

	FPathFollowingRequestResult Result = MoveTo(MoveReq);
	RequestID = Result.MoveId;

	return Result.Code;
}

FPathFollowingRequestResult ABasePlayerController::MoveTo(const FAIMoveRequest& MoveRequest, FNavPathSharedPtr* OutPath)
{
	FPathFollowingRequestResult ResultData;
	ResultData.Code = EPathFollowingRequestResult::Failed;

	if (MoveRequest.IsValid() == false)
	{
		return ResultData;
	}

	if (PathFollowingComponent == nullptr)
	{
		return ResultData;
	}

	ensure(MoveRequest.GetNavigationFilter());

	bool bCanRequestMove = true;
	bool bAlreadyAtGoal = false;

	if (!MoveRequest.IsMoveToActorRequest())
	{
		if (MoveRequest.GetGoalLocation().ContainsNaN() || FAISystem::IsValidLocation(MoveRequest.GetGoalLocation()) == false)
		{
			bCanRequestMove = false;
		}

		if (bCanRequestMove && MoveRequest.IsProjectingGoal())
		{
			UNavigationSystemV1* NavSys = FNavigationSystem::GetCurrent<UNavigationSystemV1>(GetWorld());
			const FNavAgentProperties& AgentProps = GetNavAgentPropertiesRef();
			FNavLocation ProjectedLocation;

			if (NavSys && !NavSys->ProjectPointToNavigation(MoveRequest.GetGoalLocation(), ProjectedLocation, INVALID_NAVEXTENT, &AgentProps))
			{
				bCanRequestMove = false;
			}

			MoveRequest.UpdateGoalLocation(ProjectedLocation.Location);
		}

		bAlreadyAtGoal = bCanRequestMove && PathFollowingComponent->HasReached(MoveRequest);
	}
	else
	{
		bAlreadyAtGoal = bCanRequestMove && PathFollowingComponent->HasReached(MoveRequest);
	}

	if (bAlreadyAtGoal)
	{
		ResultData.MoveId = PathFollowingComponent->RequestMoveWithImmediateFinish(EPathFollowingResult::Success);
		ResultData.Code = EPathFollowingRequestResult::AlreadyAtGoal;
	}
	else if (bCanRequestMove)
	{
		FPathFindingQuery PFQuery;

		const bool bValidQuery = BuildPathfindingQuery(MoveRequest, PFQuery);
		if (bValidQuery)
		{
			FNavPathSharedPtr Path;
			FindPathForMoveRequest(MoveRequest, PFQuery, Path);

			const FAIRequestID RequestID = Path.IsValid() ? RequestMove(MoveRequest, Path) : FAIRequestID::InvalidRequest;
			if (RequestID.IsValid())
			{
				ResultData.MoveId = RequestID;
				ResultData.Code = EPathFollowingRequestResult::RequestSuccessful;

				if (OutPath)
				{
					*OutPath = Path;
				}
			}
		}
	}

	if (ResultData.Code == EPathFollowingRequestResult::Failed)
	{
		ResultData.MoveId = PathFollowingComponent->RequestMoveWithImmediateFinish(EPathFollowingResult::Invalid);
	}

	return ResultData;
}

FAIRequestID ABasePlayerController::RequestMove(const FAIMoveRequest& MoveRequest, FNavPathSharedPtr Path)
{
	uint32 RequestID = FAIRequestID::InvalidRequest;
	if (PathFollowingComponent)
	{
		RequestID = PathFollowingComponent->RequestMove(MoveRequest, Path);
	}

	return RequestID;
}

void ABasePlayerController::FindPathForMoveRequest(const FAIMoveRequest& MoveRequest, FPathFindingQuery& Query, FNavPathSharedPtr& OutPath) const
{
	UNavigationSystemV1* NavSys = FNavigationSystem::GetCurrent<UNavigationSystemV1>(GetWorld());
	if (NavSys)
	{
		FPathFindingResult PathResult = NavSys->FindPathSync(Query);
		if (PathResult.Result != ENavigationQueryResult::Error)
		{
			if (PathResult.IsSuccessful() && PathResult.Path.IsValid())
			{
				if (MoveRequest.IsMoveToActorRequest())
				{
					PathResult.Path->SetGoalActorObservation(*MoveRequest.GetGoalActor(), 100.0f);
				}

				PathResult.Path->EnableRecalculationOnInvalidation(true);
				OutPath = PathResult.Path;
			}
		}
	}
}

bool ABasePlayerController::BuildPathfindingQuery(const FAIMoveRequest& MoveRequest, FPathFindingQuery& Query) const
{
	bool bResult = false;

	UNavigationSystemV1* NavSys = FNavigationSystem::GetCurrent<UNavigationSystemV1>(GetWorld());
	const ANavigationData* NavData = (NavSys == nullptr) ? nullptr :
		MoveRequest.IsUsingPathfinding() ? NavSys->GetNavDataForProps(GetNavAgentPropertiesRef(), GetNavAgentLocation()) :
		NavSys->GetAbstractNavData();

	if (NavData)
	{
		FVector GoalLocation = MoveRequest.GetGoalLocation();
		if (MoveRequest.IsMoveToActorRequest())
		{
			const INavAgentInterface* NavGoal = Cast<const INavAgentInterface>(MoveRequest.GetGoalActor());
			if (NavGoal)
			{
				const FVector Offset = NavGoal->GetMoveGoalOffset(this);
				GoalLocation = FQuatRotationTranslationMatrix(MoveRequest.GetGoalActor()->GetActorQuat(), NavGoal->GetNavAgentLocation()).TransformPosition(Offset);
			}
			else
			{
				GoalLocation = MoveRequest.GetGoalActor()->GetActorLocation();
			}
		}

		FSharedConstNavQueryFilter NavFilter = UNavigationQueryFilter::GetQueryFilter(*NavData, this, MoveRequest.GetNavigationFilter());
		Query = FPathFindingQuery(*this, *NavData, GetNavAgentLocation(), GoalLocation, NavFilter);
		Query.SetAllowPartialPaths(MoveRequest.IsUsingPartialPaths());

		if (PathFollowingComponent)
		{
			PathFollowingComponent->OnPathfindingQuery(Query);
		}

		bResult = true;
	}

	return bResult;
}

bool ABasePlayerController::PauseMove(FAIRequestID RequestToPause)
{
	if (PathFollowingComponent != NULL && RequestToPause.IsEquivalent(PathFollowingComponent->GetCurrentRequestId()))
	{
		PathFollowingComponent->PauseMove(RequestToPause, EPathFollowingVelocityMode::Reset);
		return true;
	}
	return false;
}

bool ABasePlayerController::ResumeMove(FAIRequestID RequestToResume)
{
	if (PathFollowingComponent != NULL && RequestToResume.IsEquivalent(PathFollowingComponent->GetCurrentRequestId()))
	{
		PathFollowingComponent->ResumeMove(RequestToResume);
		return true;
	}
	return false;
}

void ABasePlayerController::StopMovement()
{
	PathFollowingComponent->AbortMove(*this, FPathFollowingResultFlags::MovementStop | FPathFollowingResultFlags::ForcedScript);
}


bool ABasePlayerController::GetHitResultUnderCursorWithIgnoreActors(ECollisionChannel TraceChannel, bool bTraceComplex, FHitResult& HitResult,const TArray<AActor*> IngoreActors) const
{
	ULocalPlayer* LocalPlayer = Cast<ULocalPlayer>(Player);
	bool bHit = false;
	if (LocalPlayer && LocalPlayer->ViewportClient)
	{
		FVector2D MousePosition;
	
		if (LocalPlayer->ViewportClient->GetMousePosition(MousePosition))
		{
			FCollisionQueryParams CollisionQueryParams(SCENE_QUERY_STAT(ClickableTrace), bTraceComplex );
			CollisionQueryParams.AddIgnoredActors(IngoreActors);
			bHit = GetHitResultAtScreenPosition(MousePosition, TraceChannel, CollisionQueryParams, HitResult);
		}
	}

	if(!bHit)	//If there was no hit we reset the results. This is redundant but helps Blueprint users
		{
		HitResult = FHitResult();
		}

	return bHit;
}

bool ABasePlayerController::GetHitResultUnderFingerWithIgnoreActors(ETouchIndex::Type FingerIndex, ECollisionChannel TraceChannel, bool bTraceComplex, FHitResult& HitResult,const TArray<AActor*> IngoreActors) const
{
	bool bHit = false;
	if (PlayerInput)
	{
		FVector2f TouchPosition;
		bool bIsPressed = false;
		GetInputTouchState(FingerIndex, TouchPosition.X, TouchPosition.Y, bIsPressed);
		if (bIsPressed)
		{
			FCollisionQueryParams CollisionQueryParams(SCENE_QUERY_STAT(ClickableTrace), bTraceComplex );
			CollisionQueryParams.AddIgnoredActors(IngoreActors);
			bHit = GetHitResultAtScreenPosition(FVector2D(TouchPosition), TraceChannel, CollisionQueryParams, HitResult);
		}
	}

	if(!bHit)	//If there was no hit we reset the results. This is redundant but helps Blueprint users
	{
		HitResult = FHitResult();
	}

	return bHit;
}

bool ABasePlayerController::GetMouseRayPlaneIntersection(float Height, float& PositionX, float& PositionY, float& PositionZ)
{
	FVector WorldLocation;
	FVector WorldDirection;
	float MouseX, MouseY;
        
	GetMousePosition(MouseX, MouseY);
	DeprojectScreenPositionToWorld(MouseX, MouseY, WorldLocation, WorldDirection);

	FVector PlanePosition = FVector(0, 0, Height);
	FVector PlaneNormal = FVector(0, 0, 1);

	float DotProduct = FVector::DotProduct(WorldDirection, PlaneNormal);
	if (FMath::Abs(DotProduct) < KINDA_SMALL_NUMBER)
	{
		return false;
	}
       
	float IntersectionDistance = FVector::DotProduct(PlanePosition - WorldLocation, PlaneNormal) / DotProduct;
	if (IntersectionDistance < 0)
	{
		return false;
	}

	FVector IntersectPoint = WorldLocation + IntersectionDistance * WorldDirection;
	PositionX = IntersectPoint.X;
	PositionY = IntersectPoint.Y;
	PositionZ = IntersectPoint.Z;

	return true;
}

#pragma endregion PathFollow


#pragma region AudioListener


void ABasePlayerController::GetAudioListenerPosition(FVector& OutLocation, FVector& OutFrontDir, FVector& OutRightDir) const
{
	ABaseCharacter* MainPlayer = Cast<ABaseCharacter>(GetPawn());
	if (AudioListenerMode == EAudioListenerMode::Player && MainPlayer && IsValid(PlayerCameraManager))
	{
		// 先尝试不挂头看看效果
		FVector PlayerLocation = MainPlayer->GetActorLocation();
		FRotator CameraRotation = PlayerCameraManager->GetCameraRotation();

		const FRotationTranslationMatrix RotationTranslationMatrix(CameraRotation, PlayerLocation);

		OutLocation = PlayerLocation;
		OutFrontDir = RotationTranslationMatrix.GetUnitAxis(EAxis::X);
		OutRightDir = RotationTranslationMatrix.GetUnitAxis(EAxis::Y);
	}
	else
	{
		Super::GetAudioListenerPosition(OutLocation, OutFrontDir, OutRightDir);	
	}
}

void ABasePlayerController::SwitchAudioListenerMode(EAudioListenerMode InAudioListenerMode)
{
UE_LOG(LogAkAudio, Log, TEXT("ABasePlayerController::SwitchAudioListenerMode to %u"), InAudioListenerMode);
	AudioListenerMode = InAudioListenerMode;
	
	if (IsValid(PlayerCameraManager))
	{
		if (UAkComponent* AkComponent = PlayerCameraManager->GetComponentByClass<UAkComponent>())
		{
			if (AudioListenerMode == EAudioListenerMode::Camera)
			{
				AkComponent->AttachToComponent(PlayerCameraManager->GetRootComponent(), FAttachmentTransformRules::SnapToTargetIncludingScale);
			}
			else if (AudioListenerMode == EAudioListenerMode::Player)
			{
				if (ABaseCharacter* MainPlayer = Cast<ABaseCharacter>(GetPawn()))
				{
					AkComponent->AttachToComponent(MainPlayer->GetRootComponent(), FAttachmentTransformRules::SnapToTargetIncludingScale);
				}
			}	
		}
	}
}


#pragma endregion AudioListener


void ABasePlayerController::SetSpawnPoint(float X, float Y, float Z, float Pitch, float Yaw, float Roll)
{
	SpawnLocation.X = X;
	SpawnLocation.Y = Y;
	SpawnLocation.Z = Z;

	SpawnRotation.Pitch = Pitch;
	SpawnRotation.Yaw = Yaw;
	SpawnRotation.Roll = Roll;
}

void ABasePlayerController::GetSpawnPoint(FVector& OutLocation, FRotator& OutRotation)
{
	OutLocation = SpawnLocation;
	OutRotation = SpawnRotation;
}

FVector ABasePlayerController::GetSpawnLocation()
{
	return SpawnLocation;
}
