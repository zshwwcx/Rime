#include "3C/Light/CharacterLightManager.h"
#include "3C/Camera/CameraManager.h"

void UCharacterLightManager::NativeInit()
{
	Super::NativeInit();
	FCoreUObjectDelegates::PreLoadMap.AddUObject(this, &UCharacterLightManager::OnPreLoadMap);
	
	using namespace NS_SLUA;
	REG_MANAGER_FUNC(UCharacterLightManager, "SetCharacterLightFixControllerClassPath", &UCharacterLightManager::SetCharacterLightFixControllerClassPath);
	REG_MANAGER_FUNC(UCharacterLightManager, "SetOverrideIndirectIntensity", &UCharacterLightManager::SetOverrideIndirectIntensity);
	REG_MANAGER_FUNC(UCharacterLightManager, "SetOverrideIndirectColor", &UCharacterLightManager::SetOverrideIndirectColor);
	REG_MANAGER_FUNC(UCharacterLightManager, "SetOverrideDirLightWeight", &UCharacterLightManager::SetOverrideDirLightWeight);
	REG_MANAGER_FUNC(UCharacterLightManager, "SetOverrideInverseExposureBlend", &UCharacterLightManager::SetOverrideInverseExposureBlend);
	REG_MANAGER_FUNC(UCharacterLightManager, "SetOverrideCharacterFaceLightIntensity", &UCharacterLightManager::SetOverrideCharacterFaceLightIntensity);
	REG_MANAGER_FUNC(UCharacterLightManager, "SetOverrideCharacterHDRLightIntensity", &UCharacterLightManager::SetOverrideCharacterHDRLightIntensity);
	REG_MANAGER_FUNC(UCharacterLightManager, "GetCurrentCharacterIndirectIntensity", &UCharacterLightManager::GetCurrentCharacterIndirectIntensity);
	REG_MANAGER_FUNC(UCharacterLightManager, "StartExposureBlend", &UCharacterLightManager::StartExposureBlend);
	REG_MANAGER_FUNC(UCharacterLightManager, "EnableCharacterLightFix", &UCharacterLightManager::EnableCharacterLightFix);
	REG_MANAGER_FUNC(UCharacterLightManager, "CloseSceneWeight", &UCharacterLightManager::CloseSceneWeight);
	REG_MANAGER_FUNC(UCharacterLightManager, "SetLightFixDataPath", &UCharacterLightManager::SetLightFixDataPath);
	REG_MANAGER_FUNC(UCharacterLightManager, "RefreshLightFixDataReference", &UCharacterLightManager::RefreshLightFixDataReference);
	REG_MANAGER_FUNC(UCharacterLightManager, "SetTickFrameTime", &UCharacterLightManager::SetTickFrameTime);
	REG_MANAGER_FUNC(UCharacterLightManager, "SetIsFemale", &UCharacterLightManager::SetIsFemale);
	REG_MANAGER_FUNC(UCharacterLightManager, "Tick", &UCharacterLightManager::Tick); // invoke in editor
}

void UCharacterLightManager::NativeUninit()
{
	Super::NativeUninit();
	FCoreUObjectDelegates::PreLoadMap.RemoveAll(this);
}

void UCharacterLightManager::OnPreLoadMap(const FString& MapName)
{
	bActive = false;
}

void UCharacterLightManager::OnPostLoadMapWithWorld(UWorld* World)
{
	if(World == nullptr || World->PersistentLevel == nullptr)
	{
		return;
	}
	bActive = true;
	TickFunction.UnRegisterTickFunction();
	TickFunction.Manager = this;
	TickFunction.TickGroup = ETickingGroup::TG_DuringPhysics;
	TickFunction.RegisterTickFunction(World->PersistentLevel);
}

void UCharacterLightManager::SetTickFrameTime(float time)
{
	tickFrameTime = time;
}

void UCharacterLightManager::Tick(float DeltaTime)
{
	QUICK_SCOPE_CYCLE_COUNTER(CharacterLightManager_Tick);
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("CharacterLightManager_Tick");
	
	if (!bActive)
	{
		return;
	}

	UWorld* World = GetWorld();
    if (!World)
    {
    	return;
    }
	
	double CurrentTime = World->GetTimeSeconds();
	if (CurrentTime - LastUpdateTime < tickFrameTime)
	{
		return;
	}
	LastUpdateTime = CurrentTime;
	
	TickExposureBlend(DeltaTime);
	UpdateCharacterLight(DeltaTime);
}

void UCharacterLightManager::SetCharacterLightFixControllerClassPath(FString ClassPath)
{
	CharacterLightFixControllerClassPath = ClassPath;
	CharacterLightFixControllerClass = LoadClass<UObject>(nullptr, *ClassPath);
}

void UCharacterLightManager::SetOverrideIndirectIntensity(bool bOverride, double InColor)
{
	// Todo: 后续会改成C++
	if (UObject* LightFixController = GetCurrentCharacterLightFixController())
	{
		if (const FBoolProperty* Prop = FindFProperty<FBoolProperty>(LightFixController->GetClass(), TEXT("IsOverrideIndirectIntensity")))
		{
			Prop->SetPropertyValue_InContainer(LightFixController, bOverride);
		}

		if (UFunction* Func = LightFixController->FindFunction(FName("SetOverrideIndirectIntensity")))
		{
			struct FParams { double Value; };
			FParams Params{InColor};
			LightFixController->ProcessEvent(Func, &Params);
		}
		UpdateCharacterLight(0.1f);
	}
}

void UCharacterLightManager::SetOverrideDirLightWeight(bool bOverride, double InValue)
{
	if (UObject* LightFixController = GetCurrentCharacterLightFixController())
	{
		if (const FBoolProperty* Prop = FindFProperty<FBoolProperty>(LightFixController->GetClass(), TEXT("IsOverrideDirLightWeight")))
		{
			Prop->SetPropertyValue_InContainer(LightFixController, bOverride);
		}

		if (UFunction* Func = LightFixController->FindFunction(FName("SetOverrideDirLightWeight")))
		{
			struct FParams { double Value; };
			FParams Params{InValue};
			LightFixController->ProcessEvent(Func, &Params);
		}
		UpdateCharacterLight(0.1f);
	}
}

void UCharacterLightManager::SetOverrideInverseExposureBlend(bool bOverride, double InValue)
{
	if (UObject* LightFixController = GetCurrentCharacterLightFixController())
	{
		if (const FBoolProperty* Prop = FindFProperty<FBoolProperty>(LightFixController->GetClass(), TEXT("IsOverrideInverseExposureBlend")))
		{
			Prop->SetPropertyValue_InContainer(LightFixController, bOverride);
		}

		if (UFunction* Func = LightFixController->FindFunction(FName("SetOverrideInverseExposureBlend")))
		{
			struct FParams { double Value; };
			FParams Params{InValue};
			LightFixController->ProcessEvent(Func, &Params);
		}
	}
}

void UCharacterLightManager::SetOverrideCharacterFaceLightIntensity(bool bOverride, double InValue)
{
	if (UObject* LightFixController = GetCurrentCharacterLightFixController())
	{
		if (const FBoolProperty* Prop = FindFProperty<FBoolProperty>(LightFixController->GetClass(), TEXT("IsOverrideCharacterFaceLightIntensity")))
		{
			Prop->SetPropertyValue_InContainer(LightFixController, bOverride);
		}

		if (UFunction* Func = LightFixController->FindFunction(FName("SetOverrideCharacterFaceLightIntensity")))
		{
			struct FParams { double Value; };
			FParams Params{InValue};
			LightFixController->ProcessEvent(Func, &Params);
		}
	}
}

void UCharacterLightManager::SetOverrideCharacterHDRLightIntensity(bool bOverride, double InValue)
{
	if (UObject* LightFixController = GetCurrentCharacterLightFixController())
	{
		if (const FBoolProperty* Prop = FindFProperty<FBoolProperty>(LightFixController->GetClass(), TEXT("IsOverrideCharacterHDRLightIntensity")))
		{
			Prop->SetPropertyValue_InContainer(LightFixController, bOverride);
		}

		if (UFunction* Func = LightFixController->FindFunction(FName("SetOverrideCharacterHDRLightIntensity")))
		{
			struct FParams { double Value; };
			FParams Params{InValue};
			LightFixController->ProcessEvent(Func, &Params);
		}
	}
}

void UCharacterLightManager::SetIsFemale(bool bNewIsFemale)
{
	IsFemale = bNewIsFemale;
}

void UCharacterLightManager::SetOverrideIndirectColor(bool bOverride, FLinearColor InColor)
{
	if (UObject* LightFixController = GetCurrentCharacterLightFixController())
	{
		if (const FBoolProperty* Prop = FindFProperty<FBoolProperty>(LightFixController->GetClass(), TEXT("IsOverrideIndirectColor")))
		{
			Prop->SetPropertyValue_InContainer(LightFixController, bOverride);
		}

		if (UFunction* Func = LightFixController->FindFunction(FName("SetOverrideIndirectColor")))
		{
			struct FParams { FLinearColor Value; };
			FParams Params{InColor};
			LightFixController->ProcessEvent(Func, &Params);
		}
		UpdateCharacterLight(0.1f);
	}
}

float UCharacterLightManager::GetCurrentCharacterIndirectIntensity()
{
	if (UObject* LightFixController = GetCurrentCharacterLightFixController())
	{
		UFunction* Func = LightFixController->FindFunction(FName("Get Current Charactor Indirect Intensity"));
		if (Func)
		{
			struct FParams { double Value; };
			FParams Params;
			LightFixController->ProcessEvent(Func, &Params);
			return Params.Value;
		}
	}
	
	return -1;
}

UObject* UCharacterLightManager::GetCurrentCharacterLightFixController()
{
	if(CharacterLightFixController.IsValid())
	{
		return CharacterLightFixController.Get(); 
	}

	CharacterLightFixController = UGameplayStatics::GetActorOfClass(GetWorld(), CharacterLightFixControllerClass);
	if(!CharacterLightFixController.IsValid())
	{
		UWorld* World = GetWorld();
		if (!World || !World->GetCurrentLevel())
		{
			UE_LOG(LogTemp, Warning, TEXT("UCharacterLightManager::GetCurrentCharacterLightFixController, invalid world"));
			return nullptr;
		}
		CharacterLightFixController = World->SpawnActor(CharacterLightFixControllerClass);
		if (!CharacterLightFixController.IsValid())
		{
			UE_LOG(LogTemp, Error, TEXT("UCharacterLightManager SpawnActor %s failed"), *CharacterLightFixControllerClass->GetName());
			return nullptr;
		}
	}
	return CharacterLightFixController.Get();
}

//角色的曝光补偿 https://docs.corp.kuaishou.com/d/home/fcADIMEr3TG7ol6BVTaAYrU2z
void UCharacterLightManager::StartExposureBlend(float targetExp, float blendTime)
{
	if (blendTime < 0.0f)
	{
		blendTime = 0.0f;
	}
	StartLightExp = CurrentLightExp;
	TargetLightExp = targetExp;
	EXPTotalBlendTime = blendTime;
	EXPCurTime = 0.0f;
}

void UCharacterLightManager::TickExposureBlend(float DeltaTime)
{
	if (EXPCurTime < 0 || EXPTotalBlendTime < 0)
	{
		return;
	}

	EXPCurTime += DeltaTime;
	float Value = 1.0f;

	if (EXPCurTime < EXPTotalBlendTime && EXPTotalBlendTime != 0.0f)
	{
		float alpha = EXPCurTime / EXPTotalBlendTime;
		Value = (TargetLightExp - StartLightExp) * alpha + StartLightExp;
	}
	else
	{
		EXPTotalBlendTime = -1.0f;
		EXPCurTime = -1.0f;
		Value = TargetLightExp;
	}
	
	if (UObject* lightFixController = GetCurrentCharacterLightFixController())
	{
		UFunction* SetCurExposureCompensationFunction = lightFixController->FindFunction(FName("SetCurExposureCompensation"));
		if(SetCurExposureCompensationFunction)
		{
			struct FParams { double Value; };
			FParams Params;
			Params.Value = Value;
			CurrentLightExp = Value;
			lightFixController->ProcessEvent(SetCurExposureCompensationFunction, &Params);
		}
	}
}

void UCharacterLightManager::EnableCharacterLightFix(bool bEnable)
{
	EnableCharacterLight = bEnable;
	EnableCharacterLightDirty = true;
}

void UCharacterLightManager::CloseSceneWeight()
{
	if (UObject* lightFixController = GetCurrentCharacterLightFixController())
	{
		UFunction* CloseSceneWeightFunction = lightFixController->FindFunction(FName("CloseSceneWeight"));
		if(CloseSceneWeightFunction)
		{
			lightFixController->ProcessEvent(CloseSceneWeightFunction, nullptr);
		}
	}
}

APlayerCameraManager* UCharacterLightManager::GetCameraManager()
{
	if (CameraManager.IsValid()){
		return CameraManager.Get();
	}
	CameraManager = UGameplayStatics::GetPlayerCameraManager(GetWorld(), 0);
	return CameraManager.Get();
}

void UCharacterLightManager::UpdateForwardDirection()
{
	ACameraManager* CurrentCameraManager = Cast<ACameraManager>(GetCameraManager());
	if (!CurrentCameraManager)
	{
		return;
	}
	
	UKgCameraMode* CurMode = CurrentCameraManager->GetCurCameraMode();
	if(!CurMode)
	{
		return;
	}
	
	ForwardDirection = CameraManager->GetCameraCacheView().Rotation.Vector();
}

void UCharacterLightManager::UpdateCharacterLight(float DeltaTime)
{
	UpdateForwardDirection();
	
	if (UObject* lightFixController = GetCurrentCharacterLightFixController())
	{
		if(EnableCharacterLightDirty)
		{
			if(EnableCharacterLight)
			{
				UFunction* OpenLightFixFunction = lightFixController->FindFunction(FName("OpenLightFix"));
				if(OpenLightFixFunction)
				{
					lightFixController->ProcessEvent(OpenLightFixFunction, nullptr);
				}
			}
			else
			{
				UFunction* CloseLightFixFunction = lightFixController->FindFunction(FName("CloseLightFix"));
				if(CloseLightFixFunction)
				{
					lightFixController->ProcessEvent(CloseLightFixFunction, nullptr);
				}
			}
			EnableCharacterLightDirty = false;
		}
		
		UFunction* BPFunction = lightFixController->FindFunction(FName("UpdateCharactorDirectionalLightParam"));
		if(BPFunction)
		{
			struct FParams
			{
				FVector ForwardVector;
				bool IsFemale;
			};
			FParams Params;
			Params.ForwardVector = ForwardDirection;
			Params.IsFemale = IsFemale;
			lightFixController->ProcessEvent(BPFunction, &Params);
		}
	}
}

void UCharacterLightManager::SetLightFixDataPath(FString DataPath)
{
	if(DataPath.IsEmpty())
	{
		return;
	}
	
	if (UObject* lightFixController = GetCurrentCharacterLightFixController())
	{
		UFunction* BPFunction = lightFixController->FindFunction(FName("SetLevelPath"));
		if(BPFunction)
		{
			struct FParams { FString DataPath; };
			FParams Params;
			Params.DataPath = DataPath;
			lightFixController->ProcessEvent(BPFunction, &Params);
		}
	}
}

void UCharacterLightManager::RefreshLightFixDataReference(FString DataPath)
{
	if (UObject* lightFixController = GetCurrentCharacterLightFixController())
	{
		if(!DataPath.IsEmpty())
		{
			UFunction* BPFunction = lightFixController->FindFunction(FName("SetLevelPath"));
			if(BPFunction)
			{
				struct FParams { FString DataPath; };
				FParams Params;
				Params.DataPath = DataPath;
				lightFixController->ProcessEvent(BPFunction, &Params);
			}
		}

		UFunction* BPFunction = lightFixController->FindFunction(FName("UpdateLightFixReference"));
		if(BPFunction)
		{
			lightFixController->ProcessEvent(BPFunction, nullptr);
		}
	}
}