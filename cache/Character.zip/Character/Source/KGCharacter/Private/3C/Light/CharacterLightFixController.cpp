#include "3C/Light/CharacterLightFixController.h"

ACharacterLightFixController::ACharacterLightFixController()
{
	PrimaryActorTick.bCanEverTick = true;
}

void ACharacterLightFixController::BeginPlay()
{
	Super::BeginPlay();
	
}

void ACharacterLightFixController::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

float ACharacterLightFixController::GetCurrentCharacterLightIntensity()
{
	return 0;
}