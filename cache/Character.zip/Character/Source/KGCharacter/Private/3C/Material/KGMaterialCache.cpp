#include "3C/Material/KGMaterialCache.h"

#include "Manager/KGCppAssetManager.h"
#include "3C/Core/C7ActorInterface.h"
#include "3C/Material/KGMaterialManager.h"
#include "3C/Util/KGUtils.h"
#include "Components/MeshComponent.h"
#include "GameFramework/Actor.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Runtime/FaceControlComponent.h"

#include "3C/Material/KGMaterialCommon.h" // KGMaterialUtils::CreateDynamicMaterialInstance
#include "Misc/ScopeLock.h"

LLM_DEFINE_TAG(FMaterialMIDPool);

FMaterialMIDPool& FMaterialMIDPool::Get()
{
	static FMaterialMIDPool Instance;
	return Instance;
}

static TAutoConsoleVariable<int32> CVarMaterialMIDPoolEnable(
	TEXT("MaterialMIDPool.Enable"), 1,
	TEXT("Enable Material MID Pool (0=off, 1=on)")
);

static TAutoConsoleVariable<int32> CVarMaterialMIDPoolDontClear(
	TEXT("MaterialMIDPool.DontClear"), 0,
	TEXT("Release Material Dont Clear Values (0=off, 1=on)")
);

static  TAutoConsoleVariable<int32> CVarMaterialMIDPoolClearMode(
	TEXT("MaterialMIDPool.ClearMode"), 2,
	TEXT("Release Material Clear Mode (1=Simple, 2=Deep)")
);

void FMaterialMIDPool::SetMaxPerParent(int32 InMax)
{
	MaxPerParent = FMath::Max(1, InMax);
}

// Tick 会定期清理空桶与超时桶
void FMaterialMIDPool::Tick()
{
	if (CVarMaterialMIDPoolEnable.GetValueOnGameThread() == 0) return;

	static double LastTickTime = 0.0;
	const double CurrentTime = FPlatformTime::Seconds();
	const double TickInterval = 5.0; // 5 seconds interval

	if (CurrentTime - LastTickTime < TickInterval)
	{
		return;
	}
	LastTickTime = CurrentTime;

	TArray<UMaterialInterface*> KeysToRemove;
	for (auto& Kvp : PoolMap)
	{
		UMaterialInterface* Key = Kvp.Key;
		FMaterialMIDBucket& Bucket = Kvp.Value;

		CleanUpExpiredBucket(Bucket.Items);

		// 如果桶为空并且超过空桶保留时间，则移除整个键
		if (Bucket.Items.Num() == 0)
		{
			if (CurrentTime - Bucket.LastAccessTime > EmptyBucketEvictSeconds)
			{
				KeysToRemove.Add(Key);
			}
		}
		else
		{
			// 如果最近访问超过阈值，则回收该桶中的所有 MID（RemoveFromRoot）
			if (CurrentTime - Bucket.LastAccessTime > BucketEvictSeconds)
			{
				for (TWeakObjectPtr<UMaterialInstanceDynamic>& MIDPtr : Bucket.Items)
				{
					if (MIDPtr.IsValid())
					{
						UMaterialInstanceDynamic* MID = MIDPtr.Get();
						if (!MID->IsUnreachable() && !MID->HasAnyFlags(RF_BeginDestroyed | RF_FinishDestroyed))
						{
							MID->RemoveFromRoot();
						}
					}
				}
				Bucket.Items.Empty();
				KeysToRemove.Add(Key);
			}
		}
	}

	for (UMaterialInterface* Key : KeysToRemove)
	{
		PoolMap.Remove(Key);
	}
}

static FORCEINLINE uint64 PtrKey(const UMaterialInstanceDynamic* MID)
{
	return static_cast<uint64>(reinterpret_cast<uintptr_t>(MID));
}

UMaterialInstanceDynamic* FMaterialMIDPool::Acquire(UMaterialInterface* Parent)
{
	if (CVarMaterialMIDPoolEnable.GetValueOnGameThread() == 0)
	{
		return CreateMID(Parent);
	}

	if (Parent == nullptr)
	{
		return nullptr;
	}

	LLM_SCOPE_BYTAG(FMaterialMIDPool);

	FMaterialMIDBucket& Bucket = PoolMap.FindOrAdd(Parent);
	Bucket.Touch();

	for (int32 i = 0; i < Bucket.Items.Num(); ++i)
	{
		TWeakObjectPtr<UMaterialInstanceDynamic> MIDPtr = Bucket.Items[i];
		if (!MIDPtr.IsValid())
		{
			Bucket.Items.RemoveAtSwap(i);
			--i;
			continue;
		}

		UMaterialInstanceDynamic* MID = MIDPtr.Get();
		Bucket.Items.RemoveAtSwap(i);
		if (!IsValidRawMID(MID))
		{
			--i;
			continue;
		}
		const uint64 Key = PtrKey(MID);
		Bucket.DedupSet.Remove(Key);
		MID->RemoveFromRoot();
		CPP_MAT_CACHE_LOG(TEXT("FMaterialMIDPool::Acquire Parent-> %s Mid -> %s(%p)(%d) Buckets -> %d"), *Parent->GetName(), *MID->GetName(), MID, Key, Bucket.Items.Num());
		return MID;
	}
	UMaterialInstanceDynamic* NewMID = CreateMID(Parent);
	CPP_MAT_CACHE_LOG(TEXT("FMaterialMIDPool::New Parent -> %s Mid -> %s(%p) "), *Parent->GetName(), *NewMID->GetName(), NewMID);
	return NewMID;
}

void FMaterialMIDPool::Release(UMaterialInterface* MI)
{
	if (MI == nullptr)
	{
		return;
	}
	if (UMaterialInstanceDynamic* MID = Cast<UMaterialInstanceDynamic>(MI))
	{
		Release(MID);
	}
}

void FMaterialMIDPool::Release(UMaterialInstanceDynamic* MID)
{
	static IConsoleVariable* CVar = IConsoleManager::Get().FindConsoleVariable(TEXT("MaterialMIDPool.Enable"));
	if (CVar != nullptr && CVar->GetInt() == 0) return;

	if (!IsValidRawMID(MID))
	{
		return;
	}

	UMaterialInterface* Parent = MID->Parent.Get();
	if (Parent == nullptr)
	{
		if (!MID->IsUnreachable() && !MID->HasAnyFlags(RF_BeginDestroyed | RF_FinishDestroyed))
		{
			MID->RemoveFromRoot();
		}
		CPP_MAT_CACHE_LOG(TEXT("FMaterialMIDPool::Release Parent is NuLL Mid -> %s"), *MID->GetName());
		return;
	}
	LLM_SCOPE_BYTAG(FMaterialMIDPool);
	FMaterialMIDBucket* BucketPtr = PoolMap.Find(Parent);
	if (!BucketPtr)
	{
		//CPP_MAT_CACHE_LOG(TEXT("FMaterialMIDPool::Release Parent -> %s Mid -> %s No Bucket"), *Parent->GetName(), *MID->GetName());
		return;
	}
	FMaterialMIDBucket& Bucket = *BucketPtr;

	// 清理参数避免串味
	if (CVarMaterialMIDPoolDontClear.GetValueOnGameThread() == 0)
	{
		if (CVarMaterialMIDPoolClearMode.GetValueOnGameThread() == 1)
		{
			MID->ScalarParameterValues.Empty();
			MID->VectorParameterValues.Empty();
			MID->DoubleVectorParameterValues.Empty();
			MID->TextureParameterValues.Empty();
			MID->RuntimeVirtualTextureParameterValues.Empty();
			MID->SparseVolumeTextureParameterValues.Empty();
			MID->FontParameterValues.Empty();
		}
		else
		{
			MID->ClearParameterValues();
		}
	}
		

	// 保持在根上以防被 GC 回收
	MID->AddToRoot();
	
	const uint64 Key = PtrKey(MID);
	CPP_MAT_CACHE_LOG(TEXT("FMaterialMIDPool::Release Parent -> %s Mid -> %s(%p)(%d) Buckets -> %d"), *Parent->GetName(), *MID->GetName(), MID, Key, Bucket.Items.Num());
	if (Bucket.DedupSet.Contains(Key))
	{
		Bucket.Touch();
		return;
	}

	Bucket.Items.Insert(TWeakObjectPtr<UMaterialInstanceDynamic>(MID), 0);
	Bucket.DedupSet.Add(Key);
	Bucket.Touch();

	while (Bucket.Items.Num() > MaxPerParent)
	{
		TWeakObjectPtr<UMaterialInstanceDynamic> TailPtr = Bucket.Items.Pop(EAllowShrinking::No);
		if (TailPtr.IsValid())
		{
			if (UMaterialInstanceDynamic* Tail = TailPtr.Get())
			{
				Bucket.DedupSet.Remove(PtrKey(Tail));
				Tail->RemoveFromRoot();
			}
		}
		else
		{
			Bucket.DedupSet.Remove(PtrKey(TailPtr.Get()));
		}
	}
}

void FMaterialMIDPool::Flush()
{
	LLM_SCOPE_BYTAG(FMaterialMIDPool);
	for (auto& Kvp : PoolMap)
	{
		FMaterialMIDBucket& Bucket = Kvp.Value;
		for (TWeakObjectPtr<UMaterialInstanceDynamic>& MIDPtr : Bucket.Items)
		{
			if (MIDPtr.IsValid())
			{
				if (UMaterialInstanceDynamic* MID = MIDPtr.Get())
				{
					MID->RemoveFromRoot();
				}
			}
			
		}
		Bucket.Items.Empty();
	}
	PoolMap.Empty();
}

void FKGMaterialCacheController::InitMaterialCacheStack(TWeakObjectPtr<AActor> ActorPtr, const KGMaterialCacheKeyMapping& MaterialCacheKeys, bool bUseAssetMaterial)
{
	if (!ActorPtr.IsValid())
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialCacheSet::InitMaterialCacheStack, invalid actor"));
		return;
	}

	for (const auto& Kvp : MaterialCacheKeys)
	{
		InitPerMeshMaterialCacheStack(ActorPtr, Kvp.Key, Kvp.Value, bUseAssetMaterial);
	}
}

void FKGMaterialCacheController::InitPerMeshMaterialCacheStack(
	TWeakObjectPtr<AActor> ActorPtr, TWeakObjectPtr<UMeshComponent> MeshComponentPtr, const TArray<KGMaterialCacheKey>& MaterialCacheKeys, bool bUseAssetMaterial)
{
	SCOPED_NAMED_EVENT(FKGMaterialCacheController_InitPerMeshMaterialCacheStack, FColor::Red);
	
	if (!ActorPtr.IsValid())
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialCacheSet::InitPerMeshMaterialCacheStack, invalid actor"));
		return;
	}

	AActor* Actor = ActorPtr.Get();
	if (!MeshComponentPtr.IsValid())
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialCacheSet::InitPerMeshMaterialCacheStack, invalid mesh component %s"), *GetNameSafe(Actor));
		return;
	}
	UMeshComponent* MeshComponent = MeshComponentPtr.Get();
	auto& MeshComponents = MeshComponentCaches.FindOrAdd(ActorPtr.KGGetObjectID());
	MeshComponents.Add(MeshComponentPtr);

	auto& MaterialCacheStacks = MaterialCacheSets.FindOrAdd(MeshComponentPtr.KGGetObjectID()).MaterialCacheStacks;
	for (const KGMaterialCacheKey MaterialCacheKey : MaterialCacheKeys)
	{
		if (MaterialCacheStacks.Contains(MaterialCacheKey))
		{
			continue;
		}

		auto& MaterialCacheStack = MaterialCacheStacks.Add(MaterialCacheKey).Items;

		// default material可能为空
		auto& MaterialCacheStackItem = MaterialCacheStack.AddDefaulted_GetRef();
		MaterialCacheStackItem.bIsDefaultMaterial = true;
		// 确保default material一直在材质栈的最底部, 优先级一直给-1
		MaterialCacheStackItem.Priority = -1;

		/**
		 * 原始预期是所有mesh变化(AddMesh/DeleteMesh/MeshAssetChange)以后, 外部直接调用RefreshAllMaterialCaches来刷新材质参数, 但是存在以下问题
		 * #149750 【Bug】【变身】变身恢复后，材质残留
		 * 对于变身过程中的材质表现(小丑变回角色存在溶解效果), 目前的流程是先溶解(可选), 接着切换mesh asset, 最后调用refresh all material caches(此时会先执行ClearMaterialCacheSet)
		 * 溶解之前由于角色本身没有构建材质栈缓存, 那么此时构建的材质栈缓存用的是小丑的材质, 当最后refresh all material caches, 清理所有材质栈并默认回退到default材质时, 此时发现默认材质
		 * 是小丑的材质, 会导致变回角色时扔保留小丑的材质
		 * 
		 * 对于上述bug, 考虑的解决思路是对于变身流程 refresh all material caches时, 不回退到默认材质, 但是这样也存在问题
		 * 这是因为如果不回退到默认材质的话, refresh all material caches执行完ClearMaterialCacheSet后, 角色身上还是动态材质(Dissolve材质, 角色此时正在执行溶解效果), 此时紧跟着执行
		 * ChangeMaterialRequest和ChangeMaterialParamRequest的应用逻辑, 此时会拿到角色当前材质为Dissolve材质, 并以Dissolve材质作为default材质
		 *
		 * 如果ClearMaterialCacheSet后在不fallback to default material的情况下调用EmptyOverrideMaterials会出现以下问题
		 * 对于NPC的外观组装来说, 外观这边会拿到dynamic material instance直接设置外观相关材质参数, 设置完以后紧接着会调用一次
		 * RefreshAllMaterialCaches, 这个时候调用EmptyOverrideMaterials会把动态材质也清理掉, 导致NPC外观变为默认外观
		 * 因此, 这里总是优先尝试拿 mesh asset对应的material
		 *
		 * 20250605 对于观众技能用到的BPEffect来说, 表现目前是在蓝图中配置的, 目前有两个蓝图(A和B), 两个蓝图会引用同一个static mesh, 预期上是希望引用关系是
		 * BP_A -> StaticMesh -> MaterialA
		 * BP_B -> StaticMesh -> MaterialB
		 * 但是StaticMesh上只能有一个默认材质, 为了不复制StaticMesh, 目前是将 MaterialA和MaterialB都设置到 BP上
		 * 因此如果这里读的是mesh asset上的material, 总是拿到的是错误的材质, 鉴于已经在MeshAsset变化时会重新构建材质栈缓存, 其实这里可以直接拿当前材质使用
		 */
		UMaterialInterface* CurMaterialInstance;
		if (bUseAssetMaterial)
		{
			CurMaterialInstance = KGMaterialUtils::GetDefaultMaterialInstanceByMaterialCacheKey(MeshComponent, MaterialCacheKey);
		}
		else
		{
			CurMaterialInstance = KGMaterialUtils::GetMaterialInstanceByMaterialCacheKey(MeshComponent, MaterialCacheKey);
		}
		
		UE_LOG(LogKGMaterial, Log,
			TEXT("FKGMaterialCacheSet::InitPerMeshMaterialCacheStack, actor %s, mesh component %s, mesh asset %s, material cache key %lld, "
				"default material %s(%d)"),
			*GetNameSafe(Actor), *GetNameSafe(MeshComponent), *KGMaterialUtils::GetMeshAssetNameDebugUsage(MeshComponent),
			MaterialCacheKey, *KGMaterialUtils::GetMaterialInfoDebugUsage(CurMaterialInstance), bUseAssetMaterial);
		
		if (CurMaterialInstance == nullptr)
		{
			return;
		}
		
		UMaterialInstanceDynamic* NewMaterialInstanceDynamic;
		if (UMaterialInstanceDynamic* CurMaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(CurMaterialInstance))
		{
			if (CurMaterialInstanceDynamic->Parent == nullptr)
			{
				UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialCacheSet::InitPerMeshMaterialCacheStack, material instance dynamic parent is null, %s, %lld, %s"),
					*GetNameSafe(MeshComponent), MaterialCacheKey, *KGMaterialUtils::GetMaterialInfoDebugUsage(CurMaterialInstance));
				return;
			}
			MaterialCacheStackItem.MaterialInterface = CurMaterialInstanceDynamic->Parent;
			NewMaterialInstanceDynamic = CurMaterialInstanceDynamic;
		}
		else
		{
			NewMaterialInstanceDynamic = KGMaterialUtils::CreateDynamicMaterialInstance(CurMaterialInstance);
			MaterialCacheStackItem.MaterialInterface = CurMaterialInstance;
			KGMaterialUtils::SetMaterialInstanceByMaterialCacheKey(MeshComponent, NewMaterialInstanceDynamic, MaterialCacheKey);
		}

		if (KGMaterialManager.IsValid())
		{
			KGMaterialUtils::SetDynamicMaterialInstanceCharacterHeightInfo(
				MeshComponent, NewMaterialInstanceDynamic, KGMaterialManager->GetCharacterHeightParamName(), false);
		}
	}
}

void FKGMaterialCacheController::ClearAllMaterialCaches(KGObjectID ActorID)
{
	if (!MeshComponentCaches.Contains(ActorID))
	{
		return;
	}

	auto MeshComponents = MeshComponentCaches[ActorID];
	for (auto MeshComponent : MeshComponents)
	{
		ClearMaterialCacheSet(ActorID, MeshComponent);
	}

	MeshComponentCaches.Remove(ActorID);
}

void FKGMaterialCacheController::ClearMaterialCacheSet(
	KGObjectID ActorID, TWeakObjectPtr<UMeshComponent> MeshComponentPtr)
{
	UE_LOG(LogKGMaterial, Log, TEXT("FKGMaterialCacheController::ClearMaterialCacheSet, actor: %s, mesh component: %s"),
		*GetNameSafe(KGUtils::GetObjectByID(ActorID)), *GetNameSafe(MeshComponentPtr.Get()));
	
	const auto MeshCompID = MeshComponentPtr.KGGetObjectID();
	if (MaterialCacheSets.Contains(MeshCompID))
	{
		MaterialCacheSets.Remove(MeshCompID);
	}

	if (MeshComponentCaches.Contains(ActorID) && MeshComponentCaches[ActorID].Contains(MeshComponentPtr))
	{
		MeshComponentCaches[ActorID].Remove(MeshComponentPtr);
	}
}

void FKGMaterialCacheController::ClearNonDefaultMaterialCaches(TWeakObjectPtr<AActor> ActorPtr)
{
	const auto ActorID = ActorPtr.KGGetObjectID();
	if (!MeshComponentCaches.Contains(ActorID))
	{
		return;
	}
	
	UE_LOG(LogKGMaterial, Log, TEXT("FKGMaterialCacheController::ClearNonDefaultMaterialCaches, actor: %s"),
		*GetNameSafe(ActorPtr.Get()));

	auto MeshComponents = MeshComponentCaches[ActorID];
	for (auto MeshComponentPtr : MeshComponents)
	{
		if (auto* MaterialCacheSetPtr = MaterialCacheSets.Find(MeshComponentPtr.KGGetObjectID()))
		{
			if (MeshComponentPtr.IsValid())
			{
				UE_LOG(LogKGMaterial, Log,
					TEXT("FKGMaterialCacheController::ClearNonDefaultMaterialCaches, mesh component is valid, remove all non default material cache, actor: %s, mesh component: %s"),
					*GetNameSafe(ActorPtr.Get()), *GetNameSafe(MeshComponentPtr.Get()));
				for (auto& Kvp : MaterialCacheSetPtr->MaterialCacheStacks)
				{
					auto& MaterialCacheStack = Kvp.Value.Items;
					if (MaterialCacheStack.Num() > 1)
					{
						MaterialCacheStack.RemoveAt(0, MaterialCacheStack.Num() - 1);
						
						UE_CLOG(!MaterialCacheStack[0].bIsDefaultMaterial, LogKGMaterial, Error,
							TEXT("FKGMaterialCacheController::ClearNonDefaultMaterialCaches, expect default material cache in stack, actor: %s, mesh component: %s, material cache key: %lld"),
							*GetNameSafe(ActorPtr.Get()), *GetNameSafe(MeshComponentPtr.Get()), Kvp.Key);
					}
				}
			}
			else
			{
				UE_LOG(LogKGMaterial, Log,
					TEXT("FKGMaterialCacheController::ClearNonDefaultMaterialCaches, mesh component is invalid, clear component cache, actor: %s"),
					*GetNameSafe(ActorPtr.Get()));
				ClearMaterialCacheSet(ActorID, MeshComponentPtr);
			}
		}
	}
}

void FKGMaterialCacheController::ClearAllMaterialCachesAndFallbackToDefaultMaterial(KGObjectID ActorID)
{
	if (!MeshComponentCaches.Contains(ActorID))
	{
		return;
	}

	const auto& MeshComponents = MeshComponentCaches[ActorID];
	for (auto MeshComponent : MeshComponents)
	{
		if (!MeshComponent.IsValid())
		{
			continue;
		}
		
		const auto MeshCompID = MeshComponent.KGGetObjectID();
		auto* MaterialCacheSetPtr = MaterialCacheSets.Find(MeshCompID);
		if (MaterialCacheSetPtr == nullptr)
		{
			continue;
		}

		const auto& MaterialCacheStacks = MaterialCacheSetPtr->MaterialCacheStacks;
		for (const auto& Kvp : MaterialCacheStacks)
		{
			const auto& MaterialCacheKey = Kvp.Key;
			const auto& MaterialCacheStack = Kvp.Value.Items;
			if (MaterialCacheStack.Num() == 0)
			{
				continue;
			}
			
			auto& DefaultMaterialCacheItem = MaterialCacheStack.Last();
			KGMaterialUtils::SetMaterialInstanceByMaterialCacheKey(
				MeshComponent.Get(), DefaultMaterialCacheItem.MaterialInterface, MaterialCacheKey);
		}

		MaterialCacheSets.Remove(MeshCompID);
	}

	MeshComponentCaches.Remove(ActorID);
}

void FKGMaterialCacheController::AddMaterialCacheStackItems(FKGChangeMaterialContext& InOutChangeMaterialContext)
{
	SCOPED_NAMED_EVENT(UKGMaterialManager_AddMaterialCacheStackItems, FColor::Red);
	
	for (const auto& Kvp : InOutChangeMaterialContext.MaterialCacheKeyMapping)
	{
		if (!InOutChangeMaterialContext.MaterialInterface)
		{
			UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialCacheController::AddPerMeshMaterialCacheStackItems, invalid material interface, %s"),
				*InOutChangeMaterialContext.ToString());
			return;
		}

		AddPerMeshMaterialCacheItems(InOutChangeMaterialContext, Kvp.Key, Kvp.Value);
	}
}

void FKGMaterialCacheController::AddPerMeshMaterialCacheItems(
	FKGChangeMaterialContext& InOutChangeMaterialContext, TWeakObjectPtr<UMeshComponent> MeshComponentPtr, const TArray<KGMaterialCacheKey>& MaterialCacheKeys)
{
	if (!MeshComponentPtr.IsValid())
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialCacheController::AddPerMeshMaterialCacheItems, invalid mesh component, %s"),
			*InOutChangeMaterialContext.ToString());
		return;
	}

	auto* MaterialCacheSetPtr = MaterialCacheSets.Find(MeshComponentPtr.KGGetObjectID());
	if (!MaterialCacheSetPtr)
	{
		UE_LOG(LogKGMaterial, Error,
			TEXT("FKGMaterialCacheController::AddPerMeshMaterialCacheItems, cannot find mesh component in material cache, mesh component: %s, %s"),
			*GetNameSafe(MeshComponentPtr.Get()), *InOutChangeMaterialContext.ToString());
		return;
	}

	const auto& ChangeMaterialRequest = InOutChangeMaterialContext.ChangeMaterialRequest;
	for (const auto MaterialCacheKey : MaterialCacheKeys)
	{
		auto* MaterialCacheStackPtr = MaterialCacheSetPtr->MaterialCacheStacks.Find(MaterialCacheKey);
		if (MaterialCacheStackPtr == nullptr)
		{
			UE_LOG(LogKGMaterial, Error,
				TEXT("FKGMaterialCacheController::AddPerMeshMaterialCacheItems, cannot find material cache stack, mesh component: %s, MaterialCacheKey: %lld, %s"),
				*GetNameSafe(MeshComponentPtr.Get()), MaterialCacheKey, *InOutChangeMaterialContext.ToString());
			continue;
		}

		auto& MaterialCacheStack = MaterialCacheStackPtr->Items;
		UMaterialInterface* OldEffectiveMaterialInterface = nullptr;
		uint32 OldReqID = 0;
		UMaterialInterface* DefaultMaterial = nullptr;
		if (MaterialCacheStack.Num() > 0)
		{
			OldEffectiveMaterialInterface = MaterialCacheStack[0].MaterialInterface;
			OldReqID = MaterialCacheStack[0].ReqId;
			DefaultMaterial = MaterialCacheStack.Last().MaterialInterface;
		}
		else
		{
			UE_LOG(LogKGMaterial, Error,
				TEXT("FKGMaterialCacheController::AddPerMeshMaterialCacheItems, material cache stack should not be empty, mesh component: %s, MaterialCacheKey: %lld, %s"),
				*GetNameSafe(MeshComponentPtr.Get()), MaterialCacheKey, *InOutChangeMaterialContext.ToString());
		}
		
		if (!CanMaterialTakeEffect(InOutChangeMaterialContext, MeshComponentPtr, MaterialCacheKey, DefaultMaterial))
		{
			continue;
		}

		UE_CLOG(MaterialCacheStack.Num() > KG_MAX_MATERIAL_CACHE_STACK_NUM, LogKGMaterial, Error,
			TEXT("FKGMaterialCacheController::AddPerMeshMaterialCacheItems, material cache stack over limit %s"),
			*FString::JoinBy(MaterialCacheStack, TEXT(", "), [](const FKGMaterialCacheStackItem& Item)
			{
				return FString::Printf(TEXT("Material: %s"), *GetPathNameSafe(Item.MaterialInterface));
			}));

		FKGMaterialCacheStackItem MaterialCacheStackItem;
		MaterialCacheStackItem.Priority = ChangeMaterialRequest.Priority;
		MaterialCacheStackItem.SequenceId = InOutChangeMaterialContext.SequenceId;
		MaterialCacheStackItem.ReqId = InOutChangeMaterialContext.ReqId;
		MaterialCacheStackItem.MaterialInterface = InOutChangeMaterialContext.MaterialInterface;
		
		MaterialCacheStack.Add(MaterialCacheStackItem);
		if (MaterialCacheStack.Num() > 1)
		{
			Algo::Sort(MaterialCacheStack);
		}

		UMaterialInterface* NewEffectiveMaterialInterface = MaterialCacheStack[0].MaterialInterface;
		const uint32 NewReqID = MaterialCacheStack[0].ReqId;

		UE_LOG(LogKGMaterial, Log,
			TEXT("FKGMaterialCacheController::AddPerMeshMaterialCacheItems, actor: %s, mesh: %s, material cache key: %lld, old: %s, new: %s, %s"),
			*GetNameSafe(ChangeMaterialRequest.OwnerActor.Get()), *GetNameSafe(MeshComponentPtr.Get()),
			MaterialCacheKey, *KGMaterialUtils::GetMaterialInfoDebugUsage(OldEffectiveMaterialInterface),
			 *KGMaterialUtils::GetMaterialInfoDebugUsage(NewEffectiveMaterialInterface), *InOutChangeMaterialContext.ToString());
		
		if (OldEffectiveMaterialInterface != NewEffectiveMaterialInterface)
		{
			UMaterialInstanceDynamic* OldMaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(
			KGMaterialUtils::GetMaterialInstanceByMaterialCacheKey(MeshComponentPtr.Get(), MaterialCacheKey));
	
			if (!OldMaterialInstanceDynamic)
			{
				InOutChangeMaterialContext.bNeedRefreshMaterialParamReq = true;
			}
			
			KGMaterialUtils::ChangeMaterialParent(MeshComponentPtr.Get(), NewEffectiveMaterialInterface, MaterialCacheKey);

			UMaterialInstanceDynamic* NewMaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(
				KGMaterialUtils::GetMaterialInstanceByMaterialCacheKey(MeshComponentPtr.Get(), MaterialCacheKey));
			
			if (KGMaterialManager.IsValid() && OldMaterialInstanceDynamic)
			{
				KGMaterialManager->UpdateDynamicMaterialInstance(OldMaterialInstanceDynamic, NewMaterialInstanceDynamic);
			}

			UpdateInheritedMaterialParams(NewMaterialInstanceDynamic, MeshComponentPtr, MaterialCacheKey, OldReqID, NewReqID);
		}
	}
}

void FKGMaterialCacheController::RemoveMaterialCacheStackItems(const FKGChangeMaterialContext& ChangeMaterialContext)
{
	for (const auto& Kvp : ChangeMaterialContext.MaterialCacheKeyMapping)
	{
		auto MeshComponentPtr = Kvp.Key;
		if (!MeshComponentPtr.IsValid())
		{
			// sequence中使用材质管理器不会通知新增或者删除mesh component, 这里日志等级调整为warning
			UE_LOG(LogKGMaterial, Warning, TEXT("FKGMaterialCacheController::RemoveMaterialCacheStackItems, invalid mesh component, %s"),
				*ChangeMaterialContext.ToString());
			continue;
		}
		
		auto* MaterialCacheSetPtr = MaterialCacheSets.Find(MeshComponentPtr.KGGetObjectID());
		if (!MaterialCacheSetPtr)
		{
			UE_LOG(LogKGMaterial, Error,
				TEXT("FKGMaterialCacheController::RemoveMaterialCacheStackItems, cannot find mesh component in material cache, mesh component: %s, %s"),
				*GetNameSafe(MeshComponentPtr.Get()), *ChangeMaterialContext.ToString());
			continue;
		}

		auto& MaterialCacheStacks = MaterialCacheSetPtr->MaterialCacheStacks;
		const auto& MaterialCacheKeys = Kvp.Value;
		for (const auto MaterialCacheKey : MaterialCacheKeys)
		{
			auto* MaterialCacheStackPtr = MaterialCacheStacks.Find(MaterialCacheKey);
			if (MaterialCacheStackPtr == nullptr)
			{
				UE_LOG(LogKGMaterial, Error,
					TEXT("FKGMaterialCacheController::RemoveMaterialCacheStackItems, cannot find material cache stack, mesh component: %s, MaterialCacheKey: %lld, %s"),
					*GetNameSafe(MeshComponentPtr.Get()), MaterialCacheKey, *ChangeMaterialContext.ToString());
				continue;
			}

			auto& MaterialCacheStack = MaterialCacheStackPtr->Items;
			if (MaterialCacheStack.Num() == 0)
			{
				UE_LOG(LogKGMaterial, Error,
					TEXT("FKGMaterialCacheController::RemoveMaterialCacheStackItems, material cache stack should not be empty, mesh component: %s, MaterialCacheKey: %lld, %s"),
					*GetNameSafe(MeshComponentPtr.Get()), MaterialCacheKey, *ChangeMaterialContext.ToString());
				continue;
			}

			UMaterialInterface* OldEffectiveMaterialInterface = MaterialCacheStack[0].MaterialInterface;
			const uint32 OldReqID = MaterialCacheStack[0].ReqId;
			for (int32 i = 0; i < MaterialCacheStack.Num(); ++i)
			{
				if (MaterialCacheStack[i].SequenceId == ChangeMaterialContext.SequenceId)
				{
					MaterialCacheStack.RemoveAtSwap(i);
					break;
				}
			}
			
			if (MaterialCacheStack.Num() > 1)
			{
				Algo::Sort(MaterialCacheStack);
			}

			// 栈中至少要保留一个default材质，不可能为空
			if (MaterialCacheStack.Num() == 0)
			{
				UE_LOG(LogKGMaterial, Error,
					TEXT("FKGMaterialCacheController::RemoveMaterialCacheStackItems, material cache stack missing default material, mesh component: %s, MaterialCacheKey: %lld, %s"),
					*GetNameSafe(MeshComponentPtr.Get()), MaterialCacheKey, *ChangeMaterialContext.ToString());
				continue;
			}
			
			UMaterialInterface* NewEffectiveMaterialInterface = MaterialCacheStack[0].MaterialInterface;
			const uint32 NewReqID = MaterialCacheStack[0].ReqId;
			UE_LOG(LogKGMaterial, Log,
				TEXT("FKGMaterialCacheController::RemoveMaterialCacheStackItems, actor: %s, mesh component: %s, material cache key: %lld, old: %s, new: %s, %s"),
				*GetNameSafe(ChangeMaterialContext.ChangeMaterialRequest.OwnerActor.Get()), *GetNameSafe(MeshComponentPtr.Get()),
				MaterialCacheKey, *KGMaterialUtils::GetMaterialInfoDebugUsage(OldEffectiveMaterialInterface),
				*KGMaterialUtils::GetMaterialInfoDebugUsage(NewEffectiveMaterialInterface), *ChangeMaterialContext.ToString());
			
			if (NewEffectiveMaterialInterface != OldEffectiveMaterialInterface)
			{
				UMaterialInstanceDynamic* OldMaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(
					KGMaterialUtils::GetMaterialInstanceByMaterialCacheKey(MeshComponentPtr.Get(), MaterialCacheKey));
				
				if (NewEffectiveMaterialInterface == nullptr)
				{
					KGMaterialUtils::SetMaterialInstanceByMaterialCacheKey(MeshComponentPtr.Get(), nullptr, MaterialCacheKey);
				}
				else
				{
					KGMaterialUtils::ChangeMaterialParent(MeshComponentPtr.Get(), NewEffectiveMaterialInterface, MaterialCacheKey);	
				}

				UMaterialInstanceDynamic* NewMaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(
					KGMaterialUtils::GetMaterialInstanceByMaterialCacheKey(MeshComponentPtr.Get(), MaterialCacheKey));
				
				if (KGMaterialManager.IsValid() && OldMaterialInstanceDynamic)
				{
					KGMaterialManager->UpdateDynamicMaterialInstance(OldMaterialInstanceDynamic, NewMaterialInstanceDynamic);
				}

				UpdateInheritedMaterialParams(NewMaterialInstanceDynamic, MeshComponentPtr, MaterialCacheKey, OldReqID, NewReqID);
			}
		}
	}
}

bool FKGMaterialCacheController::CanMaterialTakeEffect(
	FKGChangeMaterialContext& InOutChangeMaterialContext, TWeakObjectPtr<UMeshComponent> MeshComponentPtr, KGMaterialCacheKey MaterialCacheKey,
	UMaterialInterface* DefaultMaterial)
{
	auto& EffectiveParentMaterialNames = InOutChangeMaterialContext.ChangeMaterialRequest.EffectiveParentMaterialNames;
	if (EffectiveParentMaterialNames.Num() == 0)
	{
		return true;
	}

	if (!MeshComponentPtr.IsValid())
	{
		return false;
	}
	
	if (!KGMaterialManager.IsValid())
	{
		return false;
	}
	
	UMaterialInstance* CurrentMI = Cast<UMaterialInstance>(DefaultMaterial);
	if (CurrentMI == nullptr)
	{
		// overlay material无底材质, parent为空
		return true;
	}
	
	FName MaterialSlotName;
	if (!KGMaterialUtils::GetSlotNameByMaterialCacheKey(MeshComponentPtr.Get(), MaterialCacheKey, MaterialSlotName))
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialCacheController::CanMaterialTakeEffect, cannot find material slot name by material cache key %s, %lld"),
			*MeshComponentPtr->GetName(), MaterialCacheKey);
		return false;
	}
	
	auto* ParentMaterialNamesPtr = EffectiveParentMaterialNames.Find(MaterialSlotName);
	if (ParentMaterialNamesPtr == nullptr)
	{
		return true;
	}
	
	int32 CurIterNum = 0;
	const int32 MaxIterNum = KGMaterialManager->GetMaxParentMaterialCheckNum();
	while (CurIterNum < MaxIterNum && CurrentMI)
	{
		CurIterNum++;
		
		// 这里目前比较的是材质的名称, 跟TA讨论过以下方案
		// 1) 比较材质路径，但是根据UObject获取材质路径需要字符串拼接, 开销比较高, 不可取
		// 2) 比较材质UObject, 这个需要长时间持有 parent material资产(不卸载), 会有一定内存额外开销
		// 3) 仅比较名字, 因为现在MR材质都是TA自己维护的, 所以重名概率不高, 后续补一个资源检查基本不会有问题(目前采用的是这个方案)
		const auto& CurrentMIName = CurrentMI->GetFName();
		if (ParentMaterialNamesPtr->Contains(CurrentMIName))
		{
			UE_LOG(LogKGMaterial, Log, TEXT("FKGMaterialCacheController::CanMaterialTakeEffect, material (%s, %lld, %s) use parent material %s, valid to change material"), 
				*MeshComponentPtr->GetName(), MaterialCacheKey, *DefaultMaterial->GetPathName(), *CurrentMIName.ToString());
			return true;
		}
		
		CurrentMI = Cast<UMaterialInstance>(CurrentMI->Parent);
	}

	UE_LOG(LogKGMaterial, Log, TEXT("FKGMaterialCacheController::CanMaterialTakeEffect, material (%s, %lld, %s) cannot find valid parent material"), 
		*MeshComponentPtr->GetName(), MaterialCacheKey, *DefaultMaterial->GetPathName());
	return false;
}

void FKGMaterialCacheController::UpdateInheritedMaterialParams(
	UMaterialInstanceDynamic* NewMID, TWeakObjectPtr<UMeshComponent> MeshComponentPtr, KGMaterialCacheKey MaterialCacheKey, uint32 OldReqID, uint32 NewReqID)
{
	// 雨水材质生效时, 需要将当前default材质上的材质参数拷贝到雨水材质对应的MID上
	// 相应地, 雨水材质被其他材质覆盖时, 相应继承来的材质参数需要清理, 直到雨水材质再次生效时才能再次继承相应材质参数
	SCOPED_NAMED_EVENT(FKGMaterialCacheController_UpdateInheritedMaterialParams, FColor::Red);
	if (!NewMID)
	{
		return;
	}

	if (!MeshComponentPtr.IsValid())
	{
		return;
	}
	UMeshComponent* MeshComponent = MeshComponentPtr.Get();

	auto* RoleCompositeParamCachePtr = KGMaterialManager->GetRoleCompositeParamCachePtr(MeshComponent, MaterialCacheKey);

	BATCH_DMIPARAM_SCOPE(NewMID);
	if (auto* OldChangeMaterialContextPtr = KGMaterialManager->GetChangeMaterialContextPtr(OldReqID))
	{
		const auto& OldChangeMaterialRequest = OldChangeMaterialContextPtr->ChangeMaterialRequest;
		for (auto& ParamName : OldChangeMaterialRequest.ScalarParamsInheritFromDefaultMaterial)
		{
			if (RoleCompositeParamCachePtr == nullptr ||
				!RoleCompositeParamCachePtr->ScalarParams.Contains(ParamName))
			{
				NewMID->RemoveGameScalarParameter(ParamName);
			}
			else
			{
				UE_LOG(LogKGMaterial, Log, 
					TEXT("FKGMaterialCacheController::UpdateInheritedMaterialParams, remove inherit scalar param,  %s found in role composite param cache"),
					*ParamName.ToString());
			}
		}
		for (auto& ParamName : OldChangeMaterialRequest.VectorParamsInheritFromDefaultMaterial)
		{
			if (RoleCompositeParamCachePtr == nullptr ||
				!RoleCompositeParamCachePtr->VectorParams.Contains(ParamName))
			{
				NewMID->RemoveGameVectorParameter(ParamName);	
			}
			else
			{
				UE_LOG(LogKGMaterial, Log, 
					TEXT("FKGMaterialCacheController::UpdateInheritedMaterialParams, remove inherit vector param %s found in role composite param cache"),
					*ParamName.ToString());
			}
		}
		for (auto& ParamName : OldChangeMaterialRequest.TextureParamsInheritFromDefaultMaterial)
		{
			if (RoleCompositeParamCachePtr == nullptr ||
				!RoleCompositeParamCachePtr->TextureParams.Contains(ParamName))
			{
				NewMID->RemoveGameTextureParameter(ParamName);	
			}
			else
			{
				UE_LOG(LogKGMaterial, Log, 
					TEXT("FKGMaterialCacheController::UpdateInheritedMaterialParams, remove inherit texture param %s found in role composite param cache"),
					*ParamName.ToString());
			}
		}
	}
	
	if (auto* NewChangeMaterialContextPtr = KGMaterialManager->GetChangeMaterialContextPtr(NewReqID))
	{
		const auto& NewChangeMaterialRequest = NewChangeMaterialContextPtr->ChangeMaterialRequest;
		if (NewChangeMaterialRequest.ScalarParamsInheritFromDefaultMaterial.Num() > 0 ||
			NewChangeMaterialRequest.VectorParamsInheritFromDefaultMaterial.Num() > 0 ||
			NewChangeMaterialRequest.TextureParamsInheritFromDefaultMaterial.Num() > 0)
		{
			if (UMaterialInterface* DefaultMaterial = GetDefaultMaterial(MeshComponentPtr.Get(), MaterialCacheKey))
			{
				for (auto& ParamName : NewChangeMaterialRequest.ScalarParamsInheritFromDefaultMaterial)
				{
					if (RoleCompositeParamCachePtr && RoleCompositeParamCachePtr->ScalarParams.Contains(ParamName))
					{
						UE_LOG(LogKGMaterial, Log, 
							TEXT("FKGMaterialCacheController::UpdateInheritedMaterialParams, set inherit scalar param %s found in role composite param cache"),
							*ParamName.ToString());
						continue;
					}
					
					float ParamValue;
					if (DefaultMaterial->GetScalarParameterValue(ParamName, ParamValue))
					{
						NewMID->SetGameScalarParameterValue(ParamName, ParamValue);
					}
				}
				for (auto& ParamName : NewChangeMaterialRequest.VectorParamsInheritFromDefaultMaterial)
				{
					if (RoleCompositeParamCachePtr && RoleCompositeParamCachePtr->VectorParams.Contains(ParamName))
					{
						UE_LOG(LogKGMaterial, Log, 
							TEXT("FKGMaterialCacheController::UpdateInheritedMaterialParams, set inherit vector param %s found in role composite param cache"),
							*ParamName.ToString());
						continue;
					}
					
					FLinearColor ParamValue;
					if (DefaultMaterial->GetVectorParameterValue(ParamName, ParamValue))
					{
						NewMID->SetGameVectorParameterValue(ParamName, ParamValue);
					}
				}
				for (auto& ParamName : NewChangeMaterialRequest.TextureParamsInheritFromDefaultMaterial)
				{
					if (RoleCompositeParamCachePtr && RoleCompositeParamCachePtr->TextureParams.Contains(ParamName))
					{
						UE_LOG(LogKGMaterial, Log, 
                        	TEXT("FKGMaterialCacheController::UpdateInheritedMaterialParams, set inherit texture param %s found in role composite param cache"),
                        	*ParamName.ToString());
						continue;
					}
					
					UTexture* ParamValue;
					if (DefaultMaterial->GetTextureParameterValue(ParamName, ParamValue))
					{
						NewMID->SetGameTextureParameterValue(ParamName, ParamValue);
					}
				}
			}
			else
			{
				UE_LOG(LogKGMaterial, Warning,
					TEXT("FKGMaterialCacheController::UpdateInheritedMaterialParams, default material is null, mesh component: %s, MaterialCacheKey: %lld"),
					*GetNameSafe(MeshComponentPtr.Get()), MaterialCacheKey);
			}
		}
	}
}

void FKGMaterialCacheController::ChangeRuntimeSeparateOverlayMaterial(
	TWeakObjectPtr<AActor> ActorPtr, const TArray<TWeakObjectPtr<UMeshComponent>>& CustomMeshComponents,
	uint32 ChangeMaterialParamReqID, bool bUseCharacterCameraDither, bool bIncludeChildActors,
	bool bIgnoreExcludeMeshComponent, bool bIsCameraDither, bool bUseWorldPivotPosition, bool bNeedAngleThresholdParams)
{
	SCOPED_NAMED_EVENT(FKGMaterialCacheController_ChangeRuntimeSeparateOverlayMaterial, FColor::Red);
	if (!ActorPtr.IsValid())
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("FKGMaterialCacheController::ChangeRuntimeSeparateOverlayMaterial, invalid actor"));
		return;
	}

	const auto ActorID = ActorPtr.KGGetObjectID();
	if (RuntimeSeparateOverlayMaterialInfos.Contains(ActorID))
	{
		if (ChangeMaterialParamReqID != 0)
		{
			RuntimeSeparateOverlayMaterialInfos[ActorID].ChangeMaterialParamReqIDs.Add(ChangeMaterialParamReqID);
		}
		
		if (bUseCharacterCameraDither || CustomMeshComponents.Num() == 0)
		{
			UE_LOG(LogKGMaterial, Log, TEXT("FKGMaterialCacheController::ChangeRuntimeSeparateOverlayMaterial, actor all mesh has replaced OLM"));
			return;
		}
	}

	if (!KGMaterialManager.IsValid())
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialCacheController::ChangeRuntimeSeparateOverlayMaterial, invalid material manager"));
		return;
	}

	UE_LOG(LogKGMaterial, Log, TEXT("FKGMaterialCacheController::ChangeRuntimeSeparateOverlayMaterial, actor: %s, ChangeMaterialParamReqID: %d"),
		*GetNameSafe(ActorPtr.Get()), ChangeMaterialParamReqID);
	
	auto& MaterialInfo = RuntimeSeparateOverlayMaterialInfos.FindOrAdd(ActorID);
	if (ChangeMaterialParamReqID != 0)
	{
		MaterialInfo.ChangeMaterialParamReqIDs.Add(ChangeMaterialParamReqID);
	}
	MaterialInfo.bUseCharacterCameraDither = bUseCharacterCameraDither;
	MaterialInfo.bUseWorldPivotPosition = bUseWorldPivotPosition;
	MaterialInfo.bNeedAngleThresholdParams = bNeedAngleThresholdParams;
	
	// step 1, 将runtime separate overlay材质设置到对应的mesh component上, 并进行default material参数拷贝
	KGMaterialCacheKeyMapping NewMaterialCacheKeyMapping;
	if (bUseCharacterCameraDither || CustomMeshComponents.Num() == 0)
	{
		KGMaterialManager->GetAllAffectedMaterialCacheKeysByActor(
			ActorPtr.Get(), bIncludeChildActors, bIgnoreExcludeMeshComponent, bIsCameraDither,
			KGMaterialManager->GetCameraDitherExcludeMeshTags(), NewMaterialCacheKeyMapping);	
	}
	else
	{
		static TArray<FName> EmptyMaterialSlotNames;
		KGMaterialManager->GetAffectedMaterialCacheKeys(
			ActorPtr.Get(), EKGSearchMeshType::UseCustomMeshComps, NAME_None, CustomMeshComponents,
			KGMaterialManager->GetCameraDitherExcludeMeshTags(), EKGSearchMaterialType::SearchAllNormalMaterial,
			EmptyMaterialSlotNames, bIgnoreExcludeMeshComponent, bIsCameraDither, NewMaterialCacheKeyMapping);
	}

	KGMaterialCacheKeyMapping TempMaterialCacheKeyMapping(NewMaterialCacheKeyMapping);
	for (const auto& Kvp : TempMaterialCacheKeyMapping)
	{
		const auto& MeshComponentPtr = Kvp.Key;
		if (MaterialInfo.MaterialCacheKeyMapping.Contains(MeshComponentPtr))
		{
			NewMaterialCacheKeyMapping.Remove(MeshComponentPtr);
		}
		else
		{
			MaterialInfo.MaterialCacheKeyMapping.Add(MeshComponentPtr, Kvp.Value);
		}
	}

	if (NewMaterialCacheKeyMapping.Num() == 0)
	{
		UE_LOG(LogKGMaterial, Log,
			TEXT("FKGMaterialCacheController::ChangeRuntimeSeparateOverlayMaterial, no new mesh component need to replace OLM, %s"),
			*GetNameSafe(ActorPtr.Get()));
		return;
	}
	
	InternalChangeRuntimeSeparateOverlayMaterial(
		ActorPtr, NewMaterialCacheKeyMapping, bUseCharacterCameraDither, bIsCameraDither, bUseWorldPivotPosition, bNeedAngleThresholdParams);

	// step 3, 关闭groom
	if (UFaceControlComponent* FaceControlComponent = ActorPtr->FindComponentByClass<UFaceControlComponent>())
	{
		FaceControlComponent->SetDisableGroom(EKGEnableGroomReason::OLM, true);
	}
}

void FKGMaterialCacheController::ChangeRuntimeSeparateOverlayMaterialOnAddMeshComponent(TWeakObjectPtr<AActor> ActorPtr, TWeakObjectPtr<UMeshComponent> MeshComponent)
{
	SCOPED_NAMED_EVENT(FKGMaterialCacheController_ChangeRuntimeSeparateOverlayMaterialOnAddMeshComponent, FColor::Red);
	if (!ActorPtr.IsValid())
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("FKGMaterialCacheController::ChangeRuntimeSeparateOverlayMaterialOnAddMeshComponent, invalid actor"));
		return;
	}

	if (!MeshComponent.IsValid())
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("FKGMaterialCacheController::ChangeRuntimeSeparateOverlayMaterialOnAddMeshComponent, invalid mesh component"));
		return;
	}

	const auto ActorID = ActorPtr.KGGetObjectID();
	if (!RuntimeSeparateOverlayMaterialInfos.Contains(ActorID))
	{
		UE_LOG(LogKGMaterial, Log,
			TEXT("FKGMaterialCacheController::ChangeRuntimeSeparateOverlayMaterialOnAddMeshComponent, actor has no runtime separate overlay material info, actor: %s"),
			*GetNameSafe(ActorPtr.Get()));
		return;
	}

	auto& MaterialInfo = RuntimeSeparateOverlayMaterialInfos[ActorID];
	if (MaterialInfo.MaterialCacheKeyMapping.Contains(MeshComponent))
	{
		UE_LOG(LogKGMaterial, Log,
			TEXT("FKGMaterialCacheController::ChangeRuntimeSeparateOverlayMaterialOnAddMeshComponent, mesh component has replaced OLM, actor: %s, mesh component: %s"),
			*GetNameSafe(ActorPtr.Get()), *GetNameSafe(MeshComponent.Get()));
		return;
	}

	static TArray<FName> EmptyMaterialSlotNames;
	KGMaterialCacheKeyMapping NewMaterialCacheKeyMapping;
	KGMaterialManager->GetAffectedMaterialCacheKeys(
		ActorPtr.Get(), EKGSearchMeshType::UseCustomMeshComps, NAME_None, { MeshComponent }, KGMaterialManager->GetCameraDitherExcludeMeshTags(),
		EKGSearchMaterialType::SearchAllNormalMaterial, EmptyMaterialSlotNames, true, false, NewMaterialCacheKeyMapping);
	if (!NewMaterialCacheKeyMapping.Contains(MeshComponent))
	{
		UE_LOG(LogKGMaterial, Warning, 
			TEXT("FKGMaterialCacheController::ChangeRuntimeSeparateOverlayMaterialOnAddMeshComponent, cannot find affected material cache keys, actor: %s, mesh component: %s"),
			*GetNameSafe(ActorPtr.Get()), *GetNameSafe(MeshComponent.Get()));
		return;
	}

	InternalChangeRuntimeSeparateOverlayMaterial(
		ActorPtr, NewMaterialCacheKeyMapping, MaterialInfo.bUseCharacterCameraDither, false, MaterialInfo.bUseWorldPivotPosition, MaterialInfo.bNeedAngleThresholdParams);
	MaterialInfo.MaterialCacheKeyMapping.Add(MeshComponent, NewMaterialCacheKeyMapping[MeshComponent]);
}

void FKGMaterialCacheController::RevertRuntimeSeparateOverlayMaterial(TWeakObjectPtr<AActor> ActorPtr, uint32 ChangeMaterialParamReqID, bool bRevertOLM)
{
	const auto ActorID = ActorPtr.KGGetObjectID();
	if (!RuntimeSeparateOverlayMaterialInfos.Contains(ActorID))
	{
		return;
	}

	auto& MaterialInfos = RuntimeSeparateOverlayMaterialInfos[ActorID];
	if (!MaterialInfos.ChangeMaterialParamReqIDs.Contains(ChangeMaterialParamReqID))
	{
		return;
	}

	MaterialInfos.ChangeMaterialParamReqIDs.Remove(ChangeMaterialParamReqID);
	if (MaterialInfos.ChangeMaterialParamReqIDs.Num() > 0)
	{
		// 还有其他的ChangeMaterialParamRequest在等待, 不需要清理
		return;
	}

	UE_LOG(LogKGMaterial, Log, TEXT("FKGMaterialCacheController::RevertRuntimeSeparateOverlayMaterial, actor: %s, ChangeMaterialParamReqID: %d"),
		*GetNameSafe(ActorPtr.Get()), ChangeMaterialParamReqID);
	
	if (bRevertOLM)
	{
		InternalRevertRuntimeSeparateOverlayMaterial(ActorPtr);
	}
	else
	{
		RuntimeSeparateOverlayMaterialInfos.Remove(ActorID);
	}
}

void FKGMaterialCacheController::RevertRuntimeSeparateOverlayMaterialOnRefreshMaterial(TWeakObjectPtr<AActor> ActorPtr)
{
	InternalRevertRuntimeSeparateOverlayMaterial(ActorPtr);
}

void FKGMaterialCacheController::InternalRevertRuntimeSeparateOverlayMaterial(TWeakObjectPtr<AActor> ActorPtr)
{
	const auto ActorID = ActorPtr.KGGetObjectID();
	if (!RuntimeSeparateOverlayMaterialInfos.Contains(ActorID))
	{
		return;
	}

	auto& MaterialInfos = RuntimeSeparateOverlayMaterialInfos[ActorID];
	// 恢复disallow nanite 设置
	for (const auto& Kvp : MaterialInfos.MaterialCacheKeyMapping)
	{
		if (!Kvp.Key.IsValid())
		{
			UE_LOG(LogKGMaterial, Verbose,
				TEXT("FKGMaterialCacheController::RevertRuntimeSeparateOverlayMaterial, revert disable nanite, mesh component is invalid"));
			continue;
		}

		// 尝试清理所有runtime separate overlay材质
		int32 RuntimeSeparateOverlayMaterialNum = Kvp.Key->GetNumRuntimeSeperateOverlayMaterials();
		for (int32 i = 0; i < RuntimeSeparateOverlayMaterialNum; ++i)
		{
			UMaterialInterface* MID = Kvp.Key->GetRuntimeSeperateOverlayMaterial(i);
			FMaterialMIDPool::Get().Release(MID);
			Kvp.Key->SetRuntimeSeperateOverlayMaterial(i, nullptr);
		}

		if (UStaticMeshComponent* StaticMeshComponent = Cast<UStaticMeshComponent>(Kvp.Key.Get()))
		{
			// 这里需要设置disallow nanite, 否则会导致nanite mesh无法正确显示
			StaticMeshComponent->SetForceDisableNanite(false);
		}
	}	

	if (ActorPtr.IsValid())
	{
		if (UFaceControlComponent* FaceControlComponent = ActorPtr->FindComponentByClass<UFaceControlComponent>())
		{
			FaceControlComponent->SetDisableGroom(EKGEnableGroomReason::OLM, false);
		}
	}
	
	RuntimeSeparateOverlayMaterialInfos.Remove(ActorID);
}

void FKGMaterialCacheController::InternalChangeRuntimeSeparateOverlayMaterial(TWeakObjectPtr<AActor> ActorPtr,
	const KGMaterialCacheKeyMapping& NewMaterialCacheKeyMapping, bool bUseCharacterCameraDither, bool bIsCameraDither, bool bUseWorldPivotPosition,
	bool bNeedAngleThresholdParams)
{
	if (!KGMaterialManager.IsValid())
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialCacheController::ChangeRuntimeSeparateOverlayMaterial, invalid material manager"));
		return;
	}
	
	FName AngleThresholdMinParamName = NAME_None, AngleThresholdMaxParamName = NAME_None;
	float AngleThresholdMin = 0.0f, AngleThresholdMax = 0.0f;
	KGMaterialManager->GetCameraDitherAngleInfo(
		AngleThresholdMinParamName, AngleThresholdMin, 
		AngleThresholdMaxParamName, AngleThresholdMax);
	if (!bNeedAngleThresholdParams)
	{
		// 为-1表示不需要启用角度虚化
		AngleThresholdMin = -1.0f;
		AngleThresholdMax = -1.0f;
	}
	
	for (const auto& Kvp : NewMaterialCacheKeyMapping)
	{
		const auto& MeshComp = Kvp.Key;
		if (!MeshComp.IsValid())
		{
			continue;
		}
		
		for (const auto MaterialCacheKey : Kvp.Value)
		{
			UMaterialInstance* DefaultMaterial = Cast<UMaterialInstance>(GetDefaultMaterial(MeshComp.Get(), MaterialCacheKey));
			if (DefaultMaterial == nullptr)
			{
				UE_LOG(LogKGMaterial, Verbose,
					TEXT("FKGMaterialCacheController::ChangeRuntimeSeparateOverlayMaterial, default material is null, mesh component: %s, MaterialCacheKey: %lld"),
					*GetNameSafe(MeshComp.Get()), MaterialCacheKey);
				continue;
			}

			UMaterialInterface* RuntimeSeparateOverlayMaterial = nullptr;
			if (UMaterialInstanceDynamic* DefaultMaterialDynamic = Cast<UMaterialInstanceDynamic>(DefaultMaterial))
			{
				if (UMaterialInstance* ParentMaterial = Cast<UMaterialInstance>(DefaultMaterialDynamic->Parent))
				{
					RuntimeSeparateOverlayMaterial = ParentMaterial->GetOverlayOverride();
				}
			}
			else
			{
				RuntimeSeparateOverlayMaterial = DefaultMaterial->GetOverlayOverride();
			}
			
			UMaterialInstanceDynamic* DynamicMaterialInstance = nullptr;
			bool bDefaultOLM = false;
			if (!RuntimeSeparateOverlayMaterial)
			{
				RuntimeSeparateOverlayMaterial = bUseCharacterCameraDither ? KGMaterialManager->GetCharacterDefaultOLM() : KGMaterialManager->GetEnvDefaultOLM();
				if (RuntimeExcludeOLMBatchCompIDs.Find(ActorPtr.KGGetObjectID()))
				{
					auto& Info = RuntimeExcludeOLMBatchCompIDs[ActorPtr.KGGetObjectID()];
					bDefaultOLM = !Info.Contains(KGUtils::GetIDByObject(MeshComp.Get()));
				}
				else
				{
					bDefaultOLM = true;
				}
			}
			else
			{
				if (RuntimeSeparateOverlayMaterial == KGMaterialManager->GetCharacterDefaultOLM() || RuntimeSeparateOverlayMaterial == KGMaterialManager->GetEnvDefaultOLM())
				{
					bDefaultOLM = true;
				}
			}
			
			if (!RuntimeSeparateOverlayMaterial)
			{
				UE_LOG(LogKGMaterial, Log, TEXT("FKGMaterialCacheController::ChangeRuntimeSeparateOverlayMaterial, empty OLM, origin asset: %s"),
					*DefaultMaterial->GetPathName());
				continue;
			}
			
			UE_LOG(LogKGMaterial, Log,
				TEXT("FKGMaterialCacheController::ChangeRuntimeSeparateOverlayMaterial, actor: %s, mesh component: %s, material cache key: %lld, bUseCharacterCameraDither: %d, bNeedAngleThresholdParams: %d, default material: %s, OLM: %s"),
				*GetNameSafe(ActorPtr.Get()), *GetNameSafe(MeshComp.Get()), MaterialCacheKey, bUseCharacterCameraDither, bNeedAngleThresholdParams,
				*KGMaterialUtils::GetMaterialInfoDebugUsage(DefaultMaterial), *KGMaterialUtils::GetMaterialInfoDebugUsage(RuntimeSeparateOverlayMaterial));
			
			int32 MaterialIndex;
			KGMaterialUtils::GetMaterialIndexByCacheKey(MaterialCacheKey, MaterialIndex);			
			
			if (!bDefaultOLM)
			{
				DynamicMaterialInstance = FMaterialMIDPool::Get().Acquire(RuntimeSeparateOverlayMaterial);// KGMaterialUtils::CreateDynamicMaterialInstance(RuntimeSeparateOverlayMaterial);
				if (!DynamicMaterialInstance)
				{
					UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialCacheController::ChangeRuntimeSeparateOverlayMaterial, dynamic material instance create failed, %s"),
						*KGMaterialUtils::GetMaterialInfoDebugUsage(RuntimeSeparateOverlayMaterial));
					continue;
				}

				{
					SCOPED_NAMED_EVENT(FKGMaterialCacheController_CopyMaterialInstanceParameters, FColor::Red);
					DynamicMaterialInstance->K2_CopyMaterialInstanceParameters(DefaultMaterial, true);
				}
				
				{
					SCOPED_NAMED_EVENT(FKGMaterialCacheController_CopyRoleCompositeParams, FColor::Red);
					CopyRoleCompositeParamsToOLM(MeshComp.Get(), MaterialCacheKey, DynamicMaterialInstance);
				}
			}
			else
			{
				if (bUseCharacterCameraDither)
				{
					auto& MaterialInfo = RuntimeSeparateOverlayMaterialInfos.FindOrAdd(ActorPtr.KGGetObjectID());
					if (MaterialInfo.BaseOverlayMaterial == nullptr)
					{
						MaterialInfo.BaseOverlayMaterial = KGMaterialUtils::CreateDynamicMaterialInstance(KGMaterialManager->GetCharacterDefaultOLM());
					}
					DynamicMaterialInstance = MaterialInfo.BaseOverlayMaterial;
				}
				else
				{
					if (bIsCameraDither)
					{
						if (!Cast<IC7ActorInterface>(ActorPtr))
						{
							DynamicMaterialInstance = KGMaterialManager->GetEnvDefaultMID();
						}
						else
						{
							DynamicMaterialInstance = FMaterialMIDPool::Get().Acquire(RuntimeSeparateOverlayMaterial);
						}
					}						
					else
					{
						DynamicMaterialInstance = KGMaterialUtils::CreateDynamicMaterialInstance(RuntimeSeparateOverlayMaterial); //FMaterialMIDPool::Get().Acquire(RuntimeSeparateOverlayMaterial);
						if (!DynamicMaterialInstance)
						{
							UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialCacheController::ChangeRuntimeSeparateOverlayMaterial, dynamic material instance create failed, %s"),
								*KGMaterialUtils::GetMaterialInfoDebugUsage(RuntimeSeparateOverlayMaterial));
							continue;
						}
					}						
				}
			}

			{
				BATCH_DMIPARAM_SCOPE(DynamicMaterialInstance);
				
				KGMaterialUtils::SetDynamicMaterialInstanceCharacterHeightInfo(
					MeshComp.Get(), DynamicMaterialInstance, KGMaterialManager->GetCharacterHeightParamName(), true);

				DynamicMaterialInstance->SetGameScalarParameterValue(
					KGMaterialManager->GetCameraDitherCharacterTypeParamName(), bUseCharacterCameraDither ? 1.0f : 0.0f);

				DynamicMaterialInstance->SetGameScalarParameterValue(
					KGMaterialManager->GetCameraDitherIfUseWorldSpacePivotPosParamName(), bUseWorldPivotPosition ? 1.0f : 0.0f);

				if (MeshComp->ComponentTags.Contains(KGMaterialManager->GetUseSelfLocationMeshTag()))
				{
					DynamicMaterialInstance->SetGameScalarParameterValue(KGMaterialManager->GetUseActorLocationParamName(), 0.0f);	
				}
				
				DynamicMaterialInstance->SetGameScalarParameterValue(AngleThresholdMinParamName, AngleThresholdMin);
				DynamicMaterialInstance->SetGameScalarParameterValue(AngleThresholdMaxParamName, AngleThresholdMax);
			}
			
			MeshComp->SetRuntimeSeperateOverlayMaterial(MaterialIndex, DynamicMaterialInstance);
		}
	}

	// step 2, 设置mesh component disallow nanite
	for (const auto& Kvp : NewMaterialCacheKeyMapping)
	{
		if (!Kvp.Key.IsValid())
		{
			UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialCacheController::ChangeRuntimeSeparateOverlayMaterial, mesh component is invalid"));
			continue;
		}

		if (UStaticMeshComponent* StaticMeshComponent = Cast<UStaticMeshComponent>(Kvp.Key.Get()))
		{
			// 这里需要设置disallow nanite, 否则会导致nanite mesh无法正确显示
			StaticMeshComponent->SetForceDisableNanite(true);
		}
	}
}

void FKGMaterialCacheController::CopyRoleCompositeParamsToOLM(UMeshComponent* MeshComponent, KGMaterialCacheKey MaterialCacheKey, UMaterialInstanceDynamic* MaterialInstanceDynamic)
{
	if (!IsValid(MeshComponent) || !IsValid(MaterialInstanceDynamic))
	{
		UE_LOG(LogKGMaterial, Error,
			TEXT("FKGMaterialCacheController::CopyRoleCompositeParamsToOLM, invalid mesh component or material instance dynamic"));
		return;
	}
	
	if (!KGMaterialManager.IsValid())
	{
		UE_LOG(LogKGMaterial, Error,
			TEXT("FKGMaterialCacheController::CopyRoleCompositeParamsToOLM, invalid KGMaterialManager"));
		return;
	}
	
	const auto& RoleCompositeParamsCopyToOLM = KGMaterialManager->GetRoleCompositeParamsCopyToOLM();
	
	FName SlotName = NAME_None;
	if (!KGMaterialUtils::GetSlotNameByMaterialCacheKey(MeshComponent, MaterialCacheKey, SlotName))
	{
		return;
	}
	
	auto* RoleCompositeParamsPtr = RoleCompositeParamsCopyToOLM.Find(SlotName);
	if (RoleCompositeParamsPtr == nullptr)
	{
		return;
	}
	
	auto* RoleCompositeParamCachePtr = KGMaterialManager->GetRoleCompositeParamCachePtr(MeshComponent, MaterialCacheKey);
	if (RoleCompositeParamCachePtr == nullptr)
	{
		return;
	}
	
	BATCH_DMIPARAM_SCOPE(MaterialInstanceDynamic);
	if (RoleCompositeParamCachePtr->ScalarParams.Num() > 0)
	{
		for (const auto& ParamName : RoleCompositeParamsPtr->ScalarParamNames)
		{
			if (auto* ParamValuePtr = RoleCompositeParamCachePtr->ScalarParams.Find(ParamName))
			{
				UE_LOG(LogKGMaterial, Log, 
					TEXT("FKGMaterialCacheController::CopyRoleCompositeParamsToOLM, set scalar param %s %f to OLM"), *ParamName.ToString(), *ParamValuePtr);
				MaterialInstanceDynamic->SetGameScalarParameterValue(ParamName, *ParamValuePtr);
			}
		}
	}

	if (RoleCompositeParamCachePtr->VectorParams.Num() > 0)
	{
		for (const auto& ParamName : RoleCompositeParamsPtr->VectorParamNames)
		{
			if (auto* ParamValuePtr = RoleCompositeParamCachePtr->VectorParams.Find(ParamName))
			{
				UE_LOG(LogKGMaterial, Log, 
					TEXT("FKGMaterialCacheController::CopyRoleCompositeParamsToOLM, set vector param %s %s to OLM"), *ParamName.ToString(), *ParamValuePtr->ToString());
				MaterialInstanceDynamic->SetGameVectorParameterValue(ParamName, *ParamValuePtr);
			}
		}
	}
	
	if (RoleCompositeParamCachePtr->TextureParams.Num() > 0)
	{
		for (const auto& ParamName : RoleCompositeParamsPtr->TextureParamNames)
		{
			if (auto* ParamValuePtr = RoleCompositeParamCachePtr->TextureParams.Find(ParamName))
			{
				UE_LOG(LogKGMaterial, Log,
					TEXT("FKGMaterialCacheController::CopyRoleCompositeParamsToOLM, set texture param %s %s to OLM"), *ParamName.ToString(), 
					ParamValuePtr->IsValid() ? *ParamValuePtr->Get()->GetPathName() : TEXT("None"));
				MaterialInstanceDynamic->SetGameTextureParameterValue(ParamName, ParamValuePtr->Get());
			}
		}
	}
}

void FKGMaterialCacheController::ChangeDefaultMaterial(
	TWeakObjectPtr<UMeshComponent> MeshComponentPtr, int32 MaterialIndex, bool bOverlayMaterial, bool bSeparateOverlayMaterial,
	bool bRuntimeSeparateOverlayMaterial, UMaterialInstance* InNewMaterialInstance)
{
	if (!MeshComponentPtr.IsValid())
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialCacheController::ChangeDefaultMaterial, invalid mesh component"));
		return;
	}
	
	if (!KGMaterialManager.IsValid())
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialCacheController::ChangeDefaultMaterial, invalid KGMaterialManager"));
		return;
	}

	const auto MaterialCacheKey = KGMaterialUtils::GetMaterialCacheKey(MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, bRuntimeSeparateOverlayMaterial);
	if (!KGMaterialUtils::IsValidMaterialCacheKey(MeshComponentPtr.Get(), MaterialCacheKey))
	{
		UE_LOG(LogKGMaterial, Log, TEXT("FKGMaterialCacheController::ChangeDefaultMaterial, invalid material cache key %s, %lld"),
			*KGMaterialUtils::GetMeshAssetNameDebugUsage(MeshComponentPtr.Get()), MaterialCacheKey);
		return;
	}
	
	InitPerMeshMaterialCacheStack(MeshComponentPtr->GetOwner(), MeshComponentPtr, { MaterialCacheKey });

	UMaterialInterface* NewMaterialInstance = InNewMaterialInstance;
	UMaterialInstanceDynamic* DynamicMaterialInstance = Cast<UMaterialInstanceDynamic>(InNewMaterialInstance);
	if (DynamicMaterialInstance)
	{
		NewMaterialInstance = DynamicMaterialInstance->Parent;
	}
	
	auto* MaterialCacheSetPtr = MaterialCacheSets.Find(MeshComponentPtr.KGGetObjectID());
	if (MaterialCacheSetPtr == nullptr)
	{
		UE_LOG(LogKGMaterial, Error,
			TEXT("FKGMaterialCacheController::ChangeDefaultMaterial, cannot find material cache set, directly set material, mesh component: %s, MaterialCacheKey: %lld"),
			*GetNameSafe(MeshComponentPtr.Get()), MaterialCacheKey);
		return;
	}

	auto* MaterialCacheStackPtr = MaterialCacheSetPtr->MaterialCacheStacks.Find(MaterialCacheKey);
	if (MaterialCacheStackPtr == nullptr)
	{
		UE_LOG(LogKGMaterial, Error,
			TEXT("FKGMaterialCacheController::ChangeDefaultMaterial, cannot find material stack cache, directly set material, mesh component: %s, MaterialCacheKey: %lld"),
			*GetNameSafe(MeshComponentPtr.Get()), MaterialCacheKey);
		return;
	}

	// default材质肯定是最后一个, MaterialCacheItems不可能为空
	if (MaterialCacheStackPtr->Items.Num() == 0)
	{
		UE_LOG(LogKGMaterial, Error,
			TEXT("FKGMaterialCacheController::ChangeDefaultMaterial, material cache stack should not be empty, mesh component: %s, MaterialCacheKey: %lld"),
			*GetNameSafe(MeshComponentPtr.Get()), MaterialCacheKey);
		return;
	}

	UE_LOG(LogKGMaterial, Log, TEXT("FKGMaterialCacheController::ChangeDefaultMaterial, mesh comp: %s, material cache key: %lld, old: %s, new: %s"),
		*GetNameSafe(MeshComponentPtr.Get()), MaterialCacheKey,
		*KGMaterialUtils::GetMaterialInfoDebugUsage(MaterialCacheStackPtr->Items.Last().MaterialInterface),
		*KGMaterialUtils::GetMaterialInfoDebugUsage(NewMaterialInstance));
	
	auto& DefaultMaterialCacheItem = MaterialCacheStackPtr->Items.Last();
	DefaultMaterialCacheItem.MaterialInterface = NewMaterialInstance;
	
	// 雨水材质效果依赖当前默认材质的类型来决定是否能够执行替换材质操作, 因此底材质变化时, 且当前生效的材质是雨水材质(材质请求存在EffectiveParentMaterialNames)
	// 那么此时可以直接覆盖掉雨水材质
	bool bChangeOverrideMaterial = false;
	if (MaterialCacheStackPtr->Items.Num() == 1)
	{
		bChangeOverrideMaterial = true;
	}
	else if (MaterialCacheStackPtr->Items.Num() > 1)
	{
		auto& CurrentActiveMaterialCacheItem = MaterialCacheStackPtr->Items[0];
		if (auto* ContextPtr = KGMaterialManager->GetChangeMaterialContextPtr(CurrentActiveMaterialCacheItem.ReqId))
		{
			if (ContextPtr->ChangeMaterialRequest.EffectiveParentMaterialNames.Num() > 0)
			{
				if (!CanMaterialTakeEffect(*ContextPtr, MeshComponentPtr.Get(), MaterialCacheKey, NewMaterialInstance))
				{
					UE_LOG(LogKGMaterial, Log,
						TEXT("FKGMaterialCacheController::ChangeDefaultMaterial, need change override material, actor %s, mesh component: %s, MaterialCacheKey: %lld, active: %s, new default: %s"),
						*GetNameSafe(MeshComponentPtr->GetOwner()), *GetNameSafe(MeshComponentPtr.Get()), MaterialCacheKey,
						*KGMaterialUtils::GetMaterialInfoDebugUsage(CurrentActiveMaterialCacheItem.MaterialInterface),
						*KGMaterialUtils::GetMaterialInfoDebugUsage(NewMaterialInstance));
					bChangeOverrideMaterial = true;
				}
			}
		}
	}

	if (bChangeOverrideMaterial)
	{
		// 如果当前default material已经生效了, 那么还需要修改角色当前mesh身上对应的material
		if (NewMaterialInstance == nullptr)
		{
			KGMaterialUtils::SetMaterialInstanceByMaterialCacheKey(MeshComponentPtr.Get(), nullptr, MaterialCacheKey);
		}
		else
		{
			KGMaterialUtils::ChangeMaterialParent(MeshComponentPtr.Get(), NewMaterialInstance, MaterialCacheKey);

			// 如果外部传入的是一个dynamic material instance, 还需要保留原始的所有材质参数
			if (DynamicMaterialInstance)
			{
				if (UMaterialInstanceDynamic* MaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(
					KGMaterialUtils::GetMaterialInstanceByMaterialCacheKey(MeshComponentPtr.Get(), MaterialCacheKey)))
				{
					SCOPED_NAMED_EVENT(FKGMaterialCacheController_ChangeDefaultMaterial_CopyParameterOverrides, FColor::Red);
					MaterialInstanceDynamic->CopyParameterOverrides(DynamicMaterialInstance);
				}
				else
				{
					UE_LOG(LogKGMaterial, Error,
						TEXT("FKGMaterialCacheController::ChangeDefaultMaterial, invalid material instance after change material parent, cannot copy parameter overrides, mesh component: %s, MaterialCacheKey: %lld"),
						*GetNameSafe(MeshComponentPtr.Get()), MaterialCacheKey);
				}
			}
		}
	}
}

UMaterialInstanceDynamic* FKGMaterialCacheController::GetDynamicMaterialInstance(
	UMeshComponent* MeshComponent, int32 MaterialIndex, bool bOverlayMaterial, bool bSeparateOverlayMaterial, bool bRuntimeSeparateOverlayMaterial)
{
	if (!MeshComponent)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("FKGMaterialCacheController::GetDynamicMaterialInstance, invalid mesh component"));
		return nullptr;
	}

	const auto MaterialCacheKey = KGMaterialUtils::GetMaterialCacheKey(MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, bRuntimeSeparateOverlayMaterial);
	if (!KGMaterialUtils::IsValidMaterialCacheKey(MeshComponent, MaterialCacheKey))
	{
		UE_LOG(LogKGMaterial, Log, TEXT("FKGMaterialCacheController::GetDynamicMaterialInstance, invalid material cache key %s, %lld"),
			*KGMaterialUtils::GetMeshAssetNameDebugUsage(MeshComponent), MaterialCacheKey);
		return nullptr;
	}
	
	InitPerMeshMaterialCacheStack(MeshComponent->GetOwner(), MeshComponent, { MaterialCacheKey });

	UMaterialInstanceDynamic* MaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(
		KGMaterialUtils::GetMaterialInstanceByMaterialCacheKey(MeshComponent, MaterialCacheKey));
	return MaterialInstanceDynamic;
}

UMaterialInterface* FKGMaterialCacheController::GetDefaultMaterial(UMeshComponent* MeshComponent, KGMaterialCacheKey MaterialCacheKey)
{
	int32 MaterialIndex;
	bool bOutOverlayMaterial;
	bool bOutSeparateOverlayMaterial;
	bool bOutRuntimeSeparateOverlayMaterial;
	KGMaterialUtils::GetMaterialIndexInfoByCacheKey(MaterialCacheKey, MaterialIndex, bOutOverlayMaterial, bOutSeparateOverlayMaterial, bOutRuntimeSeparateOverlayMaterial);
	return GetDefaultMaterial(MeshComponent, MaterialIndex, bOutOverlayMaterial, bOutSeparateOverlayMaterial, bOutRuntimeSeparateOverlayMaterial);
}

UMaterialInterface* FKGMaterialCacheController::GetDefaultMaterial(
	UMeshComponent* MeshComponent, int32 MaterialIndex, bool bOverlayMaterial, bool bSeparateOverlayMaterial, bool bRuntimeSeparateOverlayMaterial)
{
	if (!MeshComponent)
	{
		return nullptr;
	}
	
	const auto MaterialCacheKey = KGMaterialUtils::GetMaterialCacheKey(MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, bRuntimeSeparateOverlayMaterial);
	if (!KGMaterialUtils::IsValidMaterialCacheKey(MeshComponent, MaterialCacheKey))
	{
		UE_LOG(LogKGMaterial, Log, TEXT("FKGMaterialCacheController::GetDynamicMaterialInstance, invalid material cache key %s, %lld"),
			*KGMaterialUtils::GetMeshAssetNameDebugUsage(MeshComponent), MaterialCacheKey);
		return nullptr;
	}

	const auto MeshCompID = KGUtils::GetIDByObject(MeshComponent);
	auto* MaterialCacheSetPtr = MaterialCacheSets.Find(MeshCompID);
	if (!MaterialCacheSetPtr)
	{
		return KGMaterialUtils::GetMaterialInstanceByMaterialCacheKey(MeshComponent, MaterialCacheKey);
	}

	auto* MaterialCacheStackPtr = MaterialCacheSetPtr->MaterialCacheStacks.Find(MaterialCacheKey);
	if (!MaterialCacheStackPtr)
	{
		return KGMaterialUtils::GetMaterialInstanceByMaterialCacheKey(MeshComponent, MaterialCacheKey);
	}

	if (MaterialCacheStackPtr->Items.Num() == 0)
	{
		UE_LOG(LogKGMaterial, Error,
			TEXT("FKGMaterialCacheController::GetDefaultMaterial, material cache stack should not be empty, mesh component: %s, MaterialCacheKey: %lld"),
			*GetNameSafe(MeshComponent), MaterialCacheKey);
		return nullptr;
	}
	
	return MaterialCacheStackPtr->Items.Last().MaterialInterface;
}

TArray<FString> FKGMaterialCacheController::GetDebugInfo(TWeakObjectPtr<AActor> ActorPtr)
{
	TArray<FString> DebugInfos;
#if KG_ENABLE_MATERIAL_MANAGER_DEBUG
	auto* MeshComponentsPtr = MeshComponentCaches.Find(ActorPtr.KGGetObjectID());
	if (MeshComponentsPtr == nullptr)
	{
		return DebugInfos;
	}

	for (const auto MeshComponentPtr : *MeshComponentsPtr)
	{
		auto* MaterialCacheSetPtr = MaterialCacheSets.Find(MeshComponentPtr.KGGetObjectID());
		if (MaterialCacheSetPtr == nullptr)
		{
			continue;
		}
		
		for (const auto& Kvp : MaterialCacheSetPtr->MaterialCacheStacks)
		{
			const auto& MaterialCacheKey = Kvp.Key;
			const auto& MaterialCacheStacks = Kvp.Value.Items;
			for (int32 i = 0; i < MaterialCacheStacks.Num(); ++i)
			{
				const auto& MaterialCacheStack = MaterialCacheStacks[i];

				int32 MaterialIndex;
				bool bOutOverlayMaterial;
				bool bOutSeparateOverlayMaterial;
				bool bOutRuntimeSeparateOverlayMaterial;
				KGMaterialUtils::GetMaterialIndexInfoByCacheKey(MaterialCacheKey, MaterialIndex, bOutOverlayMaterial, bOutSeparateOverlayMaterial, bOutRuntimeSeparateOverlayMaterial);
				FName MaterialSlotName = *FString(TEXT("nil"));
				KGMaterialUtils::GetSlotNameByMaterialCacheKey(MeshComponentPtr.Get(), MaterialCacheKey, MaterialSlotName);
				FStringBuilderBase ExtraMsg;
				if (i == 0)
				{
					ExtraMsg.Append(TEXT("[Active]"));
				}
				if (MaterialCacheStack.bIsDefaultMaterial)
				{
					ExtraMsg.Append(TEXT("[Default]"));
				}
				FString DebugInfo = FString::Printf(TEXT("%s|%s, %d|%d|%d|%d|%s, %s(%d|%d) %s"),
					*GetNameSafe(ActorPtr.Get()), *GetNameSafe(MeshComponentPtr.Get()), MaterialIndex, bOutOverlayMaterial, bOutSeparateOverlayMaterial, bOutRuntimeSeparateOverlayMaterial,
					*MaterialSlotName.ToString(), *GetNameSafe(MaterialCacheStack.MaterialInterface), MaterialCacheStack.Priority, MaterialCacheStack.SequenceId, ExtraMsg.ToString());
				DebugInfos.Add(DebugInfo);
			}
		}
	}
#endif
	return DebugInfos;
}

void FKGMaterialCacheController::ChangeNoBatchOLM(uint64 ActorId, KGObjectID ComponentId, bool AddOrRemove)
{
	auto& Info = RuntimeExcludeOLMBatchCompIDs.FindOrAdd(ActorId);
	if (AddOrRemove)
	{
		if (!Info.Contains(ComponentId))
			Info.Add(ComponentId);
	}
	else
	{
		if (Info.Contains(ComponentId))
			Info.Remove(ComponentId);
	}
}