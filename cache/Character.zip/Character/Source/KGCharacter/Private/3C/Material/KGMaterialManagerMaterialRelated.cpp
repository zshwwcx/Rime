#include "3C/Material/KGMaterialManager.h"
#include "Components/SkeletalMeshComponent.h"
#include "3C/Util/KGActorUtil.h"
#include "3C/Util/KGUtils.h"

static uint32 InnerMaterialInstanceSetId = 0;

#pragma region SetMeshAPI
void UKGMaterialManager::SetActorSkeletalMesh(USkeletalMeshComponent* SkeletalMeshComponent, USkeletalMesh* SkeletalMesh, bool bReinitPose, bool bEmptyOverrideMaterials)
{
	if (!SkeletalMeshComponent)
	{
		return;
	}

	if (bEmptyOverrideMaterials)
	{
		SkeletalMeshComponent->EmptyOverrideMaterials();
	}
	
	SkeletalMeshComponent->SetSkeletalMesh(SkeletalMesh, bReinitPose);
	if (UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(SkeletalMeshComponent))
	{
		MaterialManager->RefreshMaterialCacheOnMeshAssetChange(SkeletalMeshComponent->GetOwner(), SkeletalMeshComponent);
	}
}

void UKGMaterialManager::SetActorPoseableSkeletalMesh(UPoseableMeshComponent* PoseableMeshComponent, USkeletalMesh* SkeletalMesh, bool bReinitPose, bool bEmptyOverrideMaterials)
{
	if (!PoseableMeshComponent)
	{
		return;
	}
	
	if (bEmptyOverrideMaterials)
	{
		PoseableMeshComponent->EmptyOverrideMaterials();
	}

	PoseableMeshComponent->SetSkinnedAssetAndUpdate(SkeletalMesh, bReinitPose);
	if (UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(PoseableMeshComponent))
	{
		MaterialManager->RefreshMaterialCacheOnMeshAssetChange(PoseableMeshComponent->GetOwner(), PoseableMeshComponent);
	}
}

void UKGMaterialManager::SetActorStaticMesh(UStaticMeshComponent* StaticMeshComponent, UStaticMesh* StaticMesh, bool bEmptyOverrideMaterials)
{
	if (!StaticMeshComponent)
	{
		return;
	}

	if (bEmptyOverrideMaterials)
	{
		StaticMeshComponent->EmptyOverrideMaterials();
	}
	
	StaticMeshComponent->SetStaticMesh(StaticMesh);
	if (UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(StaticMeshComponent))
	{
		MaterialManager->RefreshMaterialCacheOnMeshAssetChange(StaticMeshComponent->GetOwner(), StaticMeshComponent);
	}
}

void UKGMaterialManager::SetActorSkinnedMeshAsset(USkinnedMeshComponent* SkinnedMeshComponent, USkinnedAsset* SkinnedAsset, bool bEmptyOverrideMaterials)
{
	if (!SkinnedMeshComponent)
	{
		return;
	}

	if (bEmptyOverrideMaterials)
	{
		SkinnedMeshComponent->EmptyOverrideMaterials();
	}
	
	SkinnedMeshComponent->SetSkinnedAsset(SkinnedAsset);
	if (UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(SkinnedMeshComponent))
	{
		MaterialManager->RefreshMaterialCacheOnMeshAssetChange(SkinnedMeshComponent->GetOwner(), SkinnedMeshComponent);
	}
}

void UKGMaterialManager::SetActorSkinnedAssetAndUpdate(USkinnedMeshComponent* SkinnedMeshComponent, USkinnedAsset* SkinnedAsset, bool bReinitPose, bool bEmptyOverrideMaterials)
{
	if (!SkinnedMeshComponent)
	{
		return;
	}

	if (bEmptyOverrideMaterials)
	{
		SkinnedMeshComponent->EmptyOverrideMaterials();
	}
	
	SkinnedMeshComponent->SetSkinnedAssetAndUpdate(SkinnedAsset, bReinitPose);
	if (UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(SkinnedMeshComponent))
	{
		MaterialManager->RefreshMaterialCacheOnMeshAssetChange(SkinnedMeshComponent->GetOwner(), SkinnedMeshComponent);
	}
}
#pragma endregion SetMeshAPI

#pragma region DefaultMaterialAPI

KGObjectID UKGMaterialManager::GetDynamicMaterialInstanceByID(
	KGObjectID MeshComponentID, int32 MaterialIndex, bool bOverlayMaterial, bool bSeparateOverlayMaterial)
{
	return KGUtils::GetIDByObject(GetDynamicMaterialInstance(
		Cast<UMeshComponent>(KGUtils::GetObjectByID(MeshComponentID)), MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial));
}

UMaterialInstanceDynamic* UKGMaterialManager::GetDynamicMaterialInstance(
	UMeshComponent* MeshComponent, int32 MaterialIndex, bool bOverlayMaterial, bool bSeparateOverlayMaterial)
{
	return MaterialCacheController.GetDynamicMaterialInstance(MeshComponent, MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, false);
}

void UKGMaterialManager::ChangeDefaultMaterialInstanceByID(
	KGObjectID MeshComponentID, KGObjectID MaterialInstanceID, int32 MaterialIndex, bool bOverlayMaterial, bool bSeparateOverlayMaterial)
{
	ChangeDefaultMaterialInstance(Cast<UMeshComponent>(KGUtils::GetObjectByID(MeshComponentID)),
		Cast<UMaterialInstance>(KGUtils::GetObjectByID(MaterialInstanceID)), MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial);
}

void UKGMaterialManager::ChangeDefaultMaterialInstance(
	UMeshComponent* MeshComponent, UMaterialInstance* NewMaterialInstance, int32 MaterialIndex, bool bOverlayMaterial, bool bSeparateOverlayMaterial)
{
	MaterialCacheController.ChangeDefaultMaterial(
		TWeakObjectPtr<UMeshComponent>(MeshComponent), MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, false, NewMaterialInstance);
}

KGObjectID UKGMaterialManager::GetDefaultMaterialInstanceID(KGObjectID MeshComponentID, int32 MaterialIndex, bool bOverlayMaterial, bool bSeparateOverlayMaterial)
{
	UMeshComponent* MeshComponent = Cast<UMeshComponent>(KGUtils::GetObjectByID(MeshComponentID));
	if (!MeshComponent)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::GetDefaultMaterialInstanceID, invalid mesh component"));
		return KG_INVALID_ID;
	}

	UMaterialInterface* MaterialInstance = MaterialCacheController.GetDefaultMaterial(
		MeshComponent, MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, false);
	return KGUtils::GetIDByObject(MaterialInstance);
}

#pragma endregion DefaultMaterialAPI

#pragma region MaterialCache

void UKGMaterialManager::InitMaterialCacheUseMaterialOnComponent(KGObjectID ActorID)
{
	AActor* Actor = KGUtils::GetActorByID(ActorID);
	if (!Actor)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::InitMaterialCacheUseMaterialOnComponent, invalid actor %lld"), ActorID);
		return;
	}

	KGMaterialCacheKeyMapping MaterialCacheKeyMapping;
	GetAffectedMaterialCacheKeys(
		Actor, EKGSearchMeshType::SearchSelfMeshes, NAME_None, EmptyCustomMeshComps, EmptyExcludeMeshTags,
		EKGSearchMaterialType::SearchAllNormalMaterial, EmptyMaterialSlotNames, false, false,
		MaterialCacheKeyMapping);

	MaterialCacheController.InitMaterialCacheStack(Actor, MaterialCacheKeyMapping, false);
}

// 当新增/销毁 mesh component, 切换mesh asset, 切换default material时都会执行RefreshAllMaterialCaches
// 这里的含义为, 清理当前所有非default材质(对于删除mesh component来说需要清理对应所有材质缓存), 接着所有材质修改请求和材质参数修改请求
// 都需要重新应用一遍
// 关于RefreshAllMaterialCaches时能不能清理override materials
// 此时角色组装已经设置完DefaultMaterial, 且将组装参数设置上去了, 所以这里不能empty override materials, 否则会导致组装材质参数丢失
// 调用到这里时实际上可以认定当前底材质已经是修改好了
void UKGMaterialManager::RefreshAllMaterialCaches(KGObjectID ActorID)
{
	AActor* Actor = KGUtils::GetActorByID(ActorID);
	if (!Actor)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::RefreshAllMaterialCaches, invalid actor %lld"), ActorID);
		return;
	}

	SCOPED_NAMED_EVENT(UKGMaterialManager_RefreshAllMaterialCaches, FColor::Red);	
	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::RefreshAllMaterialCaches, actor %s"), *Actor->GetName());
	
	RemoveTransientTasksByActor(ActorID);
	MaterialCacheController.ClearNonDefaultMaterialCaches(Actor);
	MaterialCacheController.RevertRuntimeSeparateOverlayMaterialOnRefreshMaterial(Actor);

	auto* ReqIdPtr = ActorChangeMaterialReqIds.Find(ActorID);
	if (ReqIdPtr)
	{
		for (const auto ReqId : *ReqIdPtr)
		{
			auto* ContextPtr = ChangeMaterialContexts.Find(ReqId);
			if (!ContextPtr)
			{
				UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::RefreshAllMaterialCaches, invalid change material req id %d"), ReqId);
				continue;
			}

			if (ContextPtr->ExecStage != EKGChangeMaterialExecStage::Activated)
			{
				continue;
			}

			auto& Request = ContextPtr->ChangeMaterialRequest;
			ContextPtr->MaterialCacheKeyMapping.Empty();
			GetAffectedMaterialCacheKeys(
				Request.OwnerActor.Get(), Request.SearchMeshType, Request.SearchMeshName, Request.CustomMeshComps,
				Request.ExcludeMeshTags, Request.SearchMaterialType, Request.MaterialSlotNames,
				Request.bIgnoreExcludedMeshComp, false, ContextPtr->MaterialCacheKeyMapping);

			MaterialCacheController.InitMaterialCacheStack(Request.OwnerActor, ContextPtr->MaterialCacheKeyMapping);
			MaterialCacheController.AddMaterialCacheStackItems(*ContextPtr);
		}
	}
	
	RefreshAllMaterialParams(Actor);
}

// 当切换mesh asset会执行 RefreshMaterialCacheOnMeshAssetChange
// 这里的含义为, 清理对应component的所有材质缓存, 接着所有材质修改请求和材质参数修改请求都需要在对应component上重新应用一遍
void UKGMaterialManager::RefreshMaterialCacheOnMeshAssetChange(AActor* Actor, UMeshComponent* MeshComponent)
{
	if (!Actor || !MeshComponent)
	{
		return;
	}

	SCOPED_NAMED_EVENT(UKGMaterialManager_RefreshMaterialCacheOnMeshAssetChange, FColor::Red);
	const auto ActorID = KGUtils::GetIDByObject(Actor);
	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::RefreshMaterialCacheOnMeshAssetChange, actor %s"), *Actor->GetName());
	RemoveTransientTasksByActor(ActorID);
	MaterialCacheController.ClearMaterialCacheSet(ActorID, MeshComponent);
	MaterialParamController.ClearMeshRoleCompositeParamCache(MeshComponent);
	
	auto* ReqIdPtr = ActorChangeMaterialReqIds.Find(ActorID);
	if (ReqIdPtr)
	{
		for (const auto ReqId : *ReqIdPtr)
		{
			auto* ContextPtr = ChangeMaterialContexts.Find(ReqId);
			if (!ContextPtr)
			{
				UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::RefreshMaterialCacheOnMeshAssetChange, invalid change material req id %d"), ReqId);
				continue;
			}

			if (ContextPtr->ExecStage != EKGChangeMaterialExecStage::Activated)
			{
				continue;
			}

			if (!ContextPtr->MaterialCacheKeyMapping.Contains(MeshComponent))
			{
				continue;
			}

			auto& Request = ContextPtr->ChangeMaterialRequest;
			auto& MaterialCacheKeys = ContextPtr->MaterialCacheKeyMapping[MeshComponent];
			MaterialCacheKeys.Empty();
			GetAffectedMaterialCacheKeysInComponent(
				Request.OwnerActor.Get(), MeshComponent,
				Request.SearchMaterialType, Request.MaterialSlotNames,
				Request.bIgnoreExcludedMeshComp, false, ContextPtr->MaterialCacheKeyMapping);

			MaterialCacheController.InitPerMeshMaterialCacheStack(Request.OwnerActor, MeshComponent, MaterialCacheKeys);
			MaterialCacheController.AddPerMeshMaterialCacheItems(*ContextPtr, MeshComponent, MaterialCacheKeys);
		}
	}
	
	ReqIdPtr = ActorChangeMaterialParamReqIds.Find(ActorID);
	if (ReqIdPtr)
	{
		for (const auto ReqId : *ReqIdPtr)
		{
			auto* ContextPtr = ChangeMaterialParamContexts.Find(ReqId);
			if (!ContextPtr)
			{
				UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::RefreshMaterialCacheOnMeshAssetChange, invalid change material param req id %d"), ReqId);
				continue;
			}

			if (ContextPtr->ExecStage <= EKGChangeMaterialParamExecStage::WaitingRelatedChangeMaterial)
			{
				continue;
			}
			
			RefreshMaterialParamsOnMeshAssetChange(*ContextPtr, MeshComponent);
		}
	}
}

void UKGMaterialManager::KAPI_MaterialManager_RefreshMaterialCacheOnAddMeshComponent(KGObjectID ActorID, KGObjectID MeshCompID, bool bInheritMaterialEffect)
{
	RefreshMaterialCacheOnAddMeshComponent(ActorID, MeshCompID, bInheritMaterialEffect);
}

void UKGMaterialManager::RefreshMaterialCacheOnAddMeshComponent(KGObjectID ActorID, KGObjectID MeshCompID, bool bInheritMaterialEffect)
{
	AActor* Actor = KGUtils::GetActorByID(ActorID);
	if (!IsValid(Actor))
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::RefreshMaterialCacheOnAddMeshComponent, invalid actor"));
		return;
	}

	UMeshComponent* MeshComponent = Cast<UMeshComponent>(KGUtils::GetObjectByID(MeshCompID));
	if (!IsValid(MeshComponent))
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::RefreshMaterialCacheOnAddMeshComponent, invalid MeshComponent"));
		return;
	}

	SCOPED_NAMED_EVENT(UKGMaterialManager_RefreshMaterialCacheOnAddMeshComponent, FColor::Red);
	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::RefreshMaterialCacheOnAddMeshComponent, actor %s, component: %s"),
		*Actor->GetName(), *MeshComponent->GetName());

	if (bInheritMaterialEffect)
	{
		MaterialCacheController.ChangeRuntimeSeparateOverlayMaterialOnAddMeshComponent(Actor, MeshComponent);
	}
	
	auto* ReqIdPtr = ActorChangeMaterialReqIds.Find(ActorID);
	if (ReqIdPtr)
	{
		for (const auto ReqId : *ReqIdPtr)
		{
			auto* ContextPtr = ChangeMaterialContexts.Find(ReqId);
			if (!ContextPtr)
			{
				UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::RefreshMaterialCacheOnAddMeshComponent, invalid change material req id %d"), ReqId);
				continue;
			}

			if (ContextPtr->ExecStage != EKGChangeMaterialExecStage::Activated)
			{
				continue;
			}

			auto& Request = ContextPtr->ChangeMaterialRequest;
			KGMaterialCacheKeyMapping NewMaterialCacheKeyMapping;
			GetAffectedMaterialCacheKeys(
				Request.OwnerActor.Get(), Request.SearchMeshType, Request.SearchMeshName, Request.CustomMeshComps,
				Request.ExcludeMeshTags, Request.SearchMaterialType, Request.MaterialSlotNames,
				Request.bIgnoreExcludedMeshComp, false, NewMaterialCacheKeyMapping);
			if (!NewMaterialCacheKeyMapping.Contains(MeshComponent))
			{
				continue;
			}

			const auto& MaterialCacheKeys = NewMaterialCacheKeyMapping[MeshComponent];
			ContextPtr->MaterialCacheKeyMapping.Add(MeshComponent, MaterialCacheKeys);
			MaterialCacheController.InitPerMeshMaterialCacheStack(Request.OwnerActor, MeshComponent, MaterialCacheKeys);
			MaterialCacheController.AddPerMeshMaterialCacheItems(*ContextPtr, MeshComponent, MaterialCacheKeys);
		}
	}

	ReqIdPtr = ActorChangeMaterialParamReqIds.Find(ActorID);
	if (ReqIdPtr)
	{
		for (const auto ReqId : *ReqIdPtr)
		{
			auto* ContextPtr = ChangeMaterialParamContexts.Find(ReqId);
			if (!ContextPtr)
			{
				UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::RefreshMaterialCacheOnAddMeshComponent, invalid change material param req id %d"), ReqId);
				continue;
			}

			auto& Request = ContextPtr->ChangeMaterialParamRequest;
			// 这个在任何stage下都需要调用
			if (Request.ShouldUseOLM() && Request.bIgnoreExcludedMeshComp && !bInheritMaterialEffect)
			{
				MaterialCacheController.ChangeRuntimeSeparateOverlayMaterialOnAddMeshComponent(Actor, MeshComponent);
			}
			
			if (ContextPtr->ExecStage <= EKGChangeMaterialParamExecStage::WaitingRelatedChangeMaterial)
			{
				continue;
			}
			
			KGMaterialCacheKeyMapping NewMaterialCacheKeyMapping;
			GetAffectedMaterialCacheKeys(
				Request.OwnerActor.Get(), Request.SearchMeshType, Request.SearchMeshName, Request.CustomMeshComps,
				Request.ExcludeMeshTags, Request.SearchMaterialType, Request.MaterialSlotNames,
				Request.bIgnoreExcludedMeshComp, Request.bIsCameraDither, NewMaterialCacheKeyMapping);
			if (!NewMaterialCacheKeyMapping.Contains(MeshComponent))
			{
				continue;
			}

			const auto& MaterialCacheKeys = NewMaterialCacheKeyMapping[MeshComponent];
			ContextPtr->MaterialCacheKeyMapping.Add(MeshComponent, MaterialCacheKeys);
			if (!Request.ShouldUseOLM())
			{
				MaterialCacheController.InitPerMeshMaterialCacheStack(Request.OwnerActor, MeshComponent, MaterialCacheKeys);
			}
			
			RemoveMaterialInstanceSet(ContextPtr->MaterialInstanceSetId);
			const auto NewMaterialInstanceSetID = CreateMaterialInstanceSet(ContextPtr->MaterialCacheKeyMapping);
			UE_LOG(LogKGMaterial, Log,
				TEXT("UKGMaterialManager::RefreshMaterialCacheOnAddMeshComponent, replace material instance set id, req id %d, old: %d, new: %d"),
				ContextPtr->ReqId, ContextPtr->MaterialInstanceSetId, NewMaterialInstanceSetID);
			ContextPtr->MaterialInstanceSetId = NewMaterialInstanceSetID;

			if (IsChangeMaterialRequestActive(*ContextPtr))
			{
				InitConstMaterialParams(*ContextPtr);
			}

			for (const auto Kvp : ContextPtr->MaterialParamUpdateTaskIds)
			{
				MaterialParamController.UpdateTaskMaterialInstanceSetID(Kvp.Value, ContextPtr->MaterialInstanceSetId);
			}
		}
	}
}

void UKGMaterialManager::KAPI_MaterialManager_RefreshMaterialCacheOnRemoveMeshComponent(KGObjectID ActorID, KGObjectID MeshCompID)
{
	RefreshMaterialCacheOnRemoveMeshComponent(ActorID, MeshCompID);
}

// 必须在mesh component删除之前调用这个接口
void UKGMaterialManager::RefreshMaterialCacheOnRemoveMeshComponent(KGObjectID ActorID, KGObjectID MeshCompID)
{
	AActor* Actor = KGUtils::GetActorByID(ActorID);
	if (!IsValid(Actor))
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::RefreshMaterialCacheOnRemoveMeshComponent, invalid actor"));
		return;
	}

	UMeshComponent* MeshComponent = Cast<UMeshComponent>(KGUtils::GetObjectByID(MeshCompID));
	if (!IsValid(MeshComponent))
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::RefreshMaterialCacheOnRemoveMeshComponent, invalid MeshComponent"));
		return;
	}

	SCOPED_NAMED_EVENT(UKGMaterialManager_RefreshMaterialCacheOnRemoveMeshComponent, FColor::Red);
	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::RefreshMaterialCacheOnRemoveMeshComponent, actor %s, component: %s"),
		*Actor->GetName(), *MeshComponent->GetName());
	
	MaterialCacheController.ClearMaterialCacheSet(ActorID, MeshComponent);
	MaterialParamController.ClearMeshRoleCompositeParamCache(MeshComponent);

	auto* ReqIdPtr = ActorChangeMaterialReqIds.Find(ActorID);
	if (ReqIdPtr)
	{
		for (const auto ReqId : *ReqIdPtr)
		{
			auto* ContextPtr = ChangeMaterialContexts.Find(ReqId);
			if (!ContextPtr)
			{
				UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::RefreshMaterialCacheOnRemoveMeshComponent, invalid change material req id %d"), ReqId);
				continue;
			}

			if (ContextPtr->ExecStage != EKGChangeMaterialExecStage::Activated)
			{
				continue;
			}
			
			auto& MaterialCacheKeyMapping = ContextPtr->MaterialCacheKeyMapping;
			if (!MaterialCacheKeyMapping.Contains(MeshComponent))
			{
				continue;
			}
			
			MaterialCacheKeyMapping.Remove(MeshComponent);
		}
	}

	ReqIdPtr = ActorChangeMaterialParamReqIds.Find(ActorID);
	if (ReqIdPtr)
	{
		for (const auto ReqId : *ReqIdPtr)
		{
			auto* ContextPtr = ChangeMaterialParamContexts.Find(ReqId);
			if (!ContextPtr)
			{
				UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::RefreshMaterialCacheOnRemoveMeshComponent, invalid change material param req id %d"), ReqId);
				continue;
			}

			if (ContextPtr->ExecStage <= EKGChangeMaterialParamExecStage::WaitingRelatedChangeMaterial)
			{
				continue;
			}

			// tick阶段发现invalid material instance本身会直接跳过材质参数设置
			auto& MaterialCacheKeyMapping = ContextPtr->MaterialCacheKeyMapping;
			if (!MaterialCacheKeyMapping.Contains(MeshComponent))
			{
				continue;
			}
			
			MaterialCacheKeyMapping.Remove(MeshComponent);
		}
	}
}

void UKGMaterialManager::RefreshAllMaterialParams(AActor* Actor)
{
	if (!Actor)
	{
		return;
	}

	const auto ActorID = KGUtils::GetIDByObject(Actor);
	auto* ReqIdPtr = ActorChangeMaterialParamReqIds.Find(ActorID);
	if (ReqIdPtr)
	{
		for (const auto ReqId : *ReqIdPtr)
		{
			auto* ContextPtr = ChangeMaterialParamContexts.Find(ReqId);
			if (!ContextPtr)
			{
				UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::RefreshAllMaterialParams, invalid change material param req id %d"), ReqId);
				continue;
			}

			if (ContextPtr->ExecStage <= EKGChangeMaterialParamExecStage::WaitingRelatedChangeMaterial)
			{
				UE_LOG(LogKGMaterial, Log,
					TEXT("UKGMaterialManager::RefreshAllMaterialParams, change material param request %d loading material param assets or waiting related change material"), ReqId);
				continue;
			}
			
			RefreshMaterialParamsOnRefreshAllMaterialCaches(*ContextPtr);
		}
	}
}

void UKGMaterialManager::RefreshMaterialParamsOnRefreshAllMaterialCaches(FKGChangeMaterialParamContext& InOutContext)
{
	auto& Request = InOutContext.ChangeMaterialParamRequest;
	if (Request.ShouldUseOLM())
	{
		UE_LOG(LogKGMaterial, Log,
			TEXT("UKGMaterialManager::RefreshAllMaterialCaches, change material param request %d need runtime separate overlay material"), InOutContext.ReqId);
		MaterialCacheController.ChangeRuntimeSeparateOverlayMaterial(
			Request.OwnerActor, Request.CustomMeshComps, InOutContext.ReqId, Request.bUseCharacterCameraDither,
			Request.SearchMeshType == EKGSearchMeshType::SearchAllMesh, Request.bIgnoreExcludedMeshComp, Request.bIsCameraDither,
			Request.bUseWorldPivotPositionForCameraDither, Request.bNeedAngleThresholdParams);
	}
	
	InOutContext.MaterialCacheKeyMapping.Empty();
	GetAffectedMaterialCacheKeys(
		Request.OwnerActor.Get(), Request.SearchMeshType, Request.SearchMeshName, Request.CustomMeshComps,
		Request.ExcludeMeshTags, Request.SearchMaterialType, Request.MaterialSlotNames,
		Request.bIgnoreExcludedMeshComp, Request.bIsCameraDither, InOutContext.MaterialCacheKeyMapping);

	if (!Request.ShouldUseOLM())
	{
		MaterialCacheController.InitMaterialCacheStack(Request.OwnerActor, InOutContext.MaterialCacheKeyMapping);	
	}
	
	RemoveMaterialInstanceSet(InOutContext.MaterialInstanceSetId);
	const auto NewMaterialInstanceSetID = CreateMaterialInstanceSet(InOutContext.MaterialCacheKeyMapping);
	UE_LOG(LogKGMaterial, Log,
		TEXT("UKGMaterialManager::RefreshAllMaterialParams, replace material instance set id, req id %d, old: %d, new: %d"),
		InOutContext.ReqId, InOutContext.MaterialInstanceSetId, NewMaterialInstanceSetID);
	InOutContext.MaterialInstanceSetId = NewMaterialInstanceSetID;

	if (IsChangeMaterialRequestActive(InOutContext))
	{
		InitConstMaterialParams(InOutContext);
	}

	for (const auto Kvp : InOutContext.MaterialParamUpdateTaskIds)
	{
		MaterialParamController.UpdateTaskMaterialInstanceSetID(Kvp.Value, InOutContext.MaterialInstanceSetId);
	}
}

void UKGMaterialManager::RefreshMaterialParamsOnMeshAssetChange(FKGChangeMaterialParamContext& InOutContext, TWeakObjectPtr<UMeshComponent> MeshComponent)
{
	if (!MeshComponent.IsValid())
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::RefreshMaterialParamsOnMeshAssetChange, invalid mesh component, %s"),
			*InOutContext.ToString());
		return;
	}
	
	if (!InOutContext.MaterialCacheKeyMapping.Contains(MeshComponent))
	{
		return;
	}

	auto& Request = InOutContext.ChangeMaterialParamRequest;
	if (Request.ShouldUseOLM())
	{
		MaterialCacheController.ChangeRuntimeSeparateOverlayMaterial(
			Request.OwnerActor, Request.CustomMeshComps, InOutContext.ReqId, Request.bUseCharacterCameraDither,
			Request.SearchMeshType == EKGSearchMeshType::SearchAllMesh, Request.bIgnoreExcludedMeshComp, Request.bIsCameraDither,
			Request.bUseWorldPivotPositionForCameraDither, Request.bNeedAngleThresholdParams);
	}
	
	auto& MaterialCacheKeys = InOutContext.MaterialCacheKeyMapping[MeshComponent];
	MaterialCacheKeys.Empty();
	GetAffectedMaterialCacheKeysInComponent(
		Request.OwnerActor.Get(), MeshComponent.Get(),
		Request.SearchMaterialType, Request.MaterialSlotNames,
		Request.bIgnoreExcludedMeshComp, Request.bIsCameraDither, InOutContext.MaterialCacheKeyMapping);

	if (!Request.ShouldUseOLM())
	{
		MaterialCacheController.InitPerMeshMaterialCacheStack(Request.OwnerActor, MeshComponent, MaterialCacheKeys);
	}
			
	RemoveMaterialInstanceSet(InOutContext.MaterialInstanceSetId);
	const auto NewMaterialInstanceSetID = CreateMaterialInstanceSet(InOutContext.MaterialCacheKeyMapping);
	UE_LOG(LogKGMaterial, Log,
		TEXT("UKGMaterialManager::RefreshMaterialParamsOnMeshAssetChange, replace material instance set id, req id %d, old: %d, new: %d"),
		InOutContext.ReqId, InOutContext.MaterialInstanceSetId, NewMaterialInstanceSetID);
	InOutContext.MaterialInstanceSetId = NewMaterialInstanceSetID;

	if (IsChangeMaterialRequestActive(InOutContext))
	{
		InitConstMaterialParams(InOutContext);
	}

	for (const auto Kvp : InOutContext.MaterialParamUpdateTaskIds)
	{
		MaterialParamController.UpdateTaskMaterialInstanceSetID(Kvp.Value, InOutContext.MaterialInstanceSetId);
	}
}

TArray<FString> UKGMaterialManager::KAPI_MaterialManager_GetMaterialCacheDebugInfos(KGObjectID ActorID)
{
	return MaterialCacheController.GetDebugInfo(KGUtils::GetActorByID(ActorID));
}

#pragma endregion MaterialCache

#pragma region MaterialInstanceSet

uint32 UKGMaterialManager::CreateMaterialInstanceSet(const KGMaterialCacheKeyMapping& Mapping)
{
	const auto MaterialInstanceSetId = KGMaterialUtils::GenerateIncId(InnerMaterialInstanceSetId);
	
	TMap<TWeakObjectPtr<UMaterialInstanceDynamic>, FKGMaterialInfo> MaterialInstanceMapping;
	for (const auto& Kvp : Mapping)
	{
		auto& MeshComponent = Kvp.Key;
		if (!MeshComponent.IsValid())
		{
			continue;
		}
		
		for (const auto MaterialCacheKey : Kvp.Value)
		{
			// GetMaterialInstanceByMaterialCacheKey的逻辑是, 如果存在override material且override material不为空则返回override material, 否则返回资产上配置的
			// material, 对于组装逻辑来说, 可能会通过ChangeDefaultMaterial设置一个存在default material的asset对应的override material为nullptr, 此时这里拿到的实际
			// 是资产上的default material, 会导致下面逻辑报错, 因此这里总是拿override material使用
			UMaterialInterface* MaterialInterface = KGMaterialUtils::GetOverrideMaterialInstanceByMaterialCacheKey(MeshComponent.Get(), MaterialCacheKey);
			if (!MaterialInterface)
			{
				continue;
			}
			
			if (UMaterialInstanceDynamic* MaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(MaterialInterface))
			{
				FKGMaterialInfo MaterialInfo;
				MaterialInfo.MeshComponent = MeshComponent;
				MaterialInfo.MaterialCacheKey = MaterialCacheKey;
				MaterialInstanceMapping.Add(MaterialInstanceDynamic, MaterialInfo);
				UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::CreateMaterialInstanceSet, create material instance set %s, %lld, %s, %d"),
					*MeshComponent->GetName(), MaterialCacheKey, *KGMaterialUtils::GetMaterialInfoDebugUsage(MaterialInterface), MaterialInstanceSetId);
			}
			else
			{
				UE_LOG(LogKGMaterial, Error,
					TEXT("UKGMaterialManager::CreateMaterialInstanceSet, expected dynamic material instance %s, %lld, but got: %s"),
					*MeshComponent->GetName(), MaterialCacheKey, *KGMaterialUtils::GetMaterialInfoDebugUsage(MaterialInterface));
			}
		}
	}
	
	MaterialInstancesSets.Add(MaterialInstanceSetId, MaterialInstanceMapping);

	for (auto& Kvp : MaterialInstanceMapping)
	{
		auto& MaterialInstance = Kvp.Key;
		auto& SetIds = MaterialInstanceToMaterialInstanceSetIds.FindOrAdd(MaterialInstance);
		SetIds.Add(MaterialInstanceSetId);
	}
	
	return MaterialInstanceSetId;
}

void UKGMaterialManager::ClearInvalidMaterialCache()
{
	TArray<KGObjectID> ActorIDs;
	ActorChangeMaterialReqIds.GenerateKeyArray(ActorIDs);
	for (const auto ActorID : ActorIDs)
	{
		if (!KGUtils::GetObjectByID(ActorID))
		{
			RevertMaterialByActorId(ActorID);
		}
	}
	
	ActorChangeMaterialParamReqIds.GenerateKeyArray(ActorIDs);
	for (const auto ActorID : ActorIDs)
	{
		if (!KGUtils::GetObjectByID(ActorID))
		{
			RevertMaterialParamByActorId(ActorID);
		}
	}
}

void UKGMaterialManager::RemoveMaterialInstanceSet(uint32 SetId)
{
	if (MaterialInstancesSets.Contains(SetId))
	{
		auto& MaterialInstanceSet = MaterialInstancesSets[SetId];
		for (auto& Kvp : MaterialInstanceSet)
		{
			auto& MaterialInstance = Kvp.Key;
			if (auto* SetIdsPtr = MaterialInstanceToMaterialInstanceSetIds.Find(MaterialInstance))
			{
				if (SetIdsPtr->Contains(SetId))
				{
					SetIdsPtr->Remove(SetId);
					UE_LOG(LogKGMaterial, Verbose, TEXT("UKGMaterialManager::RemoveMaterialInstanceSet, remove material instance set %s, %d"),
						*KGMaterialUtils::GetMaterialInfoDebugUsage(MaterialInstance.Get()), SetId);
				}

				if (SetIdsPtr->Num() == 0)
				{
					MaterialInstanceToMaterialInstanceSetIds.Remove(MaterialInstance);
				}
			}
		}
		
		MaterialInstancesSets.Remove(SetId);
	}
}

void UKGMaterialManager::UpdateDynamicMaterialInstance(
	UMaterialInstanceDynamic* OldMaterialInstanceDynamic, UMaterialInstanceDynamic* NewMaterialInstanceDynamic)
{
	if (OldMaterialInstanceDynamic == nullptr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::UpdateDynamicMaterialInstance, invalid old material instance"));
		return;
	}

	TWeakObjectPtr<UMaterialInstanceDynamic> OldMaterialInstanceDynamicPtr(OldMaterialInstanceDynamic);
	TWeakObjectPtr<UMaterialInstanceDynamic> NewMaterialInstanceDynamicPtr(NewMaterialInstanceDynamic);
	if (const auto* MaterialInstanceSetIdsPtr = MaterialInstanceToMaterialInstanceSetIds.Find(OldMaterialInstanceDynamicPtr))
	{
		for (const auto SetId : *MaterialInstanceSetIdsPtr)
		{
			if (!MaterialInstancesSets.Contains(SetId))
			{
				UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::UpdateDynamicMaterialInstance, set id %d not found"), SetId);
				continue;
			}

			MaterialInstancesSets[SetId].Remove(OldMaterialInstanceDynamicPtr);
			if (NewMaterialInstanceDynamic)
			{
				MaterialInstancesSets[SetId].Add(NewMaterialInstanceDynamicPtr);
			}
			UE_LOG(LogKGMaterial, Verbose, TEXT("UKGMaterialManager::UpdateDynamicMaterialInstance, update material instance set %s, %s, %d"),
				*KGMaterialUtils::GetMaterialInfoDebugUsage(OldMaterialInstanceDynamicPtr.Get()),
				*KGMaterialUtils::GetMaterialInfoDebugUsage(NewMaterialInstanceDynamic), SetId);
		}

		if (NewMaterialInstanceDynamic)
		{
			// MaterialInstanceToMaterialInstanceSetIds执行完FindOrAdd以后, MaterialInstanceSetIdsPtr指向可能已经失效, 这里总是重新index一遍
			auto& SetIds = MaterialInstanceToMaterialInstanceSetIds.FindOrAdd(NewMaterialInstanceDynamicPtr);
			check(MaterialInstanceToMaterialInstanceSetIds.Contains(OldMaterialInstanceDynamicPtr));
			SetIds.Append(MaterialInstanceToMaterialInstanceSetIds[OldMaterialInstanceDynamicPtr]);
		}

		MaterialInstanceToMaterialInstanceSetIds.Remove(OldMaterialInstanceDynamicPtr);
	}
}
#pragma endregion MaterialInstanceSet

#pragma region SearchMaterial

void UKGMaterialManager::GetAllAffectedMaterialCacheKeysByActor(
	AActor* Actor, bool bIncludeChildActors, bool bIgnoreExcludeMeshComp, bool bIsCameraDither, const TArray<FName>& ExcludeMeshTags,
	KGMaterialCacheKeyMapping& OutMaterialCacheKeyMapping)
{
	GetAffectedMaterialCacheKeys(
		Actor, bIncludeChildActors ? EKGSearchMeshType::SearchAllMesh : EKGSearchMeshType::SearchSelfMeshes, TEXT(""), EmptyCustomMeshComps, ExcludeMeshTags,
		EKGSearchMaterialType::SearchAllNormalMaterial, EmptyMaterialSlotNames, bIgnoreExcludeMeshComp, bIsCameraDither, OutMaterialCacheKeyMapping);
}

void UKGMaterialManager::GetAffectedMaterialCacheKeys(
	AActor* Actor, EKGSearchMeshType SearchMeshType, const FName& MeshName, const TArray<TWeakObjectPtr<UMeshComponent>>& CustomMeshComponents,
	const TArray<FName>& ExcludeMeshTags, EKGSearchMaterialType SearchMaterialType,
	const TArray<FName>& MaterialSlotNames, bool bIgnoreExcludedMeshComp, bool bIsCameraDither, KGMaterialCacheKeyMapping& OutMaterialCacheKeyMapping)
{
	if (!Actor)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::GetAffectedMaterialCacheKeys, invalid actor"));
		return;
	}
	
	if (SearchMeshType == EKGSearchMeshType::SearchMeshByName)
	{
		// todo MeshName配置方式要整理
		// 处理上下坐骑以后角色妆容参数丢失问题
		// 首先玩家在播表情动画，身上持续存在一个修改Head(Mesh) - Face(MaterialSlot) 的材质参数请求, 人坐上车的时候，会将人的材质效果同步给车，
		// 此时会将人身上的表情材质参数修改请求尝试同步给车
		// 于是执行了一次修改车的Head这个Mesh上的材质参数请求，由于现在Mesh的查找是包括ChildActor的，车去修改Head(Mesh) - Face(MaterialSlot)时实际又查到了人的Mesh，
		// 就会再尝试给人执行一次表情材质参数修改（这里已经不对了）
		// 因为这个原因，往下就错误执行到了Head Mesh材质缓存的Clear & ReInit，导致重新构建新的MID，妆容材质参数就丢失了
		if (USceneComponent* Component = UKGActorUtil::GetComponentByNameAndClass(Actor, MeshName, UMeshComponent::StaticClass(), true))
		{
			GetAffectedMaterialCacheKeysInComponent(
				Actor, Cast<UMeshComponent>(Component), SearchMaterialType, MaterialSlotNames,
				bIgnoreExcludedMeshComp, bIsCameraDither, OutMaterialCacheKeyMapping);
		}
	}
	else
	{
		TArray<UMeshComponent*> MeshComponents;
		if (SearchMeshType == EKGSearchMeshType::SearchSelfMeshes)
		{
			const auto& Components = UKGActorUtil::GetComponentsByClasses(Actor, ValidClassTypes, false);
			for (const auto& Component : Components)
			{
				if (UMeshComponent* MeshComp = Cast<UMeshComponent>(Component))
				{
					MeshComponents.Add(MeshComp);
				}
			}
		}
		else if (SearchMeshType == EKGSearchMeshType::SearchAllMesh)
		{
			const auto& Components = UKGActorUtil::GetComponentsByClasses(Actor, ValidClassTypes, true);
			for (const auto& Component : Components)
			{
				if (UMeshComponent* MeshComp = Cast<UMeshComponent>(Component))
				{
					MeshComponents.Add(MeshComp);
				}
			}
		}
		else if (SearchMeshType == EKGSearchMeshType::UseCustomMeshComps)
		{
			for (const auto& Component : CustomMeshComponents)
			{
				if (Component.IsValid())
				{
					MeshComponents.Add(Component.Get());
				}
			}
		}
		else
		{
			UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::GetAffectedMaterialCacheKeys, invalid search mesh type %d"), (int32)SearchMeshType);
			return;
		}

		for (const auto Component : MeshComponents)
		{
			if (!Component)
			{
				continue;
			}

			if (KGMaterialUtils::ComponentHasAnyTag(Component, ExcludeMeshTags))
			{
				UE_LOG(LogKGMaterial, Verbose, TEXT("UKGMaterialManager::GetAffectedMaterialCacheKeys, mesh component excluded, %s, %s"),
					*Actor->GetName(), *Component->GetName());
				continue;
			}
			
			GetAffectedMaterialCacheKeysInComponent(
				Actor, Component, SearchMaterialType, MaterialSlotNames, bIgnoreExcludedMeshComp, bIsCameraDither, OutMaterialCacheKeyMapping);
		}
	}
}

void UKGMaterialManager::GetAffectedMaterialCacheKeysInComponent(
	AActor* Actor, UMeshComponent* MeshComponent, EKGSearchMaterialType SearchMaterialType,
	const TArray<FName>& MaterialSlotNames, bool bIgnoreExcludedMeshComp, bool bIsCameraDither, KGMaterialCacheKeyMapping& OutMaterialCacheKeyMapping)
{
	if (!Actor)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::GetAffectedMaterialCacheKeys, invalid actor"));
		return;
	}

	if (!MeshComponent)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::GetAffectedMaterialCacheKeys, invalid mesh component"));
		return;
	}
	
	const auto ActorID = KGUtils::GetIDByObject(Actor);
	if (!bIgnoreExcludedMeshComp)
	{
		if (auto* ExcludedMeshCompInfoPtr = ActorExcludedMeshComps.Find(ActorID))
		{
			if (auto* ExcludeInfoPtr = ExcludedMeshCompInfoPtr->Find(MeshComponent))
			{
				if (ExcludeInfoPtr->bIgnoreCameraDither && bIsCameraDither)
				{
					UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::GetAffectedMaterialCacheKeys, mesh component excluded for camera dither, %s, %s"),
						*Actor->GetName(), *MeshComponent->GetName());
					return;
				}

				if (ExcludeInfoPtr->bIgnoreNonCameraDither && !bIsCameraDither)
				{
					UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::GetAffectedMaterialCacheKeys, mesh component excluded for camera dither, %s, %s"),
						*Actor->GetName(), *MeshComponent->GetName());
					return;
				}
			}
		}
	}

	TWeakObjectPtr<UMeshComponent> MeshComponentPtr(MeshComponent);
	auto& MaterialCacheKeys = OutMaterialCacheKeyMapping.FindOrAdd(MeshComponentPtr);

	if (SearchMaterialType == EKGSearchMaterialType::SearchAllNormalMaterial)
	{
		const auto& MaterialInstances = MeshComponent->GetMaterials();
		for (int32 i = 0; i < MaterialInstances.Num(); i++)
		{
			const auto MaterialInstance = MeshComponent->GetMaterial(i);
			if (!IsValid(MaterialInstance))
			{
				continue;
			}

			const KGMaterialCacheKey CacheKey = KGMaterialUtils::GetMaterialCacheKey(i, false, false, false);
			MaterialCacheKeys.Add(CacheKey);
		}
	}
	else if (SearchMaterialType == EKGSearchMaterialType::SearchOverlayMaterial)
	{
		// overlay material可以修改空的
		const KGMaterialCacheKey CacheKey = KGMaterialUtils::GetMaterialCacheKey(0, true, false, false);
		MaterialCacheKeys.Add(CacheKey);
	}
	else if (SearchMaterialType == EKGSearchMaterialType::SearchMaterialBySlots)
	{
		const auto& MaterialInstances = MeshComponent->GetMaterials();
		const auto& SlotNames = MeshComponent->GetMaterialSlotNames();
		for (int32 i = 0; i < MaterialInstances.Num(); i++)
		{
			const auto MaterialInstance = MeshComponent->GetMaterial(i);
			if (!IsValid(MaterialInstance))
			{
				continue;
			}

			if (SlotNames.IsValidIndex(i) && MaterialSlotNames.Contains(SlotNames[i]))
			{
				const KGMaterialCacheKey CacheKey = KGMaterialUtils::GetMaterialCacheKey(i, false, false, false);
				MaterialCacheKeys.Add(CacheKey);	
			}
		}
	}
	else if (SearchMaterialType == EKGSearchMaterialType::SearchRuntimeSeparateOverlayMaterial)
	{
		const auto& MaterialInstances = MeshComponent->GetRuntimeSeperateOverlayMaterials();
		for (int32 i = 0; i < MaterialInstances.Num(); i++)
		{
			const auto MaterialInstance = MeshComponent->GetRuntimeSeperateOverlayMaterial(i);
			if (!IsValid(MaterialInstance))
			{
				continue;
			}

			const KGMaterialCacheKey CacheKey = KGMaterialUtils::GetMaterialCacheKey(i, false, false, true);
			MaterialCacheKeys.Add(CacheKey);
		}
	}
	else if (SearchMaterialType == EKGSearchMaterialType::SearchRuntimeSeparateOverlayMaterialBySlots)
	{
		const auto& MaterialInstances = MeshComponent->GetRuntimeSeperateOverlayMaterials();
		const auto& SlotNames = MeshComponent->GetRuntimeSeperateOverlayMaterialSlotNames();
		for (int32 i = 0; i < MaterialInstances.Num(); i++)
		{
			const auto MaterialInstance = MeshComponent->GetRuntimeSeperateOverlayMaterial(i);
			if (!IsValid(MaterialInstance))
			{
				continue;
			}

			if (SlotNames.IsValidIndex(i) && MaterialSlotNames.Contains(SlotNames[i]))
			{
				const KGMaterialCacheKey CacheKey = KGMaterialUtils::GetMaterialCacheKey(i, false, false, true);
				MaterialCacheKeys.Add(CacheKey);	
			}
		}
	}
}

#pragma endregion SearchMaterial
