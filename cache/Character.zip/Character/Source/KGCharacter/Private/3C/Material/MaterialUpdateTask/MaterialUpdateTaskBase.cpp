#include "3C/Material/MaterialUpdateTask/MaterialUpdateTaskBase.h"
#include "Engine/Engine.h"
#include "Kismet/KismetMaterialLibrary.h"
#include "Manager/KGCppAssetManager.h"
#include "3C/Material/KGMaterialManager.h"

bool GDebugShowMPCParam = false;
static FAutoConsoleVariableRef CVarDebugShowMPCParam(
	TEXT("gp.DebugShowMPCParam"),
	GDebugShowMPCParam,
	TEXT("DebugShowMPCParam."),
	ECVF_Default
);

void FKGMaterialParamUpdateTaskBase::OnTaskEnd()
{
	if (bRevertToDefaultValueOnTaskEnd)
	{
		const EKGMaterialParamType ParamType = GetParamType();
		if (ParamType == EKGMaterialParamType::Scalar)
		{
			RemoveOverrideScalarParameter();
		}
		else if (ParamType == EKGMaterialParamType::LinearColor)
		{
			RemoveOverrideVectorParameter();
		}
	}

	if (MaterialParamUpdateTarget.AssetLoadID != 0)
	{
		if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(KGMaterialManager.Get()))
		{
			AssetManager->CancelAsyncLoadByLoadID(MaterialParamUpdateTarget.AssetLoadID);
			MaterialParamUpdateTarget.AssetLoadID = 0;
		}
	}
}

void FKGMaterialParamUpdateTaskBase::SetScalarParameterValue(float ParamVal)
{
	if (!KGMaterialManager.IsValid())
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamUpdateTaskBase::SetScalarParameterValue, invalid material manager"));
		return;
	}
	
	if (MaterialParamUpdateTarget.MaterialInstanceSetId.IsSet())
	{
		KGMaterialManager->SetScalarParameterBySetId(MaterialParamUpdateTarget.MaterialInstanceSetId.GetValue(), ParamName, ParamVal);
	}
	else if (MaterialParamUpdateTarget.MaterialParameterCollection.IsValid())
	{
		UKismetMaterialLibrary::SetScalarParameterValue(KGMaterialManager.Get(), MaterialParamUpdateTarget.MaterialParameterCollection.Get(), ParamName, ParamVal);
#if KG_ENABLE_MATERIAL_MANAGER_DEBUG
		if (GDebugShowMPCParam)
		{
			GEngine->AddOnScreenDebugMessage(INDEX_NONE, .0f, FColor::Green,
				FString::Printf(TEXT("[MPC] %s, %s, %f"), *MaterialParamUpdateTarget.MaterialParameterCollection->GetName(), *ParamName.ToString(), ParamVal));
		}
#endif
	}
	else
	{
		for (auto MaterialInstance : MaterialParamUpdateTarget.MaterialInstances)
		{
			if (MaterialInstance.IsValid())
			{
				MaterialInstance->SetScalarParameterValue(ParamName, ParamVal);
			}
		}
	}
	
	bLatestValueSet = true;
	LatestScalarValue = ParamVal;
}

void FKGMaterialParamUpdateTaskBase::SetVectorParameterValue(const FVector& ParamVal)
{
	FLinearColor LinearColorVal = FLinearColor(ParamVal);
	SetVectorParameterValue(LinearColorVal);
}

void FKGMaterialParamUpdateTaskBase::SetVectorParameterValue(const FLinearColor& ParamVal)
{
	if (!KGMaterialManager.IsValid())
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamUpdateTaskBase::SetVectorParameterValue, invalid material manager"));
		return;
	}
	
	if (MaterialParamUpdateTarget.MaterialInstanceSetId.IsSet())
	{
		KGMaterialManager->SetVectorParameterBySetId(MaterialParamUpdateTarget.MaterialInstanceSetId.GetValue(), ParamName, ParamVal);
	}
	else if (MaterialParamUpdateTarget.MaterialParameterCollection.IsValid())
	{
		UKismetMaterialLibrary::SetVectorParameterValue(KGMaterialManager.Get(), MaterialParamUpdateTarget.MaterialParameterCollection.Get(), ParamName, ParamVal);
#if KG_ENABLE_MATERIAL_MANAGER_DEBUG
		if (GDebugShowMPCParam)
		{
			GEngine->AddOnScreenDebugMessage(INDEX_NONE, .0f, FColor::Green,
				FString::Printf(TEXT("[MPC] %s, %s, %s"), *MaterialParamUpdateTarget.MaterialParameterCollection->GetName(), *ParamName.ToString(), *ParamVal.ToString()));
		}
#endif
	}
	else
	{
		for (auto MaterialInstance : MaterialParamUpdateTarget.MaterialInstances)
		{
			if (MaterialInstance.IsValid())
			{
				MaterialInstance->SetVectorParameterValue(ParamName, ParamVal);
			}
		}
	}

	bLatestValueSet = true;
	LatestVectorValue = ParamVal;
}

void FKGMaterialParamUpdateTaskBase::RemoveOverrideScalarParameter()
{
	if (!KGMaterialManager.IsValid())
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamUpdateTaskBase::SetScalarParameterValueToDefault, invalid material manager"));
		return;
	}

	if (MaterialParamUpdateTarget.MaterialParameterCollection.IsValid())
	{
		const FCollectionScalarParameter* ScalarParameter = MaterialParamUpdateTarget.MaterialParameterCollection->GetScalarParameterByName(ParamName);
		if (ScalarParameter != nullptr)
		{
			UKismetMaterialLibrary::SetScalarParameterValue(
				KGMaterialManager.Get(), MaterialParamUpdateTarget.MaterialParameterCollection.Get(), ParamName, ScalarParameter->DefaultValue);
#if KG_ENABLE_MATERIAL_MANAGER_DEBUG
			if (GDebugShowMPCParam)
			{
				GEngine->AddOnScreenDebugMessage(INDEX_NONE, .0f, FColor::Green,
					FString::Printf(TEXT("[MPC][RevertToDefault] %s, %s, %f"), *MaterialParamUpdateTarget.MaterialParameterCollection->GetName(), *ParamName.ToString(), ScalarParameter->DefaultValue));
			}
#endif
		}
		else
		{
			UE_LOG(LogKGMaterial, Warning, TEXT("MPC %s does not have scalar parameter %s"),
				*MaterialParamUpdateTarget.MaterialParameterCollection->GetPathName(), *ParamName.ToString());
		}
	}
	else
	{
		if (MaterialParamUpdateTarget.MaterialInstanceSetId.IsSet())
		{
			KGMaterialManager->RemoveOrRevertParameterBySetId(MaterialParamUpdateTarget.MaterialInstanceSetId.GetValue(), ParamName, EKGMaterialParamType::Scalar);
		}
		else
		{
			for (auto MaterialInstance : MaterialParamUpdateTarget.MaterialInstances)
			{
				if (MaterialInstance.IsValid())
				{
					MaterialInstance->RemoveScalarParameter(ParamName);
				}
			}
		}
	}
}

void FKGMaterialParamUpdateTaskBase::RemoveOverrideVectorParameter()
{
	if (!KGMaterialManager.IsValid())
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamUpdateTaskBase::SetVectorParameterValueToDefault, invalid material manager"));
		return;
	}
	
	if (MaterialParamUpdateTarget.MaterialParameterCollection.IsValid())
	{
		const FCollectionVectorParameter* VectorParameter = MaterialParamUpdateTarget.MaterialParameterCollection->GetVectorParameterByName(ParamName);
		if (VectorParameter != nullptr)
		{
			UKismetMaterialLibrary::SetVectorParameterValue(KGMaterialManager.Get(), MaterialParamUpdateTarget.MaterialParameterCollection.Get(), ParamName, VectorParameter->DefaultValue);
#if KG_ENABLE_MATERIAL_MANAGER_DEBUG
			if (GDebugShowMPCParam)
			{
				GEngine->AddOnScreenDebugMessage(INDEX_NONE, .0f, FColor::Green,
					FString::Printf(TEXT("[MPC][RevertToDefault] %s, %s, %s"), *MaterialParamUpdateTarget.MaterialParameterCollection->GetName(),
						*ParamName.ToString(), *VectorParameter->DefaultValue.ToString()));
			}
#endif
		}
		else
		{
			UE_LOG(LogKGMaterial, Warning, TEXT("MPC %s does not have vector parameter %s"),
				*MaterialParamUpdateTarget.MaterialParameterCollection->GetPathName(), *ParamName.ToString());
		}
	}
	else
	{
		if (MaterialParamUpdateTarget.MaterialInstanceSetId.IsSet())
		{
			KGMaterialManager->RemoveOrRevertParameterBySetId(MaterialParamUpdateTarget.MaterialInstanceSetId.GetValue(), ParamName, EKGMaterialParamType::LinearColor);
		}
		else
		{
			for (auto MaterialInstance : MaterialParamUpdateTarget.MaterialInstances)
			{
				if (MaterialInstance.IsValid())
				{
					MaterialInstance->RemoveVectorParameter(ParamName);
				}
			}
		}
	}
}

void FKGMaterialParamUpdateTaskBase::ApplyLatestValueIfSet()
{
	if (!bLatestValueSet)
	{
		return;
	}

	const auto ParamType = GetParamType();
	if (ParamType == EKGMaterialParamType::Scalar)
	{
		SetScalarParameterValue(LatestScalarValue);
	}
	else if (ParamType == EKGMaterialParamType::LinearColor)
	{
		SetVectorParameterValue(LatestVectorValue);
	}
}

bool FKGMaterialParamUpdateTaskBase::IsValid() const
{
	if (KGMaterialManager.IsValid() && MaterialParamUpdateTarget.MaterialInstanceSetId.IsSet())
	{
		return KGMaterialManager->IsValidMaterialInstanceSet(MaterialParamUpdateTarget.MaterialInstanceSetId.GetValue());
	}

	return MaterialParamUpdateTarget.MaterialParameterCollection.IsValid() || MaterialParamUpdateTarget.MaterialInstances.Num() > 0;
}