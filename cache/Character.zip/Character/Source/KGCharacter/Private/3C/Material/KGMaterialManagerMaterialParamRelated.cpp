#include "3C/Material/KGMaterialManager.h"
#include "3C/Util/KGUtils.h"

static uint32 InnerTransientMaterialParamUpdateTaskId = 0;

#pragma region MaterialParamUpdateAPI
uint32 UKGMaterialManager::AddCurveParamByDynamicMaterialInstanceID(
	const FName& ParamName, KGObjectID DynamicMaterialInstanceID, const FString& CurvePath, bool bNeedRemap, float RemapTime, bool bLoop, bool bRevertToDefaultValueOnTaskEnd)
{
	UMaterialInstanceDynamic* MaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(KGUtils::GetObjectByID(DynamicMaterialInstanceID));
	return AddCurveParamByDynamicMaterialInstance(ParamName, MaterialInstanceDynamic, CurvePath, bNeedRemap, RemapTime, bLoop, bRevertToDefaultValueOnTaskEnd);
}

uint32 UKGMaterialManager::AddCurveParamByDynamicMaterialInstance(const FName& ParamName, UMaterialInstanceDynamic* DynamicMaterialInstance, const FString& CurvePath, bool bNeedRemap, float RemapTime, bool bLoop, bool bRevertToDefaultValueOnTaskEnd)
{
	if (!IsValid(DynamicMaterialInstance))
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::AddCurveParamByDynamicMaterialInstanceID, invalid dynamic material instance id"));
		return 0;
	}
	
	FKGCommonMaterialParamUpdateParams UpdateParams;
	UpdateParams.ParamName = ParamName;
	UpdateParams.MaterialParamUpdateTarget.MaterialInstances.Add(DynamicMaterialInstance);
	UpdateParams.bRevertToDefaultValueOnTaskEnd = bRevertToDefaultValueOnTaskEnd;
	return MaterialParamController.AddCurveParamByCurvePath(UpdateParams, CurvePath, bNeedRemap, RemapTime, bLoop);
}

uint32 UKGMaterialManager::AddCurveParamByDynamicMaterialInstanceIDs(
	const FName& ParamName, const TArray<KGObjectID>& DynamicMaterialInstanceIDs, const FString& CurvePath, bool bNeedRemap, float RemapTime, bool bLoop, bool bRevertToDefaultValueOnTaskEnd)
{
	TSet<TWeakObjectPtr<UMaterialInstanceDynamic>> MaterialInstanceDynamics;
	if (!KGMaterialUtils::GetDynamicMaterialInstancesByMaterialInstanceIDs(DynamicMaterialInstanceIDs, MaterialInstanceDynamics))
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("AddCurveParamByDynamicMaterialInstanceIDs, no valid material instance dynamic found"));
		return 0;
	}

	FKGCommonMaterialParamUpdateParams UpdateParams;
	UpdateParams.ParamName = ParamName;
	UpdateParams.MaterialParamUpdateTarget.MaterialInstances.Append(MaterialInstanceDynamics);
	UpdateParams.bRevertToDefaultValueOnTaskEnd = bRevertToDefaultValueOnTaskEnd;
	return MaterialParamController.AddCurveParamByCurvePath(UpdateParams, CurvePath, bNeedRemap, RemapTime, bLoop);
}

uint32 UKGMaterialManager::AddCurveParamByCurveIDAndDynamicMaterialInstanceID(
	const FName& ParamName, KGObjectID DynamicMaterialInstanceID, KGObjectID CurveID, bool bNeedRemap, float RemapTime, bool bLoop, bool bRevertToDefaultValueOnTaskEnd)
{
	UMaterialInstanceDynamic* MaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(KGUtils::GetObjectByID(DynamicMaterialInstanceID));
	UCurveBase* CurveBase = Cast<UCurveBase>(KGUtils::GetObjectByID(CurveID));
	return AddCurveParamByDynamicMaterialInstance(ParamName, MaterialInstanceDynamic, CurveBase, bNeedRemap, RemapTime, bLoop, bRevertToDefaultValueOnTaskEnd);
}

uint32 UKGMaterialManager::AddCurveParamByCurveIDAndDynamicMaterialInstanceIDs(
	const FName& ParamName, const TArray<KGObjectID>& DynamicMaterialInstanceIDs, KGObjectID CurveID, bool bNeedRemap, float RemapTime, bool bLoop, bool bRevertToDefaultValueOnTaskEnd)
{
	TSet<TWeakObjectPtr<UMaterialInstanceDynamic>> MaterialInstanceDynamics;
	if (!KGMaterialUtils::GetDynamicMaterialInstancesByMaterialInstanceIDs(DynamicMaterialInstanceIDs, MaterialInstanceDynamics))
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("AddCurveParamByCurveIDAndDynamicMaterialInstanceIDs, no valid material instance dynamic found"));
		return 0;
	}

	UCurveBase* CurveBase = Cast<UCurveBase>(KGUtils::GetObjectByID(CurveID));
	if (!CurveBase)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::AddCurveParamByCurveIDAndDynamicMaterialInstanceIDs, invalid curve id"));
		return 0;
	}

	FKGCommonMaterialParamUpdateParams UpdateParams;
	UpdateParams.ParamName = ParamName;
	UpdateParams.MaterialParamUpdateTarget.MaterialInstances.Append(MaterialInstanceDynamics);
	UpdateParams.bRevertToDefaultValueOnTaskEnd = bRevertToDefaultValueOnTaskEnd;
	return MaterialParamController.AddCurveParam(UpdateParams, CurveBase, bNeedRemap, RemapTime, bLoop);
}

uint32 UKGMaterialManager::AddLinearSampleParamByDynamicMaterialInstanceID(
	const FName& ParamName, KGObjectID DynamicMaterialInstanceID, float StartVal, float EndVal, float Duration, bool bRevertToDefaultValueOnTaskEnd)
{
	UMaterialInstanceDynamic* MaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(KGUtils::GetObjectByID(DynamicMaterialInstanceID));
	return AddScalarLinearSampleParamByDynamicMaterialInstance(
		ParamName, MaterialInstanceDynamic, StartVal, EndVal, Duration, bRevertToDefaultValueOnTaskEnd);
}

uint32 UKGMaterialManager::AddLinearSampleParamByDynamicMaterialInstanceIDs(
	const FName& ParamName, const TArray<KGObjectID>& DynamicMaterialInstanceIDs, float StartVal, float EndVal, float Duration, bool bRevertToDefaultValueOnTaskEnd)
{
	TSet<TWeakObjectPtr<UMaterialInstanceDynamic>> MaterialInstanceDynamics;
	if (!KGMaterialUtils::GetDynamicMaterialInstancesByMaterialInstanceIDs(DynamicMaterialInstanceIDs, MaterialInstanceDynamics))
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("AddLinearSampleParamByDynamicMaterialInstanceIDs, no valid material instance dynamic found"));
		return 0;
	}

	FKGCommonMaterialParamUpdateParams UpdateParams;
	UpdateParams.ParamName = ParamName;
	UpdateParams.MaterialParamUpdateTarget.MaterialInstances.Append(MaterialInstanceDynamics);
	UpdateParams.bRevertToDefaultValueOnTaskEnd = bRevertToDefaultValueOnTaskEnd;
	return MaterialParamController.AddScalarLinearSampleParam(UpdateParams, StartVal, EndVal, Duration);
}

void UKGMaterialManager::UpdateLinearSampleParamTargetValue(
	uint32 ReqId, const FName& ParamName, float TargetVal, bool bUseNewDuration, float InNewDuration)
{
	auto* ContextPtr = ChangeMaterialParamContexts.Find(ReqId);
	if (!ContextPtr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::UpdateLinearSampleParamTargetValue, invalid req id %d"), ReqId);
		return;
	}

	auto* LinearSampleParamsPtr = ContextPtr->ChangeMaterialParamRequest.ScalarLinearSampleParams.Find(ParamName);
	if (LinearSampleParamsPtr == nullptr)
	{
		UE_LOG(LogKGMaterial, Error,
			TEXT("UKGMaterialManager::UpdateLinearSampleParamTargetValue, invalid linear sample param %s, %s"),
			*ParamName.ToString(), *ContextPtr->ToString());
		return;
	}

	if (ContextPtr->bHasInit == false)
	{
		LinearSampleParamsPtr->NewDuration = bUseNewDuration ? InNewDuration : (FMath::Abs((
			TargetVal - LinearSampleParamsPtr->StartVal) / (LinearSampleParamsPtr->EndVal - LinearSampleParamsPtr->StartVal)) * LinearSampleParamsPtr->Duration);
		LinearSampleParamsPtr->CurTargetVal = TargetVal;
		return;
	}

	auto* TaskIDPtr = ContextPtr->MaterialParamUpdateTaskIds.Find(ParamName);
	if (!TaskIDPtr)
	{
		UE_LOG(LogKGMaterial, Error,
			TEXT("UKGMaterialManager::UpdateLinearSampleParamTargetValue, invalid material param update task id %s, %s"),
			*ParamName.ToString(), *ContextPtr->ToString());
		return;
	}

	FKGCommonMaterialParamUpdateParams UpdateParams;
	UpdateParams.ParamName = ParamName;
	UpdateParams.MaterialParamUpdateTarget.MaterialInstanceSetId = ContextPtr->MaterialInstanceSetId;
	float OriginTargetVal = LinearSampleParamsPtr->CurTargetVal.IsSet() ? LinearSampleParamsPtr->CurTargetVal.GetValue() : LinearSampleParamsPtr->EndVal;
	const auto TaskID = MaterialParamController.UpdateOrAddLinearSampleParamTargetValue(*TaskIDPtr, UpdateParams,
		LinearSampleParamsPtr->StartVal, LinearSampleParamsPtr->EndVal, LinearSampleParamsPtr->Duration,
		OriginTargetVal, TargetVal, bUseNewDuration, InNewDuration);
	if (TaskID != 0)
	{
		LinearSampleParamsPtr->CurTargetVal = TargetVal;
		ContextPtr->MaterialParamUpdateTaskIds[ParamName] = TaskID;
	}
}

uint32 UKGMaterialManager::AddVectorLinearSampleParamByDynamicMaterialInstanceIDs(
	const FName& ParamName, const TArray<KGObjectID>& DynamicMaterialInstanceIDs, float StartR, float StartG, float StartB, float StartA,
	float EndR, float EndG, float EndB, float EndA, float Duration, bool bRevertToDefaultValueOnTaskEnd)
{
	TSet<TWeakObjectPtr<UMaterialInstanceDynamic>> MaterialInstanceDynamics;
	if (!KGMaterialUtils::GetDynamicMaterialInstancesByMaterialInstanceIDs(DynamicMaterialInstanceIDs, MaterialInstanceDynamics))
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("AddVectorLinearSampleParamByDynamicMaterialInstanceIDs, no valid material instance dynamic found"));
		return 0;
	}

	FLinearColor StartVal(StartR, StartG, StartB, StartA);
	check(!FVector4(StartVal).ContainsNaN());
	FLinearColor EndVal(EndR, EndG, EndB, EndA);
	check(!FVector4(EndVal).ContainsNaN());
	
	FKGCommonMaterialParamUpdateParams UpdateParams;
	UpdateParams.ParamName = ParamName;
	UpdateParams.bRevertToDefaultValueOnTaskEnd = bRevertToDefaultValueOnTaskEnd;
	UpdateParams.MaterialParamUpdateTarget.MaterialInstances.Append(MaterialInstanceDynamics);
	return MaterialParamController.AddVectorLinearSampleParam(UpdateParams, StartVal, EndVal, Duration);
}

uint32 UKGMaterialManager::AddVectorLinearSampleParamByDynamicMaterialInstanceID(
	const FName& ParamName, KGObjectID DynamicMaterialInstanceID, float StartR, float StartG, float StartB, float StartA,
	float EndR, float EndG, float EndB, float EndA, float Duration, bool bRevertToDefaultValueOnTaskEnd)
{
	UMaterialInstanceDynamic* MaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(KGUtils::GetObjectByID(DynamicMaterialInstanceID));
	
	FLinearColor StartVal(StartR, StartG, StartB, StartA);
	FLinearColor EndVal(EndR, EndG, EndB, EndA);
	
	return AddVectorLinearSampleParamByDynamicMaterialInstance(
		ParamName, MaterialInstanceDynamic, StartVal, EndVal, Duration, bRevertToDefaultValueOnTaskEnd);
}

uint32 UKGMaterialManager::AddMPCLinearSampleParamTask(
	const FName& ParamName, const FString& MPCAssetPath, float StartVal, float EndVal, float Duration, bool bRevertToDefaultValueOnTaskEnd)
{
	FKGCommonMaterialParamUpdateParams UpdateParams;
	UpdateParams.ParamName = ParamName;
	UpdateParams.MaterialParamUpdateTarget.MaterialParameterCollectionAssetPath = MPCAssetPath;
	UpdateParams.bRevertToDefaultValueOnTaskEnd = bRevertToDefaultValueOnTaskEnd;
	return MaterialParamController.AddScalarLinearSampleParam(UpdateParams, StartVal, EndVal, Duration);
}

uint32 UKGMaterialManager::AddMPCActorLocationTask(const FName& ParamName, const FString& MPCAssetPath, KGObjectID ActorId, bool bRevertToDefaultValueOnTaskEnd)
{
	AActor* Actor = KGUtils::GetActorByID(ActorId);
	if (!Actor)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::AddMPCActorLocationTask, invalid actor %lld"), ActorId);
		return 0;
	}
	
	FKGCommonMaterialParamUpdateParams UpdateParams;
	UpdateParams.ParamName = ParamName;
	UpdateParams.MaterialParamUpdateTarget.MaterialParameterCollectionAssetPath = MPCAssetPath;
	UpdateParams.bRevertToDefaultValueOnTaskEnd = bRevertToDefaultValueOnTaskEnd;
	return MaterialParamController.AddActorLocationParamSimple(UpdateParams, Actor);
}

uint32 UKGMaterialManager::AddMPCCurveParamTask(
	const FName& ParamName, const FString& MPCAssetPath, const FString& CurvePath, bool bNeedRemap, float RemapTime, bool bLoop, bool bRevertToDefaultValueOnTaskEnd)
{
	FKGCommonMaterialParamUpdateParams UpdateParams;
	UpdateParams.ParamName = ParamName;
	UpdateParams.MaterialParamUpdateTarget.MaterialParameterCollectionAssetPath = MPCAssetPath;
	UpdateParams.bRevertToDefaultValueOnTaskEnd = bRevertToDefaultValueOnTaskEnd;
	return MaterialParamController.AddCurveParamByCurvePath(UpdateParams, CurvePath, bNeedRemap, RemapTime, bLoop);
}

uint32 UKGMaterialManager::AddScalarLinearSampleParamByDynamicMaterialInstance(
	const FName& ParamName, UMaterialInstanceDynamic* DynamicMaterialInstance, float StartVal, float EndVal, float Duration,
	bool bRevertToDefaultValueOnTaskEnd, bool bActivateImmediately)
{
	if (!DynamicMaterialInstance)
	{
		UE_LOG(LogKGMaterial, Error,
			TEXT("UKGMaterialManager::AddScalarLinearSampleParamByDynamicMaterialInstance, invalid dynamic material instance %s"), *ParamName.ToString());
		return 0;
	}

	FKGCommonMaterialParamUpdateParams UpdateParams;
	UpdateParams.ParamName = ParamName;
	UpdateParams.MaterialParamUpdateTarget.MaterialInstances.Add(DynamicMaterialInstance);
	UpdateParams.bRevertToDefaultValueOnTaskEnd = bRevertToDefaultValueOnTaskEnd;
	UpdateParams.bActivateImmediately = bActivateImmediately;
	return MaterialParamController.AddScalarLinearSampleParam(UpdateParams, StartVal, EndVal, Duration);
}

uint32 UKGMaterialManager::AddVectorLinearSampleParamByDynamicMaterialInstance(
	const FName& ParamName, UMaterialInstanceDynamic* DynamicMaterialInstance, const FLinearColor& StartVal, const FLinearColor& EndVal, float Duration,
	bool bRevertToDefaultValueOnTaskEnd)
{
	if (!DynamicMaterialInstance)
	{
		UE_LOG(LogKGMaterial, Error,
			TEXT("UKGMaterialManager::AddVectorLinearSampleParamByDynamicMaterialInstance, invalid dynamic material instance %s"), *ParamName.ToString());
		return 0;
	}

	check(!FVector4(StartVal).ContainsNaN());
	check(!FVector4(EndVal).ContainsNaN());
	
	FKGCommonMaterialParamUpdateParams UpdateParams;
	UpdateParams.ParamName = ParamName;
	UpdateParams.MaterialParamUpdateTarget.MaterialInstances.Add(DynamicMaterialInstance);
	UpdateParams.bRevertToDefaultValueOnTaskEnd = bRevertToDefaultValueOnTaskEnd;
	return MaterialParamController.AddVectorLinearSampleParam(UpdateParams, StartVal, EndVal, Duration);
}

uint32 UKGMaterialManager::AddCurveParamByDynamicMaterialInstance(
	const FName& ParamName, UMaterialInstanceDynamic* DynamicMaterialInstance, UCurveBase* CurveAsset,
	bool bNeedRemap, float RemapTime, bool bLoop, bool bRevertToDefaultValueOnTaskEnd)
{
	if (!DynamicMaterialInstance)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::AddCurveParamByDynamicMaterialInstance, invalid dynamic material instance id"));
		return 0;
	}
	
	if (!CurveAsset)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::AddCurveParamByDynamicMaterialInstance, invalid curve id"));
		return 0;
	}

	FKGCommonMaterialParamUpdateParams UpdateParams;
	UpdateParams.ParamName = ParamName;
	UpdateParams.MaterialParamUpdateTarget.MaterialInstances.Add(DynamicMaterialInstance);
	UpdateParams.bRevertToDefaultValueOnTaskEnd = bRevertToDefaultValueOnTaskEnd;
	return MaterialParamController.AddCurveParam(UpdateParams, CurveAsset, bNeedRemap, RemapTime, bLoop);
}

uint32 UKGMaterialManager::AddActorLocationParamByDynamicMaterialInstance(
	const FName& ParamName, UMaterialInstanceDynamic* DynamicMaterialInstance, AActor* Actor, bool bRevertToDefaultValueOnTaskEnd)
{
	if (!DynamicMaterialInstance)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::AddActorLocationParamByDynamicMaterialInstance, invalid dynamic material instance id"));
		return 0;
	}
	
	if (!Actor)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::AddActorLocationParamByDynamicMaterialInstance, invalid actor"));
		return 0;
	}

	FKGCommonMaterialParamUpdateParams UpdateParams;
	UpdateParams.ParamName = ParamName;
	UpdateParams.MaterialParamUpdateTarget.MaterialInstances.Add(DynamicMaterialInstance);
	UpdateParams.bRevertToDefaultValueOnTaskEnd = bRevertToDefaultValueOnTaskEnd;
	return MaterialParamController.AddActorLocationParamSimple(UpdateParams, Actor);
}

uint32 UKGMaterialManager::AddEntityLocationParamByDynamicMaterialInstance(
	const FName& ParamName, UMaterialInstanceDynamic* DynamicMaterialInstance, KGEntityID EntityID, bool bRevertToDefaultValueOnTaskEnd)
{
	if (!DynamicMaterialInstance)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::AddEntityLocationParamByDynamicMaterialInstance, invalid dynamic material instance id"));
		return 0;
	}

	FKGCommonMaterialParamUpdateParams UpdateParams;
	UpdateParams.ParamName = ParamName;
	UpdateParams.MaterialParamUpdateTarget.MaterialInstances.Add(DynamicMaterialInstance);
	UpdateParams.bRevertToDefaultValueOnTaskEnd = bRevertToDefaultValueOnTaskEnd;
	return MaterialParamController.AddEntityLocationParam(UpdateParams, EntityID);
}

uint32 UKGMaterialManager::AddLinearBlendParamByDynamicMaterialInstance(
	const FName& ParamName, UMaterialInstanceDynamic* DynamicMaterialInstance,
	float StartVal, float EndVal, float BlendInTime, float BlendOutTime, float Duration, bool bRevertToDefaultValueOnTaskEnd)
{
	if (!DynamicMaterialInstance)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::AddLinearBlendParamByDynamicMaterialInstance, invalid dynamic material instance id"));
		return 0;
	}

	FKGCommonMaterialParamUpdateParams UpdateParams;
	UpdateParams.ParamName = ParamName;
	UpdateParams.MaterialParamUpdateTarget.MaterialInstances.Add(DynamicMaterialInstance);
	UpdateParams.bRevertToDefaultValueOnTaskEnd = bRevertToDefaultValueOnTaskEnd;
	return MaterialParamController.AddLinearBlendParam(
		UpdateParams, StartVal, EndVal, BlendInTime, BlendOutTime, Duration);
}

uint32 UKGMaterialManager::UpdateOrAddLinearSampleParamTargetValue(
	uint32 TaskId, const FName& ParamName, UMaterialInstanceDynamic* DynamicMaterialInstance, float OriginStartVal, float OriginEndVal, float OriginDuration,
	float OriginTargetVal, float TargetVal, bool bUseNewDuration, float InNewDuration)
{
	if (!DynamicMaterialInstance)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::UpdateOrAddLinearSampleParamTargetValue, invalid dynamic material instance id"));
		return 0;
	}

	FKGCommonMaterialParamUpdateParams UpdateParams;
	UpdateParams.ParamName = ParamName;
	UpdateParams.MaterialParamUpdateTarget.MaterialInstances.Add(DynamicMaterialInstance);
	return MaterialParamController.UpdateOrAddLinearSampleParamTargetValue(
		TaskId, UpdateParams, OriginStartVal, OriginEndVal, OriginDuration, OriginTargetVal,
		TargetVal, bUseNewDuration, InNewDuration);
}

uint32 UKGMaterialManager::UpdateOrAddLinearSampleParamTargetValueWithNewDuration(
	uint32 TaskId, const FName& ParamName, UMaterialInstanceDynamic* DynamicMaterialInstance, 
	float OriginEndVal, float TargetVal, float InNewDuration)
{
	return UpdateOrAddLinearSampleParamTargetValue(
		TaskId, ParamName, DynamicMaterialInstance, 0.0f, 0.0f, 0.0f, 
		OriginEndVal, TargetVal, true, InNewDuration);
}

void UKGMaterialManager::RemoveMaterialParamUpdateTask(uint32 TaskID)
{
	MaterialParamController.RemoveMaterialParamUpdateTask(TaskID);
}

void UKGMaterialManager::PauseMaterialParamUpdateTask(uint32 TaskID)
{
	MaterialParamController.PauseMaterialParamUpdateTask(TaskID);
}

void UKGMaterialManager::ResumeMaterialParamUpdateTask(uint32 TaskID)
{
	MaterialParamController.ResumeMaterialParamUpdateTask(TaskID);
}

void UKGMaterialManager::AdvanceUpdateTask(uint32 TaskID, float DeltaTime)
{
	MaterialParamController.AdvanceUpdateTask(TaskID, DeltaTime);
}

#pragma endregion MaterialParamUpdateAPI

#pragma region RoleCompositeMaterialParam

void UKGMaterialManager::SetRoleCompositeScalarMaterialParam(
	UMeshComponent* MeshComponent, int32 MaterialIndex, bool bOverlayMaterial, bool bSeparateOverlayMaterial, const FName& ParamName, float ParamVal)
{
	TMap<FName, float> Params;
	Params.Add(ParamName, ParamVal);
	SetRoleCompositeScalarMaterialParams(MeshComponent, MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, Params);
}

void UKGMaterialManager::SetRoleCompositeScalarMaterialParams(
	UMeshComponent* MeshComponent, int32 MaterialIndex, bool bOverlayMaterial, bool bSeparateOverlayMaterial, const TMap<FName, float>& Params)
{
	MaterialParamController.SetRoleCompositeScalarMaterialParams(MeshComponent, MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, Params);
}

void UKGMaterialManager::SetRoleCompositeVectorMaterialParam(
	UMeshComponent* MeshComponent, int32 MaterialIndex, bool bOverlayMaterial, bool bSeparateOverlayMaterial, const FName& ParamName, const FLinearColor& ParamVal)
{
	TMap<FName, FLinearColor> Params;
	Params.Add(ParamName, ParamVal);
	SetRoleCompositeVectorMaterialParams(MeshComponent, MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, Params);
}

void UKGMaterialManager::SetRoleCompositeVectorMaterialParams(
	UMeshComponent* MeshComponent, int32 MaterialIndex, bool bOverlayMaterial, bool bSeparateOverlayMaterial, const TMap<FName, FLinearColor>& Params)
{
	MaterialParamController.SetRoleCompositeVectorMaterialParams(MeshComponent, MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, Params);
}

void UKGMaterialManager::SetRoleCompositeTextureMaterialParam(
	UMeshComponent* MeshComponent, int32 MaterialIndex, bool bOverlayMaterial, bool bSeparateOverlayMaterial, const FName& ParamName, UTexture* ParamVal)
{
	TMap<FName, UTexture*> Params;
	Params.Add(ParamName, ParamVal);
	SetRoleCompositeTextureMaterialParams(MeshComponent, MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, Params);
}

void UKGMaterialManager::SetRoleCompositeTextureMaterialParams(
	UMeshComponent* MeshComponent, int32 MaterialIndex, bool bOverlayMaterial, bool bSeparateOverlayMaterial, const TMap<FName, UTexture*>& Params)
{
	MaterialParamController.SetRoleCompositeTextureMaterialParams(MeshComponent, MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, Params);
}

const FKGMaterialRoleCompositeParamCache* UKGMaterialManager::GetRoleCompositeParamCachePtr(UMeshComponent* MeshComponent, KGMaterialCacheKey MaterialCacheKey)
{
	return MaterialParamController.GetRoleCompositeParamCachePtr(MeshComponent, MaterialCacheKey);
}

TArray<FString> UKGMaterialManager::KAPI_MaterialManager_GetRoleCompositeMaterialParamCacheDebugInfos(KGObjectID ActorID)
{
	return MaterialParamController.GetRoleCompositeMaterialParamCacheDebugInfos(ActorID);
}

#pragma endregion RoleCompositeMaterialParam

#pragma region MaterialParamSetAndRevert

void UKGMaterialManager::SetScalarParameterBySetId(uint32 SetId, FName ParameterName, float ParamVal)
{
	auto* MaterialSetPtr = MaterialInstancesSets.Find(SetId);
	if (!MaterialSetPtr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::SetScalarParameterBySetId, invalid material instance set %d %s"), SetId, *ParameterName.ToString());
		return;
	}

	UE_LOG(LogKGMaterial, Verbose, TEXT("UKGMaterialManager::SetScalarParameterBySetId, %d %s %f"), SetId, *ParameterName.ToString(), ParamVal);
	
	for (const auto& Kvp : *MaterialSetPtr)
	{
		auto MaterialInstance = Kvp.Key;
		if (!MaterialInstance.IsValid())
		{
			continue;
		}

		MaterialInstance->SetScalarParameterValue(ParameterName, ParamVal);
	}
}

void UKGMaterialManager::SetVectorParameterBySetId(uint32 SetId, FName ParameterName, const FLinearColor& LinearColor)
{
	auto* MaterialSetPtr = MaterialInstancesSets.Find(SetId);
	if (!MaterialSetPtr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::SetVectorParameterBySetId, invalid material instance set %d %s"), SetId, *ParameterName.ToString());
		return;
	}
	
	check(!FVector4(LinearColor).ContainsNaN());
	UE_LOG(LogKGMaterial, Verbose, TEXT("UKGMaterialManager::SetVectorParameterBySetId, %d %s %s"), SetId, *ParameterName.ToString(), *LinearColor.ToString());

	for (auto& Kvp : *MaterialSetPtr)
	{
		auto MaterialInstance = Kvp.Key;
		if (!MaterialInstance.IsValid())
		{
			continue;
		}

		MaterialInstance->SetVectorParameterValue(ParameterName, LinearColor);
	}
}

void UKGMaterialManager::RemoveOrRevertParameterBySetId(uint32 SetId, FName ParameterName, EKGMaterialParamType ParamType)
{
	auto* MaterialSetPtr = MaterialInstancesSets.Find(SetId);
	if (!MaterialSetPtr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::RemoveOrRevertScalarParameterBySetId, invalid material instance set %d %s"), SetId, *ParameterName.ToString());
		return;
	}

	for (const auto& Kvp : *MaterialSetPtr)
	{
		auto& MaterialInstance = Kvp.Key;
		if (!MaterialInstance.IsValid())
		{
			continue;
		}

		RemoveOrRevertMaterialParam(MaterialInstance.Get(), Kvp.Value, ParameterName, ParamType, false);
	}
}

void UKGMaterialManager::RemoveOrRevertMaterialParam(
	UMaterialInstanceDynamic* MaterialInstanceDynamic, const FKGMaterialInfo& MaterialInfo, const FName& ParamName, EKGMaterialParamType ParamType, bool bUseBatchParamSet)
{
	if (!MaterialInstanceDynamic)
	{
		return;
	}

	int32 MaterialIndex = 0;
	bool bOverlayMaterial = false;
	bool bSeparateOverlayMaterial = false;
	bool bRuntimeSeparateOverlayMaterial = false;
	KGMaterialUtils::GetMaterialIndexInfoByCacheKey(
		MaterialInfo.MaterialCacheKey, MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, bRuntimeSeparateOverlayMaterial);
	
	if (ParamType == EKGMaterialParamType::Scalar)
	{
		float DefaultVal = 0.0f;
		if (MaterialParamController.GetScalarRoleCompositeParamCache(
			MaterialInfo.MeshComponent.Get(), MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, ParamName, DefaultVal))
		{
			UE_LOG(LogKGMaterial, Log,
				TEXT("UKGMaterialManager::RemoveOrRevertMaterialParam, mesh: %s, key: %lld, revert scalar param %s to role composite param cache %f"),
				MaterialInfo.MeshComponent.IsValid() ? *MaterialInfo.MeshComponent->GetName() : TEXT("nullptr"),
				MaterialInfo.MaterialCacheKey, *ParamName.ToString(), DefaultVal);
			MaterialInstanceDynamic->SetScalarParameterValue(ParamName, DefaultVal);
			return;
		}
	}
	else if (ParamType == EKGMaterialParamType::LinearColor)
	{
		FLinearColor DefaultVal = FLinearColor::Black;
		if (MaterialParamController.GetVectorRoleCompositeParamCache(
			MaterialInfo.MeshComponent.Get(), MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, ParamName, DefaultVal))
		{
			UE_LOG(LogKGMaterial, Log,
				TEXT("UKGMaterialManager::RemoveOrRevertMaterialParam, mesh: %s, key: %lld, revert vector param %s to role composite param cache %s"),
				MaterialInfo.MeshComponent.IsValid() ? *MaterialInfo.MeshComponent->GetName() : TEXT("nullptr"),
				MaterialInfo.MaterialCacheKey, *ParamName.ToString(), *DefaultVal.ToString());
			MaterialInstanceDynamic->SetVectorParameterValue(ParamName, DefaultVal);
			return;
		}
	}
	else if (ParamType == EKGMaterialParamType::Texture)
	{
		UTexture* DefaultVal = nullptr;
		if (MaterialParamController.GetTextureRoleCompositeParamCache(
			MaterialInfo.MeshComponent.Get(), MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, ParamName, DefaultVal))
		{
			UE_LOG(LogKGMaterial, Log,
				TEXT("UKGMaterialManager::RemoveOrRevertMaterialParam, mesh: %s, key: %lld, revert texture param %s to role composite param cache %s"),
				MaterialInfo.MeshComponent.IsValid() ? *MaterialInfo.MeshComponent->GetName() : TEXT("nullptr"),
				MaterialInfo.MaterialCacheKey, *ParamName.ToString(), DefaultVal ? *DefaultVal->GetPathName() : TEXT("nullptr"));
			MaterialInstanceDynamic->SetTextureParameterValue(ParamName, DefaultVal);
			return;
		}
	}
	else
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::RemoveOrRevertMaterialParam, invalid param type %d"), (int32)ParamType);
		return;
	}

	UE_LOG(LogKGMaterial, Verbose,
		TEXT("UKGMaterialManager::RemoveOrRevertMaterialParam, mesh: %s, key: %lld, remove param %s"),
		MaterialInfo.MeshComponent.IsValid() ? *MaterialInfo.MeshComponent->GetName() : TEXT("nullptr"),
		MaterialInfo.MaterialCacheKey, *ParamName.ToString());
	if (bUseBatchParamSet)
	{
		if (ParamType == EKGMaterialParamType::Scalar)
		{
			MaterialInstanceDynamic->RemoveGameScalarParameter(ParamName);
		}
		else if (ParamType == EKGMaterialParamType::LinearColor)
		{
			MaterialInstanceDynamic->RemoveGameVectorParameter(ParamName);
		}
		else if (ParamType == EKGMaterialParamType::Texture)
		{
			MaterialInstanceDynamic->RemoveGameTextureParameter(ParamName);
		}
	}
	else
	{
		if (ParamType == EKGMaterialParamType::Scalar)
		{
			MaterialInstanceDynamic->RemoveScalarParameter(ParamName);
		}
		else if (ParamType == EKGMaterialParamType::LinearColor)
		{
			MaterialInstanceDynamic->RemoveVectorParameter(ParamName);
		}
		else if (ParamType == EKGMaterialParamType::Texture)
		{
			MaterialInstanceDynamic->RemoveTextureParameter(ParamName);
		}
	}
}

#pragma endregion MaterialParamSetAndRevert

#pragma region TransientUpdateTask

uint32 UKGMaterialManager::KAPI_MaterialManager_AddTransientUpdateTask(KGObjectID ActorId, float LifeTimeSeconds, bool bHasValidEffectType, uint8 EffectType)
{
	AActor* Actor = KGUtils::GetActorByID(ActorId);
	if (!Actor)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::KAPI_MaterialManager_AddTransientUpdateTask, invalid actor %lld"), ActorId);
		return 0;
	}

	return AddTransientUpdateTask(Actor, LifeTimeSeconds, bHasValidEffectType, static_cast<EKGMaterialEffectType>(EffectType));
}

uint32 UKGMaterialManager::AddTransientUpdateTask(AActor* Actor, float LifeTimeSeconds, bool bHasValidEffectType, EKGMaterialEffectType EffectType)
{
	if (!Actor)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::AddTransientUpdateTask, invalid actor"));
		return 0;
	}
	
	if (bHasValidEffectType && MaterialParamController.HasItemInPriorityQueue(Actor, EffectType))
	{
		return 0;
	}
	
	KGMaterialCacheKeyMapping KeyMapping;
	GetAllAffectedMaterialCacheKeysByActor(Actor, false, false, false, EmptyExcludeMeshTags, KeyMapping);
	MaterialCacheController.InitMaterialCacheStack(Actor, KeyMapping);
	const auto MaterialInstanceSetId = CreateMaterialInstanceSet(KeyMapping);

	if (LifeTimeSeconds <= 0)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::AddTransientUpdateTask, invalid LifeTime %f"), LifeTimeSeconds);
		return 0;
	}

	if (bHasValidEffectType && TransientTasks.Num() > 0)
	{
		RemoveTransientTaskByEffectType(Actor, EffectType);	
	}
	
	const uint32 TaskId = KGMaterialUtils::GenerateIncId(InnerTransientMaterialParamUpdateTaskId);
	FKGTransientMaterialParamUpdateTask Task;
	if (bHasValidEffectType)
	{
		Task.EffectType = EffectType;	
	}
	
	Task.Actor = Actor;
	Task.MaterialInstanceSetId = MaterialInstanceSetId;
	TransientTasks.Add(TaskId, Task);

	FKGTransientMaterialParamUpdateTaskLifeTimeParams LifeTimeParams;
	LifeTimeParams.TaskId = TaskId;
	LifeTimeParams.TimeoutTimestamp = FPlatformTime::Seconds() + LifeTimeSeconds;
	LifeTimeParamPriorityQueue.HeapPush(LifeTimeParams);
	
	return TaskId;
}

void UKGMaterialManager::SetScalarParameterByTransientTaskId(uint32 TaskId, FName ParameterName, float ParamVal)
{
	if (!TransientTasks.Contains(TaskId))
	{
		// transient task很有可能受优先级影响播不出, 这里不需要报错
		UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::SetScalarParameterByTransientTaskId, invalid task id %d"), TaskId);
		return;
	}

	auto& Task = TransientTasks[TaskId];

	const uint32 MaterialInstanceSetId = Task.MaterialInstanceSetId;
	SetScalarParameterBySetId(MaterialInstanceSetId, ParameterName, ParamVal);
	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::SetScalarParameterByTransientTaskId, SetScalarParameterBySetId, %d %s %f"),
		MaterialInstanceSetId, *ParameterName.ToString(), ParamVal);

	Task.AffectedScalarMaterialParamNames.AddUnique(ParameterName);
}

void UKGMaterialManager::RemoveTransientTaskByEffectType(TWeakObjectPtr<AActor> Actor, EKGMaterialEffectType EffectType)
{
	TArray<uint32, TInlineAllocator<4>> TaskIdsNeedToRemove;
	for (const auto& Kvp : TransientTasks)
	{
		if (Kvp.Value.EffectType == EffectType &&
			Kvp.Value.Actor == Actor)
		{
			TaskIdsNeedToRemove.Add(Kvp.Key);
		}
	}

	for (uint32 TaskId : TaskIdsNeedToRemove)
	{
		// 这里不删除 LifeTimeParamPriorityQueue, 因为这里删除的复杂度是O(n), 等tick过程中再删
		RemoveTransientTaskById(TaskId);
	}
}

void UKGMaterialManager::RemoveTransientTaskById(uint32 TaskId)
{
	if (!TransientTasks.Contains(TaskId))
	{
		return;
	}
	
	const auto& Task = TransientTasks[TaskId];
	if (auto MaterialInstanceSetPtr = MaterialInstancesSets.Find(Task.MaterialInstanceSetId))
	{
		for (auto& Kvp : *MaterialInstanceSetPtr)
		{
			auto MaterialInstance = Kvp.Key;
			if (MaterialInstance.IsValid())
			{
				UMaterialInstanceDynamic* MaterialInstanceDynamic = MaterialInstance.Get();
				BATCH_DMIPARAM_SCOPE(MaterialInstanceDynamic);
				
				for (const auto& ParamName : Task.AffectedScalarMaterialParamNames)
				{
					MaterialInstanceDynamic->RemoveScalarParameter(ParamName);
				}
			}
		}
	}	
	
	TransientTasks.Remove(TaskId);
}

void UKGMaterialManager::RemoveTransientTasksByActor(KGObjectID ActorID)
{
	TArray<uint32, TInlineAllocator<8>> TaskIdsNeedToRemove;
	for (const auto& Kvp : TransientTasks)
	{
		if (Kvp.Value.Actor.KGGetObjectID() == ActorID)
		{
			TaskIdsNeedToRemove.Add(Kvp.Key);
		}
	}

	for (uint32 TaskId : TaskIdsNeedToRemove)
	{
		// 这里不删除 LifeTimeParamPriorityQueue, 因为这里删除的复杂度是O(n), 等tick过程中再删
		RemoveTransientTaskById(TaskId);
	}
}

void UKGMaterialManager::UpdateTransientTasks()
{
	const double StartTime = FPlatformTime::Seconds();

	while (LifeTimeParamPriorityQueue.Num() > 0)
	{
		// 这里因为是排序好的 所以只要有一个不满足时间要求的, 后续的就都到没到超时时间
		if (LifeTimeParamPriorityQueue[0].TimeoutTimestamp > StartTime)
		{
			break;
		}

		FKGTransientMaterialParamUpdateTaskLifeTimeParams Params;
		LifeTimeParamPriorityQueue.HeapPop(Params);

		RemoveTransientTaskById(Params.TaskId);
	}
}

#pragma endregion TransientUpdateTask

#pragma region Debug

TArray<FString> UKGMaterialManager::KAPI_MaterialManager_GetMaterialParamDebugInfos(KGObjectID ActorID)
{
	TArray<FString> DebugInfos;
#if KG_ENABLE_MATERIAL_MANAGER_DEBUG
	AActor* Actor = KGUtils::GetActorByID(ActorID);
	if (!Actor)
	{
		return DebugInfos;
	}

	auto* ReqIdsPtr = ActorChangeMaterialParamReqIds.Find(ActorID);
	if (!ReqIdsPtr)
	{
		return DebugInfos;
	}

	for (const auto ReqId : *ReqIdsPtr)
	{
		auto* ContextPtr = ChangeMaterialParamContexts.Find(ReqId);
		if (!ContextPtr)
		{
			continue;
		}

		for (const auto& Kvp : ContextPtr->MaterialCacheKeyMapping)
		{
			if (!Kvp.Key.IsValid())
			{
				continue;
			}
			
			for (const auto MaterialCacheKey : Kvp.Value)
			{
				UMaterialInstanceDynamic* MaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(
					KGMaterialUtils::GetMaterialInstanceByMaterialCacheKey(Kvp.Key.Get(), MaterialCacheKey));

				const FString& ParamInfo = KGMaterialUtils::GetMaterialParamInfoDebugUsage(
					MaterialInstanceDynamic,
					ContextPtr->ModifiedScalarParamNames.Array(),
					ContextPtr->ModifiedVectorParamNames.Array(),
					ContextPtr->ModifiedTextureParamNames.Array());

				int32 MaterialInstance;
				bool bOutOverlayMaterial;
				bool bOutSeparateOverlayMaterial;
				bool bOutRuntimeSeparateOverlayMaterial;
				KGMaterialUtils::GetMaterialIndexInfoByCacheKey(
					MaterialCacheKey, MaterialInstance, bOutOverlayMaterial, bOutSeparateOverlayMaterial, bOutRuntimeSeparateOverlayMaterial);
				FName MaterialSlotName = *FString(TEXT("nil"));
				KGMaterialUtils::GetSlotNameByMaterialCacheKey(Kvp.Key.Get(), MaterialCacheKey, MaterialSlotName);
				DebugInfos.Add(FString::Printf(TEXT("%s, %d|%d|%d|%d|%s, [%s]"), *GetNameSafe(Kvp.Key.Get()), 
					MaterialInstance, bOutOverlayMaterial, bOutSeparateOverlayMaterial, bOutRuntimeSeparateOverlayMaterial, *MaterialSlotName.ToString(), *ParamInfo));
			}
		}
	}
#endif
	return DebugInfos;
}

#pragma endregion Debug
