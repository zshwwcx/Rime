#include "3C/Material/MaterialUpdateTask/MaterialUpdateTaskBindLocation.h"
#include "Components/SkeletalMeshComponent.h"
#include "3C/Core/KGUEActorManager.h"
#include "GameFramework/Character.h"

bool FKGMaterialActorLocationUpdateTask::Execute(float DeltaTime)
{
	if (!FKGMaterialParamUpdateTaskBase::Execute(DeltaTime))
	{
		return false;
	}
	
	if (!Actor.IsValid())
	{
		return false;
	}

	FVector AnchorPos = FVector::ZeroVector;
	if (LocationType == EKGMaterialParamActorLocationType::UseActorLocation)
	{
		AnchorPos = Actor->GetActorLocation();
	}
	else if (LocationType == EKGMaterialParamActorLocationType::UseActorMainMesh)
	{
		if (UMeshComponent* MeshComponent = GetAndCacheMeshComponent())
		{
			AnchorPos = MeshComponent->GetComponentLocation();
		}
		else
		{
			return false;
		}
	}
	else if (LocationType == EKGMaterialParamActorLocationType::UseSocketLocation)
	{
		if (UMeshComponent* MeshComponent = GetAndCacheMeshComponent())
		{
			AnchorPos = MeshComponent->GetSocketLocation(SocketName);
		}
		else
		{
			return false;
		}
	}
	else
	{
		return false;
	}

	AnchorPos += RelativePosOffset;

	if (AnchorPos.ContainsNaN())
	{
		UE_LOG(LogKGMaterial, Error,
			TEXT("FKGMaterialActorLocationUpdateTask::Execute, invalid anchor pos, RelativePosOffset: %s, LocationType: %d, Actor: %s"),
			*RelativePosOffset.ToString(), LocationType, *Actor->GetName());
		return false;
	}
	
	SetVectorParameterValue(AnchorPos);
	return true;
}

UMeshComponent* FKGMaterialActorLocationUpdateTask::GetAndCacheMeshComponent()
{
	if (CachedMeshComponent.IsValid())
	{
		return CachedMeshComponent.Get();
	}
	
	if (!Actor.IsValid())
	{
		return nullptr;
	}
	
	if (ACharacter* Character = Cast<ACharacter>(Actor))
	{
		CachedMeshComponent = Character->GetMesh();
	}
	
	if (!CachedMeshComponent.IsValid())
	{
		CachedMeshComponent = Actor->GetComponentByClass<UMeshComponent>();
	}
	
	return CachedMeshComponent.Get();
}

bool FKGMaterialEntityLocationUpdateTask::Execute(float DeltaTime)
{
	if (!FKGMaterialParamUpdateTaskBase::Execute(DeltaTime))
	{
		return false;
	}
	
	if (!ActorManager.IsValid())
	{
		return false;
	}

	auto* Entity = ActorManager->GetLuaEntity(EntityID);
	if (!Entity)
	{
		return false;
	}
	
	SetVectorParameterValue(Entity->GetLocation());

	return true;
}