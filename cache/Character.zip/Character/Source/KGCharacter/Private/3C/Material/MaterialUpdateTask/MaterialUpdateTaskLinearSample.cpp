﻿#include "3C/Material/MaterialUpdateTask/MaterialUpdateTaskLinearSample.h"

bool FKGMaterialLinearSampleUpdateTask::Execute(float DeltaTime)
{
	if (!FKGMaterialParamUpdateTaskBase::Execute(DeltaTime))
	{
		return false;
	}
		
	AccumulatedTime += DeltaTime;
	AccumulatedTime = FMath::Min(Duration, AccumulatedTime);

	// 加入是已经做过判定, 这里直接check
	check(!FMath::IsNearlyZero(Duration, UE_KINDA_SMALL_NUMBER));
	if (ValueType == EFKGMaterialLinearSampleValueType::Scalar)
	{
		float ParamVal = StartVal.GetSubtype<float>() + (EndVal.GetSubtype<float>() - StartVal.GetSubtype<float>()) * AccumulatedTime / Duration;
		CurVal.SetSubtype<float>(ParamVal);
		SetScalarParameterValue(ParamVal);	
	}
	else if (ValueType == EFKGMaterialLinearSampleValueType::LinearColor)
	{
		const FLinearColor ParamVal = StartVal.GetSubtype<FLinearColor>() + (
			EndVal.GetSubtype<FLinearColor>() - StartVal.GetSubtype<FLinearColor>()) * AccumulatedTime / Duration;
		CurVal.SetSubtype<FLinearColor>(ParamVal);
		SetVectorParameterValue(ParamVal);	
	}

	if (AccumulatedTime >= Duration && !bIsFinished)
	{
		bIsFinished = true;
	}

	return true;
}

bool FKGMaterialLinearBlendUpdateTask::Execute(float DeltaTime)
{
	if (!FKGMaterialParamUpdateTaskBase::Execute(DeltaTime))
	{
		return false;
	}

	AccumulatedTime += DeltaTime;
	AccumulatedTime = FMath::Min(Duration, AccumulatedTime);
	
	float BlendAlpha;
	if (AccumulatedTime < BlendInTime && !FMath::IsNearlyZero(BlendInTime))
	{
		BlendAlpha = AccumulatedTime / BlendInTime;
	}
	else if (AccumulatedTime > Duration - BlendOutTime)
	{
		if (FMath::IsNearlyZero(BlendOutTime))
		{
			BlendAlpha = 0.0f;
		}
		else
		{
			BlendAlpha = (Duration - AccumulatedTime) / BlendOutTime;
		}
	}
	else
	{
		BlendAlpha = 1.0f;
	}

	BlendAlpha = FMath::Clamp(BlendAlpha, 0.0f, 1.0f);
	
	// 加入是已经做过判定, 这里直接check
	check(!FMath::IsNearlyZero(Duration, UE_KINDA_SMALL_NUMBER));
	if (ValueType == EFKGMaterialLinearSampleValueType::Scalar)
	{
		float ParamVal = StartVal.GetSubtype<float>() + (EndVal.GetSubtype<float>() - StartVal.GetSubtype<float>()) * BlendAlpha;
		SetScalarParameterValue(ParamVal);	
	}
	else if (ValueType == EFKGMaterialLinearSampleValueType::LinearColor)
	{
		const FLinearColor ParamVal = StartVal.GetSubtype<FLinearColor>() + (
			EndVal.GetSubtype<FLinearColor>() - StartVal.GetSubtype<FLinearColor>()) * BlendAlpha;
		SetVectorParameterValue(ParamVal);	
	}

	if (AccumulatedTime >= Duration && !bIsFinished)
	{
		bIsFinished = true;
	}
	
	return true;
}