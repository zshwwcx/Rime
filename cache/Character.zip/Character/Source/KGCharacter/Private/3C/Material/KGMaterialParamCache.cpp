#include "3C/Material/KGMaterialParamCache.h"

#include "Manager/KGCppAssetManager.h"
#include "3C/Core/KGUEActorManager.h"
#include "3C/Material/KGMaterialManager.h"
#include "Curves/CurveLinearColor.h"
#include "GameFramework/Character.h"
#include "Kismet/KismetMaterialLibrary.h"
#include "Components/SkeletalMeshComponent.h"
#include "3C/Util/KGUtils.h"
#include "3C/Material/MaterialUpdateTask/MaterialUpdateTaskBindLocation.h"
#include "3C/Material/MaterialUpdateTask/MaterialUpdateTaskCurve.h"
#include "3C/Material/MaterialUpdateTask/MaterialUpdateTaskLinearSample.h"

static uint32 InnerTaskID = 0;
static TMap<FName, float> EmptyScalarParamMap;
static TMap<FName, FLinearColor> EmptyVectorParamMap;
static TMap<FName, UTexture*> EmptyTextureParamMap;

bool GDebugShowRoleCompositeParam = false;
static FAutoConsoleVariableRef CVarDebugShowRoleCompositeParam(
	TEXT("gp.DebugShowRoleCompositeParam"),
	GDebugShowRoleCompositeParam,
	TEXT("DebugShowRoleCompositeParam."),
	ECVF_Default
);

FString FKGMaterialParamUpdateTarget::ToString() const
{
	if (MaterialInstanceSetId.IsSet())
	{
		return FString::Printf(TEXT("MaterialInstanceSetId: %d"), MaterialInstanceSetId.GetValue());
	}

	if (!MaterialParameterCollectionAssetPath.IsEmpty())
	{
		return MaterialParameterCollectionAssetPath;
	}

	if (MaterialParameterCollection.IsValid())
	{
		return MaterialParameterCollection->GetName();
	}

	return FString::JoinBy(MaterialInstances, TEXT(", "), [](const TWeakObjectPtr<UMaterialInstanceDynamic>& MaterialInstance)
	{
		return KGMaterialUtils::GetMaterialInfoDebugUsage(MaterialInstance.Get());
	});
}

void FKGMaterialParamController::Update(float DeltaTime)
{
	TArray<uint32, TInlineAllocator<4>> FinishedTaskIds;
	for (const auto& Kvp : UpdateTasks)
	{
		const auto& Task = Kvp.Value;
		if (!Task.IsValid() || Task->bPaused)
		{
			continue;
		}
		
		float DeltaTimeScaled = DeltaTime;
		if (Task->bFollowSlomo && Task->OwnerActor.IsValid())
		{
			DeltaTimeScaled *= Task->OwnerActor->CustomTimeDilation;
		}
		
		Task->Execute(DeltaTimeScaled);
		if (Task->IsFinished() && Task->IsAutoStop())
		{
			Task->OnTaskEnd();
			FinishedTaskIds.Add(Kvp.Key);
		}
	}

	for (const auto FinishedTaskId : FinishedTaskIds)
	{
		UpdateTasks.Remove(FinishedTaskId);
	}
}

void FKGMaterialParamController::AddNewItemToPriorityQueue(const FKGChangeMaterialParamContext& Context)
{
	const auto& Request = Context.ChangeMaterialParamRequest;
	auto& PriorityQueueSet = PriorityQueueSets.FindOrAdd(Request.OwnerActor.KGGetObjectID());
	auto& PriorityQueue = PriorityQueueSet.PriorityQueues.FindOrAdd(Request.EffectType);
	auto& PriorityQueueItems = PriorityQueue.PriorityQueueItems;

	FKGMaterialParamPriorityQueueItem NewItem;
	NewItem.Priority = Request.Priority;
	NewItem.ReqId = Context.ReqId;
	NewItem.SequenceId = Context.SequenceId;

	uint32 OldEffectiveReqId = 0;
	if (PriorityQueueItems.Num() > 0)
	{
		OldEffectiveReqId = PriorityQueueItems[0].ReqId;
	}
	
	PriorityQueueItems.HeapPush(NewItem);

	uint32 NewEffectiveReqId = PriorityQueueItems[0].ReqId;
	if (OldEffectiveReqId != NewEffectiveReqId)
	{
		if (KGMaterialManager.IsValid())
		{
			if (OldEffectiveReqId != 0)
			{
				KGMaterialManager->DeactivateMaterialParams(OldEffectiveReqId);
			}

			KGMaterialManager->ActivateOrSetMaterialParams(NewEffectiveReqId);
		}
		else
		{
			UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamController::AddNewItemToPriorityQueue, invalid material manager"));
		}
	}
}

void FKGMaterialParamController::RemoveItemInPriorityQueue(const FKGChangeMaterialParamContext& Context, bool bRevertMaterialParams)
{
	const auto& Request = Context.ChangeMaterialParamRequest;
	auto* PriorityQueueSetPtr = PriorityQueueSets.Find(Request.OwnerActor.KGGetObjectID());
	if (PriorityQueueSetPtr == nullptr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamController::RemoveItemInPriorityQueue, invalid priority queue set, %s,"), 
			*Context.ToString());
		return;
	}
	
	auto* PriorityQueuePtr = PriorityQueueSetPtr->PriorityQueues.Find(Request.EffectType);
	if (PriorityQueuePtr == nullptr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamController::RemoveItemInPriorityQueue, invalid priority queue, %s,"), 
			*Context.ToString());
		return;
	}
	
	auto& PriorityQueueItems = PriorityQueuePtr->PriorityQueueItems;
	if (PriorityQueueItems.Num() == 0)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamController::RemoveItemInPriorityQueue, invalid priority items, %s,"), 
			*Context.ToString());
		return;
	}

	const uint32 OldEffectiveReqId = PriorityQueueItems[0].ReqId;
	for (int32 i = 0; i < PriorityQueueItems.Num(); ++i)
	{
		if (PriorityQueueItems[i].ReqId == Context.ReqId)
		{
			PriorityQueueItems.HeapRemoveAt(i);
			break;
		}
	}

	uint32 NewEffectiveReqId = 0;
	if (PriorityQueueItems.Num() > 0)
	{
		NewEffectiveReqId = PriorityQueueItems[0].ReqId;
	}

	if (KGMaterialManager.IsValid())
	{
		if (bRevertMaterialParams)
		{
			if (OldEffectiveReqId == Context.ReqId)
			{
				KGMaterialManager->SetAllMaterialParamsToDefault(Context);
			}

			KGMaterialManager->RemoveMaterialInstanceSet(Context.MaterialInstanceSetId);

			if (OldEffectiveReqId != NewEffectiveReqId && NewEffectiveReqId != 0)
			{
				KGMaterialManager->ActivateOrSetMaterialParams(NewEffectiveReqId);
			}
		}
		else
		{
			KGMaterialManager->RemoveMaterialInstanceSet(Context.MaterialInstanceSetId);
		}
	}
	else
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamController::RemoveItemInPriorityQueue, invalid material manager"));
	}
}

bool FKGMaterialParamController::HasItemInPriorityQueue(TWeakObjectPtr<AActor> Actor, EKGMaterialEffectType EffectType)
{
	uint32 ReqIdUnused;
	return GetActiveReqIdInPriorityQueue(Actor, EffectType, ReqIdUnused);
}

bool FKGMaterialParamController::GetActiveReqIdInPriorityQueue(TWeakObjectPtr<AActor> Actor, EKGMaterialEffectType EffectType, uint32& OutReqId)
{
	auto* PriorityQueueSetPtr = PriorityQueueSets.Find(Actor.KGGetObjectID());
    if (PriorityQueueSetPtr == nullptr)
    {
    	return false;
    }
    
    auto* PriorityQueuePtr = PriorityQueueSetPtr->PriorityQueues.Find(EffectType);
    if (PriorityQueuePtr == nullptr)
    {
    	return false;
    }

    if (PriorityQueuePtr->PriorityQueueItems.Num() == 0)
    {
    	return false;
    }

	OutReqId = PriorityQueuePtr->PriorityQueueItems[0].ReqId;
	return true;
}

void FKGMaterialParamController::SetRoleCompositeScalarMaterialParams(
	UMeshComponent* MeshComponent, int32 MaterialIndex, bool bOverlayMaterial, bool bSeparateOverlayMaterial, const TMap<FName, float>& Params)
{
	InternalSetRoleCompositeScalarMaterialParams(
		MeshComponent, MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, Params, EmptyVectorParamMap, EmptyTextureParamMap);
}

void FKGMaterialParamController::SetRoleCompositeVectorMaterialParams(
	UMeshComponent* MeshComponent, int32 MaterialIndex, bool bOverlayMaterial, bool bSeparateOverlayMaterial, const TMap<FName, FLinearColor>& Params)
{
	InternalSetRoleCompositeScalarMaterialParams(
		MeshComponent, MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, EmptyScalarParamMap, Params, EmptyTextureParamMap);
}

void FKGMaterialParamController::SetRoleCompositeTextureMaterialParams(
	UMeshComponent* MeshComponent, int32 MaterialIndex, bool bOverlayMaterial, bool bSeparateOverlayMaterial, const TMap<FName, UTexture*>& Params)
{
	InternalSetRoleCompositeScalarMaterialParams(
		MeshComponent, MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, EmptyScalarParamMap, EmptyVectorParamMap, Params);
}

void FKGMaterialParamController::ClearMeshRoleCompositeParamCache(UMeshComponent* MeshComponent)
{
	if (!MeshComponent)
	{
		return;
	}

	const auto MeshComponentID = KGUtils::GetIDByObject(MeshComponent);
	RoleCompositeParamCaches.Remove(MeshComponentID);
}

void FKGMaterialParamController::ClearActorRoleCompositeParamCache(KGObjectID ActorID)
{
	if (!ParamCacheActorIDToMeshComponentIDs.Contains(ActorID))
	{
		return;
	}

	for (const auto MeshCompID : ParamCacheActorIDToMeshComponentIDs[ActorID])
	{
		if (UMeshComponent* MeshComp = KGUtils::GetObjectByID<UMeshComponent>(MeshCompID))
		{
			ClearMeshRoleCompositeParamCache(MeshComp);
		}
	}
	ParamCacheActorIDToMeshComponentIDs.Remove(ActorID);
}

const FKGMaterialRoleCompositeParamCache* FKGMaterialParamController::GetRoleCompositeParamCachePtr(UMeshComponent* MeshComponent, KGMaterialCacheKey MaterialCacheKey)
{
	if (!MeshComponent)
	{
		return nullptr;
	}

	auto* MeshParamCachePtr = RoleCompositeParamCaches.Find(KGUtils::GetIDByObject(MeshComponent));
	if (!MeshParamCachePtr)
	{
		return nullptr;
	}

	return MeshParamCachePtr->MaterialParamCaches.Find(MaterialCacheKey);
}

TArray<FString> FKGMaterialParamController::GetRoleCompositeMaterialParamCacheDebugInfos(KGObjectID ActorID)
{
	TArray<FString> DebugInfos;
#if KG_ENABLE_MATERIAL_MANAGER_DEBUG
	if (!GDebugShowRoleCompositeParam)
	{
		// 参数比较多, 可能会比较卡, 这里默认不开启
		return DebugInfos;
	}
	
	if (!ParamCacheActorIDToMeshComponentIDs.Contains(ActorID))
	{
		return DebugInfos;
	}
	
	for (const auto MeshCompID : ParamCacheActorIDToMeshComponentIDs[ActorID])
	{
		UMeshComponent* MeshComp = KGUtils::GetObjectByID<UMeshComponent>(MeshCompID);
		if (!MeshComp)
		{
			continue;
		}

		auto* MeshParamCachePtr = RoleCompositeParamCaches.Find(MeshCompID);
		if (!MeshParamCachePtr)
		{
			continue;
		}

		for (const auto& Kvp : MeshParamCachePtr->MaterialParamCaches)
		{
			const int32 MaterialCacheKey = Kvp.Key;
			UMaterialInstanceDynamic* MaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(
				KGMaterialUtils::GetMaterialInstanceByMaterialCacheKey(MeshComp, MaterialCacheKey));

			int32 MaterialIndex = 0;
			bool bOverlayMaterial = false;
			bool bSeparateOverlayMaterial = false;
			bool bRuntimeSeparateOverlayMaterial = false;
			KGMaterialUtils::GetMaterialIndexInfoByCacheKey(
				MaterialCacheKey, MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, bRuntimeSeparateOverlayMaterial);

			TArray<FName> ScalarNames;
			Kvp.Value.ScalarParams.GetKeys(ScalarNames);
			TArray<FName> VectorNames;
			Kvp.Value.VectorParams.GetKeys(VectorNames);
			TArray<FName> TextureNames;
			Kvp.Value.TextureParams.GetKeys(TextureNames);
			const FString& ParamInfo = KGMaterialUtils::GetMaterialParamInfoDebugUsage(MaterialInstanceDynamic, ScalarNames, VectorNames, TextureNames);
			FName MaterialSlotName = *FString(TEXT("nil"));
			KGMaterialUtils::GetSlotNameByMaterialCacheKey(MeshComp, MaterialCacheKey, MaterialSlotName);
			DebugInfos.Add(FString::Printf(TEXT("%s, %d|%d|%d|%d|%s, [%s]"), *GetNameSafe(MeshComp), 
				MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, bRuntimeSeparateOverlayMaterial, *MaterialSlotName.ToString(), *ParamInfo));
		}
	}
#endif
	return DebugInfos;
}

bool FKGMaterialParamController::GetScalarRoleCompositeParamCache(
	UMeshComponent* MeshComponent, int32 MaterialIndex, bool bOverlayMaterial, bool bSeparateOverlayMaterial, const FName& ParamName, float& OutVal)
{
	if (!MeshComponent)
	{
		return false;
	}

	auto* MeshParamCachePtr = RoleCompositeParamCaches.Find(KGUtils::GetIDByObject(MeshComponent));
	if (!MeshParamCachePtr)
	{
		return false;
	}

	const auto MaterialCacheKey = KGMaterialUtils::GetMaterialCacheKey(MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, false);
	auto* MaterialParamCachePtr = MeshParamCachePtr->MaterialParamCaches.Find(MaterialCacheKey);
	if (!MaterialParamCachePtr)
	{
		return false;
	}

	if (!MaterialParamCachePtr->ScalarParams.Contains(ParamName))
	{
		return false;
	}

	OutVal = MaterialParamCachePtr->ScalarParams[ParamName];
	return true;
}

bool FKGMaterialParamController::GetVectorRoleCompositeParamCache(
	UMeshComponent* MeshComponent, int32 MaterialIndex, bool bOverlayMaterial, bool bSeparateOverlayMaterial, const FName& ParamName, FLinearColor& OutVal)
{
	if (!MeshComponent)
	{
		return false;
	}

	auto* MeshParamCachePtr = RoleCompositeParamCaches.Find(KGUtils::GetIDByObject(MeshComponent));
	if (!MeshParamCachePtr)
	{
		return false;
	}

	const auto MaterialCacheKey = KGMaterialUtils::GetMaterialCacheKey(MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, false);
	auto* MaterialParamCachePtr = MeshParamCachePtr->MaterialParamCaches.Find(MaterialCacheKey);
	if (!MaterialParamCachePtr)
	{
		return false;
	}

	if (!MaterialParamCachePtr->VectorParams.Contains(ParamName))
	{
		return false;
	}

	OutVal = MaterialParamCachePtr->VectorParams[ParamName];
	return true;
}

bool FKGMaterialParamController::GetTextureRoleCompositeParamCache(
	UMeshComponent* MeshComponent, int32 MaterialIndex, bool bOverlayMaterial, bool bSeparateOverlayMaterial, const FName& ParamName, UTexture*& OutVal)
{
	if (!MeshComponent)
	{
		return false;
	}

	auto* MeshParamCachePtr = RoleCompositeParamCaches.Find(KGUtils::GetIDByObject(MeshComponent));
	if (!MeshParamCachePtr)
	{
		return false;
	}

	const auto MaterialCacheKey = KGMaterialUtils::GetMaterialCacheKey(MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, false);
	auto* MaterialParamCachePtr = MeshParamCachePtr->MaterialParamCaches.Find(MaterialCacheKey);
	if (!MaterialParamCachePtr)
	{
		return false;
	}

	if (!MaterialParamCachePtr->TextureParams.Contains(ParamName))
	{
		return false;
	}

	auto TexturePtr = MaterialParamCachePtr->TextureParams[ParamName];
	OutVal = TexturePtr.Get();
	return true;
}

uint32 FKGMaterialParamController::AddVectorLinearSampleParam(
    const FKGCommonMaterialParamUpdateParams& Params, const FLinearColor& InStartVal, const FLinearColor& InEndVal, float Duration)
{
	if (FVector4(InStartVal).ContainsNaN() || FVector4(InEndVal).ContainsNaN())
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::AddVectorLinearSampleParam, start val or end val contains NaN, %s, %s"), 
			*InStartVal.ToString(), *InEndVal.ToString());
		return 0;
	}
	
	if (InStartVal.Equals(InEndVal, UE_KINDA_SMALL_NUMBER))
	{
		UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::AddVectorLinearSampleParam, no need to use tick"));
		return 0;
	}

	if (FMath::IsNearlyZero(Duration, UE_KINDA_SMALL_NUMBER))
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::AddVectorLinearSampleParam, invalid duration"));
		return 0;
	}

	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::AddVectorLinearSampleParam, %s, %s, %s, %f, Target: %s"),
		*Params.ParamName.ToString(), *InStartVal.ToString(), *InEndVal.ToString(), Duration, *Params.MaterialParamUpdateTarget.ToString());
	
	TSharedPtr<FKGMaterialLinearSampleUpdateTask> UpdateTask = MakeShared<FKGMaterialLinearSampleUpdateTask>(
		Params, KGMaterialManager, InStartVal, InEndVal, EFKGMaterialLinearSampleValueType::LinearColor, Duration);

	const auto TaskID = KGMaterialUtils::GenerateIncId(InnerTaskID);
	UpdateTasks.Add(TaskID, UpdateTask);
	TryLoadMaterialParameterCollectionAsset(UpdateTask->MaterialParamUpdateTarget, TaskID);
	if (Params.bActivateImmediately)
	{
		UpdateTask->Execute(0.0f);
	}
	return TaskID;
}

uint32 FKGMaterialParamController::AddScalarLinearSampleParam(
	const FKGCommonMaterialParamUpdateParams& Params, float StartVal, float EndVal, float Duration)
{
	if (FMath::IsNearlyEqual(StartVal, EndVal))
	{
		UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::AddLinearSampleParam, no need to use tick"));
		return 0;
	}

	if (FMath::IsNearlyZero(Duration, UE_KINDA_SMALL_NUMBER))
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::AddLinearSampleParam, invalid duration"));
		return 0;
	}

	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::AddScalarLinearSampleParam, %s, %f, %f, %f, Target: %s"),
		*Params.ParamName.ToString(), StartVal, EndVal, Duration, *Params.MaterialParamUpdateTarget.ToString());
	
	TSharedPtr<FKGMaterialLinearSampleUpdateTask> UpdateTask = MakeShared<FKGMaterialLinearSampleUpdateTask>(
		Params, KGMaterialManager, StartVal, EndVal, EFKGMaterialLinearSampleValueType::Scalar, Duration);

	const auto TaskID = KGMaterialUtils::GenerateIncId(InnerTaskID);
	UpdateTasks.Add(TaskID, UpdateTask);
	TryLoadMaterialParameterCollectionAsset(UpdateTask->MaterialParamUpdateTarget, TaskID);
	if (Params.bActivateImmediately)
	{
		UpdateTask->Execute(0.0f);
	}
	return TaskID;
}

uint32 FKGMaterialParamController::AddCurveParam(
	const FKGCommonMaterialParamUpdateParams& Params, UCurveBase* Curve, bool bNeedRemap, float RemapTime, bool bLoop)
{
	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::AddCurveParam, %s, %s, %d, %f, %d, Target: %s"),
		*Params.ParamName.ToString(), *GetNameSafe(Curve), bNeedRemap, RemapTime, bLoop, *Params.MaterialParamUpdateTarget.ToString());

	FKGCurveEvalParams CurveEvalParams;
	CurveEvalParams.InitEvalParams(Curve, bNeedRemap, RemapTime, bLoop);
	
	TSharedPtr<FKGMaterialCurveParams> UpdateTask = MakeShared<FKGMaterialCurveParams>(Params, KGMaterialManager, CurveEvalParams);

	const auto TaskID = KGMaterialUtils::GenerateIncId(InnerTaskID);
	UpdateTasks.Add(TaskID, UpdateTask);
	TryLoadMaterialParameterCollectionAsset(UpdateTask->MaterialParamUpdateTarget, TaskID);
	if (Params.bActivateImmediately)
	{
		UpdateTask->Execute(0.0f);
	}
	return TaskID;
}

uint32 FKGMaterialParamController::AddCurveParamByCurvePath(
	const FKGCommonMaterialParamUpdateParams& Params, const FString& CurvePath, bool bNeedRemap, float RemapTime, bool bLoop)
{
	UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(KGMaterialManager.Get());
	if (!AssetManager)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamController::AddCurveParamByCurvePath, cannot find asset manager"));
		return 0;
	}

	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::AddCurveParamByCurvePath, %s, %s, %d, %f, %d, Target: %s"),
		*Params.ParamName.ToString(), *CurvePath, bNeedRemap, RemapTime, bLoop, *Params.MaterialParamUpdateTarget.ToString());

	uint32 TaskID = AddCurveParam(Params, nullptr, bNeedRemap, RemapTime, bLoop);
	
	auto* UpdateTaskPtr = UpdateTasks.Find(TaskID);
	if (UpdateTaskPtr == nullptr || !UpdateTaskPtr->IsValid())
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamController::AddCurveParamByCurvePath, invalid update task id, %d"), TaskID);
		return 0;
	}

	auto& UpdateTask = *UpdateTaskPtr;
	if (UpdateTask->GetTaskType() != EKGMaterialParamUpdateTaskType::Curve)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamController::AddCurveParamByCurvePath, invalid update task type, %d, %d"),
			TaskID, UpdateTask->GetTaskType());
		return 0;
	}

	FKGMaterialCurveParams* TaskPtr = StaticCast<FKGMaterialCurveParams*>(UpdateTask.Get());
	int AssetLoadID = AssetManager->AsyncLoadAsset(CurvePath,
		FAsyncLoadCompleteDelegate::CreateRaw(this, &FKGMaterialParamController::InternalOnCurveAssetLoaded, TaskID));
	TaskPtr->CurveAssetLoadID = AssetLoadID;
	TaskPtr->CurvePath = CurvePath;
	TaskPtr->bLoop = bLoop;
	if (bNeedRemap)
	{
		TaskPtr->RemapTime = RemapTime;
	}

	return TaskID;
}

uint32 FKGMaterialParamController::AddActorLocationParamSimple(const FKGCommonMaterialParamUpdateParams& Params, AActor* InActor)
{
	return AddActorLocationParam(Params, InActor, EKGMaterialParamActorLocationType::UseActorLocation, FVector::Zero(), NAME_None);
}

uint32 FKGMaterialParamController::AddActorLocationParam(
	const FKGCommonMaterialParamUpdateParams& Params, AActor* InActor, EKGMaterialParamActorLocationType LocationType, const FVector& RelativePos,
	const FName& SocketName)
{
	if (!IsValid(InActor))
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamController::AddActorLocationParam, invalid actor"));
		return 0;
	}

	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::AddActorLocationParam, %s, %s, %s, Target: %s"),
		*Params.ParamName.ToString(), *InActor->GetName(), *SocketName.ToString(), *Params.MaterialParamUpdateTarget.ToString());

	TSharedPtr<FKGMaterialActorLocationUpdateTask> UpdateTask = MakeShared<FKGMaterialActorLocationUpdateTask>(
		Params, KGMaterialManager, InActor, LocationType, RelativePos, SocketName);
	
	const auto TaskID = KGMaterialUtils::GenerateIncId(InnerTaskID);
	UpdateTasks.Add(TaskID, UpdateTask);
	TryLoadMaterialParameterCollectionAsset(UpdateTask->MaterialParamUpdateTarget, TaskID);
	return TaskID;
}

uint32 FKGMaterialParamController::AddEntityLocationParam(const FKGCommonMaterialParamUpdateParams& Params, KGEntityID EntityID)
{
	if (EntityID == KG_INVALID_ENTITY_ID)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamController::AddEntityLocationParam, invalid entity id"));
		return 0;
	}

	UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(KGMaterialManager.Get());
	if (ActorManager == nullptr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamController::AddEntityLocationParam, invalid ActorManager"));
		return 0;
	}
	
	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::AddEntityLocationParam, %s, %lld, Target: %s"),
		*Params.ParamName.ToString(), EntityID, *Params.MaterialParamUpdateTarget.ToString());

	TSharedPtr<FKGMaterialEntityLocationUpdateTask> UpdateTask = MakeShared<FKGMaterialEntityLocationUpdateTask>(
		Params, KGMaterialManager, EntityID, ActorManager);
	
	const auto TaskID = KGMaterialUtils::GenerateIncId(InnerTaskID);
	UpdateTasks.Add(TaskID, UpdateTask);
	TryLoadMaterialParameterCollectionAsset(UpdateTask->MaterialParamUpdateTarget, TaskID);
	return TaskID;
}

uint32 FKGMaterialParamController::AddLinearBlendParam(
	const FKGCommonMaterialParamUpdateParams& Params, float StartVal, float EndVal, float BlendInTime, float BlendOutTime, float Duration)
{
	if (BlendInTime + BlendOutTime > Duration)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::AddLinearBlendParam, invalid blend in/out time, %f + %f > %f"),
			BlendInTime, BlendOutTime, Duration);
		return 0;
	}

	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::AddLinearBlendParam, %s, %f -> %f, %f,%f,%f, Target: %s"),
		*Params.ParamName.ToString(), StartVal, EndVal, BlendInTime, BlendOutTime, Duration, *Params.MaterialParamUpdateTarget.ToString());
	
	TSharedPtr<FKGMaterialLinearBlendUpdateTask> UpdateTask = MakeShared<FKGMaterialLinearBlendUpdateTask>(
		Params, KGMaterialManager, StartVal, EndVal, BlendInTime, BlendOutTime, EFKGMaterialLinearSampleValueType::Scalar, Duration);

	const auto TaskID = KGMaterialUtils::GenerateIncId(InnerTaskID);
	UpdateTasks.Add(TaskID, UpdateTask);
	TryLoadMaterialParameterCollectionAsset(UpdateTask->MaterialParamUpdateTarget, TaskID);
	if (Params.bActivateImmediately)
	{
		UpdateTask->Execute(0.0f);
	}
	return TaskID;
}

uint32 FKGMaterialParamController::AddScalarRuntimeCurveParam(const FKGCommonMaterialParamUpdateParams& Params, 
	const FRuntimeFloatCurve& RuntimeFloatCurve, bool bNeedRemap, float RemapTime, bool bLoop)
{
	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::AddScalarRuntimeCurveParam, %s, %d, %f, %d, Target: %s"),
		*Params.ParamName.ToString(), bNeedRemap, RemapTime, bLoop, *Params.MaterialParamUpdateTarget.ToString());
	
	auto* RichCurve = RuntimeFloatCurve.GetRichCurveConst();
	if (RichCurve == nullptr)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::AddScalarRuntimeCurveParam, invalid rich curve"));
		return 0;
	}
	
	if (RichCurve->GetNumKeys() == 0)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::AddScalarRuntimeCurveParam, empty rich curve"));
		return 0;
	}
	
	TSharedPtr<FKGMaterialScalarRuntimeCurveParams> UpdateTask = MakeShared<FKGMaterialScalarRuntimeCurveParams>(
		Params, KGMaterialManager, RuntimeFloatCurve, bNeedRemap, RemapTime, bLoop);
	const auto TaskID = KGMaterialUtils::GenerateIncId(InnerTaskID);
	UpdateTasks.Add(TaskID, UpdateTask);
	TryLoadMaterialParameterCollectionAsset(UpdateTask->MaterialParamUpdateTarget, TaskID);
	if (Params.bActivateImmediately)
	{
		UpdateTask->Execute(0.0f);
	}
	return TaskID;
}

uint32 FKGMaterialParamController::UpdateOrAddLinearSampleParamTargetValue(
	uint32 TaskId, const FKGCommonMaterialParamUpdateParams& Params, float OriginStartVal, float OriginEndVal, float OriginDuration,
	float OriginTargetVal, float TargetVal, bool bUseNewDuration, float InNewDuration)
{
	if (!bUseNewDuration && FMath::IsNearlyEqual(OriginEndVal, OriginStartVal, UE_KINDA_SMALL_NUMBER))
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::UpdateOrAddLinearSampleParamTargetValue, invalid origin start/end val"));
		return 0;
	}
	
	auto* ExistingTaskPtr = UpdateTasks.Find(TaskId);
	if (ExistingTaskPtr != nullptr && ExistingTaskPtr->IsValid())
	{
		auto& Task = *ExistingTaskPtr;
		if (Task->GetTaskType() != EKGMaterialParamUpdateTaskType::LinearSample)
		{
			UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::UpdateOrAddLinearSampleParamTargetValue, invalid task type, %d, %d"), 
				TaskId, Task->GetTaskType());
			return 0;
		}
		
		FKGMaterialLinearSampleUpdateTask* TaskPtr = StaticCast<FKGMaterialLinearSampleUpdateTask*>(Task.Get());
		float NewDuration = InNewDuration;
		if (!bUseNewDuration)
		{
			float CurVal = OriginStartVal;
			if (TaskPtr->CurVal.HasSubtype<float>())
			{
				CurVal = TaskPtr->CurVal.GetSubtype<float>();
			}
			else if (TaskPtr->StartVal.HasSubtype<float>())
			{
				// 还没执行过第一次tick
				CurVal = TaskPtr->StartVal.GetSubtype<float>();
			}
			NewDuration = FMath::Abs((TargetVal - CurVal) / (OriginEndVal - OriginStartVal)) * OriginDuration;
		}
		
		TaskPtr->StartVal = TaskPtr->CurVal;
		TaskPtr->EndVal.SetSubtype<float>(TargetVal);
		TaskPtr->AccumulatedTime = 0;
		// 有可能这里设置TargetVal为CurVal, 实际只需要再tick一次就可以了, 此时NewDuration为0是合理的
		TaskPtr->Duration = FMath::Max(NewDuration, 1e-3);
		TaskPtr->bIsFinished = false;
		return TaskId;
	}

	// 没有task时按照材质参数已经到OriginTargetVal来处理
	float NewDuration = bUseNewDuration ? InNewDuration : (FMath::Abs((TargetVal - OriginTargetVal) / (OriginEndVal - OriginStartVal)) * OriginDuration);
	NewDuration = FMath::Max(NewDuration, 1e-3);
	return AddScalarLinearSampleParam(Params, OriginTargetVal, TargetVal, NewDuration);
}

void FKGMaterialParamController::RemoveMaterialParamUpdateTask(uint32 TaskId, bool bSkipMaterialParamRevert)
{
	auto* TaskPtr = UpdateTasks.Find(TaskId);
	if (TaskPtr != nullptr && TaskPtr->IsValid())
	{
		auto& Task = *TaskPtr;
		if (bSkipMaterialParamRevert)
		{
			Task->bRevertToDefaultValueOnTaskEnd = false;
		}
		Task->OnTaskEnd();
		UpdateTasks.Remove(TaskId);
	}
}

void FKGMaterialParamController::PauseMaterialParamUpdateTask(uint32 TaskId)
{
	InternalPauseTask(TaskId, true);
}

void FKGMaterialParamController::ResumeMaterialParamUpdateTask(uint32 TaskId)
{
	InternalPauseTask(TaskId, false);
}

void FKGMaterialParamController::AdvanceUpdateTask(uint32 TaskID, float DeltaTime)
{
	if (DeltaTime < UE_KINDA_SMALL_NUMBER)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("FKGMaterialParamController::AdvanceUpdateTask, invalid delta time"));
		return;
	}
	
	auto* TaskPtr = UpdateTasks.Find(TaskID);
	if (!TaskPtr)
	{
		return;
	}
	
	auto& Task = *TaskPtr;
	if (!Task.IsValid())
	{
		return;
	}
	
	Task->AdvanceUpdateTask(DeltaTime);
}

void FKGMaterialParamController::UpdateTaskMaterialInstanceSetID(uint32 TaskId, uint32 MaterialInstanceSetID)
{
	auto* TaskPtr = UpdateTasks.Find(TaskId);
	if (TaskPtr != nullptr && TaskPtr->IsValid())
	{
		auto& Task = *TaskPtr;
		Task->MaterialParamUpdateTarget.MaterialInstanceSetId = MaterialInstanceSetID;
	}
}

bool FKGMaterialParamController::IsTaskFinished(uint32 TaskId) const
{
	auto* TaskPtr = UpdateTasks.Find(TaskId);
	if (TaskPtr != nullptr && TaskPtr->IsValid())
	{
		auto& Task = *TaskPtr;
		return Task->IsFinished();
	}
	
	return true;
}

void FKGMaterialParamController::ApplyTaskLatestValue(uint32 TaskId)
{
	auto* TaskPtr = UpdateTasks.Find(TaskId);
	if (TaskPtr != nullptr && TaskPtr->IsValid())
	{
		auto& Task = *TaskPtr;
		Task->ApplyLatestValueIfSet();
	}
}

void FKGMaterialParamController::InternalPauseTask(int32 TaskId, bool bPaused)
{
	auto* TaskPtr = UpdateTasks.Find(TaskId);
	if (TaskPtr != nullptr && TaskPtr->IsValid())
	{
		auto& Task = *TaskPtr;
		Task->bPaused = bPaused;
	}
}

void FKGMaterialParamController::TryLoadMaterialParameterCollectionAsset(FKGMaterialParamUpdateTarget& InOutMaterialParamUpdateTarget, uint32 TaskID)
{
	if (InOutMaterialParamUpdateTarget.MaterialParameterCollectionAssetPath.IsEmpty())
	{
		return;
	}

	UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(KGMaterialManager.Get());
	if (!AssetManager)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamController::TryLoadMaterialParameterCollectionAsset, cannot find asset manager"));
		return;
	}
	
	InOutMaterialParamUpdateTarget.AssetLoadID = AssetManager->AsyncLoadAsset(InOutMaterialParamUpdateTarget.MaterialParameterCollectionAssetPath,
		FAsyncLoadCompleteDelegate::CreateRaw(this, &FKGMaterialParamController::InternalOnMPCLoaded, TaskID));
}

void FKGMaterialParamController::InternalOnCurveAssetLoaded(int InLoadID, UObject* LoadedAsset, uint32 TaskID)
{
	TSharedPtr<FKGMaterialParamUpdateTaskBase>* TaskPtr = UpdateTasks.Find(TaskID);
	if (TaskPtr == nullptr || !TaskPtr->IsValid())
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamController::InternalOnCurveAssetLoaded, invalid task id %d, %s"), TaskID, *GetNameSafe(LoadedAsset));
		return;
	}

	auto& Task = *TaskPtr;
	if (Task->GetTaskType() != EKGMaterialParamUpdateTaskType::Curve)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamController::InternalOnCurveAssetLoaded, invalid task type %d, %d, %s"), 
			TaskID, Task->GetTaskType(), *GetNameSafe(LoadedAsset));
		return;
	}
	
	FKGMaterialCurveParams* CurveTaskPtr = StaticCast<FKGMaterialCurveParams*>(Task.Get());
	CurveTaskPtr->CurveAssetLoadID.Reset();
	UCurveBase* CurveBase = Cast<UCurveBase>(LoadedAsset);
	if (CurveBase == nullptr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamController::InternalOnCurveAssetLoaded, invalid loaded asset %s"), *CurveTaskPtr->CurvePath);
		RemoveMaterialParamUpdateTask(TaskID);
		return;
	}
	
	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::InternalOnCurveAssetLoaded, %s, %s"),
    	*CurveTaskPtr->ParamName.ToString(), *CurveTaskPtr->CurvePath);

	bool bRemapTimeSet = CurveTaskPtr->RemapTime.IsSet();
	float RemapTime = 0.0f;
	if (bRemapTimeSet)
	{
		RemapTime = CurveTaskPtr->RemapTime.GetValue();
	}
	CurveTaskPtr->CurveEvalParams.InitEvalParams(CurveBase, bRemapTimeSet, RemapTime, CurveTaskPtr->bLoop);
}

void FKGMaterialParamController::InternalOnMPCLoaded(int InLoadID, UObject* LoadedAsset, uint32 TaskID)
{
	TSharedPtr<FKGMaterialParamUpdateTaskBase>* TaskPtr = UpdateTasks.Find(TaskID);
	if (TaskPtr == nullptr || !TaskPtr->IsValid())
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamController::InternalOnMPCLoaded, invalid task id %d, %s"), TaskID, *GetNameSafe(LoadedAsset));
		return;
	}

	auto& Task = *TaskPtr;
	auto& UpdateTarget = Task->MaterialParamUpdateTarget;

	UpdateTarget.AssetLoadID = 0;

	UMaterialParameterCollection* MaterialParameterCollection = Cast<UMaterialParameterCollection>(LoadedAsset);
	if (MaterialParameterCollection == nullptr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamController::InternalOnMPCLoaded, invalid loaded asset %s"),
			*UpdateTarget.MaterialParameterCollectionAssetPath);
		RemoveMaterialParamUpdateTask(TaskID);
		return;
	}
	
	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::InternalOnMPCLoaded, %s, %s"),
        *Task->ParamName.ToString(), *UpdateTarget.MaterialParameterCollectionAssetPath);
	
	UpdateTarget.MaterialParameterCollection = TStrongObjectPtr(MaterialParameterCollection);
}

void FKGMaterialParamController::InternalSetRoleCompositeScalarMaterialParams(
	UMeshComponent* MeshComponent, int32 MaterialIndex, bool bOverlayMaterial, bool bSeparateOverlayMaterial, const TMap<FName, float>& ScalarParams,
	const TMap<FName, FLinearColor>& VectorParams, const TMap<FName, UTexture*>& TextureParams)
{
	if (MaterialIndex == INDEX_NONE)
	{
		return;
	}
	
	if (!MeshComponent)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamController::InternalSetRoleCompositeScalarMaterialParams, invalid mesh component"));
		return;
	}
	
	if (!KGMaterialManager.IsValid())
	{
		UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamController::InternalSetRoleCompositeScalarMaterialParams, invalid material manager"));
		return;
	}

	UMaterialInstanceDynamic* DynamicMaterialInstance = KGMaterialManager->GetDynamicMaterialInstance(
		MeshComponent, MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial);
	if (!DynamicMaterialInstance)
	{
		UE_LOG(LogKGMaterial, Log, TEXT("FKGMaterialParamController::InternalSetRoleCompositeScalarMaterialParams, cannot get dynamic material instance, %s, MaterialIndex: %d, bOverlayMaterial: %d, bSeparateOverlayMaterial: %d"),
			*KGMaterialUtils::GetMeshAssetNameDebugUsage(MeshComponent), MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial);
		return;
	}

	const auto MeshCompID = KGUtils::GetIDByObject(MeshComponent);
	if (AActor* Actor = MeshComponent->GetOwner())
	{
		const auto ActorID = KGUtils::GetIDByObject(Actor);
		auto& MeshCompIDs = ParamCacheActorIDToMeshComponentIDs.FindOrAdd(ActorID);
		MeshCompIDs.Add(MeshCompID);
	}
	
	auto& MeshParamCache = RoleCompositeParamCaches.FindOrAdd(MeshCompID).MaterialParamCaches;
	const auto MaterialCacheKey = KGMaterialUtils::GetMaterialCacheKey(MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, false);
	auto& MaterialParamCache = MeshParamCache.FindOrAdd(MaterialCacheKey);
	
	BATCH_DMIPARAM_SCOPE(DynamicMaterialInstance);
	for (const auto& Kvp : ScalarParams)
	{
		UE_LOG(LogKGMaterial, Verbose,
			TEXT("UKGMaterialManager::InternalSetRoleCompositeScalarMaterialParams, mesh: %s, key: %lld, set role composite param cache %s, %f"),
			*MeshComponent->GetName(), MaterialCacheKey, *Kvp.Key.ToString(), Kvp.Value);
		DynamicMaterialInstance->SetGameScalarParameterValue(Kvp.Key, Kvp.Value);
		MaterialParamCache.ScalarParams.Add(Kvp.Key, Kvp.Value);
	}

	for (const auto& Kvp : VectorParams)
	{
		UE_LOG(LogKGMaterial, Verbose,
			TEXT("UKGMaterialManager::InternalSetRoleCompositeScalarMaterialParams, mesh: %s, key: %lld, set role composite param cache %s, %s"),
			*MeshComponent->GetName(), MaterialCacheKey, *Kvp.Key.ToString(), *Kvp.Value.ToString());
		DynamicMaterialInstance->SetGameVectorParameterValue(Kvp.Key, Kvp.Value);
		MaterialParamCache.VectorParams.Add(Kvp.Key, Kvp.Value);
	}

	for (const auto& Kvp : TextureParams)
	{
		UE_LOG(LogKGMaterial, Verbose,
			TEXT("UKGMaterialManager::InternalSetRoleCompositeScalarMaterialParams, mesh: %s, key: %lld, set role composite param cache %s, %s"),
			*MeshComponent->GetName(), MaterialCacheKey, *Kvp.Key.ToString(), Kvp.Value ? *Kvp.Value->GetPathName() : TEXT("nullptr"));
		DynamicMaterialInstance->SetGameTextureParameterValue(Kvp.Key, Kvp.Value);
		MaterialParamCache.TextureParams.Add(Kvp.Key, Kvp.Value);
	}
}
