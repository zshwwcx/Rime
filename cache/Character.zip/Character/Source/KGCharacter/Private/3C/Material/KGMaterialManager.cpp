#include "3C/Material/KGMaterialManager.h"

#include "3C/Camera/BaseCamera.h"
#include "BinkMediaTexture.h"
#include "3C/Core/C7ActorInterface.h"
#include "3C/Camera/CameraManager.h"
#include "Manager/KGCppAssetManager.h"
#include "3C/Media/KGMediaManager.h"
#include "Manager/KGObjectActorManager.h"
#include "3C/RoleComposite/RoleCompositeManager.h"
#include "3C/Core/KGUEActorManager.h"
#include "3C/Util/KGUtils.h"
#include "Misc/ObjCrashCollector.h"
#include "TimerManager.h"
#include "Components/CapsuleComponent.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "Components/MeshComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/Engine.h"
#include "Managers/KGDataCacheManager.h"

bool GDrawKGMaterialManagerDebugInfo = false;
static FAutoConsoleVariableRef CVarDrawKGMaterialManagerDebugInfo(
	TEXT("gp.DrawKGMaterialManagerDebugInfo"),
	GDrawKGMaterialManagerDebugInfo,
	TEXT("DrawKGMaterialManagerDebugInfo."),
	ECVF_Default
);

static uint32 InnerChangeMaterialReqId = 0;
TArray<TWeakObjectPtr<UMeshComponent>> UKGMaterialManager::EmptyCustomMeshComps = {};
TArray<FName> UKGMaterialManager::EmptyExcludeMeshTags = {};
TArray<FName> UKGMaterialManager::EmptyMaterialSlotNames = {};

void UKGMaterialManager::NativeInit()
{
	Super::NativeInit();
	
	using namespace NS_SLUA;
	REG_MANAGER_FUNC(UKGMaterialManager, "ScriptChangeMaterial", &UKGMaterialManager::ScriptChangeMaterial);
	REG_MANAGER_FUNC(UKGMaterialManager, "RevertMaterial", &UKGMaterialManager::RevertMaterial);
	REG_MANAGER_FUNC(UKGMaterialManager, "RevertMaterialByActorId", &UKGMaterialManager::RevertMaterialByActorId);
	
	REG_MANAGER_FUNC(UKGMaterialManager, "ScriptChangeMaterialParam", &UKGMaterialManager::ScriptChangeMaterialParam);
	REG_MANAGER_FUNC(UKGMaterialManager, "InnerAddScalarParam", &UKGMaterialManager::InnerAddScalarParam);
	REG_MANAGER_FUNC(UKGMaterialManager, "InnerAddVectorParam", &UKGMaterialManager::InnerAddVectorParam);
	REG_MANAGER_FUNC(UKGMaterialManager, "InnerAddTextureParam", &UKGMaterialManager::InnerAddTextureParam);
	REG_MANAGER_FUNC(UKGMaterialManager, "InnerAddLinearSampleScalarParam", &UKGMaterialManager::InnerAddLinearSampleScalarParam);
	REG_MANAGER_FUNC(UKGMaterialManager, "InnerAddLinearSampleVectorParam", &UKGMaterialManager::InnerAddLinearSampleVectorParam);
	REG_MANAGER_FUNC(UKGMaterialManager, "InnerAddCurveParam", &UKGMaterialManager::InnerAddCurveParam);
	REG_MANAGER_FUNC(UKGMaterialManager, "InnerAddActorLocationParam", &UKGMaterialManager::InnerAddActorLocationParam);
	REG_MANAGER_FUNC(UKGMaterialManager, "InnerAddMediaTextureParam", &UKGMaterialManager::InnerAddMediaTextureParam);
	REG_MANAGER_FUNC(UKGMaterialManager, "InnerAddInheritDefaultMaterialTextureParam", &UKGMaterialManager::InnerAddInheritDefaultMaterialTextureParam);
	REG_MANAGER_FUNC(UKGMaterialManager, "ActivateChangeMaterialParamReq", &UKGMaterialManager::ActivateChangeMaterialParamReq);
	REG_MANAGER_FUNC(UKGMaterialManager, "RevertMaterialParam", &UKGMaterialManager::RevertMaterialParam);
	REG_MANAGER_FUNC(UKGMaterialManager, "RevertMaterialParamByActorId", &UKGMaterialManager::RevertMaterialParamByActorId);
	
	REG_MANAGER_FUNC(UKGMaterialManager, "AddCurveParamByDynamicMaterialInstanceID", &UKGMaterialManager::AddCurveParamByDynamicMaterialInstanceID);
	REG_MANAGER_FUNC(UKGMaterialManager, "AddCurveParamByDynamicMaterialInstanceIDs", &UKGMaterialManager::AddCurveParamByDynamicMaterialInstanceIDs);
	REG_MANAGER_FUNC(UKGMaterialManager, "AddCurveParamByCurveIDAndDynamicMaterialInstanceID", &UKGMaterialManager::AddCurveParamByCurveIDAndDynamicMaterialInstanceID);
	REG_MANAGER_FUNC(UKGMaterialManager, "AddCurveParamByCurveIDAndDynamicMaterialInstanceIDs", &UKGMaterialManager::AddCurveParamByCurveIDAndDynamicMaterialInstanceIDs);
	REG_MANAGER_FUNC(UKGMaterialManager, "AddLinearSampleParamByDynamicMaterialInstanceID", &UKGMaterialManager::AddLinearSampleParamByDynamicMaterialInstanceID);
	REG_MANAGER_FUNC(UKGMaterialManager, "AddLinearSampleParamByDynamicMaterialInstanceIDs", &UKGMaterialManager::AddLinearSampleParamByDynamicMaterialInstanceIDs);
	REG_MANAGER_FUNC(UKGMaterialManager, "UpdateLinearSampleParamTargetValue", &UKGMaterialManager::UpdateLinearSampleParamTargetValue);
	REG_MANAGER_FUNC(UKGMaterialManager, "AddVectorLinearSampleParamByDynamicMaterialInstanceID", &UKGMaterialManager::AddVectorLinearSampleParamByDynamicMaterialInstanceID);
	REG_MANAGER_FUNC(UKGMaterialManager, "AddVectorLinearSampleParamByDynamicMaterialInstanceIDs", &UKGMaterialManager::AddVectorLinearSampleParamByDynamicMaterialInstanceIDs);
	REG_MANAGER_FUNC(UKGMaterialManager, "AddMPCLinearSampleParamTask", &UKGMaterialManager::AddMPCLinearSampleParamTask);
	REG_MANAGER_FUNC(UKGMaterialManager, "AddMPCActorLocationTask", &UKGMaterialManager::AddMPCActorLocationTask);
	REG_MANAGER_FUNC(UKGMaterialManager, "AddMPCCurveParamTask", &UKGMaterialManager::AddMPCCurveParamTask);
	REG_MANAGER_FUNC(UKGMaterialManager, "RemoveMaterialParamUpdateTask", &UKGMaterialManager::RemoveMaterialParamUpdateTask);
	
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_AddTransientUpdateTask", &UKGMaterialManager::KAPI_MaterialManager_AddTransientUpdateTask);
	REG_MANAGER_FUNC(UKGMaterialManager, "SetScalarParameterByTransientTaskId", &UKGMaterialManager::SetScalarParameterByTransientTaskId);
	REG_MANAGER_FUNC(UKGMaterialManager, "RemoveTransientTaskById", &UKGMaterialManager::RemoveTransientTaskById);
	
	REG_MANAGER_FUNC(UKGMaterialManager, "GetDynamicMaterialInstanceByID", &UKGMaterialManager::GetDynamicMaterialInstanceByID);
	REG_MANAGER_FUNC(UKGMaterialManager, "ChangeDefaultMaterialInstanceByID", &UKGMaterialManager::ChangeDefaultMaterialInstanceByID);
	REG_MANAGER_FUNC(UKGMaterialManager, "GetDefaultMaterialInstanceID", &UKGMaterialManager::GetDefaultMaterialInstanceID);
	
	REG_MANAGER_FUNC(UKGMaterialManager, "AddExcludedMeshComponentId", &UKGMaterialManager::AddExcludedMeshComponentId);
	REG_MANAGER_FUNC(UKGMaterialManager, "RemoveExcludedMeshComponentId", &UKGMaterialManager::RemoveExcludedMeshComponentId);
	
	REG_MANAGER_FUNC(UKGMaterialManager, "GenerateReqId", &UKGMaterialManager::GenerateReqId);
	
	REG_MANAGER_FUNC(UKGMaterialManager, "InitMaterialCacheUseMaterialOnComponent", &UKGMaterialManager::InitMaterialCacheUseMaterialOnComponent);
	REG_MANAGER_FUNC(UKGMaterialManager, "RefreshAllMaterialCaches", &UKGMaterialManager::RefreshAllMaterialCaches);
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_RefreshMaterialCacheOnAddMeshComponent", &UKGMaterialManager::KAPI_MaterialManager_RefreshMaterialCacheOnAddMeshComponent);
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_RefreshMaterialCacheOnRemoveMeshComponent", &UKGMaterialManager::KAPI_MaterialManager_RefreshMaterialCacheOnRemoveMeshComponent);
	
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_InitConfig", &UKGMaterialManager::KAPI_MaterialManager_InitConfig);
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_AddValidClassType", &UKGMaterialManager::KAPI_MaterialManager_AddValidClassType);
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_ClearValidClassType", &UKGMaterialManager::KAPI_MaterialManager_ClearValidClassType);
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_SetCameraDitherInfos", &UKGMaterialManager::KAPI_MaterialManager_SetCameraDitherInfos);
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_SetCameraDitherDistanceScale", &UKGMaterialManager::KAPI_MaterialManager_SetCameraDitherDistanceScale);
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_SetCameraDitherUseDefaultOLM", &UKGMaterialManager::KAPI_MaterialManager_SetCameraDitherUseDefaultOLM);
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_AddRoleCompositeParamCopyToOLM", &UKGMaterialManager::KAPI_MaterialManager_AddRoleCompositeParamCopyToOLM);
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_ClearRoleCompositeParamCopyToOLM", &UKGMaterialManager::KAPI_MaterialManager_ClearRoleCompositeParamCopyToOLM);
	
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_GetMaterialCacheDebugInfos", &UKGMaterialManager::KAPI_MaterialManager_GetMaterialCacheDebugInfos);
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_GetMaterialParamDebugInfos", &UKGMaterialManager::KAPI_MaterialManager_GetMaterialParamDebugInfos);
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_GetRoleCompositeMaterialParamCacheDebugInfos", &UKGMaterialManager::KAPI_MaterialManager_GetRoleCompositeMaterialParamCacheDebugInfos);

	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_SetRainEffectParams", &UKGMaterialManager::KAPI_MaterialManager_SetRainEffectParams);
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_AddRainEffectFaceEffectiveParentMaterialPath", &UKGMaterialManager::KAPI_MaterialManager_AddRainEffectFaceEffectiveParentMaterialPath);
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_AddRainEffectBodyEffectiveParentMaterialPath", &UKGMaterialManager::KAPI_MaterialManager_AddRainEffectBodyEffectiveParentMaterialPath);
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_AddRainEffectBodyWithTightEffectiveParentMaterialPath", &UKGMaterialManager::KAPI_MaterialManager_AddRainEffectBodyWithTightEffectiveParentMaterialPath);
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_EmptyRainEffectEffectiveParentMaterialPath", &UKGMaterialManager::KAPI_MaterialManager_EmptyRainEffectEffectiveParentMaterialPath);
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_EnableRainEffect", &UKGMaterialManager::KAPI_MaterialManager_EnableRainEffect);
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_EnableSimpleRainEffect", &UKGMaterialManager::KAPI_MaterialManager_EnableSimpleRainEffect);
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_DisableRainEffect", &UKGMaterialManager::KAPI_MaterialManager_DisableRainEffect);
	
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_EnableActorOLM", &UKGMaterialManager::KAPI_MaterialManager_EnableActorOLM);
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_DisableActorOLM", &UKGMaterialManager::KAPI_MaterialManager_DisableActorOLM);
	
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_StartDissolveMaterialEffectByDissolveEffectID", &UKGMaterialManager::KAPI_MaterialManager_StartDissolveMaterialEffectByDissolveEffectID);
	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_StartDissolveMaterialEffectByMaterialParamID", &UKGMaterialManager::KAPI_MaterialManager_StartDissolveMaterialEffectByMaterialParamID);

	REG_MANAGER_FUNC(UKGMaterialManager, "KAPI_MaterialManager_FlushMIDPool", &UKGMaterialManager::FlushMIDPool);
	
	MaterialCacheController.KGMaterialManager = this;
	MaterialParamController.KGMaterialManager = this;
}

void UKGMaterialManager::NativeUninit()
{
	Super::NativeUninit();
	FMaterialMIDPool::Get().Flush();
}

void UKGMaterialManager::OnPostLoadMapWithWorld(UWorld* World)
{
	if(World == nullptr || World->PersistentLevel == nullptr)
	{
		return;
	}
	TickFunction.UnRegisterTickFunction();
	TickFunction.Manager = this;
	TickFunction.TickGroup = ETickingGroup::TG_DuringPhysics;
	TickFunction.RegisterTickFunction(World->PersistentLevel);

	ClearInvalidMaterialCache();
	RevertAllCameraDither();
	EmptyRainEffectRecords();
	ActorsWithTimeDilation.Empty();
}

void UKGMaterialManager::Tick(float DeltaTime)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGMaterialManager_Tick");
	
	UpdateTransientTasks();
	UpdateCameraDitherActors();
	ProcessPendingMaterialRequests();
	MaterialParamController.Update(DeltaTime);
	FMaterialMIDPool::Get().Tick();
	UpdateDilationTimers(DeltaTime);

#if KG_ENABLE_MATERIAL_MANAGER_DEBUG
	if (GDrawKGMaterialManagerDebugInfo)
	{
		GEngine->AddOnScreenDebugMessage(INDEX_NONE, .0f, FColor::Green,
			FString::Printf(TEXT("[TransientTask] %d [MaterialTickTask] %d\n [ChangeMaterialReq] %d [ChangeMaterialParamReq] %d"),
				TransientTasks.Num(), MaterialParamController.UpdateTasks.Num(), ChangeMaterialContexts.Num(), ChangeMaterialParamContexts.Num()));
	}
#endif
}

uint32 UKGMaterialManager::ScriptChangeMaterial(
	const FString& MaterialPath, EKGSearchMeshType SearchMeshType, const FName& SearchMeshName,
	const TArray<FName>& ExcludeMeshTags, EKGSearchMaterialType SearchMaterialType, const TArray<FName>& MaterialSlotNames, 
	bool bIgnoreExcludedMeshComp, uint32 Priority, float TotalLifeTimeMs, KGObjectID OwnerActorID,  bool bActivateImmediately,
	uint32 CustomChangeMaterialReqId, uint32 RelatedChangeMaterialParamReqID)
{
	FKGChangeMaterialRequest ChangeMaterialRequest;
	ChangeMaterialRequest.MaterialPath = MaterialPath;
	ChangeMaterialRequest.SearchMeshType = SearchMeshType;
	ChangeMaterialRequest.ExcludeMeshTags = ExcludeMeshTags;
	ChangeMaterialRequest.SearchMeshName = SearchMeshName;
	ChangeMaterialRequest.SearchMaterialType = SearchMaterialType;
	ChangeMaterialRequest.MaterialSlotNames = MaterialSlotNames;
	ChangeMaterialRequest.bIgnoreExcludedMeshComp = bIgnoreExcludedMeshComp;
	ChangeMaterialRequest.Priority = Priority;
	ChangeMaterialRequest.TotalLifeTimeMs = TotalLifeTimeMs;
	ChangeMaterialRequest.bActivateImmediately = bActivateImmediately;
	ChangeMaterialRequest.OwnerActor = KGUtils::GetActorByID(OwnerActorID);
	ChangeMaterialRequest.RelatedChangeMaterialParamReqID = RelatedChangeMaterialParamReqID;
	if (CustomChangeMaterialReqId != 0)
	{
		ChangeMaterialRequest.CustomChangeMaterialReqId = CustomChangeMaterialReqId;
	}

	return ChangeMaterial(ChangeMaterialRequest);
}

uint32 UKGMaterialManager::ChangeMaterial(const FKGChangeMaterialRequest& ChangeMaterialRequest)
{
	SCOPED_NAMED_EVENT(UKGMaterialManager_ChangeMaterial, FColor::Red);
	
	if (ChangeMaterialRequest.MaterialPath.IsEmpty())
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::ChangeMaterial, invalid material path"));
		return 0;
	}
	
	if (!ChangeMaterialRequest.OwnerActor.IsValid())
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::ChangeMaterial, invalid owner actor %s"), *ChangeMaterialRequest.MaterialPath);
		return 0;
	}

	UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this);
    if (!AssetManager)
    {
    	UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::ChangeMaterial, no asset manager"));
    	return 0;
    }

	uint32 ChangeMaterialReqId;
	if (ChangeMaterialRequest.CustomChangeMaterialReqId.IsSet())
	{
		ChangeMaterialReqId = ChangeMaterialRequest.CustomChangeMaterialReqId.GetValue();
	}
	else
	{
		ChangeMaterialReqId = KGMaterialUtils::GenerateIncId(InnerChangeMaterialReqId);
	}

	if (ChangeMaterialContexts.Contains(ChangeMaterialReqId))
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::ChangeMaterial, req id %d already exist"), ChangeMaterialReqId);
		return 0;
	}
	
	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::ChangeMaterial, change material %s, %s, %d"),
		*ChangeMaterialRequest.MaterialPath, *ChangeMaterialRequest.OwnerActor->GetName(), ChangeMaterialReqId);

	FKGChangeMaterialContext& ChangeMaterialContext = ChangeMaterialContexts.Add(ChangeMaterialReqId);
	ChangeMaterialContext.ChangeMaterialRequest = ChangeMaterialRequest;
	// 都是自增的, 先复用同一个ID
	ChangeMaterialContext.SequenceId = ChangeMaterialReqId;
	ChangeMaterialContext.ReqId = ChangeMaterialReqId;
	ChangeMaterialContext.LifeTimeHandler.SetOwnerActor(ChangeMaterialRequest.OwnerActor.Get());

	const auto ActorID = ChangeMaterialRequest.OwnerActor.KGGetObjectID();
	auto& ReqIds = ActorChangeMaterialReqIds.FindOrAdd(ActorID);
	ReqIds.Add(ChangeMaterialReqId);
	
	UObject* ExistingMaterial = nullptr;
	ChangeMaterialContext.AssetLoadID = AssetManager->AsyncLoadAsset(
		ChangeMaterialRequest.MaterialPath, ExistingMaterial, FAsyncLoadCompleteDelegate::CreateUObject(
		this, &UKGMaterialManager::InternalOnMaterialAssetLoaded, ChangeMaterialReqId, true));

	if (ExistingMaterial != nullptr)
	{
		InternalOnMaterialAssetLoaded(KG_CPP_INVALID_ASSET_LOAD_ID, ExistingMaterial, ChangeMaterialReqId, false);
	}
	
	RefreshAttachActorMaterial(ChangeMaterialRequest.OwnerActor.Get(), ChangeMaterialRequest.SourceReqID);
	
	return ChangeMaterialReqId;
}

bool UKGMaterialManager::RevertMaterial(uint32 ChangeMaterialReqId, bool bRevertMaterial, bool bActivateImmediately)
{
	auto* ContextPtr = ChangeMaterialContexts.Find(ChangeMaterialReqId);
	if (!ContextPtr)
	{
		UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::RevertMaterial, cannot find change material context %d"), ChangeMaterialReqId);
		return false;
	}
	
	if (bActivateImmediately)
	{
		return InternalRevertMaterial(*ContextPtr, bRevertMaterial);
	}
	
	FKGMaterialRequestPendingInfo PendingInfo;
	PendingInfo.ReqID = ChangeMaterialReqId;
	PendingInfo.bIsChangeMaterialReq = true;
	PendingInfo.bActivated = false;
	PendingInfo.bRevertMaterial = bRevertMaterial;
	PendingActiveMaterialRequests.PushLast(PendingInfo);
	
	return true;
}

void UKGMaterialManager::RevertMaterialByActorId(KGObjectID ActorId, bool bRevertMaterial)
{
	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::RevertMaterialByActorId, %s"),
		*GetNameSafe(KGUtils::GetActorByID(ActorId)));

	if (auto* ReqIdsPtr = ActorChangeMaterialReqIds.Find(ActorId))
	{
		const TSet<uint32> TempReqIds = *ReqIdsPtr;
		for (const auto ReqId : TempReqIds)
		{
			RevertMaterial(ReqId, false, true);
		}

		ActorChangeMaterialReqIds.Remove(ActorId);
	}

	if (bRevertMaterial)
	{
		MaterialCacheController.ClearAllMaterialCachesAndFallbackToDefaultMaterial(ActorId);
	}
	else
	{
		MaterialCacheController.ClearAllMaterialCaches(ActorId);	
	}

	if (ActorExcludedMeshComps.Contains(ActorId))
	{
		ActorExcludedMeshComps.Remove(ActorId);
	}
}

uint32 UKGMaterialManager::ScriptChangeMaterialParam(
	EKGSearchMeshType SearchMeshType, const FName& SearchMeshName, EKGSearchMaterialType SearchMaterialType,
	const TArray<FName>& MaterialSlotNames, bool bIgnoreExcludedMeshComp, uint32 Priority, float TotalLifeTimeMs,
	bool bUsePriorityControl, uint32 EffectType, KGObjectID OwnerActorID, bool bUseOLMDissolve, bool bActivateImmediately, 
	uint32 CustomReqId, uint32 RelatedChangeMaterialReqID)
{
	FKGChangeMaterialParamRequest ChangeMaterialParamRequest;
	ChangeMaterialParamRequest.SearchMeshType = SearchMeshType;
	ChangeMaterialParamRequest.SearchMeshName = SearchMeshName;
	ChangeMaterialParamRequest.SearchMaterialType = SearchMaterialType;
	ChangeMaterialParamRequest.MaterialSlotNames = MaterialSlotNames;
	ChangeMaterialParamRequest.bIgnoreExcludedMeshComp = bIgnoreExcludedMeshComp;
	ChangeMaterialParamRequest.Priority = Priority;
	ChangeMaterialParamRequest.bUsePriorityControl = bUsePriorityControl;
	ChangeMaterialParamRequest.EffectType = static_cast<EKGMaterialEffectType>(EffectType);
	ChangeMaterialParamRequest.TotalLifeTimeMs = TotalLifeTimeMs;
	ChangeMaterialParamRequest.OwnerActor = KGUtils::GetActorByID(OwnerActorID);
	ChangeMaterialParamRequest.RelatedChangeMaterialReqID = RelatedChangeMaterialReqID;
	ChangeMaterialParamRequest.bUseOLMDissolve = bUseOLMDissolve;
	ChangeMaterialParamRequest.bActivateImmediately = bActivateImmediately;
	if (CustomReqId != 0)
	{
		ChangeMaterialParamRequest.CustomChangeMaterialParamReqId = CustomReqId;
	}

	return ChangeMaterialParam(ChangeMaterialParamRequest, false);
}

void UKGMaterialManager::InnerAddScalarParam(uint32 ReqId, const FName& ParamName, float ParamVal)
{
	auto* ReqPtr = ChangeMaterialParamContexts.Find(ReqId);
	if (ReqPtr == nullptr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::InnerAddScalarParam, invalid ReqId %d"), ReqId);
		return;
	}
	ReqPtr->ChangeMaterialParamRequest.ScalarParams.Add(ParamName, ParamVal);
}

void UKGMaterialManager::InnerAddVectorParam(uint32 ReqId, const FName& ParamName, float R, float G, float B, float A)
{
	auto* ReqPtr = ChangeMaterialParamContexts.Find(ReqId);
	if (ReqPtr == nullptr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::InnerAddVectorParam, invalid ReqId %d"), ReqId);
		return;
	}
	ReqPtr->ChangeMaterialParamRequest.VectorParams.Add(ParamName, FLinearColor(R, G, B, A));
}

void UKGMaterialManager::InnerAddTextureParam(uint32 ReqId, const FName& ParamName, const FString& TexturePath)
{
	auto* ReqPtr = ChangeMaterialParamContexts.Find(ReqId);
	if (ReqPtr == nullptr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::InnerAddTextureParam, invalid ReqId %d"), ReqId);
		return;
	}
	ReqPtr->ChangeMaterialParamRequest.TextureParams.Add(ParamName, TexturePath);
}

void UKGMaterialManager::InnerAddLinearSampleScalarParam(
	uint32 ReqId, const FName& ParamName, float StartVal, float EndVal, float Duration, bool bActivateImmediately)
{
	auto* ReqPtr = ChangeMaterialParamContexts.Find(ReqId);
	if (ReqPtr == nullptr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::InnerAddLinearSampleScalarParam, invalid ReqId %d"), ReqId);
		return;
	}
	FKGLinearSampleParams<float> LinearSampleParams;
	LinearSampleParams.StartVal = StartVal;
	LinearSampleParams.EndVal = EndVal;
	LinearSampleParams.Duration = Duration;
	LinearSampleParams.bActivateImmediately = bActivateImmediately;
	ReqPtr->ChangeMaterialParamRequest.ScalarLinearSampleParams.Add(ParamName, LinearSampleParams);
}

void UKGMaterialManager::InnerAddLinearSampleVectorParam(
	uint32 ReqId, const FName& ParamName, float StartR, float StartG, float StartB, float StartA, float EndR, float EndG, float EndB, float EndA,
	float Duration, bool bActivateImmediately)
{
	auto* ReqPtr = ChangeMaterialParamContexts.Find(ReqId);
	if (ReqPtr == nullptr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::InnerAddLinearSampleVectorParam, invalid ReqId %d"), ReqId);
		return;
	}
	FKGLinearSampleParams<FLinearColor> LinearSampleParams;
	LinearSampleParams.StartVal = FLinearColor(StartR, StartG, StartB, StartA);
	LinearSampleParams.EndVal = FLinearColor(EndR, EndG, EndB, EndA);
	LinearSampleParams.Duration = Duration;
	LinearSampleParams.bActivateImmediately = bActivateImmediately;
	ReqPtr->ChangeMaterialParamRequest.VectorLinearSampleParams.Add(ParamName, LinearSampleParams);
}

void UKGMaterialManager::InnerAddCurveParam(uint32 ReqId, const FName& ParamName, const FString& CurvePath, bool bNeedRemap, float RemapTime, bool bLoop, bool bActivateImmediately)
{
	auto* ReqPtr = ChangeMaterialParamContexts.Find(ReqId);
	if (ReqPtr == nullptr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::InnerAddCurveParam, invalid ReqId %d"), ReqId);
		return;
	}
	FKGCurveParams CurveParams;
	CurveParams.CurvePath = CurvePath;
	CurveParams.bNeedRemap = bNeedRemap;
	CurveParams.RemapTime = RemapTime;
	CurveParams.bLoop = bLoop;
	CurveParams.bActivateImmediately = bActivateImmediately;
	ReqPtr->ChangeMaterialParamRequest.CurveParams.Add(ParamName, CurveParams);
}

void UKGMaterialManager::InnerAddActorLocationParam(uint32 ReqId, const FName& ParamName, KGObjectID ActorId)
{
	auto* ReqPtr = ChangeMaterialParamContexts.Find(ReqId);
	if (ReqPtr == nullptr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::InnerAddActorLocationParam, invalid ReqId %d"), ReqId);
		return;
	}
	AActor* Actor = KGUtils::GetActorByID(ActorId);
	if (!Actor)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::InnerAddActorLocationParam, invalid actor %lld"), ActorId);
		return;
	}
	FKGActorLocationMaterialParams ActorLocationMaterialParams;
	ActorLocationMaterialParams.Actor = Actor;
	ReqPtr->ChangeMaterialParamRequest.ActorLocationParams.Add(ParamName, ActorLocationMaterialParams);
}

void UKGMaterialManager::InnerAddMediaTextureParam(uint32 ReqId, const FName& ParamName, uint32 MediaPlayID)
{
	auto* ReqPtr = ChangeMaterialParamContexts.Find(ReqId);
	if (ReqPtr == nullptr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::InnerAddMediaTextureParam, invalid ReqId %d"), ReqId);
		return;
	}
	ReqPtr->ChangeMaterialParamRequest.MediaTextureParams.Add(ParamName, MediaPlayID);
}

void UKGMaterialManager::InnerAddInheritDefaultMaterialTextureParam(uint32 ReqId, const FName& ParamName)
{
	auto* ReqPtr = ChangeMaterialParamContexts.Find(ReqId);
	if (ReqPtr == nullptr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::InnerAddInheritDefaultMaterialTextureParam, invalid ReqId %d"), ReqId);
		return;
	}
	ReqPtr->ChangeMaterialParamRequest.TextureMaterialParamsInheritDefaultMaterial.Add(ParamName);
}

void UKGMaterialManager::ActivateChangeMaterialParamReq(uint32 ChangeMaterialParamReqId)
{
	auto* ReqPtr = ChangeMaterialParamContexts.Find(ChangeMaterialParamReqId);
	if (ReqPtr == nullptr)
	{
		UE_LOG(LogKGMaterial, Error,
			TEXT("UKGMaterialManager::ActivateChangeMaterialParamReq, invalid ChangeMaterialParamReqId %d"), ChangeMaterialParamReqId);
		return;
	}

	TryLoadMaterialParamAssets(*ReqPtr);
}

uint32 UKGMaterialManager::ChangeMaterialParam(const FKGChangeMaterialParamRequest& ChangeMaterialParamRequest, bool bActivateChangeMaterialParamReq)
{
	SCOPED_NAMED_EVENT(UKGMaterialManager_ChangeMaterialParam, FColor::Red);
	
	if (!ChangeMaterialParamRequest.OwnerActor.IsValid())
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::ChangeMaterialParam, invalid owner actor"));
		return 0;
	}
	
	if (!UpdateAndCacheManagers())
	{
		return 0;
	}
	check(ActorManager.IsValid());

	uint32 ReqId;
	if (ChangeMaterialParamRequest.CustomChangeMaterialParamReqId.IsSet())
	{
		ReqId = ChangeMaterialParamRequest.CustomChangeMaterialParamReqId.GetValue();
	}
	else
	{
		ReqId = KGMaterialUtils::GenerateIncId(InnerChangeMaterialReqId);
	}

	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::ChangeMaterialParam, %d, %s, %d"),
		ReqId, *ChangeMaterialParamRequest.OwnerActor->GetName(), bActivateChangeMaterialParamReq);

	if (ChangeMaterialParamContexts.Contains(ReqId))
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::ChangeMaterialParam, req id %d already exist"), ReqId);
		return 0;
	}
	
	auto& ChangeMaterialParamContext = ChangeMaterialParamContexts.Add(ReqId);
	ChangeMaterialParamContext.ChangeMaterialParamRequest = ChangeMaterialParamRequest;
	if (ChangeMaterialParamRequest.EffectType == EKGMaterialEffectType::Dissolve && ChangeMaterialParamRequest.bUseOLMDissolve)
	{
		if (ChangeMaterialParamRequest.SearchMaterialType == EKGSearchMaterialType::SearchAllNormalMaterial)
		{
			ChangeMaterialParamContext.ChangeMaterialParamRequest.SearchMaterialType = EKGSearchMaterialType::SearchRuntimeSeparateOverlayMaterial;
		}
		else if (ChangeMaterialParamRequest.SearchMaterialType == EKGSearchMaterialType::SearchMaterialBySlots)
		{
			ChangeMaterialParamContext.ChangeMaterialParamRequest.SearchMaterialType = EKGSearchMaterialType::SearchRuntimeSeparateOverlayMaterialBySlots;
		}
	}
	
	// 都是自增的, 先复用同一个ID
	ChangeMaterialParamContext.SequenceId = ReqId;
	ChangeMaterialParamContext.ReqId = ReqId;
	ChangeMaterialParamContext.LifeTimeHandler.SetOwnerActor(ChangeMaterialParamRequest.OwnerActor.Get());

	auto& ReqIds = ActorChangeMaterialParamReqIds.FindOrAdd(ChangeMaterialParamRequest.OwnerActor.KGGetObjectID());
	ReqIds.Add(ReqId);

	if (ChangeMaterialParamContext.ChangeMaterialParamRequest.ShouldUseOLM())
	{
		if (!ChangeMaterialParamContext.ChangeMaterialParamRequest.bUseCharacterCameraDither)
		{
			if (auto* Entity = ChangeMaterialParamContext.GetOwnerEntity(ActorManager.Get()))
			{
				if (Entity->GetUseCharacterTypeCameraDither())
				{
					ChangeMaterialParamContext.ChangeMaterialParamRequest.bUseCharacterCameraDither = true;
				}
			}
		}
		
		// 对于attach actor来说, 永远跟parent的camera dither保持一致
		if (!ChangeMaterialParamContext.ChangeMaterialParamRequest.bUseCharacterCameraDither)
		{
			if (IC7ActorInterface* ActorInterface = Cast<IC7ActorInterface>(ChangeMaterialParamContext.ChangeMaterialParamRequest.OwnerActor.Get()))
			{
				KGActorID ParentActorId = ActorInterface->GetLoigcParent();
				if (ParentActorId != KG_INVALID_ACTOR_ID)
				{
					if (auto* ParentEntity = ActorManager->GetLuaEntityByActorID(ParentActorId))
					{
						ChangeMaterialParamContext.ChangeMaterialParamRequest.bUseCharacterCameraDither = ParentEntity->GetUseCharacterTypeCameraDither();	
					}
				}
			}	
		}
		
		if (!ChangeMaterialParamContext.ChangeMaterialParamRequest.bNeedAngleThresholdParams)
		{
			if (auto* Entity = ChangeMaterialParamContext.GetOwnerEntity(ActorManager.Get()))
			{
				if (Entity->GetIsMainPlayer())
				{
					ChangeMaterialParamContext.ChangeMaterialParamRequest.bNeedAngleThresholdParams = true;
					ChangeMaterialParamContext.ChangeMaterialParamRequest.ScalarParams.Add(CameraDither_AngleThresholdMinParamName, CameraDither_AngleThresholdMin);
					ChangeMaterialParamContext.ChangeMaterialParamRequest.ScalarParams.Add(CameraDither_AngleThresholdMaxParamName, CameraDither_AngleThresholdMax);
				}
			}
		}
		
		// 相机虚化开始的时候额外总是额外设置一次IfUseWorldPosition, 避免先做溶解, 溶解过程中启动相机虚化(此时不会重复执行OLM材质设置)导致对应挂接物的虚化效果异常
		if (ChangeMaterialParamContext.ChangeMaterialParamRequest.bUseWorldPivotPositionForCameraDither)
		{
			ChangeMaterialParamContext.ChangeMaterialParamRequest.ScalarParams.Add(CameraDither_IfUseWorldPositionParamName, 1.0f);
		}
	}
	
	if (bActivateChangeMaterialParamReq)
	{
		TryLoadMaterialParamAssets(ChangeMaterialParamContext);	
	}
	
	return ReqId;
}

bool UKGMaterialManager::RevertMaterialParam(uint32 ChangeMaterialParamReqId, EKGMaterialParamRevertType RevertType, bool bActivateImmediately)
{
	auto* ContextPtr = ChangeMaterialParamContexts.Find(ChangeMaterialParamReqId);
	if (!ContextPtr)
	{
		UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::RevertMaterialParam, cannot find change material context %d"), ChangeMaterialParamReqId);
		return false;
	}
	
	if (bActivateImmediately)
	{
		return InternalRevertMaterialParam(*ContextPtr, RevertType);
	}
	
	FKGMaterialRequestPendingInfo PendingInfo;
	PendingInfo.ReqID = ChangeMaterialParamReqId;
	PendingInfo.bIsChangeMaterialReq = false;
	PendingInfo.bActivated = false;
	PendingInfo.RevertType = RevertType;
	PendingActiveMaterialRequests.PushLast(PendingInfo);
	
	return true;
}

void UKGMaterialManager::RevertMaterialParamByActorId(KGObjectID ActorId, EKGMaterialParamRevertType RevertType)
{
	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::RevertMaterialParamByActorId, %s"),
		*GetNameSafe(KGUtils::GetActorByID(ActorId)));

	if (auto* ReqIdsPtr = ActorChangeMaterialParamReqIds.Find(ActorId))
	{
		const TSet<uint32> TempReqIds = *ReqIdsPtr;
		for (const auto ReqId : TempReqIds)
		{
			RevertMaterialParam(ReqId, RevertType, true);
		}

		ActorChangeMaterialParamReqIds.Remove(ActorId);
	}

	RemoveTransientTasksByActor(ActorId);
	MaterialParamController.PriorityQueueSets.Remove(ActorId);
	MaterialParamController.ClearActorRoleCompositeParamCache(ActorId);
}

void UKGMaterialManager::RevertMaterialAndMaterialParamsOnActorDestroy(KGActorID ActorID, bool bFallbackToDefaultMaterial)
{
	SCOPED_NAMED_EVENT(UKGMaterialManager_RevertMaterialAndMaterialParamsOnActorDestroy, FColor::Red);
	
	RevertMaterialByActorId(ActorID, bFallbackToDefaultMaterial);
	RevertMaterialParamByActorId(
		ActorID, bFallbackToDefaultMaterial ? EKGMaterialParamRevertType::RevertOLMAndClearState : EKGMaterialParamRevertType::ClearStateOnly);
	if (ActorsWithTimeDilation.Contains(ActorID))
	{
		ActorsWithTimeDilation.Remove(ActorID);	
	}
}

void UKGMaterialManager::InternalOnMaterialAssetLoaded(int InLoadID, UObject* LoadedAsset, uint32 ChangeMaterialReqId, bool bAsyncAssetLoadCallback)
{
	SCOPED_NAMED_EVENT(UKGMaterialManager_InternalOnMaterialAssetLoaded, FColor::Red);
	
	auto* ContextPtr = ChangeMaterialContexts.Find(ChangeMaterialReqId);
	if (!ContextPtr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::InternalOnMaterialAssetLoaded, invalid req id %d"), ChangeMaterialReqId);
		return;
	}

	if (bAsyncAssetLoadCallback)
	{
		ContextPtr->AssetLoadID = 0;
	}
	
	// 避免重复执行
	if (ContextPtr->bAssetLoaded == true)
	{
		UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::InternalOnMaterialAssetLoaded, asset already loaded, %s"),
			*ContextPtr->ToString());
		return;
	}
	ContextPtr->bAssetLoaded = true;
	
	UMaterialInterface* MaterialInterface = Cast<UMaterialInterface>(LoadedAsset);
	if (MaterialInterface == nullptr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::InternalOnMaterialAssetLoaded, invalid material instance loaded %s"),
			*ContextPtr->ToString());
		InternalRevertMaterial(*ContextPtr);
		return;
	}

	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::InternalOnMaterialAssetLoaded, asset %s loaded, %s"),
		*MaterialInterface->GetName(), *ContextPtr->ToString());
	
	ContextPtr->MaterialInterface = MaterialInterface;

	if (ContextPtr->ChangeMaterialRequest.bActivateImmediately == true)
	{
		ContextPtr->ExecStage = EKGChangeMaterialExecStage::PendingActivate;
		FKGMaterialRequestPendingInfo PendingInfo;
		PendingInfo.bActivated = true;
		PendingInfo.ReqID = ChangeMaterialReqId;
		PendingInfo.bIsChangeMaterialReq = true;
		PendingActiveMaterialRequests.PushLast(PendingInfo);
	}
	else
	{
		InternalChangeMaterial(*ContextPtr);	
	}
}

void UKGMaterialManager::InternalChangeMaterial(FKGChangeMaterialContext& InOutContext)
{
	SCOPED_NAMED_EVENT(UKGMaterialManager_InternalChangeMaterial, FColor::Red);
	const auto& Request = InOutContext.ChangeMaterialRequest;

	FKGChangeMaterialParamContext* RelatedMaterialParamContextPtr = nullptr;
	if (Request.RelatedChangeMaterialParamReqID != 0)
	{
		RelatedMaterialParamContextPtr = ChangeMaterialParamContexts.Find(Request.RelatedChangeMaterialParamReqID);
		if (!RelatedMaterialParamContextPtr || RelatedMaterialParamContextPtr->bAssetLoaded == false)
		{
			UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::InternalChangeMaterial, related change material param req id %d not ready"),
				Request.RelatedChangeMaterialParamReqID);
			InOutContext.ExecStage = EKGChangeMaterialExecStage::WaitingRelatedChangeMaterialParam;
			return;
		}
	}

	InOutContext.ExecStage = EKGChangeMaterialExecStage::Activated;
	
	GetAffectedMaterialCacheKeys(
		Request.OwnerActor.Get(), Request.SearchMeshType, Request.SearchMeshName, Request.CustomMeshComps,
		Request.ExcludeMeshTags, Request.SearchMaterialType, Request.MaterialSlotNames,
		Request.bIgnoreExcludedMeshComp, false, InOutContext.MaterialCacheKeyMapping);

	MaterialCacheController.InitMaterialCacheStack(Request.OwnerActor, InOutContext.MaterialCacheKeyMapping);
	MaterialCacheController.AddMaterialCacheStackItems(InOutContext);

	if (InOutContext.bNeedRefreshMaterialParamReq)
	{
		UE_LOG(LogKGMaterial, Log,
			TEXT("UKGMaterialManager::InternalChangeMaterial, set material to empty material slot, refresh material params, %d"), InOutContext.ReqId);
		RefreshAllMaterialParams(Request.OwnerActor.Get());
	}
	
	// 一定要先修改材质再修改材质参数
	if (RelatedMaterialParamContextPtr != nullptr)
	{
		UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::InternalChangeMaterial, related change material param req id %d is ready and apply material now"),
			Request.RelatedChangeMaterialParamReqID);

		if (RelatedMaterialParamContextPtr->ExecStage == EKGChangeMaterialParamExecStage::WaitingRelatedChangeMaterial)
		{
			check(InOutContext.ExecStage != EKGChangeMaterialExecStage::WaitingRelatedChangeMaterialParam);
			ApplyMaterialParams(*RelatedMaterialParamContextPtr);
		}
	}
	
	if (Request.TotalLifeTimeMs > 0)
	{
		const bool bUseTimerManager = !ActorsWithTimeDilation.Contains(Request.OwnerActor.KGGetObjectID());
		UE_LOG(LogKGMaterial, Log,
			TEXT("UKGMaterialManager::InternalChangeMaterial, start life time timer %f seconds, %s, bUseTimerManager=%d"),
			Request.TotalLifeTimeMs / 1000.0f, *InOutContext.ToString(), bUseTimerManager);
		InOutContext.LifeTimeHandler.InitOnceTimer(Request.TotalLifeTimeMs / 1000.0f,
			FTimerDelegate::CreateUObject(this, &UKGMaterialManager::OnChangeMaterialLifeTimeExpired, InOutContext.ReqId),
			bUseTimerManager);
	}
}

void UKGMaterialManager::OnChangeMaterialLifeTimeExpired(uint32 ChangeMaterialReqId)
{
	auto* ChangeMaterialContextPtr = ChangeMaterialContexts.Find(ChangeMaterialReqId);
	if (!ChangeMaterialContextPtr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::OnChangeMaterialLifeTimeExpired, invalid req id %d"), ChangeMaterialReqId);
		return;
	}

	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::OnChangeMaterialLifeTimeExpired, %s"), *ChangeMaterialContextPtr->ToString());
	RevertMaterial(ChangeMaterialReqId);
}

bool UKGMaterialManager::InternalRevertMaterial(FKGChangeMaterialContext& InOutContext, bool bRevertMaterial)
{
	SCOPED_NAMED_EVENT(UKGMaterialManager_InternalRevertMaterial, FColor::Red);
	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::InternalRevertMaterial, %s"), *InOutContext.ToString());

	if (InOutContext.AssetLoadID != 0)
	{
		UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this);
		if (!AssetManager)
		{
			UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::RevertMaterial, no asset manager"));
			return false;
		}
		
		AssetManager->CancelAsyncLoadByLoadID(InOutContext.AssetLoadID);
	}
	
	if (InOutContext.ExecStage == EKGChangeMaterialExecStage::Activated && bRevertMaterial)
	{
		MaterialCacheController.RemoveMaterialCacheStackItems(InOutContext);
	}

	const auto ActorID = InOutContext.ChangeMaterialRequest.OwnerActor.KGGetObjectID();
	if (ActorChangeMaterialReqIds.Contains(ActorID))
	{
		auto& ReqIds = ActorChangeMaterialReqIds[ActorID];
		if (ReqIds.Contains(InOutContext.ReqId))
		{
			ReqIds.Remove(InOutContext.ReqId);
		}
		else
		{
			UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::RevertMaterial, cannot find req id record %s"),
				*InOutContext.ToString());
		}
	}
	else
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::RevertMaterial, cannot find actor req id record %s"), 
			*InOutContext.ToString());
	}

	InOutContext.LifeTimeHandler.ClearTimer();

	AActor* OwnerActor = InOutContext.ChangeMaterialRequest.OwnerActor.Get();
	auto SourceReqID = InOutContext.ChangeMaterialRequest.SourceReqID;
	
	ChangeMaterialContexts.Remove(InOutContext.ReqId);
	
	RefreshAttachActorMaterial(OwnerActor, SourceReqID);
	return true;
}

void UKGMaterialManager::OnChangeMaterialParamLifeTimeExpired(uint32 ChangeMaterialParamReqId)
{
	auto* ContextPtr = ChangeMaterialParamContexts.Find(ChangeMaterialParamReqId);
	if (!ContextPtr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::OnChangeMaterialParamLifeTimeExpired, invalid req id %d"), ChangeMaterialParamReqId);
		return;
	}

	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::OnChangeMaterialParamLifeTimeExpired, %s"), *ContextPtr->ToString());
	RevertMaterialParam(ChangeMaterialParamReqId);
}

void UKGMaterialManager::TryLoadMaterialParamAssets(FKGChangeMaterialParamContext& InOutContext)
{
	AssembleAssetsToLoad(InOutContext);

	if (InOutContext.AssetPaths.Num() > 0)
	{
		UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this);
		if (!AssetManager)
		{
			UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamController::TryLoadMaterialParamAssets, cannot find asset manager"));
			return;
		}

		UE_LOG(LogKGMaterial, Log,
			TEXT("UKGMaterialManager::TryLoadMaterialParamAssets, found %d assets to load, %s"), InOutContext.AssetPaths.Num(), *InOutContext.ToString());

		InOutContext.bAssetLoaded = false;
		TArray<UObject*> Assets;
		InOutContext.AssetLoadID = AssetManager->AsyncLoadAsset(InOutContext.AssetPaths, Assets,
		FAsyncLoadListCompleteDelegate::CreateUObject(this, &UKGMaterialManager::InternalOnMaterialParamAssetsLoaded, InOutContext.ReqId, true));
		if (Assets.Num() > 0)
		{
			InternalOnMaterialParamAssetsLoaded(KG_CPP_INVALID_ASSET_LOAD_ID, Assets, InOutContext.ReqId, false);
		}
	}
	else if (InOutContext.ChangeMaterialParamRequest.bActivateImmediately)
	{
		ApplyMaterialParams(InOutContext);
	}
	else
	{
		InOutContext.ExecStage = EKGChangeMaterialParamExecStage::PendingActivate;
		FKGMaterialRequestPendingInfo PendingInfo;
		PendingInfo.bActivated = true;
		PendingInfo.ReqID = InOutContext.ReqId;
		PendingInfo.bIsChangeMaterialReq = false;
		PendingActiveMaterialRequests.PushLast(PendingInfo);
	}

	RefreshAttachActorMaterialParams(
		InOutContext.ChangeMaterialParamRequest.OwnerActor.Get(), InOutContext.ChangeMaterialParamRequest.SourceReqID);
}

void UKGMaterialManager::ApplyMaterialParams(FKGChangeMaterialParamContext& InOutContext)
{
	SCOPED_NAMED_EVENT(UKGMaterialManager_ApplyMaterialParams, FColor::Red);
	const auto& Request = InOutContext.ChangeMaterialParamRequest;
	if (Request.RelatedChangeMaterialReqID != 0)
	{
		auto* MaterialContextPtr = ChangeMaterialContexts.Find(Request.RelatedChangeMaterialReqID);
		if (!MaterialContextPtr || !MaterialContextPtr->bAssetLoaded)
		{
			UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::ApplyMaterialParams, related change material req id %d not ready"),
				Request.RelatedChangeMaterialReqID);
			InOutContext.ExecStage = EKGChangeMaterialParamExecStage::WaitingRelatedChangeMaterial;
			return;
		}

		UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::ApplyMaterialParams, related change material param req id %d is ready and apply material now"),
			Request.RelatedChangeMaterialReqID);

		if (MaterialContextPtr->ExecStage == EKGChangeMaterialExecStage::WaitingRelatedChangeMaterialParam)
		{
			check(InOutContext.ExecStage != EKGChangeMaterialParamExecStage::WaitingRelatedChangeMaterial);
			InternalChangeMaterial(*MaterialContextPtr);	
		}
	}

	// 在目前的使用场景下, 可以在这里加载runtime separate overlay材质, 对于camera dither, 本身没有类型设置需求, 对于溶解来说, 只要有任意一种溶解效果存在
	// 都需要去加载runtime separate overlay材质
	if (Request.ShouldUseOLM())
	{
		UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::ApplyMaterialParams, set runtime separate overlay material %s"), *InOutContext.ToString());
		MaterialCacheController.ChangeRuntimeSeparateOverlayMaterial(
			Request.OwnerActor, Request.CustomMeshComps, InOutContext.ReqId, Request.bUseCharacterCameraDither,
			Request.SearchMeshType == EKGSearchMeshType::SearchAllMesh, Request.bIgnoreExcludedMeshComp, Request.bIsCameraDither,
			Request.bUseWorldPivotPositionForCameraDither, Request.bNeedAngleThresholdParams);
	}
	
	if (!Request.OwnerActor.IsValid())
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::ApplyMaterialParams, invalid owner actor, %s"), *InOutContext.ToString());
		return;
	}

	InOutContext.ExecStage = EKGChangeMaterialParamExecStage::Activated;
	GetAffectedMaterialCacheKeys(
		Request.OwnerActor.Get(), Request.SearchMeshType, Request.SearchMeshName, Request.CustomMeshComps,
		Request.ExcludeMeshTags, Request.SearchMaterialType, Request.MaterialSlotNames,
		Request.bIgnoreExcludedMeshComp, Request.bIsCameraDither, InOutContext.MaterialCacheKeyMapping);
	if (!Request.ShouldUseOLM())
	{
		MaterialCacheController.InitMaterialCacheStack(Request.OwnerActor, InOutContext.MaterialCacheKeyMapping);
	}

	InOutContext.MaterialInstanceSetId = CreateMaterialInstanceSet(InOutContext.MaterialCacheKeyMapping);

	UE_LOG(LogKGMaterial, Log,
		TEXT("UKGMaterialManager::ApplyMaterialParams, create new material instance id %s, %d"),
		*InOutContext.ToString(), InOutContext.MaterialInstanceSetId);

	if (Request.bUsePriorityControl)
	{
		RemoveTransientTaskByEffectType(Request.OwnerActor, Request.EffectType);
		MaterialParamController.AddNewItemToPriorityQueue(InOutContext);
	}
	else
	{
		InternalSetMaterialParams(InOutContext);
	}

	if (Request.TotalLifeTimeMs > 0)
	{
		const bool bUseTimerManager = !ActorsWithTimeDilation.Contains(Request.OwnerActor.KGGetObjectID());
		UE_LOG(LogKGMaterial, Log,
			TEXT("UKGMaterialManager::ApplyMaterialParams, start life time timer %f seconds, %s, bUseTimerManager=%d"),
			Request.TotalLifeTimeMs / 1000.0f, *InOutContext.ToString(), bUseTimerManager);
		InOutContext.LifeTimeHandler.InitOnceTimer(Request.TotalLifeTimeMs / 1000.0f,
			FTimerDelegate::CreateUObject(this, &UKGMaterialManager::OnChangeMaterialParamLifeTimeExpired, InOutContext.ReqId),
			bUseTimerManager);
	}
}

void UKGMaterialManager::RemoveMaterialParams(FKGChangeMaterialParamContext& InOutContext, EKGMaterialParamRevertType RevertType)
{
	const auto& Request = InOutContext.ChangeMaterialParamRequest;
	if (Request.ShouldUseOLM())
	{
		MaterialCacheController.RevertRuntimeSeparateOverlayMaterial(Request.OwnerActor, InOutContext.ReqId,
			RevertType == EKGMaterialParamRevertType::Default || RevertType == EKGMaterialParamRevertType::RevertOLMAndClearState);
	}
	
	if (InOutContext.ExecStage != EKGChangeMaterialParamExecStage::Activated)
	{
		UE_LOG(LogKGMaterial, Log,
			TEXT("UKGMaterialManager::RemoveMaterialParams, material param not taken effect, maybe waiting change material request, %s"),
			*InOutContext.ToString());
		return;
	}

	const bool bRevertMaterialParams = RevertType == EKGMaterialParamRevertType::Default;
	if (Request.bUsePriorityControl)
	{
		for (const auto& Kvp : InOutContext.MaterialParamUpdateTaskIds)
		{
			MaterialParamController.RemoveMaterialParamUpdateTask(Kvp.Value, !bRevertMaterialParams);
		}

		UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::RemoveMaterialParams, remove material instance set id %d, %s"),
			InOutContext.MaterialInstanceSetId, *InOutContext.ToString());
		MaterialParamController.RemoveItemInPriorityQueue(InOutContext, bRevertMaterialParams);
	}
	else
	{
		InternalRevertMaterialParams(InOutContext, bRevertMaterialParams);
	}
}

void UKGMaterialManager::InternalSetMaterialParams(FKGChangeMaterialParamContext& InOutContext)
{
	InOutContext.bHasInit = true;

	InitConstMaterialParams(InOutContext);
	AddMaterialParamUpdateTasks(InOutContext);
}

void UKGMaterialManager::InitConstMaterialParams(FKGChangeMaterialParamContext& InOutContext)
{
	SCOPED_NAMED_EVENT(FKGMaterialCacheController_InitConstMaterialParams, FColor::Red);
	
	const auto& ChangeMaterialParamRequest = InOutContext.ChangeMaterialParamRequest;
	const auto* MaterialInstanceSetPtr = MaterialInstancesSets.Find(InOutContext.MaterialInstanceSetId);
	if (MaterialInstanceSetPtr != nullptr)
	{
		for (auto& MaterialInstanceSetKvp : *MaterialInstanceSetPtr)
		{
			auto& MaterialInstance = MaterialInstanceSetKvp.Key;
			if (!MaterialInstance.IsValid())
			{
				continue;
			}

			UMaterialInstanceDynamic* MaterialInstanceDynamic = MaterialInstance.Get();
			BATCH_DMIPARAM_SCOPE(MaterialInstanceDynamic);

			for (const auto& Kvp : ChangeMaterialParamRequest.ScalarParams)
			{
				UE_LOG(LogKGMaterial, Verbose,
					TEXT("UKGMaterialManager::InitConstMaterialParams, SetScalarParameterBySetId, %s %s %f"),
					*KGMaterialUtils::GetMaterialInfoDebugUsage(MaterialInstanceDynamic), *Kvp.Key.ToString(), Kvp.Value);
				MaterialInstanceDynamic->SetGameScalarParameterValue(Kvp.Key, Kvp.Value);
				InOutContext.ModifiedScalarParamNames.Add(Kvp.Key);
			}

			for (const auto& Kvp : ChangeMaterialParamRequest.VectorParams)
			{
				UE_LOG(LogKGMaterial, Verbose,
					TEXT("UKGMaterialManager::InitConstMaterialParams, SetVectorParameterBySetId, %s %s %s"),
					*KGMaterialUtils::GetMaterialInfoDebugUsage(MaterialInstanceDynamic), *Kvp.Key.ToString(), *Kvp.Value.ToString());
				MaterialInstanceDynamic->SetGameVectorParameterValue(Kvp.Key, Kvp.Value);
				InOutContext.ModifiedVectorParamNames.Add(Kvp.Key);
			}

			for (const auto& Kvp : ChangeMaterialParamRequest.TextureParams)
			{
				if (InOutContext.LoadedAssets.Contains(Kvp.Key))
				{
					UTexture* Texture = Cast<UTexture>(InOutContext.LoadedAssets[Kvp.Key]);
					UE_LOG(LogKGMaterial, Verbose,
						TEXT("UKGMaterialManager::InitConstMaterialParams, SetTextureParameterBySetId, %s %s %s"),
						*KGMaterialUtils::GetMaterialInfoDebugUsage(MaterialInstanceDynamic), *Kvp.Key.ToString(),
						Texture ? *Texture->GetPathName() : TEXT("nullptr"));
					MaterialInstanceDynamic->SetGameTextureParameterValue(Kvp.Key, Texture);
					InOutContext.ModifiedTextureParamNames.Add(Kvp.Key);
				}
				else
				{
					UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::InitConstMaterialParams, cannot find texture %s, %s"), *Kvp.Key.ToString(), *Kvp.Value);
				}
			}

			if (ChangeMaterialParamRequest.MediaTextureParams.Num() > 0)
			{
				if (UKGMediaManager* MediaManager = UKGMediaManager::GetInstance(this))
				{
					for (const auto& Kvp : ChangeMaterialParamRequest.MediaTextureParams)
					{
						UBinkMediaTexture* Texture = MediaManager->GetBinkMediaTexture(Kvp.Value);
						UE_LOG(LogKGMaterial, Verbose,
							TEXT("UKGMaterialManager::InitConstMaterialParams, SetMediaTextureParameterBySetId, %s %s %s"),
							*KGMaterialUtils::GetMaterialInfoDebugUsage(MaterialInstanceDynamic), *Kvp.Key.ToString(),
							Texture ? *Texture->GetPathName() : TEXT("nullptr"));
						MaterialInstanceDynamic->SetGameTextureParameterValue(Kvp.Key, Texture);
						InOutContext.ModifiedTextureParamNames.Add(Kvp.Key);
					}
				}
				else
				{
					UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::InitConstMaterialParams, invalid media manager"));
				}
			}
		}
	}

	// 这里是铅笔画后处理定制逻辑, 迁移到batch模式逻辑调整较大, 暂不做处理
	if (ChangeMaterialParamRequest.TextureMaterialParamsInheritDefaultMaterial.Num() > 0)
	{
		for (const auto& TextureParamName : ChangeMaterialParamRequest.TextureMaterialParamsInheritDefaultMaterial)
		{
			InOutContext.ModifiedTextureParamNames.Add(TextureParamName);
			for (const auto& Kvp : InOutContext.MaterialCacheKeyMapping)
			{
				for (const auto MaterialCacheKey : Kvp.Value)
				{
					// 目前的使用case上如果参数已经被修改, 那么这里无需做任何处理
					// 1) 如果参数被组装修改, 那么这里是否设置其实效果是一样的, 因为设置sketch material时会copy material param, 但是需要注意的是结束时不能回退
					// 2) 如果参数没有被修改, 用的就是材质默认给的参数, 那么这里一定需要设置, 且结束时可以不回退, 如果要回退的话, 一定要先revert sketch material, 然后再执行回退
					// 3) 如果这里参数被外部非组装逻辑修改了, 其实按照目前的逻辑, 怎么样都会有问题, 必须将组装参数单独存一份, 这种case遇到再处理
					// 还需要注意的是
					// 1) 这里为了兼容组装修改参数, 需要先进行材质参数修改, 再执行材质修改, 避免读取default material错误
					// 2) 如果这里没有执行revert material param, 那么在这个材质参数将一直保留, 可能对后续其他材质相应材质参数造成影响
					UMaterialInterface* MaterialInstance = MaterialCacheController.GetDefaultMaterial(Kvp.Key.Get(), MaterialCacheKey);
					if (MaterialInstance == nullptr)
					{
						UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::InitConstMaterialParams, Default Material %lld is nullptr"), MaterialCacheKey);
						continue;
					}

					UMaterialInterface* CurMaterialInterface = KGMaterialUtils::GetMaterialInstanceByMaterialCacheKey(Kvp.Key.Get(), MaterialCacheKey);
					if (!CurMaterialInterface)
					{
						// 原始材质插槽为空 无需报错
						continue;
					}
					
					FMaterialParameterInfo ParameterInfo(TextureParamName);
					UTexture* OutTexture = nullptr;
					if (!MaterialInstance->GetTextureParameterValue(ParameterInfo, OutTexture))
					{
						UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::InitConstMaterialParams, Material %s does not have texture parameter %s"),
							*KGMaterialUtils::GetMaterialInfoDebugUsage(CurMaterialInterface), *TextureParamName.ToString());
						continue;
					}
			
					if (UMaterialInstanceDynamic* MaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(CurMaterialInterface))
					{
						MaterialInstanceDynamic->SetTextureParameterValue(TextureParamName, OutTexture);
					}
					else
					{
						UE_LOG(LogKGMaterial, Error,
							TEXT("UKGMaterialManager::InitConstMaterialParams, expected dynamic material instance %s, %lld, but got: %s"),
							*Kvp.Key->GetName(), MaterialCacheKey, *KGMaterialUtils::GetMaterialInfoDebugUsage(CurMaterialInterface));
					}
				}
			}
		}
	}
}

void UKGMaterialManager::DeactivateMaterialParams(uint32 ReqId)
{
	auto* ContextPtr = ChangeMaterialParamContexts.Find(ReqId);
	if (!ContextPtr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::DeactivateMaterialParams, cannot find context %d"), ReqId);
		return;
	}
	
	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::DeactivateMaterialParams, deactivate material params %s"), *ContextPtr->ToString());

	SetAllMaterialParamsToDefault(*ContextPtr);
	for (const auto& Kvp : ContextPtr->MaterialParamUpdateTaskIds)
	{
		MaterialParamController.PauseMaterialParamUpdateTask(Kvp.Value);
	}
}

void UKGMaterialManager::ActivateOrSetMaterialParams(uint32 ReqId)
{
	auto* ContextPtr = ChangeMaterialParamContexts.Find(ReqId);
	if (!ContextPtr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::ActivateOrSetMaterialParams, cannot find context %d"), ReqId);
		return;
	}

	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::ActivateOrSetMaterialParams, activate material params %s"), *ContextPtr->ToString());

	if (!ContextPtr->bHasInit)
	{
		InternalSetMaterialParams(*ContextPtr);
		return;
	}

	InitConstMaterialParams(*ContextPtr);
	for (const auto& Kvp : ContextPtr->MaterialParamUpdateTaskIds)
	{
		if (MaterialParamController.IsTaskFinished(Kvp.Value))
		{
			MaterialParamController.ApplyTaskLatestValue(Kvp.Value);
		}
		else
		{
			MaterialParamController.ResumeMaterialParamUpdateTask(Kvp.Value);	
		}
	}
}

void UKGMaterialManager::AddMaterialParamUpdateTasks(FKGChangeMaterialParamContext& InOutContext)
{
	SCOPED_NAMED_EVENT(FKGMaterialCacheController_AddMaterialParamUpdateTasks, FColor::Red);
	
	const auto& ChangeMaterialParamRequest = InOutContext.ChangeMaterialParamRequest;
	FKGCommonMaterialParamUpdateParams UpdateParams;
	UpdateParams.MaterialParamUpdateTarget.MaterialInstanceSetId = InOutContext.MaterialInstanceSetId;
	UpdateParams.bAutoStop = false;
	UpdateParams.bRevertToDefaultValueOnTaskEnd = false;
	UpdateParams.OwnerActor = InOutContext.ChangeMaterialParamRequest.OwnerActor;
	UpdateParams.bFollowSlomo = true;
	
	for (const auto& Kvp : ChangeMaterialParamRequest.CurveParams)
	{
		if (InOutContext.LoadedAssets.Contains(Kvp.Key))
		{
			UCurveBase* CurveBase = Cast<UCurveBase>(InOutContext.LoadedAssets[Kvp.Key]);
			UpdateParams.ParamName = Kvp.Key;
			UpdateParams.bActivateImmediately = Kvp.Value.bActivateImmediately;
			const auto TaskID = MaterialParamController.AddCurveParam(
				UpdateParams, CurveBase, Kvp.Value.bNeedRemap, Kvp.Value.RemapTime, Kvp.Value.bLoop);
			if (TaskID != 0)
			{
				InOutContext.MaterialParamUpdateTaskIds.Add(Kvp.Key, TaskID);
				if (CurveBase)
				{
					if (CurveBase->IsA(UCurveFloat::StaticClass()))
					{
						InOutContext.ModifiedScalarParamNames.Add(Kvp.Key);
					}
					else
					{
						InOutContext.ModifiedVectorParamNames.Add(Kvp.Key);
					}
				}
			}
		}
		else
		{
			UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::InitConstMaterialParams, cannot find curve asset %s, %s"),
				*Kvp.Key.ToString(), *Kvp.Value.CurvePath);
		}
	}
	
	for (const auto& Kvp : ChangeMaterialParamRequest.ScalarRuntimeCurveParams)
	{
		const auto& CurveParams = Kvp.Value;
		UpdateParams.ParamName = Kvp.Key;
		const auto TaskID = MaterialParamController.AddScalarRuntimeCurveParam(
			UpdateParams, CurveParams.RuntimeFloatCurve, CurveParams.bNeedRemap, CurveParams.RemapTime, CurveParams.bLoop);
		if (TaskID != 0)
		{
			InOutContext.MaterialParamUpdateTaskIds.Add(Kvp.Key, TaskID);
		}
		InOutContext.ModifiedScalarParamNames.Add(Kvp.Key);
	}

	for (const auto& Kvp : ChangeMaterialParamRequest.ScalarLinearSampleParams)
	{
		uint32 TaskID = 0;
		if (Kvp.Value.CurTargetVal.IsSet() && Kvp.Value.NewDuration.IsSet())
		{
			if (FMath::IsNearlyEqual(Kvp.Value.StartVal, Kvp.Value.CurTargetVal.GetValue()) || FMath::IsNearlyZero(Kvp.Value.NewDuration.GetValue()))
			{
				SetScalarParameterBySetId(InOutContext.MaterialInstanceSetId, Kvp.Key, Kvp.Value.StartVal);
			}
			else
			{
				UpdateParams.ParamName = Kvp.Key;
				UpdateParams.bActivateImmediately = Kvp.Value.bActivateImmediately;
				TaskID = MaterialParamController.AddScalarLinearSampleParam(
					UpdateParams, Kvp.Value.StartVal, Kvp.Value.CurTargetVal.GetValue(), Kvp.Value.NewDuration.GetValue());
			}
		}
		else
		{
			UpdateParams.ParamName = Kvp.Key;
			UpdateParams.bActivateImmediately = Kvp.Value.bActivateImmediately;
			TaskID = MaterialParamController.AddScalarLinearSampleParam(
				UpdateParams, Kvp.Value.StartVal, Kvp.Value.EndVal, Kvp.Value.Duration);
		}

		if (TaskID != 0)
		{
			InOutContext.MaterialParamUpdateTaskIds.Add(Kvp.Key, TaskID);
		}
		InOutContext.ModifiedScalarParamNames.Add(Kvp.Key);
	}

	for (const auto& Kvp : ChangeMaterialParamRequest.VectorLinearSampleParams)
	{
		UpdateParams.ParamName = Kvp.Key;
		UpdateParams.bActivateImmediately = Kvp.Value.bActivateImmediately;
		const auto TaskID = MaterialParamController.AddVectorLinearSampleParam(
			UpdateParams, Kvp.Value.StartVal, Kvp.Value.EndVal, Kvp.Value.Duration);
		if (TaskID != 0)
		{
			InOutContext.MaterialParamUpdateTaskIds.Add(Kvp.Key, TaskID);
		}
		InOutContext.ModifiedVectorParamNames.Add(Kvp.Key);
	}

	for (const auto& Kvp : ChangeMaterialParamRequest.ActorLocationParams)
	{
		const auto& Param = Kvp.Value;
		UpdateParams.ParamName = Kvp.Key;
		UpdateParams.bActivateImmediately = false;
		const auto TaskID = MaterialParamController.AddActorLocationParam(
			UpdateParams, Param.Actor.Get(), Param.LocationType, Param.RelativeLocation, Param.SocketName);
		if (TaskID != 0)
		{
			InOutContext.MaterialParamUpdateTaskIds.Add(Kvp.Key, TaskID);
		}
		InOutContext.ModifiedVectorParamNames.Add(Kvp.Key);
	}

	for (const auto& Kvp : ChangeMaterialParamRequest.LinearBlendParams)
	{
		const auto& Param = Kvp.Value;
		UpdateParams.ParamName = Kvp.Key;
		UpdateParams.bActivateImmediately = false;
		const auto TaskID = MaterialParamController.AddLinearBlendParam(
			UpdateParams, Param.StartVal, Param.EndVal, Param.BlendInTime, Param.BlendOutTime, Param.Duration);
		if (TaskID != 0)
		{
			InOutContext.MaterialParamUpdateTaskIds.Add(Kvp.Key, TaskID);
		}
		InOutContext.ModifiedScalarParamNames.Add(Kvp.Key);
	}
}

void UKGMaterialManager::SetAllMaterialParamsToDefault(const FKGChangeMaterialParamContext& InOutContext)
{
	SCOPED_NAMED_EVENT(UKGMaterialManager_SetAllMaterialParamsToDefault, FColor::Red);
	
	const auto MaterialInstanceSetPtr = MaterialInstancesSets.Find(InOutContext.MaterialInstanceSetId);
	if (MaterialInstanceSetPtr == nullptr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::SetAllMaterialParamsToDefault, invalid material instance set id %d"), InOutContext.MaterialInstanceSetId);
		return;
	}

	for (auto& MaterialInstanceSetKvp : *MaterialInstanceSetPtr)
	{
		auto& DynamicMaterialInstance = MaterialInstanceSetKvp.Key;
		if (!DynamicMaterialInstance.IsValid())
		{
			continue;
		}

		UMaterialInstanceDynamic* MaterialInstanceDynamic = DynamicMaterialInstance.Get();
		BATCH_DMIPARAM_SCOPE(MaterialInstanceDynamic);

		for (const auto& ParamName : InOutContext.ModifiedScalarParamNames)
		{
			RemoveOrRevertMaterialParam(MaterialInstanceDynamic, MaterialInstanceSetKvp.Value, ParamName, EKGMaterialParamType::Scalar, true);
		}
		for (const auto& ParamName : InOutContext.ModifiedVectorParamNames)
		{
			RemoveOrRevertMaterialParam(MaterialInstanceDynamic, MaterialInstanceSetKvp.Value, ParamName, EKGMaterialParamType::LinearColor, true);
		}
		for (const auto& ParamName : InOutContext.ModifiedTextureParamNames)
		{
			RemoveOrRevertMaterialParam(MaterialInstanceDynamic, MaterialInstanceSetKvp.Value, ParamName, EKGMaterialParamType::Texture, true);
		}
	}
}

bool UKGMaterialManager::InternalRevertMaterialParam(FKGChangeMaterialParamContext& InOutContext, EKGMaterialParamRevertType RevertType)
{
	SCOPED_NAMED_EVENT(UKGMaterialManager_InternalRevertMaterialParam, FColor::Red);
	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::InternalRevertMaterialParam, %s"), *InOutContext.ToString());

	if (InOutContext.AssetLoadID != 0)
	{
		if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this))
		{
			AssetManager->CancelAsyncLoadByLoadID(InOutContext.AssetLoadID);
		}
		else
		{
			UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialParamController::RevertMaterialParam, cannot find asset manager"));
		}
	}
	
	RemoveMaterialParams(InOutContext, RevertType);

	const auto ActorID = InOutContext.ChangeMaterialParamRequest.OwnerActor.KGGetObjectID();
	if (ActorChangeMaterialParamReqIds.Contains(ActorID))
	{
		auto& ReqIds = ActorChangeMaterialParamReqIds[ActorID];
		if (ReqIds.Contains(InOutContext.ReqId))
		{
			ReqIds.Remove(InOutContext.ReqId);
		}
		else
		{
			UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::RevertMaterialParam, cannot find req id record %s"),
				*InOutContext.ToString());
		}
	}
	else
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::RevertMaterialParam, cannot find actor req id record %s"), 
			*InOutContext.ToString());
	}

	InOutContext.LifeTimeHandler.ClearTimer();

	AActor* OwnerActor = InOutContext.ChangeMaterialParamRequest.OwnerActor.Get();
	auto SourceReqID = InOutContext.ChangeMaterialParamRequest.SourceReqID;
	
	ChangeMaterialParamContexts.Remove(InOutContext.ReqId);

	RefreshAttachActorMaterialParams(OwnerActor, SourceReqID);
	return true;
}

void UKGMaterialManager::AddExcludedMeshComponentId(KGObjectID ActorID, KGObjectID MeshCompID, bool bIgnoreCameraDither, bool bIgnoreNonCameraDither)
{
	AActor* Actor = KGUtils::GetActorByID(ActorID);
	if (!Actor)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::AddExcludedMeshComponentId, invalid actor %lld"), ActorID);
		return;
	}

	UMeshComponent* MeshComp = Cast<UMeshComponent>(KGUtils::GetObjectByID(MeshCompID));
	if (!MeshComp)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::AddExcludedMeshComponentId, invalid mesh comp %lld"), MeshCompID);
		return;
	}

	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::AddExcludedMeshComponentId, %s, %s"), *Actor->GetName(), *MeshComp->GetName());
	
	auto& Comps = ActorExcludedMeshComps.FindOrAdd(ActorID);
	auto& ExcludeInfo = Comps.Add(MeshComp);
	ExcludeInfo.bIgnoreCameraDither = bIgnoreCameraDither;
	ExcludeInfo.bIgnoreNonCameraDither = bIgnoreNonCameraDither;
}

void UKGMaterialManager::RemoveExcludedMeshComponentId(KGObjectID ActorID, KGObjectID MeshCompID)
{
	UMeshComponent* MeshComp = Cast<UMeshComponent>(KGUtils::GetObjectByID(MeshCompID));
	if (!MeshComp)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::RemoveExcludedMeshComponentId, invalid mesh comp %lld"), MeshCompID);
		return;
	}

	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::RemoveExcludedMeshComponentId, %s, %s"),
		*GetNameSafe(KGUtils::GetActorByID(ActorID)), *MeshComp->GetName());
	
	auto* CompsPtr = ActorExcludedMeshComps.Find(ActorID);
	if (CompsPtr && CompsPtr->Contains(MeshComp))
	{
		CompsPtr->Remove(MeshComp);	
	}
}

uint32 UKGMaterialManager::GenerateReqId()
{
	return KGMaterialUtils::GenerateIncId(InnerChangeMaterialReqId);
}

void UKGMaterialManager::KAPI_MaterialManager_InitConfig(
	const FName& InCharacterHeightParamName, const FName& InCharacterDitherAlphaParamName,
	const FName& InDissolveColorParamName, int32 InWeaponDissolveInEdgeEffectID, int32 InWeaponDissolveOutEdgeEffectID,
	int32 InWeaponDissolveInType, int32 InWeaponDissolveOutType, float InMaxTimeSecondsProcessPendingInfo)
{
	CharacterHeightParamName = InCharacterHeightParamName;
	CharacterDitherAlphaParamName = InCharacterDitherAlphaParamName;
	DissolveColorParamName = InDissolveColorParamName;
	WeaponDissolveInEdgeEffectID = InWeaponDissolveInEdgeEffectID;
	WeaponDissolveOutEdgeEffectID = InWeaponDissolveOutEdgeEffectID;
	WeaponDissolveInType = InWeaponDissolveInType;
	WeaponDissolveOutType = InWeaponDissolveOutType;
	MaxTimeSecondsProcessPendingInfo = InMaxTimeSecondsProcessPendingInfo;
}

void UKGMaterialManager::KAPI_MaterialManager_AddValidClassType(UClass* InValidClassType)
{
	if (InValidClassType)
	{
		ValidClassTypes.Add(InValidClassType);
	}
	else
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::KAPI_MaterialManager_AddValidClassType, invalid class type"));
	}
}

void UKGMaterialManager::UpdateCharacterHeightParam(AActor* Actor, float NewCharacterHeight)
{
	KGMaterialCacheKeyMapping KeyMapping;
	GetAllAffectedMaterialCacheKeysByActor(Actor, false, true, false, EmptyExcludeMeshTags, KeyMapping);
	for (const auto& Kvp : KeyMapping)
	{
		for (const auto MaterialCacheKey : Kvp.Value)
		{
			UMaterialInstanceDynamic* MaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(
				KGMaterialUtils::GetMaterialInstanceByMaterialCacheKey(Kvp.Key.Get(), MaterialCacheKey));
			if (!MaterialInstanceDynamic)
			{
				continue;
			}

			if (CharacterHeightParamName.IsNone())
			{
				continue;
			}

			MaterialInstanceDynamic->SetScalarParameterValue(CharacterHeightParamName, NewCharacterHeight);
		}
	}
}

void UKGMaterialManager::InternalRevertMaterialParams(FKGChangeMaterialParamContext& InOutContext, bool bRevertMaterialParams)
{
	SCOPED_NAMED_EVENT(UKGMaterialManager_InternalRevertMaterialParams, FColor::Red);

	if (bRevertMaterialParams)
	{
		SetAllMaterialParamsToDefault(InOutContext);
	}

	RemoveMaterialInstanceSet(InOutContext.MaterialInstanceSetId);
	const bool bSkipMaterialParamRevert = !bRevertMaterialParams;
	for (const auto Kvp : InOutContext.MaterialParamUpdateTaskIds)
	{
		MaterialParamController.RemoveMaterialParamUpdateTask(Kvp.Value, bSkipMaterialParamRevert);
	}
}

void UKGMaterialManager::AssembleAssetsToLoad(FKGChangeMaterialParamContext& InOutContext)
{
	const auto& Request = InOutContext.ChangeMaterialParamRequest;
	for (const auto& Kvp : Request.TextureParams)
	{
		InOutContext.AssetPaths.Add(Kvp.Value);
		InOutContext.AssetParamNames.Add(Kvp.Key);
	}

	for (const auto& Kvp : Request.CurveParams)
	{
		InOutContext.AssetPaths.Add(Kvp.Value.CurvePath);
		InOutContext.AssetParamNames.Add(Kvp.Key);
	}
}

void UKGMaterialManager::InternalOnMaterialParamAssetsLoaded(int InLoadID, const TArray<UObject*>& Assets, uint32 ReqId, bool bAsyncAssetLoadCallback)
{
	SCOPED_NAMED_EVENT(UKGMaterialManager_InternalOnMaterialParamAssetsLoaded, FColor::Red);
	
	auto* ContextPtr = ChangeMaterialParamContexts.Find(ReqId);
	if (!ContextPtr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::InternalOnMaterialParamAssetsLoaded, invalid req id %d"), ReqId);
		return;
	}

	if (bAsyncAssetLoadCallback)
	{
		ContextPtr->AssetLoadID = 0;
	}
	
	// 避免重复执行
	if (ContextPtr->bAssetLoaded == true)
	{
		UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::InternalOnMaterialParamAssetsLoaded, asset already loaded, %s"),
			*ContextPtr->ToString());
		return;
	}
	ContextPtr->bAssetLoaded = true;
	
	if (Assets.Num() != ContextPtr->AssetPaths.Num() || 
		Assets.Num() != ContextPtr->AssetParamNames.Num())
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::InternalOnMaterialParamAssetsLoaded, invalid asset num %d/%d, %s"),
			Assets.Num(), ContextPtr->AssetPaths.Num(), *ContextPtr->ToString());
		return;
	}
	
	for (int32 i = 0; i < Assets.Num(); i++)
	{
		UObject* Asset = Assets[i];
		if (!Asset)
		{
			UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::InternalOnMaterialParamAssetsLoaded, invalid asset %s, %s"),
				*ContextPtr->AssetPaths[i], *ContextPtr->ToString());
			continue;
		}
		
		ContextPtr->LoadedAssets.Add(ContextPtr->AssetParamNames[i], Asset);
	}
	
	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::InternalOnMaterialParamAssetsLoaded, loaded %d assets, %s"),
		Assets.Num(), *ContextPtr->ToString());
	
	if (ContextPtr->ChangeMaterialParamRequest.bActivateImmediately)
	{
		ApplyMaterialParams(*ContextPtr);
	}
	else
	{
		ContextPtr->ExecStage = EKGChangeMaterialParamExecStage::PendingActivate;
		FKGMaterialRequestPendingInfo PendingInfo;
		PendingInfo.bActivated = true;
		PendingInfo.ReqID = ContextPtr->ReqId;
		PendingInfo.bIsChangeMaterialReq = false;
		PendingActiveMaterialRequests.PushLast(PendingInfo);
	}
}

bool UKGMaterialManager::IsChangeMaterialRequestActive(FKGChangeMaterialParamContext& InOutContext)
{
	const auto& Request = InOutContext.ChangeMaterialParamRequest;
	if (!Request.bUsePriorityControl)
	{
		return true;
	}

	if (InOutContext.ExecStage != EKGChangeMaterialParamExecStage::Activated)
	{
		return false;
	}

	uint32 ReqId;
	return MaterialParamController.GetActiveReqIdInPriorityQueue(
		Request.OwnerActor.Get(), Request.EffectType, ReqId) && ReqId == InOutContext.ReqId;
}

bool UKGMaterialManager::UpdateAndCacheManagers()
{
	if (!DataCacheManager.IsValid())
	{
		DataCacheManager = UKGDataCacheManager::GetInstance(this);
		if (!DataCacheManager.IsValid())
		{
			UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::StartDissolveMaterialEffect, invalid data cache manager"));
			return false;
		}
	}

	if (!ActorManager.IsValid())
	{
		ActorManager = UKGUEActorManager::GetInstance(this);
		if (!ActorManager.IsValid())
		{
			UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::StartDissolveMaterialEffect, invalid actor manager"));
			return false;
		}
	}

	return true;
}


void UKGMaterialManager::ProcessPendingMaterialRequests()
{
	SCOPED_NAMED_EVENT(UKGMaterialManager_ProcessPendingMaterialRequests, FColor::Red);
	
	if (PendingActiveMaterialRequests.Num() > 0)
	{
		auto StartTime = FPlatformTime::Seconds();
		FKGMaterialRequestPendingInfo PendingInfo;
		while (PendingActiveMaterialRequests.TryPopFirst(PendingInfo))
		{
			if (PendingInfo.bIsChangeMaterialReq)
			{
				auto* ChangeMaterialContextPtr = ChangeMaterialContexts.Find(PendingInfo.ReqID);
				if (!ChangeMaterialContextPtr)
				{
					continue;
				}
				
				if (PendingInfo.bActivated)
				{
					InternalChangeMaterial(*ChangeMaterialContextPtr);
				}
				else
				{
					InternalRevertMaterial(*ChangeMaterialContextPtr, PendingInfo.bRevertMaterial);	
				}
			}
			else
			{
				auto* ContextPtr = ChangeMaterialParamContexts.Find(PendingInfo.ReqID);
				if (!ContextPtr)
				{
					continue;
				}
				
				if (PendingInfo.bActivated)
				{
					ApplyMaterialParams(*ContextPtr);
				}
				else
				{
					InternalRevertMaterialParam(*ContextPtr, PendingInfo.RevertType);	
				}
			}
			
			const auto CurrentTime = FPlatformTime::Seconds();
			if (CurrentTime - StartTime >= MaxTimeSecondsProcessPendingInfo)
			{
				break;
			}	
		}
	}
}

void UKGMaterialManager::FlushMIDPool()
{
	FMaterialMIDPool::Get().Flush();
}