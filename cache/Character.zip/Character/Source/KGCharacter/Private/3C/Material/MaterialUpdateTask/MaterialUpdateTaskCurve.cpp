#include "3C/Material/MaterialUpdateTask/MaterialUpdateTaskCurve.h"

#include "Manager/KGCppAssetManager.h"
#include "3C/Material/KGMaterialManager.h"

bool FKGMaterialCurveParams::Execute(float DeltaTime)
{
	if (!FKGMaterialParamUpdateTaskBase::Execute(DeltaTime))
	{
		return false;
	}

	if (!CurveEvalParams.IsValid())
	{
		return false;
	}
	
	AccumulatedTime += DeltaTime;

	float FloatCurveVal = 0.0f;
	FVector VectorCurveVal = FVector::ZeroVector;
	FLinearColor LinearColorCurveVal = FLinearColor::Black;
	if (CurveEvalParams.GetFloatValue(AccumulatedTime, FloatCurveVal))
	{
		SetScalarParameterValue(FloatCurveVal);	
	}
	else if (CurveEvalParams.GetVectorValue(AccumulatedTime, VectorCurveVal))
	{
		SetVectorParameterValue(VectorCurveVal);
	}
	else if (CurveEvalParams.GetLinearColorValue(AccumulatedTime, LinearColorCurveVal))
	{
		SetVectorParameterValue(LinearColorCurveVal);
	}

	// 放在最后做是为了避免到不了curve的最后一个值
	if (CurveEvalParams.DoesTimeReachEnd(AccumulatedTime) && !bIsFinished)
	{
		bIsFinished = true;
	}
	
	return true;
}

void FKGMaterialCurveParams::OnTaskEnd()
{
	if (CurveAssetLoadID.IsSet())
	{
		if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(KGMaterialManager.Get()))
		{
			AssetManager->CancelAsyncLoadByLoadID(CurveAssetLoadID.GetValue());
			CurveAssetLoadID.Reset();
		}
		else
		{
			UE_LOG(LogKGMaterial, Error, TEXT("FKGMaterialCurveParams::OnTaskEnd, invalid asset manager"));
		}
	}
	
	FKGMaterialParamUpdateTaskBase::OnTaskEnd();
}

bool FKGMaterialScalarRuntimeCurveParams::Execute(float DeltaTime)
{
	if (!FKGMaterialParamUpdateTaskBase::Execute(DeltaTime))
	{
		return false;
	}

	if (!CurveEvalHelper.IsValid())
	{
		return false;
	}
	
	AccumulatedTime += DeltaTime;

	float FloatCurveVal = 0.0f;
	if (CurveEvalHelper.GetValue(AccumulatedTime, FloatCurveVal))
	{
		SetScalarParameterValue(FloatCurveVal);	
	}

	// 放在最后做是为了避免到不了curve的最后一个值
	if (CurveEvalHelper.DoesTimeReachEnd(AccumulatedTime) && !bIsFinished)
	{
		bIsFinished = true;
	}
	
	return true;
}