#include "3C/Material/KGMaterialManager.h"

#include "3C/Core/C7ActorInterface.h"
#include "3C/Core/KGUEActorManager.h"
#include "3C/RoleComposite/RoleCompositeManager.h"
#include "Components/CapsuleComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "3C/Effect/KGEffectManager.h"
#include "Engine/StaticMesh.h"
#include "Managers/KGDataCacheManager.h"
#include "3C/Material/KGMaterialCommon.h"
#include "Runtime/AvatarBodyPartType.h"
#include "3C/Util/KGUtils.h"

#pragma region RainEffect

void UKGMaterialManager::KAPI_MaterialManager_SetRainEffectParams(
	const TArray<FName>& InRainEffectFaceSlotName, const TArray<FName>& InRainEffectBodySlotName,
	const FString& InRainEffectFaceMaterialPath, const FString& InRainEffectBodyMaterialPath, const FString& InRainEffectBodyWithTightMaterialPath,
	const FName& InRainEffectSimpleWetIntensityParamName, const FName& InRainEffectGeneralWetIntensityParamName,
	const TArray<FName>& InRainEffectScalarParamsInheritFromDefaultMaterial,
	const TArray<FName>& InRainEffectVectorParamsInheritFromDefaultMaterial,
	const TArray<FName>& InRainEffectTextureParamsInheritFromDefaultMaterial,
	uint32 InRainEffectPriority, int32 InMaxParentMaterialCheckNum)
{
	RainEffectFaceSlotNames = InRainEffectFaceSlotName;
	RainEffectBodySlotNames = InRainEffectBodySlotName;
	RainEffectFaceMaterialPath = InRainEffectFaceMaterialPath;
	RainEffectBodyMaterialPath = InRainEffectBodyMaterialPath;
	RainEffectBodyWithTightMaterialPath = InRainEffectBodyWithTightMaterialPath;
	RainEffectSimpleWetIntensityParamName = InRainEffectSimpleWetIntensityParamName;
	RainEffectGeneralWetIntensityParamName = InRainEffectGeneralWetIntensityParamName;
	ScalarParamsInheritFromDefaultMaterial = InRainEffectScalarParamsInheritFromDefaultMaterial;
	VectorParamsInheritFromDefaultMaterial = InRainEffectVectorParamsInheritFromDefaultMaterial;
	TextureParamsInheritFromDefaultMaterial = InRainEffectTextureParamsInheritFromDefaultMaterial;
	RainEffectMaterialPriority = InRainEffectPriority;
	MaxParentMaterialCheckNum = InMaxParentMaterialCheckNum;
}

void UKGMaterialManager::KAPI_MaterialManager_AddRainEffectFaceEffectiveParentMaterialPath(const FName& BodySlotName, const TArray<FName>& ParentMaterials)
{
	RainEffectFaceEffectiveParentMaterialNames.Add(BodySlotName, TSet(ParentMaterials));
}

void UKGMaterialManager::KAPI_MaterialManager_AddRainEffectBodyEffectiveParentMaterialPath(const FName& BodySlotName, const TArray<FName>& ParentMaterials)
{
	RainEffectBodyEffectiveParentMaterialNames.Add(BodySlotName, TSet(ParentMaterials));
}

void UKGMaterialManager::KAPI_MaterialManager_AddRainEffectBodyWithTightEffectiveParentMaterialPath(const FName& BodySlotName, const TArray<FName>& ParentMaterials)
{
	RainEffectBodyWithTightEffectiveParentMaterialNames.Add(BodySlotName, TSet(ParentMaterials));
}

void UKGMaterialManager::KAPI_MaterialManager_EmptyRainEffectEffectiveParentMaterialPath()
{
	RainEffectFaceEffectiveParentMaterialNames.Empty();
	RainEffectBodyEffectiveParentMaterialNames.Empty();
	RainEffectBodyWithTightEffectiveParentMaterialNames.Empty();
}

void UKGMaterialManager::KAPI_MaterialManager_EnableRainEffect(KGObjectID ActorId, float SimpleWetIntensity, EKGRainEffectEffectiveType EffectiveType)
{
	AActor* Actor = KGUtils::GetActorByID(ActorId);
	EnableRainEffect(Actor, SimpleWetIntensity, EffectiveType);
}

void UKGMaterialManager::KAPI_MaterialManager_EnableSimpleRainEffect(KGObjectID ActorId, float SimpleWetIntensity)
{
	AActor* Actor = KGUtils::GetActorByID(ActorId);
	EnableSimpleRainEffect(Actor, SimpleWetIntensity);
}

void UKGMaterialManager::KAPI_MaterialManager_DisableRainEffect(KGObjectID ActorId)
{
	AActor* Actor = KGUtils::GetActorByID(ActorId);
	DisableRainEffect(Actor);
}

bool UKGMaterialManager::EnableRainEffect(AActor* Actor, float SimpleWetIntensity, EKGRainEffectEffectiveType EffectiveType)
{
	if (!Actor)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::EnableRainEffect, invalid actor"));
		return false;
	}
	
	if (ActorRainEffectReqIDs.Contains(Actor))
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::EnableRainEffect, rain effect already enabled for actor %s"), *Actor->GetName());
		return false;
	}
	
	if (EffectiveType == EKGRainEffectEffectiveType::AllParts)
	{
		return EnableRainEffect_AllParts(Actor, SimpleWetIntensity);
	}
	
	if (EffectiveType == EKGRainEffectEffectiveType::FaceOnly)
	{
		return EnableRainEffect_FaceOnly(Actor);
	}
	
	return false;
}

bool UKGMaterialManager::EnableRainEffect_AllParts(AActor* Actor, float SimpleWetIntensity)
{
	if (RainEffectFaceMaterialPath.IsEmpty() || RainEffectBodyMaterialPath.IsEmpty() ||
		RainEffectFaceSlotNames.Num() == 0 || RainEffectBodySlotNames.Num() == 0)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::EnableRainEffect_AllParts, rain effect not configured"));
		return false;
	}

	FKGRainEffectReqIDs& ActorRainEffectReqID = ActorRainEffectReqIDs.Add(Actor);
	
	FKGChangeMaterialRequest ChangeFaceMaterialRequest;
	ChangeFaceMaterialRequest.MaterialPath = RainEffectFaceMaterialPath;
	ChangeFaceMaterialRequest.OwnerActor = Actor;
	ChangeFaceMaterialRequest.Priority = RainEffectMaterialPriority;
	ChangeFaceMaterialRequest.SearchMeshType = EKGSearchMeshType::SearchMeshByName;
	ChangeFaceMaterialRequest.SearchMeshName = URoleCompositeMgr::AvatarBodyPartEnumToName(static_cast<int32>(EAvatarBodyPartType::Head));
	ChangeFaceMaterialRequest.SearchMaterialType = EKGSearchMaterialType::SearchMaterialBySlots;
	ChangeFaceMaterialRequest.MaterialSlotNames = RainEffectFaceSlotNames;
	ChangeFaceMaterialRequest.ScalarParamsInheritFromDefaultMaterial = ScalarParamsInheritFromDefaultMaterial;
	ChangeFaceMaterialRequest.VectorParamsInheritFromDefaultMaterial = VectorParamsInheritFromDefaultMaterial;
	ChangeFaceMaterialRequest.TextureParamsInheritFromDefaultMaterial = TextureParamsInheritFromDefaultMaterial;
	ChangeFaceMaterialRequest.EffectiveParentMaterialNames = RainEffectFaceEffectiveParentMaterialNames;
	const auto FaceMaterialReqID = ChangeMaterial(ChangeFaceMaterialRequest);
	ActorRainEffectReqID.RainEffectMaterialReqIDs.Add(FaceMaterialReqID);

	FKGChangeMaterialRequest ChangeBodyMaterialRequest;
	ChangeBodyMaterialRequest.MaterialPath = RainEffectBodyMaterialPath;
	ChangeBodyMaterialRequest.OwnerActor = Actor;
	ChangeBodyMaterialRequest.Priority = RainEffectMaterialPriority;
	ChangeBodyMaterialRequest.SearchMaterialType = EKGSearchMaterialType::SearchMaterialBySlots;
	ChangeBodyMaterialRequest.MaterialSlotNames = RainEffectBodySlotNames;
	ChangeBodyMaterialRequest.ScalarParamsInheritFromDefaultMaterial = ScalarParamsInheritFromDefaultMaterial;
	ChangeBodyMaterialRequest.VectorParamsInheritFromDefaultMaterial = VectorParamsInheritFromDefaultMaterial;
	ChangeBodyMaterialRequest.TextureParamsInheritFromDefaultMaterial = TextureParamsInheritFromDefaultMaterial;
	ChangeBodyMaterialRequest.EffectiveParentMaterialNames = RainEffectBodyEffectiveParentMaterialNames;
	const auto BodyMaterialReqID = ChangeMaterial(ChangeBodyMaterialRequest);
	ActorRainEffectReqID.RainEffectMaterialReqIDs.Add(BodyMaterialReqID);

	FKGChangeMaterialRequest ChangeBodyWithTightMaterialRequest;
	ChangeBodyWithTightMaterialRequest.MaterialPath = RainEffectBodyWithTightMaterialPath;
	ChangeBodyWithTightMaterialRequest.OwnerActor = Actor;
	ChangeBodyWithTightMaterialRequest.Priority = RainEffectMaterialPriority;
	ChangeBodyWithTightMaterialRequest.SearchMaterialType = EKGSearchMaterialType::SearchMaterialBySlots;
	ChangeBodyWithTightMaterialRequest.MaterialSlotNames = RainEffectBodySlotNames;
	ChangeBodyWithTightMaterialRequest.ScalarParamsInheritFromDefaultMaterial = ScalarParamsInheritFromDefaultMaterial;
	ChangeBodyWithTightMaterialRequest.VectorParamsInheritFromDefaultMaterial = VectorParamsInheritFromDefaultMaterial;
	ChangeBodyWithTightMaterialRequest.TextureParamsInheritFromDefaultMaterial = TextureParamsInheritFromDefaultMaterial;
	ChangeBodyWithTightMaterialRequest.EffectiveParentMaterialNames = RainEffectBodyWithTightEffectiveParentMaterialNames;
	const auto BodyWithTightMaterialReqID = ChangeMaterial(ChangeBodyWithTightMaterialRequest);
	ActorRainEffectReqID.RainEffectMaterialReqIDs.Add(BodyWithTightMaterialReqID);
	
	FKGChangeMaterialParamRequest ChangeMaterialParamRequest;
	ChangeMaterialParamRequest.OwnerActor = Actor;
	ChangeMaterialParamRequest.ScalarParams.Add(RainEffectSimpleWetIntensityParamName, SimpleWetIntensity);
	ChangeMaterialParamRequest.ScalarParams.Add(RainEffectGeneralWetIntensityParamName, SimpleWetIntensity);
	ActorRainEffectReqID.RainEffectMaterialParamReqID = ChangeMaterialParam(ChangeMaterialParamRequest);

	return true;
}

bool UKGMaterialManager::EnableRainEffect_FaceOnly(AActor* Actor)
{
	if (RainEffectFaceMaterialPath.IsEmpty() || RainEffectFaceSlotNames.Num() == 0)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::EnableRainEffect_FaceOnly, rain effect not configured"));
		return false;
	}

	FKGRainEffectReqIDs& ActorRainEffectReqID = ActorRainEffectReqIDs.Add(Actor);
	
	const FName& HeadName = URoleCompositeMgr::AvatarBodyPartEnumToName(static_cast<int32>(EAvatarBodyPartType::Head));
	FKGChangeMaterialRequest ChangeFaceMaterialRequest;
	ChangeFaceMaterialRequest.MaterialPath = RainEffectFaceMaterialPath;
	ChangeFaceMaterialRequest.OwnerActor = Actor;
	ChangeFaceMaterialRequest.Priority = RainEffectMaterialPriority;
	ChangeFaceMaterialRequest.SearchMeshType = EKGSearchMeshType::SearchMeshByName;
	ChangeFaceMaterialRequest.SearchMeshName = HeadName;
	ChangeFaceMaterialRequest.SearchMaterialType = EKGSearchMaterialType::SearchMaterialBySlots;
	ChangeFaceMaterialRequest.MaterialSlotNames = RainEffectFaceSlotNames;
	ChangeFaceMaterialRequest.ScalarParamsInheritFromDefaultMaterial = ScalarParamsInheritFromDefaultMaterial;
	ChangeFaceMaterialRequest.VectorParamsInheritFromDefaultMaterial = VectorParamsInheritFromDefaultMaterial;
	ChangeFaceMaterialRequest.TextureParamsInheritFromDefaultMaterial = TextureParamsInheritFromDefaultMaterial;
	ChangeFaceMaterialRequest.EffectiveParentMaterialNames = RainEffectFaceEffectiveParentMaterialNames;
	const auto FaceMaterialReqID = ChangeMaterial(ChangeFaceMaterialRequest);
	ActorRainEffectReqID.RainEffectMaterialReqIDs.Add(FaceMaterialReqID);

	return true;
}

void UKGMaterialManager::DisableRainEffect(AActor* Actor)
{
	if (!Actor)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::DisableRainEffect, invalid actor"));
		return;
	}

	auto* ReqIDsPtr = ActorRainEffectReqIDs.Find(Actor);
	if (ReqIDsPtr == nullptr)
	{
		UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::DisableRainEffect, rain effect not enabled for actor %s"), *Actor->GetName());
		return;
	}
	
	if (ReqIDsPtr->RainEffectMaterialReqIDs.Num() > 0)
	{
		for (uint32 ReqID : ReqIDsPtr->RainEffectMaterialReqIDs)
		{
			RevertMaterial(ReqID);
		}
	}

	RevertMaterialParam(ReqIDsPtr->RainEffectMaterialParamReqID);
	ActorRainEffectReqIDs.Remove(Actor);
}

bool UKGMaterialManager::EnableSimpleRainEffect(AActor* Actor, float SimpleWetIntensity)
{
	if (!Actor)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::EnableSimpleRainEffect, invalid actor"));
		return false;
	}
	
	if (ActorRainEffectReqIDs.Contains(Actor))
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::EnableSimpleRainEffect, rain effect already enabled for actor %s"), *Actor->GetName());
		return false;
	}

	FKGRainEffectReqIDs& ActorRainEffectReqID = ActorRainEffectReqIDs.Add(Actor);

	FKGChangeMaterialParamRequest ChangeMaterialParamRequest;
	ChangeMaterialParamRequest.OwnerActor = Actor;
	ChangeMaterialParamRequest.ScalarParams.Add(RainEffectSimpleWetIntensityParamName, SimpleWetIntensity);
	ActorRainEffectReqID.RainEffectMaterialParamReqID = ChangeMaterialParam(ChangeMaterialParamRequest);

	return true;
}

#pragma endregion RainEffect

#pragma region ModelColor

TArray<uint32> UKGMaterialManager::ChangeModelColor(AActor* Actor, const FString& ModelName, const FString& ColorName)
{
	TArray<uint32> ReqIDs;
	if (!IsValid(Actor))
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::ChangeModelColor: Actor is not valid"));
		return ReqIDs;
	}

	URoleCompositeMgr* RoleCompositeMgr = URoleCompositeMgr::GetInstance(Actor);
	if (!RoleCompositeMgr)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::ChangeModelColor: RoleCompositeMgr is null, Actor:%s"), *Actor->GetName());
		return ReqIDs;
	}
	
	const auto& ColorData = RoleCompositeMgr->GetModelColorMaterialData(ModelName, ColorName);
	if (ColorData.Num() == 0)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::ChangeModelColor: can not find color data, ModelName:%s, ColorName:%s"), *ModelName, *ColorName);
		return ReqIDs;
	}

	USkeletalMeshComponent* SkeletalMeshComponent = Actor->FindComponentByClass<USkeletalMeshComponent>();
	if (!SkeletalMeshComponent)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::ChangeModelColor: can not find SkeletalMeshComponent, Actor:%s"), *Actor->GetName());
		return ReqIDs;
	}

	TArray<TWeakObjectPtr<UMeshComponent>> MeshComps;
	MeshComps.Add(SkeletalMeshComponent);
	const auto& MaterialSlotNames = SkeletalMeshComponent->GetMaterialSlotNames();
	
	for (const auto& Kvp : ColorData)
	{
		const auto& SlotIndex  = Kvp.Key;
		if (!MaterialSlotNames.IsValidIndex(SlotIndex))
		{
			UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::ChangeModelColor: invalid slot index, ModelName:%s, ColorName:%s, SlotIndex: %d"),
				*ModelName, *ColorName, SlotIndex);
			continue;
		}
		const auto& SlotName = MaterialSlotNames[SlotIndex];
		
		const auto& MaterialPath = Kvp.Value;
		if (!MaterialPath.IsNone())
		{
			FKGChangeMaterialRequest ChangeMaterialRequest;
			ChangeMaterialRequest.MaterialPath = MaterialPath.ToString();
			ChangeMaterialRequest.SearchMeshType = EKGSearchMeshType::UseCustomMeshComps;
			ChangeMaterialRequest.CustomMeshComps = MeshComps;
			ChangeMaterialRequest.SearchMaterialType = EKGSearchMaterialType::SearchMaterialBySlots;
			ChangeMaterialRequest.MaterialSlotNames.Add(SlotName);
			ChangeMaterialRequest.Priority = static_cast<uint32>(EKGMaterialPriority::ChangeModelColor);
			ChangeMaterialRequest.OwnerActor = Actor;

			const uint32 ReqID = ChangeMaterial(ChangeMaterialRequest);
			if (ReqID != 0)
			{
				ReqIDs.Add(ReqID);
			}
		}
		else
		{
			UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::ChangeModelColor: invalid material path, ModelName:%s, ColorName:%s, SlotIndex: %d"),
				*ModelName, *ColorName, SlotIndex);
		}
	}

	return ReqIDs;
}

#pragma endregion ModelColor

#pragma region CameraDither

void UKGMaterialManager::KAPI_MaterialManager_SetCameraDitherInfos(
	const FName& CharacterTypeParamName, const FName& DistanceScaleParamName, float InCapsuleScale,
	uint32 MaxEnableNumPerTick, const FString& CharacterDefaultOLMPath, const FString& EnvDefaultOLMPath, const FName& IfUseWorldPositionParamName,
	const FName& WorldPivotPointParamName, const FName& ManorBuildingMeshTag,
	const FName& InUseActorLocationParamName, const FName& InUseActorLocationMeshTag,
	const FName& InCameraDitherAngleThresholdMinName,const FName& InCameraDitherAngleThresholdMaxName, float DefaultDistanceScale)
{
	CameraDither_CharacterTypeParamName = CharacterTypeParamName;
	CameraDither_DistanceScaleParamName = DistanceScaleParamName;
	CameraDither_CapsuleScale = InCapsuleScale; 
	CameraDither_MaxEnableCameraDitherNumPerTick = MaxEnableNumPerTick;
	CameraDither_IfUseWorldPositionParamName = IfUseWorldPositionParamName;
	CameraDither_WorldPivotPointParamName = WorldPivotPointParamName;
	CameraDither_ManorBuildingMeshTag = ManorBuildingMeshTag;
	CameraDither_UseActorLocationParamName = InUseActorLocationParamName;
	UseSelfLocationMeshTag = InUseActorLocationMeshTag;

	CameraDither_ExcludeMeshTags.Empty();
	CameraDither_ExcludeMeshTags.Add(CameraDither_ManorBuildingMeshTag);
	// 初始化时做一次, 加载完成后常驻内存
	if (!CharacterDefaultOLMPath.IsEmpty())
	{
		CameraDither_CharacterDefaultOLM = Cast<UMaterialInterface>(StaticLoadObject(UMaterialInterface::StaticClass(), nullptr, *CharacterDefaultOLMPath));
		UE_CLOG(CameraDither_CharacterDefaultOLM == nullptr, LogKGMaterial, Error,
			TEXT("UKGMaterialManager::SetCameraDitherInfos, load invalid CharacterDefaultOLMPath: %s"), *CharacterDefaultOLMPath);
	}
	if (!EnvDefaultOLMPath.IsEmpty())
	{
		CameraDither_EnvDefaultOLM = Cast<UMaterialInterface>(StaticLoadObject(UMaterialInterface::StaticClass(), nullptr, *EnvDefaultOLMPath));
		UE_CLOG(CameraDither_EnvDefaultOLM == nullptr, LogKGMaterial, Error,
			TEXT("UKGMaterialManager::SetCameraDitherInfos, load invalid EnvDefaultOLMPath: %s"), *EnvDefaultOLMPath);
	}
	
	CameraDither_AngleThresholdMinParamName = InCameraDitherAngleThresholdMinName;
	CameraDither_AngleThresholdMaxParamName = InCameraDitherAngleThresholdMaxName;
	CameraDither_DefaultDistanceScale = DefaultDistanceScale;
}

void UKGMaterialManager::KAPI_MaterialManager_AddRoleCompositeParamCopyToOLM(
	const FName& SlotName, const TArray<FName>& ScalarParamNames, const TArray<FName>& VectorParamNames, const TArray<FName>& TextureParamNames)
{
	auto& ParamNames = RoleCompositeParamsCopyToOLM.Add(SlotName);
	ParamNames.ScalarParamNames.Reset();
	ParamNames.ScalarParamNames.Append(ScalarParamNames);
	
	ParamNames.VectorParamNames.Reset();
	ParamNames.VectorParamNames.Append(VectorParamNames);
	
	ParamNames.TextureParamNames.Reset();
	ParamNames.TextureParamNames.Append(TextureParamNames);
}

void UKGMaterialManager::EnableCameraDither(AActor* InActor, UMeshComponent* InComponent)
{
	if (!IsValid(InActor))
	{
		return;
	}

	if (!UpdateAndCacheManagers())
	{
		return;
	}
	check(ActorManager.IsValid());

	FKGCameraDitherKey CameraDitherKey;
	CameraDitherKey.Actor = InActor;
	CameraDitherKey.Component = InComponent;
	if (IC7ActorInterface* C7ActorInterface = Cast<IC7ActorInterface>(InActor))
	{
		if (auto* Entity = ActorManager->GetLuaEntity(C7ActorInterface->GetEntityUID()))
		{
			if (!Entity->IsCameraDitherEnabled())
			{
				return;
			}
		}
	}
	
	if (!IsValid(InComponent))
	{
		CameraDitherKey.bReplaceAllMeshOLM = true;
	}
	
	if (CameraDitherInfos.Contains(CameraDitherKey))
	{
		// 已经启用的忽略
		return;
	}
	
	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::EnableCameraDither, actor %s, component: %s"), *InActor->GetName(), *GetNameSafe(InComponent));

	PendingActivateCameraDitherComponents.PushLast(CameraDitherKey);
	CameraDitherInfos.Add(CameraDitherKey, 0);
}

void UKGMaterialManager::DisableCameraDither(AActor* InActor, UMeshComponent* InComponent)
{
	if (!IsValid(InActor))
	{
		return;
	}

	FKGCameraDitherKey CameraDitherKey;
	CameraDitherKey.Actor = InActor;
	CameraDitherKey.Component = InComponent;
	if (!IsValid(InComponent))
	{
		CameraDitherKey.bReplaceAllMeshOLM = true;
	}
	
	if (!CameraDitherInfos.Contains(CameraDitherKey))
	{
		// 已经启用的忽略
		return;
	}

	SCOPED_NAMED_EVENT(UKGMaterialManager_DisableCameraDither, FColor::Red);	

	UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::DisableCameraDither, actor %s, component: %s"), *InActor->GetName(), *GetNameSafe(InComponent));
	
	const auto ReqID = CameraDitherInfos[CameraDitherKey];
	if (ReqID != 0)
	{
		// 如果有对应的请求, 则需要先回退材质参数
		RevertMaterialParam(ReqID);
	}
	CameraDitherInfos.Remove(CameraDitherKey);
}

void UKGMaterialManager::RevertAllCameraDither()
{
	for (const auto& Kvp : CameraDitherInfos)
	{
		if (Kvp.Value == 0)
		{
			continue;
		}
		
		RevertMaterialParam(Kvp.Value);
	}
	CameraDitherInfos.Empty();
}


void UKGMaterialManager::UpdateCameraDitherActors()
{
	uint32 CameraDitherNumEnabled = 0;
	FKGCameraDitherKey CameraDitherKey;
	while (PendingActivateCameraDitherComponents.TryPopFirst(CameraDitherKey))
	{
		if (!CameraDitherKey.Actor.IsValid() ||
			!CameraDitherInfos.Contains(CameraDitherKey))
		{
			continue;
		}

		if (!CameraDitherKey.bReplaceAllMeshOLM &&
			!CameraDitherKey.Component.IsValid())
		{
			continue;
		}

		CameraDitherNumEnabled++;
		InternalEnableCameraDither(CameraDitherKey);
		
		if (CameraDitherNumEnabled >= CameraDither_MaxEnableCameraDitherNumPerTick)
		{
			break;
		}
	}
}

void UKGMaterialManager::InternalEnableCameraDither(const FKGCameraDitherKey& Key)
{
	SCOPED_NAMED_EVENT(FKGMaterialEffectController_EnableCameraDither, FColor::Red);	
	
	// 后续一些角色体型数据可能要作为材质参数传下去
	FKGChangeMaterialParamRequest CameraDitherRequest;
	CameraDitherRequest.SearchMaterialType = EKGSearchMaterialType::SearchRuntimeSeparateOverlayMaterial;
	CameraDitherRequest.OwnerActor = Key.Actor;
	CameraDitherRequest.bIsCameraDither = true;
	if (IC7ActorInterface* C7ActorInterface = Cast<IC7ActorInterface>(Key.Actor.Get()))
	{
		UpdateAndCacheManagers();
		if (ActorManager.IsValid())
		{
			if (auto* Entity = ActorManager->GetLuaEntity(C7ActorInterface->GetEntityUID()))
			{
				if (Entity->GetUseCharacterTypeCameraDither())
				{
					CameraDitherRequest.bUseCharacterCameraDither = true;
					
					const FName& CameraDitherPivotSocketName = Entity->GetCameraDitherPivotSocketName();
					if (CameraDitherPivotSocketName != NAME_None)
					{
						CameraDitherRequest.bUseWorldPivotPositionForCameraDither = true;
						
						FKGActorLocationMaterialParams ActorLocationMaterialParams;
						ActorLocationMaterialParams.Actor = Key.Actor;
						ActorLocationMaterialParams.LocationType = EKGMaterialParamActorLocationType::UseSocketLocation;
						ActorLocationMaterialParams.SocketName = CameraDitherPivotSocketName;
						CameraDitherRequest.ActorLocationParams.Add(CameraDither_WorldPivotPointParamName, ActorLocationMaterialParams);
					}
					
					// 虚化百分比 dither_alpha = (cam_pos - pivot_pos_ws).distance / distance_scale
					// distance_scale = capsule_scale * capsule_half_height
					// 为了方便外部使用, 外部总是配置单位胶囊体半径的倍率 capsule_scale
					float DistanceScale = CameraDither_DefaultDistanceScale;
					// 默认的情况下, 这里的pivot position是一个mesh local space的坐标点, 材质内部会将其转化到世界空间并根据mesh与相机的距离来计算虚化程度
					// 对于武器来说, 为了确保武器跟角色始终保持相同的虚化程度, 武器需要外部传入世界空间位置, 不能在材质里面自行计算, 且传入的总是parent的世界空间位置
					if (UCapsuleComponent* Capsule = Key.Actor->GetComponentByClass<UCapsuleComponent>())
					{
						float CapsuleScale = CameraDither_CapsuleScale;
						FLinearColor PivotOffset = FLinearColor::Black;
						if (Entity->GetIsMainPlayer())
						{
							const auto HalfHeight = Capsule->GetScaledCapsuleHalfHeight();
							PivotOffset.B = HalfHeight * 2.0 - Capsule->GetScaledCapsuleRadius();
							if (!FMath::IsNearlyZero(PivotOffset.B))
							{
								CapsuleScale *= (HalfHeight / PivotOffset.B);
							}
							else
							{
								UE_LOG(LogKGMaterial, Error,
									TEXT("UKGMaterialManager::EnableCameraDither, invalid capsule half height %f, radius %f, actor %s"), 
									HalfHeight, Capsule->GetScaledCapsuleRadius(), *Key.Actor->GetName());
							}
						}
						else
						{
							PivotOffset.B = Capsule->GetScaledCapsuleHalfHeight();
						}
			
						DistanceScale = CapsuleScale * PivotOffset.B;
					}
					
					CameraDitherRequest.ScalarParams.Add(CameraDither_DistanceScaleParamName, DistanceScale);	
				}
			}
		}
	}

	if (!Key.bReplaceAllMeshOLM)
	{
		CameraDitherRequest.SearchMeshType = EKGSearchMeshType::UseCustomMeshComps;
		CameraDitherRequest.CustomMeshComps.Add(Key.Component);
	}

	// 这里可以补充定制的角色参数, 例如角色当前体型数据
	const auto ReqID = ChangeMaterialParam(CameraDitherRequest);
	CameraDitherInfos.Add(Key, ReqID);
}

#pragma endregion CameraDither

#pragma region Dissolve

uint32 UKGMaterialManager::KAPI_MaterialManager_StartDissolveMaterialEffectByDissolveEffectID(
	KGEntityID EntityID, KGActorID ActorID, int32 DissolveEffectID, bool bAutoRevertMaterialEffect, uint32 Priority, uint32 CustomEffectID)
{
	AActor* Actor = KGUtils::GetActorByID(ActorID);
	if (!Actor)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::StartDissolveMaterialEffect, invalid actor"));
		return 0;
	}
	return StartDissolveMaterialEffectByDissolveEffectID(EntityID, Actor, DissolveEffectID, bAutoRevertMaterialEffect, Priority, CustomEffectID);
}

uint32 UKGMaterialManager::StartDissolveMaterialEffectByDissolveEffectID(
	KGEntityID EntityID, AActor* Actor, int32 DissolveEffectID, bool bAutoRevertMaterialEffect, uint32 Priority, uint32 CustomEffectID)
{
	SCOPED_NAMED_EVENT(UKGMaterialManager_StartDissolveMaterialEffectByDissolveEffectID, FColor::Red);
	
	if (!IsValid(Actor))
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::StartDissolveMaterialEffect, invalid actor"));
		return 0;
	}

	if (!UpdateAndCacheManagers())
	{
		return 0;
	}
	check(DataCacheManager.IsValid());
	check(ActorManager.IsValid());

	auto* DissolveEffectData = DataCacheManager->GetDissolveEffectData(DissolveEffectID);
	if (!DissolveEffectData)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::StartDissolveMaterialEffect, cannot find dissolve effect data %d"), DissolveEffectID);
		return 0;
	}

	FKGChangeMaterialParamRequest DissolveMaterialParamRequest;
	DissolveMaterialParamRequest.OwnerActor = Actor;
	DissolveMaterialParamRequest.EffectType = EKGMaterialEffectType::Dissolve;
	DissolveMaterialParamRequest.SearchMeshType = EKGSearchMeshType::SearchAllMesh;
	DissolveMaterialParamRequest.Priority = Priority;
	DissolveMaterialParamRequest.bActivateImmediately = true;

	if (CustomEffectID != 0)
	{
		DissolveMaterialParamRequest.CustomChangeMaterialParamReqId = CustomEffectID;
	}
	
	if (DissolveEffectData->MaterialSlotNames.Num() > 0)
	{
		DissolveMaterialParamRequest.SearchMaterialType = EKGSearchMaterialType::SearchMaterialBySlots;
		DissolveMaterialParamRequest.MaterialSlotNames = DissolveEffectData->MaterialSlotNames;
	}
	
	ProcessMaterialParams(DissolveEffectData->DissolveType, true, DissolveMaterialParamRequest);

	if (DissolveEffectData->bLinearSampleDissolve)
	{
		auto& ScalarLinearSampleParams = DissolveMaterialParamRequest.ScalarLinearSampleParams;
		if (ScalarLinearSampleParams.Contains(DissolveEffectData->DissolveSwitchParamName))
		{
			ScalarLinearSampleParams[DissolveEffectData->DissolveSwitchParamName].Duration = DissolveEffectData->Duration;
		}
	}
	else
	{
		auto& CurveParams = DissolveMaterialParamRequest.CurveParams;
		if (CurveParams.Contains(DissolveEffectData->DissolveSwitchParamName))
		{
			auto& CurveParam = CurveParams[DissolveEffectData->DissolveSwitchParamName];
			CurveParam.bNeedRemap = true;
			CurveParam.RemapTime = DissolveEffectData->Duration;
		}
	}
	
	if (DissolveEffectData->bOverrideDissolveColor)
	{
		DissolveMaterialParamRequest.VectorParams.Add(DissolveColorParamName, DissolveEffectData->OverrideDissolveColor);
	}

	if (bAutoRevertMaterialEffect)
	{
		DissolveMaterialParamRequest.TotalLifeTimeMs = DissolveEffectData->Duration * 1000.0f;
	}

	if (DissolveEffectData->EffectIDs.Num() > 0)
	{
		if (UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(this))
		{
			for (auto EffectID : DissolveEffectData->EffectIDs)
			{
				EffectManager->CreateNiagaraSystemByAttachEffectDataID(
					EffectID, DissolveEffectData->Duration,
					EKGNiagaraDestroyType::BlendOutBeforeDestroy, false, 0.0f, false, 0,
					KGUtils::GetIDByObject(Actor), EntityID);
			}
		}
		else
		{
			UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::StartDissolveMaterialEffect, cannot find effect manager"));
		}
	}

	if (DissolveEffectData->DissolveType == WeaponDissolveInType || DissolveEffectData->DissolveType == WeaponDissolveOutType)
	{
		const bool bDissolveIn = (DissolveEffectData->DissolveType == WeaponDissolveInType);
		PlayExtraWeaponDissolveEffect(DissolveEffectData, Actor, bDissolveIn);
	}
	
	return ChangeMaterialParam(DissolveMaterialParamRequest);
}

uint32 UKGMaterialManager::KAPI_MaterialManager_StartDissolveMaterialEffectByMaterialParamID(
	KGActorID ActorID, int32 MaterialParamID, bool bAutoRevertMaterialEffect, float Duration, uint32 Priority)
{
	return StartDissolveMaterialEffectByMaterialParamID(ActorID, MaterialParamID, bAutoRevertMaterialEffect, Duration, Priority);
}

uint32 UKGMaterialManager::StartDissolveMaterialEffectByMaterialParamID(
	KGActorID ActorID, int32 MaterialParamID, bool bAutoRevertMaterialEffect, float Duration, uint32 Priority)
{
	AActor* Actor = KGUtils::GetActorByID(ActorID);
	if (!Actor)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::StartDissolveMaterialEffect, invalid actor"));
		return 0;
	}

	FKGChangeMaterialParamRequest DissolveMaterialParamRequest;
	DissolveMaterialParamRequest.OwnerActor = Actor;
	DissolveMaterialParamRequest.EffectType = EKGMaterialEffectType::Dissolve;
	DissolveMaterialParamRequest.SearchMeshType = EKGSearchMeshType::SearchAllMesh;
	DissolveMaterialParamRequest.Priority = Priority;
	DissolveMaterialParamRequest.bActivateImmediately = true;
	if (bAutoRevertMaterialEffect)
	{
		DissolveMaterialParamRequest.TotalLifeTimeMs = Duration * 1000.0f;
	}
	
	ProcessMaterialParams(MaterialParamID, true, DissolveMaterialParamRequest);
	
	return ChangeMaterialParam(DissolveMaterialParamRequest);
}

void UKGMaterialManager::ProcessMaterialParams(int32 MaterialParamID, bool bActivateImmediately, FKGChangeMaterialParamRequest& InOutRequest)
{
	if (!UpdateAndCacheManagers())
	{
		return;
	}
	check(DataCacheManager.IsValid());
	
	auto* DissolveParamData = DataCacheManager->GetMaterialParamsData(MaterialParamID);
	if (!DissolveParamData)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::StartDissolveMaterialEffect, cannot find dissolve param data %d"), MaterialParamID);
		return;
	}
	
	InOutRequest.ScalarParams = DissolveParamData->ScalarParams;
	InOutRequest.VectorParams = DissolveParamData->VectorParams;
	InOutRequest.TextureParams = DissolveParamData->TextureParams;
	
	for (const auto& Kvp : DissolveParamData->LinearSampleScalarParams)
	{
		FKGLinearSampleParams<float> Params;
		Params.StartVal = Kvp.Value.StartVal;
		Params.EndVal = Kvp.Value.EndVal;
		Params.Duration = Kvp.Value.Duration;
		Params.bActivateImmediately = bActivateImmediately;
		InOutRequest.ScalarLinearSampleParams.Add(Kvp.Key, Params);
	}

	for (const auto& Kvp : DissolveParamData->LinearSampleVectorParams)
	{
		FKGLinearSampleParams<FLinearColor> Params;
		Params.StartVal = Kvp.Value.StartVal;
		Params.EndVal = Kvp.Value.EndVal;
		Params.Duration = Kvp.Value.Duration;
		Params.bActivateImmediately = bActivateImmediately;
		InOutRequest.VectorLinearSampleParams.Add(Kvp.Key, Params);
	}

	for (const auto& Kvp : DissolveParamData->CurveParams)
	{
		FKGCurveParams Params;
		Params.CurvePath = Kvp.Value.CurvePath;
		Params.bNeedRemap = Kvp.Value.bNeedRemap;
		Params.RemapTime = Kvp.Value.RemapTime;
		Params.bActivateImmediately = bActivateImmediately;
		InOutRequest.CurveParams.Add(Kvp.Key, Params);
	}
}

void UKGMaterialManager::PlayExtraWeaponDissolveEffect(FKGDissolveEffectData* DissolveEffectData, AActor* WeaponActor, bool bDissolveIn)
{
	if (!DissolveEffectData)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::PlayExtraWeaponDissolveEffect, invalid dissolve effect"));
		return;
	}

	if (!IsValid(WeaponActor))
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::PlayExtraWeaponDissolveEffect, invalid weapon actor"));
		return;
	}
	
	IC7ActorInterface* C7ActorInterface = Cast<IC7ActorInterface>(WeaponActor);
	if (!C7ActorInterface)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::PlayExtraWeaponDissolveEffect, invalid weapon actor"));
		return;
	}

	FKGChangeMaterialParamRequest WeaponEdgeEffect;
	WeaponEdgeEffect.OwnerActor = WeaponActor;
	WeaponEdgeEffect.EffectType = EKGMaterialEffectType::Edge;
	WeaponEdgeEffect.Priority = static_cast<uint32>(EKGMaterialPriority::WeaponDissolve);
	WeaponEdgeEffect.SearchMaterialType = EKGSearchMaterialType::SearchRuntimeSeparateOverlayMaterial;
	WeaponEdgeEffect.TotalLifeTimeMs = DissolveEffectData->Duration * 1000.0f;
	WeaponEdgeEffect.bActivateImmediately = true;
	if (bDissolveIn)
	{
		ProcessMaterialParams(WeaponDissolveInEdgeEffectID, false, WeaponEdgeEffect);
	}
	else
	{
		ProcessMaterialParams(WeaponDissolveOutEdgeEffectID, false, WeaponEdgeEffect);
	}

	ChangeMaterialParam(WeaponEdgeEffect);

	UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(this);
	if (!EffectManager)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::PlayExtraWeaponDissolveEffect, cannot find effect manager"));
		return;
	}
	
	KGActorID ParentActorID = C7ActorInterface->GetLoigcParent();
	if (ParentActorID == KG_INVALID_ACTOR_ID)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::PlayExtraWeaponDissolveEffect, invalid weapon owner actor id"));
		return;
	}

	auto* WeaponOwnerActor = KGUtils::GetActorByID(ParentActorID);
	if (!WeaponOwnerActor)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::PlayExtraWeaponDissolveEffect, cannot find weapon owner actor"));
		return;
	}

	IC7ActorInterface* WeaponOwnerC7ActorInterface = Cast<IC7ActorInterface>(WeaponOwnerActor);
	if (!WeaponOwnerC7ActorInterface)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::PlayExtraWeaponDissolveEffect, invalid weapon owner, not IC7ActorInterface"));
		return;
	}
	
	EffectManager->CreateWeaponDissolveNiagaraEffect(
		WeaponActor, KGUtils::GetIDByObject(WeaponOwnerActor), WeaponOwnerC7ActorInterface->GetEntityUID(), DissolveEffectData->WeaponDissolveSKEffectPath,
		DissolveEffectData->WeaponDissolveSMEffectPath, DissolveEffectData->Duration, bDissolveIn, DissolveEffectData->WeaponDissolveEffectPlayRate);
}

#pragma endregion Dissolve

#pragma region OLM

void UKGMaterialManager::KAPI_MaterialManager_EnableActorOLM(KGObjectID ActorID)
{
	EnableActorOLM(KGUtils::GetActorByID(ActorID));
}

void UKGMaterialManager::EnableActorOLM(TWeakObjectPtr<AActor> InActor)
{
	if (!InActor.IsValid())
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::EnableActorOLM, invalid actor"));
		return;
	}

	if (ActorOLMReqIDs.Contains(InActor))
	{
		return;
	}

	FKGChangeMaterialParamRequest CameraDitherRequest;
	CameraDitherRequest.SearchMaterialType = EKGSearchMaterialType::SearchRuntimeSeparateOverlayMaterial;
	CameraDitherRequest.OwnerActor = InActor;
	const auto ReqID = ChangeMaterialParam(CameraDitherRequest);
	ActorOLMReqIDs.Add(InActor, ReqID);
}

void UKGMaterialManager::KAPI_MaterialManager_DisableActorOLM(KGObjectID ActorID)
{
	DisableActorOLM(KGUtils::GetActorByID(ActorID));
}

void UKGMaterialManager::DisableActorOLM(TWeakObjectPtr<AActor> InActor)
{
	if (!InActor.IsValid())
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UKGMaterialManager::DisableActorOLM, invalid actor"));
		return;
	}

	auto* ReqIDPtr = ActorOLMReqIDs.Find(InActor);
	if (ReqIDPtr == nullptr)
	{
		return;
	}

	RevertMaterialParam(*ReqIDPtr);
	ActorOLMReqIDs.Remove(InActor);
}

#pragma endregion OLM

#pragma region EffectPropergate

void UKGMaterialManager::SyncMaterials(AActor* SourceActor, AActor* TargetActor)
{
	if (!IsValid(SourceActor) || !IsValid(TargetActor))
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::SyncMaterials, invalid source or target entity"));
		return;
	}

	UKGMaterialManager* MaterialManager = GetInstance(SourceActor);
	if (!MaterialManager)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::SyncMaterials, invalid material manager"));
		return;
	}

	TSet<uint32> SourceReqIDs;
	MaterialManager->GetChangeMaterialReqIDs(SourceActor, SourceReqIDs);

	TSet<uint32> InheritedSourceReqIDs;
	TMap<uint32, uint32> InheritedReqSourceIDToReqIDs;
	MaterialManager->GetInheritedChangeMaterialReqSourceIDs(TargetActor, InheritedSourceReqIDs, InheritedReqSourceIDToReqIDs);
	
	const auto& ReqIDsNeedToAdd = SourceReqIDs.Difference(InheritedSourceReqIDs);
	const auto& ReqIDsNeedToRemove = InheritedSourceReqIDs.Difference(SourceReqIDs);
	
	for (const auto SourceID : ReqIDsNeedToRemove)
	{
		check(InheritedReqSourceIDToReqIDs.Contains(SourceID));
		const auto ReqID = InheritedReqSourceIDToReqIDs[SourceID];
		UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::SyncMaterials, remove change material req id %d from %s to %s"), 
			ReqID, *SourceActor->GetName(), *TargetActor->GetName());
		MaterialManager->RevertMaterial(ReqID);	
	}
	
	for (const auto ReqID : ReqIDsNeedToAdd)
	{
		auto* ContextPtr = MaterialManager->GetChangeMaterialContextPtr(ReqID);
		if (!ContextPtr)
		{
			continue;
		}

		UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::SyncMaterials, add change material req id %d to from %s to %s"), 
			ReqID, *SourceActor->GetName(), *TargetActor->GetName());
		MaterialManager->ChangeAttachActorMaterial(*ContextPtr, TargetActor);
	}
}

bool UKGMaterialManager::GetChangeMaterialReqIDs(TWeakObjectPtr<AActor> Actor, TSet<uint32>& OutIDs)
{
	if (ActorChangeMaterialReqIds.Contains(Actor.KGGetObjectID()))
	{
		OutIDs = ActorChangeMaterialReqIds[Actor.KGGetObjectID()];
		return true;
	}
	return false;
}

bool UKGMaterialManager::GetInheritedChangeMaterialReqSourceIDs(TWeakObjectPtr<AActor> Actor, TSet<uint32>& OutSourceIDs, TMap<uint32, uint32>& OutSourceIDToReqIDs)
{
	if (ActorChangeMaterialReqIds.Contains(Actor.KGGetObjectID()))
	{
		for (const auto& ReqID : ActorChangeMaterialReqIds[Actor.KGGetObjectID()])
		{
			auto* ContextPtr = ChangeMaterialContexts.Find(ReqID);
			if (!ContextPtr)
			{
				UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::GetInheritedChangeMaterialReqSourceIDs, invalid change material req id %d"), ReqID);
				continue;
			}

			if (ContextPtr->ChangeMaterialRequest.SourceReqID != 0)
			{
				OutSourceIDs.Add(ContextPtr->ChangeMaterialRequest.SourceReqID);
				OutSourceIDToReqIDs.Add(ContextPtr->ChangeMaterialRequest.SourceReqID, ReqID);
			} 
		}
		return true;
	}
	
	return false;
}

void UKGMaterialManager::SyncMaterialParams(AActor* SourceActor, AActor* TargetActor)
{
	if (!IsValid(SourceActor) || !IsValid(TargetActor))
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::SyncMaterialParams, invalid source or target entity"));
		return;
	}

	UKGMaterialManager* MaterialManager = GetInstance(SourceActor);
	if (!MaterialManager)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::SyncMaterialParams, invalid material manager"));
		return;
	}

	TSet<uint32> SourceReqIDs;
	MaterialManager->GetChangeMaterialParamsReqIDs(SourceActor, SourceReqIDs);

	TSet<uint32> InheritedReqIDs;
	TMap<uint32, uint32> InheritedReqSourceIDToReqIDs;
	MaterialManager->GetInheritedChangeMaterialParamReqSourceIDs(TargetActor, InheritedReqIDs, InheritedReqSourceIDToReqIDs);
	
	const auto& ReqIDsNeedToAdd = SourceReqIDs.Difference(InheritedReqIDs);
	const auto& ReqIDsNeedToRemove = InheritedReqIDs.Difference(SourceReqIDs);

	// 对于观众来说武器挂接关系会在角色到小龙间转换, 为了确保虚化表现正常, 这里需要先删除再添加
	for (const auto SourceID : ReqIDsNeedToRemove)
	{
		check(InheritedReqSourceIDToReqIDs.Contains(SourceID));
		const auto ReqID = InheritedReqSourceIDToReqIDs[SourceID];
		UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::SyncMaterialParams, remove change material param req id %d from %s to %s"), 
			ReqID, *SourceActor->GetName(), *TargetActor->GetName());
		MaterialManager->RevertMaterialParam(ReqID);
	}
	
	for (const auto ReqID : ReqIDsNeedToAdd)
	{
		auto* ContextPtr = MaterialManager->GetChangeMaterialParamContextPtr(ReqID);
		if (!ContextPtr)
		{
			continue;
		}

		UE_LOG(LogKGMaterial, Log, TEXT("UKGMaterialManager::SyncMaterialParams, add change material param req id %d from %s to %s"), 
			ReqID, *SourceActor->GetName(), *TargetActor->GetName());
		MaterialManager->ChangeAttachActorMaterialParam(*ContextPtr, TargetActor);
	}
}

bool UKGMaterialManager::GetChangeMaterialParamsReqIDs(TWeakObjectPtr<AActor> Actor, TSet<uint32>& OutIDs)
{
	if (ActorChangeMaterialParamReqIds.Contains(Actor.KGGetObjectID()))
	{
		OutIDs = ActorChangeMaterialParamReqIds[Actor.KGGetObjectID()];
		return true;
	}
	return false;
}

bool UKGMaterialManager::GetInheritedChangeMaterialParamReqSourceIDs(TWeakObjectPtr<AActor> Actor, TSet<uint32>& OutSourceIDs, TMap<uint32, uint32>& OutSourceIDToReqIDs)
{
	if (ActorChangeMaterialParamReqIds.Contains(Actor.KGGetObjectID()))
	{
		for (const auto& ReqID : ActorChangeMaterialParamReqIds[Actor.KGGetObjectID()])
		{
			auto* ContextPtr = ChangeMaterialParamContexts.Find(ReqID);
			if (!ContextPtr)
			{
				UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::GetInheritedChangeMaterialParamReqSourceIDs, invalid change material req id %d"), ReqID);
				continue;
			}

			if (ContextPtr->ChangeMaterialParamRequest.SourceReqID != 0)
			{
				OutSourceIDs.Add(ContextPtr->ChangeMaterialParamRequest.SourceReqID);
				OutSourceIDToReqIDs.Add(ContextPtr->ChangeMaterialParamRequest.SourceReqID, ReqID);
			} 
		}
		return true;
	}
	
	return false;
}

void UKGMaterialManager::GetLogicChildActorIDsByAttachSemantics(IC7ActorInterface* Actor, int32 AttachSemantics, TArray<int64>& OutChildActorIDs)
{
	UpdateAndCacheManagers();
	
	if (!ActorManager.IsValid())
	{
		UE_LOG(LogKGMaterial, Error, TEXT("ABaseCharacter::GetLogicChildActorIDsByAttachSemantics, invalid actor manager"));
		return;
	}

	if (!Actor)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("ABaseCharacter::GetLogicChildActorIDsByAttachSemantics, invalid actor"));
		return;
	}

	OutChildActorIDs.Reset();

	auto* ChildMapPtr = Actor->GetLogicChildMaskMap();
	if (!ChildMapPtr)
	{
		return;
	}
	
	for (const auto& Kvp : *ChildMapPtr)
	{
		const auto AttachActorID = Kvp.Key;
		ICppEntityInterface* AttachEntity = ActorManager->GetLuaEntityByActorID(AttachActorID);
		if (!AttachEntity)
		{
			UE_LOG(LogTemp, Error, TEXT("ABaseCharacter::GetLogicChildActorIDsByAttachSemantics, invalid attach entity, %lld"), AttachActorID);
			continue;
		}

		if (AttachEntity->GetAttachSemantics() == AttachSemantics)
		{
			OutChildActorIDs.Add(AttachActorID);
		}
	}
}

uint32 UKGMaterialManager::ChangeAttachActorMaterial(FKGChangeMaterialContext& InOutContext, AActor* AttachActor)
{
	if (!AttachActor)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::ChangeAttachActorMaterial, invalid attach actor"));
		return 0;
	}
	
	const auto& Request = InOutContext.ChangeMaterialRequest;
	FKGChangeMaterialRequest AttachActorRequest = Request;
	// 仅支持传递一层
	AttachActorRequest.OwnerActor = AttachActor;
	AttachActorRequest.RelatedChangeMaterialParamReqID = 0;
	AttachActorRequest.SourceReqID = InOutContext.ReqId;
	AttachActorRequest.CustomChangeMaterialReqId.Reset();
	// child actor材质效果生命周期按照parent来处理
	AttachActorRequest.TotalLifeTimeMs = -1;
	return ChangeMaterial(AttachActorRequest);
}

uint32 UKGMaterialManager::ChangeAttachActorMaterialParam(FKGChangeMaterialParamContext& InOutContext, AActor* AttachActor)
{
	if (!AttachActor)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UKGMaterialManager::ChangeAttachActorMaterialParam, invalid attach actor"));
		return 0;
	}
	
	const auto& Request = InOutContext.ChangeMaterialParamRequest;
	FKGChangeMaterialParamRequest AttachActorRequest = Request;
	// 仅支持传递一层
	AttachActorRequest.OwnerActor = AttachActor;
	AttachActorRequest.SourceReqID = InOutContext.ReqId;
	AttachActorRequest.RelatedChangeMaterialReqID = 0;
	AttachActorRequest.CustomChangeMaterialParamReqId.Reset();
	// child actor材质效果生命周期按照parent来处理
	AttachActorRequest.TotalLifeTimeMs = -1;
	if (Request.ShouldUseOLM())
	{
		UE_LOG(LogKGMaterial, Log, 
			TEXT("UKGMaterialManager::ChangeAttachActorMaterialParam, attach actor %s use OLM for camera dither, ParentUseWorldPivotPosition: %d"),
			*AttachActor->GetName(), Request.bUseWorldPivotPositionForCameraDither);
		AttachActorRequest.bUseWorldPivotPositionForCameraDither = true;
		
		if (!Request.bUseWorldPivotPositionForCameraDither)
		{
			FKGActorLocationMaterialParams ActorLocationMaterialParams;
			ActorLocationMaterialParams.Actor = Request.OwnerActor;
			ActorLocationMaterialParams.LocationType = EKGMaterialParamActorLocationType::UseActorMainMesh;
			float DistanceScale;
			if (Request.ScalarParams.Contains(CameraDither_DistanceScaleParamName))
			{
				DistanceScale = Request.ScalarParams[CameraDither_DistanceScaleParamName];
			}
			else
			{
				DistanceScale = CameraDither_DefaultDistanceScale;
			}
			ActorLocationMaterialParams.RelativeLocation = FVector(0.0f, 0.0f, DistanceScale);
			AttachActorRequest.ActorLocationParams.Add(CameraDither_WorldPivotPointParamName, ActorLocationMaterialParams);
		}
	}
	return ChangeMaterialParam(AttachActorRequest);
}

void UKGMaterialManager::RefreshAttachActorMaterial(AActor* OwnerActor, uint32 SourceReqID)
{
	// 仅传递一次
	if (SourceReqID != 0)
	{
		return;
	}
	
	if (IC7ActorInterface* C7Actor = Cast<IC7ActorInterface>(OwnerActor))
	{
		UpdateAndCacheManagers();
		if (ActorManager.IsValid())
		{
			if (auto* Entity = ActorManager->GetLuaEntity(C7Actor->GetEntityUID()))
			{
				Entity->SyncMaterialToAttachEntities();
			}
		}
	}
}

void UKGMaterialManager::RefreshAttachActorMaterialParams(AActor* OwnerActor, uint32 SourceReqID)
{
	if (SourceReqID != 0)
	{
		return;
	}
	
	if (IC7ActorInterface* C7Actor = Cast<IC7ActorInterface>(OwnerActor))
	{
		UpdateAndCacheManagers();
		if (ActorManager.IsValid())
		{
			if (auto* Entity = ActorManager->GetLuaEntity(C7Actor->GetEntityUID()))
			{
				Entity->SyncMaterialParamToAttachEntities();
			}	
		}
	}
}

#pragma endregion EffectPropergate

#pragma region TimeDilation

void UKGMaterialManager::SetActorEnableTimeDilation(KGActorID ActorID, bool bEnableTimeDilation)
{
	const bool bOldEnabled = ActorsWithTimeDilation.Contains(ActorID);
	if (bOldEnabled == bEnableTimeDilation)
	{
		return;
	}
	
	if (bEnableTimeDilation)
	{
		ActorsWithTimeDilation.Add(ActorID);
	}
	else
	{
		ActorsWithTimeDilation.Remove(ActorID);
	}
	
	SetTimerModeByActorID(ActorID, bEnableTimeDilation);
}

void UKGMaterialManager::SetTimerModeByActorID(KGActorID ActorID, bool bEnableTimeDilation)
{
	if (auto* ChangeMaterialReqIDsPtr = ActorChangeMaterialReqIds.Find(ActorID))
	{
		for (const auto& ReqID : *ChangeMaterialReqIDsPtr)
		{
			auto* ContextPtr = ChangeMaterialContexts.Find(ReqID);
			if (!ContextPtr)
			{
				continue;
			}

			ContextPtr->LifeTimeHandler.ChangeTimerMode(bEnableTimeDilation);
		}
	}
	
	if (auto* ReqIDsPtr = ActorChangeMaterialParamReqIds.Find(ActorID))
	{
		for (const auto& ReqID : *ReqIDsPtr)
		{
			auto* ContextPtr = ChangeMaterialParamContexts.Find(ReqID);
			if (!ContextPtr)
			{
				continue;
			}

			ContextPtr->LifeTimeHandler.ChangeTimerMode(bEnableTimeDilation);
		}
	}
}

void UKGMaterialManager::UpdateDilationTimers(float DeltaTime)
{
	if (ActorsWithTimeDilation.IsEmpty())
	{
		// 绝大多数时候走的是这里
		return;
	}
	
	for (auto ActorID : ActorsWithTimeDilation)
	{
		if (auto* ChangeMaterialReqIDsPtr = ActorChangeMaterialReqIds.Find(ActorID))
		{
			auto ReqIDs(*ChangeMaterialReqIDsPtr);
			for (const auto& ReqID : ReqIDs)
			{
				auto* ContextPtr = ChangeMaterialContexts.Find(ReqID);
				if (!ContextPtr)
				{
					continue;
				}

				ContextPtr->LifeTimeHandler.UpdateTickTimer(DeltaTime);
			}
		}
	
		if (auto* ReqIDsPtr = ActorChangeMaterialParamReqIds.Find(ActorID))
		{
			auto ReqIDs(*ReqIDsPtr);
			for (const auto& ReqID : ReqIDs)
			{
				auto* ContextPtr = ChangeMaterialParamContexts.Find(ReqID);
				if (!ContextPtr)
				{
					continue;
				}

				ContextPtr->LifeTimeHandler.UpdateTickTimer(DeltaTime);
			}
		}
	}
}

#pragma endregion TimeDilation
