#include "3C/Material/KGMaterialCommon.h"

#include "3C/Character/BaseCharacter.h"
#include "Components/CapsuleComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/StaticMesh.h"
#include "3C/Material/KGMaterialManager.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "3C/Util/KGUtils.h"

DEFINE_LOG_CATEGORY(LogKGMaterial);

bool GEnableKGMaterialParamCheck = false;
static FAutoConsoleVariableRef CVarEnableKGMaterialParamCheck(
	TEXT("gp.EnableKGMaterialParamCheck"),
	GEnableKGMaterialParamCheck,
	TEXT("EnableKGMaterialParamCheck."),
	ECVF_Default
);

UMaterialInterface* KGMaterialUtils::GetDefaultMaterialInstanceByMaterialCacheKey(UMeshComponent* MeshComponent, KGMaterialCacheKey MaterialCacheKey)
{
	check(MeshComponent);
	int32 MaterialIndex;
	bool bOutOverlayMaterial;
	bool bOutSeparateOverlayMaterial;
	bool bOutRuntimeSeparateOverlayMaterial;
	GetMaterialIndexInfoByCacheKey(MaterialCacheKey, MaterialIndex, bOutOverlayMaterial, bOutSeparateOverlayMaterial, bOutRuntimeSeparateOverlayMaterial);

	if (UStaticMeshComponent* StaticMeshComponent = Cast<UStaticMeshComponent>(MeshComponent))
	{
		if (UStaticMesh* StaticMesh = StaticMeshComponent->GetStaticMesh())
		{
			if (bOutSeparateOverlayMaterial)
			{
				return StaticMesh->GetSeperateOverlayMaterial(MaterialIndex);
			}

			if (bOutOverlayMaterial || bOutRuntimeSeparateOverlayMaterial)
			{
				return nullptr;
			}
			
			return StaticMesh->GetMaterial(MaterialIndex);
		}
		return nullptr;
	}

	if (USkinnedMeshComponent* SkinnedMeshComponent = Cast<USkinnedMeshComponent>(MeshComponent))
	{
		if (USkinnedAsset* SkinnedAsset = SkinnedMeshComponent->GetSkinnedAsset())
		{
			if (bOutOverlayMaterial)
			{
				return SkinnedAsset->GetOverlayMaterial();
			}
		
			if (bOutSeparateOverlayMaterial)
			{
				const auto& Materials = SkinnedAsset->GetSeperateOverlayMaterials();
				return Materials.IsValidIndex(MaterialIndex) ? Materials[MaterialIndex].MaterialInterface : nullptr;
			}

			if (bOutRuntimeSeparateOverlayMaterial)
			{
				return nullptr;
			}

			const auto& Materials = SkinnedAsset->GetMaterials();
			return Materials.IsValidIndex(MaterialIndex) ? Materials[MaterialIndex].MaterialInterface : nullptr;
		}
		return nullptr;
	}
	
	return GetMaterialInstanceByMaterialCacheKey(MeshComponent, MaterialCacheKey);
}

UMaterialInstanceDynamic* KGMaterialUtils::CreateDynamicMaterialInstance(UMaterialInterface* ParentMaterialInterface)
{
	SCOPED_NAMED_EVENT(KGMaterialUtils_CreateDynamicMaterialInstance, FColor::Red);
	check(ParentMaterialInterface);
	
#if KG_ENABLE_MATERIAL_MANAGER_DEBUG
	FName MaterialName = MakeUniqueObjectName(nullptr, UMaterialInstanceDynamic::StaticClass(), FName(FString("KGMID_") + ParentMaterialInterface->GetName()));
	return UMaterialInstanceDynamic::Create(ParentMaterialInterface, nullptr, MaterialName);
#else
	return UMaterialInstanceDynamic::Create(ParentMaterialInterface, nullptr);
#endif
}

void KGMaterialUtils::ChangeMaterialParent(UMeshComponent* MeshComponent, UMaterialInterface* MaterialInterface, KGMaterialCacheKey MaterialCacheKey)
{
	SCOPED_NAMED_EVENT(KGMaterialUtils_ChangeMaterialParent, FColor::Red);
	// 原始的change material parent做法是, 材质管理器总是持有一个dynamic material instance, 每次需要变化材质的时候, 直接将dynamic material instance的parent设置为新的材质
	// 这样可以保留所有的材质参数, 不会创建新的动态材质实例, 减少GC的开销
	// 跟引擎确认了下, 这种做法存在潜在风险
	// 1) 可能材质实例与parent的一些state不一致产生crash
	// 2) 可能跑不了pso预热
	// 目前还是改为每次修改parent都创建新的dynamic material instance的做法, 可能导致GC开销增大, 后续关注并优化
	check(MeshComponent);

	if (!MaterialInterface)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("MaterialCacheKeyUtils::ChangeMaterialParent, invalid material interface, %s, %lld"),
			*GetNameSafe(MeshComponent), MaterialCacheKey);
		return;
	}

	if (MaterialInterface->IsA(UMaterialInstanceDynamic::StaticClass()))
	{
		UE_LOG(LogKGMaterial, Error, TEXT("MaterialCacheKeyUtils::ChangeMaterialParent, material parent cannot be dynamic material instance, %s, %lld, %s"),
			*GetNameSafe(MeshComponent), MaterialCacheKey, *GetMaterialInfoDebugUsage(MaterialInterface));
		return;
	}

	UMaterialInstanceDynamic* NewMaterialInstanceDynamic = CreateDynamicMaterialInstance(MaterialInterface);
	UMaterialInterface* MaterialInstance = GetMaterialInstanceByMaterialCacheKey(MeshComponent, MaterialCacheKey);
	if (UMaterialInstanceDynamic* MaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(MaterialInstance))
	{
		SCOPED_NAMED_EVENT(KGMaterialUtils_ChangeMaterialParent_CopyParameterOverrides, FColor::Red);
		NewMaterialInstanceDynamic->CopyParameterOverrides(MaterialInstanceDynamic);
	}

	SetMaterialInstanceByMaterialCacheKey(MeshComponent, NewMaterialInstanceDynamic, MaterialCacheKey);
}

uint32 KGMaterialUtils::GenerateIncId(uint32& InOutIncID)
{
	InOutIncID++;
	if (InOutIncID >= 0x7fffffff)
	{
		InOutIncID = 1;
	}

	return InOutIncID;
}

bool KGMaterialUtils::ComponentHasAnyTag(UActorComponent* InComponent, const TArray<FName>& InTag)
{
	if (!InComponent)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("MaterialCacheKeyUtils::ComponentHasAnyTag, invalid component"));
		return false;
	}

	if (InTag.Num() == 0)
	{
		return false;
	}

	for (const auto& Tag : InTag)
	{
		if (InComponent->ComponentHasTag(Tag))
		{
			return true;
		}
	}

	return false;
}

FString KGMaterialUtils::GetMeshAssetNameDebugUsage(UMeshComponent* MeshComponent)
{
	if (UStaticMeshComponent* StaticMeshComponent = Cast<UStaticMeshComponent>(MeshComponent))
	{
		return GetNameSafe(StaticMeshComponent->GetStaticMesh().Get());
	}

	if (USkinnedMeshComponent* SkeletalMeshComponent = Cast<USkinnedMeshComponent>(MeshComponent))
	{
		return GetNameSafe(SkeletalMeshComponent->GetSkinnedAsset());
	}

	return TEXT("invalid");
}

FString KGMaterialUtils::GetMaterialInfoDebugUsage(UMaterialInterface* MaterialInterface)
{
	if (UMaterialInstanceDynamic* MaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(MaterialInterface))
	{
		return FString::Printf(TEXT("[dynamic] %s -> %s"), *GetNameSafe(MaterialInterface), *GetNameSafe(MaterialInstanceDynamic->Parent));
	}
	
	return FString::Printf(TEXT("[instance] %s"), *GetNameSafe(MaterialInterface));
}

FString KGMaterialUtils::GetMaterialParamInfoDebugUsage(
	UMaterialInstanceDynamic* MaterialInstanceDynamic, const TArray<FName>& ScalarParamNames, const TArray<FName>& VectorParamNames, const TArray<FName>& TextureParamNames)
{
	if (!MaterialInstanceDynamic)
	{
		return TEXT("[empty]");
	}

	FStringBuilderBase ParamInfo;
	
	for (const auto& ParamName : ScalarParamNames)
	{
		const auto ParamVal = MaterialInstanceDynamic->K2_GetScalarParameterValue(ParamName);
		ParamInfo.Append(FString::Printf(TEXT("%s: %.2f, "), *ParamName.ToString(), ParamVal));
	}
				
	for (const auto& ParamName : VectorParamNames)
	{
		const auto& ParamVal = MaterialInstanceDynamic->K2_GetVectorParameterValue(ParamName);
		ParamInfo.Append(FString::Printf(TEXT("%s: (%.2f,%.2f,%.2f,%.2f), "), *ParamName.ToString(), ParamVal.R, ParamVal.G, ParamVal.B, ParamVal.A));
	}
				
	for (const auto& ParamName : TextureParamNames)
	{
		const auto ParamVal = MaterialInstanceDynamic->K2_GetTextureParameterValue(ParamName);
		ParamInfo.Append(FString::Printf(TEXT("%s: %s, "), *ParamName.ToString(), ParamVal ? *ParamVal->GetPathName() : TEXT("null")));
	}

	return ParamInfo.ToString();
}

void KGMaterialUtils::SetDynamicMaterialInstanceCharacterHeightInfo(
	UMeshComponent* MeshComponent, UMaterialInstanceDynamic* MaterialInstanceDynamic, const FName& CharacterHeightParamName, bool bBatchSet)
{
	// 仅处理角色的character height
	if (!MeshComponent)
	{
		return;
	}

	if (!MaterialInstanceDynamic)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("KGMaterialUtils::SetDynamicMaterialInstanceCharacterHeightInfo, invalid mesh component or material instance dynamic"));
		return;
	}
	
	if (ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(MeshComponent->GetOwner()))
	{
		if (UCapsuleComponent* Capsule = BaseCharacter->GetComponentByClass<UCapsuleComponent>())
		{
			const auto CharacterHeight = Capsule->GetScaledCapsuleHalfHeight() * 2.0f;
			if (bBatchSet)
			{
				MaterialInstanceDynamic->SetGameScalarParameterValue(CharacterHeightParamName, CharacterHeight);
			}
			else
			{
				MaterialInstanceDynamic->SetScalarParameterValue(CharacterHeightParamName, CharacterHeight);
			}
		}
	}
}

bool KGMaterialUtils::GetDynamicMaterialInstancesByMaterialInstanceIDs(const TArray<KGObjectID>& ObjectIDs, TSet<TWeakObjectPtr<UMaterialInstanceDynamic>>& OutMaterialInstances)
{
	OutMaterialInstances.Reserve(ObjectIDs.Num());
	for (auto ObjectID : ObjectIDs)
	{
		// 材质插槽确实可能存在材质为nullptr的情况, 此时不算错误
		if (ObjectID == 0)
		{
			continue;
		}
		
		UMaterialInstanceDynamic* MaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(KGUtils::GetObjectByID(ObjectID));
		if (!MaterialInstanceDynamic)
		{
			UE_LOG(LogKGMaterial, Error, TEXT("GetDynamicMaterialInstancesByMaterialInstanceIDs, invalid dynamic material instance id"));
			continue;
		}

		OutMaterialInstances.Add(MaterialInstanceDynamic);
	}

	return OutMaterialInstances.Num() > 0;
}

FString FKGChangeMaterialContext::ToString() const
{
	return FString::Printf(TEXT("ChangeMaterialReqId: %d, MaterialPath: %s"), ReqId, *ChangeMaterialRequest.MaterialPath);
}

ICppEntityInterface* FKGChangeMaterialParamContext::GetOwnerEntity(UKGUEActorManager* ActorManager)
{
	if (OwnerEntityInterface.IsValid())
	{
		return OwnerEntityInterface.Get();
	}
	
	if (!ChangeMaterialParamRequest.OwnerActor.IsValid() || !ActorManager)
	{
		return nullptr;
	}
	
	OwnerEntityInterface = ActorManager->GetLuaEntityByActor(ChangeMaterialParamRequest.OwnerActor.Get());
	return OwnerEntityInterface.Get();
}

FString FKGChangeMaterialParamContext::ToString() const
{
	return FString::Printf(TEXT("ReqId: %d, OwnerActor: %s, EffectType: %d, RuntimeSeparateOverlayMaterial: %d"), 
		ReqId, *GetNameSafe(ChangeMaterialParamRequest.OwnerActor.Get()), ChangeMaterialParamRequest.EffectType,
		ChangeMaterialParamRequest.SearchMaterialType == EKGSearchMaterialType::SearchRuntimeSeparateOverlayMaterial);
}
