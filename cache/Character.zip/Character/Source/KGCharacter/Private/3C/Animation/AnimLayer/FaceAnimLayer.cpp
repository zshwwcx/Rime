#include "Templates/Casts.h"
#include "UObject/Field.h"
#include "3C/Animation/AnimLayer/FaceAnimLayer.h"

DEFINE_LOG_CATEGORY_STATIC(UFaceAnimLayerLog, Log, All);

UFaceAnimLayer::UFaceAnimLayer(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer) {


}

void UFaceAnimLayer::NativeInitializeAnimation() {
	Super::NativeInitializeAnimation();
	
	
	bool isFound = false;
	for (TFieldIterator<FStructProperty> It(GetClass(), EFieldIteratorFlags::IncludeSuper); It; ++It) {
		if ((*It)->GetName() != FaceControlStructName) {
			continue;
		}


		isFound = true;
		FaceContrlStructBaseAddr = (*It)->ContainerPtrToValuePtr<uint8>(this);

		FStructProperty * temp = (*It);
		FString F_Name; FString S_Name;
		for (TFieldIterator<FProperty> FloatIt((*It)->Struct); FloatIt; ++FloatIt) {

			if (!(CastField<FFloatProperty>(*FloatIt) || CastField<FDoubleProperty>(*FloatIt))) {
				continue;
			}
			// 兼容double和float, 但目前接口只是开了float的传入
			uint8* realAddr = ((*FloatIt))->ContainerPtrToValuePtr<uint8>((*It));

			FString PropName = (*FloatIt)->GetName();
			if (PropName.Split("_", &F_Name, &S_Name))
			{
				PropName = F_Name;
			}
			FaceFloatPropertys.Emplace(PropName, (*FloatIt));
			FaceFloatPropertyAddrs.Emplace(PropName, realAddr);
		
		}
	}

	if (!isFound) {
		UE_LOG(UFaceAnimLayerLog, Error, TEXT("UFaceAnimLayer::NativeInitializeAnimation Cannot Find Face Control Struct With Name:%s, Set it to FaceControlStructName In Face ABP "), *FaceControlStructName.ToString());
	}

}

void UFaceAnimLayer::NativeUninitializeAnimation() {
	
	FaceFloatPropertys.Empty();
	FaceContrlStructBaseAddr = nullptr;
	Super::NativeUninitializeAnimation();
}

void UFaceAnimLayer::NativeUpdateAnimation(float timeDelta) {
	if (HighPriorityPerformMode >= 0) {
		FacePerformMode = HighPriorityPerformMode;
	}
	else {
		FacePerformMode = DefaultPerformMode;
	}
}

void UFaceAnimLayer::SetAnimLayerAnimAsset(const TMap<FName, UAnimSequenceBase*>& InAnimMap)
{
	FaceAnimMap = InAnimMap;
}

bool UFaceAnimLayer::SetFloatProperty(FName PropName, float value) {
	
	if (!FaceContrlStructBaseAddr) {
		return false;
	}

	if (!FaceFloatPropertys.Contains(PropName)) {
		return false;
	}
	
	if (CastField<FDoubleProperty>(FaceFloatPropertys[PropName])) {
		double tempValue = value;
		FaceFloatPropertys[PropName]->SetValue_InContainer(FaceContrlStructBaseAddr, &tempValue);
	}
	else {
		FaceFloatPropertys[PropName]->SetValue_InContainer(FaceContrlStructBaseAddr, &value);
	}


	return true;
}

bool UFaceAnimLayer::SetFloatPropertys(const TMap<FName, float> & floatValues) {
	
	FaceChannelValueMap = floatValues;

	if (!FaceContrlStructBaseAddr) {
		return false;
	}

	for (const auto& item : floatValues) {
		if (!FaceFloatPropertys.Contains(item.Key)) {
			continue;
		}
		
		if (CastField<FDoubleProperty>(FaceFloatPropertys[item.Key])) {
			double tempValue = item.Value;
			FaceFloatPropertys[item.Key]->SetValue_InContainer(FaceContrlStructBaseAddr, &tempValue);
		}
		else {
			FaceFloatPropertys[item.Key]->SetValue_InContainer(FaceContrlStructBaseAddr, &item.Value);
		}
	}
	
	return true;
};