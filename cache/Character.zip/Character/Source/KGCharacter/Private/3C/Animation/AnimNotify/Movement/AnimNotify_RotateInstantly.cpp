// Copyright Epic Games, Inc. All Rights Reserved.

// #pragma once

#include "3C/Animation/AnimNotify/Movement/AnimNotify_RotateInstantly.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Movement/RoleMovementComponent.h"



UAnimNotify_RotateInstantly::UAnimNotify_RotateInstantly(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
#if WITH_EDITORONLY_DATA
	bShouldFireInEditor = false;
#endif // WITH_EDITORONLY_DATA
}

void UAnimNotify_RotateInstantly::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotify_RotateInstantly::Notify");
	
	if (ABaseCharacter* Character = Cast<ABaseCharacter>(MeshComp->GetOwner()))
	{
		if (URoleMovementComponent* RoleMoveComp = Cast<URoleMovementComponent>(Character->GetMovementComponent()))
		{

			URoleMovementComponent* MovementControlViewProxy = GetMovementAuthorityControlRMC(RoleMoveComp);
			
			// 脚本显式开启LocoControl，这个机制才允许生效
			if (MovementControlViewProxy->GetEnableLocoContol())
			{
				FVector CachedLocoInputVec = MovementControlViewProxy->GetRoleMP().GetMovementContext().GetCachedLocoInputVec();
				if (!CachedLocoInputVec.IsNearlyZero())
				{
					FRotator CurRotator = Character->GetActorRotation();
					CurRotator.Yaw = CachedLocoInputVec.Rotation().Yaw;
					MovementControlViewProxy->GetRoleMP().GetMovementContext().SetNeedRotateInstantly(CurRotator);
				}
				
			}
		}
	}
}

