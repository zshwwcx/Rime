// Copyright Epic Games, Inc. All Rights Reserved.

#include "3C/Animation/AnimNotify/AnimNotifyState_C7TimedNiagaraEffect.h"

#include "Misc/KGPlatformUtils.h"
#include "3C/Util/KGUtils.h"
#include "Animation/AnimSequence.h"


UAnimNotifyState_C7TimedNiagaraEffect::UAnimNotifyState_C7TimedNiagaraEffect(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	SocketName = NAME_None;

	bNeedAttach = true;
	bAbsoluteRotation = false;
	bAbsoluteScale = false;
	PlayRate = 1.0f;
	ReleaseMode = EC7AnimNotifyStateNiagaraReleaseMode::AutoReleaseOnFixedTime;
	TotalLifeSeconds = 0.0f;

	Transform = FTransform();
}

#if WITH_EDITOR
void UAnimNotifyState_C7TimedNiagaraEffect::ValidateAssociatedAssets()
{
	if (this->HasAnyFlags(RF_NeedPostLoad))
		return;
	UAnimSequenceBase* AnimSequence = Cast<UAnimSequenceBase>(GetOuter());
	if (!IsValid(AnimSequence))
		return;

	const FString NiagaraSystemPath = this->TemplatePath.GetAssetName();
	if (NiagaraSystemPath.IsEmpty())
	{
		FString Message = FString::Printf(
			TEXT("AnimNotifyState Config Error: NiagaraSystem is not set. \n AnimSequence: %s \n AnimNotifyState: %s."),
			*AnimSequence->GetPathName(),
			this->GetNotifyName().IsEmpty() ? *this->GetName() : *this->GetNotifyName()
		);
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(Message));
		return;
	}

	auto NiagaraSystem = this->TemplatePath.LoadSynchronous();
	if (NiagaraSystem == nullptr)
	{
		FString Message = FString::Printf(
			TEXT("AnimNotifyState Config Error: NiagaraSystem path is invalid. \n AnimSequence: %s \n AnimNotifyState: %s."),
			*AnimSequence->GetPathName(),
			this->GetNotifyName().IsEmpty() ? *this->GetName() : *this->GetNotifyName()
		);
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(Message));
		return;
	}
	
	for (auto NotifyEvent : AnimSequence->Notifies)
	{
		if (this != NotifyEvent.NotifyStateClass.Get())
			continue;
		
		if (this->ReleaseMode == EC7AnimNotifyStateNiagaraReleaseMode::AutoReleaseOnNiagaraFinished)
		{
			if (NiagaraSystem->bInfiniteSystem)
			{
				FString Message = FString::Printf(
					TEXT("AnimNotifyState Config Error: NiagaraSystem is loop infinity. \n AnimSequence: %s \n AnimNotifyState: %s."),
					*AnimSequence->GetPathName(),
					this->GetNotifyName().IsEmpty() ? *this->GetName() : *this->GetNotifyName()
				);
				FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(Message));
			}
		}
		else  if (this->ReleaseMode == EC7AnimNotifyStateNiagaraReleaseMode::AutoReleaseOnNotifyStateEnd)
		{
			float AnimDuration = AnimSequence->GetPlayLength();
			float BeginTime = NotifyEvent.GetTriggerTime();
			float EndTime = NotifyEvent.GetEndTriggerTime();
			
			if (!FMath::IsNearlyEqual(BeginTime, 0.0f, 0.001f))
			{
				FString Message = FString::Printf(
					TEXT("AnimNotifyState Config Error: BeginTime must be 0, now it is %f. \n AnimSequence: %s \n AnimNotifyState: %s."),
					BeginTime,
					*AnimSequence->GetPathName(),
					this->GetNotifyName().IsEmpty() ? *this->GetName() : *this->GetNotifyName()
				);
				FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(Message));
			}
			else if (!FMath::IsNearlyEqual(EndTime, AnimDuration, 0.001f))
			{
				FString Message = FString::Printf(
					TEXT("AnimNotifyState Config Error: EndTime must be %f, now it is %f. \n AnimSequence: %s \n AnimNotifyState: %s."),
					AnimDuration,
					EndTime,
					*AnimSequence->GetPathName(),
					this->GetNotifyName().IsEmpty() ? *this->GetName() : *this->GetNotifyName()
				);
				FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(Message));
			}
		}
	}
}
#endif

void UAnimNotifyState_C7TimedNiagaraEffect::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation,
	float TotalDuration)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7TimedNiagaraEffect::NotifyBegin");
	
	if (!ValidateParameters(MeshComp))
	{
		return;
	}
	
	UWorld* World = GEngine->GetWorldFromContextObject(MeshComp, EGetWorldErrorMode::LogAndReturnNull);
	if (World == nullptr)
	{
		return;
	}

	if (KGPlatformUtils::IsInLevelPreviewWorld(World))
	{
		return;
	}

	UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(World);
	if (!EffectManager)
	{
		// in editor
		SpawnEffect(MeshComp, Animation);
		return;
	}

	FKGPlayNiagaraParams PlayNiagaraParams;
	PlayNiagaraParams.NiagaraEffectPath = TemplatePath.ToString();
	if (bNeedAttach)
	{
		FKGAttachedNiagaraSpawnInfo SpawnInfo;
		SpawnInfo.AttachPointName = SocketName;
		SpawnInfo.SearchAttachComponentType = EKGNiagaraSearchAttachComponentType::UseCustomAttachComponent;
		SpawnInfo.CustomAttachComponent = MeshComp;
		SpawnInfo.bAbsoluteRotation = bAbsoluteRotation;
		SpawnInfo.bAbsoluteScale = bAbsoluteScale;
		SpawnInfo.RelativeTrans = Transform;
		PlayNiagaraParams.SetAttachedSpawnInfo(SpawnInfo);
	}
	else
	{
		FKGUnattachedNiagaraSpawnInfo SpawnInfo;
		SpawnInfo.SearchSpawnLocationType = EKGNiagaraSearchSpawnLocationType::UseCustomSpawnTrans;
		SpawnInfo.WorldOrRelativeTrans = Transform * MeshComp->GetSocketTransform(SocketName, RTS_World);;
		PlayNiagaraParams.SetUnattachedSpawnInfo(SpawnInfo);
	}

	if (this->ReleaseMode == EC7AnimNotifyStateNiagaraReleaseMode::AutoReleaseOnFixedTime &&
		this->TotalLifeSeconds > 0.0f)
	{
		PlayNiagaraParams.TotalLifeMs = TotalLifeSeconds * 1000;
	}
	else
	{
		PlayNiagaraParams.TotalLifeMs = -1;
	}
	
	PlayNiagaraParams.SpawnerID = KGUtils::GetIDByObject(MeshComp->GetOwner());
	
	const int32 EffectID = EffectManager->CreateNiagaraSystem(PlayNiagaraParams);
	Mapping.Add(TWeakObjectPtr<USkeletalMeshComponent>(MeshComp), EffectID);
}

void UAnimNotifyState_C7TimedNiagaraEffect::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7TimedNiagaraEffect::NotifyEnd");
	
	const int32* ret = Mapping.Find(TWeakObjectPtr<USkeletalMeshComponent>(MeshComp));
	if (ret)
	{
		if (this->ReleaseMode == EC7AnimNotifyStateNiagaraReleaseMode::AutoReleaseOnNotifyStateEnd ||
			(this->ReleaseMode == EC7AnimNotifyStateNiagaraReleaseMode::AutoReleaseOnFixedTime && this->TotalLifeSeconds <= 0))
		{
			if (KGPlatformUtils::IsInLevelPreviewWorld(MeshComp))
			{
				return;
			}
			
			if (UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(MeshComp))
			{
				EffectManager->DestroyNiagaraSystem(*ret);
			}
			else
			{
				UE_LOG(LogTemp, Error, TEXT("UAnimNotifyState_C7TimedNiagaraEffect::NotifyEnd, cannot find effect manager"));	
			}
		}
	}
	else {
#if WITH_EDITORONLY_DATA
		auto Component = GetSpawnedEffect(MeshComp);
		if (Component) {
			MappingEditor.Remove(MeshComp);
			Component->DestroyComponent();
		}
#endif
	}
}

bool UAnimNotifyState_C7TimedNiagaraEffect::ValidateParameters(USkeletalMeshComponent* MeshComp) const
{
	bool bValid = true;
	if (TemplatePath.IsNull())
	{
		bValid = false;
	}
	// 默认行为跟引擎保持一致, 这里不需要判定
	// else if (!MeshComp->DoesSocketExist(SocketName) && MeshComp->GetBoneIndex(SocketName) == INDEX_NONE)
	// {
	// 	bValid = false;
	// }
	return bValid;
}

FString UAnimNotifyState_C7TimedNiagaraEffect::GetNotifyName_Implementation() const
{
	return TemplatePath.GetAssetName();
}

void UAnimNotifyState_C7TimedNiagaraEffect::SpawnEffect(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
#if WITH_EDITORONLY_DATA
	// Only spawn if we've got valid params
	TemplatePath.LoadSynchronous();
	UNiagaraComponent* FXComponent = nullptr;
	if (bNeedAttach)
	{
		FXComponent = UNiagaraFunctionLibrary::SpawnSystemAttached(
			TemplatePath.Get(),
			MeshComp,
			SocketName,
			Transform.GetLocation(),
			Transform.GetRotation().Rotator(),
			Transform.GetScale3D(),
			EAttachLocation::KeepRelativeOffset,
			true,
			ENCPoolMethod::None
		);
	}
	else
	{
		const auto& WorldTransform = Transform * MeshComp->GetSocketTransform(SocketName, RTS_World);
		FXComponent = UNiagaraFunctionLibrary::SpawnSystemAtLocation(
			MeshComp->GetWorld(),
			TemplatePath.Get(),
			WorldTransform.GetLocation(),
			WorldTransform.Rotator(),
			WorldTransform.GetScale3D(),
			true,
			true,
			ENCPoolMethod::None
		);
	}
	if (FXComponent)
	{
		FXComponent->SetAbsolute(false, bAbsoluteRotation, bAbsoluteScale);
		MappingEditor.Add(TWeakObjectPtr<USkeletalMeshComponent>(MeshComp), TWeakObjectPtr<UNiagaraComponent>(FXComponent));
	}
#endif
}

UNiagaraComponent* UAnimNotifyState_C7TimedNiagaraEffect::GetSpawnedEffect(USkeletalMeshComponent* MeshComp)
{
#if WITH_EDITORONLY_DATA
	auto ret = MappingEditor.Find(MeshComp);
	if (ret) {
		return ret->Get();
	}
#endif
	return nullptr;
}