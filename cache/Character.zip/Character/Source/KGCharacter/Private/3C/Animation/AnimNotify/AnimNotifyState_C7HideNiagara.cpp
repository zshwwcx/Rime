// Copyright Epic Games, Inc. All Rights Reserved.

// #pragma once

#include "3C/Animation/AnimNotify/AnimNotifyState_C7HideNiagara.h"

#include "Misc/KGPlatformUtils.h"
#include "3C/Effect/KGEffectManager.h"
#include "Animation/AnimSequenceBase.h"
#include "Components/SkeletalMeshComponent.h"


void UAnimNotifyState_C7HideNiagara::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7HideNiagara::NotifyBegin");
	
	if (!IsValid(MeshComp))
	{
		UE_LOG(LogTemp, Error, TEXT("UAnimNotifyState_C7HideNiagara::NotifyBegin, MeshComp is invalid, %s"),
			Animation ? *Animation->GetPathName() : TEXT("null"));
		return;
	}
	
	if (KGPlatformUtils::IsInLevelPreviewWorld(MeshComp))
	{
		return;
	}
	
	if (UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(MeshComp))
	{
		EffectManager->UpdateNiagaraHiddenStateByEffectTag(int32(EffectTag), true, uint8(HiddenReason), bUseBlendTime, BlendOutTimeSeconds);
	}
}

void UAnimNotifyState_C7HideNiagara::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7HideNiagara::NotifyEnd");
	
	if (!IsValid(MeshComp))
	{
		UE_LOG(LogTemp, Error, TEXT("UAnimNotifyState_C7HideNiagara::NotifyEnd, MeshComp is invalid, %s"),
			Animation ? *Animation->GetPathName() : TEXT("null"));
		return;
	}
	
	if (KGPlatformUtils::IsInLevelPreviewWorld(MeshComp))
	{
		return;
	}
	
	if (UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(MeshComp))
	{
		EffectManager->UpdateNiagaraHiddenStateByEffectTag(int32(EffectTag), false, uint8(HiddenReason), bUseBlendTime, BlendInTimeSeconds);
	}

}