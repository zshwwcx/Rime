// Copyright Epic Games, Inc. All Rights Reserved.

#include "3C/Animation/AnimationGraphNode/AnimNode_C7VehicleIK.h"
#include "Engine/Engine.h"
#include "AnimationRuntime.h"
#include "Components/SkeletalMeshComponent.h"

#include "AnimationCoreLibrary.h"
#include "Animation/AnimInstanceProxy.h"
#include "Misc/MathFormula.h"
#include "Animation/AnimTrace.h"
#include "Kismet/KismetMathLibrary.h"
#include "Kismet/KismetSystemLibrary.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(AnimNode_C7VehicleIK)

DECLARE_CYCLE_STAT(TEXT("C7VehicleIK Eval"), STAT_C7VehicleIK_Eval, STATGROUP_Anim);


/////////////////////////////////////////////////////
// FAnimNode_C7CommonIK

FAnimNode_C7VehicleIK::FAnimNode_C7VehicleIK()
{
	TraceArr.Add(UEngineTypes::ConvertToObjectType(BlockChannel));
	LODThreshold = 1;
}

void FAnimNode_C7VehicleIK::UpdateInternal(const FAnimationUpdateContext& Context)
{
	switch (VehicleIKType)
	{
	case EC7VehicleIKType::FourWheelPosture:
		CalculateFourWheelCarIK(Context);
		break;
	case EC7VehicleIKType::WheelOnGround:
		CalculateWheelOnGroundIK(Context);
		break;
	case EC7VehicleIKType::RootDependsOnWheel:
		CalculateRootDependsOnWheelIK(Context);
		break;
	case EC7VehicleIKType::None:
	default:
		break;
	}
}

void FAnimNode_C7VehicleIK::EvaluateSkeletalControl_AnyThread(FComponentSpacePoseContext& Output)
{
	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(EvaluateSkeletalControl_AnyThread)
	SCOPE_CYCLE_COUNTER(STAT_C7VehicleIK_Eval);

	BoneTransforms.Reset();
	switch (VehicleIKType)
	{
	case EC7VehicleIKType::FourWheelPosture:
		ApplyFourWheelCarIK(Output);
		break;
	case EC7VehicleIKType::WheelOnGround:
		ApplyWheelOnGroundIK(Output);
		break;
	case EC7VehicleIKType::RootDependsOnWheel:
		ApplyRootDependsOnWheelIK(Output);
		break;
	case EC7VehicleIKType::None:
		default:
		break;
	}

	if (BoneTransforms.Num() > 0)
	{
		const float BlendWeight = FMath::Clamp<float>(Alpha, 0.f, 1.f);
		Output.Pose.LocalBlendCSBoneTransforms(BoneTransforms, BlendWeight);
	}
	
	// TRACE_ANIM_NODE_VALUE(Output, TEXT("C7CommonIK"), IKBone.BoneName);
}

bool FAnimNode_C7VehicleIK::IsValidToEvaluate(const USkeleton* Skeleton, const FBoneContainer& RequiredBones) 
{
	if (VehicleIKType == EC7VehicleIKType::None)
	{
		return false;
	}
	else if (VehicleIKType == EC7VehicleIKType::FourWheelPosture)
	{
		if (!FourWheelCarIkParam.LeftFrontWheelInfo.IKBone.IsValidToEvaluate(RequiredBones) || !FourWheelCarIkParam.LeftRearWheelInfo.IKBone.IsValidToEvaluate(RequiredBones) ||
			!FourWheelCarIkParam.RightFrontWheelInfo.IKBone.IsValidToEvaluate(RequiredBones) || !FourWheelCarIkParam.RightRearWheelInfo.IKBone.IsValidToEvaluate(RequiredBones))
		{
			return false;
		}
	}
	else if (VehicleIKType == EC7VehicleIKType::WheelOnGround)
	{
		for (int i=0; i<WheelArray.Num(); i++)
		{
			if (!WheelArray[i].IKBone.IsValidToEvaluate(RequiredBones))
			{
				return false;
			}
		}
	}
	else if (VehicleIKType == EC7VehicleIKType::RootDependsOnWheel)
	{
		if (!RootDependsOnWheelParams.LeftFrontWheelInfo.IKBone.IsValidToEvaluate(RequiredBones) 
			|| !RootDependsOnWheelParams.LeftRearWheelInfo.IKBone.IsValidToEvaluate(RequiredBones) 
			|| !RootDependsOnWheelParams.RightFrontWheelInfo.IKBone.IsValidToEvaluate(RequiredBones) 
			|| !RootDependsOnWheelParams.RightRearWheelInfo.IKBone.IsValidToEvaluate(RequiredBones))
		{
			return false;
		}
	}
	
	return true;
}

void FAnimNode_C7VehicleIK::Update_AnyThread(const FAnimationUpdateContext& Context)
{
	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(Update_AnyThread)
	ComponentPose.Update(Context);
	if (IsLODEnabled(Context.AnimInstanceProxy))
	{
		UpdateInternal(Context);
	}
}

void FAnimNode_C7VehicleIK::Evaluate_AnyThread(FPoseContext& Output)
{
	if (!IsLODEnabled(Output.AnimInstanceProxy) || Alpha <= 0.001f)
	{
		ComponentPose.Evaluate(Output);;
		return ;
	}

	// Evaluate the child and convert
	FPoseContext InputPose(Output.AnimInstanceProxy);

	// We need to preserve the node ID chain as we use the proxy-based constructor above
	InputPose.SetNodeIds(Output);

	ComponentPose.Evaluate(InputPose);;

	// Evaluate the child and convert
	FComponentSpacePoseContext InputCSPose(Output.AnimInstanceProxy);
	// We need to preserve the node ID chain as we use the proxy-based constructor above
	InputCSPose.SetNodeIds(InputPose);

	InputCSPose.Pose.InitPose(MoveTemp(InputPose.Pose));
	InputCSPose.Curve = MoveTemp(InputPose.Curve);
	InputCSPose.CustomAttributes = MoveTemp(InputPose.CustomAttributes);

	BoneTransforms.Reset();
	EvaluateSkeletalControl_AnyThread(InputCSPose);

	FCSPose<FCompactPose>::ConvertComponentPosesToLocalPoses(MoveTemp(InputCSPose.Pose), Output.Pose);
	Output.Curve = MoveTemp(InputCSPose.Curve);
	Output.CustomAttributes = MoveTemp(InputCSPose.CustomAttributes);
}

void FAnimNode_C7VehicleIK::InitializeBoneReferences(const FAnimationCacheBonesContext& Context)
{
	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(InitializeBoneReferences)

	switch (VehicleIKType)
	{
	case EC7VehicleIKType::FourWheelPosture:
		InitFourWheelCarBoneReferences(Context);
		break;
	case EC7VehicleIKType::WheelOnGround:
		InitWheelOnGroundBoneReferences(Context);
		break;
	case EC7VehicleIKType::RootDependsOnWheel:
		InitRootDependsOnWheelBoneReferences(Context);
		break;
	case EC7VehicleIKType::None:
	default:
		break;
	}
}

void FAnimNode_C7VehicleIK::InitFourWheelCarBoneReferences(const FAnimationCacheBonesContext& Context)
{
	const FBoneContainer& RequiredBones = Context.AnimInstanceProxy->GetRequiredBones();
	FourWheelCarIkParam.LeftFrontWheelInfo.IKBone.Initialize(RequiredBones);
	FourWheelCarIkParam.LeftRearWheelInfo.IKBone.Initialize(RequiredBones);
	FourWheelCarIkParam.RightFrontWheelInfo.IKBone.Initialize(RequiredBones);
	FourWheelCarIkParam.RightRearWheelInfo.IKBone.Initialize(RequiredBones);
}

void FAnimNode_C7VehicleIK::InitWheelOnGroundBoneReferences(const FAnimationCacheBonesContext& Context)
{
	const FBoneContainer& RequiredBones = Context.AnimInstanceProxy->GetRequiredBones();
	for (int i=0; i<WheelArray.Num(); i++)
	{
		WheelArray[i].IKBone.Initialize(RequiredBones);
	}
}

void FAnimNode_C7VehicleIK::CalculateFourWheelCarIK(const FAnimationUpdateContext& Context)
{
	if (!OwnerSkeletalMesh.IsValid()) return;
	AActor* Owner = OwnerSkeletalMesh->GetOwner();
	if (!Owner || Owner->GetVelocity().IsNearlyZero()) return;
	
	// 计算载具俯仰角
	FHitResult FLOutHit;
	FHitResult FROutHit;
	FHitResult RLOutHit;
	FHitResult RROutHit;
	TArray<AActor*> IgnoreActor;
	
	const FVector CarFlWheelLocCache = OwnerSkeletalMesh->GetBoneLocation(FourWheelCarIkParam.LeftFrontWheelInfo.IKBone.BoneName) + FVector::UpVector * StartUpDis;
	const FVector CarFrWheelLocCache =  OwnerSkeletalMesh->GetBoneLocation(FourWheelCarIkParam.RightFrontWheelInfo.IKBone.BoneName) + FVector::UpVector * StartUpDis;
	const FVector CarRlWheelLocCache =  OwnerSkeletalMesh->GetBoneLocation(FourWheelCarIkParam.LeftRearWheelInfo.IKBone.BoneName) + FVector::UpVector * StartUpDis;
	const FVector CarRrWheelLocCache =  OwnerSkeletalMesh->GetBoneLocation(FourWheelCarIkParam.RightRearWheelInfo.IKBone.BoneName) + FVector::UpVector * StartUpDis;
	
	TraceStartList.Empty();
	TraceStartList.Add(CarFlWheelLocCache);
	TraceStartList.Add(CarFrWheelLocCache);
	TraceStartList.Add(CarRlWheelLocCache);
	TraceStartList.Add(CarRrWheelLocCache);
	
	TraceEndList.Empty();
	TraceEndList.Add(CarFlWheelLocCache + FVector::DownVector * TraceLength);
	TraceEndList.Add(CarFrWheelLocCache + FVector::DownVector * TraceLength);
	TraceEndList.Add(CarRlWheelLocCache + FVector::DownVector * TraceLength);
	TraceEndList.Add(CarRrWheelLocCache + FVector::DownVector * TraceLength);

	TraceRadius.Empty();
	TraceRadius.Add(FourWheelCarIkParam.LeftFrontWheelInfo.SphereTraceRadius);
	TraceRadius.Add(FourWheelCarIkParam.LeftRearWheelInfo.SphereTraceRadius);
	TraceRadius.Add(FourWheelCarIkParam.RightFrontWheelInfo.SphereTraceRadius);
	TraceRadius.Add(FourWheelCarIkParam.RightRearWheelInfo.SphereTraceRadius);
	
	bool bFrontLHit = UKismetSystemLibrary::SphereTraceSingleForObjects(Owner, TraceStartList[0], TraceEndList[0], TraceRadius[0],
				TraceArr, false, IgnoreActor, EDrawDebugTrace::None, FLOutHit, true);
	bool bFrontRHit = UKismetSystemLibrary::SphereTraceSingleForObjects(Owner, TraceStartList[1], TraceEndList[1], TraceRadius[1], 
		TraceArr, false, IgnoreActor, EDrawDebugTrace::None, FROutHit, true);
	bool bRearLHit = UKismetSystemLibrary::SphereTraceSingleForObjects(Owner, TraceStartList[2], TraceEndList[2], TraceRadius[2], 
		TraceArr, false, IgnoreActor, EDrawDebugTrace::None, RLOutHit, true);
	bool bRearRHit = UKismetSystemLibrary::SphereTraceSingleForObjects(Owner, TraceStartList[3], TraceEndList[3], TraceRadius[3],
		TraceArr, false, IgnoreActor, EDrawDebugTrace::None, RROutHit, true);
 
	if (bFrontLHit && bRearLHit)
	{
		DestPitch = UKismetMathLibrary::FindLookAtRotation(FLOutHit.ImpactPoint, RLOutHit.ImpactPoint).Pitch;
	}
	if (bFrontRHit && bRearRHit)
	{
		float TempDestPitch = UKismetMathLibrary::FindLookAtRotation(FROutHit.ImpactPoint, RROutHit.ImpactPoint).Pitch;
		if (FMath::Abs(TempDestPitch) > FMath::Abs(DestPitch))
		{
			DestPitch = TempDestPitch;
		}
	}

	if (bRearLHit && bRearRHit)
	{
		DestRoll = UKismetMathLibrary::FindLookAtRotation(RROutHit.ImpactPoint, RLOutHit.ImpactPoint).Pitch;
	}
	else if (bFrontLHit && bFrontRHit)
	{
		DestRoll = UKismetMathLibrary::FindLookAtRotation(FROutHit.ImpactPoint, FLOutHit.ImpactPoint).Pitch;
	}

	ApplyPitch = MathFormula::DecayValue(ApplyPitch, DestPitch, PitchHalfTime, Context.GetDeltaTime());
	ApplyRoll = MathFormula::DecayValue(ApplyRoll, DestRoll, RollHalfTime, Context.GetDeltaTime());
}

void FAnimNode_C7VehicleIK::ApplyFourWheelCarIK(FComponentSpacePoseContext& Output)
{
	const FBoneContainer& BoneContainer = Output.Pose.GetPose().GetBoneContainer();
	FBoneReference MyBoneReference;
	MyBoneReference.BoneName = ApplyModifyBone;
	if(!MyBoneReference.Initialize(BoneContainer) || !MyBoneReference.IsValidToEvaluate(Output.AnimInstanceProxy->GetRequiredBones()))
	{
		return;
	}
		
	FCompactPoseBoneIndex CompactPoseBoneToModify = MyBoneReference.GetCompactPoseIndex(BoneContainer);
	FTransform NewBoneTM = Output.Pose.GetComponentSpaceTransform(CompactPoseBoneToModify);
	FTransform ComponentTransform = Output.AnimInstanceProxy->GetComponentTransform();

	const FQuat BoneQuat(FRotator(ApplyRoll, 0, ApplyPitch));
	NewBoneTM.SetRotation(BoneQuat * NewBoneTM.GetRotation());
	FAnimationRuntime::ConvertBoneSpaceTransformToCS(ComponentTransform, Output.Pose, NewBoneTM, CompactPoseBoneToModify, EBoneControlSpace::BCS_BoneSpace);
	BoneTransforms.Add( FBoneTransform(MyBoneReference.GetCompactPoseIndex(BoneContainer), NewBoneTM));
}

void FAnimNode_C7VehicleIK::CalculateWheelOnGroundIK(const FAnimationUpdateContext& Context)
{
	if (!OwnerSkeletalMesh.IsValid() || WheelOnGroundAdjustArray.Num() != WheelArray.Num()) return;
	AActor* Owner = OwnerSkeletalMesh->GetOwner();
	if (!Owner) return;

	FVector MeshUpVector = OwnerSkeletalMesh->GetUpVector();
	
	TArray<AActor*> IgnoreActor;
	TraceStartList.Empty();
	TraceEndList.Empty();
	TraceRadius.Empty();
	for (int i=0; i<WheelArray.Num(); i++)
	{
		FWheelInfo WheelInfo = WheelArray[i];
		FHitResult HitResult;

		const FVector WheelLocation = OwnerSkeletalMesh->GetBoneLocation(WheelInfo.IKBone.BoneName) - MeshUpVector * (WheelOnGroundAdjustArray[i] + WheelInfo.WheelRadius);
		// 从轮胎底部开始检测
		const FVector StartLocation = WheelLocation + MeshUpVector * StartUpDis;
		const FVector EndLocation = StartLocation - MeshUpVector * TraceLength;
		
		TraceStartList.Add(StartLocation);
		TraceEndList.Add(EndLocation);
		TraceRadius.Add(WheelInfo.SphereTraceRadius);
		if (UKismetSystemLibrary::SphereTraceSingleForObjects(Owner, TraceStartList[i], TraceEndList[i], TraceRadius[i], TraceArr, false, IgnoreActor, EDrawDebugTrace::None, HitResult, true))
		{
			// 向下拉
			float WheelUpDistance = WheelOnGroundAdjustArray[i];
			if (HitResult.Distance > StartUpDis)
			{
				WheelUpDistance = FMath::Max(StartUpDis - HitResult.Distance, WheelUpDownRange.X);
			}
			else
			{
				WheelUpDistance = FMath::Min(StartUpDis - HitResult.Distance, WheelUpDownRange.Y);
			}
			WheelOnGroundAdjustArray[i] = MathFormula::DecayValue(WheelOnGroundAdjustArray[i], WheelUpDistance, WheelOnGroundHalfTime, Context.GetDeltaTime());
		}
	}
}

void FAnimNode_C7VehicleIK::ApplyWheelOnGroundIK(FComponentSpacePoseContext& Output)
{
	TArray<float> WheelAdjust = WheelOnGroundAdjustArray;
	if (WheelAdjust.Num() != WheelArray.Num()) return;
	
	const FBoneContainer& BoneContainer = Output.Pose.GetPose().GetBoneContainer();
	FTransform ComponentTransform = Output.AnimInstanceProxy->GetComponentTransform();

	for (int i=0; i<WheelArray.Num(); i++)
	{
		FWheelInfo WheelInfo = WheelArray[i];
		
		FCompactPoseBoneIndex CompactPoseBoneToModify = WheelInfo.IKBone.GetCompactPoseIndex(BoneContainer);
		if(CompactPoseBoneToModify == INDEX_NONE)
		{
			continue;
		}
		FTransform NewBoneTM = Output.Pose.GetComponentSpaceTransform(CompactPoseBoneToModify);
		
		FAnimationRuntime::ConvertCSTransformToBoneSpace(ComponentTransform, Output.Pose, NewBoneTM, CompactPoseBoneToModify, BCS_BoneSpace);
		
		NewBoneTM.AddToTranslation(FVector(0, 0, WheelAdjust[i]));
		
		FAnimationRuntime::ConvertBoneSpaceTransformToCS(ComponentTransform, Output.Pose, NewBoneTM, CompactPoseBoneToModify, BCS_BoneSpace);
		
		BoneTransforms.Add( FBoneTransform(WheelInfo.IKBone.GetCompactPoseIndex(BoneContainer), NewBoneTM));
	}
	
	BoneTransforms.Sort([](const FBoneTransform& A, const FBoneTransform& B) {
		return A.BoneIndex < B.BoneIndex;
	});
}

void FAnimNode_C7VehicleIK::InitRootDependsOnWheelBoneReferences(const FAnimationCacheBonesContext& Context)
{
	const FBoneContainer& RequiredBones = Context.AnimInstanceProxy->GetRequiredBones();
	RootDependsOnWheelParams.LeftFrontWheelInfo.IKBone.Initialize(RequiredBones);
	RootDependsOnWheelParams.LeftRearWheelInfo.IKBone.Initialize(RequiredBones);
	RootDependsOnWheelParams.RightFrontWheelInfo.IKBone.Initialize(RequiredBones);
	RootDependsOnWheelParams.RightRearWheelInfo.IKBone.Initialize(RequiredBones);
	
	FTransform ComponentToWorld = Context.AnimInstanceProxy->GetComponentTransform();
	FVector ComponentScale3D = ComponentToWorld.GetScale3D();
	const FReferenceSkeleton& RefSkeleton = RequiredBones.GetReferenceSkeleton();
	
	ApplyRootTransformCS = GetBoneComponentSpaceTransform(RefSkeleton, ApplyModifyRootBone);
	
	TArray<FWheelInfo> WheelInfoArray;
	WheelInfoArray.Add(RootDependsOnWheelParams.LeftFrontWheelInfo);
	WheelInfoArray.Add(RootDependsOnWheelParams.RightFrontWheelInfo);
	WheelInfoArray.Add(RootDependsOnWheelParams.LeftRearWheelInfo);
	WheelInfoArray.Add(RootDependsOnWheelParams.RightRearWheelInfo);
	
	FVector WheelCenter = FVector::ZeroVector;
	RuntimeWheels.Empty();
	for (auto& Wheel: WheelInfoArray)
	{
		FName BoneName = Wheel.IKBone.BoneName;
		FWheelRuntimeInfo RuntimeWheel;
		FTransform TransformCS = GetBoneComponentSpaceTransform(RefSkeleton, BoneName);
		RuntimeWheel.ComponentSpaceTransform = GetBoneComponentSpaceTransform(RefSkeleton, BoneName);
		RuntimeWheel.RelativeToRootTransform = TransformCS.GetRelativeTransform(ApplyRootTransformCS);
		RuntimeWheel.AppyRoll = TransformCS.GetRotation().Rotator().Roll;
		RuntimeWheel.Radius = Wheel.WheelRadius * ComponentScale3D.Z;
		RuntimeWheel.TraceRadius = Wheel.SphereTraceRadius * ComponentScale3D.Z;
		RuntimeWheels.Add(BoneName, RuntimeWheel);
		FVector Translation = (TransformCS * ComponentToWorld).GetTranslation();
		Translation.Z += RuntimeWheel.TraceRadius - RuntimeWheel.Radius;
		WheelCenter += Translation;
	}
	WheelCenter /= 4;
	
	FQuat ActorRotation = Context.AnimInstanceProxy->GetActorTransform().GetRotation();
	FVector RootLocation = (ApplyRootTransformCS * ComponentToWorld).GetTranslation();
	// RootLocation = WheelCenter + ActorRotation.RotateVector(RootToWheelCenterOffset)
	RootToWheelCenterOffset = ActorRotation.Inverse().RotateVector(RootLocation - WheelCenter);
}

FVector FAnimNode_C7VehicleIK::CalculateWheelGroundedPos(FTransform WheelTransformWS, float WheelTraceRadius, float WheelRadius)
{
	FVector BoneLocation = WheelTransformWS.GetLocation();
	FVector RetLocation = BoneLocation + FVector::UpVector * (WheelTraceRadius - WheelRadius);
	if (!OwnerSkeletalMesh.IsValid() || !OwnerSkeletalMesh->GetOwner())
	{
		return RetLocation;
	}
		
	TArray<AActor*> IgnoreActor;
	FVector TraceStart = BoneLocation + FVector::UpVector * StartUpDis;
	FVector TraceEnd = BoneLocation + FVector::DownVector * TraceLength;
	TArray<struct FHitResult> OutHits;
	UKismetSystemLibrary::SphereTraceMultiForObjects(OwnerSkeletalMesh->GetOwner(), TraceStart, TraceEnd, WheelTraceRadius, 
		TraceArr, false, IgnoreActor, EDrawDebugTrace::None, OutHits, true,
		FLinearColor::Red, FLinearColor::Green);
		
	if (OutHits.Num() > 0)
	{
		FVector CurrentGroundPos = TraceStart;
		float MaxTraceDistance = StartUpDis + TraceLength;
		FVector HitNormal = FVector::UpVector;
		for (struct FHitResult& Hit : OutHits)
		{
			if (MaxTraceDistance > Hit.Distance)
			{
				// 轮胎是扁的，不是标准球形，所以离的远的碰撞直接忽略
				FVector PointInWheelSpace = WheelTransformWS.InverseTransformPosition(Hit.ImpactPoint);
				if ( WheelWidth > 0 && (PointInWheelSpace.X > WheelWidth || PointInWheelSpace.X < -WheelWidth))
				{
					continue;
				}
				MaxTraceDistance = Hit.Distance;
				CurrentGroundPos = Hit.ImpactPoint;
				HitNormal = Hit.ImpactNormal;
			}
		}
			
		if (!CurrentGroundPos.Equals(TraceStart))
		{
			FVector WheelCenter = CurrentGroundPos + HitNormal * WheelTraceRadius;
			RetLocation = WheelCenter;
		}
		return RetLocation;
	}
	return RetLocation;
}

float FAnimNode_C7VehicleIK::CalculateWheelRoll(const float CurrentRoll, float TranslationDelta, float WheelRadius)
{
	float RetRoll = CurrentRoll;
	if (WheelRadius > UE_SMALL_NUMBER)
	{
		float WheelRollDelta = TranslationDelta / (2 * PI * WheelRadius) * 360;
		RetRoll += WheelRollDelta;
	}
	if (RetRoll > 360)
	{
		RetRoll -= 360;
	}
	return RetRoll;
}

FTransform FAnimNode_C7VehicleIK::GetBoneComponentSpaceTransform(const FReferenceSkeleton& RefSkeleton, FName BoneName) const
{
	FTransform RetTransform;
	int32 BoneIndex = RefSkeleton.FindBoneIndex(BoneName);
	if (BoneIndex == INDEX_NONE)
	{
		return RetTransform;
	}
	RetTransform = RefSkeleton.GetRefBonePose()[BoneIndex];
	int32 ParentIndex = RefSkeleton.GetParentIndex(BoneIndex);
	while (ParentIndex != INDEX_NONE)
	{
		RetTransform = RetTransform * RefSkeleton.GetRefBonePose()[ParentIndex];
		ParentIndex = RefSkeleton.GetParentIndex(ParentIndex);
	}
	return RetTransform;

};

void FAnimNode_C7VehicleIK::CalculateRootDependsOnWheelIK(const FAnimationUpdateContext& Context)
{
	if (!OwnerSkeletalMesh.IsValid()) return;
	AActor* Owner = OwnerSkeletalMesh->GetOwner();
	if (!Owner || Owner->GetVelocity().IsNearlyZero()) return;
	float CurVelocity = Owner->GetVelocity().Length();
	
	const auto& Params = RootDependsOnWheelParams;
	if (!RuntimeWheels.Contains(Params.LeftFrontWheelInfo.IKBone.BoneName) || !RuntimeWheels.Contains(Params.RightFrontWheelInfo.IKBone.BoneName)
		|| !RuntimeWheels.Contains(Params.LeftRearWheelInfo.IKBone.BoneName) || !RuntimeWheels.Contains(Params.RightRearWheelInfo.IKBone.BoneName))
	return;
	
	FTransform ComponentToWorld = Context.AnimInstanceProxy->GetComponentTransform();
	FVector ComponentScale3D = ComponentToWorld.GetScale3D();
	
	auto& WheelFrontLeft = RuntimeWheels[Params.LeftFrontWheelInfo.IKBone.BoneName];
	const FVector WheelFrontLeftGroundLoc = CalculateWheelGroundedPos( WheelFrontLeft.ComponentSpaceTransform * ComponentToWorld, WheelFrontLeft.TraceRadius, WheelFrontLeft.Radius);
	auto& WheelFrontRight = RuntimeWheels[Params.RightFrontWheelInfo.IKBone.BoneName];
	const FVector WheelFrontRightGroundLoc =  CalculateWheelGroundedPos( WheelFrontRight.ComponentSpaceTransform * ComponentToWorld, WheelFrontRight.TraceRadius, WheelFrontRight.Radius);
	auto& WheelRearLeft = RuntimeWheels[Params.LeftRearWheelInfo.IKBone.BoneName];
	const FVector WheelRearLeftGroundLoc =  CalculateWheelGroundedPos( WheelRearLeft.ComponentSpaceTransform * ComponentToWorld, WheelRearLeft.TraceRadius, WheelRearLeft.Radius);
	auto& WheelRearRight = RuntimeWheels[Params.RightRearWheelInfo.IKBone.BoneName];
	const FVector WheelRearRightGroundLoc =  CalculateWheelGroundedPos( WheelRearRight.ComponentSpaceTransform * ComponentToWorld, WheelRearRight.TraceRadius, WheelRearRight.Radius);
	
	const FVector FrontCenter = (WheelFrontLeftGroundLoc + WheelFrontRightGroundLoc) / 2;
	const FVector RearCenter = (WheelRearLeftGroundLoc + WheelRearRightGroundLoc) / 2;
	
	FVector XDir = FrontCenter - RearCenter;
	FVector YDir = WheelRearRightGroundLoc - WheelRearLeftGroundLoc;
	FRotator DestRotator = UKismetMathLibrary::MakeRotFromXY(XDir, YDir);
	FVector DestLocation = (FrontCenter + RearCenter) / 2 + DestRotator.RotateVector(RootToWheelCenterOffset);
	
	FTransform LastRootTransform = ApplyRootTransformCS * ComponentToWorld;
	FRotator LastRootRotator = LastRootTransform.GetRotation().Rotator();
	FVector LastRootLocation = LastRootTransform.GetLocation();
	
	FVector ApplyLocation = FVector::ZeroVector;
	MathFormula::DecayValue(ApplyLocation, LastRootLocation, DestLocation, RootLocationHalfTime, Context.GetDeltaTime());
	
	FRotator ApplyRotation = FRotator(
		MathFormula::DecayValue(LastRootRotator.Pitch, DestRotator.Roll, RootPitchHalfTime, Context.GetDeltaTime()), 
		DestRotator.Yaw-90, 
		MathFormula::DecayValue(LastRootRotator.Roll, DestRotator.Pitch*-1, RootRollHalfTime, Context.GetDeltaTime())
		);
	ApplyRootTransformCS = FTransform(ApplyRotation, ApplyLocation, ComponentScale3D).GetRelativeTransform(ComponentToWorld);
	
	const float DeltaTranslation = CurVelocity * Context.GetDeltaTime();
	if (DeltaTranslation > UE_SMALL_NUMBER)
	{
		WheelFrontLeft.AppyRoll = CalculateWheelRoll(WheelFrontLeft.AppyRoll, DeltaTranslation, WheelFrontLeft.Radius);
		WheelFrontRight.AppyRoll = CalculateWheelRoll(WheelFrontRight.AppyRoll, DeltaTranslation, WheelFrontRight.Radius);
		WheelRearLeft.AppyRoll = CalculateWheelRoll(WheelRearLeft.AppyRoll, DeltaTranslation, WheelRearLeft.Radius);
		WheelRearRight.AppyRoll = CalculateWheelRoll(WheelRearRight.AppyRoll, DeltaTranslation, WheelRearRight.Radius);
	}
}

void FAnimNode_C7VehicleIK::ApplyRootDependsOnWheelIK(FComponentSpacePoseContext& Output)
{
	const FBoneContainer& BoneContainer = Output.Pose.GetPose().GetBoneContainer();
	FBoneReference MyBoneReference;
	MyBoneReference.BoneName = ApplyModifyRootBone;
	if(!MyBoneReference.Initialize(BoneContainer) || !MyBoneReference.IsValidToEvaluate(Output.AnimInstanceProxy->GetRequiredBones()))
	{
		return;
	}
	FCompactPoseBoneIndex CompactPoseBoneToModify = MyBoneReference.GetCompactPoseIndex(BoneContainer);
	if (CompactPoseBoneToModify == INDEX_NONE)
	{
		return;
	}
	
	BoneTransforms.Add( FBoneTransform(MyBoneReference.GetCompactPoseIndex(BoneContainer), ApplyRootTransformCS));
	for (auto& WheelElem: RuntimeWheels)
	{
		FBoneReference WheelBoneReference;
		WheelBoneReference.BoneName = WheelElem.Key;
		if(!WheelBoneReference.Initialize(BoneContainer) || !WheelBoneReference.IsValidToEvaluate(Output.AnimInstanceProxy->GetRequiredBones()))
		{
			continue;
		}
		FCompactPoseBoneIndex BoneToModify = WheelBoneReference.GetCompactPoseIndex(BoneContainer);
		if (BoneToModify == INDEX_NONE)
		{
			continue;
		}
		const auto& RuntimeWheel = WheelElem.Value;
		FTransform WheelTransform = RuntimeWheel.RelativeToRootTransform * ApplyRootTransformCS;
		FRotator CurrentRotator = WheelTransform.GetRotation().Rotator();
		CurrentRotator.Roll = RuntimeWheel.AppyRoll;
		WheelTransform.SetRotation(CurrentRotator.Quaternion());
		BoneTransforms.Add( FBoneTransform(BoneToModify, WheelTransform));
	}
	
	if (BoneTransforms.Num() > 1)
	{
		BoneTransforms.Sort([](const FBoneTransform& A, const FBoneTransform& B)
			{
				return A.BoneIndex < B.BoneIndex;
			});
	}
}

void FAnimNode_C7VehicleIK::Initialize_AnyThread(const FAnimationInitializeContext& Context)
{
	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(Initialize_AnyThread)
	Super::Initialize_AnyThread(Context);
	ComponentPose.Initialize(Context);
	
	OwnerSkeletalMesh = Context.AnimInstanceProxy->GetSkelMeshComponent();

	for (int i=0; i<WheelArray.Num(); i++)
	{
		WheelOnGroundAdjustArray.Add(0);
	}
}

void FAnimNode_C7VehicleIK::CacheBones_AnyThread(const FAnimationCacheBonesContext& Context)
{
	FAnimNode_Base::CacheBones_AnyThread(Context);
	InitializeBoneReferences(Context);
	ComponentPose.CacheBones(Context);
}
