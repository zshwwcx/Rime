// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Animation/AnimNotify/AnimNotify_C7PostProcess.h"

#include "3C/Character/BaseCharacter.h"
#include "3C/Character/LuaActorBase.h"
#include "Components/SkeletalMeshComponent.h"

void UAnimNotify_C7PostProcess::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotify_C7PostProcess::Notify");
	
	if (MeshComp)
	{
		if (ABaseCharacter* Character = Cast<ABaseCharacter>(MeshComp->GetOwner()))
		{
			ACTOR_CALL_LUA_ENTITY(Character, "KCB_C7PostProcess", PostID, AlphaInTime, AlphaOutTime, Duration);
		}
		
	}
}
