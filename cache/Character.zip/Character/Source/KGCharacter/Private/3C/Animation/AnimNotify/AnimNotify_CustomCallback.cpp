// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Animation/AnimNotify/AnimNotify_CustomCallback.h"

void UAnimNotify_CustomCallback::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotify_CustomCallback::Notify");
	
	if(OnAnimNotifyDelegate.IsBound())
	{
		OnAnimNotifyDelegate.Execute(NotifyName, MeshComp, Animation);
	}
}
