// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Animation/AnimNotify/AnimNotifyState_C7ChangeHair.h"

#include "3C/Animation/BaseAnimInstance.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Character/C7Actor.h"
#include "GameFramework/Character.h"

void UAnimNotifyState_C7ChangeHair::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation,
                                                float TotalDuration)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7ChangeHair::NotifyBegin");
	
	ABaseCharacter* TargetCharacter = Cast<ABaseCharacter>(MeshComp->GetOwner());
	AC7Actor* C7Actor = Cast<AC7Actor>(MeshComp->GetOwner());
	if (TargetCharacter == nullptr && C7Actor == nullptr)
	{
		return;
	}
	
	if(TargetCharacter)
	{
		TargetCharacter->CallLuaEntity(TargetCharacter, TargetCharacter->GetEntityUID(), "KCB_OnAnimNotify_C7ChangeHair", TargetCharacter->GetEntityUID(), !bReverse);
	}
	else
	{
		C7Actor->CallLuaEntity(C7Actor, C7Actor->GetEntityUID(), "KCB_OnAnimNotify_C7ChangeHair", C7Actor->GetEntityUID(), !bReverse);
	}
}

void UAnimNotifyState_C7ChangeHair::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7ChangeHair::NotifyEnd");
	
	ABaseCharacter* TargetCharacter = Cast<ABaseCharacter>(MeshComp->GetOwner());
	AC7Actor* C7Actor = Cast<AC7Actor>(MeshComp->GetOwner());
	if (TargetCharacter == nullptr && C7Actor == nullptr)
	{
		return;
	}
	
	if(TargetCharacter)
	{
		TargetCharacter->CallLuaEntity(TargetCharacter, TargetCharacter->GetEntityUID(), "KCB_OnAnimNotify_C7ChangeHair", TargetCharacter->GetEntityUID(), bReverse);
	}
	else
	{
		C7Actor->CallLuaEntity(C7Actor, C7Actor->GetEntityUID(), "KCB_OnAnimNotify_C7ChangeHair", C7Actor->GetEntityUID(), bReverse);
	}
}
