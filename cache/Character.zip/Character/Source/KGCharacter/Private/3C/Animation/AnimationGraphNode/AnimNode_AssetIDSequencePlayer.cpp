#include "3C/Animation/AnimationGraphNode/AnimNode_AssetIDSequencePlayer.h"
#include "Animation/AnimInstanceProxy.h"
#include "AnimEncoding.h"
#include "3C/Animation/BaseAnimInstance.h"
#include "Animation/AnimBlueprintGeneratedClass.h"
#include "Animation/AnimTrace.h"
#include "Animation/AnimMontage.h"

#define LOCTEXT_NAMESPACE "AnimNode_AssetIDSequencePlayer"

/////////////////////////////////////////////////////
// FAnimSequencePlayerNode

float FAnimNode_AssetIDSequencePlayer::GetCurrentAssetTime() const
{
	return InternalTimeAccumulator;
}

float FAnimNode_AssetIDSequencePlayer::GetCurrentAssetTimePlayRateAdjusted() const
{
	const float SequencePlayRate = (Sequence ? Sequence->RateScale : 1.f);
	const float AdjustedPlayRate = PlayRateScaleBiasClamp.ApplyTo(FMath::IsNearlyZero(PlayRateBasis) ? 0.f : (PlayRate / PlayRateBasis), 0.f);
	const float EffectivePlayrate = SequencePlayRate * AdjustedPlayRate;
	return (EffectivePlayrate < 0.0f) ? GetCurrentAssetLength() - InternalTimeAccumulator : InternalTimeAccumulator;
}

float FAnimNode_AssetIDSequencePlayer::GetCurrentAssetLength() const
{
	return Sequence ? Sequence->GetPlayLength() : 0.0f;
}
 
void FAnimNode_AssetIDSequencePlayer::Initialize_AnyThread(const FAnimationInitializeContext& Context)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_AssetIDSequencePlayer::Initialize_AnyThread");
	FAnimNode_AssetPlayerBase::Initialize_AnyThread(Context);

	GetEvaluateGraphExposedInputs().Execute(Context);

	if (Sequence && !ensureMsgf(!Sequence->IsA<UAnimMontage>(), TEXT("Sequence players do not support anim montages.")))
	{
		Sequence = nullptr;
	}

	if (Sequence != nullptr)
	{
		if(StartPositionType == EStartPositionType::FootPosture)
		{
			StartPosition = 0.f;
			if(FootPostureValue>0)
			{
				StartPosition = Sequence->GetPlayLength() * FootPostureAnimLengthRatio;
			}
		}
		else if(StartPositionType == EStartPositionType::MapRange)
		{
			StartPosition = FMath::GetMappedRangeValueUnclamped(MapRangeStruct.InRange, MapRangeStruct.OutRange, MapRangeValue);
		}
	}

	InternalTimeAccumulator = StartPosition;
	PlayRateScaleBiasClamp.Reinitialize();

	if (Sequence != nullptr)
	{
		InternalTimeAccumulator = FMath::Clamp(StartPosition, 0.f, Sequence->GetPlayLength());
		const float AdjustedPlayRate = PlayRateScaleBiasClamp.ApplyTo(FMath::IsNearlyZero(PlayRateBasis) ? 0.f : (PlayRate / PlayRateBasis), 0.f);
		const float EffectivePlayrate = Sequence->RateScale * AdjustedPlayRate;
		if ((StartPosition == 0.f) && (EffectivePlayrate < 0.f))
		{
			InternalTimeAccumulator = Sequence->GetPlayLength();
		}
	}
}

void FAnimNode_AssetIDSequencePlayer::CacheBones_AnyThread(const FAnimationCacheBonesContext& Context)
{
}

void FAnimNode_AssetIDSequencePlayer::UpdateAssetPlayer(const FAnimationUpdateContext& Context)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_AssetIDSequencePlayer::UpdateAssetPlayer");
	GetEvaluateGraphExposedInputs().Execute(Context);

	if (Sequence && !ensureMsgf(!Sequence->IsA<UAnimMontage>(), TEXT("Sequence players do not support anim montages.")))
	{
		Sequence = nullptr;
	}
	
	if(DynamicLoadFromBaseAnimInstance && Sequence == nullptr)
	{
		UAnimInstance* AnimInstance = Cast<UAnimInstance>(Context.AnimInstanceProxy->GetAnimInstanceObject());
		if(!AnimInstance)
		{
			return;
		}

		USkeletalMeshComponent* OwningComponent = AnimInstance->GetOwningComponent();
		if(!OwningComponent)
		{
			return;
		}
		
		if (UBaseAnimInstance* BaseAnimInstance = Cast<UBaseAnimInstance>(OwningComponent->GetAnimInstance()))
		{
			Sequence = BaseAnimInstance->GetSequenceFromAssetID(AssetID);
		}
	}
	
	if ((Sequence != nullptr) && (Sequence->GetSkeleton() != nullptr))
	{
		float AdjustedPlayRate = PlayRateScaleBiasClamp.ApplyTo(FMath::IsNearlyZero(PlayRateBasis) ? 0.f : (PlayRate / PlayRateBasis), Context.GetDeltaTime());
		bool IsEvaluator = false;
		// 这里通过explicitTime来模拟SequenceEvaluator, 把动画一直定到某一帧的功能
		if(StartPositionType == EStartPositionType::ExplicitTime)
		{
			InternalTimeAccumulator = StartPosition;
			AdjustedPlayRate = 0.0f;
			IsEvaluator = true;
		}
	
		InternalTimeAccumulator = FMath::Clamp(InternalTimeAccumulator, 0.f, Sequence->GetPlayLength());
		
		CreateTickRecordForNode(Context, Sequence, bLoopAnimation, AdjustedPlayRate, IsEvaluator);
	}

#if WITH_EDITORONLY_DATA
	if (FAnimBlueprintDebugData* DebugData = Context.AnimInstanceProxy->GetAnimBlueprintDebugData())
	{
		DebugData->RecordSequencePlayer(Context.GetCurrentNodeId(), GetAccumulatedTime(), Sequence != nullptr ? Sequence->GetPlayLength() : 0.0f, Sequence != nullptr ? Sequence->GetNumberOfSampledKeys() : 0);
	}
#endif

	if(AnimLibID != NAME_None && Sequence == nullptr)
	{
		UE_LOG(LogAnimation, Warning, TEXT("[FAnimNode_AssetIDSequencePlayer]: Cannot Find Anim Sequence With ABP AnimLib:%s  AnimKey:%s , NodeName:%s"),
			*AnimLibID.ToString(), *AssetID.GetNameID().ToString(), *Name.ToString() );
	}
}

void FAnimNode_AssetIDSequencePlayer::Evaluate_AnyThread(FPoseContext& Output)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_AssetIDSequencePlayer::Evaluate_AnyThread");
	if ((Sequence != nullptr) && (Sequence->GetSkeleton() != nullptr))
	{
		check(IsValid(Sequence));
		check(IsValid(Sequence->GetSkeleton()));
		check(Output.Pose.GetBoneContainer().IsValid());
		check(Output.Pose.GetNumBones() > 0);
		const bool bExpectedAdditive = Output.ExpectsAdditivePose();
		const bool bIsAdditive = Sequence->IsValidAdditive();

		if (bExpectedAdditive && !bIsAdditive)
		{
			FText Message = FText::Format(LOCTEXT("AdditiveMismatchWarning", "Trying to play a non-additive animation '{0}' into a pose that is expected to be additive in anim instance '{1}'"), FText::FromString(Sequence->GetName()), FText::FromString(Output.AnimInstanceProxy->GetAnimInstanceName()));
			Output.LogMessage(EMessageSeverity::Warning, Message);
		}

		FAnimationPoseData AnimationPoseData(Output);
		Sequence->GetAnimationPose(AnimationPoseData, FAnimExtractContext((double)InternalTimeAccumulator, Output.AnimInstanceProxy->ShouldExtractRootMotion()));
	}
	else
	{
		Output.ResetToRefPose();
	}
}

void FAnimNode_AssetIDSequencePlayer::OverrideAsset(UAnimationAsset* NewAsset)
{
	if (UAnimSequenceBase* AnimSequence = Cast<UAnimSequenceBase>(NewAsset))
	{
		Sequence = AnimSequence;
	}
}

FName FAnimNode_AssetIDSequencePlayer::GetGroupName() const
{
	return GET_ANIM_NODE_DATA(FName, GroupName);
}

EAnimGroupRole::Type FAnimNode_AssetIDSequencePlayer::GetGroupRole() const
{
	return GET_ANIM_NODE_DATA(TEnumAsByte<EAnimGroupRole::Type>, GroupRole);
}

EAnimSyncMethod FAnimNode_AssetIDSequencePlayer::GetGroupMethod() const
{
	return GET_ANIM_NODE_DATA(EAnimSyncMethod, Method);
}

bool FAnimNode_AssetIDSequencePlayer::GetIgnoreForRelevancyTest() const
{
	return GET_ANIM_NODE_DATA(bool, bIgnoreForRelevancyTest);
}

bool FAnimNode_AssetIDSequencePlayer::SetGroupName(FName InGroupName)
{
#if WITH_EDITORONLY_DATA
	GroupName = InGroupName;
#endif

	if(FName* GroupNamePtr = GET_INSTANCE_ANIM_NODE_DATA_PTR(FName, GroupName))
	{
		*GroupNamePtr = InGroupName;
		return true;
	}

	return false;
}

bool FAnimNode_AssetIDSequencePlayer::SetGroupRole(EAnimGroupRole::Type InRole)
{
#if WITH_EDITORONLY_DATA
	GroupRole = InRole;
#endif

	if(TEnumAsByte<EAnimGroupRole::Type>* GroupRolePtr = GET_INSTANCE_ANIM_NODE_DATA_PTR(TEnumAsByte<EAnimGroupRole::Type>, GroupRole))
	{
		*GroupRolePtr = InRole;
		return true;
	}

	return false;
}

bool FAnimNode_AssetIDSequencePlayer::SetGroupMethod(EAnimSyncMethod InMethod)
{
#if WITH_EDITORONLY_DATA
	Method = InMethod;
#endif

	if(EAnimSyncMethod* MethodPtr = GET_INSTANCE_ANIM_NODE_DATA_PTR(EAnimSyncMethod, Method))
	{
		*MethodPtr = InMethod;
		return true;
	}

	return false;
}

bool FAnimNode_AssetIDSequencePlayer::SetIgnoreForRelevancyTest(bool bInIgnoreForRelevancyTest)
{
#if WITH_EDITORONLY_DATA
	bIgnoreForRelevancyTest = bInIgnoreForRelevancyTest;
#endif

	if(bool* bIgnoreForRelevancyTestPtr = GET_INSTANCE_ANIM_NODE_DATA_PTR(bool, bIgnoreForRelevancyTest))
	{
		*bIgnoreForRelevancyTestPtr = bInIgnoreForRelevancyTest;
		return true;
	}

	return false;
}


void FAnimNode_AssetIDSequencePlayer::GatherDebugData(FNodeDebugData& DebugData)
{
	FString DebugLine = DebugData.GetNodeName(this);

	DebugLine += FString::Printf(TEXT("('%s' Play Time: %.3f Weight: %.0f%%)"), Sequence ? *Sequence->GetName() : TEXT("NULL"), InternalTimeAccumulator, BlendWeight*100.0f);
	DebugData.AddDebugItem(DebugLine, true);
}

float FAnimNode_AssetIDSequencePlayer::GetTimeFromEnd(float CurrentNodeTime)
{
	return Sequence->GetPlayLength() - CurrentNodeTime;
}

#undef LOCTEXT_NAMESPACE