#include "3C/Animation/BaseAnimInstance.h"

#include "3C/Character/BaseCharacter.h"
#include "Animation/AnimNode_AssetPlayerBase.h"
#include "3C/Animation/AnimCommon.h"
#include "3C/Animation/AnimationGraphNode/AnimNode_AssetIDSequencePlayer.h"
#include "3C/Animation/AnimationGraphNode/AnimNode_WebSequencePlayer.h"
#include "3C/Controller/BasePlayerController.h"
#include "Misc/MathFormula.h"
#include "Animation/AnimNode_LinkedAnimLayer.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "Animation/AnimComposite.h"
#include "Kismet/KismetMathLibrary.h"
#include "Logging/LogMacros.h"
#include "3C/Util/KGUtils.h"
#include "Misc/ObjCrashCollector.h"
#include "Manager/KGCppAssetManager.h"
#include "AnimNode_KawaiiPhysicsAllInOne.h"
#include "3C/Camera/CameraManager.h"
#include "Manager/KGObjectActorManager.h"
#include "3C/Component/ProfessionalismComponent.h"
#include "Managers/KGWebAnimationManager.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "3C/Animation/ALS/ALS_MathLibrary.h"
#include "Engine/World.h"
#include "TimerManager.h"

DEFINE_LOG_CATEGORY_STATIC(UBaseAnimInstanceLog, Log, All);

//PRAGMA_DISABLE_OPTIMIZATION

/*-------------------------------------曲线配置 Start---------------------------------------------*/
// 脚步动画衔接曲线
static FName FootRatioCurveName = FName("FootCurveRatio");
// 混出时间曲线
static FName BlendOutTimeCurveName = FName("BlendOutTimeCurveValue");
// Kawaii 相关
static FName DisableKawaiiCurveName = FName("DisableKawaii");
static FName DisableKawaiiCloakCurveName = FName("DisableKawaiiCloak");
static FName DisableKawaiiSkirtCurveName = FName("DisableKawaiiSkirt");
// Ik 相关
static FName EnableLHandIKCurveName = FName("EnableLHandIK");
static FName EnableRHandIKCurveName = FName("EnableRHandIK");
static FName EnableLFootIKCurveName = FName("EnableLFootIK");
static FName EnableRFootIKCurveName = FName("EnableRFootIK");
static FName DisableLHandIKCurveName = FName("DisableLHandIK");
static FName DisableRHandIKCurveName = FName("DisableRHandIK");
static FName DisableLFootIKCurveName = FName("DisableLFootIK");
static FName DisableRFootIKCurveName = FName("DisableRFootIK");
// 手臂叠加曲线
static FName DisableArmAdditiveCurveName = FName("DisableArmAdditive");

static FName EnableIK_FootL_CurveName = FName("EnableIK_FootL");
static FName EnableIK_FootR_CurveName = FName("EnableIK_FootR");
// 眼皮相关
static FName EyeIKCurveCurveName = FName("EyeIKCurve");
// LookAt 禁用曲线
static FName DisableLookAtCurveName = FName("DisableLookAt");
/*-------------------------------------曲线配置 End---------------------------------------------*/

TMap<uint8, FName> UBaseAnimInstance::StateTypeToStateNameMap;
TMap<FName, uint8> UBaseAnimInstance::StateNameToStateTypeMap;
TMap<FString, FName> UBaseAnimInstance::ClothingToKawaiiMap;
TMap<FString, TArray<FName>> UBaseAnimInstance::ClothingToKawaiiNodeMap;

bool UBaseAnimInstance::bIsLocomotionStateTypeMapsInitialized = false;
bool UBaseAnimInstance::bIsClothingToKawaiiMapInitialized = false;
bool UBaseAnimInstance::bAnimSkeletonCheck = false;
bool UBaseAnimInstance::bAnimSkeletonSlotCheck = false;

UBaseAnimInstance::UBaseAnimInstance(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer), bEnableCacheAttributeCurve(false)
{
	bIsClothingToKawaiiMapInitialized = false;
	InitBaseAnimInstanceParam();
}

#pragma region ALS_C++
static const FName NAME_BasePose_CLF(TEXT("BasePose_CLF"));
static const FName NAME_BasePose_N(TEXT("BasePose_N"));
static const FName NAME_Enable_FootIK_R(TEXT("Enable_FootIK_R"));
static const FName NAME_Enable_FootIK_L(TEXT("Enable_FootIK_L"));
static const FName NAME_Enable_HandIK_L(TEXT("Enable_HandIK_L"));
static const FName NAME_Enable_HandIK_R(TEXT("Enable_HandIK_R"));
static const FName NAME_Enable_Transition(TEXT("Enable_Transition"));
static const FName NAME_FootLock_L(TEXT("FootLock_L"));
static const FName NAME_FootLock_R(TEXT("FootLock_R"));
static const FName NAME_Grounded___Slot(TEXT("Grounded Slot"));
static const FName NAME_Layering_Arm_L(TEXT("Layering_Arm_L"));
static const FName NAME_Layering_Arm_L_Add(TEXT("Layering_Arm_L_Add"));
static const FName NAME_Layering_Arm_L_LS(TEXT("Layering_Arm_L_LS"));
static const FName NAME_Layering_Arm_R(TEXT("Layering_Arm_R"));
static const FName NAME_Layering_Arm_R_Add(TEXT("Layering_Arm_R_Add"));
static const FName NAME_Layering_Arm_R_LS(TEXT("Layering_Arm_R_LS"));
static const FName NAME_Layering_Hand_L(TEXT("Layering_Hand_L"));
static const FName NAME_Layering_Hand_R(TEXT("Layering_Hand_R"));
static const FName NAME_Layering_Head_Add(TEXT("Layering_Head_Add"));
static const FName NAME_Layering_Spine_Add(TEXT("Layering_Spine_Add"));
static const FName NAME_Mask_AimOffset(TEXT("Mask_AimOffset"));
static const FName NAME_Mask_LandPrediction(TEXT("Mask_LandPrediction"));
static const FName NAME__ALSCharacterAnimInstance__RotationAmount(TEXT("RotationAmount"));
static const FName NAME_VB___foot_target_l(TEXT("VB foot_target_l"));
static const FName NAME_VB___foot_target_r(TEXT("VB foot_target_r"));
static const FName NAME_W_Gait(TEXT("Weight_Gait"));
static const FName NAME__ALSCharacterAnimInstance__root(TEXT("root"));

static const FName NAME__CanRotateInPlace__CheckMontagePlayingSlot(TEXT("(N) Turn/Rotate"));
static const FName NAME__CanRotateInPlace__CheckCurveName(TEXT("RotateLRState"));
static const FName IkFootL_BoneName = FName(TEXT("ik_foot_l"));
static const FName IkFootR_BoneName = FName(TEXT("ik_foot_r"));

// ALS 原地转身相关
static FName ALSTurn90IPLeftCurveName = FName("ALSTurnLeft90InPlace");
static FName ALSTurn90IPRightCurveName = FName("ALSTurnRight90InPlace");
static FName ALSTurn180IPLeftCurveName = FName("ALSTurnLeft180InPlace");
static FName ALSTurn180IPRightCurveName = FName("ALSTurnRight180InPlace");
// ---------------------------ALS ----------------------------------------
static FName NAME_Enable_FootIK_R_CurveName = (TEXT("Enable_FootIK_R"));
static FName NAME_Enable_FootIK_L_CurveName = (TEXT("Enable_FootIK_L"));
static FName NAME_Enable_HandIK_L_CurveName = (TEXT("Enable_HandIK_L"));
static FName NAME_Enable_HandIK_R_CurveName = (TEXT("Enable_HandIK_R"));
static FName NAME_FootLock_L_CurveName = (TEXT("FootLock_L"));
static FName NAME_FootLock_R_CurveName = (TEXT("FootLock_R"));
// ---------------------------ALS END------------------------------------

void UBaseAnimInstance::NativeInitializeAnimation()
{
	Super::NativeInitializeAnimation();
	OwnerCharacter = Cast<ABaseCharacter>(TryGetPawnOwner());
}

void UBaseAnimInstance::ALS_NativeUpdateAnimation(float DeltaSeconds)
{
	if (!IsValid(OwnerCharacter) || DeltaSeconds == 0.0f)
	{
		return;
	}

	const bool bPrevShouldMove = bShouldMove;
	// Update rest of character information. Others are reflected into anim bp when they're set inside character class
	MovementState = IsGrounded ? EALS_MovementState::Grounded : EALS_MovementState::InAir;
	// Stance = EALS_Stance::Standing;
	// ViewMode = EALS_ViewMode::ThirdPerson;

	// 保持和ALS原生一样的顺序
	ALS_CalculateAimingValues(DeltaSeconds);
	ALS_UpdateLayerValues();
	if (URoleMovementComponent* RoleMoveComp = OwnerCharacter->GetComponentByClass<URoleMovementComponent>())
	{
		ALS_RotationMode = RoleMoveComp->ALS_RotationMode;
		UpdateALSData(*RoleMoveComp, DeltaSeconds);
	}

	if (bShouldMove)
	{
		if (bPrevShouldMove == false)
		{
			// Do When Starting To Move
			TurnInPlaceValues.ElapsedDelayTime = 0.0f;
			bRotateL = false;
			bRotateR = false;
		}
		// Do While Moving
		ALS_UpdateMovementValues(DeltaSeconds);
		ALS_UpdateRotationValues();
	}
	else
	{
		// Do While Not Moving
		if (ALS_CanRotateInPlace())
		{
			ALS_RotateInPlaceCheck();
		}
		else
		{
			bRotateL = false;
			bRotateR = false;
		}
		if (ALS_CanTurnInPlace())
		{
			ALS_TurnInPlaceCheck(DeltaSeconds);
		}
		else
		{
			TurnInPlaceValues.ElapsedDelayTime = 0.0f;
		}
		if (ALS_CanDynamicTransition())
		{
			ALS_DynamicTransitionCheck();
		}
	}
}

void UBaseAnimInstance::ALS_UpdateLayerValues()
{
	// Get the Aim Offset weight by getting the opposite of the Aim Offset Mask.
	LayerBlendingValues.EnableAimOffset = FMath::Lerp(1.0f, 0.0f, GetCurveValue(NAME_Mask_AimOffset));
	// Set the Base Pose weights
	LayerBlendingValues.BasePose_N = GetCurveValue(NAME_BasePose_N);
	LayerBlendingValues.BasePose_CLF = GetCurveValue(NAME_BasePose_CLF);
	// Set the Additive amount weights for each body part
	LayerBlendingValues.Spine_Add = GetCurveValue(NAME_Layering_Spine_Add);
	LayerBlendingValues.Head_Add = GetCurveValue(NAME_Layering_Head_Add);
	LayerBlendingValues.Arm_L_Add = GetCurveValue(NAME_Layering_Arm_L_Add);
	LayerBlendingValues.Arm_R_Add = GetCurveValue(NAME_Layering_Arm_R_Add);
	// Set the Hand Override weights
	LayerBlendingValues.Hand_R = GetCurveValue(NAME_Layering_Hand_R);
	LayerBlendingValues.Hand_L = GetCurveValue(NAME_Layering_Hand_L);
	// Blend and set the Hand IK weights to ensure they only are weighted if allowed by the Arm layers.
	LayerBlendingValues.EnableHandIK_L = FMath::Lerp(0.0f, GetCurveValue(NAME_Enable_HandIK_L),
		GetCurveValue(NAME_Layering_Arm_L));
	LayerBlendingValues.EnableHandIK_R = FMath::Lerp(0.0f, GetCurveValue(NAME_Enable_HandIK_R),
		GetCurveValue(NAME_Layering_Arm_R));
	// Set whether the arms should blend in mesh space or local space.
	// The Mesh space weight will always be 1 unless the Local Space (LS) curve is fully weighted.
	LayerBlendingValues.Arm_L_LS = GetCurveValue(NAME_Layering_Arm_L_LS);
	LayerBlendingValues.Arm_L_MS = static_cast<float>(1 - FMath::FloorToInt(LayerBlendingValues.Arm_L_LS));
	LayerBlendingValues.Arm_R_LS = GetCurveValue(NAME_Layering_Arm_R_LS);
	LayerBlendingValues.Arm_R_MS = static_cast<float>(1 - FMath::FloorToInt(LayerBlendingValues.Arm_R_LS));
}

void UBaseAnimInstance::ALS_UpdateMovementValues(float DeltaSeconds)
{
	// Interp and set the Velocity Blend.
	const FALS_VelocityBlend& TargetBlend = ALS_CalculateVelocityBlend();
	VelocityBlend.F = FMath::FInterpTo(VelocityBlend.F, TargetBlend.F, DeltaSeconds, Config.VelocityBlendInterpSpeed);
	VelocityBlend.B = FMath::FInterpTo(VelocityBlend.B, TargetBlend.B, DeltaSeconds, Config.VelocityBlendInterpSpeed);
	VelocityBlend.L = FMath::FInterpTo(VelocityBlend.L, TargetBlend.L, DeltaSeconds, Config.VelocityBlendInterpSpeed);
	VelocityBlend.R = FMath::FInterpTo(VelocityBlend.R, TargetBlend.R, DeltaSeconds, Config.VelocityBlendInterpSpeed);

	// Set the Diagonal Scale Amount.
	DiagonalScaleAmount = ALS_CalculateDiagonalScaleAmount();

	// Set the Relative Acceleration Amount and Interp the Lean Amount.
	RelativeAccelerationAmount = ALS_CalculateRelativeAccelerationAmount();
	LeanAmount.LR = FMath::FInterpTo(LeanAmount.LR, RelativeAccelerationAmount.Y, DeltaSeconds,
		Config.GroundedLeanInterpSpeed);
	LeanAmount.FB = FMath::FInterpTo(LeanAmount.FB, RelativeAccelerationAmount.X, DeltaSeconds,
		Config.GroundedLeanInterpSpeed);
	
	// Set the Walk Run Blend
	WalkRunBlend = ALS_CalculateWalkRunBlend();

	// Set the Stride Blend
	StrideBlend = ALS_CalculateStrideBlend();

	// Set the Standing and Crouching Play Rates
	StandingPlayRate = ALS_CalculateStandingPlayRate();
}

void UBaseAnimInstance::ALS_UpdateRotationValues()
{
	// Set the Movement Direction
	MovementDirection = ALS_CalculateMovementDirection();
	IsForwardMovementDirection = MovementDirection == EALS_MovementDirection::Forward;
	IsBackwardMovementDirection = MovementDirection == EALS_MovementDirection::Backward;
	IsLeftMovementDirection = MovementDirection == EALS_MovementDirection::Left;
	IsRightMovementDirection = MovementDirection == EALS_MovementDirection::Right;

	if (!IsValid(YawOffset_FB) || !IsValid(YawOffset_LR)) {
		UE_LOG(LogTemp, Warning, TEXT("InValid YawOffset_FB or YawOffset_LR Curve! Use Latest ALS ABP & C++ Version Please!"));
		return;
	}
	// Set the Yaw Offsets. These values influence the "YawOffset" curve in the AnimGraph and are used to offset
	// the characters rotation for more natural movement. The curves allow for fine control over how the offset
	// behaves for each movement direction.
	FRotator Delta = MovementVelocity.ToOrientationRotator() - AimingRotation;
	Delta.Normalize();
	const FVector& FBOffset = YawOffset_FB->GetVectorValue(Delta.Yaw);
	FYaw = FBOffset.X;
	BYaw = FBOffset.Y;
	const FVector& LROffset = YawOffset_LR->GetVectorValue(Delta.Yaw);
	LYaw = LROffset.X;
	RYaw = LROffset.Y;
}

FALS_VelocityBlend UBaseAnimInstance::ALS_CalculateVelocityBlend() const
{
	// Calculate the Velocity Blend. This value represents the velocity amount of the actor in each direction (normalized so that
	// diagonals equal .5 for each direction), and is used in a BlendMulti node to produce better
	// directional blending than a standard blendspace.
	const FVector LocRelativeVelocityDir =
		ViewActorTransform.GetRotation().UnrotateVector(MovementVelocity.GetSafeNormal(0.1f));
	const float Sum = FMath::Abs(LocRelativeVelocityDir.X) + FMath::Abs(LocRelativeVelocityDir.Y) +
		FMath::Abs(LocRelativeVelocityDir.Z);
	const FVector RelativeDir = LocRelativeVelocityDir / Sum;
	FALS_VelocityBlend Result;
	Result.F = FMath::Clamp(RelativeDir.X, 0.0f, 1.0f);
	Result.B = FMath::Abs(FMath::Clamp(RelativeDir.X, -1.0f, 0.0f));
	Result.L = FMath::Abs(FMath::Clamp(RelativeDir.Y, -1.0f, 0.0f));
	Result.R = FMath::Clamp(RelativeDir.Y, 0.0f, 1.0f);
	return Result;
}

float UBaseAnimInstance::ALS_CalculateDiagonalScaleAmount() const
{
	// Calculate the Diagonal Scale Amount. This value is used to scale the Foot IK Root bone to make the Foot IK bones
	// cover more distance on the diagonal blends. Without scaling, the feet would not move far enough on the diagonal
	// direction due to the linear translational blending of the IK bones. The curve is used to easily map the value.
	if (!IsValid(DiagonalScaleAmountCurve)) {
		UE_LOG(LogTemp, Warning, TEXT("InValid DiagonalScaleAmountCurve! Use Latest ALS ABP & C++ Version Please!"));
		return 0.0f;
	}
	return DiagonalScaleAmountCurve->GetFloatValue(FMath::Abs(VelocityBlend.F + VelocityBlend.B));
}

FVector UBaseAnimInstance::ALS_CalculateRelativeAccelerationAmount() const
{
	// Calculate the Relative Acceleration Amount. This value represents the current amount of acceleration / deceleration
	// relative to the actor rotation. It is normalized to a range of -1 to 1 so that -1 equals the Max Braking Deceleration,
	// and 1 equals the Max Acceleration of the Character Movement Component.
	if (FVector::DotProduct(MovementAcceleration, MovementVelocity) > 0.0f)
	{
		// 处理除以0的情况，Add By szk
		if (MovementMaxAcceleration <= 0.0f) {
			return FVector::ZeroVector;
		}

		return ViewActorTransform.GetRotation().UnrotateVector(
			MovementAcceleration.GetClampedToMaxSize(MovementMaxAcceleration) / MovementMaxAcceleration);
	}

	// 处理除以0的情况，Add By szk
	if (MovementMaxDeceleration <= 0.0f) {
		return FVector::ZeroVector;
	}
	return ViewActorTransform.GetRotation().UnrotateVector(
		MovementAcceleration.GetClampedToMaxSize(MovementMaxDeceleration) / MovementMaxDeceleration);
}

float UBaseAnimInstance::ALS_CalculateStrideBlend() const
{
	if (!IsValid(StrideBlend_N_Walk) || !IsValid(StrideBlend_N_Run)) {
		UE_LOG(LogTemp, Warning, TEXT("InValid StrideBlend_N_Walk or StrideBlend_N_Run Curve! Use Latest ALS ABP & C++ Version Please!"));
		return 0.0f;
	}
	// Calculate the Stride Blend. This value is used within the blendspaces to scale the stride (distance feet travel)
	// so that the character can walk or run at different movement speeds.
	// It also allows the walk or run gait animations to blend independently while still matching the animation speed to
	// the movement speed, preventing the character from needing to play a half walk+half run blend.
	// The curves are used to map the stride amount to the speed for maximum control.
	const float CurveTime = VelocityXY / GetOwningComponent()->GetComponentScale().Z;
	const float ClampedGait = GetAnimCurveClamped(NAME_W_Gait, -1.0, 0.0f, 1.0f);
	//const float LerpedStrideBlend =
	return FMath::Lerp(StrideBlend_N_Walk->GetFloatValue(CurveTime), StrideBlend_N_Run->GetFloatValue(CurveTime),
			ClampedGait);
	//return FMath::Lerp(LerpedStrideBlend, StrideBlend_C_Walk->GetFloatValue(VelocityXY),
	//	GetCurveValue(NAME_BasePose_CLF));
}

float UBaseAnimInstance::ALS_CalculateWalkRunBlend() const
{
	return ALSMovePosture == 1 ? 0.0f : 1.0f;
}

float UBaseAnimInstance::ALS_CalculateStandingPlayRate() const
{
	// Calculate the Play Rate by dividing the Character's speed by the Animated Speed for each gait.
	// The lerps are determined by the "W_Gait" anim curve that exists on every locomotion cycle so
	// that the play rate is always in sync with the currently blended animation.
	// The value is also divided by the Stride Blend and the mesh scale so that the play rate increases as the stride or scale gets smaller
	const float LerpedSpeed = FMath::Lerp(VelocityXY / Config.AnimatedWalkSpeed,
		VelocityXY / Config.AnimatedRunSpeed,
		GetAnimCurveClamped(NAME_W_Gait, -1.0f, 0.0f, 1.0f));

	const float SprintAffectedSpeed = FMath::Lerp(LerpedSpeed, VelocityXY / Config.AnimatedSprintSpeed,
		GetAnimCurveClamped(NAME_W_Gait, -2.0f, 0.0f, 1.0f));

	return FMath::Clamp((SprintAffectedSpeed / StrideBlend) / GetOwningComponent()->GetComponentScale().Z,
		0.0f, 3.0f);
}

float UBaseAnimInstance::GetAnimCurveClamped(const FName& Name, float Bias, float ClampMin, float ClampMax) const
{
	return FMath::Clamp(GetCurveValue(Name) + Bias, ClampMin, ClampMax);
}

EALS_MovementDirection UBaseAnimInstance::ALS_CalculateMovementDirection() const
{
	// Calculate the Movement Direction. This value represents the direction the character is moving relative to the camera
	// during the Looking Direction / Aiming rotation modes, and is used in the Cycle Blending Anim Layers to blend to the
	// appropriate directional states.
	if (ALSMovePosture == 2 || ALS_RotationMode == EALS_RotationMode::VelocityDirection)
	{
		return EALS_MovementDirection::Forward;
	}

	FRotator Delta = MovementVelocity.ToOrientationRotator() - AimingRotation;
	Delta.Normalize();
	return UALS_MathLibrary::CalculateQuadrant(MovementDirection, 70.0f, -70.0f, 110.0f, -110.0f, 5.0f, Delta.Yaw);
}

bool UBaseAnimInstance::ALS_CanRotateInPlace() const
{
	return ALS_RotationMode == EALS_RotationMode::Aiming && 
		!IsSlotMontagePlaying(NAME__CanRotateInPlace__CheckMontagePlayingSlot) && 
		GetCurveValue(NAME__CanRotateInPlace__CheckCurveName) < 0.01;
}

void UBaseAnimInstance::ALS_RotateInPlaceCheck()
{
	// Step 1: Check if the character should rotate left or right by checking if the Aiming Angle exceeds the threshold.
	bRotateL = AimingAngle.X < RotateInPlace.RotateMinThreshold;
	bRotateR = AimingAngle.X > RotateInPlace.RotateMaxThreshold;

	// Step 2: If the character should be rotating, set the Rotate Rate to scale with the Aim Yaw Rate.
	// This makes the character rotate faster when moving the camera faster.
	// 这里的RotateRate没有使用，不再计算
	//if (bRotateL || bRotateR)
	//{
	//	RotateRate = FMath::GetMappedRangeValueClamped<float, float>(
	//		{ RotateInPlace.AimYawRateMinRange, RotateInPlace.AimYawRateMaxRange },
	//		{ RotateInPlace.MinPlayRate, RotateInPlace.MaxPlayRate },
	//		AimYawRate);
	//}
}

bool UBaseAnimInstance::ALS_CanTurnInPlace() const
{
	return ALS_RotationMode == EALS_RotationMode::LookingDirection &&
		ViewMode == EALS_ViewMode::ThirdPerson &&
		GetCurveValue(NAME_Enable_Transition) >= 0.99f &&
		!bIsLockingTarget;
}

void UBaseAnimInstance::ALS_TurnInPlaceCheck(float DeltaSeconds)
{
	// Step 1: Check if Aiming angle is outside of the Turn Check Min Angle, and if the Aim Yaw Rate is below the Aim Yaw Rate Limit.
	// If so, begin counting the Elapsed Delay Time. If not, reset the Elapsed Delay Time.
	// This ensures the conditions remain true for a sustained period of time before turning in place.
	if (FMath::Abs(AimingAngle.X) <= TurnInPlaceValues.TurnCheckMinAngle ||
		AimYawRate >= TurnInPlaceValues.AimYawRateLimit)
	{
		TurnInPlaceValues.ElapsedDelayTime = 0.0f;
		return;
	}

	TurnInPlaceValues.ElapsedDelayTime += DeltaSeconds;
	const float ClampedAimAngle = FMath::GetMappedRangeValueClamped<float, float>({ TurnInPlaceValues.TurnCheckMinAngle, 180.0f },
																	{
																		TurnInPlaceValues.MinAngleDelay,
																		TurnInPlaceValues.MaxAngleDelay
																	},
		//AimingAngle.X);
		// 原动画蓝图这里额外取绝对值，保留一致
		FMath::Abs(AimingAngle.X));

	// Step 2: Check if the Elapsed Delay time exceeds the set delay (mapped to the turn angle range). If so, trigger a Turn In Place.
	if (TurnInPlaceValues.ElapsedDelayTime > ClampedAimAngle)
	{
		FRotator TurnInPlaceYawRot = AimingRotation;
		TurnInPlaceYawRot.Roll = 0.0f;
		TurnInPlaceYawRot.Pitch = 0.0f;
		ALS_TurnInPlace(TurnInPlaceYawRot, 1.0f, 0.0f, false);
	}
}

void UBaseAnimInstance::ALS_TurnInPlace(FRotator TargetRotation, float PlayRateScale, float StartTime, bool OverrideCurrent)
{
	// Step 1: Set Turn Angle
	FRotator Delta = TargetRotation - ViewActorTransform.GetRotation().Rotator();
	Delta.Normalize();
	const float TurnAngle = Delta.Yaw;

	// Step 2: Choose Turn Asset based on the Turn Angle and Stance
	FALS_TurnInPlaceAsset TargetTurnAsset;
	if (FMath::Abs(TurnAngle) < TurnInPlaceValues.Turn180Threshold)
	{
		if (TurnAngle < 0)
		{
			TargetTurnAsset = IsMaleSex
				? TurnInPlaceValues.N_TurnIP_L90
				: TurnInPlaceValues.F_N_TurnIP_L90;
		}
		else
		{
			TargetTurnAsset = IsMaleSex
				? TurnInPlaceValues.N_TurnIP_R90
				: TurnInPlaceValues.F_N_TurnIP_R90;
		}
	}
	else
	{
		if (TurnAngle < 0)
		{
			TargetTurnAsset = IsMaleSex
				? TurnInPlaceValues.N_TurnIP_L180
				: TurnInPlaceValues.F_N_TurnIP_L180;
		}
		else
		{
			TargetTurnAsset = IsMaleSex
				? TurnInPlaceValues.N_TurnIP_R180
				: TurnInPlaceValues.F_N_TurnIP_R180;
		}
	}

	// Step 3: If the Target Turn Animation is not playing or set to be overriden, play the turn animation as a dynamic montage.
	if (!OverrideCurrent && IsPlayingSlotAnimation(TargetTurnAsset.Animation, TargetTurnAsset.SlotName))
	{
		return;
	}
	PlaySlotAnimationAsDynamicMontage(TargetTurnAsset.Animation, TargetTurnAsset.SlotName, 0.2f, 0.2f,
		TargetTurnAsset.PlayRate * PlayRateScale, 1, 0.0f, StartTime);

	// Step 4: Scale the rotation amount (gets scaled in AnimGraph) to compensate for turn angle (If Allowed) and play rate.
	// 使用C7motionwarp 就不需要控制速率了。 后续旋转计算也不需要
	//if (TargetTurnAsset.ScaleTurnAngle)
	//{
	//	Grounded.RotationScale = (TurnAngle / TargetTurnAsset.AnimatedAngle) * TargetTurnAsset.PlayRate * PlayRateScale;
	//}
	//else
	//{
	//	Grounded.RotationScale = TargetTurnAsset.PlayRate * PlayRateScale;
	//}
}

bool UBaseAnimInstance::ALS_CanDynamicTransition() const
{
	return GetCurveValue(NAME_Enable_Transition) >= 0.99f;
}

void UBaseAnimInstance::ALS_DynamicTransitionCheck()
{
	// Check each foot to see if the location difference between the IK_Foot bone and its desired / target location
	// (determined via a virtual bone) exceeds a threshold. If it does, play an additive transition animation on that foot.
	// The currently set transition plays the second half of a 2 foot transition animation, so that only a single foot moves.
	// Because only the IK_Foot bone can be locked, the separate virtual bone allows the system to know its desired location when locked.
	FTransform SocketTransformA = GetOwningComponent()->GetSocketTransform(IkFootL_BoneName, RTS_Component);
	FTransform SocketTransformB = GetOwningComponent()->GetSocketTransform(
		NAME_VB___foot_target_l, RTS_Component);
	float Distance = (SocketTransformB.GetLocation() - SocketTransformA.GetLocation()).Size();
	if (Distance > Config.DynamicTransitionThreshold)
	{
		FALS_DynamicMontageParams Params;
		Params.Animation = IsMaleSex ? TransitionAnim_R : F_TransitionAnim_R;
		Params.BlendInTime = 0.2f;
		Params.BlendOutTime = 0.2f;
		Params.PlayRate = 1.5f;
		Params.StartTime = 0.8f;
		ALS_PlayDynamicTransition(0.1f, Params);
	}

	SocketTransformA = GetOwningComponent()->GetSocketTransform(IkFootR_BoneName, RTS_Component);
	SocketTransformB = GetOwningComponent()->GetSocketTransform(NAME_VB___foot_target_r, RTS_Component);
	Distance = (SocketTransformB.GetLocation() - SocketTransformA.GetLocation()).Size();
	if (Distance > Config.DynamicTransitionThreshold)
	{
		FALS_DynamicMontageParams Params;
		Params.Animation = IsMaleSex ? TransitionAnim_L : F_TransitionAnim_L;
		Params.BlendInTime = 0.2f;
		Params.BlendOutTime = 0.2f;
		Params.PlayRate = 1.5f;
		Params.StartTime = 0.8f;
		ALS_PlayDynamicTransition(0.1f, Params);
	}
}

void UBaseAnimInstance::ALS_PlayDynamicTransition(float ReTriggerDelay, FALS_DynamicMontageParams Parameters)
{
	if (bIsInStopTransitionCoolDown)
	{
		return;
	}

	if (bCanPlayDynamicTransition)
	{
		bCanPlayDynamicTransition = false;

		// Play Dynamic Additive Transition Animation
		ALS_PlayTransition(Parameters);

		UWorld* World = GetWorld();
		check(World);
		World->GetTimerManager().SetTimer(PlayDynamicTransitionTimer, this,
			&UBaseAnimInstance::ALS_PlayDynamicTransitionDelay,
			ReTriggerDelay, false);
	}
}

void UBaseAnimInstance::ALS_PlayTransition(const FALS_DynamicMontageParams& Parameters)
{
	if (bIsInStopTransitionCoolDown)
	{
		return;
	}

	PlaySlotAnimationAsDynamicMontage(Parameters.Animation, NAME_Grounded___Slot,
		Parameters.BlendInTime, Parameters.BlendOutTime, Parameters.PlayRate, 1,
		0.0f, Parameters.StartTime);
}

void UBaseAnimInstance::ALS_PlayTransitionChecked(const FALS_DynamicMontageParams& Parameters)
{
	if (Stance == EALS_Stance::Standing && !bShouldMove)
	{
		ALS_PlayTransition(Parameters);
	}
}

void UBaseAnimInstance::ALS_PlayDynamicTransitionDelay()
{
	bCanPlayDynamicTransition = true;
}
#pragma endregion ALS_C++

void UBaseAnimInstance::Montage_SetBlendTime(UAnimMontage* InMontage, float BlendIn, float BlendOut, bool bEnableAutoBlendOut, float BlendOutTriggerTime)
{
	if (InMontage)
	{
		InMontage->BlendIn.SetBlendTime(BlendIn);
		InMontage->BlendOut.SetBlendTime(BlendOut);
		InMontage->bEnableAutoBlendOut = bEnableAutoBlendOut;
		InMontage->BlendOutTriggerTime = BlendOutTriggerTime;
	}
}

void UBaseAnimInstance::Montage_SetBlendOption(UAnimMontage* InMontage, FAlphaBlend BlendIn, FAlphaBlend BlendOut, bool bEnableAutoBlendOut)
{
	if (InMontage)
	{
		InMontage->BlendIn = BlendIn;
		InMontage->BlendOut = BlendOut;
		InMontage->bEnableAutoBlendOut = bEnableAutoBlendOut;
	}
}

void UBaseAnimInstance::SetBoneTrackActorInfo(FName BoneName, KGObjectID TargetActorID, float Speed, FVector LocketOffset, float InTrackDuration)
{
	BoneTrackActorMap.Add(BoneName, FBoneTrackActorInfo(TargetActorID, Speed, LocketOffset, InTrackDuration));
	TargetBoneTranslationMap.Add(BoneName, FVector::ZeroVector);
	TargetBoneRotMap.Add(BoneName, FRotator::ZeroRotator);
	TargetBoneScaleMap.Add(BoneName, FVector::ZeroVector);
	BoneStartPosMap.Add(BoneName, GetOwningComponent()->GetBoneLocation(BoneName, EBoneSpaces::WorldSpace));
	UpdateTrackActorBoneTransform(0.0);
}

void UBaseAnimInstance::DelBoneTrackActorInfo(FName BoneName, bool bDelAll)
{
	if (bDelAll)
	{
		BoneTrackActorMap.Empty();
		TargetBoneTranslationMap.Empty();
		TargetBoneRotMap.Empty();
		TargetBoneScaleMap.Empty();

		for (auto& TrackInfo : BoneTrackActorMap)
		{
			RemoveModifyBone(TrackInfo.Key);
		}
	}
	else
	{
		BoneTrackActorMap.Remove(BoneName);
		TargetBoneTranslationMap.Remove(BoneName);
		TargetBoneRotMap.Remove(BoneName);
		TargetBoneScaleMap.Remove(BoneName);
		RemoveModifyBone(BoneName);
	}
}


void UBaseAnimInstance::UpdateTrackActorBoneTransform(float DeltaSeconds)
{
	for (auto& TrackInfo : BoneTrackActorMap)
	{
		FBoneTrackActorInfo TrackActorInfo = TrackInfo.Value;
		if (TrackActorInfo.TrackDuration < TrackActorInfo.RunningDuration)
		{
			continue;
		}

		AActor* TargetActor = Cast<AActor>(KGUtils::GetObjectByID(TrackActorInfo.TrackedActorID));
		if (!TargetActor)
		{
			continue;
		}

		FName BoneName = TrackInfo.Key;
		BoneTrackActorMap[BoneName].RunningDuration += DeltaSeconds;
		USkeletalMeshComponent* OwnerComp = GetSkelMeshComponent();
		//FVector BoneCurPos = OwnerComp->GetBoneLocation(BoneName, EBoneSpaces::WorldSpace);
		FVector BoneStartPos = BoneStartPosMap[BoneName];

		FVector TargetActorPos = TargetActor->GetActorLocation() + TrackActorInfo.TargetPosOffset;
		FVector Dir = TargetActorPos - BoneStartPos;
		Dir = Dir.GetSafeNormal();
		if (!Dir.IsNearlyZero())
		{
			if ((Dir * TrackActorInfo.Speed * BoneTrackActorMap[BoneName].RunningDuration).Length() >= (TargetActorPos - BoneStartPos).Length())
			{
				TargetBoneTranslationMap[BoneName] = TargetActorPos;
			}
			else
			{
				TargetBoneTranslationMap[BoneName] = BoneStartPos + Dir * TrackActorInfo.Speed * BoneTrackActorMap[BoneName].RunningDuration;
			}
			TargetBoneRotMap[BoneName] = Dir.Rotation();
		}
		TargetBoneScaleMap[BoneName] = OwnerComp->GetBoneTransform(BoneName).GetScale3D();
		
		FVector NewPosition = TargetBoneTranslationMap[BoneName] - BoneStartPosMap[BoneName];
		FRotator CurRotation = GetOwningActor() ? GetOwningActor()->GetActorRotation() : FRotator::ZeroRotator;
		FRotator NewRotation = TargetBoneRotMap[BoneName] - CurRotation;
		UpdateModifyBoneAutoAdd(BoneName, EC7BoneModificationMode::BMM_Additive, EC7BoneModificationMode::BMM_Additive, EC7BoneModificationMode::BMM_Ignore, EBoneControlSpace::BCS_WorldSpace,
			NewPosition.X, NewPosition.Y, NewPosition.Z, 0.f, NewRotation.Yaw, NewRotation.Roll, 1.f, 1.f, 1.f, NAME_None, 1.f, 1.f);
	}
}


void UBaseAnimInstance::GetLocoAnimRootMotionInfo(FName LocoAnimName, float StartTime, float SampleTime, float & DurationOut, float & DistanceOut, float & YawDiffOut)
{
	DurationOut = 0;
	DistanceOut = 0;
	YawDiffOut = 0;

	if(!FinalLocoAnimAssets.Contains(LocoAnimName))
	{
		return;
	}
	
	UAnimSequenceBase * AnimSeqBase = FinalLocoAnimAssets[LocoAnimName];
	DurationOut = AnimSeqBase->GetPlayLength();

	if(SampleTime < 0 || SampleTime > DurationOut){
		SampleTime = DurationOut;
	}


	FTransform TotalRootDelta = AnimSeqBase->ExtractRootMotionFromRange(StartTime, SampleTime);
	DistanceOut = TotalRootDelta.GetTranslation().Length();
	YawDiffOut = TotalRootDelta.GetRotation().Rotator().Yaw;
	
	return;
}

FTransform UBaseAnimInstance::GetLocoAnimRootMotion(FName LocoAnimName, float StartTime, float DeltaTime, bool AllowLoop)
{
	if(!FinalLocoAnimAssets.Contains(LocoAnimName))
	{
		return {};
	}

	UAnimSequenceBase * AnimSeqBase = FinalLocoAnimAssets[LocoAnimName];

	float AnimLength = AnimSeqBase->GetPlayLength();
	StartTime = FMath::Fmod(StartTime, AnimLength);
	
	return AnimSeqBase->ExtractRootMotion(StartTime, DeltaTime, AllowLoop);
}

float UBaseAnimInstance::CalculateLoopToEndTimeWithDistance(FName LStartName, FName RStartName, FName LoopName, FName LEndName, FName REndName, float TotalSplineLength, float MapInX, float MapInY, float MapOutX, float MapOutY,
	int LStartEnterLoopFrame, int RStartEnterLoopFrame, float& OutLoopMoveDuration, float& OutEndStartTime, float& OutTotalTime, float &OutStartDuration, FName &OutStartName, FName& OutEndAnimName)
{
	if (!FinalLocoAnimAssets.Contains(LStartName) || !FinalLocoAnimAssets.Contains(RStartName) || !FinalLocoAnimAssets.Contains(LoopName))
	{
		return -1;
	}
	
	UAnimSequenceBase* LStartAnimSeqBase = FinalLocoAnimAssets[LStartName];
	UAnimSequenceBase* RStartAnimSeqBase = FinalLocoAnimAssets[RStartName];
	UAnimSequenceBase* LoopAnimSeqBase = FinalLocoAnimAssets[LoopName];
	
	if (!LStartAnimSeqBase || !RStartAnimSeqBase || !LoopAnimSeqBase) return -1;
	
	float LoopDuration = 0;
	float LoopDistance = 0;
	float LoopYawDiff = 0;
	
	// Loop 原始动画数据
	GetLocoAnimRootMotionInfo(LoopName, 0, -1, LoopDuration, LoopDistance, LoopYawDiff);
	
	// 左脚起步最小停步距离计算
	float LStartDuration = 0.f, LLoopDuration = 0.f, LEndStartTime = 0.f, LLoopStartTime = 0.f;
	float RStartDuration = 0.f, RLoopDuration = 0.f, REndStartTime = 0.f, RLoopStartTime = 0.f;
	FName LOutAnimName, ROutAnimName;
	int LOutFrame = 0, ROutFrame = 0;
	
	float LMinDistance = CalculateLoopToEndOptimisationDistance(LStartName, LoopName, LEndName, REndName, TotalSplineLength, MapInX, MapInY, MapOutX, MapOutY, LStartEnterLoopFrame,
		LStartDuration, LLoopDuration,  LEndStartTime, LOutAnimName, LOutFrame, LLoopStartTime);

	// 右脚起步最小停步距离计算
	float RMinDistance = CalculateLoopToEndOptimisationDistance(RStartName, LoopName, LEndName, REndName, TotalSplineLength, MapInX, MapInY, MapOutX, MapOutY, RStartEnterLoopFrame,
	RStartDuration, RLoopDuration,  REndStartTime,  ROutAnimName, ROutFrame, RLoopStartTime);

	if (LMinDistance == -1 && RMinDistance == -1) return false;
	
	bool bLeftStart = FMath::Abs(LMinDistance) < FMath::Abs(RMinDistance);
	float MinDistance = bLeftStart ? LMinDistance : RMinDistance;
	float MinDistanceFrame = bLeftStart ? LOutFrame : ROutFrame;
	OutStartName = bLeftStart ? LStartName : RStartName;
	OutEndAnimName = bLeftStart ? LOutAnimName : ROutAnimName;
	// 开始动作 & 停步动作
	if (!FinalLocoAnimAssets.Contains(OutStartName) || !FinalLocoAnimAssets.Contains(OutEndAnimName)) return -1;
	UAnimSequenceBase* StartAnimSeqBase = FinalLocoAnimAssets[OutStartName];
	UAnimSequenceBase* EndAnimSeqBase = FinalLocoAnimAssets[OutEndAnimName];
	if (!StartAnimSeqBase || !EndAnimSeqBase) return -1;

	OutStartDuration = StartAnimSeqBase->GetPlayLength() - CrossTimeOfLoop;
	// 此时停步
	OutEndStartTime = bLeftStart ? LEndStartTime : REndStartTime;
	OutLoopMoveDuration = bLeftStart ? LLoopDuration : RLoopDuration;
	OutTotalTime = (bLeftStart ? LStartDuration : RStartDuration) + OutLoopMoveDuration + (EndAnimSeqBase->GetPlayLength() - OutEndStartTime);
		
	SequenceStartFootPosture = bLeftStart ? 1 : 0;
	SequenceBeginStartTime = 0.f;
	SequenceStartToLoopStartTimeCache = bLeftStart ? LLoopStartTime : RLoopStartTime;
	SequenceLoopToEndStartTimeCache = OutEndStartTime;
	SequenceStartToLoopStartTime = SequenceStartToLoopStartTimeCache;
	SequenceLoopToEndStartTime = SequenceLoopToEndStartTimeCache;

	if (bDebugDialogueLog)
	{
		UE_LOG(LogTemp, Log, TEXT("[CalculateDialogue]: StartFoot:%s, ToLoopStartTime:%f ToEndStartTime:%f MinDistanceFrame:%f MinDistance:%f LoopToEndThreshold:%f"),
			SequenceStartFootPosture ? TEXT("LeftStart") : TEXT("RightStart"), SequenceStartToLoopStartTime, SequenceLoopToEndStartTime, MinDistanceFrame, MinDistance, LoopToEndThreshold);
	}
	
	return MinDistance;
}

float UBaseAnimInstance::CalculateLoopToEndOptimisationDistance(FName StartName, FName LoopName, FName LEndName, FName REndName, float TotalSplineLength, float MapInX, float MapInY, float MapOutX, float MapOutY,
	int EnterLoopFrame, float& OutStartMoveDuration, float& OutLoopMoveDuration, float& OutEndStartTime, FName& OutEndAnimName, int& OutFrame, float& OutLoopStartTime)
{
	if (!FinalLocoAnimAssets.Contains(StartName) || !FinalLocoAnimAssets.Contains(LoopName)) return -1;
	
	UAnimSequenceBase * StartAnimSeqBase = FinalLocoAnimAssets[StartName];
	UAnimSequenceBase * LoopAnimSeqBase = FinalLocoAnimAssets[LoopName];
	if (!StartAnimSeqBase || !LoopAnimSeqBase) return -1;
	
	float StartDuration = 0, LoopDuration = 0, EndDuration = 0;
	float StartDistance = 0, LoopDistance = 0, EndDistance = 0;
	float StartYawDiff = 0, LoopYawDiff = 0, EndYawDiff = 0;
	
	// Loop 原始动画数据
	GetLocoAnimRootMotionInfo(StartName, 0, -1, StartDuration, StartDistance, StartYawDiff);
	GetLocoAnimRootMotionInfo(LoopName, 0, -1, LoopDuration, LoopDistance, LoopYawDiff);
	GetLocoAnimRootMotionInfo(LEndName, 0, -1, EndDuration, EndDistance, EndYawDiff);

	OutStartMoveDuration = StartDuration;
	
	// 停步时 进 Loop 百分比
	OutLoopStartTime = FMath::Clamp((float)LoopAnimSeqBase->GetSamplingFrameRate().AsSeconds(EnterLoopFrame), 0.f, LoopDuration);
	float LoopEnterLeftTime = LoopAnimSeqBase->GetPlayLength() - OutLoopStartTime;
	float LoopFirstLeftDistance = LoopDistance - (LoopAnimSeqBase->ExtractRootMotionFromRange(0, OutLoopStartTime)).GetTranslation().Length();
	float AvgLoopSpeed = LoopDistance / LoopDuration;
	
	// Loop 和 停步距离 
	float LoopAndEndDistance = TotalSplineLength - StartDistance;
	if (LoopAndEndDistance < EndDistance)
	{
		UE_LOG(LogTemp, Warning, TEXT("[URoleMovementComponent:CalculateLoopToEndOptimisationDistance] Spline Length To Short To Use CycleMotion, SplineLength:%.2f, StartAndEnd Length:%.2f"),TotalSplineLength, StartDistance + EndDistance);
		return -1;
	}
	
	// 从中间进入循环之前要先减去这部分数据
	float LoopAllDis = 0.f;
	int StartToLoopFrame = EnterLoopFrame;
	if (StartToLoopFrame != 0)
	{
		// 如果剩余距离超出了 半个Loop循环距离+停步距离 则先走完这半个循环
		if (LoopAndEndDistance >= LoopFirstLeftDistance + EndDistance)
		{
			LoopAndEndDistance -= LoopFirstLeftDistance;
			OutLoopMoveDuration += LoopEnterLeftTime;
			LoopAllDis += LoopFirstLeftDistance;
			StartToLoopFrame = 0;
		}
	}
	
	int IntegerPart = FMath::Floor(LoopAndEndDistance / LoopDistance);
	float LeftDistance =  LoopAndEndDistance - IntegerPart * LoopDistance;

	float MinDistance = -1;
	float OutLoopLeftTime = 0.f;
	LoopAllDis += IntegerPart * LoopDistance;
	if (LeftDistance > EndDistance)
	{
		OutLoopMoveDuration += IntegerPart * LoopDuration;

		if (bDebugDialogueLog)
		{
			UE_LOG(LogTemp, Log, TEXT("[CalculateDialogue]:	StartName:%s  ToLoopFrame:%d LoopIntPart:%d TotalDis:%f StartDis:%f, LoopAllDis:%f, LeftDis:%f"),
				*StartName.ToString(), StartToLoopFrame, IntegerPart, TotalSplineLength, StartDistance, LoopAllDis, LeftDistance)
		}
		
		MinDistance = CalculateOptimisationLeftDistance(StartName, LoopName, LEndName, REndName, MapInX, MapInY, MapOutX, MapOutY, StartToLoopFrame, AvgLoopSpeed, LeftDistance, EndDistance,
			OutEndAnimName, OutEndStartTime, OutFrame, OutLoopLeftTime);
	}
	else
	{
		// 分两种情况 不恢复做一次计算 恢复做一次计算 取最优解
		FName OutEndAnimNameNoLoop, OutEndAnimNameWithLoop;
		float OutEndStartTimeNoLoop, OutEndStartTimeWithLoop, OutLoopLeftTimeNoLoop, OutLoopLeftTimeWithLoop;
		int OutFrameNoLoop, OutFrameWithLoop;
		
		// 直接用剩余距离计算
		if (bDebugDialogueLog)
		{
			UE_LOG(LogTemp, Log, TEXT("[CalculateDialogue]: NoLoop StartName:%s  ToLoopFrame:%d LoopIntPart:%d TotalDis:%f StartDis:%f, LoopAllDis:%f, LeftDis:%f"),
				*StartName.ToString(), StartToLoopFrame, IntegerPart, TotalSplineLength, StartDistance, LoopAllDis, LeftDistance)
		}
		float MinDistanceNoLoop = CalculateOptimisationLeftDistance(StartName, LoopName, LEndName, REndName, MapInX, MapInY, MapOutX, MapOutY, StartToLoopFrame, AvgLoopSpeed, LeftDistance, EndDistance,
			OutEndAnimNameNoLoop, OutEndStartTimeNoLoop, OutFrameNoLoop, OutLoopLeftTimeNoLoop);

		// 恢复一段距离后计算
		// 如果大于 0 则恢复一个循环,反之恢复之前的半个循环
		float RecoveryLength = IntegerPart > 0 ? LoopDistance : LoopFirstLeftDistance;
		LoopAllDis -= RecoveryLength;

		// 恢复一次 Loop循环后计算
		if (bDebugDialogueLog)
		{
			UE_LOG(LogTemp, Log, TEXT("[CalculateDialogue]: WithLoop StartName:%s  ToLoopFrame:%d LoopIntPart:%d TotalDis:%f StartDis:%f, LoopAllDis:%f, LeftDis:%f"),
				*StartName.ToString(), StartToLoopFrame, IntegerPart, TotalSplineLength, StartDistance, LoopAllDis, LeftDistance + RecoveryLength)
		}
		float MinDistanceWithLoop = CalculateOptimisationLeftDistance(StartName, LoopName, LEndName, REndName, MapInX, MapInY, MapOutX, MapOutY, StartToLoopFrame, AvgLoopSpeed, LeftDistance + RecoveryLength, EndDistance,
			OutEndAnimNameWithLoop, OutEndStartTimeWithLoop, OutFrameWithLoop, OutLoopLeftTimeWithLoop);
		
		if (FMath::Abs(MinDistanceWithLoop) < FMath::Abs(MinDistanceNoLoop))
		{
			if (IntegerPart > 0)
			{
				OutLoopMoveDuration += (IntegerPart - 1) * LoopDuration;
			}
			else
			{
				OutLoopMoveDuration = 0;
			}
			
			MinDistance = MinDistanceWithLoop;
			OutEndAnimName = OutEndAnimNameWithLoop;
			OutEndStartTime = OutEndStartTimeWithLoop;
			OutFrame = OutFrameWithLoop;
			OutLoopLeftTime = OutLoopLeftTimeWithLoop;
		}
		else
		{
			OutLoopMoveDuration += IntegerPart * LoopDuration;
		
			MinDistance = MinDistanceNoLoop;
			OutEndAnimName = OutEndAnimNameNoLoop;
			OutEndStartTime = OutEndStartTimeNoLoop;
			OutFrame = OutFrameNoLoop;
			OutLoopLeftTime = OutLoopLeftTimeNoLoop;
		}
	}

	OutLoopMoveDuration += OutLoopLeftTime;
	return MinDistance;
}

float UBaseAnimInstance::CalculateOptimisationLeftDistance(FName StartName, FName LoopName, FName LEndName, FName REndName, float MapInX, float MapInY, float MapOutX, float MapOutY,
	int StartToLoopFrame, float AvgLoopSpeed, float LeftDistance, float EndDistance, FName& OutEndAnimName, float& OutEndStartTime, int& OutFrame, float& OutLoopLeftTime)
{
	if (!FinalLocoAnimAssets.Contains(StartName) || !FinalLocoAnimAssets.Contains(LoopName)) return -1;
	
	UAnimSequenceBase* StartAnimSeqBase = FinalLocoAnimAssets[StartName];
	UAnimSequenceBase* LoopAnimSeqBase = FinalLocoAnimAssets[LoopName];
	if (!StartAnimSeqBase || !LoopAnimSeqBase) return -1;
	
	float LeftLoopTime = LeftDistance > EndDistance ? (LeftDistance - EndDistance) / AvgLoopSpeed : 0;
	
	OutEndAnimName = LEndName;
	float MinDistance = TNumericLimits<float>::Max();
	
	const int32 NumFramesOfLoop = LoopAnimSeqBase->GetNumberOfSampledKeys();
	const float LoopAnimLength = LoopAnimSeqBase->GetPlayLength();
	for (int32 FrameIndex = StartToLoopFrame; FrameIndex < NumFramesOfLoop; ++FrameIndex)
	{
		const float CurveTime = FMath::Clamp((float)LoopAnimSeqBase->GetSamplingFrameRate().AsSeconds(FrameIndex), 0.f, LoopAnimLength);
		float FootPostureValue = LoopAnimSeqBase->EvaluateCurveData(FootPostureCurveName, CurveTime); // 曲线值
		
		// 左脚先行停步动作
		OutEndAnimName = FootPostureValue <= 0 ? REndName :LEndName;
		if (!FinalLocoAnimAssets.Contains(OutEndAnimName)) return -1;
		UAnimSequenceBase* EndAnimSeqBase = FinalLocoAnimAssets[OutEndAnimName];
		if (!EndAnimSeqBase) return -1;
		
		if (CurveTime >= LeftLoopTime)
		{
			// float LoopFootRatio = LoopFootCurveRatio->Evaluate(CurveTime);
			float LoopFootRatio = LoopAnimSeqBase->EvaluateCurveData(FootRatioCurveName, CurveTime); // 曲线值
			float EndStartTime = FMath::GetMappedRangeValueUnclamped(FVector2f(MapInX, MapInY), FVector2f(MapOutX, MapOutY), LoopFootRatio);
			float EndAnimLength = EndAnimSeqBase->GetPlayLength();
			FTransform LoopRootDelta = LoopAnimSeqBase->ExtractRootMotionFromRange(0, CurveTime);
			FTransform EndRootDelta = EndAnimSeqBase->ExtractRootMotionFromRange(EndStartTime, EndAnimLength);
			float LoopDistanceOut = LoopRootDelta.GetTranslation().Length();
			float EndDistanceOut = EndRootDelta.GetTranslation().Length();
			float DeltaDistance = LeftDistance - LoopDistanceOut - EndDistanceOut;

			if (bDebugDialogueLog)
			{
				UE_LOG(LogTemp, Log, TEXT("[CalculateDialogue]:	FrameIndex:%d  LoopFootRatio:%f EndStartTime:%f LoopDistanceOut:%f EndDistanceOut:%f, DeltaDistance:%f"),
					FrameIndex, LoopFootRatio, EndStartTime, LoopDistanceOut, EndDistanceOut, DeltaDistance)	
			}
			
			if (FMath::Abs(MinDistance) > FMath::Abs(DeltaDistance))
			{
				MinDistance = DeltaDistance;
				OutEndStartTime = EndStartTime;
				OutFrame = FrameIndex;
				OutLoopLeftTime = CurveTime;
			}
		}
	}
	return MinDistance;
}

void UBaseAnimInstance::PushTrackTargetBone(FTrackTargetBone TrackTargetBone)
{
	if (TrackTargetBone.bBreak)
	{
		TrackTargetBoneMap.Remove(TrackTargetBone.EffectBone);
		return ;
	}

	FTrackTargetBone* TrackBoneInfo = TrackTargetBoneMap.Find(TrackTargetBone.EffectBone);
	if (TrackBoneInfo)
	{
		(*TrackBoneInfo) = TrackTargetBone;

		return ;
	}


	TrackTargetBoneMap.Add(TrackTargetBone.EffectBone, TrackTargetBone);

	UpdateTrackTargetBone(0.0f);
}

void UBaseAnimInstance::UpdateTrackTargetBone(float DeltaTime)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UpdateTrackTargetBone");
	if (TrackTargetBoneMap.Num() <= 0)
		return ;

	TArray<FString> DelayDelete;
	for (auto& Elem : TrackTargetBoneMap)
	{
		FTrackTargetBone& TrackBoneInfo = Elem.Value;
		TrackBoneInfo.RemainTime = TrackBoneInfo.RemainTime - DeltaTime;

		if (TrackBoneInfo.RemainTime <= .0f || !TrackBoneInfo.ReferenceMesh.IsValid())
		{
			DelayDelete.Push(Elem.Key);
			continue;
		}

		//更新帮信息
		FVector OutLocation; FRotator OutRotation;
		TrackBoneInfo.ReferenceMesh->GetSocketWorldLocationAndRotation(FName(TrackBoneInfo.ReferenceBone), OutLocation, OutRotation);
		FTransform _ReferenceWTF(OutRotation, OutLocation);

		TrackBoneInfo.FinalTF = TrackBoneInfo.Offset * _ReferenceWTF;
	}

	for (auto& DElem : DelayDelete)
	{
		TrackTargetBoneMap.Remove(DElem);
	}
}

bool UBaseAnimInstance::IsSlotMontagePlaying(FName SlotNodeName) const
{
	return GetSlotMontageGlobalWeight(SlotNodeName) > .0f;
}

float UBaseAnimInstance::GetMorphTargetCurveValue(FName CurveName) const
{
	float Value = 0.f;
	const TMap<FName, float>& MorphMap = GetAnimationCurveList(EAnimCurveType::MorphTargetCurve);
	const float* OutValue = MorphMap.Find(CurveName);
	if (OutValue)
	{
		Value = *OutValue;
		return Value;
	}

	return Value;
}

float UBaseAnimInstance::GetCacheAttributeCurveValue(FName CurveName)
{
	if (!bEnableCacheAttributeCurve)
	{
		bEnableCacheAttributeCurve = true;
		return .0f;
	}

	const float* OutValue = CacheAttributeCurveMap.Find(CurveName);
	if (OutValue)
	{
		return *OutValue;
	}

	return .0f;
}


void UBaseAnimInstance::NativeUpdateAnimation(float DeltaSeconds)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UBaseAnimInstance_NativeUpdateAnimation");
	
	auto* ownerPtr = TryGetPawnOwner();
	if (!ownerPtr) { return; }

	LastActorRotation = ViewActorTransform.GetRotation().Rotator();
	LastViewActorTransform = ViewActorTransform;
	// 这个要放在前面, 要保障下面逻辑依赖其时拿到的是最新数据
	ViewActorTransform = ownerPtr->GetActorTransform();
	
	//更新骨骼追踪数据
	UpdateTrackTargetBone(DeltaSeconds);
	UpdateTrackActorBoneTransform(DeltaSeconds);

	bool IsInDefaultLoco = true;
	{
		TRACE_CPUPROFILER_EVENT_SCOPE_STR("UpdateArgsFromMovement");

		auto* pawnComPtr = ownerPtr->GetMovementComponent();
		if (URoleMovementComponent* uRoleMCPtr = Cast<URoleMovementComponent>(pawnComPtr))
		{
			uRoleMCPtr->PullMovementControlDataByAnim(*this, DeltaSeconds);
			// 计算姿态数据
			if (BodyLeanAxisDataSource != EBodyLeanAxisDataSource::None)
			{
				UpdateBodyLeanAlpha(uRoleMCPtr, DeltaSeconds);
				UpdateRelInputAxis(uRoleMCPtr);
			}
			LastFrameAnimRotator = uRoleMCPtr->GetLastFrameRotator();
			IsInDefaultLoco = uRoleMCPtr->IsInDefaultLocoState();

			// 更新动画曲线数据 (动画数据更新,没有移动组件的单位应该不需要动画数据更新,后续遇到需要的case再考虑提取出去)
			CalculateAnimationControl(DeltaSeconds);
			// 应用坐骑IK数据
			UpdateRideMountIkInfo(uRoleMCPtr, ownerPtr);

			UpdateBoneAutoRotate(DeltaSeconds);
			
			if (bIsALSMode)
			{
				ALS_NativeUpdateAnimation(DeltaSeconds);
			}
 
		}
		else
		{
			// 对于简单单位, 可能没有RoleMovementComponent, 下面按需计算自己要的逻辑 
			if (DeltaSeconds > KINDA_SMALL_NUMBER)
			{
				FVector MoveDelta = ownerPtr->GetActorLocation() - LastFramePos;
				MovementVelocity = MoveDelta / DeltaSeconds;
				VelocityValue = MovementVelocity.Length();
				VelocityXY = MovementVelocity.Size2D();
				ExpectedVelocity = MovementVelocity;
				VelocityZ = ExpectedVelocity.Z;
				LastExpectVelocityInAir = MovementVelocity;
			}
			LastFramePos = ownerPtr->GetActorLocation();
		}
	}

	if (IsSlaveAnimControl) {
		DoSlaveControl(DeltaSeconds);
	}
	else
	{
		SetLocomotionBoolData(LocomotionStatemachineName, IsLocoStart, IsGrounded);
	}

	int OldAnimSignificanceOffset = CurTrivialAnimSignificanceOffset;
	// 开启动画贡献进行动画重要影响的开关, 并且当前在默认Locomotion表现中、没有任何Montage在播放, 则可以进行重要度调整
	if(bEnableTrivialAnimSignificanceOffset && IsInDefaultLoco && (!IsAnyMontagePlaying()))
	{
		CurTrivialAnimSignificanceOffset = ConfigTrivialAnimSignificanceOffset;
	}
	else
	{
		CurTrivialAnimSignificanceOffset = 0;
	}

	if(OldAnimSignificanceOffset != CurTrivialAnimSignificanceOffset && TrivialSignificanceChangedDelegate.IsBound())
	{
		TrivialSignificanceChangedDelegate.Execute();
	}

	// 动画定帧功能
	if(AnimationToFreeze.IsValid())
	{
		UpdateAnimationToFreeze(DeltaSeconds);
	}

	// 同步职业专属动画数据 占卜家
	if (bSyncSeerParam)
	{
		UpdateSeerAnimationSync(DeltaSeconds);
	}
	
	// LookAt 功能
	const bool bTickGaze = CurrentGazeType != EGazeTargetType::None or (CurrentGazeType == EGazeTargetType::None and CurrentGazeData.GazeAlpha > 0);
	if (bTickGaze)
	{
		TickGaze(DeltaSeconds);
	}

	if (bIsRagDoll)
	{
		UpdateRagdollValues();
	}
}

void UBaseAnimInstance::UpdateRagdollValues()
{
	const float VelocityLength = GetOwningComponent()->GetPhysicsLinearVelocity(NAME__ALSCharacterAnimInstance__root).Size();
	MassFlailRate = FMath::GetMappedRangeValueClamped<float, float>({0.0f, 1000.0f}, {0.0f, 1.0f}, VelocityLength);
}


void UBaseAnimInstance::PullLocomotionControlDataFromRoleMovement(URoleMovementComponent& rmc, float DeltaTime) {

	// ------------------从MovementComponent中拉数据-------------------
#if UE_BUILD_DEVELOPMENT
	bool OldIsGrounded = IsGrounded;
#endif
	// 公共部分
	IsGrounded = rmc.GetHasLocoGroundSupport();
	MovementVelocity = rmc.GetMovementVelocity();
	MovementAcceleration =  rmc.MovementAcceleration;
	LocoInputVec = rmc.GetLocoInputVector();
	VelocityValue = MovementVelocity.Length();
	VelocityXY = MovementVelocity.Size2D();
	ExpectedVelocity = rmc.ExpectVelocity;
	LastExpectVelocityInAir = rmc.LastExpectVelocityInAir;
	MovementMaxAcceleration = rmc.GetMaxAcceleration();
	MovementMaxDeceleration = rmc.GetMaxBrakingDeceleration();
	VelocityZ = ExpectedVelocity.Z;
	IsLocoStart = rmc.GetIsLocoStart();
	LocoStateInnerIndexFromMask = rmc.GetLocoStateInnerIndexFromMask();
#if UE_BUILD_DEVELOPMENT
	if (IsGrounded && !OldIsGrounded)
	{
		OnGroundExpectedVelocity = ExpectedVelocity;
	}
#endif
	const FRideMountContextInfo RideMountContextInfo = rmc.GetRoleMP().GetMovementContext().GetRideMountContextInfo();
	
	AttachmentInfo.MountDirYawToActorYawDelta = RideMountContextInfo.MountDirYawToActorYawDelta;
	AttachmentInfo.RealMountDeltaYawScale = RideMountContextInfo.RealMountDeltaYawScale;
	AttachmentInfo.RealMountDirYawToActorYawDelta = RideMountContextInfo.MountDirYawToActorYawDelta * RideMountContextInfo.RealMountDeltaYawScale;
	AttachmentInfo.MountFrontMoveAngle = RideMountContextInfo.MountFrontMoveAngle;
	AttachmentInfo.MountEndMoveAngle = RideMountContextInfo.MountEndMoveAngle;
	
	// 主端生效
	FaceAndDriveDiffRadian = 0.0f;
	AbsFaceAndDriveDiffRadian = 0.0f;
	bool isNetSimulate = rmc.GetCurrentIsNetSimulate();
	if (!isNetSimulate)
	{
		FaceAndDriveDiffRadian = rmc.GetFaceAndDriveDiffRadian();
		bIsBackCar = rmc.GetIsBackCar();
		AbsFaceAndDriveDiffRadian = FMath::Abs(FaceAndDriveDiffRadian);
	}
	UpdateAllowMoveTurn();

	
	ThreeLayerPostureParam.bLocoMoving = IsLocoStart || !rmc.IsInDefaultLocoState() || bLowerLocoWorking;
	if (LastExpectVelocityInAir.Z < HighJumpEndVelocityZThreshold) {
		IsHighJumpEnd = true;
	}
	else {
		IsHighJumpEnd = false;
	}

}

void UBaseAnimInstance::CalculateAnimationControl(float DeltaTime) {
	// ------------------计算动画需要的数据----------------------------
	if (RemainAnimMovePostureCacheTime > 0.0f)
	{
		RemainAnimMovePostureCacheTime -= DeltaTime;
		if (RemainAnimMovePostureCacheTime < 0.0f)
		{
			DelayedAnimMovePosture = AnimMovePosture;
			DelayedMoveAnimPlayRate = MoveAnimPlayRate;
			UpdateDelayedAnimMovePosture();
		}
	}
    UpdateCurveControl(DeltaTime);

	if (AnimMoveMode != 0)
	{
		CalWanderingVelYawAndSpeedOrient(MovementVelocity, ViewActorTransform.GetRotation().Rotator().Yaw, FaceAndVelDiffVec2D);
	}
}

void UBaseAnimInstance::DoSlaveControl(float deltaTime) {
	
	// IsLocoStart = false;

}

void UBaseAnimInstance::UpdateSeerAnimationSync(float DeltaSeconds)
{
	UProfessionalismComponent* ProfessionalCmpt = IsValid(OwnerCharacter) ? Cast<UProfessionalismComponent>(OwnerCharacter->GetComponentByClass(UProfessionalismComponent::StaticClass())) : nullptr;
	if (ProfessionalCmpt)
	{
		ProfessionalCmpt->SyncSeerAnimParam(this, DeltaSeconds);
	}
}

void UBaseAnimInstance::UpdateAnimationToFreeze(float DeltaSeconds)
{
	UAnimMontage* MontageToFreeze = AnimationToFreeze.Get();
	AnimationFreezePassedTime += DeltaSeconds;
	if(FAnimMontageInstance* MontageInstance = GetActiveInstanceForMontage(MontageToFreeze))
	{
		float DesiredPlayRate = 1.f;
		if(AnimationFreezePassedTime < AnimationFreezeInTime)
		{
			DesiredPlayRate = AnimationFreezeSpeed;
		}
		else if(AnimationFreezePassedTime < AnimationFreezeInTime + AnimationFreezeOutTime)
		{
			DesiredPlayRate = AnimationFreezeFixUpSpeed;
		}
		else
		{
			DesiredPlayRate = AnimationFreezeRowPlayRate;
			AnimationToFreeze.Reset();
		}
		MontageInstance->SetPlayRate(DesiredPlayRate);
	}
	else
	{
		AnimationToFreeze.Reset();
	}
}

void UBaseAnimInstance::NativePostEvaluateAnimation()
{
	if (bEnableCacheAttributeCurve)
	{
		CacheAttributeCurveMap.Reset();
		AppendAnimationCurveList(EAnimCurveType::AttributeCurve, CacheAttributeCurveMap);
	}
}

void UBaseAnimInstance::NativeUninitializeAnimation()
{
	// 数据清理
	FaceAnimLayerWeakPtr.Reset();

	for (auto& LayerPtr:FeatureAnimLayers)
	{
		LayerPtr.Value.Reset();
	}
	FeatureAnimLayers.Empty();

	LocoSequencePrioritys.Reset();
	LocoSequenceForbidden.Reset();
	LocoSequenceMappings.Reset();
	FinalLocoAnimAssets.Reset();

	Super::NativeUninitializeAnimation();
}




void UBaseAnimInstance::CalWanderingVelYawAndSpeedOrient(const FVector& ActorVelocity, float FaceYaw, FVector2D& InFaceVelDiffVec)
{
	if(ActorVelocity.IsNearlyZero())
	{
		InFaceVelDiffVec = FVector2D::ZeroVector;
		return;
	}
	const float VelYaw = FMath::RadiansToDegrees(FMath::Atan2(ActorVelocity.Y, ActorVelocity.X));
	const float DiffYaw = FMath::DegreesToRadians(MathFormula::ClosetYawSignedDiff(FaceYaw, VelYaw));
	InFaceVelDiffVec.Y = FMath::Cos(DiffYaw);
	InFaceVelDiffVec.X = FMath::Sin(DiffYaw);
}


#if WITH_EDITOR
void UBaseAnimInstance::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	RefreshLocoAnimSequenceInABP();
}
#endif

float UBaseAnimInstance::GetMontageCurrentPosition(UAnimMontage* CheckMontage)
{
	const FAnimMontageInstance* MontageInstance = GetActiveInstanceForMontage(CheckMontage);
	if (MontageInstance)
	{
		return MontageInstance->GetPosition();
	}
	return 0.0f;
}

UAnimMontage* UBaseAnimInstance::GetSlotPlayingMontage(FName SlotName)
{
	for (int32 InstanceIndex = 0; InstanceIndex < MontageInstances.Num(); InstanceIndex++)
	{
		FAnimMontageInstance* MontageInstance = MontageInstances[InstanceIndex];

		if (MontageInstance && MontageInstance->IsActive() && MontageInstance->IsPlaying())
		{
			UAnimMontage* CurMontage = MontageInstance->Montage;
			if (CurMontage && CurMontage->SlotAnimTracks[0].SlotName == SlotName)
				return CurMontage;
		}
	}

	return NULL;
}


UAnimSequenceBase* UBaseAnimInstance::GetSequenceFromAssetID(const FAnimNodeAssetID& AssetID)
{
	auto sequenceObjPtr = FinalLocoAnimAssets.Find(AssetID.GetNameID());
	if (sequenceObjPtr)
	{
		return sequenceObjPtr->Get();
	}
	
	if(AnimLibItemName != NAME_None)
	{
		UE_LOG(UBaseAnimInstanceLog, Warning,
			TEXT("UBaseAnimInstance::GetSequenceFromAssetID Cannot Find ABP Anim, AnimLib:%s  AnimKey:%s "),
			*AnimLibItemName.ToString(), *AssetID.GetNameID().ToString());
	}
	return nullptr;
}


bool UBaseAnimInstance::GetAnimSequenceBaseCurrentPlayedTime(UAnimSequenceBase * TargetAnim, float & OutCurrentPlayedTime)
{
	if(!TargetAnim)
	{
		return false;
	}
	
	TArray<FAnimTickRecord> UngroupedActivePlayers = GetProxyOnGameThread<FAnimInstanceProxy>().GetUngroupedActivePlayersRead();
	const TMap<FName, FAnimGroupInstance> &  AnimMap = GetProxyOnGameThread<FAnimInstanceProxy>().GetSyncGroupMapRead();
	for(auto & Item:AnimMap)
	{
		UngroupedActivePlayers.Append(Item.Value.ActivePlayers);
	}

	for(auto & AnimPlayer:UngroupedActivePlayers)
	{
		if(AnimPlayer.SourceAsset == TargetAnim && AnimPlayer.TimeAccumulator)
		{
			OutCurrentPlayedTime = *AnimPlayer.TimeAccumulator;
			return true;
		}
	}

	return false;
	
}

#pragma region Animation Load Management

void UBaseAnimInstance::InitLocoSequenceContainerSize(uint8 size, FName animLibItemName) {
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UBaseAnimInstance::InitLocoSequenceContainerSize");

#if !UE_BUILD_SHIPPING
	// 目前脚本层5个优先级
	constexpr int UnFeasibleSize = 5;
	if (size > UnFeasibleSize) {
		UE_LOG(UBaseAnimInstanceLog, Warning, TEXT("UBaseAnimInstance::InitLocoSequenceContainerSize UnFeasible Size: %d "), size);
	}
#endif

	AnimLibItemName = animLibItemName;
	
	if (LocoSequenceMappings.Num() > 0 || LocoSequencePrioritys.Num() > 0) {
		if(LocoSequenceMappings.Num() < size)
		{
			LocoSequenceMappings.SetNum(size);
		}
		if(LocoSequenceForbidden.Num() < size)
		{
			LocoSequenceForbidden.SetNum(size);
		}
		if(LocoSequencePrioritys.Num() < size)
		{
			int OldSize = LocoSequencePrioritys.Num();
			LocoSequencePrioritys.SetNum(size);
			for(int Index = OldSize; Index < size; ++Index)
			{
				LocoSequencePrioritys[Index] = UnusedSemanticTag;
			}
		}
		return;
	}

	LocoSequenceMappings.SetNum(size);
	LocoSequenceForbidden.SetNum(size);
	LocoSequencePrioritys.SetNum(size);
	for (int index = 0; index < size; ++index) {
		LocoSequencePrioritys[index] = UnusedSemanticTag;
		LocoSequenceForbidden[index] = false;
	}
}

bool UBaseAnimInstance::ObtainLocoSequenceMappingWithPriorityIndex(uint8 priorityIndex, uint8 prioritySemanticTag, const TMap<FName, UAnimSequenceBase*>& sequenceMap){
	if (priorityIndex >= LocoSequencePrioritys.Num()) {
#if !UE_BUILD_SHIPPING
		UE_LOG(UBaseAnimInstanceLog, Warning, TEXT("UBaseAnimInstance::SetLocoSequenceMappingWithPriorityIndex  Invalid Index: %d,  current size:%d "), priorityIndex, LocoSequencePrioritys.Num());
#endif
		return false;
	}

	if (sequenceMap.Num() == 0) {
#if !UE_BUILD_SHIPPING
		UE_LOG(UBaseAnimInstanceLog, Warning, TEXT("UBaseAnimInstance::SetLocoSequenceMappingWithPriorityIndex  Empty Sequence Map "));
#endif
		return false;
	}

	LocoSequencePrioritys[priorityIndex] = prioritySemanticTag;
	auto& curMap = LocoSequenceMappings[priorityIndex];

	curMap.Reset();
	curMap.Reserve(sequenceMap.Num());
	
	for (auto& pair : sequenceMap)
	{
		curMap.Emplace(pair.Key, pair.Value);
	}

	RefreshLocoAnimSequenceInABP();

	return true;
}

bool UBaseAnimInstance::UpdateAnimSequenceInLocoSequenceMapping(uint8 priorityIndex, const TMap<FName, UAnimSequenceBase*>& seqMap)
{
	if (priorityIndex >= LocoSequencePrioritys.Num()) {
#if !UE_BUILD_SHIPPING
		UE_LOG(UBaseAnimInstanceLog, Warning, TEXT("UBaseAnimInstance::UpdateAnimSequenceInLocoSequenceMapping  Invalid Index: %d,  current size:%d "), priorityIndex, LocoSequencePrioritys.Num());
#endif
		return false;
	}

	if (seqMap.Num() == 0) {
#if !UE_BUILD_SHIPPING
		UE_LOG(UBaseAnimInstanceLog, Warning, TEXT("UBaseAnimInstance::UpdateAnimSequenceInLocoSequenceMapping  Empty Sequence Map "));
#endif
		return false;
	}

	auto& curMap = LocoSequenceMappings[priorityIndex];
	for (auto& pair : seqMap)
	{
		curMap.Emplace(pair.Key, pair.Value);
	}

	RefreshLocoAnimSequenceInABP();
	return true;
}

bool UBaseAnimInstance::SetLocoSequenceForbiddenByPriorityIndex(uint8 PriorityIndex, bool IsForbidden)
{
	if (PriorityIndex >= LocoSequencePrioritys.Num()) {
#if !UE_BUILD_SHIPPING
		UE_LOG(UBaseAnimInstanceLog, Warning, TEXT("UBaseAnimInstance::SetLocoSequenceForbiddenByPriorityIndex  Invalid Index: %d,  current size:%d "), PriorityIndex, LocoSequencePrioritys.Num());
#endif
		return false;
	}

	if(LocoSequenceForbidden[PriorityIndex] == IsForbidden)
	{
		return true;
	}

	LocoSequenceForbidden[PriorityIndex] = IsForbidden;
	RefreshLocoAnimSequenceInABP();
	return true;
}

bool UBaseAnimInstance::ReleaseLocoSequenceMappingWithPriorityIndex(uint8 priorityIndex) {
	if (priorityIndex >= LocoSequencePrioritys.Num()) {
#if !UE_BUILD_SHIPPING
		UE_LOG(UBaseAnimInstanceLog, Warning, TEXT("UBaseAnimInstance::ReleaseLocoSequenceMappingWithPriorityIndex  Invalid Index: %d,  current size:%d "), priorityIndex, LocoSequencePrioritys.Num());
#endif
		return false;
	}

	LocoSequencePrioritys[priorityIndex] = UnusedSemanticTag;

	TArray<FName> locoNames;
	LocoSequenceMappings[priorityIndex].Reset();

	RefreshLocoAnimSequenceInABP();
	return true;
}


int UBaseAnimInstance::GetLocoSequenceSemanticByPriorityIndex(uint8 priorityIndex) {
	if (priorityIndex >= LocoSequencePrioritys.Num()) {
#if !UE_BUILD_SHIPPING
		UE_LOG(UBaseAnimInstanceLog, Warning, TEXT("UBaseAnimInstance::ReleaseLocoSequenceMappingWithPriorityIndex  Invalid Index: %d,  current size:%d "), priorityIndex, LocoSequencePrioritys.Num());
#endif
		return UnusedSemanticTag;
	}
	
	return LocoSequencePrioritys[priorityIndex];
}

void UBaseAnimInstance::RefreshLocoAnimSequenceInABP()
{
	FinalLocoAnimAssets.Reset();
	
	for (int index = LocoSequencePrioritys.Num() - 1; index >= 0; --index) {
		if (LocoSequencePrioritys[index] == UnusedSemanticTag || LocoSequenceForbidden[index] == true) {
			continue;
		}

		auto const& curSeqMap = LocoSequenceMappings[index];

		for (auto const& pair : curSeqMap) {
			if (!pair.Value.IsValid() || FinalLocoAnimAssets.Contains(pair.Key)) {
				continue;
			}

			if (!((pair.Value)->IsA(UAnimSequence::StaticClass()) || (pair.Value)->IsA(UAnimComposite::StaticClass()))) {
				UE_LOG(
					UBaseAnimInstanceLog, Error, 
					TEXT("UBaseAnimInstance::RefreshLocoAnimSequenceInABP Uncompatible Sequence Type. Semantic:%d  AnimLib:%s, Empty Name:%s  in ABP:%s "), 
					LocoSequencePrioritys[index] , *AnimLibItemName.ToString(), *pair.Key.ToString(), *GetName()
				);
				continue;
			}

			FinalLocoAnimAssets.Emplace(pair.Key, pair.Value.Get());
		}
	}

	ReplaceSequenceInABP(FinalLocoAnimAssets);
	ReplaceSequenceInABPLayer(FinalLocoAnimAssets);
}

void UBaseAnimInstance::ReplaceSequenceInABPLayer(TMap<FName, TObjectPtr<UAnimSequenceBase>>& seqMap)
{
	for (auto& LayerPtr:FeatureAnimLayers)
	{
		if(!LayerPtr.Value.IsValid())
		{
			continue;
		}
		
		IAnimClassInterface* AnimClassInterface = IAnimClassInterface::GetFromClass(LayerPtr.Value->GetClass());
		if (!AnimClassInterface)
		{
#if !UE_BUILD_SHIPPING
			UE_LOG(UBaseAnimInstanceLog, Warning, TEXT("UBaseAnimInstance::ReplaceSequenceInABPLayer  Invalid AnimClassInterface when Replacing sequences "));
#endif
			return;
		}

		const TArray<FStructProperty*>& AnimNodeProperties = AnimClassInterface->GetAnimNodeProperties();

		for (auto E : AnimNodeProperties)
		{
			SetAssetIDSequencePlayer(LayerPtr.Value.Get(), E, seqMap);
		}
	}
}

void UBaseAnimInstance::ReplaceSequenceInABP(TMap<FName, TObjectPtr<UAnimSequenceBase>>& seqMap)
{
	IAnimClassInterface* AnimClassInterface = IAnimClassInterface::GetFromClass(GetClass());
	if (!AnimClassInterface)
	{
#if !UE_BUILD_SHIPPING
		UE_LOG(UBaseAnimInstanceLog, Warning, TEXT("UBaseAnimInstance::ReplaceSequenceInABP  Invalid AnimClassInterface when Replacing sequences "));
#endif
		return;
	}

	const TArray<FStructProperty*>& AnimNodeProperties = AnimClassInterface->GetAnimNodeProperties();

	for (auto E : AnimNodeProperties)
	{
		SetAssetIDSequencePlayer(this, E, seqMap);
	}
}

void UBaseAnimInstance::SetAssetIDSequencePlayer(UAnimInstance* AnimInstance, FStructProperty* MachineInstanceProperty, TMap<FName, TObjectPtr<UAnimSequenceBase>>& seqMap)
{
	if (!MachineInstanceProperty->Struct->IsChildOf(FAnimNode_AssetIDSequencePlayer::StaticStruct()))
	{
		return;
	}

	FAnimNode_AssetIDSequencePlayer* Player = MachineInstanceProperty->ContainerPtrToValuePtr<FAnimNode_AssetIDSequencePlayer>(AnimInstance);
	if (!Player)
	{
		return;
	}

	FString Name = Player->AssetID.GetID();
	// 要去掉, 避免动画生命周期被释放
	Player->Sequence = nullptr;
	Player->AnimLibID = AnimLibItemName;
		
	if (Name.IsEmpty())
	{
#if !UE_BUILD_SHIPPING
		UE_LOG(UBaseAnimInstanceLog, Error, TEXT("UBaseAnimInstance::SetAssetIDSequencePlayer  Empty Name:%s  in ABP:%s "), *Name, *GetName());
#endif
		return;
	}

	auto SequencePtr = seqMap.Find(FName(Name));
	if (!SequencePtr)
	{
		// 现在Loco动画的替换会先进行缓存内容的替换后进行加载资产后的替换，对于前者这里可能会产生误报
		// #if !UE_BUILD_SHIPPING
		// 			UE_LOG(UBaseAnimInstanceLog, Error, TEXT("UBaseAnimInstance::SetAssetIDSequencePlayer  UnMatched Name:%s   in  AnimLibName:%s "), *Name, *AnimLibItemName.ToString());
		// #endif
		return;;
	}

	Player->Sequence = SequencePtr->Get();
}

#pragma endregion


#pragma region Body Posture

void UBaseAnimInstance::SetBodyLeanAxisDataSource(EBodyLeanAxisDataSource DataSource)
{
	BodyLeanAxisDataSource = DataSource;
}

void UBaseAnimInstance::SetLocEnableBodyLean(bool bEnable)
{
	bEnableCalculateBodyLean = bEnable;
}

void UBaseAnimInstance::SetLocEnableInputAxis(bool bEnable)
{
	bEnableCalculateInputAxis = bEnable;
}

void UBaseAnimInstance::SetIsEnableRideMountIK(bool EnableHandIK, FName LHandBoneName, FName RHandBoneName, bool EnableFootIK, FName LFootBoneName, FName RFootBoneName)
{
	HandFootIKConfig.bEnableHandIK = EnableHandIK;
	HandFootIKConfig.bEnableFootIK = EnableFootIK;

	if (EnableHandIK)
	{
		HandFootIKConfig.MountHandLBoneName = LHandBoneName;
		HandFootIKConfig.MountHandRBoneName = RHandBoneName;
	}
	else
	{
		RemoveTwoBoneIKParam(HandFootIKConfig.HandLBoneName);
		RemoveTwoBoneIKParam(HandFootIKConfig.HandRBoneName);
		HandFootIKConfig.MountHandLBoneName = NAME_None;
		HandFootIKConfig.MountHandRBoneName = NAME_None;
	}
	
	if (EnableFootIK)
	{
		HandFootIKConfig.MountFootLBoneName = LFootBoneName;
		HandFootIKConfig.MountFootRBoneName = RFootBoneName;
	}
	else
	{
		RemoveTwoBoneIKParam(HandFootIKConfig.FootLBoneName);
		RemoveTwoBoneIKParam(HandFootIKConfig.FootRBoneName);
		HandFootIKConfig.MountFootLBoneName = NAME_None;
		HandFootIKConfig.MountFootRBoneName = NAME_None;
	}
}

void UBaseAnimInstance::EnableEyesIk(bool bEnable)
{
	if (bEnable)
	{
		AddModifyBoneParam(CommonIKConfig.LEyeIKBoneName, EC7BoneModificationMode::BMM_Additive, EC7BoneModificationMode::BMM_Ignore, EC7BoneModificationMode::BMM_Ignore, EBoneControlSpace::BCS_BoneSpace,
			CommonIKConfig.LEyeIkLoc.X, CommonIKConfig.LEyeIkLoc.Y, CommonIKConfig.LEyeIkLoc.Z, 0, 0, 0, 0, 0, 0, EyeIKCurveCurveName, 0);
		AddModifyBoneParam(CommonIKConfig.REyeIKBoneName, EC7BoneModificationMode::BMM_Additive, EC7BoneModificationMode::BMM_Ignore, EC7BoneModificationMode::BMM_Ignore, EBoneControlSpace::BCS_BoneSpace,
			CommonIKConfig.REyeIkLoc.X, CommonIKConfig.REyeIkLoc.Y, CommonIKConfig.REyeIkLoc.Z, 0, 0, 0, 0, 0, 0, EyeIKCurveCurveName, 0);
	}
	else
	{
		RemoveModifyBone(CommonIKConfig.LEyeIKBoneName);
		RemoveModifyBone(CommonIKConfig.REyeIKBoneName);
	}
}

void UBaseAnimInstance::AddModifyBoneParam(FName BoneName, EC7BoneModificationMode LocMode, EC7BoneModificationMode RotMode, EC7BoneModificationMode ScaleMode, EBoneControlSpace BoneControlSpace,
	float LocX, float LocY, float LocZ, float Pitch, float Yaw, float Roll, float ScaleX, float ScaleY, float ScaleZ, FName AlphaCurveName, float AlphaCurveDefaultValue, float BlendAlpha)
{
	FC7ModifyBones_Params BoneParam;
	BoneParam.BoneToModify = BoneName;
	BoneParam.TranslationMode = LocMode;
	BoneParam.RotationMode = RotMode;
	BoneParam.ScaleMode = ScaleMode;
	BoneParam.BoneControlSpace = BoneControlSpace;
	BoneParam.AlphaCurveName = AlphaCurveName;
	BoneParam.AlphaDefaultValue = AlphaCurveDefaultValue;
	BoneParam.Transform.SetLocation(FVector(LocX, LocY, LocZ));
	BoneParam.Transform.SetRotation(FRotator(Pitch, Yaw, Roll).Quaternion());
	BoneParam.Transform.SetScale3D(FVector(ScaleX, ScaleY, ScaleZ));
	BoneParam.BlendAlpha = BlendAlpha;
	BonesModifyMap.Emplace(BoneName, BoneParam);
	UpdateBatchIKAlpha();
}

void UBaseAnimInstance::UpdateModifyBoneParam(FName BoneName, float LocX, float LocY, float LocZ, float Pitch, float Yaw, float Roll, float ScaleX, float ScaleY, float ScaleZ, float Alpha)
{
	if (BonesModifyMap.Contains(BoneName))
	{
		BonesModifyMap[BoneName].Transform.SetLocation(FVector(LocX, LocY, LocZ));
		BonesModifyMap[BoneName].Transform.SetRotation(FRotator(Pitch, Yaw, Roll).Quaternion());
		BonesModifyMap[BoneName].Transform.SetScale3D(FVector(ScaleX, ScaleY, ScaleZ));
		BonesModifyMap[BoneName].BlendAlpha = Alpha;
	}
}

void UBaseAnimInstance::UpdateModifyBoneAlphaParam(FName BoneName, float Alpha)
{
	if (BonesModifyMap.Contains(BoneName))
	{
		BonesModifyMap[BoneName].BlendAlpha = Alpha;
	}
}

void UBaseAnimInstance::UpdateModifyBoneAutoAdd(FName BoneName, EC7BoneModificationMode LocMode, EC7BoneModificationMode RotMode, EC7BoneModificationMode ScaleMode, EBoneControlSpace BoneControlSpace,
	float LocX, float LocY, float LocZ, float Pitch, float Yaw, float Roll, float ScaleX, float ScaleY, float ScaleZ, FName AlphaCurveName, float AlphaCurveDefaultValue, float Alpha)
{
	if (BoneName == NAME_None) return;
	
	if (BonesModifyMap.Contains(BoneName))
	{
		UpdateModifyBoneParam(BoneName, LocX, LocY, LocZ, Pitch, Yaw, Roll, ScaleX, ScaleY, ScaleZ, Alpha);
	}
	else
	{
		AddModifyBoneParam(BoneName, LocMode, RotMode, ScaleMode, BoneControlSpace, LocX, LocY, LocZ, Pitch, Yaw, Roll, ScaleX, ScaleY, ScaleZ, AlphaCurveName, AlphaCurveDefaultValue, Alpha);
	}
}

void UBaseAnimInstance::RemoveModifyBone(FName BoneName)
{
	BonesModifyMap.Remove(BoneName);
	UpdateBatchIKAlpha();
}

void UBaseAnimInstance::RemoveModifyBones(TArray<FName> BoneNameArr)
{
	for (auto BoneName : BoneNameArr)
	{
		BonesModifyMap.Remove(BoneName);
	}
	UpdateBatchIKAlpha();
}

void UBaseAnimInstance::SequenceUpdateGazeBonesModify(FRotator Eye, FVector EyeScale, FRotator Head, FRotator Body, FRotator Spine_01, FRotator Spine_02, FRotator Spine_03)
{
	EC7BoneModificationMode Ignore = EC7BoneModificationMode::BMM_Ignore;
	EC7BoneModificationMode Additive = EC7BoneModificationMode::BMM_Additive;
	// EC7BoneModificationMode ScaleMode = EC7BoneModificationMode::BMM_Ignore;
	
	UpdateModifyBoneAutoAdd(FCommonHumanSkeletonBoneNames::GetHead(), Ignore, Additive, Ignore, EBoneControlSpace::BCS_BoneSpace, 0, 0, 0, Head.Pitch, Head.Yaw, Head.Roll, 1, 1, 1, NAME_None, 1, 1);
	UpdateModifyBoneAutoAdd(FCommonHumanSkeletonBoneNames::GetPelvis(), Ignore, Additive, Ignore, EBoneControlSpace::BCS_BoneSpace, 0, 0, 0, Body.Pitch, Body.Yaw, Body.Roll, 1, 1, 1, NAME_None, 1, 1);
	UpdateModifyBoneAutoAdd(FCommonHumanSkeletonBoneNames::GetSpine_01(), Ignore, Additive, Ignore, EBoneControlSpace::BCS_BoneSpace, 0, 0, 0, Spine_01.Pitch, Spine_01.Yaw, Spine_01.Roll, 1, 1, 1, NAME_None, 1, 1);
	UpdateModifyBoneAutoAdd(FCommonHumanSkeletonBoneNames::GetSpine_02(), Ignore, Additive, Ignore, EBoneControlSpace::BCS_BoneSpace, 0, 0, 0, Spine_02.Pitch, Spine_02.Yaw, Spine_02.Roll, 1, 1, 1, NAME_None, 1, 1);
	UpdateModifyBoneAutoAdd(FCommonHumanSkeletonBoneNames::GetSpine_03(), Ignore, Additive, Ignore, EBoneControlSpace::BCS_BoneSpace, 0, 0, 0, Spine_03.Pitch, Spine_03.Yaw, Spine_03.Roll, 1, 1, 1, NAME_None, 1, 1);

	// 眼部
	UpdateModifyBoneAutoAdd(FCommonHumanSkeletonBoneNames::GetLEyeBall(), Ignore, Additive, Ignore, EBoneControlSpace::BCS_BoneSpace, 0, 0, 0, Eye.Pitch, Eye.Yaw, Eye.Roll, 1, 1, 1, NAME_None, 1, 1);
	UpdateModifyBoneAutoAdd(FCommonHumanSkeletonBoneNames::GetREyeBall(), Ignore, Additive, Ignore, EBoneControlSpace::BCS_BoneSpace, 0, 0, 0, -Eye.Pitch, -Eye.Yaw, Eye.Roll, 1, 1, 1, NAME_None, 1, 1);

	UpdateModifyBoneAutoAdd(FCommonHumanSkeletonBoneNames::GetLEyeBall_01(), Ignore, Ignore, Additive, EBoneControlSpace::BCS_BoneSpace, 0, 0, 0, 0, 0, 0, EyeScale.X, EyeScale.Y, EyeScale.Z, NAME_None, 1, 1);
	UpdateModifyBoneAutoAdd(FCommonHumanSkeletonBoneNames::GetREyeBall_01(), Ignore, Ignore, Additive, EBoneControlSpace::BCS_BoneSpace, 0, 0, 0, 0, 0, 0, EyeScale.X, EyeScale.Y, EyeScale.Z, NAME_None, 1, 1);
}

void UBaseAnimInstance::AddTwoBoneIKParamSimply(FName IKBoneName, FName JointBoneName, float EL_X, float EL_Y, float EL_Z, FName AlphaCurveName, float AlphaCurveDefaultValue)
{
	if(BatchTwoBoneIKParams.Contains(IKBoneName))
	{
		UE_LOG(LogTemp, Error, TEXT("UBaseAnimInstance:AddTwoBoneIKParamSimply Already Has Two Bone IK: %s!!!!!"), *IKBoneName.ToString());
		return;
	}

	auto & TwoBoneIKParamValue = BatchTwoBoneIKParams.Emplace(IKBoneName);
	TwoBoneIKParamValue.EffectorLocation.Set(EL_X, EL_Y, EL_Z);
	TwoBoneIKParamValue.IKBone.BoneName = IKBoneName;
	TwoBoneIKParamValue.EffectorLocationSpace = EBoneControlSpace::BCS_WorldSpace;
	TwoBoneIKParamValue.JointTarget.BoneReference.BoneName = JointBoneName;
	TwoBoneIKParamValue.JointTargetLocationSpace = EBoneControlSpace::BCS_BoneSpace;
	TwoBoneIKParamValue.AlphaCurveName = AlphaCurveName;
	TwoBoneIKParamValue.AlphaDefaultValue = AlphaCurveDefaultValue;
	UpdateBatchIKAlpha();
}

void UBaseAnimInstance::AddAndResetTwoBoneIKParamSimply(FName IKBoneName, FName JointBoneName, float EL_X, float EL_Y,
	float EL_Z, FName AlphaCurveName, float AlphaCurveDefaultValue, const FVector& JointTargetLocation)
{
	if (BatchTwoBoneIKParams.Contains(IKBoneName))
	{
		BatchTwoBoneIKParams.Remove(IKBoneName);
	}

	auto & TwoBoneIKParamValue = BatchTwoBoneIKParams.Emplace(IKBoneName);
	TwoBoneIKParamValue.EffectorLocation.Set(EL_X, EL_Y, EL_Z);
	TwoBoneIKParamValue.IKBone.BoneName = IKBoneName;
	TwoBoneIKParamValue.EffectorLocationSpace = EBoneControlSpace::BCS_WorldSpace;
	TwoBoneIKParamValue.JointTarget.BoneReference.BoneName = JointBoneName;
	TwoBoneIKParamValue.JointTargetLocationSpace = EBoneControlSpace::BCS_BoneSpace;
	TwoBoneIKParamValue.JointTargetLocation = JointTargetLocation;
	TwoBoneIKParamValue.AlphaCurveName = AlphaCurveName;
	TwoBoneIKParamValue.AlphaDefaultValue = AlphaCurveDefaultValue;
	UpdateBatchIKAlpha();
}

void UBaseAnimInstance::AddOrUpdateTwoBoneIKParam(
	FName IKBoneName,
	EBoneControlSpace EffectorLocationSpace,
	bool bTakeRotationFromEffectorSpace ,
	FName EffectorTargetBoneName,
	EC7TwoBoneIKModificationMode EffectorLocationMode,
	const FVector & EffectorLocation,
	float StartStretchRatio,
	float MaxStretchScale,
	bool bAllowStretching,
	bool bMaintainEffectorRelRot,
	bool bAllowTwist,
	const FAxis & TwistAxis,
	EBoneControlSpace JointBoneControlSpace,
	FName JointTargetBoneName,
	const FVector & JointTargetLocation,
	float BlendAlpha,
	FName AlphaCurveName,
	float AlphaDefaultValue
	
)
{
	if(!BatchTwoBoneIKParams.Contains(IKBoneName))
	{
		BatchTwoBoneIKParams.Emplace(IKBoneName);
		UpdateBatchIKAlpha();
	}

	auto & TwoBoneIKParam = BatchTwoBoneIKParams[IKBoneName];
	TwoBoneIKParam.IKBone.BoneName = IKBoneName;
	TwoBoneIKParam.EffectorLocationSpace = EffectorLocationSpace;
	TwoBoneIKParam.bTakeRotationFromEffectorSpace = bTakeRotationFromEffectorSpace;
	TwoBoneIKParam.EffectorTarget.BoneReference.BoneName = EffectorTargetBoneName;
	TwoBoneIKParam.EffectorLocationMode = EffectorLocationMode;
	TwoBoneIKParam.EffectorLocation = EffectorLocation;
	TwoBoneIKParam.StartStretchRatio = StartStretchRatio;
	TwoBoneIKParam.MaxStretchScale = MaxStretchScale;
	TwoBoneIKParam.bAllowStretching = bAllowStretching;
	TwoBoneIKParam.bAllowTwist = bAllowTwist;
	TwoBoneIKParam.bMaintainEffectorRelRot = bMaintainEffectorRelRot;
	TwoBoneIKParam.TwistAxis = TwistAxis;
	TwoBoneIKParam.JointTargetLocationSpace = JointBoneControlSpace;
	TwoBoneIKParam.JointTarget.BoneReference.BoneName = JointTargetBoneName;
	TwoBoneIKParam.JointTargetLocation = JointTargetLocation;
	TwoBoneIKParam.BlendAlpha = BlendAlpha;
	TwoBoneIKParam.AlphaCurveName = AlphaCurveName;
	TwoBoneIKParam.AlphaDefaultValue = AlphaDefaultValue;
}


bool UBaseAnimInstance::HasTwoBoneIK(const FName& IKBoneName)
{
	return BatchTwoBoneIKParams.Contains(IKBoneName);
}

void UBaseAnimInstance::AddTwoBoneIKParamByAdditiveEffectorMode(FName IKBoneName, FName JointBoneName, float EL_X, float EL_Y, float EL_Z, FName AlphaCurveName, float AlphaCurveDefaultValue)
{
	AddOrUpdateTwoBoneIKParam(
		IKBoneName, 
		EBoneControlSpace::BCS_WorldSpace,
		false,
		IKBoneName, 
		EC7TwoBoneIKModificationMode::TBMM_Additive,
		FVector(EL_X, EL_Y, EL_Z), 
		1.0f,
		1.2f,
		false,
		false,
		true,
		FAxis(FVector::ForwardVector),
		EBoneControlSpace::BCS_BoneSpace,
		JointBoneName,
		FVector::Zero(),
		1.0f,
		AlphaCurveName,
		AlphaCurveDefaultValue);
}

void UBaseAnimInstance::UpdateBoneAutoRotate(float DeltaTime)
{
	USkeletalMeshComponent* SkelMeshComp = GetSkelMeshComponent();
	if (!SkelMeshComp)return;

	for (auto& Kvp : MapOfBoneAutoRotate)
	{
		FName BoneName = Kvp.Key;
		auto RotateConfig = Kvp.Value;
		float Speed = RotateConfig.RotateSpeed;
		ETransformOperateMask RotateAxesMask = RotateConfig.RotateAxesMask;
		const FRotator* RotateAxesCache = BoneAutoRotateAxesCacheMap.Find(BoneName);
		if (!RotateAxesCache) {
			continue;
		}
		float Pitch = RotateAxesCache->Pitch;
		float Yaw = RotateAxesCache->Yaw;
		float Roll = RotateAxesCache->Roll;

		if (EnumHasAnyFlags(RotateAxesMask, ETransformOperateMask::PITCH))
		{
			Pitch += Speed * DeltaTime;
			Pitch = FMath::Fmod(Pitch, 360.f);
		}

		if (EnumHasAnyFlags(RotateAxesMask, ETransformOperateMask::YAW))
		{
			Yaw += Speed * DeltaTime;
			Yaw = FMath::Fmod(Yaw, 360.f);
		}

		if (EnumHasAnyFlags(RotateAxesMask, ETransformOperateMask::ROLL))
		{
			Roll += Speed * DeltaTime;
			Roll = FMath::Fmod(Roll, 360.f);
		}
		BoneAutoRotateAxesCacheMap.Add(BoneName, { Pitch, Yaw, Roll });
		if (EnumHasAnyFlags(RotateAxesMask, ETransformOperateMask::ROTATION_MASK))
		{
			EC7BoneModificationMode Ignore = EC7BoneModificationMode::BMM_Ignore;
			EC7BoneModificationMode Replace = EC7BoneModificationMode::BMM_Replace;
			UpdateModifyBoneAutoAdd(BoneName, Ignore, Replace, Ignore, EBoneControlSpace::BCS_BoneSpace,
				0, 0, 0, Pitch, Yaw, Roll, 1, 1, 1, NAME_None, 1, 1);
		}
	}
}

void UBaseAnimInstance::AddBoneAutoRotate(FName BoneName, float RotateSpeed, ETransformOperateMask RotateAxesMask)
{
	MapOfBoneAutoRotate.FindOrAdd(BoneName, { RotateSpeed, RotateAxesMask });
	if (!BoneAutoRotateAxesCacheMap.Find(BoneName)) {
		BoneAutoRotateAxesCacheMap.Add(BoneName, {0, 0, 0});
	}
}

void UBaseAnimInstance::RemoveBoneAutoRotate(FName BoneName, bool bReset)
{
	MapOfBoneAutoRotate.Remove(BoneName);

	if (bReset)
	{	
		BoneAutoRotateAxesCacheMap.Remove(BoneName);
		RemoveModifyBone(BoneName);
	}
}

void UBaseAnimInstance::UpdateTwoBoneIKParamSimply(FName IKBoneName, float EL_X, float EL_Y, float EL_Z, float Alpha)
{
	if(!BatchTwoBoneIKParams.Contains(IKBoneName))
	{
		return;
	}

	BatchTwoBoneIKParams[IKBoneName].EffectorLocation.Set(EL_X, EL_Y, EL_Z);
	BatchTwoBoneIKParams[IKBoneName].BlendAlpha = Alpha;
}

void UBaseAnimInstance::UpdateTwoBoneIKParamSimply(FName IKBoneName, const FVector& TargetPos, float Alpha)
{
	if(!BatchTwoBoneIKParams.Contains(IKBoneName))
	{
		return;
	}

	BatchTwoBoneIKParams[IKBoneName].EffectorLocation = TargetPos;
	BatchTwoBoneIKParams[IKBoneName].BlendAlpha = Alpha;
}

void UBaseAnimInstance::UpdateTwoBoneIKParamSimplyOnlyAlpha(FName IKBoneName, float Alpha)
{
	if(!BatchTwoBoneIKParams.Contains(IKBoneName))
	{
		return;
	}

	BatchTwoBoneIKParams[IKBoneName].BlendAlpha = Alpha;
}

void UBaseAnimInstance::RemoveTwoBoneIKParam(FName IKBoneName)
{
	if(!BatchTwoBoneIKParams.Contains(IKBoneName))
	{
		return;
	}

	BatchTwoBoneIKParams.Remove(IKBoneName);
	UpdateBatchIKAlpha();
}

void UBaseAnimInstance::UpdateRideMountIkInfo(URoleMovementComponent* RoleMCPtr, APawn* OwnerPtr)
{
	if (!RoleMCPtr || !OwnerPtr) return;

	const bool bEnabledIk = HandFootIKConfig.bEnableHandIK or HandFootIKConfig.bEnableFootIK;
	if (bEnabledIk)
	{
		const FRideMountContextInfo MountContextInfo = RoleMCPtr->GetRoleMP().GetMovementContext().GetRideMountContextInfo();
		if (!MountMeshPtr.IsValid())
		{
			MountMeshPtr = Cast<USkeletalMeshComponent>(UKGObjectActorManager::GetInstance(this)->GetObjectByID(MountContextInfo.SkeletalMeshID));
		}

		if (!MountMeshPtr.IsValid())
		{
			return;
		}

		TArray<FName> IKBoneArray;
		TArray<FName> IKJointBoneArray;
		TArray<FName> TargetBoneArray;
		TArray<FName> AlphaCurveNameArray;
		TArray<float> CurveDefaultValueArray;

		if (HandFootIKConfig.MountHandLBoneName != NAME_None)
		{
			IKBoneArray.Add(HandFootIKConfig.HandLBoneName);
			IKJointBoneArray.Add(HandFootIKConfig.HandLJointBoneName);
			TargetBoneArray.Add(HandFootIKConfig.MountHandLBoneName);
			AlphaCurveNameArray.Add(HandFootIKConfig.bEnableHandIK ? DisableLHandIKCurveName : EnableLHandIKCurveName);
			CurveDefaultValueArray.Add(HandFootIKConfig.bEnableHandIK ? 1 : 0);
		}
		
		if (HandFootIKConfig.MountHandRBoneName != NAME_None)
		{
			IKBoneArray.Add(HandFootIKConfig.HandRBoneName);
			IKJointBoneArray.Add(HandFootIKConfig.HandRJointBoneName);
			TargetBoneArray.Add(HandFootIKConfig.MountHandRBoneName);
			AlphaCurveNameArray.Add(HandFootIKConfig.bEnableHandIK ? DisableRHandIKCurveName : EnableRHandIKCurveName);
			CurveDefaultValueArray.Add(HandFootIKConfig.bEnableHandIK ? 1 : 0);
		}

		if (HandFootIKConfig.MountFootLBoneName != NAME_None)
		{
			IKBoneArray.Add(HandFootIKConfig.FootLBoneName);
			IKJointBoneArray.Add(HandFootIKConfig.FootLJointBoneName);
			TargetBoneArray.Add(HandFootIKConfig.MountFootLBoneName);
			AlphaCurveNameArray.Add(HandFootIKConfig.bEnableFootIK ? DisableLFootIKCurveName : EnableLFootIKCurveName);
			CurveDefaultValueArray.Add(HandFootIKConfig.bEnableFootIK ? 1 : 0);
		}

		if (HandFootIKConfig.MountFootRBoneName != NAME_None)
		{
			IKBoneArray.Add(HandFootIKConfig.FootRBoneName);
			IKJointBoneArray.Add(HandFootIKConfig.FootRJointBoneName);
			TargetBoneArray.Add(HandFootIKConfig.MountFootRBoneName);
			AlphaCurveNameArray.Add(HandFootIKConfig.bEnableFootIK ? DisableRFootIKCurveName : EnableRFootIKCurveName);
			CurveDefaultValueArray.Add(HandFootIKConfig.bEnableFootIK ? 1 : 0);
		}

		for (int i=0; i<IKBoneArray.Num(); i++)
		{
			FVector TargetLocation = MountMeshPtr->GetSocketTransform(TargetBoneArray[i]).GetLocation();
			FName IKBoneName = IKBoneArray[i];
			if (BatchTwoBoneIKParams.Contains(IKBoneName))
			{
				UpdateTwoBoneIKParamSimply(IKBoneName, TargetLocation, 1);
			}
			else
			{
				AddTwoBoneIKParamSimply(IKBoneName, IKJointBoneArray[i], TargetLocation.X, TargetLocation.Y, TargetLocation.Z, AlphaCurveNameArray[i], CurveDefaultValueArray[i]);
			}
		}
		
	}
	else if (MountMeshPtr.IsValid())
	{
		MountMeshPtr.Reset();
	}
}

void UBaseAnimInstance::UpdateBatchIKAlpha()
{
	if(BonesModifyMap.Num() > 0 || BatchTwoBoneIKParams.Num() > 0)
	{
		BatchIKAlpha = 1.0f;
	}
	else
	{
		BatchIKAlpha = 0.0f;
	}
}

void UBaseAnimInstance::UpdateBodyLeanAlpha(URoleMovementComponent* RoleMCPtr, float DeltaSeconds)
{
	if (!bEnableCalculateBodyLean && FMath::IsNearlyZero(BodyLeanAlpha)) return;

	float RelAngle = 0.f;
	FRotator CurrentRotator = RoleMCPtr->GetActorTransform().GetRotation().Rotator();

	if (bEnableCalculateBodyLean)
	{
		if (BodyLeanAxisDataSource == EBodyLeanAxisDataSource::FaceRadian)
		{
			RelAngle = FMath::RadiansToDegrees(FaceAndDriveDiffRadian);
		}
		else if (BodyLeanAxisDataSource == EBodyLeanAxisDataSource::AngleAccumulate)
		{
			float DeltaAngle = MathFormula::ClosetYawSignedDiff(LastFrameAnimRotator.Yaw, CurrentRotator.Yaw);
			if (FMath::IsNearlyZero(DeltaAngle))
			{
				InputRelAngleAccumulate = MathFormula::DecayValue(InputRelAngleAccumulate, 0, RelAngleAccumulateEasyOutHalfTime, DeltaSeconds);
			}
			else
			{
				InputRelAngleAccumulate += DeltaAngle;
				InputRelAngleAccumulate = FMath::Clamp(InputRelAngleAccumulate, -90, 90);
			}
			RelAngle = InputRelAngleAccumulate;
		}
		else if (BodyLeanAxisDataSource == EBodyLeanAxisDataSource::DestAngle)
		{
			bool bHasTargetRotation = false;
			float TargetYaw = 0.f;
			RoleMCPtr->GetTargetDirectionParam(bHasTargetRotation, TargetYaw);
			if (bHasTargetRotation)
			{
				RelAngle = MathFormula::ClosetYawSignedDiff(CurrentRotator.Yaw, TargetYaw);	
			}
		}
	}
	
	// 计算姿态倾斜
	float BodyLeanTargetAxis = 0.f;
	float PostureRate = AnimMovePosture < MovePostureRate.Num() ? PostureRate = MovePostureRate[AnimMovePosture] : 1;
	if (RoleMCPtr->GetIsLocoStart() && FMath::Abs(RelAngle) > EnableLeanMinAngle)
	{
		FVector TargetVector = FRotator(0, RelAngle, 0).Vector().GetSafeNormal() * PostureRate;
		BodyLeanTargetAxis = TargetVector.Y;
	}
	float BodyLeanInterpHalfTime = BodyLeanAlpha * BodyLeanTargetAxis < 0 ? BodyLeanEasyInInterpHalfTime : (FMath::Abs(BodyLeanTargetAxis) > FMath::Abs(BodyLeanAlpha) ? BodyLeanEasyInInterpHalfTime : BodyLeanEasyOutInterpHalfTime);
	BodyLeanAlpha = MathFormula::DecayValue(BodyLeanAlpha, BodyLeanTargetAxis, BodyLeanInterpHalfTime, DeltaSeconds);
}

void UBaseAnimInstance::UpdateRelInputAxis(URoleMovementComponent* RoleMCPtr)
{
	RelInputAxisToForward = 0.f;
	RelInputAxisToRight = 0.f;
	
	if (!bEnableCalculateInputAxis || !RoleMCPtr->GetIsLocoStart()) return;
	
	float InputAxisRelAngle = 0.f;
	if (BodyLeanAxisDataSource == EBodyLeanAxisDataSource::FaceRadian)
	{
		InputAxisRelAngle = FMath::RadiansToDegrees(FaceAndDriveDiffRadian);
	}
	else if (BodyLeanAxisDataSource == EBodyLeanAxisDataSource::AngleAccumulate)
	{
		const FRotator CurrentRotator = RoleMCPtr->GetActorTransform().GetRotation().Rotator();
		const FRotator VelocityRot = RoleMCPtr->Velocity.GetSafeNormal2D().Rotation();
		InputAxisRelAngle = MathFormula::ClosetYawSignedDiff(CurrentRotator.Yaw, VelocityRot.Yaw);
	}

	// 计算输入轴向
	FVector TargetVector = FRotator(0, InputAxisRelAngle, 0).Vector().GetSafeNormal();
	RelInputAxisToForward = TargetVector.X;
	RelInputAxisToRight = TargetVector.Y;
}

#pragma endregion 

#pragma region Dialogue
void UBaseAnimInstance::DialogueCrossfadeToStage(EDialogueStage DialogueStage, bool bCrossInstance)
{
	if (CurDialogueStage == DialogueStage)
	{
		return;
	}
	CurDialogueStage = DialogueStage;
	
	switch (DialogueStage)
	{
	case EDialogueStage::Idle:
		CrossfadeInFixedTime(LocomotionStatemachineName, DialogueMoveIdleState, bCrossInstance ? 0 : CrossTimeOfIdle);
		break;
	case EDialogueStage::MoveStart:
		CrossfadeInFixedTime(LocomotionStatemachineName, DialogueMoveStartState, bCrossInstance ? 0 : CrossTimeOfStart);
		break;
	case EDialogueStage::MoveLoop:
		CrossfadeInFixedTime(LocomotionStatemachineName, DialogueMoveLoopState, bCrossInstance ? 0 : CrossTimeOfLoop);
		break;
	case EDialogueStage::MoveEnd:
		CrossfadeInFixedTime(LocomotionStatemachineName, DialogueMoveEndState, bCrossInstance ? 0 : CrossTimeOfEnd);
		break;
	case EDialogueStage::None:
		break;
	default:
		break;
	}
}

void UBaseAnimInstance::DialogueUpdateStagePercent(EDialogueStage DialogueStage, float Percent)
{
	if (CurDialogueStage != DialogueStage) return;
	
	switch (DialogueStage)
	{
	case EDialogueStage::Idle:
		UAnimInstance::SetAllSequencePlayerProgressInStateNode(LocomotionStatemachineName, DialogueMoveIdleState, Percent);
		break;
	case EDialogueStage::MoveStart:
		UAnimInstance::SetAllSequencePlayerProgressInStateNode(LocomotionStatemachineName, DialogueMoveStartState, Percent);
		break;
	case EDialogueStage::MoveLoop:
		UAnimInstance::SetAllSequencePlayerProgressInStateNode(LocomotionStatemachineName, DialogueMoveLoopState, Percent);
		break;
	case EDialogueStage::MoveEnd:
		UAnimInstance::SetAllSequencePlayerProgressInStateNode(LocomotionStatemachineName, DialogueMoveEndState, Percent);
		break;
	case EDialogueStage::None:
		break;
	default:
		break;
	}
}

void UBaseAnimInstance::UpdateSequenceStartTime(float StartTime, float StartToLoopTime, float LoopToEndTime)
{
	SequenceBeginStartTime = StartTime;
	SequenceStartToLoopStartTime = StartToLoopTime;
	SequenceLoopToEndStartTime = LoopToEndTime;
}

#pragma endregion Dialogue

#pragma region LayerManagement

UBaseAnimLayer*  UBaseAnimInstance::LinkFeatureAnimLayer(FName FeatureLayerTag, TSubclassOf<UAnimInstance> InClass) {
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UBaseAnimInstance::LinkFeatureAnimLayer");
	if (FeatureAnimLayers.Contains(FeatureLayerTag)) {
		UE_LOG(UBaseAnimInstanceLog, Warning, TEXT("UBaseAnimInstance::LinkFeatureAnimLayer Already Linked Feature Layer :%s "), *FeatureLayerTag.ToString());
		return nullptr;
	}

	if (!InClass.Get()) {
		UE_LOG(UBaseAnimInstanceLog, Warning, TEXT("UBaseAnimInstance::LinkFeatureAnimLayer InClass Is Null. Layer Feature: %s"), *FeatureLayerTag.ToString());
		return nullptr;
	}
	
	LinkAnimClassLayers(InClass);

	auto* CurAnimInst = GetLinkedAnimGraphInstanceByTag(FeatureLayerTag);
	if (!CurAnimInst) {
		UE_LOG(UBaseAnimInstanceLog, Warning, TEXT("UBaseAnimInstance::LinkFeatureAnimLayer Link Feature Fail. Layer Feature Is Null.  Layer Feature:%s"), *FeatureLayerTag.ToString());
		return nullptr;
	}

	auto * featureAnimLayer = Cast<UBaseAnimLayer>(CurAnimInst);
	if (!featureAnimLayer) {
		UE_LOG(UBaseAnimInstanceLog, Warning, TEXT("UBaseAnimInstance::LinkFeatureAnimLayer Should Use UBaseAnimLayer For Feature Layer :%s"), *FeatureLayerTag.ToString());
		return nullptr;
	}

	FeatureAnimLayers.Emplace(FeatureLayerTag, featureAnimLayer);
	return featureAnimLayer;
}

bool UBaseAnimInstance::UnlinkFeatureAnimLayer(FName FeatureLayerTag) {
	if (!FeatureAnimLayers.Contains(FeatureLayerTag)) {
		return false;
	}

	TWeakObjectPtr<UBaseAnimLayer> featureLayerWeakPtr = FeatureAnimLayers[FeatureLayerTag];
	FeatureAnimLayers.Remove(FeatureLayerTag);

	if (!featureLayerWeakPtr.IsValid()) {
		UE_LOG(UBaseAnimInstanceLog, Warning, TEXT("UBaseAnimInstance::UnlinkFeatureAnimLayer Unexpected Feature Layer Is InValid:%s"), *FeatureLayerTag.ToString());
		return true;
	}
	
	UnlinkAnimClassLayers(featureLayerWeakPtr->GetClass());

	return true;
}

bool UBaseAnimInstance::HasLinkFeatureAnimLayer(FName FeatureLayerTag)
{
	return FeatureAnimLayers.Contains(FeatureLayerTag);
}

bool UBaseAnimInstance::SetFeatureAnimLayerBoolProperty(FName AnimLayerTag, FName PropName, bool bValue)
{
	if (!FeatureAnimLayers.Contains(AnimLayerTag)) {
		return false;
	}

	if (!FeatureAnimLayers[AnimLayerTag].IsValid()) {
		return false;
	}

	TWeakObjectPtr<UBaseAnimLayer> AnimLayer = FeatureAnimLayers[AnimLayerTag];
	if(FBoolProperty* TargetPropertyPtr = AnimLayer->GetPropertyPtr<FBoolProperty>(PropName))
	{
		void* PropertyValuePtr = TargetPropertyPtr->ContainerPtrToValuePtr<void>(AnimLayer.Get());
		TargetPropertyPtr->SetPropertyValue(PropertyValuePtr, bValue);
		return true;
	}

	return false;
}

bool UBaseAnimInstance::SetFeatureAnimLayerFloatProperty(FName AnimLayerTag, FName PropName, float value) {
	if (!FeatureAnimLayers.Contains(AnimLayerTag)) {
		return false;
	}

	if (!FeatureAnimLayers[AnimLayerTag].IsValid()) {
		return false;
	}

	return FeatureAnimLayers[AnimLayerTag]->SetFloatProperty(PropName, value);
}

bool UBaseAnimInstance::SetFeatureAnimLayerFloatPropertys(FName AnimLayerTag, const TMap<FName, float> & FloatContainer) {

	if (!FeatureAnimLayers.Contains(AnimLayerTag)) {
		return false;
	}

	if (!FeatureAnimLayers[AnimLayerTag].IsValid()) {
		return false;
	}

	return FeatureAnimLayers[AnimLayerTag]->SetFloatPropertys(FloatContainer);
}

void UBaseAnimInstance::EnableAnimFeatureLayer(FName AnimLayerTag)
{
	if (FeatureAnimLayers.Contains(AnimLayerTag) && FeatureAnimLayers[AnimLayerTag].IsValid()) {
		FeatureAnimLayers[AnimLayerTag]->SetEnableAnimLayerTick(true);
	}
}

void UBaseAnimInstance::DisableAnimFeatureLayer(FName AnimLayerTag)
{
	if (FeatureAnimLayers.Contains(AnimLayerTag) && FeatureAnimLayers[AnimLayerTag].IsValid()) {
		FeatureAnimLayers[AnimLayerTag]->SetEnableAnimLayerTick(false);
	}
}

UBaseAnimLayer* UBaseAnimInstance::GetFeatureAnimLayer(const FName& AnimLayerTag) {
	
	if (!FeatureAnimLayers.Contains(AnimLayerTag)) {
		return nullptr;
	}

	if (!FeatureAnimLayers[AnimLayerTag].IsValid()) {
		return nullptr;
	}

	return FeatureAnimLayers[AnimLayerTag].Get();
}

void UBaseAnimInstance::LinkFaceAnimFeatureAnimLayer(FName FeatureLayerTag, TSubclassOf<UAnimInstance> InClass)
{
	UBaseAnimLayer* Layer = LinkFeatureAnimLayer(FeatureLayerTag, InClass);
	if (!Layer) return;

	FaceAnimLayerWeakPtr = Cast<UFaceAnimLayer>(Layer);
}

bool UBaseAnimInstance::UnLinkFaceAnimFeatureAnimLayer(FName FeatureLayerTag)
{
	FaceAnimLayerWeakPtr.Reset();
	
	return UnlinkFeatureAnimLayer(FeatureLayerTag);
}

void UBaseAnimInstance::SetAnimLayerAnimAsset(FName AnimLayerTag, const TMap<FName, UAnimSequenceBase*>& InAnimMap)
{
	if (!FeatureAnimLayers.Contains(AnimLayerTag)) {
		return ;
	}

	if (!FeatureAnimLayers[AnimLayerTag].IsValid()) {
		return ;
	}

	FeatureAnimLayers[AnimLayerTag]->SetAnimLayerAnimAsset(InAnimMap);
}

void UBaseAnimInstance::SetDefaultPerformMode(int mode)
{
	if (FaceAnimLayerWeakPtr.IsValid())
	{
		FaceAnimLayerWeakPtr->SetDefaultPerformMode(mode);
	}
}

void UBaseAnimInstance::SetHighPriorityPerformMode(int mode)
{
	if (FaceAnimLayerWeakPtr.IsValid())
	{
		FaceAnimLayerWeakPtr->SetHighPriorityPerformMode(mode);
	}
}

void UBaseAnimInstance::UpdateChaosClothAndKawaii(bool bChaosClothPermit, bool ForceRecreateCloth, bool bKawaiiPermit, const FName& AnimLayerTag, bool HasKawaii, const FString& InClass)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UBaseAnimInstance::UpdateChaosClothAndKawaii");
	APawn* Actor = TryGetPawnOwner();

	if (!Actor)
	{
		UE_LOG(LogTemp, Error, TEXT("[AnimInstance] UpdateChaosClothAndKawaii : actor is not valid"));
		return;
	}

	TArray<USkeletalMeshComponent*> SkeletalMeshComponents;
	Actor->GetComponents<USkeletalMeshComponent>(SkeletalMeshComponents);
	
	if(bChaosClothPermit || bKawaiiPermit)
	{
		UKGCppAssetManager* CppAssetManager = UKGCppAssetManager::GetInstance(this);
		if (!CppAssetManager) {
			return;
		}
		
		UClass* AnimClassPtr = nullptr;
		if (HasKawaii) {
			AnimClassPtr = CppAssetManager->GetAnimABPClassCache(FName(InClass));
			if (!AnimClassPtr) {
				UE_LOG(LogTemp, Error, TEXT("[AnimInstance]  UpdateChaosClothAndKawaii: cannot Get Anim Class By Path:%s"), *InClass);
				return;
			}
		}

		TSubclassOf<UAnimInstance> AnimationClass(AnimClassPtr);
		
		if (bChaosClothPermit)
		{
			TSet<FString> ClothingNames;
			for (USkeletalMeshComponent* Component : SkeletalMeshComponents)
			{
				USkeletalMesh* SkeletalMesh = Component->GetSkeletalMeshAsset();
				if (!SkeletalMesh)
					continue;
			
				TArray<TObjectPtr<UClothingAssetBase>> ClothingAssets = SkeletalMesh->GetMeshClothingAssets();
				for (auto Asset : ClothingAssets)
				{
					if (Asset == nullptr) continue;
					ClothingNames.Add(Asset.GetName());
				}
			}
			
			for (USkeletalMeshComponent* Component : SkeletalMeshComponents)
			{
				USkeletalMesh* SkeletalMesh = Component->GetSkeletalMeshAsset();
				if (!SkeletalMesh)
					continue;
				
				if (!SkeletalMesh->GetMeshClothingAssets().IsEmpty())
				{
					Component->bDisableClothSimulation = false;
					Component->SetAllowClothActors(true);
					// 拼装流程默认会不允许布料进行创建处理, 所以开启布料的时候, 都要判断处理一下是否要创建
					//ForceRecreateCloth 会在变身中使用, 如果SK Com上的SkeletalAsset被替换, 那么cloth就要重新创建一次, 否则布料tick运算没有实际效果(应该是底层有hold数据判断,猜测是渲染侧)
					if (!Component->GetClothingSimulation() || ForceRecreateCloth) {
						Component->RecreateClothingActors();
					}
					
					//如果有独立动画蓝图，说明是挂接类型的SkeletalMesh，关闭冲突的Kawaii节点
					if(UAnimInstance* AnimIns = Cast<UAnimInstance>(Component->GetAnimInstance()))
					{
                        SetAttachMeshKawaiiAlphaFloatPropertys(AnimIns, KGUtils::GetIDByObject(Component), false);
					}
				}
				else
				{
					Component->SetAllowClothActors(false);
					Component->bDisableClothSimulation = true;
				}

				if (UAnimInstance* AnimIns = Cast<UAnimInstance>(Component->GetAnimInstance()))
                {
                    SetAttachMeshKawaiiWindScalePropertys(AnimIns);
                }
			}
			
			if(HasKawaii && IsValid(AnimationClass))
			{
				EnableKawaiiNodeMap.IgnoreValue.Reset();
				for (auto& ClothingConfig : this->ClothingToKawaiiMap)
				{
					bool bContains = false;
					
					for (const FString& ClothingName : ClothingNames)
					{
						if (ClothingName.Contains(ClothingConfig.Key))
						{
							bContains = true;
							break;
						}
					}

					if(UseKawaiiAllInOne)
					{
						if(bContains && ClothingToKawaiiNodeMap.Contains(ClothingConfig.Key))
						{
							TArray<FName>& KawaiiNode = ClothingToKawaiiNodeMap[ClothingConfig.Key];
							for (auto& NodeName : KawaiiNode)
							{
								EnableKawaiiNodeMap.IgnoreValue.Add(NodeName, true);
							}
						}
					}
					else
					{
						this->SetFeatureAnimLayerBoolProperty(AnimLayerTag, ClothingConfig.Value, !bContains);
					}
				}
				
				if(!this->HasLinkFeatureAnimLayer(AnimLayerTag))
				{
					const auto KawaiiLayer = this->LinkFeatureAnimLayer(AnimLayerTag, AnimationClass);
					this->SetMainMeshKawaiiAlphaFloatPropertys(KawaiiLayer);

					this->SetMainMeshKawaiiWindScalePropertys(KawaiiLayer);
				}
				else if(ForceRecreateCloth)
				{
					const auto KawaiiLayer = this->GetFeatureAnimLayer(AnimLayerTag);
					this->SetMainMeshKawaiiAlphaFloatPropertys(KawaiiLayer);

					this->SetMainMeshKawaiiWindScalePropertys(KawaiiLayer);
				}
			}

			//目前Kawaii蓝图中Hair部分不与Cloth互斥，就算是开关全关这里需要Enable
			this->EnableAnimFeatureLayer(AnimLayerTag);
		}
		else if (bKawaiiPermit)
		{
			for (USkeletalMeshComponent* Component : SkeletalMeshComponents)
			{
				Component->bDisableClothSimulation = true;
				Component->SetAllowClothActors(false);

				//如果有独立动画蓝图，说明是挂接类型的SkeletalMesh，打开冲突的Kawaii节点
				if(UAnimInstance* AnimIns = Cast<UAnimInstance>(Component->GetAnimInstance()))
				{
					SetAttachMeshKawaiiAlphaFloatPropertys(AnimIns, KGUtils::GetIDByObject(Component),true);

					SetAttachMeshKawaiiWindScalePropertys(AnimIns);
				}
			}
			
			if(HasKawaii && IsValid(AnimationClass))
			{
				if(!this->HasLinkFeatureAnimLayer(AnimLayerTag))
				{
					const auto KawaiiLayer = this->LinkFeatureAnimLayer(AnimLayerTag, AnimationClass);
					this->SetMainMeshKawaiiAlphaFloatPropertys(KawaiiLayer);

					this->SetMainMeshKawaiiWindScalePropertys(KawaiiLayer);
				}
				else if(ForceRecreateCloth)
				{
					const auto KawaiiLayer = this->GetFeatureAnimLayer(AnimLayerTag);
					this->SetMainMeshKawaiiAlphaFloatPropertys(KawaiiLayer);

					this->SetMainMeshKawaiiWindScalePropertys(KawaiiLayer);
				}
			}
			
			for (auto ClothingConfig : ClothingToKawaiiMap)
			{
				//对应AnimLayer没有相应开关，允许这种情况出现，输出Warning
				if (!this->SetFeatureAnimLayerBoolProperty(AnimLayerTag, ClothingConfig.Value, true))
				{
					UE_LOG(UBaseAnimInstanceLog, Warning, TEXT("UBaseAnimInstance:: Kawaii Layer not find Property Name:%s  AnimationClass:%s"), *ClothingConfig.Value.ToString(), *InClass);
				}
			}

			this->EnableAnimFeatureLayer(AnimLayerTag);
		}
	}
	else
	{
		for (USkeletalMeshComponent* Component : SkeletalMeshComponents)
		{
			Component->bDisableClothSimulation = true;
			Component->SetAllowClothActors(false);
		}
		
		this->DisableAnimFeatureLayer(AnimLayerTag);
	}

	//这里放到最后处理，可能会出现原本的ModelID有kawaii，后面的没有了，所以这里最后要Disable
	if (!HasKawaii)
	{
		this->DisableAnimFeatureLayer(AnimLayerTag);
	}
}

void UBaseAnimInstance::DisableChaosClothAndKawaii(const FName& AnimLayerTag)
{
	APawn* Actor = TryGetPawnOwner();

	if (!Actor)
	{
		UE_LOG(LogTemp, Error, TEXT("[AnimInstance] DisableChaosClothAndKawaii : actor is not valid"));
		return;
	}

	TArray<USkeletalMeshComponent*> SkeletalMeshComponents;
	Actor->GetComponents<USkeletalMeshComponent>(SkeletalMeshComponents);

	for (USkeletalMeshComponent* Component : SkeletalMeshComponents)
	{
		Component->bDisableClothSimulation = true;
		Component->SetAllowClothActors(false);
	}

	this->DisableAnimFeatureLayer(AnimLayerTag);
}

void UBaseAnimInstance::UpdateIsEnableChaosClothByTag(const FName& ComponentTag, bool bEnable)
{
	if (auto Owner = TryGetPawnOwner())
	{
		TArray<UActorComponent*> MeshArray = Owner->GetComponentsByTag(USkeletalMeshComponent::StaticClass(), ComponentTag);
		for (auto Mesh : MeshArray)
		{
			if (USkeletalMeshComponent* MeshComponent = Cast<USkeletalMeshComponent>(Mesh))
			{
				MeshComponent->bDisableClothSimulation = !bEnable;
				MeshComponent->SetAllowClothActors(bEnable);
			}
		}
	}
}

void UBaseAnimInstance::UpdateIsVisibleClothByTag(const FName& ComponentTag, bool bVisible)
{
	if (auto Owner = TryGetPawnOwner())
	{
		TArray<UActorComponent*> MeshArray = Owner->GetComponentsByTag(USkeletalMeshComponent::StaticClass(), ComponentTag);
		for (auto Mesh : MeshArray)
		{
			if (USkeletalMeshComponent* MeshComponent = Cast<USkeletalMeshComponent>(Mesh))
			{
				MeshComponent->SetHiddenInGame(!bVisible);
			}
		}
	}
}

bool UBaseAnimInstance::SetMainMeshKawaiiAlphaFloatPropertys(UBaseAnimLayer* AnimLayer)
{
	if(!AnimLayer || !EnableMainMeshKawaiiOptimize)
	{
		return false;
	}

	if(const FBoolProperty* PropertyPtr = AnimLayer->GetPropertyPtr<FBoolProperty>(KawaiiAllInOnePropName))
	{
		void* PropertyValuePtr = PropertyPtr->ContainerPtrToValuePtr<void>(AnimLayer);
		PropertyPtr->SetPropertyValue(PropertyValuePtr, UseKawaiiAllInOne);
	}

	if(const FBoolProperty* PropertyPtr = AnimLayer->GetPropertyPtr<FBoolProperty>(KawaiiEnableASkirtControlRigPropName))
	{
		void* PropertyValuePtr = PropertyPtr->ContainerPtrToValuePtr<void>(AnimLayer);
		PropertyPtr->SetPropertyValue(PropertyValuePtr, EnableASkirtControlRig);
	}

	if(IsValid(OwnerCharacter))
	{
		if(UseKawaiiAllInOne)
		{
			EnableKawaiiNodeMap.EnableValue.Reset();
			if(const FStructProperty* PropertyPtr = AnimLayer->GetPropertyPtr<FStructProperty>(KawaiiEnableNodeNameMapPropName))
			{
				for(auto& AlphaEnableMap : OwnerCharacter->MainMeshKawaiiAlphaEnableMap)
				{
					if(AlphaEnableMap.Value.Num()>0)
					{
						EnableKawaiiNodeMap.EnableValue.Add(AlphaEnableMap.Key, true);
					}
				}
		
				// 获取目标对象中该属性的内存地址
				void* DestPtr = PropertyPtr->ContainerPtrToValuePtr<void>(AnimLayer);
				// 使用 CopySingleValue (推荐用于简单结构体)
				PropertyPtr->CopySingleValue(DestPtr, &EnableKawaiiNodeMap);
			}
		}
		else
		{
			for (TFieldIterator<FProperty> It(AnimLayer->GetClass(), EFieldIteratorFlags::IncludeSuper); It; ++It)
			{
				if (const FDoubleProperty* DoubleProperty = CastField<FDoubleProperty>(*It))
				{
					FString PropertyNameStr = DoubleProperty->GetName();
					FName PropertyName = DoubleProperty->GetFName();
					if(PropertyNameStr.Contains(KawaiiAlphaPrefix))
					{
						void* PropertyValuePtr = DoubleProperty->ContainerPtrToValuePtr<void>(AnimLayer);
						if(OwnerCharacter->MainMeshKawaiiAlphaEnableMap.Contains(PropertyName) && OwnerCharacter->MainMeshKawaiiAlphaEnableMap[PropertyName].Num() > 0)
						{
							DoubleProperty->SetPropertyValue(PropertyValuePtr, 1.0f);
						}
						else
						{
							DoubleProperty->SetPropertyValue(PropertyValuePtr, 0.0f);
						}
					}
				}
			}
		}
	}
	
	return true;
}

void UBaseAnimInstance::SetAttachMeshKawaiiAlphaKeys(const int64& MeshComID, const TArray<FName>& KawaiiAlphaEnableArray, bool Enable, float WindScale)
{
	AttachMeshKawaiiAlphaDisableMap.Remove(MeshComID);
	if(Enable)
	{
		auto& Value = AttachMeshKawaiiAlphaDisableMap.FindOrAdd(MeshComID);
		for(auto KawaiiAlphaEnable: KawaiiAlphaEnableArray )
		{
			Value.Add(KawaiiAlphaEnable);

			// set wind scale
            {
                FString KawaiiBoneStr = KawaiiAlphaEnable.ToString();
                KawaiiBoneStr.ReplaceInline(*KawaiiAlphaPrefix, TEXT(""));
                FName KawaiiBoneName = FName(KawaiiBoneStr);

                auto& WindScaleValue = AttachMeshKawaiiWindScaleMap.FindOrAdd(KawaiiBoneName);
                WindScaleValue = WindScale;
            }
		}
	}
}

bool UBaseAnimInstance::SetAttachMeshKawaiiAlphaFloatPropertys(UAnimInstance* AnimInstance,const int64& MeshComID, bool Enable)
{
	if(!AttachMeshKawaiiAlphaDisableMap.Contains(MeshComID) || !EnableAttachMeshKawaiiOptimize)
	{
		return false;
	}

	auto KawaiiAlphaDisableSet = AttachMeshKawaiiAlphaDisableMap[MeshComID];

	for (TFieldIterator<FProperty> It(AnimInstance->GetClass(), EFieldIteratorFlags::IncludeSuper); It; ++It)
	{
		if (const FDoubleProperty* DoubleProperty = CastField<FDoubleProperty>(*It))
		{
			FString PropertyNameStr = DoubleProperty->GetName();
			FName PropertyName = DoubleProperty->GetFName();
			if(PropertyNameStr.Contains(KawaiiAlphaPrefix))
			{
				void* PropertyValuePtr = DoubleProperty->ContainerPtrToValuePtr<void>(AnimInstance);
				if(KawaiiAlphaDisableSet.Contains(PropertyName))
				{
					DoubleProperty->SetPropertyValue(PropertyValuePtr, Enable ? 1.0f : 0.0f);
				}
				else
				{
					DoubleProperty->SetPropertyValue(PropertyValuePtr, 0.0f);
				}
			}
		}
	}
	return true;
}

bool UBaseAnimInstance::SetMainMeshKawaiiWindScalePropertys(UBaseAnimLayer* AnimLayer)
{
    if (!AnimLayer || !EnableMainMeshKawaiiOptimize)
    {
        return false;
    }

    if (IsValid(OwnerCharacter))
    {
        if (const FMapProperty* MapPropertyPtr = AnimLayer->GetPropertyPtr<FMapProperty>(PresetTypeWindScalePropName))
        {
            void* MapContainerPtr = MapPropertyPtr->ContainerPtrToValuePtr<void>(AnimLayer);
            FScriptMapHelper MapHelper(MapPropertyPtr, MapContainerPtr);

            for (const auto& Pair : OwnerCharacter->MainMeshKawaiiWindScaleMap)
            {
                int32 FoundIndex = INDEX_NONE;
                for (int32 Index = 0; Index < MapHelper.GetMaxIndex(); ++Index)
                {
                    if (MapHelper.IsValidIndex(Index))
                    {
                        void* KeyPtr = MapHelper.GetKeyPtr(Index);
                        void* ValuePtr = MapHelper.GetValuePtr(Index);

                        FName Key = *reinterpret_cast<FName*>(KeyPtr);
                        if (Key == Pair.Key)
                        {
                            FoundIndex = Index;
                            break;
                        }
                    }
                }

				if (FoundIndex != INDEX_NONE)
                {
                    void* ValuePtr = MapHelper.GetValuePtr(FoundIndex);
                    FDoubleProperty* ValueProp = CastFieldChecked<FDoubleProperty>(MapPropertyPtr->ValueProp);

                    ValueProp->SetPropertyValue(ValuePtr, Pair.Value);
                }
                else
                {
                    int32 NewIndex = MapHelper.AddDefaultValue_Invalid_NeedsRehash();
                    void* KeyPtr = MapHelper.GetKeyPtr(NewIndex);
                    void* ValuePtr = MapHelper.GetValuePtr(NewIndex);
                    FNameProperty* KeyProp = CastFieldChecked<FNameProperty>(MapPropertyPtr->KeyProp);
                    FDoubleProperty* ValueProp = CastFieldChecked<FDoubleProperty>(MapPropertyPtr->ValueProp);
                    
					KeyProp->SetPropertyValue(KeyPtr, Pair.Key);
                    ValueProp->SetPropertyValue(ValuePtr, Pair.Value);
                }
                MapHelper.Rehash();
            }
        }
    }

    return true;
}

bool UBaseAnimInstance::SetAttachMeshKawaiiWindScalePropertys(UAnimInstance* AnimInstance)
{
    if (!AnimInstance || !EnableAttachMeshKawaiiOptimize)
    {
        return false;
    }

    for (TFieldIterator<FProperty> It(AnimInstance->GetClass(), EFieldIteratorFlags::IncludeSuper); It; ++It)
    {
        if (const FMapProperty* MapPropertyPtr = CastField<FMapProperty>(*It))
        {
            FName PropertyName = MapPropertyPtr->GetFName();

			if (PropertyName == PresetTypeWindScalePropName)
			{
                void* MapContainerPtr = MapPropertyPtr->ContainerPtrToValuePtr<void>(AnimInstance);
                FScriptMapHelper MapHelper(MapPropertyPtr, MapContainerPtr);

				for (const auto& Pair : AttachMeshKawaiiWindScaleMap)
                {
                    int32 FoundIndex = INDEX_NONE;
                    for (int32 Index = 0; Index < MapHelper.GetMaxIndex(); ++Index)
                    {
                        if (MapHelper.IsValidIndex(Index))
                        {
                            void* KeyPtr = MapHelper.GetKeyPtr(Index);
                            void* ValuePtr = MapHelper.GetValuePtr(Index);

                            FName Key = *reinterpret_cast<FName*>(KeyPtr);
                            if (Key == Pair.Key)
                            {
                                FoundIndex = Index;
                                break;
                            }
                        }
                    }

                    if (FoundIndex != INDEX_NONE)
                    {
                        void* ValuePtr = MapHelper.GetValuePtr(FoundIndex);
                        FDoubleProperty* ValueProp = CastFieldChecked<FDoubleProperty>(MapPropertyPtr->ValueProp);

                        ValueProp->SetPropertyValue(ValuePtr, Pair.Value);
                    }
                    else
                    {
                        int32 NewIndex = MapHelper.AddDefaultValue_Invalid_NeedsRehash();
                        void* KeyPtr = MapHelper.GetKeyPtr(NewIndex);
                        void* ValuePtr = MapHelper.GetValuePtr(NewIndex);
                        FNameProperty* KeyProp = CastFieldChecked<FNameProperty>(MapPropertyPtr->KeyProp);
                        FDoubleProperty* ValueProp = CastFieldChecked<FDoubleProperty>(MapPropertyPtr->ValueProp);

                        KeyProp->SetPropertyValue(KeyPtr, Pair.Key);
                        ValueProp->SetPropertyValue(ValuePtr, Pair.Value);
                    }
                    MapHelper.Rehash();
                }
			}
        }
        else if (const FIntProperty* IntPropertyPtr = CastField<FIntProperty>(*It))
		{
            FName IntPropertyName = IntPropertyPtr->GetFName();

			if (IntPropertyName == ApplyWindScaleChangedCountName)
			{
                void* ValuePropertyPtr = IntPropertyPtr->ContainerPtrToValuePtr<void>(AnimInstance);
                int32 Value = *reinterpret_cast<int32*>(ValuePropertyPtr);

                IntPropertyPtr->SetPropertyValue(ValuePropertyPtr, Value + 1);
			}
		}
    }

    return true;
}

void UBaseAnimInstance::SetSyncSeerAnimParamToProfessionalComponent(bool bSyncAnim)
{
	bSyncSeerParam = bSyncAnim;
}

void UBaseAnimInstance::SetUseIdleFightABPVar(bool UseIdleFightABPVar)
{
	bUseIdleFightABPVar = UseIdleFightABPVar;
}

void UBaseAnimInstance::SetIsComplexMove(bool IsComplexMove)
{
	bComplexMove = IsComplexMove;
}

void UBaseAnimInstance::SetCommonLogicIndex(int LogicIndex)
{
	CommonLogicIndex = LogicIndex;
}

#pragma endregion



void UBaseAnimInstance::ConsumeRootMotionFromAnimation(FRootMotionMovementParams& OutExtractedRootMotion) {
	OutExtractedRootMotion = ConsumeExtractedRootMotion(1.0f);
	if (RootMotionMode == ERootMotionMode::IgnoreRootMotion)
	{
		// 在切换RootmotionMode为Ignore的临界情况下，可能会积累一帧的动画Rootmotion，这一帧需要丢弃
		OutExtractedRootMotion.Clear();
	}
}


void UBaseAnimInstance::SetAnimMovePostureAndPlayRate(int NewPosture, float NewPlayRate)
{
	if (NewPosture == AnimMovePosture)
	{
		MoveAnimPlayRate = NewPlayRate;
		if (RemainAnimMovePostureCacheTime < 0.0f) {
			DelayedMoveAnimPlayRate = MoveAnimPlayRate;
		}
		return;
	}

	// LocoStart为true时，Delay机制才生效
	if (DelayedAnimMovePostureCacheTime > 0.0f && IsLocoStart)
	{
		DelayedAnimMovePosture = AnimMovePosture;
		DelayedMoveAnimPlayRate = MoveAnimPlayRate;
		RemainAnimMovePostureCacheTime = DelayedAnimMovePostureCacheTime;
	}
	else
	{
		DelayedAnimMovePosture = NewPosture;
		DelayedMoveAnimPlayRate = NewPlayRate;
		RemainAnimMovePostureCacheTime = -1.0f;
	}
	UpdateDelayedAnimMovePosture();

	AnimMovePosture = NewPosture;
	MoveAnimPlayRate = NewPlayRate;
	UpdateAnimMovePosture();
}

void UBaseAnimInstance::InitBaseAnimInstanceParam()
{
	BatchIKAlpha = 0;
	ArmAdditiveAlpha = 0;
	
	IsSlaveAnimControl = false;
	bSyncSeerParam = false;
	
	HandFootIKConfig.Reset();
	BonesModifyMap.Reset();
	BatchTwoBoneIKParams.Reset();
	MapOfBoneAutoRotate.Reset();
	BoneAutoRotateAxesCacheMap.Reset();

	EnableALSFootIK = false;
	ForbiddenALSFootIKDuration = 0;
	EnableFootIKAlpha = 0.0f;
}

void UBaseAnimInstance::ResetToDefaultsForCache()
{
	InitBaseAnimInstanceParam();
}

void UBaseAnimInstance::InitLocomotionStateTypeMaps(const TMap<FName, uint8>& NewStateNameToStateTypeMap, const TMap<uint8, FName>& NewStateTypeToStateNameMap)
{
	if (bIsLocomotionStateTypeMapsInitialized)
	{
		return;
	}

	bIsLocomotionStateTypeMapsInitialized = true;

	StateNameToStateTypeMap = NewStateNameToStateTypeMap;
	StateTypeToStateNameMap = NewStateTypeToStateNameMap;
}

bool UBaseAnimInstance::IsLocomotionStateTypeMapsInitialized()
{
	return bIsLocomotionStateTypeMapsInitialized;
}

void UBaseAnimInstance::InitClothingToKawaiiMap(const TMap<FString, FName>& InClothingToKawaiiMap)
{
	bIsClothingToKawaiiMapInitialized = true;
	ClothingToKawaiiMap = InClothingToKawaiiMap;
	ClothingToKawaiiNodeMap.Reset();
}

void UBaseAnimInstance::InitClothingToKawaiiNodeMap(const FString InClothingToKawaiiKey, const TArray<FName>& KawaiiNodeMap)
{
	ClothingToKawaiiNodeMap.Add(InClothingToKawaiiKey,KawaiiNodeMap);
}

bool UBaseAnimInstance::IsClothingToKawaiiMapInitialized()
{
	return bIsClothingToKawaiiMapInitialized;
}

void UBaseAnimInstance::UpdateParentToChildStateMap(const TMap<FName, FName>& StateMachineReplace)
{
	ClearParentToChildStateMap();

	ParentToChildAnimStateReplace = StateMachineReplace;
}

void UBaseAnimInstance::ClearParentToChildStateMap()
{
	ParentToChildAnimStateReplace.Empty();
}

const FName& UBaseAnimInstance::GetParentToChildStateMachine(const FName& MachineName)
{
	if (ParentToChildAnimStateReplace.Contains(MachineName))
	{
		return ParentToChildAnimStateReplace[MachineName];
	}
	return MachineName;
}

float UBaseAnimInstance::Montage_PlayWithBasicParams(UAnimMontage* MontageToPlay, float blendInTime , bool isLoop, float InPlayRate,float InTimeToStartMontageAt, bool bStopAllMontages, EMontagePlayReturnType ReturnValueType) {

	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UBaseAnimInstance::Montage_PlayWithBasicParams");

	FMontageBlendSettings BlendSettings;
	if (MontageToPlay)
	{
		BlendSettings.Blend = MontageToPlay->BlendIn;
		BlendSettings.BlendMode = MontageToPlay->BlendModeIn;
		BlendSettings.BlendProfile = MontageToPlay->BlendProfileIn;
		
		BlendSettings.Blend.BlendTime = blendInTime;
	}

	if(FMath::IsNearlyZero(blendInTime) && MontageToPlay->SlotAnimTracks.Num() == 1)
	{
		const FName& ToPlaySlot = MontageToPlay->SlotAnimTracks[0].SlotName;
		for (int32 InstanceIndex = MontageInstances.Num() - 1; InstanceIndex > -1; --InstanceIndex)
		{
			FAnimMontageInstance* MontageInstance = MontageInstances[InstanceIndex];
			if (MontageInstance && MontageInstance->Montage && MontageInstance->Montage->IsValidSlot(ToPlaySlot))
			{
				MontageInstance->Stop(BlendSettings, true);
			}
		}
	}
	
	float returnValue = Montage_PlayInternal(MontageToPlay, BlendSettings, InPlayRate, ReturnValueType, InTimeToStartMontageAt, bStopAllMontages);

	if (isLoop) {
		FAnimMontageInstance* MontIns = GetActiveInstanceForMontage(MontageToPlay);
		if (MontIns)
		{
			MontIns->SetNextSectionName("Default", "Default");
		}
	}
	return returnValue;

}

float UBaseAnimInstance::Montage_PlayWithBasicParams(UAnimMontage* MontageToPlay, float blendInTime,
	EAlphaBlendOption blendOption, bool isLoop, float InPlayRate, float InTimeToStartMontageAt, bool bStopAllMontages,
	EMontagePlayReturnType ReturnValueType)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UBaseAnimInstance::Montage_PlayWithBasicParams");

	FMontageBlendSettings BlendSettings;
	if (MontageToPlay)
	{
		BlendSettings.Blend = MontageToPlay->BlendIn;
		BlendSettings.BlendMode = MontageToPlay->BlendModeIn;
		BlendSettings.BlendProfile = MontageToPlay->BlendProfileIn;
		
		BlendSettings.Blend.BlendTime = blendInTime;
		BlendSettings.Blend.BlendOption = blendOption;
	}

	if(FMath::IsNearlyZero(blendInTime) && MontageToPlay->SlotAnimTracks.Num() == 1)
	{
		const FName& ToPlaySlot = MontageToPlay->SlotAnimTracks[0].SlotName;
		for (int32 InstanceIndex = MontageInstances.Num() - 1; InstanceIndex > -1; --InstanceIndex)
		{
			FAnimMontageInstance* MontageInstance = MontageInstances[InstanceIndex];
			if (MontageInstance && MontageInstance->Montage && MontageInstance->Montage->IsValidSlot(ToPlaySlot))
			{
				MontageInstance->Stop(BlendSettings, true);
			}
		}
	}
	
	float returnValue = Montage_PlayInternal(MontageToPlay, BlendSettings, InPlayRate, ReturnValueType, InTimeToStartMontageAt, bStopAllMontages);

	if (isLoop) {
		FAnimMontageInstance* MontIns = GetActiveInstanceForMontage(MontageToPlay);
		if (MontIns)
		{
			MontIns->SetNextSectionName("Default", "Default");
		}
	}
	return returnValue;
}

float UBaseAnimInstance::Montage_PlayWithBasicParamsOnLayer(const FName& LayerName, UAnimMontage* MontageToPlay,
                                                            float blendInTime, bool isLoop, float InPlayRate,
                                                            float InTimeToStartMontageAt, bool bStopAllMontages,
                                                            EMontagePlayReturnType ReturnValueType)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UBaseAnimInstance::Montage_PlayWithBasicParamsOnLayer");

	UAnimInstance* TargetLayer = GetFeatureAnimLayer(LayerName);

	if(TargetLayer == nullptr)
	{
		UE_LOG(UBaseAnimInstanceLog, Log, TEXT("UBaseAnimInstance::Montage_PlayWithBasicParamsOnLayer Do Not Have Anim Layer:%s"), *LayerName.ToString());
		return 0.f;
	}

	if(FMath::IsNearlyZero(blendInTime) && MontageToPlay->SlotAnimTracks.Num() == 1)
	{
		const FName& ToPlaySlot = MontageToPlay->SlotAnimTracks[0].SlotName;
		for (int32 InstanceIndex = TargetLayer->MontageInstances.Num() - 1; InstanceIndex > -1; --InstanceIndex)
		{
			FAnimMontageInstance* MontageInstance = TargetLayer->MontageInstances[InstanceIndex];
			if (MontageInstance && MontageInstance->Montage && MontageInstance->Montage->IsValidSlot(ToPlaySlot))
			{
				FAlphaBlend Blend = MontageInstance->GetBlend();
				Blend.SetBlendTime(blendInTime);
				MontageInstance->Stop(Blend, true);
			}
		}
	}
	
	float returnValue = TargetLayer->Montage_PlayWithBlendIn(MontageToPlay, blendInTime, InPlayRate, ReturnValueType, InTimeToStartMontageAt, bStopAllMontages);

	if (isLoop) {
		if (FAnimMontageInstance* MontIns = TargetLayer->GetActiveInstanceForMontage(MontageToPlay))
		{
			MontIns->SetNextSectionName("Default", "Default");
		}
	}
	return returnValue;
}

float UBaseAnimInstance::Montage_PlayWithBasicParamsOnLayer(const FName& LayerName, UAnimMontage* MontageToPlay,
	float blendInTime, EAlphaBlendOption blendOption, bool isLoop, float InPlayRate, float InTimeToStartMontageAt,
	bool bStopAllMontages, EMontagePlayReturnType ReturnValueType)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UBaseAnimInstance::Montage_PlayWithBasicParamsOnLayer");

	UAnimInstance* TargetLayer = GetFeatureAnimLayer(LayerName);

	if(TargetLayer == nullptr)
	{
		UE_LOG(UBaseAnimInstanceLog, Log, TEXT("UBaseAnimInstance::Montage_PlayWithBasicParamsOnLayer Do Not Have Anim Layer:%s"), *LayerName.ToString());
		return 0.f;
	}

	if(FMath::IsNearlyZero(blendInTime) && MontageToPlay->SlotAnimTracks.Num() == 1)
	{
		const FName& ToPlaySlot = MontageToPlay->SlotAnimTracks[0].SlotName;
		for (int32 InstanceIndex = TargetLayer->MontageInstances.Num() - 1; InstanceIndex > -1; --InstanceIndex)
		{
			FAnimMontageInstance* MontageInstance = TargetLayer->MontageInstances[InstanceIndex];
			if (MontageInstance && MontageInstance->Montage && MontageInstance->Montage->IsValidSlot(ToPlaySlot))
			{
				FAlphaBlend Blend = MontageInstance->GetBlend();
				Blend.SetBlendTime(blendInTime);
				MontageInstance->Stop(Blend, true);
			}
		}
	}

	FAlphaBlendArgs BlendArgs{blendInTime};
	BlendArgs.BlendOption = blendOption;
	float returnValue = TargetLayer->Montage_PlayWithBlendIn(MontageToPlay, BlendArgs, InPlayRate, ReturnValueType, InTimeToStartMontageAt, bStopAllMontages);

	if (isLoop) {
		if (FAnimMontageInstance* MontIns = TargetLayer->GetActiveInstanceForMontage(MontageToPlay))
		{
			MontIns->SetNextSectionName("Default", "Default");
		}
	}
	return returnValue;
}

void UBaseAnimInstance::Montage_StopOnLayer(const FName& LayerName, float BlendOutTime, UAnimMontage* MontageToStop)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UBaseAnimInstance::Montage_PlayWithBasicParamsOnLayer");

	if(UAnimInstance* TargetLayer = GetFeatureAnimLayer(LayerName))
	{
		TargetLayer->Montage_Stop(BlendOutTime, MontageToStop);
	}
}

void UBaseAnimInstance::ForceExecuteNotifyStateEnd(FString NotifyStateName)
{	
	USkeletalMeshComponent* SkelMeshComp = GetSkelMeshComponent();
	TArray<int32> WillExecuteNotifyStateIndex;
	for (int32 Index = 0; Index < ActiveAnimNotifyState.Num(); ++Index)
	{
		const FAnimNotifyEvent& AnimNotifyEvent = ActiveAnimNotifyState[Index];
		if (NotifyStateName == AnimNotifyEvent.NotifyStateClass->GetClass()->GetName())
		{
			WillExecuteNotifyStateIndex.Add(Index);
		}
	}

	for (int32 Index = 0; Index < WillExecuteNotifyStateIndex.Num(); ++Index)
	{
		int32 NotifyStateIndex = WillExecuteNotifyStateIndex[Index];

		if (ActiveAnimNotifyState.IsValidIndex(NotifyStateIndex) == false)
		{
			UE_LOG(LogTemp, Error, TEXT("ActiveAnimNotifyState is invalid at index %d when ForceExecuteNotifyStateEnd %s!!!!!"), NotifyStateIndex, *NotifyStateName);
			return;
		}

		const FAnimNotifyEvent& AnimNotifyEvent = ActiveAnimNotifyState[NotifyStateIndex];
		const FAnimNotifyEventReference& EventReference = ActiveAnimNotifyEventReference[NotifyStateIndex];
		if (AnimNotifyEvent.NotifyStateClass && ShouldTriggerAnimNotifyState(AnimNotifyEvent.NotifyStateClass))
		{
			TRACE_ANIM_NOTIFY(this, AnimNotifyEvent, End);
			AnimNotifyEvent.NotifyStateClass->NotifyEnd(SkelMeshComp, Cast<UAnimSequenceBase>(AnimNotifyEvent.NotifyStateClass->GetOuter()), EventReference);
		}
	}

	for (int32 Index = WillExecuteNotifyStateIndex.Num() - 1; Index >= 0; --Index)
	{
		int32 NotifyStateIndex = WillExecuteNotifyStateIndex[Index];
		if (ActiveAnimNotifyState.IsValidIndex(NotifyStateIndex) == false)
		{
			UE_LOG(LogTemp, Error, TEXT("ActiveAnimNotifyState is invalid at index %d when ForceExecuteNotifyStateEnd %s!!!!!"), NotifyStateIndex, *NotifyStateName);
			return;
		}
		ActiveAnimNotifyState.RemoveAt(NotifyStateIndex);
		ActiveAnimNotifyEventReference.RemoveAt(NotifyStateIndex);
	}

}


void UBaseAnimInstance::LocomotionCrossfadeInFixedTime(int stateType, float transitionTime) {

	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UBaseAnimInstance_LocomotionCrossfadeInFixedTime");
	if (!UBaseAnimInstance::StateTypeToStateNameMap.Contains(stateType)) {
		UE_LOG(UBaseAnimInstanceLog, Warning, TEXT("UBaseAnimInstance::LocomotionCrossfadeInFixedTime StateType:%d"), stateType);
		return;
	}

	CrossfadeInFixedTime(LocomotionStatemachineName, UBaseAnimInstance::StateTypeToStateNameMap[stateType], transitionTime);
}

// 直接给locomotion的回调做逻辑定制
void UBaseAnimInstance::DoNotifyAnyStateChangedFromStateMachine(const FName& PrevStateNameOut, const FName& CurStateNameOut) {

	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UBaseAnimInstance_DoNotifyAnyStateChangedFromStateMachine");
	
	uint8 NewLocomotionStateType = 0;
	if (bIsALSMode)
	{
		 if(!ALSLocoNameToCommonLocoNameMap.Contains(CurStateNameOut))
		 {
			 return;
		 }

		 if (!StateNameToStateTypeMap.Contains(ALSLocoNameToCommonLocoNameMap[CurStateNameOut])) {
#if UE_BUILD_DEVELOPMENT
			 UE_LOG(UBaseAnimInstanceLog, Warning, TEXT("UBaseAnimInstance::DoNotifyAnyStateChangedFromStateMachine StateName:%s Without StateType Defined"), *(CurStateNameOut.ToString()));
#endif
			 return;
		 }
	}
	else
	{
		if (!StateNameToStateTypeMap.Contains(CurStateNameOut)) {
#if UE_BUILD_DEVELOPMENT
			UE_LOG(UBaseAnimInstanceLog, Warning, TEXT("UBaseAnimInstance::DoNotifyAnyStateChangedFromStateMachine StateName:%s Without StateType Defined"), *(CurStateNameOut.ToString()));
#endif
			return;
		}
	}

	auto* ownerPtr = TryGetPawnOwner();
	if (!ownerPtr) {
		return;
	}
	auto* pawnComPtr = ownerPtr->GetMovementComponent();
	if (!pawnComPtr) {
		return;
	}

	URoleMovementComponent* uRoleMCPtr = Cast<URoleMovementComponent>(pawnComPtr);
	if (!uRoleMCPtr) {
		return;
	}

	if (bIsALSMode)
	{
		CurSMStateName = ALSLocoNameToCommonLocoNameMap[CurStateNameOut];
		PrevSMStateName = ALSLocoNameToCommonLocoNameMap.Contains(PrevStateNameOut) ? ALSLocoNameToCommonLocoNameMap[PrevStateNameOut] : PrevStateNameOut;
	}
	else
	{
		PrevSMStateName = PrevStateNameOut;
		CurSMStateName = CurStateNameOut;
	}
	const FName& RealCurSMStateName = CurSMStateName;
	
	NewLocomotionStateType = StateNameToStateTypeMap[RealCurSMStateName];
	uRoleMCPtr->DoAnyLocoStateChangedFromStateMachine(NewLocomotionStateType, LocoStateInnerIndex);
	
	if (UsingLocoCrossfadeSynchronizeToLogicChilds) {
		IC7ActorInterface* c7ActorInterface = Cast<IC7ActorInterface>(ownerPtr);
		const FName& SMName = LocomotionStatemachineName;
		const float CrossFadeTime = LocoCrossFadeTime;
		int TempLocoStateInnerIndex = LocoStateInnerIndex;
		
		c7ActorInterface->ForEachLogicChildDoLogicSynchronize((int32)ELogicParentFeatureSynchronizeMask::AnimationLocoState,
			[SMName, RealCurSMStateName, CrossFadeTime, NewLocomotionStateType, TempLocoStateInnerIndex](IC7ActorInterface* logicActor) {

				if(ABaseCharacter *BaseChar = Cast<ABaseCharacter>(logicActor))
				{
					URoleMovementComponent* uRoleMCPtrFromRelation = Cast<URoleMovementComponent>( BaseChar->GetMovementComponent());
					uRoleMCPtrFromRelation->DoAnyLocoStateChangedFromStateMachine(NewLocomotionStateType, TempLocoStateInnerIndex);
				}
				
				
				const USkeletalMeshComponent* Mesh = logicActor->GetMainMesh();
				if (!Mesh) {
					return;
				}

				UAnimInstance* AnimInstance = (Mesh) ? Mesh->GetAnimInstance() : nullptr;
				if (!AnimInstance) {
					return;
				}

				auto* baseAnimInst = Cast<UBaseAnimInstance>(AnimInstance);
				if (baseAnimInst) {
					const FName& DestStateName = baseAnimInst->GetParentToChildStateMachine(RealCurSMStateName);
					baseAnimInst->CrossfadeInFixedTime(SMName, DestStateName, CrossFadeTime);
				}
			}
		);
	}
}

bool UBaseAnimInstance::SetAllSequencePlayerProgressInStateNode(const uint8 InLocoState, float InPercent)
{
	if (!UBaseAnimInstance::StateTypeToStateNameMap.Contains(InLocoState)) {
		UE_LOG(UBaseAnimInstanceLog, Warning, TEXT("UBaseAnimInstance::SetAllSequencePlayerProgressInStateNode None StateType:%d"), InLocoState);
		return false;
	}

	return UAnimInstance::SetAllSequencePlayerProgressInStateNode(LocomotionStatemachineName, UBaseAnimInstance::StateTypeToStateNameMap[InLocoState], InPercent);
}

#pragma region ThreeBattlePostureBlend
void UBaseAnimInstance::StartActionPostureWork(float blendDuration, EActionBlendRule blendRule) {
	ThreeLayerPostureParam.bActionWorking = true;
	ThreeLayerPostureParam.ActionBlendTime = blendDuration;
	ThreeLayerPostureParam.ActionBlendRule = blendRule;
}

void UBaseAnimInstance::StopActionPostureWork(float blendDuration){
	ThreeLayerPostureParam.bActionWorking = false;
	ThreeLayerPostureParam.ActionBlendTime = blendDuration;
}

void UBaseAnimInstance::StartLowerLocoPostureWork()
{
	bLowerLocoWorking = true;
}

void UBaseAnimInstance::StopLowerLocoPostureWork()
{
	bLowerLocoWorking = false;
}

void UBaseAnimInstance::EnableActionMeshSpaceBlend(bool bEnable)
{
	ThreeLayerPostureParam.bActionMeshSpaceBlend = bEnable;
}

void UBaseAnimInstance::SetActionPostureBoneFilter(FName boneName, int boneDepth){
	ThreeLayerPostureParam.ActionFilterBoneName = boneName;
	ThreeLayerPostureParam.ActionFilterBoneDepth = boneDepth;
}

void UBaseAnimInstance::SetPerformBoneData(TMap<int, FName>& BoneData)
{
	ThreeLayerPerformBoneMap = BoneData;
}

void UBaseAnimInstance::StartPerformPostureWork(float blendDuration, EActionBlendRule blendRule){
	ThreeLayerPostureParam.bPerformWorking = true;
	ThreeLayerPostureParam.PerformBlendTime = blendDuration;
	ThreeLayerPostureParam.PerformBlendRule = blendRule;
}

void UBaseAnimInstance::StartPerformPostureWorkUpdateBone(float blendDuration, int boneEnum, int boneDepth, EActionBlendRule blendRule)
{
	if (ThreeLayerPerformBoneMap.Contains(boneEnum))
	{
		SetPosturePostureBoneFilter(ThreeLayerPerformBoneMap[boneEnum], boneDepth);
	}
	
	StartPerformPostureWork(blendDuration, blendRule);
}

void UBaseAnimInstance::StopPerformPostureWork(float blendDuration){
	ThreeLayerPostureParam.bPerformWorking = false;
	ThreeLayerPostureParam.PerformBlendTime = blendDuration;
}

void UBaseAnimInstance::SetPosturePostureBoneFilter(FName boneName, int boneDepth){
	ThreeLayerPostureParam.PerformFilterBoneName = boneName;
	ThreeLayerPostureParam.PerformFilterBoneDepth = boneDepth;
}

#pragma endregion ThreeBattlePostureBlend


void UBaseAnimInstance::GetAllActiveAnimationMessages(TArray<FString>& OutMessages, bool NeedSyncGroupAnims)
{
	TArray<FAnimTickRecord> UngroupedActivePlayers = GetProxyOnGameThread<FAnimInstanceProxy>().GetUngroupedActivePlayersRead();

	if(NeedSyncGroupAnims)
	{
		const TMap<FName, FAnimGroupInstance> &  AnimMap = GetProxyOnGameThread<FAnimInstanceProxy>().GetSyncGroupMapRead();
		for(auto & Item:AnimMap)
		{
			UngroupedActivePlayers.Append(Item.Value.ActivePlayers);
		}
	}
	
	for (int32 PlayerIndex = 0; PlayerIndex < UngroupedActivePlayers.Num(); ++PlayerIndex)
	{
		const FAnimTickRecord& Player = UngroupedActivePlayers[PlayerIndex];

		FString PlayerEntry = FString::Printf
		(
			TEXT("%s  Weight(%.f%%)"),
			*Player.SourceAsset->GetName(),
			Player.EffectiveBlendWeight * 100.f
		);

		if (UAnimSequenceBase* AnimSeqBase = Cast<UAnimSequenceBase>(Player.SourceAsset))
		{
			PlayerEntry += FString::Printf
			(
				TEXT("  Percent(%.2f/%.2f)"),
				Player.TimeAccumulator != nullptr ? *Player.TimeAccumulator : 0.f,
				AnimSeqBase->GetPlayLength()
			);
		}
		else if (UBlendSpace* BlendSpace = Cast<UBlendSpace>(Player.SourceAsset))
		{
			if (Player.BlendSpace.BlendSampleDataCache && Player.BlendSpace.BlendSampleDataCache->Num() > 0)
			{
				TArray<FBlendSampleData> SampleData = *Player.BlendSpace.BlendSampleDataCache;
				SampleData.Sort([](const FBlendSampleData& L, const FBlendSampleData& R) { return L.SampleDataIndex < R.SampleDataIndex; });

				const FVector BlendSpacePosition(Player.BlendSpace.BlendSpacePositionX, Player.BlendSpace.BlendSpacePositionY, 0.f);
				PlayerEntry += FString::Printf(TEXT("  Blendspace Input (%s)"), *BlendSpacePosition.ToString());

				const TArray<FBlendSample>& BlendSamples = BlendSpace->GetBlendSamples();

				int32 WeightedSampleIndex = 0;
				for (int32 SampleIndex = 0; SampleIndex < BlendSamples.Num(); ++SampleIndex)
				{
					const FBlendSample& BlendSample = BlendSamples[SampleIndex];

					float Weight = 0.f;
					for (; WeightedSampleIndex < SampleData.Num(); ++WeightedSampleIndex)
					{
						FBlendSampleData& WeightedSample = SampleData[WeightedSampleIndex];
						if (WeightedSample.SampleDataIndex == SampleIndex)
						{
							Weight += WeightedSample.GetClampedWeight();
						}
						else if (WeightedSample.SampleDataIndex > SampleIndex)
						{
							break;
						}
					}

					PlayerEntry += FString::Printf(TEXT("  %s W:%.1f%%"), *GetNameSafe(BlendSample.Animation), Weight * 100.f);
				}
			}
		}

		OutMessages.Add(PlayerEntry);
	}

	for (int32 InstanceIndex = 0; InstanceIndex < MontageInstances.Num(); InstanceIndex++)
	{
		FAnimMontageInstance* MontageInstance = MontageInstances[InstanceIndex];

		if (MontageInstance && MontageInstance->IsActive() && MontageInstance->IsPlaying())
		{
			UAnimMontage* CurMontage = MontageInstance->Montage;
			FString PlayerEntry;

			CurMontage->GetName(PlayerEntry);
			OutMessages.Add(PlayerEntry);
		}
	}
}

void UBaseAnimInstance::SetIsSlaveAnimControl(bool isSlave) {
	IsSlaveAnimControl = isSlave; 

	SetNeedStateTransitionEvaluate(LocomotionStatemachineName, !isSlave);
};


void UBaseAnimInstance::SetUint8EnumProperty(const FName& PropName, uint8 Value)
{
	if(FEnumProperty* TargetPropertyPtr = GetPropertyPtr<FEnumProperty>(PropName))
	{
		void* PropertyValuePtr = TargetPropertyPtr->ContainerPtrToValuePtr<void>(this);
		TargetPropertyPtr->SetValue_InContainer(PropertyValuePtr, &Value);
	}
}

uint8 UBaseAnimInstance::GetUint8EnumPropertyValue(const FName& PropName, uint8 DefaultValueWhenFail)
{
	if(FEnumProperty* TargetPropertyPtr = GetPropertyPtr<FEnumProperty>(PropName))
	{
		void* PropertyValuePtr = TargetPropertyPtr->ContainerPtrToValuePtr<void>(this);
		uint8 Result = DefaultValueWhenFail;
		TargetPropertyPtr->GetValue_InContainer(PropertyValuePtr, &Result);
		return Result;
	}
	return DefaultValueWhenFail;
}

void UBaseAnimInstance::SetBoolProperty(const FName& PropName, bool bValue)
{
	if(FBoolProperty* TargetPropertyPtr = GetPropertyPtr<FBoolProperty>(PropName))
	{
		void* PropertyValuePtr = TargetPropertyPtr->ContainerPtrToValuePtr<void>(this);
		TargetPropertyPtr->SetPropertyValue(PropertyValuePtr, bValue);
	}
}

bool UBaseAnimInstance::GetBoolPropertyValue(const FName& PropName)
{
	if(FBoolProperty* TargetPropertyPtr = GetPropertyPtr<FBoolProperty>(PropName))
	{
		void* PropertyValuePtr = TargetPropertyPtr->ContainerPtrToValuePtr<void>(this);
		return TargetPropertyPtr->GetPropertyValue(PropertyValuePtr);
	}
	return false;
}

void UBaseAnimInstance::SetAnimationFreeze(UAnimMontage* FreezeMontage, float RowPlayRate, float FreezePlayRate, float FreezeInTime,
	float FreezeOutTime, float FreezeFixUpPlayRate)
{
	// 已有动画进行顿帧 目前不处理
	if(FreezeMontage == nullptr || AnimationToFreeze.IsValid())
	{
		return;
	}

	AnimationFreezeInTime = FreezeInTime;
	AnimationFreezeOutTime = FreezeOutTime;
	AnimationFreezeRowPlayRate = RowPlayRate;
	AnimationFreezeSpeed = FreezePlayRate;
	AnimationFreezeFixUpSpeed = FreezeFixUpPlayRate;
	AnimationFreezePassedTime = 0.f;
	AnimationToFreeze = FreezeMontage;
}

void UBaseAnimInstance::ClearAnimationFreeze(UAnimMontage* FreezeMontageToStop, float RowPlayRate)
{
	if(FreezeMontageToStop == nullptr || !AnimationToFreeze.IsValid())
	{
		return;
	}

	if(AnimationToFreeze.Get() == FreezeMontageToStop)
	{
		if(FAnimMontageInstance* MontageInstance = GetActiveInstanceForMontage(FreezeMontageToStop))
		{
			MontageInstance->SetPlayRate(RowPlayRate);
		}
		AnimationToFreeze.Reset();
	}
}

#pragma region PropertyUpdate
void UBaseAnimInstance::UpdateAllowMoveTurn()
{
	bAllowMoveTurn180 = !bDisableMoveTurn && !bIsBackCar && FMath::Abs(FaceAndDriveDiffRadian) >= 2.5f;
	bAllowSprintMoveTurn180NotInBattle = !bDisableMoveTurn && !bIsBackCar && FMath::Abs(FaceAndDriveDiffRadian) >= 2.5f && bIsSprintAnimMovePosture && !bIsBattleAnimBasePosture;
	bAllowMoveTurn90L = !bDisableMoveTurn && !bIsBackCar && FaceAndDriveDiffRadian >= -2.5f && FaceAndDriveDiffRadian <= -1.0f;
	bAllowMoveTurn90R = !bDisableMoveTurn && !bIsBackCar && FaceAndDriveDiffRadian >= 1.0f && FaceAndDriveDiffRadian <= 2.5f; 
	bAllowMoveTurn180SprintNotInBattleOrRunPosture = bAllowSprintMoveTurn180NotInBattle || (bIsRunAnimMovePosture && bAllowMoveTurn180);
}

void UBaseAnimInstance::UpdateLocoGroup()
{
	bIsNormalWalkingLocoGroup = LocoGroup == (int)ELocoGroupType::ELGT_NormalWalking;
	bIsRideLocoGroup = LocoGroup == (int)ELocoGroupType::ELGT_Ride;
	bIsWaterWalkLocoGroup = LocoGroup == (int)ELocoGroupType::ELGT_WaterWalk;
	bIsDizzinessWalkLocoGroup = LocoGroup == (int)ELocoGroupType::ELGT_DizzinessWalk;
	bIsCameraDirMoveLocoGroup = LocoGroup == (int)ELocoGroupType::ELGT_CameraDirMove;
	bIsClimbLocoGroup = LocoGroup == (int)ELocoGroupType::ELGT_Climb;
	bIsSwimLocoGroup = LocoGroup == (int)ELocoGroupType::ELGT_Swim;
}

void UBaseAnimInstance::UpdateAnimMovePosture()
{
	bIsWalkAnimMovePosture = AnimMovePosture == 1;
	bIsRunAnimMovePosture = AnimMovePosture == 0;
	bIsSprintAnimMovePosture = AnimMovePosture == 2;
}

void UBaseAnimInstance::UpdateAnimBasePosture()
{
	bIsNormalAnimBasePosture = AnimBasePosture == 0;
	bIsBattleAnimBasePosture = AnimBasePosture == 1;
	bIsPatrolAnimBasePosture = AnimBasePosture == 2;
}

void UBaseAnimInstance::UpdateDelayedAnimMovePosture()
{
	bIsWalkDelayedAnimMovePosture = DelayedAnimMovePosture == 1;
	bIsRunDelayedAnimMovePosture = DelayedAnimMovePosture == 0;
	bIsSprintDelayedAnimMovePosture = DelayedAnimMovePosture == 2;
}

void UBaseAnimInstance::UpdateCurveControl(float DeltaTime)
{
	// 左右脚
	if (!IsSlaveAnimControl)
	{
		FootPosture = GetCacheAttributeCurveValue(FootPostureCurveName) > 0.01f ? 1 : 0;	
	}
	
	BooleanFootPosture = FootPosture > 0;
	// 脚步动画百分比
	FootCurveRatioValue = GetCurveValue(FootRatioCurveName);
	BlendOutTimeCurveValue = GetCurveValue(BlendOutTimeCurveName);

	// 手臂叠加
	float TargetArmAdditive = 0.f;
	bool bHasDisAdditiveCurve = GetCurveValueWithDefault(DisableArmAdditiveCurveName, 1, TargetArmAdditive);
	TargetArmAdditive = bHasDisAdditiveCurve ? 0 : 1;
	CurveArmAdditiveAlpha = FMath::FInterpTo(CurveArmAdditiveAlpha, TargetArmAdditive, DeltaTime, DisableArmAdditiveInterpSpeed);
	ArmAdditiveAlpha = LuaArmAdditiveAlpha * CurveArmAdditiveAlpha;

	// LookAt 禁用
	float LookAtAlpha = 0.f;
	bool bHasDisLookAtCurve = GetCurveValueWithDefault(DisableLookAtCurveName, 1, LookAtAlpha);
	LookAtAlpha = bHasDisLookAtCurve ? 0 : 1;
	CurveControlLookAtAlpha = FMath::FInterpTo(CurveControlLookAtAlpha, LookAtAlpha, DeltaTime, DisableLookAtInterpSpeed);

	//脚步IK控制曲线
	float OldIKFootLValue = EnableIK_FootL_CurveValue;
	float OldIKFootRValue = EnableIK_FootR_CurveValue;
	EnableIK_FootL_CurveValue = GetCurveValue(EnableIK_FootL_CurveName);
	EnableIK_FootR_CurveValue = GetCurveValue(EnableIK_FootR_CurveName);

	if (bIsALSMode)
	{
		bAlsTurnLeft90IP = GetCurveValue(ALSTurn90IPLeftCurveName) > 0;
		bAlsTurnRight90IP = GetCurveValue(ALSTurn90IPRightCurveName) > 0;
		bAlsTurnLeft180IP = GetCurveValue(ALSTurn180IPLeftCurveName) > 0;
		bAlsTurnRight180IP = GetCurveValue(ALSTurn180IPRightCurveName) > 0;
	}

	if(UsingFootLock)
	{
		auto * SKMesh = GetOwningComponent();
		if(IsValid(SKMesh) && IsValid(SKMesh->GetOwner()))
		{
			auto *SKOwner = SKMesh->GetOwner();
			const float TOLERATE_VALUE = 0.01f;
			if(EnableIK_FootL_CurveValue > TOLERATE_VALUE && OldIKFootLValue < TOLERATE_VALUE)
			{
				LockPosition_FootL = SKMesh->GetBoneTransform(FootL_BoneName).GetTranslation();
			}

			if(EnableIK_FootR_CurveValue > TOLERATE_VALUE && OldIKFootRValue < TOLERATE_VALUE)
			{
				LockPosition_FootR = SKMesh->GetBoneTransform(FootR_BoneName).GetTranslation();
			}
		}
	}
	
	//一些动画需要临时关闭一下Kawaii的功能，为了表现不穿帮，靠原始动画处理
    UpdateKawaiiCurveValue(DeltaTime);
}

void UBaseAnimInstance::UpdateKawaiiCurveValue(float DeltaTime)
{
	bool HasDisableKawaii =  GetCurveValueWithDefault(DisableKawaiiCurveName, -1, DisableKawaii);
	bool HasDisableKawaiiCloak =  GetCurveValueWithDefault(DisableKawaiiCloakCurveName, -1, DisableKawaiiCloak);
	bool HasDisableKawaiiSkirt =  GetCurveValueWithDefault(DisableKawaiiSkirtCurveName, -1, DisableKawaiiSkirt);

    float TargetKawaiiAlpha = DisableKawaiiAlpha;
    bool TargetEnableKawaii = bEnableKawaii;
    if (HasDisableKawaii || HasDisableKawaiiCloak || HasDisableKawaiiSkirt)
    {
        TargetKawaiiAlpha = 0.000001F; //这里应该是为了让Kawaii能继续跑，等切换回来的时候表现正常
        TargetEnableKawaii = false;
    }
	else
	{
        TargetKawaiiAlpha = 1.0F;
        TargetEnableKawaii = true;
	}

	if (TargetEnableKawaii != bEnableKawaii)
	{
        bEnableKawaii = TargetEnableKawaii;
        bIsKawaiiTransition = true;
        CurKawaiiTransitionTime = 0.f;
        StartTransitionKawaiiAlpha = DisableKawaiiAlpha;
	}

	if (!bIsKawaiiTransition)
	{
        return;
	}

	CurKawaiiTransitionTime += DeltaTime;
    float LerpAlpha = KawaiiTransitionTime > 0 ? CurKawaiiTransitionTime / KawaiiTransitionTime : 1;
    LerpAlpha = FMath::Clamp(LerpAlpha, 0.f, 1.f);
    DisableKawaiiAlpha = FMath::Lerp(StartTransitionKawaiiAlpha, TargetKawaiiAlpha, LerpAlpha);

    if (CurKawaiiTransitionTime >= KawaiiTransitionTime)
    {
        bIsKawaiiTransition = false;
        CurKawaiiTransitionTime = 0.f;
    }

    UBaseAnimLayer* KawaiiLayer = GetFeatureAnimLayer(FName(ABaseCharacter::KawaiiTag));
	if (!KawaiiLayer)
	{
        return;
	}

	if (const FFloatProperty* PropertyPtr = KawaiiLayer->GetPropertyPtr<FFloatProperty>(KawaiiAlphaName))
    {
        void* PropertyValuePtr = PropertyPtr->ContainerPtrToValuePtr<void>(KawaiiLayer);
        PropertyPtr->SetPropertyValue(PropertyValuePtr, DisableKawaiiAlpha);
    }
}
#pragma endregion PropertyUpdate

#pragma region PlayWebSequence

void UBaseAnimInstance::SetWebSequenceAsset(const FString& WebAnimSequenceName, int32 PeopleIndex, int32 Sex, float StartTime)
{
	UE_LOG(LogTemp, Log, TEXT("SetWebSequenceAsset: AnimationName=%s, PeopleIndex=%d, Sex=%d, StartTime=%.2f"), *WebAnimSequenceName, PeopleIndex, Sex, StartTime);
	FAnimInstanceProxy& Proxy = GetProxyOnAnyThread<FAnimInstanceProxy>();

	if (!Proxy.GetAnimClassInterface())
	{
#if !UE_BUILD_SHIPPING
		UE_LOG(UBaseAnimInstanceLog, Warning, TEXT("UBaseAnimInstance::SetWebSequenceAsset Invalid Animation Proxy"));
#endif
		return;
	}

	const TArray<FStructProperty*>& AnimNodeProperties = Proxy.GetAnimClassInterface()->GetAnimNodeProperties();
	UE_LOG(LogTemp, Log, TEXT("SetWebSequenceAsset: Searching WebSequencePlayer node in %d anim nodes"), AnimNodeProperties.Num());
	
	for (auto E : AnimNodeProperties)
	{
		FStructProperty* MachineInstanceProperty = E;
		if (!MachineInstanceProperty->Struct->IsChildOf(FAnimNode_WebSequencePlayer::StaticStruct()))
		{
			continue;
		}
		FAnimNode_WebSequencePlayer* Player = MachineInstanceProperty->ContainerPtrToValuePtr<FAnimNode_WebSequencePlayer>(Proxy.GetAnimInstanceObject());
		if (!Player)
		{
			UE_LOG(LogTemp, Warning, TEXT("SetWebSequenceAsset: Found WebSequencePlayer node but failed to get pointer"));
			continue;
		}

		UE_LOG(LogTemp, Log, TEXT("SetWebSequenceAsset: Found WebSequencePlayer node, loading animation data..."));
		UKGWebAnimationManager* WebAnimationManager = UKGWebAnimationManager::GetInstance(this);
		if (!WebAnimationManager)
		{
			UE_LOG(LogTemp, Warning, TEXT("SetWebSequenceAsset: Failed to get WebAnimationManager instance"));
			return;
		}

		TSharedPtr<FCustomAnimationData> WebAnimSequence = WebAnimationManager->GetWebAnimSequence(WebAnimSequenceName, PeopleIndex, Sex);
		if (!WebAnimSequence)
		{
			UE_LOG(LogTemp, Warning, TEXT("SetWebSequenceAsset: Failed to get WebAnimSequence data for %s"), *WebAnimSequenceName);
			return;
		}

		Player->AnimationData = *WebAnimSequence;
		const TMap<FString, FVector>* BoneLocationDataPtr = WebAnimationManager->GetBoneLocationData(Sex);
		if (BoneLocationDataPtr)
		{
			Player->BoneLocationData = *BoneLocationDataPtr;
			UE_LOG(LogTemp, Log, TEXT("SetWebSequenceAsset: BoneLocationData loaded, %d bones"), BoneLocationDataPtr->Num());
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("SetWebSequenceAsset: Failed to get BoneLocationData for Sex=%d"), Sex);
		}

		// 加载BlendArray数据
		const TArray<float>* BlendArrayPtr = WebAnimationManager->GetBlendArray(WebAnimSequenceName, PeopleIndex);
		if (BlendArrayPtr)
		{
			Player->BlendArray = *BlendArrayPtr;
			UE_LOG(LogTemp, Log, TEXT("SetWebSequenceAsset: BlendArray loaded, %d values"), BlendArrayPtr->Num());
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("SetWebSequenceAsset: Failed to get BlendArray for PeopleIndex=%d"), PeopleIndex);
			Player->BlendArray.Empty();
		}

		// 设置人物索引和帧率
		Player->PeopleIndex = PeopleIndex;
		TSharedPtr<FVideoGenData> VideoGenData = WebAnimationManager->GetWebAnimData(WebAnimSequenceName);
		if (VideoGenData.IsValid())
		{
			Player->SampleRate = VideoGenData->SampleRate;
		}

		Player->PlayTime = StartTime;
		UE_LOG(LogTemp, Log, TEXT("SetWebSequenceAsset: Successfully loaded animation '%s', Duration=%.2f, StartTime=%.2f"), *WebAnimSequenceName, WebAnimSequence->Duration, StartTime);
		return;
	}
	
	UE_LOG(LogTemp, Warning, TEXT("SetWebSequenceAsset: No WebSequencePlayer node found in animation blueprint"));
}

void UBaseAnimInstance::SetWebSequencePlayControl(bool bPlaying, bool bPause, float playRate)
{
	UE_LOG(LogTemp, Log, TEXT("SetWebSequencePlayControl: bPlaying=%d, bPause=%d, playRate=%.2f"), bPlaying, bPause, playRate);
	bPlayWebSequenceEnable = bPlaying;
	bPlayWebSequencePause = bPause;
	PlayWebSequencePlayRate = playRate;
}

bool UBaseAnimInstance::IsWebSequencePlaying() const
{
	return bPlayWebSequenceEnable;
}

#pragma endregion PlayWebSequence

#pragma region LookAt
inline float GetAngle(const FVector& Dir, const FVector& AxisDir)
{
	const float normDot = FVector::DotProduct(Dir.GetSafeNormal(), AxisDir.GetSafeNormal());
	return FMath::RadiansToDegrees(FMath::Acos(FMath::Clamp(normDot, -1.f, 1.f)));
}

inline void CalculateRelativeAngles(const FVector& Dir, const FVector& AxisDir, float& HorizontalAngle, float& VerticalAngle)
{
	// 水平角度计算（带安全校验）
	FVector HorDir = FVector(Dir.X, Dir.Y, 0);
	if (HorDir.Normalize()) {
		FVector HorAxisDir = FVector(AxisDir.X, AxisDir.Y, 0).GetSafeNormal();
		HorizontalAngle = HorAxisDir.IsNearlyZero() ? 0 : GetAngle(HorDir, HorAxisDir);
	} else {
		HorizontalAngle = 0; // 处理垂直方向
	}

	// 标准垂直角度计算
	const float horizSize = FVector2D(Dir.X, Dir.Y).Size();
	VerticalAngle = FMath::RadiansToDegrees(FMath::Atan2(Dir.Z, horizSize));
}

inline void GetRotateAngle(FVector& NormalizedDir, FVector& ForwardDir, FVector& UpwardDir, FVector& RightDir, float& OutVertAngle, float& OutHorizAngle)
{
	// 确保所有方向向量都已归一化
	ForwardDir.Normalize();
	UpwardDir.Normalize();
	RightDir.Normalize();
	NormalizedDir.Normalize();
	
	// 计算垂直角度 (俯仰角)
	OutVertAngle = FMath::RadiansToDegrees(FMath::Asin(FVector::DotProduct(NormalizedDir, UpwardDir)));

	// 计算在垂直于Up方向的平面上的投影
	FVector ProjectedOnPlane = NormalizedDir - FVector::DotProduct(NormalizedDir, UpwardDir) * UpwardDir;
	// 检查投影是否为零向量
	if (!ProjectedOnPlane.Normalize()) {
		// 处理零向量的情况，例如设置默认值或返回错误
		OutHorizAngle = 0.0f;
	} else {
		// 计算水平角度 (偏航角)
		OutHorizAngle = FMath::RadiansToDegrees(FMath::Atan2(
			FVector::DotProduct(ProjectedOnPlane, RightDir),
			FVector::DotProduct(ProjectedOnPlane, ForwardDir)
		));
	}
}


void UBaseAnimInstance::ApplyGaze(UAnimLayerContext& AnimLayerContext)
{
	if (CurrentGazeType == EGazeTargetType::None)
	{
		if (!FMath::IsNearlyEqual(CurrentGazeData.GazeAlpha, 0, 1.e-2f))
		{
			CurrentGazeData.GazeAlpha = UKismetMathLibrary::FInterpTo(CurrentGazeData.GazeAlpha, 0, AnimLayerContext.DeltaTime, GazeConfig.GazeAlphaOutSpeed);
		}
		else
		{
			CurrentGazeData.GazeAlpha = 0;
		}
	}
	else
	{
		CurrentGazeData.GazeAlpha = GazeConfig.bGazeInstant ? 1 : UKismetMathLibrary::FInterpTo(CurrentGazeData.GazeAlpha, 1, AnimLayerContext.DeltaTime, GazeConfig.GazeAlphaInSpeed);
	}
	
	if (!FMath::IsNearlyEqual(CurrentGazeData.GazeAlpha, 0, 1.e-2f))
	{
		CalculateGaze(AnimLayerContext);

		if (GazeConfig.bGazeInstant)
		{
			CurrentGazeData.HeadRotate_Horiz = CurrentGazeData.HeadRotate_HorizTarget * GazeConfig.HeadAlphaCoefficient;
			CurrentGazeData.HeadRotate_Vert = CurrentGazeData.HeadRotate_VertTarget * GazeConfig.HeadAlphaCoefficient;
			CurrentGazeData.NeckRotate_Horiz = CurrentGazeData.NeckRotate_HorizTarget * GazeConfig.NeckAlphaCoefficient;
			CurrentGazeData.NeckRotate_Vert = CurrentGazeData.NeckRotate_VertTarget * GazeConfig.NeckAlphaCoefficient;
			CurrentGazeData.SpineRotate_Horiz = CurrentGazeData.SpineRotate_HorizTarget * GazeConfig.SpineAlphaCoefficient;
			CurrentGazeData.SpineRotate_Vert = CurrentGazeData.SpineRotate_VertTarget * GazeConfig.SpineAlphaCoefficient;

			CurrentGazeData.LEyeRotate_Horiz = CurrentGazeData.LEyeRotate_HorizTarget * GazeConfig.EyeAlphaCoefficient;
			CurrentGazeData.LEyeRotate_Vert = CurrentGazeData.LEyeRotate_VertTarget * GazeConfig.EyeAlphaCoefficient;
			CurrentGazeData.REyeRotate_Horiz = CurrentGazeData.REyeRotate_HorizTarget * GazeConfig.EyeAlphaCoefficient;
			CurrentGazeData.REyeRotate_Vert =   CurrentGazeData.REyeRotate_VertTarget * GazeConfig.EyeAlphaCoefficient;
		}
		else
		{
			BlendGazeAlpha(CurrentGazeData.HeadRotate_Horiz, CurrentGazeData.CacheHeadRotate_Horiz, CurrentGazeData.HeadRotate_HorizTarget * GazeConfig.HeadAlphaCoefficient,
				CurrentGazeData.HeadRotate_Vert, CurrentGazeData.CacheHeadRotate_Vert, CurrentGazeData.HeadRotate_VertTarget * GazeConfig.HeadAlphaCoefficient,
				AnimLayerContext.DeltaTime, GazeConfig.HeadRotateSpeed);

			BlendGazeAlpha(CurrentGazeData.NeckRotate_Horiz, CurrentGazeData.CacheNeckRotate_Horiz, CurrentGazeData.NeckRotate_HorizTarget * GazeConfig.NeckAlphaCoefficient,
				CurrentGazeData.NeckRotate_Vert, CurrentGazeData.CacheNeckRotate_Vert, CurrentGazeData.NeckRotate_VertTarget * GazeConfig.NeckAlphaCoefficient
				, AnimLayerContext.DeltaTime, GazeConfig.NeckRotateSpeed);
			
			BlendGazeAlpha(CurrentGazeData.SpineRotate_Horiz, CurrentGazeData.CacheSpineRotate_Horiz, CurrentGazeData.SpineRotate_HorizTarget * GazeConfig.SpineAlphaCoefficient,
				CurrentGazeData.SpineRotate_Vert, CurrentGazeData.CacheSpineRotate_Vert, CurrentGazeData.SpineRotate_VertTarget * GazeConfig.SpineAlphaCoefficient, AnimLayerContext.DeltaTime, GazeConfig.SpineRotateSpeed);

			BlendGazeAlpha(CurrentGazeData.LEyeRotate_Horiz, CurrentGazeData.CacheLEyeRotate_Horiz, CurrentGazeData.LEyeRotate_HorizTarget * GazeConfig.EyeAlphaCoefficient,
				CurrentGazeData.LEyeRotate_Vert, CurrentGazeData.CacheLEyeRotate_Vert, CurrentGazeData.LEyeRotate_VertTarget * GazeConfig.EyeAlphaCoefficient
				, AnimLayerContext.DeltaTime, GazeConfig.EyeRotateSpeed);
			BlendGazeAlpha(CurrentGazeData.REyeRotate_Horiz, CurrentGazeData.CacheREyeRotate_Horiz, CurrentGazeData.REyeRotate_HorizTarget * GazeConfig.EyeAlphaCoefficient,
				CurrentGazeData.REyeRotate_Vert, CurrentGazeData.CacheREyeRotate_Vert, CurrentGazeData.REyeRotate_VertTarget * GazeConfig.EyeAlphaCoefficient
				, AnimLayerContext.DeltaTime, GazeConfig.EyeRotateSpeed);
		}
	}

	// 设置骨骼数据
	EC7BoneModificationMode LocMode = EC7BoneModificationMode::BMM_Ignore;
	EC7BoneModificationMode RotMode = EC7BoneModificationMode::BMM_Additive;
	EC7BoneModificationMode ScaleMode = EC7BoneModificationMode::BMM_Ignore;

	float GazeAlpha = CurrentGazeData.GazeAlpha * CurveControlLookAtAlpha;
	float EffectHeadHoriz = -CurrentGazeData.HeadRotate_Horiz;
	float EffectHeadVert = -CurrentGazeData.HeadRotate_Vert;
	float EffectSpineHoriz = -CurrentGazeData.SpineRotate_Horiz;
	float EffectSpineVert = -CurrentGazeData.SpineRotate_Vert;
	float EffectNeckHoriz = -CurrentGazeData.NeckRotate_Horiz;
	float EffectNeckVert = -CurrentGazeData.NeckRotate_Vert;
	float EffectLEyeHoriz = CurrentGazeData.LEyeRotate_Horiz;
	float EffectLEyeVert = -CurrentGazeData.LEyeRotate_Vert;
	float EffectREyeHoriz = -CurrentGazeData.REyeRotate_Horiz;
	float EffectREyeVert = -CurrentGazeData.REyeRotate_Vert;

	// 头部
	UpdateModifyBoneAutoAdd(CommonIKConfig.LEyeBallBoneName, LocMode, RotMode, ScaleMode, EBoneControlSpace::BCS_ParentBoneSpace, 0, 0, 0, EffectLEyeHoriz, 0, EffectLEyeVert, 1, 1, 1, NAME_None, 1, GazeAlpha);
	UpdateModifyBoneAutoAdd(CommonIKConfig.REyeBallBoneName, LocMode, RotMode, ScaleMode, EBoneControlSpace::BCS_ParentBoneSpace, 0, 0, 0, EffectREyeHoriz, 0, EffectREyeVert, 1, 1, 1, NAME_None, 1, GazeAlpha);
	UpdateModifyBoneAutoAdd(CommonIKConfig.HeadBoneName, LocMode, RotMode, ScaleMode, EBoneControlSpace::BCS_BoneSpace, 0, 0, 0, 0, EffectHeadVert, EffectHeadHoriz, 1, 1, 1, NAME_None, 1, GazeAlpha);
	UpdateModifyBoneAutoAdd(CommonIKConfig.Spine02BoneName, LocMode, RotMode, ScaleMode, EBoneControlSpace::BCS_BoneSpace, 0, 0, 0, 0, EffectSpineVert, EffectSpineHoriz, 1, 1, 1, NAME_None, 1, GazeAlpha);
	UpdateModifyBoneAutoAdd(CommonIKConfig.Neck01BoneName, LocMode, RotMode, ScaleMode, EBoneControlSpace::BCS_BoneSpace, 0, 0, 0, 0, EffectNeckVert, EffectNeckHoriz, 1, 1, 1, NAME_None, 1, GazeAlpha);
}

void UBaseAnimInstance::BlendGazeAlpha(float& HCurrentValue, float HStartValue, float HTargetValue, float& VCurrentValue, float VStartValue, float VTargetValue, float DeltaTime, float Speed)
{
	if (HTargetValue == HStartValue && VTargetValue == VStartValue)
	{
		HCurrentValue = HTargetValue;
		VCurrentValue = VTargetValue;
		return;
	}
	
	if (GazeConfig.GazeEasyInOutExp == EAlphaBlendOption::Linear)
	{
		HCurrentValue = UKismetMathLibrary::FInterpTo(HCurrentValue, HTargetValue, DeltaTime, Speed);
		VCurrentValue = UKismetMathLibrary::FInterpTo(VCurrentValue, VTargetValue, DeltaTime, Speed);
	}
	else
	{
		BlendTimeTotal += DeltaTime;
		float HAlpha = FMath::Clamp((BlendTimeTotal * Speed) / FMath::Abs((HTargetValue - HStartValue)), 0.0f, 1.0f);
		HAlpha = FAlphaBlend::AlphaToBlendOption(HAlpha, GazeBlendAlpha.GetBlendOption(), GazeBlendAlpha.GetCustomCurve());

		float VAlpha = FMath::Clamp((BlendTimeTotal * Speed) / FMath::Abs((VTargetValue - VStartValue)), 0.0f, 1.0f);
		VAlpha = FAlphaBlend::AlphaToBlendOption(VAlpha, GazeBlendAlpha.GetBlendOption(), GazeBlendAlpha.GetCustomCurve());

		CurrentGazeData.AlphaBlendMin = FMath::Min(HAlpha, VAlpha);
		HCurrentValue = FMath::Lerp(HStartValue, HTargetValue, CurrentGazeData.AlphaBlendMin);
		VCurrentValue = FMath::Lerp(VStartValue, VTargetValue, CurrentGazeData.AlphaBlendMin);
	}
}

bool UBaseAnimInstance::CollectBoneTransform(UAnimLayerContext& AnimLayerContext)
{
	if (!AnimLayerContext.SMC.IsValid()) return false;

	const TWeakObjectPtr<class USkeletalMeshComponent>& Smc = AnimLayerContext.SMC;

	FTransform FaceTf = Smc->GetSocketTransform(AnimGazeBoneNames.HeadBoneName, ERelativeTransformSpace::RTS_World);
	CurrentGazeData.HeadPos = FaceTf.GetLocation();
	CurrentGazeData.HeadRotator = FaceTf.GetRotation().Rotator();
	CurrentGazeData.HeadForward = CurrentGazeData.HeadRotator.RotateVector(FVector(0, 1, 0));
	CurrentGazeData.HeadUp = CurrentGazeData.HeadRotator.RotateVector(FVector(1, 0, 0));
	CurrentGazeData.HeadRight = CurrentGazeData.HeadRotator.RotateVector(FVector(0, 0, 1));

	FTransform EyeTf_L = Smc->GetSocketTransform(AnimGazeBoneNames.LEyeBoneName, ERelativeTransformSpace::RTS_World);
	FTransform EyeTf_R = Smc->GetSocketTransform(AnimGazeBoneNames.REyeBoneName, ERelativeTransformSpace::RTS_World);

	CurrentGazeData.Eye_L_Pos = EyeTf_L.GetLocation();
	CurrentGazeData.Eye_R_Pos = EyeTf_R.GetLocation();
	CurrentGazeData.Eye_L_Rot = EyeTf_L.GetRotation().Rotator();
	CurrentGazeData.Eye_R_Rot = EyeTf_R.GetRotation().Rotator();

	const FSharedMovementInfo& MovementInfo = UAnimLayerSharedData::GetFSharedMovementInfo(&AnimLayerContext);
	CurrentGazeData.ForwardDir = MovementInfo.ForwardDir;
	CurrentGazeData.RightDir = MovementInfo.RightDir;
	CurrentGazeData.UpDir = MovementInfo.UpDir;
	
	USkeletalMeshComponent* SkeletalMeshComponent = GetOwningComponent();
	if (SkeletalMeshComponent && GazeDirectionBoneName != NAME_None)
	{
		FQuat BoneRotator = SkeletalMeshComponent->GetBoneTransform(GazeDirectionBoneName).GetRotation();
		
		CurrentGazeData.ForwardDir = BoneRotator.GetRightVector();
		CurrentGazeData.RightDir = BoneRotator.GetUpVector();
	}
	else
	{
		CurrentGazeData.HeadPos = Smc->GetSocketTransform("CAMERA_LOOK").GetLocation();
	}

	return true;
}

bool UBaseAnimInstance::GetTargetBonePos(UAnimLayerContext& AnimLayerContext,FVector& OutTargetPos)
{
	switch (CurrentGazeType)
	{
	case EGazeTargetType::Camera:
		{
			APlayerCameraManager* CameraManager = Cast<ACameraManager>(UGameplayStatics::GetPlayerCameraManager(GetWorld(), 0));
			if (CameraManager)
			{
				OutTargetPos = CameraManager->GetCameraCacheView().Location;
				return true;
			}
			break;
		}
	case EGazeTargetType::ScreenPos:
		{
			APlayerController* PC = UGameplayStatics::GetPlayerController(this, 0);
			FVector Dir;
			return UGameplayStatics::DeprojectScreenToWorld(PC, CurrentGazeData.GazeScreenPos, OutTargetPos, Dir);
		}
	case EGazeTargetType::WorldPos:
		{
			if (GazeConfig.GazeMaxDistanceLimit > 0)
			{
				if (auto Owner = TryGetPawnOwner())
				{
					if (FVector::Distance(Owner->GetActorLocation(), GazeConfig.GazeWorldPos) > GazeConfig.GazeMaxDistanceLimit)
					{
						return false;
					}	
				}	
			}
			
			OutTargetPos = GazeConfig.GazeWorldPos;
			return true;
		}
	case EGazeTargetType::Character:
		{
			if (GazeConfig.GazeCharacter.IsValid() && !GazeConfig.GazeCharacterSocket.IsEmpty())
			{
				if (GazeConfig.GazeMaxDistanceLimit > 0)
				{
					if (auto Owner = TryGetPawnOwner())
					{
						if (FVector::Distance(Owner->GetActorLocation(), GazeConfig.GazeCharacter->GetActorLocation()) > GazeConfig.GazeMaxDistanceLimit)
						{
							return false;
						}	
					}	
				}
				
				if (USkeletalMeshComponent* Mesh = GazeConfig.GazeCharacter->FindComponentByClass<USkeletalMeshComponent>())
				{
					OutTargetPos = Mesh->GetSocketLocation(*GazeConfig.GazeCharacterSocket);
				}
				else
				{
					OutTargetPos = GazeConfig.GazeCharacter->GetActorLocation();	
				}
				
				if (!GazeConfig.GazeCharacterSocketOffset.IsZero())
				{
					const FTransform& ActorTransform = GazeConfig.GazeCharacter->GetActorTransform();
					OutTargetPos = ActorTransform.TransformPosition(ActorTransform.InverseTransformPosition(OutTargetPos) + GazeConfig.GazeCharacterSocketOffset);	
				}

				return true;
			}
			break;
		}
	case EGazeTargetType::CustomGazeCoord:
		{
			float HoriOppositeDir = 1; //如果相机在背面 则需要左右方向反转

			FVector HeadPos = CurrentGazeData.HeadPos;
			ACameraManager* CameraManager = Cast<ACameraManager>(UGameplayStatics::GetPlayerCameraManager(GetWorld(), 0));
			if (CameraManager)
			{
				if (FVector::DotProduct((CameraManager->GetCameraCacheView().Location - HeadPos), CurrentGazeData.ForwardDir) < 0)
				{
					HoriOppositeDir = -1;
				}
			}

			FVector Dir = CurrentGazeData.ForwardDir;
			Dir = Dir.RotateAngleAxis(((CurrentGazeData.GazeCoord.Y - 0.5) / 0.5) * GazeConfig.GazeCoordRange.Y, CurrentGazeData.RightDir);
			Dir = Dir.RotateAngleAxis(((CurrentGazeData.GazeCoord.X - 0.5) / -0.5) * GazeConfig.GazeCoordRange.X * HoriOppositeDir, CurrentGazeData.UpDir);


			OutTargetPos = HeadPos + Dir.GetSafeNormal() * GazeConfig.GazeCoordDist;
			return true;
		}
	default:
		{
			break;
		}
	}
	return false;
}

void UBaseAnimInstance::CalculateGaze(UAnimLayerContext& AnimLayerContext)
{
	CurrentGazeData.LEyeRotate_HorizTarget = .0f;
	CurrentGazeData.LEyeRotate_VertTarget = .0f;
	CurrentGazeData.REyeRotate_HorizTarget = .0f;
	CurrentGazeData.REyeRotate_VertTarget = .0f;
	CurrentGazeData.HeadRotate_HorizTarget = .0f;
	CurrentGazeData.HeadRotate_VertTarget = .0f;
	CurrentGazeData.NeckRotate_HorizTarget = .0f;
	CurrentGazeData.NeckRotate_VertTarget = .0f;
	CurrentGazeData.SpineRotate_HorizTarget = .0f;
	CurrentGazeData.SpineRotate_VertTarget = .0f;

	if (!CollectBoneTransform(AnimLayerContext))
	{
		return;
	};

	if(bPauseGaze)
	{
		return;
	}

	FVector TargetPos;
	bool bValidPos = GetTargetBonePos(AnimLayerContext,TargetPos);
	bool HeadRot = false;
	bool OldIsCalculateGaze = CurCalculateGaze;
	if (bValidPos)
	{
		if (CurrentGazeData.bFirstUpdate)
		{
			CurrentGazeData.CurrentTargetPos = TargetPos;
			CurrentGazeData.bFirstUpdate = false;
		}
		else
		{
			CurrentGazeData.CurrentTargetPos = FMath::VInterpTo(CurrentGazeData.CurrentTargetPos, TargetPos, AnimLayerContext.DeltaTime, GazeConfig.LocationInterpSpeed);
		}
		
		CurrentGazeData.CurrentTargetPos += GazeConfig.GazePosOffset;
		FVector LookAtNor = (CurrentGazeData.CurrentTargetPos - CurrentGazeData.HeadPos).GetSafeNormal();

		if (bDebugDraw)
		{
			UKismetSystemLibrary::DrawDebugSphere(GetWorld(), CurrentGazeData.CurrentTargetPos, 10, 10, FLinearColor::Green, AnimLayerContext.DeltaTime);
			UKismetSystemLibrary::DrawDebugLine(GetWorld(), CurrentGazeData.HeadPos, CurrentGazeData.HeadPos + CurrentGazeData.ForwardDir * 200, FLinearColor::White, AnimLayerContext.DeltaTime);
			UKismetSystemLibrary::DrawDebugLine(GetWorld(), CurrentGazeData.HeadPos, CurrentGazeData.HeadPos + (CurrentGazeData.CurrentTargetPos - CurrentGazeData.HeadPos).GetSafeNormal() * 200, FLinearColor::Yellow, AnimLayerContext.DeltaTime);
		}
		
		float HorizontalAngle = 0.f;
		float VerticalAngle = 0.f;
		CalculateRelativeAngles(LookAtNor, CurrentGazeData.ForwardDir, HorizontalAngle, VerticalAngle);
		HorizontalAngle = FMath::Abs(HorizontalAngle);
		VerticalAngle = FMath::Abs(VerticalAngle);

		bool bHorEnableCalculate = CurCalculateGaze;
		bool bVerEnableCalculate = CurCalculateGaze;
		// 水平角度限制
		if (HorizontalAngle <= GazeConfig.HorClampAngle || HorizontalAngle > GazeConfig.HorClampAngle + DeltaClampAngle)
		{
			bHorEnableCalculate = HorizontalAngle <= GazeConfig.HorClampAngle;
		}
		// 垂直角度限制
		if (VerticalAngle <= GazeConfig.VerClampAngle || VerticalAngle > GazeConfig.VerClampAngle + DeltaClampAngle)
		{
			bVerEnableCalculate = VerticalAngle <= GazeConfig.VerClampAngle;
		}

		CurCalculateGaze = bHorEnableCalculate && bVerEnableCalculate;
		
		if (CurCalculateGaze)
		{
			float UpOffset = 0;
			float RightOffset = 0;

			GetRotateAngle(LookAtNor, CurrentGazeData.ForwardDir, CurrentGazeData.UpDir, CurrentGazeData.RightDir, UpOffset, RightOffset);

			CurrentGazeData.SpineRotate_HorizTarget = FMath::Clamp<float>(RightOffset * GazeConfig.SpineRotateBlendRate, GazeConfig.SpineClampHoriz.X, GazeConfig.SpineClampHoriz.Y);
			CurrentGazeData.SpineRotate_VertTarget = FMath::Clamp<float>(UpOffset * GazeConfig.SpineRotateBlendRate, GazeConfig.SpineClampVert.X, GazeConfig.SpineClampVert.Y);

			CurrentGazeData.NeckRotate_HorizTarget = FMath::Clamp<float>((RightOffset - CurrentGazeData.SpineRotate_HorizTarget) * GazeConfig.NeckRotateBlendRate, GazeConfig.NeckClampHoriz.X, GazeConfig.NeckClampHoriz.Y);
			CurrentGazeData.NeckRotate_VertTarget = FMath::Clamp<float>((UpOffset - CurrentGazeData.SpineRotate_VertTarget) * GazeConfig.NeckRotateBlendRate, GazeConfig.NeckClampVert.X, GazeConfig.NeckClampVert.Y);

			CurrentGazeData.HeadRotate_HorizTarget = FMath::Clamp<float>(RightOffset - CurrentGazeData.NeckRotate_HorizTarget - CurrentGazeData.SpineRotate_HorizTarget, GazeConfig.HeadClampHoriz.X, GazeConfig.HeadClampHoriz.Y);
			CurrentGazeData.HeadRotate_VertTarget = FMath::Clamp<float>(UpOffset - CurrentGazeData.NeckRotate_VertTarget - CurrentGazeData.SpineRotate_VertTarget, GazeConfig.HeadClampVert.X, GazeConfig.HeadClampVert.Y);
			HeadRot = true;
		}
	}
	else
	{
		CurCalculateGaze = false;
	}

	if (OldIsCalculateGaze != CurCalculateGaze)
	{
		CacheGazeParam();
	}
	
	if (bValidPos && HeadRot)
	{
		if (bDebugDraw)
		{
			UKismetSystemLibrary::DrawDebugLine(GetWorld(), CurrentGazeData.Eye_L_Pos, CurrentGazeData.Eye_L_Pos + CurrentGazeData.Eye_L_Rot.RotateVector(FVector(20, 0, 0)), FLinearColor::Green, AnimLayerContext.DeltaTime);
			UKismetSystemLibrary::DrawDebugLine(GetWorld(), CurrentGazeData.Eye_R_Pos, CurrentGazeData.Eye_R_Pos + CurrentGazeData.Eye_R_Rot.RotateVector(FVector(20, 0, 0)), FLinearColor::Green, AnimLayerContext.DeltaTime);
		}

		FVector LEyeLookAtNor = (CurrentGazeData.CurrentTargetPos - CurrentGazeData.Eye_L_Pos).GetSafeNormal();

		float LEyeRightOffset = 0;
		float LEyeUpOffset = 0;

		GetRotateAngle(LEyeLookAtNor, CurrentGazeData.HeadForward, CurrentGazeData.HeadUp, CurrentGazeData.HeadRight, LEyeUpOffset, LEyeRightOffset);


		CurrentGazeData.LEyeRotate_HorizTarget = FMath::Clamp<float>(LEyeRightOffset, GazeConfig.EyeClampHoriz.X, GazeConfig.EyeClampHoriz.Y);
		CurrentGazeData.LEyeRotate_VertTarget = FMath::Clamp<float>(LEyeUpOffset, GazeConfig.EyeClampVert.X, GazeConfig.EyeClampVert.Y);


		FVector REyeLookAtNor = (CurrentGazeData.CurrentTargetPos - CurrentGazeData.Eye_R_Pos).GetSafeNormal();

		float REyeRightOffset = 0;
		float REyeUpOffset = 0;

		GetRotateAngle(REyeLookAtNor, CurrentGazeData.HeadForward, CurrentGazeData.HeadUp, CurrentGazeData.HeadRight, REyeUpOffset, REyeRightOffset);

		CurrentGazeData.REyeRotate_HorizTarget = FMath::Clamp<float>(REyeRightOffset, GazeConfig.EyeClampHoriz.X, GazeConfig.EyeClampHoriz.Y);
		CurrentGazeData.REyeRotate_VertTarget = FMath::Clamp<float>(REyeUpOffset, GazeConfig.EyeClampVert.X, GazeConfig.EyeClampVert.Y);

		if (bDebugDraw)
		{
			UKismetSystemLibrary::DrawDebugLine(GetWorld(), CurrentGazeData.Eye_L_Pos, CurrentGazeData.Eye_L_Pos + CurrentGazeData.HeadForward.GetSafeNormal() * 200, FLinearColor::Red, AnimLayerContext.DeltaTime);
			UKismetSystemLibrary::DrawDebugLine(GetWorld(), CurrentGazeData.Eye_R_Pos, CurrentGazeData.Eye_R_Pos + CurrentGazeData.HeadForward.GetSafeNormal() * 200, FLinearColor::Red, AnimLayerContext.DeltaTime);
		}
	}
}

void UBaseAnimInstance::TickGaze(float DeltaSeconds)
{
	UpdateLayerContext(DeltaSeconds);
	ApplyGaze(*GazeAnimLayerContext.Get());
}

void UBaseAnimInstance::UpdateLayerContext(float DeltaSeconds)
{
	auto* OwnerPtr = TryGetPawnOwner();
	if (!OwnerPtr) return;
	
	if (!GazeAnimLayerContext) {
		GazeAnimLayerContext = NewObject<UAnimLayerContext>(this);
	}
	
	if (GazeAnimLayerContext->AnimLayerSharedData)
	{
		GazeAnimLayerContext->AnimLayerSharedData->Reset(GazeAnimLayerContext);
	}
	
	GazeAnimLayerContext->Character = OwnerPtr;
	GazeAnimLayerContext->SMC = this->GetSkelMeshComponent();
	GazeAnimLayerContext->Pos = OwnerPtr->GetActorLocation();
	
	if (GazeAnimLayerContext->Character.IsValid())
	{
		GazeAnimLayerContext->BaseCharacter = Cast<ABaseCharacter>(GazeAnimLayerContext->Character.Get());
	}
	if (GazeAnimLayerContext->BaseCharacter.IsValid() && GazeAnimLayerContext->BaseCharacter->GetMovementComponent())
	{
		GazeAnimLayerContext->CharacterMovementC = Cast<UCharacterMovementComponent>(GazeAnimLayerContext->BaseCharacter->GetMovementComponent());
	}
	
	GazeAnimLayerContext->DeltaTime = DeltaSeconds;
}

void UBaseAnimInstance::InitBasicGazeConfig(float HorClampAngle, float VerClampAngle, float LocationInterpSpeed, float AlphaIn, float AlphaOut, float EyeRotateSpeed, float EyeClampHorizX, float EyeClampHorizY, float EyeClampVertX, float EyeClampVertY, float HeadRotateSpeed,
	float HeadClampHorizX, float HeadClampHorizY, float HeadClampVertX, float HeadClampVertY, float SpineRotateSpeed, float SpineRotateBlendRate, float SpineClampHorizX, float SpineClampHorizY, float SpineClampVertX, float SpineClampVertY, float NeckRotateSpeed, float NeckRotateBlendRate,
	float NeckClampHorizX, float NeckClampHorizY, float NeckClampVertX, float NeckClampVertY, bool bGazeInstant, int EasyInOutExp, FName GazeDirBoneName)
{
	SetGazeRotateConfig(HorClampAngle, VerClampAngle, LocationInterpSpeed);
	SetGazeBlendAlpha(AlphaIn, AlphaOut);
	SetGazeEyeRotateConfig(EyeRotateSpeed, EyeClampHorizX, EyeClampHorizY, EyeClampVertX, EyeClampVertY);
	SetGazeHeadRotateConfig(HeadRotateSpeed, HeadClampHorizX, HeadClampHorizY, HeadClampVertX, HeadClampVertY);
	SetGazeSpineRotateConfig(SpineRotateSpeed, SpineRotateBlendRate, SpineClampHorizX, SpineClampHorizY, SpineClampVertX, SpineClampVertY);
	SetGazeNeckRotateConfig(NeckRotateSpeed, NeckRotateBlendRate, NeckClampHorizX, NeckClampHorizY, NeckClampVertX, NeckClampVertY);
	SetGazeInstant(bGazeInstant);
	CacheGazeParam();
	
	GazeConfig.GazeEasyInOutExp = static_cast<EAlphaBlendOption>(EasyInOutExp);
	GazeBlendAlpha.SetBlendOption(GazeConfig.GazeEasyInOutExp);
	GazeDirectionBoneName = GazeDirBoneName;
}

void UBaseAnimInstance::SetGazePartBlendAlpha(float EyeAlphaCoefficient, float HeadAlphaCoefficient, float SpineAlphaCoefficient, float NeckAlphaCoefficient)
{
	GazeConfig.EyeAlphaCoefficient = EyeAlphaCoefficient;
	GazeConfig.HeadAlphaCoefficient = HeadAlphaCoefficient;
	GazeConfig.SpineAlphaCoefficient = SpineAlphaCoefficient;
	GazeConfig.NeckAlphaCoefficient = NeckAlphaCoefficient;
}

void UBaseAnimInstance::SetGazeTargetLocation(const FVector& WorldLocation, float DistanceLimit)
{
	CurrentGazeType = EGazeTargetType::WorldPos;
	GazeConfig.GazeWorldPos = WorldLocation;
	GazeConfig.GazeMaxDistanceLimit = DistanceLimit;
}

void UBaseAnimInstance::SetGazeTargetCharacter(AActor* TargetActor, FString TargetSocket, FVector Offset, float DistanceLimit)
{
	CurrentGazeType = EGazeTargetType::Character;
	GazeConfig.GazeCharacter = TargetActor;
	GazeConfig.GazeCharacterSocket = TargetSocket;
	GazeConfig.GazeCharacterSocketOffset = Offset;
	GazeConfig.GazeMaxDistanceLimit = DistanceLimit;
}

void UBaseAnimInstance::SetGazeCurrentCamera()
{
	CurrentGazeType = EGazeTargetType::Camera;
}


void UBaseAnimInstance::SetGazeByCoord(float GazeCoordRangeX, float GazeCoordRangeY, float GazeCoordDist)
{
	CurrentGazeType = EGazeTargetType::CustomGazeCoord;
	GazeConfig.GazeCoordRange.X = GazeCoordRangeX;
	GazeConfig.GazeCoordRange.Y = GazeCoordRangeY;
	GazeConfig.GazeCoordDist = GazeCoordDist;
}

void UBaseAnimInstance::SetUnGaze(bool bImmediate)
{
	CurrentGazeType = EGazeTargetType::None;
	GazeConfig.bGazeInstant = bImmediate;
	CacheGazeParam();
}


void UBaseAnimInstance::PauseGaze(bool bPause)
{
	bPauseGaze = bPause;
}

void UBaseAnimInstance::SetGazeBlendAlpha(float AlphaIn, float AlphaOut)
{
	GazeConfig.GazeAlphaInSpeed = AlphaIn;
	GazeConfig.GazeAlphaOutSpeed = AlphaOut;
}


void UBaseAnimInstance::SetGazeRotateConfig(float HorClampAngle, float VerClampAngle, float LocationInterpSpeed)
{
	GazeConfig.HorClampAngle = HorClampAngle;
	GazeConfig.VerClampAngle = VerClampAngle;
	GazeConfig.LocationInterpSpeed = LocationInterpSpeed;
}

void UBaseAnimInstance::SetGazeEyeRotateConfig(float EyeRotateSpeed, float EyeClampHorizX, float EyeClampHorizY, float EyeClampVertX, float EyeClampVertY)
{
	GazeConfig.EyeRotateSpeed = EyeRotateSpeed;
	GazeConfig.EyeClampHoriz.X = EyeClampHorizX;
	GazeConfig.EyeClampHoriz.Y = EyeClampHorizY;
	GazeConfig.EyeClampVert.X = EyeClampVertX;
	GazeConfig.EyeClampVert.Y = EyeClampVertY;
}

void UBaseAnimInstance::SetGazeHeadRotateConfig(float HeadRotateSpeed, float HeadClampHorizX, float HeadClampHorizY, float HeadClampVertX, float HeadClampVertY)
{
	GazeConfig.HeadRotateSpeed = HeadRotateSpeed;
	GazeConfig.HeadClampHoriz.X = HeadClampHorizX;
	GazeConfig.HeadClampHoriz.Y = HeadClampHorizY;
	GazeConfig.HeadClampVert.X = HeadClampVertX;
	GazeConfig.HeadClampVert.Y = HeadClampVertY;
}

void UBaseAnimInstance::SetGazeSpineRotateConfig(float SpineRotateSpeed, float SpineRotateBlendRate, float SpineClampHorizX, float SpineClampHorizY,float SpineClampVertX, float SpineClampVertY)
{
	GazeConfig.SpineRotateSpeed = SpineRotateSpeed;
	GazeConfig.SpineRotateBlendRate = SpineRotateBlendRate;
	GazeConfig.SpineClampHoriz.X = SpineClampHorizX;
	GazeConfig.SpineClampHoriz.Y = SpineClampHorizY;
	GazeConfig.SpineClampVert.X = SpineClampVertX;
	GazeConfig.SpineClampVert.Y = SpineClampVertY;
}

void UBaseAnimInstance::SetGazeNeckRotateConfig(float NeckRotateSpeed,float NeckRotateBlendRate,float NeckClampHorizX,float NeckClampHorizY,float NeckClampVertX,float NeckClampVertY)
{
	GazeConfig.NeckRotateSpeed = NeckRotateSpeed;
	GazeConfig.NeckRotateBlendRate = NeckRotateBlendRate;
	GazeConfig.NeckClampHoriz.X = NeckClampHorizX;
	GazeConfig.NeckClampHoriz.Y = NeckClampHorizY;
	GazeConfig.NeckClampVert.X = NeckClampVertX;
	GazeConfig.NeckClampVert.Y = NeckClampVertY;
}


void UBaseAnimInstance::EnableGazeDebugDraw(bool bEnable)
{
	bDebugDraw = bEnable;
}

void UBaseAnimInstance::SetGazeInstant(bool bGazeInstant)
{
	GazeConfig.bGazeInstant = bGazeInstant;
}


void UBaseAnimInstance::UpdateGazeScreenLoc(const FVector2D& GazeLoc)
{
	CurrentGazeData.GazeScreenPos = GazeLoc;
}

void UBaseAnimInstance::UpdateGazeCoord(float CoorX,float CoordY)
{
	CurrentGazeData.GazeCoord.X = CoorX;
	CurrentGazeData.GazeCoord.Y = CoordY;
}

void UBaseAnimInstance::CacheGazeParam()
{
	CurrentGazeData.CacheHeadRotate_Horiz = CurrentGazeData.HeadRotate_Horiz;
	CurrentGazeData.CacheHeadRotate_Vert = CurrentGazeData.HeadRotate_Vert;
	CurrentGazeData.CacheNeckRotate_Horiz = CurrentGazeData.NeckRotate_Horiz;
	CurrentGazeData.CacheNeckRotate_Vert = CurrentGazeData.NeckRotate_Vert;
	CurrentGazeData.CacheSpineRotate_Horiz = CurrentGazeData.SpineRotate_Horiz;
	CurrentGazeData.CacheSpineRotate_Vert = CurrentGazeData.SpineRotate_Vert;
	CurrentGazeData.CacheLEyeRotate_Horiz = CurrentGazeData.LEyeRotate_Horiz;
	CurrentGazeData.CacheLEyeRotate_Vert = CurrentGazeData.LEyeRotate_Vert;
	CurrentGazeData.CacheREyeRotate_Horiz = CurrentGazeData.REyeRotate_Horiz;
	CurrentGazeData.CacheREyeRotate_Vert = CurrentGazeData.REyeRotate_Vert;
	BlendTimeTotal = 0.f;
}

#pragma endregion LookAt

#pragma region ALS

float UBaseAnimInstance::GetNormalizedAimingYaw(float PreviousYaw, float CurrentYaw)
{
	CurrentYaw = FRotator::NormalizeAxis(CurrentYaw);
	
	// 跨象限,保持上一个象限的最大值
	if (FMath::Abs(CurrentYaw - PreviousYaw) > 180.f)
	{
		if (PreviousYaw > 0)
		{
			return 180.f;
		}
		if (PreviousYaw < 0)
		{
			return -180.f;
		}
	}

	return CurrentYaw;
}

void UBaseAnimInstance::SetALSAnimConfig(
		float SmoothedAimingRotationInterpSpeed, float FootHeight, float IK_TraceDistanceAboveFoot, float IK_TraceDistanceBelowFoot,
		float IK_SlopeAngle, float IK_LockAlphaThreshold,
		const FVector & IK_KneeTargetLOffset, const FVector & IK_KneeTargetROffset,
		float IK_StartStretchRatio, float IK_MaxStretchScale, float IK_PelvisInterSpeed, float IK_FootOffsetMaxOffset, float IKAlphaTransitionTime,
		float IK_TolerateDistance, float IK_Tolerate_Angle)
{
	ALSAnimConfig.SmoothedAimingRotationInterpSpeed = SmoothedAimingRotationInterpSpeed;
	ALSAnimConfig.FootHeight = FootHeight;
	ALSAnimConfig.IK_TraceDistanceAboveFoot = IK_TraceDistanceAboveFoot;
	ALSAnimConfig.IK_TraceDistanceBelowFoot = IK_TraceDistanceBelowFoot;
	ALSAnimConfig.IK_SlopeAngle = IK_SlopeAngle;
	ALSAnimConfig.IK_LockAlphaThreshold = IK_LockAlphaThreshold;
	ALSAnimConfig.IK_KneeTargetLOffset = IK_KneeTargetLOffset;
	ALSAnimConfig.IK_KneeTargetROffset = IK_KneeTargetROffset;
	ALSAnimConfig.IK_StartStretchRatio = IK_StartStretchRatio;
	ALSAnimConfig.IK_MaxStretchScale = IK_MaxStretchScale;
	ALSAnimConfig.IK_PelvisInterSpeed = IK_PelvisInterSpeed;
	ALSAnimConfig.IK_FootOffsetMaxOffset = IK_FootOffsetMaxOffset;
	ALSAnimConfig.IK_EnableAlphaTransitionTime = IKAlphaTransitionTime;
	ALSAnimConfig.IK_Tolerate_Distance = IK_TolerateDistance;
	ALSAnimConfig.IK_Tolerate_Angle = IK_Tolerate_Angle;
}

void UBaseAnimInstance::SetForbiddenALSFootIKDuration(float duration, bool ForbiddenImmediately, bool IsAddDuration)
{
	ForbiddenALSFootIKDuration = duration;
	if(ForbiddenImmediately)
	{
		EnableFootIKAlpha = 0.0f;
		ResetIKOffsets();
	}
}

void UBaseAnimInstance::ForbiddenALSFootIKShortlyAndImmediately(float ShortTime)
{
	SetForbiddenALSFootIKDuration(ShortTime, true, true);
}

void UBaseAnimInstance::UpdateALSData(URoleMovementComponent& RoleMC, float TimeDelta)
{
	// https://gamecloud-redmine.corp.kuaishou.com/1007/projects/c7/issues/239391
	// 目前所有的移动操作都是有LocoStart的，因此不用再判断VelocityValue > 150.0f
	bShouldMove = (IsLocoStart && VelocityValue > 1.0f);// || VelocityValue > 150.0f;
	
	bIsLockingTarget = RoleMC.IsLockingTarget() || RoleMC.IsLockingPosition();

	AimingRotation = RoleMC.ALSAimingRotation;
	if(!FMath::IsNearlyZero(TimeDelta))
	{
		AimYawRate = MathFormula::ClosetYawAbsDiff(PreviousAimYaw, AimingRotation.Yaw) / TimeDelta;
	}
	PreviousAimYaw = AimingRotation.Yaw;
	LookAnimPercent = UKismetMathLibrary::MapRangeClamped(RoleMC.LookYawInLocalSpace, -180, 180, 0, 1);

	EnableALSFootIK = true;

	// 离地、ragdoll情况不用IK
	if(!RoleMC.IsMovingOnGround() || bIsRagDoll)
	{
		EnableALSFootIK = false;
	}

	// 有逻辑全身抢占动作, 不进行IK
	if(ThreeLayerPostureParam.bActionWorking)
	{
		EnableALSFootIK = false;
	}
	if(ForbiddenALSFootIKDuration > 0.0f )
	{
		ForbiddenALSFootIKDuration -= TimeDelta;
		EnableALSFootIK = false;
	}

	
	float LinearSpeed = 5.0f; // 默认0.2秒从0->1
	if(ALSAnimConfig.IK_EnableAlphaTransitionTime > 0)
	{
		LinearSpeed = 1.0f / ALSAnimConfig.IK_EnableAlphaTransitionTime;
	}

	const float ENABLE_THRESHOLD = 0.01f;
	if(EnableALSFootIK)
	{
		EnableFootIKAlpha = MathFormula::LinearCloseToDst(EnableFootIKAlpha, 1.0f, LinearSpeed, TimeDelta);
	}
	else
	{
		float OldEnableFootIKAlpha = EnableFootIKAlpha;
		EnableFootIKAlpha = MathFormula::LinearCloseToDst(EnableFootIKAlpha, 0.0f, LinearSpeed, TimeDelta);

		if(OldEnableFootIKAlpha > ENABLE_THRESHOLD and EnableFootIKAlpha < ENABLE_THRESHOLD)
		{
			ResetIKOffsets();
		}
	}

	if(EnableFootIKAlpha > ENABLE_THRESHOLD)
	{
		ALS_UpdateFootIK(RoleMC, TimeDelta);
	}
		
}

float UBaseAnimInstance::TriggerALSDodge(const FName& StateName, const float& BlendDuration)
{
	float CurActorForwardYaw = ViewActorTransform.GetRotation().Rotator().Yaw;
	float CurInputYaw = CurActorForwardYaw;
	if (!LocoInputVec.IsNearlyZero())
	{
		CurInputYaw = LocoInputVec.Rotation().Yaw;
	}

	// 确定使用哪个方位的动画
	float DeltaYaw = FRotator::NormalizeAxis(CurInputYaw - CurActorForwardYaw);
	float OutActorYaw = CurInputYaw;
	if (DeltaYaw > 120.0f)
	{
		ALSLocoDirection = 3;	//Back
		OutActorYaw = FRotator::NormalizeAxis(CurInputYaw - 180.0f);
	}
	else if (DeltaYaw > 60.0f) 
	{
		ALSLocoDirection = 2;	// Right
		OutActorYaw = FRotator::NormalizeAxis(CurInputYaw - 90.0f);
	}
	else if (DeltaYaw > -60.0f)
	{
		ALSLocoDirection = 0;	// Forward
		// OutActorYaw = CurInputYaw;
	}
	else if (DeltaYaw > -120.0f)
	{
		ALSLocoDirection = 1;	// Left
		OutActorYaw = FRotator::NormalizeAxis(CurInputYaw + 90.0f);
	}
	else
	{
		ALSLocoDirection = 3;	//Back
		OutActorYaw = FRotator::NormalizeAxis(CurInputYaw + 180.0f);
	}

	CrossfadeInFixedTime(LocomotionStatemachineName, StateName, BlendDuration);

	return OutActorYaw;
}

// 函数内大量MagicNumber继承自ALS原生数值,如有需要调整再开出来
void UBaseAnimInstance::ALS_CalculateAimingValues(float DeltaSeconds)
{
	if (!IsValid(OwnerCharacter))
	{
		return;
	}
	
	/*
	 * Interp the Aiming Rotation value to achieve smooth aiming rotation changes. 
	 * Interpolating the rotation before calculating the angle ensures the value is not affected by changes in actor rotation, 
	 * allowing slow aiming rotation changes with fast actor rotation changes.
	 */
	SmoothedAimingRotation = FMath::RInterpTo(SmoothedAimingRotation, AimingRotation, DeltaSeconds, ALSAnimConfig.SmoothedAimingRotationInterpSpeed);
	
	/*
	 * Calculate the Aiming angle and Smoothed Aiming Angle by getting the delta between the aiming rotation and the actor rotation.
	 */
	const FRotator CharacterRotation = OwnerCharacter->GetActorRotation();
	FRotator DeltaRotation = AimingRotation - CharacterRotation;
	AimingAngle.X = ALS_OverLayState == EALS_OverLayState::Default ? FRotator::NormalizeAxis(DeltaRotation.Yaw) : GetNormalizedAimingYaw(AimingAngle.X, DeltaRotation.Yaw);
	AimingAngle.Y = DeltaRotation.Pitch;
	FRotator SmoothedDeltaRotation = SmoothedAimingRotation - CharacterRotation;
	SmoothedAimingAngle.X = FRotator::NormalizeAxis(SmoothedDeltaRotation.Yaw);
	SmoothedAimingAngle.Y = SmoothedDeltaRotation.Pitch;
	
	/*
	 * Clamp the Aiming Pitch Angle to a range of 1 to 0 for use in the vertical aim sweeps.
	 */
	if (auto* RoleMoveComp = OwnerCharacter->GetComponentByClass<URoleMovementComponent>())
	{
		if (RoleMoveComp->ALS_RotationMode == EALS_RotationMode::Aiming || RoleMoveComp->ALS_RotationMode == EALS_RotationMode::LookingDirection)
		{
			AimSweepTime = UKismetMathLibrary::MapRangeClamped(AimingAngle.Y, -90, 90, 1.f, 0.f);
			
			/*
			 * Use the Aiming Yaw Angle divided by the number of spine+pelvis bones 
			 * to get the amount of spine rotation needed to remain facing the camera direction.
			 */
			SpineRotation.Roll = 0.f;
			SpineRotation.Pitch = 0.f;
			SpineRotation.Yaw = FMath::ClampAngle(AimingAngle.X / 4.f, -20, 20);
		}
	}
	
	/*
	 * Separate the Aiming Yaw Angle into 3 separate Yaw Times. 
	 * These 3 values are used in the Aim Offset behavior to improve the blending of the aim offset when rotating completely around the character. 
	 * This allows you to keep the aiming responsive but still smoothly blend from left to right or right to left.
	 */
	LeftYawTime = UKismetMathLibrary::MapRangeClamped(FMath::Abs(SmoothedAimingAngle.X), 0.f, 180.f, 0.5f, 0.f);
	RightYawTime = UKismetMathLibrary::MapRangeClamped(FMath::Abs(SmoothedAimingAngle.X), 0.f, 180.f, 0.5f, 1.f);
	ForwardYawTime = UKismetMathLibrary::MapRangeClamped(SmoothedAimingAngle.X, -180.f, 180.f, 0.f, 1.f);
}

void UBaseAnimInstance::ALS_UpdateFootIK(URoleMovementComponent& RMC, float DeltaSeconds)
{

	FVector LocationDiffInOneFrame = LastViewActorTransform.GetLocation() - ViewActorTransform.GetLocation();
	FRotator RotationDiffInOneFrame = LastViewActorTransform.GetRotation().Rotator() - ViewActorTransform.GetRotation().Rotator();
	RotationDiffInOneFrame.Normalize();
	// 具体太大, 就是类似传送、或者被直接裸设置位置了
	if (LocationDiffInOneFrame.Length() > ALSAnimConfig.IK_Tolerate_Distance || VelocityValue * DeltaSeconds > ALSAnimConfig.IK_Tolerate_Distance ||
		FMath::Abs(RotationDiffInOneFrame.Pitch) > ALSAnimConfig.IK_Tolerate_Angle || FMath::Abs(RotationDiffInOneFrame.Yaw) > ALSAnimConfig.IK_Tolerate_Angle ||
		FMath::Abs(RotationDiffInOneFrame.Roll) > ALSAnimConfig.IK_Tolerate_Angle)
	{
		ResetIKOffsets();
	}
	else
	{
		FVector FootOffsetLTarget = FVector::ZeroVector;
		FVector FootOffsetRTarget = FVector::ZeroVector;

		// 当操控运动过程中,
		FVector VelocityXYVec = MovementVelocity;
		VelocityXYVec.Z = 0;
	
		if(VelocityXYVec.Length() > 1.0f)
		{
			float CosOfFaceAndDriveDir = ViewActorTransform.GetRotation().GetForwardVector().Dot(VelocityXYVec.GetSafeNormal());
		
			CosOfFaceAndDriveDir = (CosOfFaceAndDriveDir + 1.0f) / 2.0f; // 使用cosine 变化趋势, 但是值归一化

			// 除去掉正常朝向变化的ik抖动
			if(CosOfFaceAndDriveDir > ALSAnimConfig.IK_FootIKApplyRatioThreshold)
			{
				CosOfFaceAndDriveDir = 1.0f;
			}
			else
			{
				CosOfFaceAndDriveDir = UKismetMathLibrary::MapRangeClamped(CosOfFaceAndDriveDir, 0.0, 0.8f, 0.0f, 1.0f);
			}

			// 0.2s 完成数值过渡
			FootIKValues.FootIKApplyExtraRatio = MathFormula::LinearCloseToDst(FootIKValues.FootIKApplyExtraRatio, CosOfFaceAndDriveDir, 5.0, DeltaSeconds);
		}
		else
		{
			// 注意：这里LockingTarget时使用0.95，是为了解决切换索敌目标时大角度转身，DynamicTransition中的脚步扭曲问题
			// https://gamecloud-redmine.corp.kuaishou.com/1007/projects/c7/issues/230878
			// #230878 【Bug】【序章3C】八向移动时切换锁定目标，脚步朝向不会发生改变导致腿部模型扭曲
			// 后续使用MotionWarp解决该朝向问题
			FootIKValues.FootIKApplyExtraRatio = MathFormula::LinearCloseToDst(FootIKValues.FootIKApplyExtraRatio, bIsLockingTarget ? 0.95f : 1.0f, 5.0, DeltaSeconds);
		}
	
		// Update Foot Locking values.
		SetFootLocking(DeltaSeconds, EnableFootIKAlpha, NAME_FootLock_L_CurveName,
					   FCommonHumanSkeletonBoneNames::GetIKFootL(), FootIKValues.FootLock_L_Alpha,
					   FootIKValues.FootLock_L_Location, FootIKValues.FootLock_L_Rotation);
		SetFootLocking(DeltaSeconds, EnableFootIKAlpha, NAME_FootLock_R_CurveName,
					   FCommonHumanSkeletonBoneNames::GetIKFootR(), FootIKValues.FootLock_R_Alpha, 
					   FootIKValues.FootLock_R_Location, FootIKValues.FootLock_R_Rotation);

		// Update all Foot Lock and Foot Offset values when not In Air
		SetFootOffsets(RMC, DeltaSeconds, EnableFootIKAlpha, FCommonHumanSkeletonBoneNames::GetIKFootL(), NAME__ALSCharacterAnimInstance__root,
					   FootOffsetLTarget,
					   FootIKValues.FootOffset_L_Location, FootIKValues.FootOffset_L_Rotation);
		SetFootOffsets(RMC, DeltaSeconds, EnableFootIKAlpha, FCommonHumanSkeletonBoneNames::GetIKFootR(), NAME__ALSCharacterAnimInstance__root,
					   FootOffsetRTarget,
					   FootIKValues.FootOffset_R_Location, FootIKValues.FootOffset_R_Rotation);
		SetPelvisIKOffset(DeltaSeconds, FootOffsetLTarget, FootOffsetRTarget);

		UpdateModifyBoneAutoAdd(
		FCommonHumanSkeletonBoneNames::GetIKFootL(),
		EC7BoneModificationMode::BMM_Replace, EC7BoneModificationMode::BMM_Replace, EC7BoneModificationMode::BMM_Ignore,
		EBoneControlSpace::BCS_ComponentSpace, FootIKValues.FootLock_L_Location.X, FootIKValues.FootLock_L_Location.Y, FootIKValues.FootLock_L_Location.Z,
		FootIKValues.FootLock_L_Rotation.Pitch, FootIKValues.FootLock_L_Rotation.Yaw, FootIKValues.FootLock_L_Rotation.Roll, 1, 1, 1,
		NAME_None, 1, FootIKValues.FootLock_L_Alpha * FootIKValues.FootIKApplyExtraRatio);

		UpdateModifyBoneAutoAdd(
			FCommonHumanSkeletonBoneNames::GetIKFootR(),
			EC7BoneModificationMode::BMM_Replace, EC7BoneModificationMode::BMM_Replace, EC7BoneModificationMode::BMM_Ignore,
			EBoneControlSpace::BCS_ComponentSpace, FootIKValues.FootLock_R_Location.X, FootIKValues.FootLock_R_Location.Y, FootIKValues.FootLock_R_Location.Z,
			FootIKValues.FootLock_R_Rotation.Pitch, FootIKValues.FootLock_R_Rotation.Yaw, FootIKValues.FootLock_R_Rotation.Roll, 1, 1, 1,
			NAME_None, 1, FootIKValues.FootLock_R_Alpha * FootIKValues.FootIKApplyExtraRatio);
		
		UpdateModifyBoneAutoAdd(
			FCommonHumanSkeletonBoneNames::GetVBIkFootLOffset(),
			EC7BoneModificationMode::BMM_Additive, EC7BoneModificationMode::BMM_Additive, EC7BoneModificationMode::BMM_Ignore,
			EBoneControlSpace::BCS_WorldSpace, FootIKValues.FootOffset_L_Location.X, FootIKValues.FootOffset_L_Location.Y, FootIKValues.FootOffset_L_Location.Z,
			FootIKValues.FootOffset_L_Rotation.Pitch, FootIKValues.FootOffset_L_Rotation.Yaw, FootIKValues.FootOffset_L_Rotation.Roll, 1, 1, 1,
			NAME_None, 1, EnableFootIKAlpha * FootIKValues.FootIKApplyExtraRatio);

		UpdateModifyBoneAutoAdd(
			FCommonHumanSkeletonBoneNames::GetVBIkFootROffset(),
			EC7BoneModificationMode::BMM_Additive, EC7BoneModificationMode::BMM_Additive, EC7BoneModificationMode::BMM_Ignore,
			EBoneControlSpace::BCS_WorldSpace, FootIKValues.FootOffset_R_Location.X, FootIKValues.FootOffset_R_Location.Y, FootIKValues.FootOffset_R_Location.Z,
			FootIKValues.FootOffset_R_Rotation.Pitch, FootIKValues.FootOffset_R_Rotation.Yaw, FootIKValues.FootOffset_R_Rotation.Roll, 1, 1, 1,
			NAME_None, 1, EnableFootIKAlpha * FootIKValues.FootIKApplyExtraRatio );

		UpdateModifyBoneAutoAdd(
			FCommonHumanSkeletonBoneNames::GetPelvis(),
			EC7BoneModificationMode::BMM_Additive, EC7BoneModificationMode::BMM_Ignore, EC7BoneModificationMode::BMM_Ignore,
			EBoneControlSpace::BCS_WorldSpace, FootIKValues.PelvisOffset.X, FootIKValues.PelvisOffset.Y, FootIKValues.PelvisOffset.Z,
			0, 0, 0, 1, 1, 1,
			NAME_None, 1, FootIKValues.PelvisAlpha * FootIKValues.FootIKApplyExtraRatio);

		UpdateModifyBoneAutoAdd(
			FCommonHumanSkeletonBoneNames::GetVBIkKneeTargetL(),
			EC7BoneModificationMode::BMM_Additive, EC7BoneModificationMode::BMM_Ignore, EC7BoneModificationMode::BMM_Ignore,
			EBoneControlSpace::BCS_BoneSpace, ALSAnimConfig.IK_KneeTargetLOffset.X, ALSAnimConfig.IK_KneeTargetLOffset.Y, ALSAnimConfig.IK_KneeTargetLOffset.Z,
			0, 0, 0, 1, 1, 1,
			NAME_None, 1, EnableFootIKAlpha * FootIKValues.FootIKApplyExtraRatio);

		UpdateModifyBoneAutoAdd(
			FCommonHumanSkeletonBoneNames::GetVBIkKneeTargetR(),
			EC7BoneModificationMode::BMM_Additive, EC7BoneModificationMode::BMM_Ignore, EC7BoneModificationMode::BMM_Ignore,
			EBoneControlSpace::BCS_BoneSpace, ALSAnimConfig.IK_KneeTargetROffset.X, ALSAnimConfig.IK_KneeTargetROffset.Y, ALSAnimConfig.IK_KneeTargetROffset.Z,
			0, 0, 0, 1, 1, 1,
			NAME_None, 1, EnableFootIKAlpha * FootIKValues.FootIKApplyExtraRatio);


		AddOrUpdateTwoBoneIKParam(FCommonHumanSkeletonBoneNames::GetFootL(), EBoneControlSpace::BCS_BoneSpace, true,
			FCommonHumanSkeletonBoneNames::GetVBIkFootLOffset(), EC7TwoBoneIKModificationMode::TBMM_Replace, FVector::Zero(),
			ALSAnimConfig.IK_StartStretchRatio, ALSAnimConfig.IK_MaxStretchScale, true, false, true,FAxis(FVector::ForwardVector),
			EBoneControlSpace::BCS_BoneSpace, FCommonHumanSkeletonBoneNames::GetVBIkKneeTargetL(), FVector::Zero(),
			EnableFootIKAlpha * FootIKValues.FootIKApplyExtraRatio, NAME_None, 0);
			
		AddOrUpdateTwoBoneIKParam(FCommonHumanSkeletonBoneNames::GetFootR(), EBoneControlSpace::BCS_BoneSpace, true,
			FCommonHumanSkeletonBoneNames::GetVBIkFootROffset(), EC7TwoBoneIKModificationMode::TBMM_Replace, FVector::Zero(),
			ALSAnimConfig.IK_StartStretchRatio, ALSAnimConfig.IK_MaxStretchScale, true, false, true,FAxis(FVector::ForwardVector),
			EBoneControlSpace::BCS_BoneSpace, FCommonHumanSkeletonBoneNames::GetVBIkKneeTargetR(), FVector::Zero(),
			EnableFootIKAlpha * FootIKValues.FootIKApplyExtraRatio, NAME_None, 0);
	}
	


}

void UBaseAnimInstance::SetFootLocking(float DeltaSeconds, float EnableFootIKAlphaArg, FName FootLockCurve,
                                               FName IKFootBone, float& CurFootLockAlpha,
                                               FVector& CurFootLockLoc, FRotator& CurFootLockRot)
{
	if (EnableFootIKAlphaArg <= 0.0f)
	{
		return;
	}

	// 由原來的0.99调整成0.8, 有一定的滑步, 但是能够解决之前的连续间断按键移动的腿部拉长
	const float CurveThresholdToLock = ALSAnimConfig.IK_LockAlphaThreshold;
	// Step 1: Set Local FootLock Curve value
	float FootLockCurveVal = GetCurveValue(FootLockCurve);

	// Step 2: Only update the FootLock Alpha if the new value is less than the current, or it equals 1. This makes it
	// so that the foot can only blend out of the locked position or lock to a new position, and never blend in.
	if (FootLockCurveVal >= CurveThresholdToLock || FootLockCurveVal < CurFootLockAlpha)
	{
		CurFootLockAlpha = FootLockCurveVal;
	}

	// Step 3: If the Foot Lock curve equals 1, save the new lock location and rotation in component space as the target.
	if (CurFootLockAlpha >= CurveThresholdToLock)
	{
		const FTransform& OwnerTransform =
			GetOwningComponent()->GetSocketTransform(IKFootBone, RTS_Component);
		CurFootLockLoc = OwnerTransform.GetLocation();
		CurFootLockRot = OwnerTransform.Rotator();
	}

	// Step 4: If the Foot Lock Alpha has a weight,
	// update the Foot Lock offsets to keep the foot planted in place while the capsule moves.
	if (CurFootLockAlpha > 0.0f)
	{
		SetFootLockOffsets(DeltaSeconds, CurFootLockLoc, CurFootLockRot);
	}
}

void UBaseAnimInstance::SetFootLockOffsets(float DeltaSeconds, FVector& LocalLoc, FRotator& LocalRot)
{
	FRotator RotationDifference = FRotator::ZeroRotator;
	// Use the delta between the current and last updated rotation to find how much the foot should be rotated
	// to remain planted on the ground.
	RotationDifference = ViewActorTransform.GetRotation().Rotator() - LastActorRotation;
	RotationDifference.Normalize();

	// Get the distance traveled between frames relative to the mesh rotation
	// to find how much the foot should be offset to remain planted on the ground.
	// 这里原本使用速度来计算, 但是因为可能会卡帧, delta时间大, 所以就会估计错误; 例如被直接设置location的时候, 这个速度本质上是瞬时的, 不是常规的运动速度
	//const FVector& LocationDifference = GetOwningComponent()->GetComponentRotation().UnrotateVector(
	//	MovementVelocity * DeltaSeconds);
	const FVector& LocationDifference = GetOwningComponent()->GetComponentRotation().UnrotateVector(
		ViewActorTransform.GetLocation() - LastViewActorTransform.GetLocation()	
	);

	// Subtract the location difference from the current local location and rotate
	// it by the rotation difference to keep the foot planted in component space.
	LocalLoc = (LocalLoc - LocationDifference).RotateAngleAxis(RotationDifference.Yaw, FVector::DownVector);

	// Subtract the Rotation Difference from the current Local Rotation to get the new local rotation.
	FRotator Delta = LocalRot - RotationDifference;
	Delta.Normalize();
	LocalRot = Delta;
}

void UBaseAnimInstance::SetPelvisIKOffset(float DeltaSeconds, FVector FootOffsetLTarget,
                                                  FVector FootOffsetRTarget)
{
	// Calculate the Pelvis Alpha by finding the average Foot IK weight. If the alpha is 0, clear the offset.
	FootIKValues.PelvisAlpha = EnableFootIKAlpha;

	if (FootIKValues.PelvisAlpha > 0.0f)
	{
		// Step 1: Set the new Pelvis Target to be the lowest Foot Offset
		const FVector PelvisTarget = FootOffsetLTarget.Z < FootOffsetRTarget.Z ? FootOffsetLTarget : FootOffsetRTarget;

		// Step 2: Interp the Current Pelvis Offset to the new target value.
		//Interpolate at different speeds based on whether the new target is above or below the current one.
		//const float InterpSpeed = PelvisTarget.Z > FootIKValues.PelvisOffset.Z ? 10.0f : 15.0f;
		const float InterpSpeed = ALSAnimConfig.IK_PelvisInterSpeed;
		FootIKValues.PelvisOffset =
			FMath::VInterpTo(FootIKValues.PelvisOffset, PelvisTarget, DeltaSeconds, InterpSpeed);
	}
	else
	{
		FootIKValues.PelvisOffset = FVector::ZeroVector;
	}
}

void UBaseAnimInstance::ResetIKOffsets()
{
	// Interp Foot IK offsets back to 0
	FootIKValues.FootOffset_L_Location = FVector::ZeroVector;
	FootIKValues.FootOffset_R_Location = FVector::ZeroVector;
	FootIKValues.FootOffset_L_Rotation = FRotator::ZeroRotator;
	FootIKValues.FootOffset_R_Rotation = FRotator::ZeroRotator;
	FootIKValues.FootLock_L_Alpha = 0.0f;
	FootIKValues.FootLock_R_Alpha = 0.0f;
	FootIKValues.FootIKApplyExtraRatio = 1.0f;
	FootIKValues.FootLock_L_Location = FVector::ZeroVector;
	FootIKValues.TargetFootLock_R_Location = FVector::ZeroVector;
	FootIKValues.FootLock_R_Location = FVector::ZeroVector;
	FootIKValues.TargetFootLock_L_Rotation = FRotator::ZeroRotator;
	FootIKValues.FootLock_L_Rotation = FRotator::ZeroRotator;
	FootIKValues.TargetFootLock_R_Rotation = FRotator::ZeroRotator;
	FootIKValues.FootLock_R_Rotation = FRotator::ZeroRotator;
	FootIKValues.PelvisOffset = FVector::ZeroVector;
	FootIKValues.PelvisAlpha = 0.0f;

	RemoveModifyBone(FCommonHumanSkeletonBoneNames::GetIKFootL());
	RemoveModifyBone(FCommonHumanSkeletonBoneNames::GetIKFootR());
	RemoveModifyBone(FCommonHumanSkeletonBoneNames::GetVBIkFootLOffset());
	RemoveModifyBone(FCommonHumanSkeletonBoneNames::GetVBIkFootROffset());
	RemoveModifyBone(FCommonHumanSkeletonBoneNames::GetPelvis());
	RemoveModifyBone(FCommonHumanSkeletonBoneNames::GetVBIkKneeTargetL());
	RemoveModifyBone(FCommonHumanSkeletonBoneNames::GetVBIkKneeTargetR());
	RemoveTwoBoneIKParam(FCommonHumanSkeletonBoneNames::GetFootL());
	RemoveTwoBoneIKParam(FCommonHumanSkeletonBoneNames::GetFootR());
}

void UBaseAnimInstance::SetFootOffsets(URoleMovementComponent & CharacterMC, float DeltaSeconds, float EnableFootIKAlphaArg, FName IKFootBone,
                                               FName RootBone, FVector& CurLocationTarget, FVector& CurLocationOffset,
                                               FRotator& CurRotationOffset)
{
	// Only update Foot IK offset values if the Foot IK curve has a weight. If it equals 0, clear the offset values.
	if (EnableFootIKAlphaArg <= 0)
	{
		CurLocationOffset = FVector::ZeroVector;
		CurRotationOffset = FRotator::ZeroRotator;
		return;
	}

	// Step 1: Trace downward from the foot location to find the geometry.
	// If the surface is walkable, save the Impact Location and Normal.
	USkeletalMeshComponent* OwnerComp = GetOwningComponent();
	FVector IKFootFloorLoc = OwnerComp->GetSocketLocation(IKFootBone);
	IKFootFloorLoc.Z = OwnerComp->GetSocketLocation(RootBone).Z;

	UWorld* World = GetWorld();
	check(World);

	FCollisionQueryParams Params;
	Params.AddIgnoredActor(CharacterMC.GetOwner());

	const FVector TraceStart = IKFootFloorLoc + FVector(0.0, 0.0, ALSAnimConfig.IK_TraceDistanceAboveFoot);
	const FVector TraceEnd = IKFootFloorLoc - FVector(0.0, 0.0, ALSAnimConfig.IK_TraceDistanceBelowFoot);

	FHitResult HitResult;
	const bool bHit = World->LineTraceSingleByChannel(HitResult,
	                                                  TraceStart,
	                                                  TraceEnd,
	                                                  ECC_Visibility, Params);


	FRotator TargetRotOffset = FRotator::ZeroRotator;
	if (CharacterMC.IsWalkable(HitResult))
	{
		FVector ImpactPoint = HitResult.ImpactPoint;
		FVector ImpactNormal = HitResult.ImpactNormal;

		if(FMath::Abs(ImpactNormal.ToOrientationRotator().Pitch) > ALSAnimConfig.IK_SlopeAngle)
		{
			// Step 1.1: Find the difference in location from the Impact point and the expected (flat) floor location.
			// These values are offset by the normal multiplied by the
			// foot height to get better behavior on angled surfaces.

			// 这里限制一下IK目标调整点的最大距离限制, 否则会有很奇怪的姿态
			CurLocationTarget = (ImpactPoint + ImpactNormal * ALSAnimConfig.FootHeight) -
				(IKFootFloorLoc + FVector(0, 0, ALSAnimConfig.FootHeight));

			if(CurLocationTarget.Length() > ALSAnimConfig.IK_FootOffsetMaxOffset)
			{
				CurLocationTarget = CurLocationTarget.GetSafeNormal() * ALSAnimConfig.IK_FootOffsetMaxOffset;
			}
			
			// Step 1.2: Calculate the Rotation offset by getting the Atan2 of the Impact Normal.
			TargetRotOffset.Pitch = -FMath::RadiansToDegrees(FMath::Atan2(ImpactNormal.X, ImpactNormal.Z));
			TargetRotOffset.Roll = FMath::RadiansToDegrees(FMath::Atan2(ImpactNormal.Y, ImpactNormal.Z));
		}
		else
		{
			CurLocationTarget.Set(0, 0, 0);
			TargetRotOffset = FRotator::ZeroRotator;
		
		}
	
	}

	// Step 2: Interp the Current Location Offset to the new target value.
	// Interpolate at different speeds based on whether the new target is above or below the current one.
	const float InterpSpeed = CurLocationOffset.Z > CurLocationTarget.Z ? 30.f : 15.0f;
	CurLocationOffset = FMath::VInterpTo(CurLocationOffset, CurLocationTarget, DeltaSeconds, InterpSpeed);

	// Step 3: Interp the Current Rotation Offset to the new target value.
	CurRotationOffset = FMath::RInterpTo(CurRotationOffset, TargetRotOffset, DeltaSeconds, 30.0f);

}


#pragma endregion ALS


#if UE_BUILD_DEVELOPMENT

void UBaseAnimInstance::AppendDebugInfo(FString& InfoOut)
{
	TStringBuilder<10240> TempInfoOut;
	float FootValue = this->GetCurveValue(FootPostureCurveName);
	TempInfoOut.Append(TEXT("<Title_Green>[Animation Instance]</>\n"));
	TempInfoOut.Append(TEXT("----------\n"));
	TempInfoOut.Appendf(TEXT("<Text>PrevStateName:%s  CurStateName: %s</>\n"), *PrevSMStateName.ToString(), *CurSMStateName.ToString());
	if (USkeletalMeshComponent* SKMesh = GetOwningComponent())
	{
		TempInfoOut.Appendf(TEXT("<Text>GlobalPlayRate: %f</>\n"), SKMesh->GlobalAnimRateScale);
	}
	TempInfoOut.Appendf(TEXT("<Text>IsSlaveControl:%d  FootCurve: %.1f  FootPosture:%i  CachedFootPosture:%i</>\n"), IsSlaveAnimControl, FootValue, FootPosture, CachedFootPosture);
	TempInfoOut.Appendf(TEXT("<Text>Current AnimMovePosture: %d MoveAnimPlayRate: %.3f DelayedAnimMovePosture: %d DelayedMoveAnimPlayRate: %.3f</>\n"), this->AnimMovePosture, this->MoveAnimPlayRate, this->DelayedAnimMovePosture, this->DelayedMoveAnimPlayRate);
	TempInfoOut.Appendf(TEXT("<Text>LastExpectVelocityInAirZ: %f HighJumpEndVelocityZThreshold: %f IsHighJumpEnd: %d IsGrounded: %d</>\n"), LastExpectVelocityInAir.Z, HighJumpEndVelocityZThreshold, IsHighJumpEnd, IsGrounded);
	TempInfoOut.Appendf(TEXT("<Text>ExpectedVelocity: %s  OnGroundExpectedVelocity: %s</>\n"), *ExpectedVelocity.ToString(), *OnGroundExpectedVelocity.ToString());
	TempInfoOut.Appendf(TEXT("<Text>bEnableCalculateBodyLean: %d  bEnableCalculateInputAxis: %d</>\n"), bEnableCalculateBodyLean, bEnableCalculateInputAxis);
	TempInfoOut.Appendf(TEXT("<Text>ALSMovePosture: %d  bInALSMode: %d  ALSLocoDirection:%d  bShouldMove:%d  ALS_OverLayState:%d</>\n"), ALSMovePosture, bIsALSMode , ALSLocoDirection, bShouldMove, ALS_OverLayState );
	TArray<FAnimMontageInstance*>& MontageArray = this->MontageInstances;
	TempInfoOut.Append(TEXT("<Text>Current Playing Montage: </>\n"));
	for (const FAnimMontageInstance* MontageInstance : MontageArray)
	{
		TempInfoOut.Appendf(TEXT("<Text>%s P(%.2f) W(%.0f%%)</>\n"), *MontageInstance->Montage->GetName(), MontageInstance->GetPosition(), MontageInstance->GetWeight()*100.0f);
	}

	TempInfoOut.Appendf(TEXT("<Text>ThreeLayer bActionWorking: %d</>\n"), ThreeLayerPostureParam.bActionWorking);
	TempInfoOut.Appendf(TEXT("<Text>ThreeLayer ActionBlendRule: %d</>\n"), ThreeLayerPostureParam.ActionBlendRule);
	TempInfoOut.Appendf(TEXT("<Text>ThreeLayer ActionBlendTime: %f</>\n"), ThreeLayerPostureParam.ActionBlendTime);
	TempInfoOut.Appendf(TEXT("<Text>ThreeLayer bPerformWorking: %d</>\n"), ThreeLayerPostureParam.bPerformWorking);
	TempInfoOut.Appendf(TEXT("<Text>ThreeLayer PerformBlendTime: %f</>\n"), ThreeLayerPostureParam.PerformBlendTime);
	TempInfoOut.Appendf(TEXT("<Text>ThreeLayer bLocoMoving: %d</>\n"), ThreeLayerPostureParam.bLocoMoving);
	TempInfoOut.Appendf(TEXT("<Text>ThreeLayer bActionWorking: %s</>\n"), *ThreeLayerPostureParam.ActionFilterBoneName.ToString());

	TempInfoOut.Appendf(
		TEXT("<Text>bEnableAnimContirubteSig: %d,  ConfigSig:%.2f   CurSig:%.2f</>\n"),
		bEnableTrivialAnimSignificanceOffset, ConfigTrivialAnimSignificanceOffset, CurTrivialAnimSignificanceOffset);

	TempInfoOut.Append(TEXT("-----IK Infos-----\n"));
	TempInfoOut.Appendf(TEXT("<Text>UsingFootLock: %d,  leftBone:%s   rightBone:%s</>\n"), UsingFootLock, *FootL_BoneName.ToString(), *FootR_BoneName.ToString());
	TempInfoOut.Appendf(TEXT("<Text>EnableFootIKAlpha: %.2f  FootLockAlpha_L:%.2f FootLockAlpha_R:%.2f  FootIKApplyExtraRatio:%.2f</>\n"), EnableFootIKAlpha, FootIKValues.FootLock_L_Alpha, FootIKValues.FootLock_R_Alpha, FootIKValues.FootIKApplyExtraRatio);


	if(USkeletalMeshComponent * MainMesh = GetSkelMeshComponent())
	{
		for(auto & ModifyParam:BonesModifyMap)
		{
			TempInfoOut.Appendf(TEXT("<Text>ModifyBoneName: %s  TarPosArg:%s  CurComponentPos:%s   CurWorldPos:%s   AlphaCurve:%s Alpha:%.2f </>\n"),
				*ModifyParam.Value.BoneToModify.ToString(), *ModifyParam.Value.Transform.GetLocation().ToCompactString(),
				*MainMesh->GetBoneLocation(	ModifyParam.Value.BoneToModify, EBoneSpaces::ComponentSpace).ToCompactString(),
				*MainMesh->GetBoneLocation(ModifyParam.Value.BoneToModify, EBoneSpaces::WorldSpace).ToCompactString(),
				*ModifyParam.Value.AlphaCurveName.ToString(),
				ModifyParam.Value.BlendAlpha
				);
		}

		for(auto & TwoBoneModifyParam:BatchTwoBoneIKParams)
		{
			TempInfoOut.Appendf(TEXT("<Text>TwoBoneName: %s  CurComponentIKPos:%s   CurWorldIKPos:%s  TarEffectBone:%s TarEffectPosArg:%s  CurEffectorComPos:%s  CurEffectorWorldPos:%s   AlphaCurve:%s Alpha:%.2f </>\n"),
				*TwoBoneModifyParam.Value.IKBone.BoneName.ToString(),
				*MainMesh->GetBoneLocation(TwoBoneModifyParam.Value.IKBone.BoneName, EBoneSpaces::ComponentSpace).ToCompactString(),
				*MainMesh->GetBoneLocation(TwoBoneModifyParam.Value.IKBone.BoneName, EBoneSpaces::WorldSpace).ToCompactString(),
				*TwoBoneModifyParam.Value.EffectorTarget.BoneReference.BoneName.ToString(),
				*TwoBoneModifyParam.Value.EffectorLocation.ToCompactString(),
				*MainMesh->GetBoneLocation(TwoBoneModifyParam.Value.EffectorTarget.BoneReference.BoneName, EBoneSpaces::ComponentSpace).ToCompactString(),
				*MainMesh->GetBoneLocation(TwoBoneModifyParam.Value.EffectorTarget.BoneReference.BoneName, EBoneSpaces::WorldSpace).ToCompactString(),
				*TwoBoneModifyParam.Value.AlphaCurveName.ToString(),
				TwoBoneModifyParam.Value.BlendAlpha
				);
		}
	}

	
	TempInfoOut.Append(TEXT("-----Animation Weights-----\n"));

	FString DebugStr;
	TArray<FString> DebugAnimInfos;
	GetAllActiveAnimationMessages(DebugAnimInfos, true);
	for (auto& Elem : DebugAnimInfos)
	{
		DebugStr += Elem;
		DebugStr += "\n";
	}
	TempInfoOut.Append(DebugStr);
	TempInfoOut.Append(TEXT("-----Animation End------------\n"));
	InfoOut.Append(TempInfoOut.ToString());
}
#endif


