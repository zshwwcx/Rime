// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Animation/AnimNotify/AnimNotify_C7AnimFeatureOperation.h"

#include "3C/Animation/BaseAnimInstance.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Character/C7Actor.h"

void UAnimNotify_C7AnimFeatureOperation::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotify_C7AnimFeatureOperation::Notify");
	
	ABaseCharacter* TargetCharacter = Cast<ABaseCharacter>(MeshComp->GetOwner());
	AC7Actor* C7Actor = Cast<AC7Actor>(MeshComp->GetOwner());
	if (TargetCharacter == nullptr && C7Actor == nullptr)
	{
		return;
	}
	
	switch (AnimFeatureType)
	{
	case EAnimFeatureNotifyType::AttachItem:
		if(TargetCharacter)
		{
			TargetCharacter->CallLuaEntity(TargetCharacter, TargetCharacter->GetEntityUID(), "KCB_OnAnimNotify_C7AttachItem", TargetCharacter->GetEntityUID(), AttachItem.AttachItemName,
				static_cast<int>(AttachItem.AttachNotifyType), AttachItem.bAttachFadeInOut);
		}
		else
		{
			C7Actor->CallLuaEntity(C7Actor, C7Actor->GetEntityUID(), "KCB_OnAnimNotify_C7AttachItem", C7Actor->GetEntityUID(), AttachItem.AttachItemName,
				static_cast<int>(AttachItem.AttachNotifyType), AttachItem.bAttachFadeInOut);
		}
		break;
	case EAnimFeatureNotifyType::AnimPoseRdy:
		if(TargetCharacter)
		{
			TargetCharacter->CallLuaEntity(TargetCharacter, TargetCharacter->GetEntityUID(), "KCB_OnAnimNotify_AnimPoseRdy", TargetCharacter->GetEntityUID(), static_cast<int>(PoseRdyTag));
		}
		else
		{
			C7Actor->CallLuaEntity(C7Actor, C7Actor->GetEntityUID(), "KCB_OnAnimNotify_AnimPoseRdy", C7Actor->GetEntityUID(), static_cast<int>(PoseRdyTag));
		}
		break;
	case EAnimFeatureNotifyType::EnvInteractRdyForOut:
		if(TargetCharacter)
		{
			TargetCharacter->CallLuaEntity(TargetCharacter, TargetCharacter->GetEntityUID(), "KCB_OnAnimNotify_EnvInteractRdyForOut", TargetCharacter->GetEntityUID(), EnvInteractTag);
		}
		else
		{
			C7Actor->CallLuaEntity(C7Actor, C7Actor->GetEntityUID(), "KCB_OnAnimNotify_EnvInteractRdyForOut", C7Actor->GetEntityUID(), EnvInteractTag);
		}
		break;
	}
}
