/**
 * Auth :   liubo
 * Date :   2026-02-07 15:21
 * Comment: 实验功能，有很多临时代码，不要正式使用
 */
 
#include "3C/Animation/AnimationGraphNode/AnimNode_AIFacePlayer.h"
#include "Animation/AnimInstanceProxy.h"
#include "AnimEncoding.h"
#include "Animation/AnimBlueprintGeneratedClass.h"
#include "Animation/AnimTrace.h"
#include "Animation/AnimMontage.h"
#include "AnimationRuntime.h" // 添加AnimationRuntime头文件
#include "Misc/FileHelper.h" // 用于文件读取
#include "Serialization/JsonReader.h" // JSON读取
#include "Serialization/JsonSerializer.h"
#include "Misc/Base64.h" // Base64解码
#include "Dom/JsonObject.h"
#include "3C/Animation/BaseAnimInstance.h"
#include "Animation/SkeletonRemappingRegistry.h"
#include "Managers/KGWebAnimationManager.h"

#define LOCTEXT_NAMESPACE "AnimNode_AIFacePlayer"


FAnimNode_AIFacePlayer::FAnimNode_AIFacePlayer()
{
	PlayTime = 0.0f;
	IsPlaying = false;
	IsPaused = false;
	Loop = false;
}

void FAnimNode_AIFacePlayer::Initialize_AnyThread(const FAnimationInitializeContext& Context)
{
	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(Initialize_AnyThread)
	FAnimNode_Base::Initialize_AnyThread(Context);
	BasePose.Initialize(Context);
	PlayTime = 0.0f;
	RetargetSourceName = "SK_Base_F"; // 暂时先写死
}

void FAnimNode_AIFacePlayer::CacheBones_AnyThread(const FAnimationCacheBonesContext& Context)
{
	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(CacheBones_AnyThread)
	FAnimNode_Base::CacheBones_AnyThread(Context);
	BasePose.CacheBones(Context);

	// 缓存骨骼引用 (UE5版本)
	BoneReferences.Empty();
	const FBoneContainer& BoneContainer = Context.AnimInstanceProxy->GetRequiredBones();
	for (const FC7BoneAnimationTrack& Track : AnimationData.BoneTracks)
	{
		FBoneReference BoneRef;
		BoneRef.BoneName = FName(*Track.BoneName);
		BoneRef.Initialize(BoneContainer);
		BoneReferences.Add(BoneRef);
	}
}

void FAnimNode_AIFacePlayer::Update_AnyThread(const FAnimationUpdateContext& Context)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_AIFacePlayer::Update_AnyThread");
	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(Update_AnyThread)
	GetEvaluateGraphExposedInputs().Execute(Context);
	
	FAnimNode_Base::Update_AnyThread(Context);
	BasePose.Update(Context);

	if (!IsPlaying)
	{
		// 停止播放时清空骨骼引用
		if (!BoneReferences.IsEmpty())
		{
			BoneReferences.Empty();
		}
		return;
	}

	// 暂停时保持当前帧，不更新时间
	if (IsPaused)
	{
		return;
	}
	
	if (BoneReferences.Num() != AnimationData.BoneTracks.Num())
	{
		UE_LOG(LogTemp, Log, TEXT("AIFacePlayer Update_AnyThread: Rebuild BoneReferences"));
		const FBoneContainer& BoneContainer = Context.AnimInstanceProxy->GetRequiredBones();
		for (const FC7BoneAnimationTrack& Track : AnimationData.BoneTracks)
		{
			FBoneReference BoneRef;
			BoneRef.BoneName = FName(*Track.BoneName);
			BoneRef.Initialize(BoneContainer);
			BoneReferences.Add(BoneRef);
		}
	}

	// 添加动画追踪 (UE5特性)
	TRACE_ANIM_NODE_VALUE(Context, TEXT("PlayTime"), PlayTime);
	TRACE_ANIM_NODE_VALUE(Context, TEXT("IsPlaying"), IsPlaying);
	TRACE_ANIM_NODE_VALUE(Context, TEXT("IsPaused"), IsPaused);
	if (AnimationData.Duration > 0.0f)
	{
		// 更新内部时间
		PlayTime += Context.GetDeltaTime();

		if (Loop)
		{
			// 循环播放模式
			PlayTime = FMath::Fmod(PlayTime, AnimationData.Duration);
			BlendToEndWeight = 1;			
		}
		else
		{
			// 非循环播放模式
			if (PlayTime >= AnimationData.Duration)
			{
				// 播放结束，停止播放
				PlayTime = AnimationData.Duration;
				IsPlaying = false;
				BlendToEndWeight = 0;
			}
			else
			{
				const float WeightTime = 0.2f;
				float PendingWeightTime = AnimationData.Duration - PlayTime; 
				if(PendingWeightTime < WeightTime)
				{
					BlendToEndWeight = PendingWeightTime / WeightTime;
				}
				else
				{
					BlendToEndWeight = 1;
				}
			}
		}
	}
}

static float GC7AnimDeltaRot = 1;
static FAutoConsoleVariableRef CVarGC7AnimDeltaRot(
	TEXT("c7.ai.anim.deltarot"),
	GC7AnimDeltaRot,
	TEXT("c7.ai.anim.deltarot"),
	ECVF_Default);

static float GC7AnimDeltaPos = 1;
static FAutoConsoleVariableRef CVarGC7AnimDeltaPos(
	TEXT("c7.ai.anim.deltapos"),
	GC7AnimDeltaPos,
	TEXT("c7.ai.anim.deltapos"),
	ECVF_Default);

static float GC7AnimDeltaScale = 0.01f;
static FAutoConsoleVariableRef CVarGC7AnimDeltaScale(
	TEXT("c7.ai.anim.deltascale"),
	GC7AnimDeltaScale,
	TEXT("c7.ai.anim.deltascale"),
	ECVF_Default);

static int GC7AnimLerp = 1;
static FAutoConsoleVariableRef CVarGC7AnimLerp(
	TEXT("c7.ai.anim.lerp"),
	GC7AnimLerp,
	TEXT("c7.ai.anim.lerp"),
	ECVF_Default);

static int GC7AnimStopRun = 0;
static FAutoConsoleVariableRef CVarGC7AnimStopRun(
	TEXT("c7.ai.anim.stoprun"),
	GC7AnimStopRun,
	TEXT("c7.ai.anim.stoprun"),
	ECVF_Default);

static int GC7AnimLogic2 = 2;
static FAutoConsoleVariableRef CVarGC7AnimLogic2(
	TEXT("c7.ai.anim.logic2"),
	GC7AnimLogic2,
	TEXT("c7.ai.anim.logic2"),
	ECVF_Default);

static int GC7AnimLogicDisable = 0;
static FAutoConsoleVariableRef CVarGC7AnimLogicDisable(
	TEXT("c7.ai.anim.logic.disable"),
	GC7AnimLogicDisable,
	TEXT("c7.ai.anim.logic.disable"),
	ECVF_Default);

// 对于AI生成的表情，此值取0；对于美术导入的动画，此值取5.神奇了
static int GC7AnimLogicMapMethod = 5;
static FAutoConsoleVariableRef CVarGC7AnimLogicMapMethod(
	TEXT("c7.ai.anim.method"),
	GC7AnimLogicMapMethod,
	TEXT("c7.ai.anim.method"),
	ECVF_Default);

static int GC7AnimLogicSkipErrScale = 0;
static FAutoConsoleVariableRef CVarGC7AnimLogicSkipErrScale(
	TEXT("c7.ai.anim.skip.errscale"),
	GC7AnimLogicSkipErrScale,
	TEXT("c7.ai.anim..skip.errscale"),
	ECVF_Default);

void FAnimNode_AIFacePlayer::Evaluate_AnyThread(FPoseContext& Output)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_AIFacePlayer::Evaluate_AnyThread");

	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(Evaluate_AnyThread)

	if(bDebugDisableRetarget)
	{
		FBoneContainer& RequiredBones = Output.Pose.GetBoneContainer();
		RequiredBones.SetDisableRetargeting(true);		
	}
	
	BasePose.Evaluate(Output);
	
	if (!IsPlaying)
		return;
	
	if(GC7AnimLogicDisable)
	{
		return;
	}

	if(!bDebugDisableRetarget)
	{
		if(GC7AnimLogic2 > 0)
		{
			if(GC7AnimLogic2 == 3)
			{
				return Evaluate_AnyThread_LogicV3(Output); 
			}
			return Evaluate_AnyThread_LogicV2(Output);			
		}
	}
}

static bool bLogBoneNameDebug = false;

void FAnimNode_AIFacePlayer::CachedRetargetInfo_AnyThread(const FPoseContext& Output)
{
	if(!CachedRetargetInfo.bDirty)
	{
		return;
	}

	CachedRetargetInfo.CachedScaleTranslationMap.Empty();
	CachedRetargetInfo.CachedRelativeTransformMap.Empty();
	CachedRetargetInfo.CachedRelativeTransformMap2.Empty();
	CachedRetargetInfo.BoneInfo = FGetBonePoseScratchAreaC7(); 

	// 应用自定义动画
	const FCompactPose& OutPose = Output.Pose;
	const FCompactPose& PendingOutPose = Output.Pose;
	const FBoneContainer& RequiredBones = OutPose.GetBoneContainer();
	auto TargetSkeleton = RequiredBones.GetSkeletonAsset();
	auto SourceSkeleton = TargetSkeleton; 
	// UAnimInstance* AnimInstance = CastChecked<UAnimInstance>(Output.AnimInstanceProxy->GetAnimInstanceObject());
	// const USkeleton* SourceSkeleton = AnimInstance ? AnimInstance->GetSkelMeshComponent()->GetSkeletalMeshAsset()->Skeleton : nullptr;
	if(!SourceSkeleton || !TargetSkeleton)
	{
		return;
	}
	
	CachedRetargetInfo.SourceSkeleton = SourceSkeleton;
	CachedRetargetInfo.TargetSkeleton = TargetSkeleton;
	CachedRetargetInfo.RetargetSource = RetargetSourceName;
	
	const FSkeletonRemapping& SkeletonRemapping = UE::Anim::FSkeletonRemappingRegistry::Get().GetRemapping(SourceSkeleton, TargetSkeleton);
	auto RetargetSource = CachedRetargetInfo.RetargetSource;
	
	const auto& RetargetTransforms = CachedRetargetInfo.GetRetargetTransforms();

	BoneTrackArray& RotationScalePairs = CachedRetargetInfo.BoneInfo.RotationScalePairs;
	BoneTrackArray& TranslationPairs = CachedRetargetInfo.BoneInfo.TranslationPairs;
	BoneTrackArray& AnimScaleRetargetingPairs = CachedRetargetInfo.BoneInfo.AnimScaleRetargetingPairs;
	BoneTrackArray& AnimRelativeRetargetingPairs = CachedRetargetInfo.BoneInfo.AnimRelativeRetargetingPairs;
	BoneTrackArray& OrientAndScaleRetargetingPairs = CachedRetargetInfo.BoneInfo.OrientAndScaleRetargetingPairs;

	{
		TArray<int> Pending;
		// todo. 找到更合理的
		int MaxBoneCnt = FMath::Max<int32>(RequiredBones.GetReferenceSkeleton().GetNum(), TargetSkeleton->GetReferenceSkeleton().GetNum());
		for(int i=0; i<MaxBoneCnt; i++)
		{
			FSkeletonPoseBoneIndex TempIndex(i);
			if(RequiredBones.IsSkeletonPoseIndexValid(TempIndex))
			{
				Pending.Add(i);
			}			
		}
		
		for(auto It : Pending)
		{			
			int TrackIndex = -1;
			const int32 SourceSkeletonBoneIndex = It;
			const int32 TargetSkeletonBoneIndex = SkeletonRemapping.IsValid() ? SkeletonRemapping.GetTargetSkeletonBoneIndex(SourceSkeletonBoneIndex) : SourceSkeletonBoneIndex;
			const FCompactPoseBoneIndex BoneIndex = RequiredBones.GetCompactPoseIndexFromSkeletonIndex(TargetSkeletonBoneIndex);
						
			const int32 CompactPoseBoneIndex = BoneIndex.GetInt();
			if(CompactPoseBoneIndex == INDEX_NONE)
			{
				continue;
			}
			
			switch (TargetSkeleton->GetBoneTranslationRetargetingMode(TargetSkeletonBoneIndex, false))
			{
			case EBoneTranslationRetargetingMode::Animation:
				TranslationPairs.Add(BoneTrackPair(CompactPoseBoneIndex, TrackIndex));
				break;
			case EBoneTranslationRetargetingMode::AnimationScaled:
				TranslationPairs.Add(BoneTrackPair(CompactPoseBoneIndex, TrackIndex));
				AnimScaleRetargetingPairs.Add(BoneTrackPair(CompactPoseBoneIndex, SourceSkeletonBoneIndex));
				break;
			case EBoneTranslationRetargetingMode::AnimationRelative:
				TranslationPairs.Add(BoneTrackPair(CompactPoseBoneIndex, TrackIndex));

				// With baked additives, we can skip 'AnimationRelative' tracks, as the relative transform gets canceled out.
				// (A1 + Rel) - (A2 + Rel) = A1 - A2.
				// if (!DecompressionContext.IsAdditiveAnimation())
				{
				AnimRelativeRetargetingPairs.Add(BoneTrackPair(CompactPoseBoneIndex, SourceSkeletonBoneIndex));
				}
				break;
			case EBoneTranslationRetargetingMode::OrientAndScale:
				TranslationPairs.Add(BoneTrackPair(CompactPoseBoneIndex, TrackIndex));

				// Additives remain additives, they're not retargeted.
				// if (!DecompressionContext.IsAdditiveAnimation())
				{
				OrientAndScaleRetargetingPairs.Add(BoneTrackPair(CompactPoseBoneIndex, SourceSkeletonBoneIndex));
				}
				break;
			}				
		}
	}
	
	{		
		TSet<int> ValidBones;
		for (int32 TrackIndex = 0; TrackIndex < AnimationData.BoneTracks.Num(); TrackIndex++)
		{
			if (TrackIndex < BoneReferences.Num())
			{
				const FC7BoneAnimationTrack& Track = AnimationData.BoneTracks[TrackIndex];
				const FBoneReference& BoneRef = BoneReferences[TrackIndex];
				if (BoneRef.IsValidToEvaluate())
				{
					const FCompactPoseBoneIndex BoneIndex = BoneRef.CachedCompactPoseIndex;
					ValidBones.Add(BoneIndex.GetInt());
				}
			}
		}
		
		const int32 NumCompactBones = OutPose.GetNumBones();
		
		// Anim Scale Retargeting
		int32 const NumBonesToScaleRetarget = AnimScaleRetargetingPairs.Num();
		if (NumBonesToScaleRetarget > 0)
		{
			TArray<FTransform> const& AuthoredOnRefSkeleton = RetargetTransforms;

			for (const BoneTrackPair& BonePair : AnimScaleRetargetingPairs)
			{
				const FCompactPoseBoneIndex BoneIndex(BonePair.AtomIndex); //Nasty, we break our type safety, code in the lower levels should be adjusted for this
				const int32 SourceSkeletonBoneIndex = BonePair.TrackIndex;

				float const SourceTranslationLength = AuthoredOnRefSkeleton[SourceSkeletonBoneIndex].GetTranslation().Size();
				if (SourceTranslationLength > UE_KINDA_SMALL_NUMBER)
				{
					float const TargetTranslationLength = RequiredBones.GetRefPoseTransform(BoneIndex).GetTranslation().Size();
					CachedRetargetInfo.CachedScaleTranslationMap.Add(BoneIndex.GetInt(), TargetTranslationLength / SourceTranslationLength);
				}
			}
		}


		// Anim Relative Retargeting
		int32 const NumBonesToRelativeRetarget = AnimRelativeRetargetingPairs.Num();
		
		if (NumBonesToRelativeRetarget > 0 && GC7AnimLogicMapMethod == 1)
		{
			TArray<FTransform> const& AuthoredOnRefSkeleton = CachedRetargetInfo.GetRetargetTransformsOrigin();;
			TArray<FTransform> const& AuthoredOnRefSkeletonRetarget = RetargetTransforms;

			for (const BoneTrackPair& BonePair : AnimRelativeRetargetingPairs)
			{

				// todo..
				if (BonePair.AtomIndex == INDEX_NONE)
				{
					continue;
				}

				const FCompactPoseBoneIndex BoneIndex(BonePair.AtomIndex); //Nasty, we break our type safety, code in the lower levels should be adjusted for this
				const int32 SourceSkeletonBoneIndex = BonePair.TrackIndex;

				// 不是本地要计算的，忽略掉
				if(!ValidBones.Contains(BoneIndex.GetInt()))
				{
					continue;
				}
				
				// const FTransform& RefPoseTransform = RequiredBones.GetRefPoseTransform(BoneIndex);

				const FTransform& RefPoseTransform = AuthoredOnRefSkeletonRetarget[SourceSkeletonBoneIndex];
				// Remap the base pose onto the target skeleton so that we are working entirely in target space
				const FTransform& RefBaseTransform = AuthoredOnRefSkeleton[SourceSkeletonBoneIndex];
				const FTransform* BaseTransform = &RefBaseTransform;
				FTransform RetargetBaseTransform;
				if (SkeletonRemapping.RequiresReferencePoseRetarget())
				{
					const int32 TargetSkeletonBoneIndex = SkeletonRemapping.GetTargetSkeletonBoneIndex(SourceSkeletonBoneIndex);
					RetargetBaseTransform = SkeletonRemapping.RetargetBoneTransformToTargetSkeleton(TargetSkeletonBoneIndex, RefBaseTransform);
					BaseTransform = &RetargetBaseTransform;
				}

				FQuat RotDelta = BaseTransform->GetRotation().Inverse() * RefPoseTransform.GetRotation();
				FVector LocDelta = (RefPoseTransform.GetTranslation() - BaseTransform->GetTranslation());
				FVector ScaleDelta = (RefPoseTransform.GetScale3D() * BaseTransform->GetSafeScaleReciprocal(BaseTransform->GetScale3D()));
				CachedRetargetInfo.CachedRelativeTransformMap2.Add(BoneIndex.GetInt(), FTransform(RotDelta, LocDelta, ScaleDelta));
			}
		}
		else if (NumBonesToRelativeRetarget > 0 && GC7AnimLogicMapMethod == 2)
		{
			TArray<FTransform> const& AuthoredOnRefSkeleton = CachedRetargetInfo.GetRetargetTransformsOrigin();

			for (const BoneTrackPair& BonePair : AnimRelativeRetargetingPairs)
			{

				// todo..
				if (BonePair.AtomIndex == INDEX_NONE)
				{
					continue;
				}

				const FCompactPoseBoneIndex BoneIndex(BonePair.AtomIndex); //Nasty, we break our type safety, code in the lower levels should be adjusted for this
				const int32 SourceSkeletonBoneIndex = BonePair.TrackIndex;

				// 不是本地要计算的，忽略掉
				if(!ValidBones.Contains(BoneIndex.GetInt()))
				{
					continue;
				}
				
				const FTransform& RefPoseTransform = RequiredBones.GetRefPoseTransform(BoneIndex);

				// Remap the base pose onto the target skeleton so that we are working entirely in target space
				const FTransform& RefBaseTransform = AuthoredOnRefSkeleton[SourceSkeletonBoneIndex];
				const FTransform* BaseTransform = &RefBaseTransform;
				FTransform RetargetBaseTransform;
				if (SkeletonRemapping.RequiresReferencePoseRetarget())
				{
					const int32 TargetSkeletonBoneIndex = SkeletonRemapping.GetTargetSkeletonBoneIndex(SourceSkeletonBoneIndex);
					RetargetBaseTransform = SkeletonRemapping.RetargetBoneTransformToTargetSkeleton(TargetSkeletonBoneIndex, RefBaseTransform);
					BaseTransform = &RetargetBaseTransform;
				}

				FQuat RotDelta = BaseTransform->GetRotation().Inverse() * RefPoseTransform.GetRotation();
				FVector LocDelta = (RefPoseTransform.GetTranslation() - BaseTransform->GetTranslation());
				FVector ScaleDelta = (RefPoseTransform.GetScale3D() * BaseTransform->GetSafeScaleReciprocal(BaseTransform->GetScale3D()));
				CachedRetargetInfo.CachedRelativeTransformMap2.Add(BoneIndex.GetInt(), FTransform(RotDelta, LocDelta, ScaleDelta));
			}
		}
		else if (NumBonesToRelativeRetarget > 0 && GC7AnimLogicMapMethod == 3)
		{
			TArray<FTransform> const& AuthoredOnRefSkeleton = RetargetTransforms;

			for (const BoneTrackPair& BonePair : AnimRelativeRetargetingPairs)
			{

				// todo..
				if (BonePair.AtomIndex == INDEX_NONE)
				{
					continue;
				}

				const FCompactPoseBoneIndex BoneIndex(BonePair.AtomIndex); //Nasty, we break our type safety, code in the lower levels should be adjusted for this
				const int32 SourceSkeletonBoneIndex = BonePair.TrackIndex;

				// 不是本地要计算的，忽略掉
				if(!ValidBones.Contains(BoneIndex.GetInt()))
				{
					continue;
				}
				
				const FTransform& RefPoseTransform = RequiredBones.GetRefPoseTransform(BoneIndex);

				// Remap the base pose onto the target skeleton so that we are working entirely in target space
				const FTransform& RefBaseTransform = AuthoredOnRefSkeleton[SourceSkeletonBoneIndex];
				const FTransform* BaseTransform = &RefBaseTransform;
				FTransform RetargetBaseTransform;
				if (SkeletonRemapping.RequiresReferencePoseRetarget())
				{
					const int32 TargetSkeletonBoneIndex = SkeletonRemapping.GetTargetSkeletonBoneIndex(SourceSkeletonBoneIndex);
					RetargetBaseTransform = SkeletonRemapping.RetargetBoneTransformToTargetSkeleton(TargetSkeletonBoneIndex, RefBaseTransform);
					BaseTransform = &RetargetBaseTransform;
				}

				FQuat RotDelta = BaseTransform->GetRotation().Inverse() * RefPoseTransform.GetRotation();
				FVector LocDelta = (RefPoseTransform.GetTranslation() - BaseTransform->GetTranslation());
				FVector ScaleDelta = (RefPoseTransform.GetScale3D() * BaseTransform->GetSafeScaleReciprocal(BaseTransform->GetScale3D()));
				CachedRetargetInfo.CachedRelativeTransformMap2.Add(BoneIndex.GetInt(), FTransform(RotDelta, LocDelta, ScaleDelta));
			}
		}
		else if (NumBonesToRelativeRetarget > 0 && GC7AnimLogicMapMethod == 5)
		{
			// 只计算Scale
			TArray<FTransform> const& AuthoredOnRefSkeleton = RetargetTransforms;

			for (const BoneTrackPair& BonePair : AnimRelativeRetargetingPairs)
			{

				// todo..
				if (BonePair.AtomIndex == INDEX_NONE)
				{
					continue;
				}

				const FCompactPoseBoneIndex BoneIndex(BonePair.AtomIndex); //Nasty, we break our type safety, code in the lower levels should be adjusted for this
				const int32 SourceSkeletonBoneIndex = BonePair.TrackIndex;

				// 不是本地要计算的，忽略掉
				if(!ValidBones.Contains(BoneIndex.GetInt()))
				{
					continue;
				}
				
				const FTransform& RefPoseTransform = RequiredBones.GetRefPoseTransform(BoneIndex);

				// Remap the base pose onto the target skeleton so that we are working entirely in target space
				const FTransform& RefBaseTransform = AuthoredOnRefSkeleton[SourceSkeletonBoneIndex];
				const FTransform* BaseTransform = &RefBaseTransform;
				FTransform RetargetBaseTransform;
				if (SkeletonRemapping.RequiresReferencePoseRetarget())
				{
					const int32 TargetSkeletonBoneIndex = SkeletonRemapping.GetTargetSkeletonBoneIndex(SourceSkeletonBoneIndex);
					RetargetBaseTransform = SkeletonRemapping.RetargetBoneTransformToTargetSkeleton(TargetSkeletonBoneIndex, RefBaseTransform);
					BaseTransform = &RetargetBaseTransform;
				}

				FQuat RotDelta = FQuat::Identity;
				FVector LocDelta = FVector::Zero();
				FVector ScaleDelta = (RefPoseTransform.GetScale3D() * BaseTransform->GetSafeScaleReciprocal(BaseTransform->GetScale3D()));
				CachedRetargetInfo.CachedRelativeTransformMap2.Add(BoneIndex.GetInt(), FTransform(RotDelta, LocDelta, ScaleDelta));
			}
		}
		else if (NumBonesToRelativeRetarget > 0 && GC7AnimLogicMapMethod == 6)
		{
			// 只计算Scale
			TArray<FTransform> const& AuthoredOnRefSkeleton = CachedRetargetInfo.GetRetargetTransformsOrigin();

			for (const BoneTrackPair& BonePair : AnimRelativeRetargetingPairs)
			{

				// todo..
				if (BonePair.AtomIndex == INDEX_NONE)
				{
					continue;
				}

				const FCompactPoseBoneIndex BoneIndex(BonePair.AtomIndex); //Nasty, we break our type safety, code in the lower levels should be adjusted for this
				const int32 SourceSkeletonBoneIndex = BonePair.TrackIndex;

				// 不是本地要计算的，忽略掉
				if(!ValidBones.Contains(BoneIndex.GetInt()))
				{
					continue;
				}
				
				const FTransform& RefPoseTransform = RequiredBones.GetRefPoseTransform(BoneIndex);

				// Remap the base pose onto the target skeleton so that we are working entirely in target space
				const FTransform& RefBaseTransform = AuthoredOnRefSkeleton[SourceSkeletonBoneIndex];
				const FTransform* BaseTransform = &RefBaseTransform;
				FTransform RetargetBaseTransform;
				if (SkeletonRemapping.RequiresReferencePoseRetarget())
				{
					const int32 TargetSkeletonBoneIndex = SkeletonRemapping.GetTargetSkeletonBoneIndex(SourceSkeletonBoneIndex);
					RetargetBaseTransform = SkeletonRemapping.RetargetBoneTransformToTargetSkeleton(TargetSkeletonBoneIndex, RefBaseTransform);
					BaseTransform = &RetargetBaseTransform;
				}

				FQuat RotDelta = FQuat::Identity;
				FVector LocDelta = FVector::Zero();
				FVector ScaleDelta = (RefPoseTransform.GetScale3D() * BaseTransform->GetSafeScaleReciprocal(BaseTransform->GetScale3D()));
				CachedRetargetInfo.CachedRelativeTransformMap2.Add(BoneIndex.GetInt(), FTransform(RotDelta, LocDelta, ScaleDelta));
			}
		}
		
		if (NumBonesToRelativeRetarget > 0)
		{
			// todo..
			TArray<FTransform> AuthoredOnRefSkeleton = RetargetTransforms;
			if(GC7AnimLogicMapMethod == 4)
			{
				AuthoredOnRefSkeleton = CachedRetargetInfo.GetRetargetTransformsOrigin();
			}

			for (const BoneTrackPair& BonePair : AnimRelativeRetargetingPairs)
			{

				// todo..
				if (BonePair.AtomIndex == INDEX_NONE)
				{
					continue;
				}

				const FCompactPoseBoneIndex BoneIndex(BonePair.AtomIndex); //Nasty, we break our type safety, code in the lower levels should be adjusted for this
				const int32 SourceSkeletonBoneIndex = BonePair.TrackIndex;

				// 不是本地要计算的，忽略掉
				if(!ValidBones.Contains(BoneIndex.GetInt()))
				{
					continue;
				}
				
				const FTransform& RefPoseTransform = RequiredBones.GetRefPoseTransform(BoneIndex);

				// Remap the base pose onto the target skeleton so that we are working entirely in target space
				const FTransform& RefBaseTransform = AuthoredOnRefSkeleton[SourceSkeletonBoneIndex];
				const FTransform* BaseTransform = &RefBaseTransform;
				FTransform RetargetBaseTransform;
				if (SkeletonRemapping.RequiresReferencePoseRetarget())
				{
					const int32 TargetSkeletonBoneIndex = SkeletonRemapping.GetTargetSkeletonBoneIndex(SourceSkeletonBoneIndex);
					RetargetBaseTransform = SkeletonRemapping.RetargetBoneTransformToTargetSkeleton(TargetSkeletonBoneIndex, RefBaseTransform);
					BaseTransform = &RetargetBaseTransform;
				}

				FQuat RotDelta = BaseTransform->GetRotation().Inverse() * RefPoseTransform.GetRotation();
				FVector LocDelta = (RefPoseTransform.GetTranslation() - BaseTransform->GetTranslation());
				FVector ScaleDelta = (RefPoseTransform.GetScale3D() * BaseTransform->GetSafeScaleReciprocal(BaseTransform->GetScale3D()));
				CachedRetargetInfo.CachedRelativeTransformMap.Add(BoneIndex.GetInt(), FTransform(RotDelta, LocDelta, ScaleDelta));
			}
		}

		
		const int32 NumBonesToOrientAndScaleRetarget = CachedRetargetInfo.BoneInfo.OrientAndScaleRetargetingPairs.Num();
		if (NumBonesToOrientAndScaleRetarget > 0)
		{
			const FRetargetSourceCachedData& RetargetSourceCachedData = RequiredBones.GetRetargetSourceCachedData(CachedRetargetInfo.RetargetSource,
				SkeletonRemapping, RetargetTransforms);
			const TArray<FOrientAndScaleRetargetingCachedData>& OrientAndScaleDataArray = RetargetSourceCachedData.OrientAndScaleData;
			CachedRetargetInfo.CompactPoseIndexToOrientAndScaleIndex = RetargetSourceCachedData.CompactPoseIndexToOrientAndScaleIndex;
		}
		else
		{
			CachedRetargetInfo.CompactPoseIndexToOrientAndScaleIndex.Empty();
		}
	}
	CachedRetargetInfo.bDirty = false;
}

void FAnimNode_AIFacePlayer::Evaluate_AnyThread_LogicV2(FPoseContext& Output)
{	
	CachedRetargetInfo_AnyThread(Output);

	if(!CachedRetargetInfo.SourceSkeleton.IsValid()
		|| !CachedRetargetInfo.TargetSkeleton.IsValid())
	{
		return;
	}
	
	// 应用自定义动画
	FCompactPose& OutPose = Output.Pose;
	FCompactPose PendingOutPose = Output.Pose;

	for (int32 TrackIndex = 0; TrackIndex < AnimationData.BoneTracks.Num(); TrackIndex++)
	{
		if (TrackIndex < BoneReferences.Num())
		{
			const FC7BoneAnimationTrack& Track = AnimationData.BoneTracks[TrackIndex];
			const FBoneReference& BoneRef = BoneReferences[TrackIndex];
			if (BoneRef.IsValidToEvaluate())
			{
				const FCompactPoseBoneIndex BoneIndex = BoneRef.CachedCompactPoseIndex;
				if (OutPose.IsValidIndex(BoneIndex))
				{
					// liubo, GetBoneTransformAtTime效率不高，看看UE是怎么播放动画的。
					// 获取当前时间的骨骼变换
					FTransform CustomTransform = GetBoneTransformAtTime(Track, PlayTime);
					// liubo, 调试，只应用rotation
					//CustomTransform.SetLocation(OutPose[BoneIndex].GetLocation());
		
					PendingOutPose[BoneIndex] = CustomTransform;
				}
			}
		}
	}

	// retarget
	if (GC7AnimStopRun == 0)
	{
		TSet<int> ValidBones;
		for (int32 TrackIndex = 0; TrackIndex < AnimationData.BoneTracks.Num(); TrackIndex++)
		{
			if (TrackIndex < BoneReferences.Num())
			{
				const FC7BoneAnimationTrack& Track = AnimationData.BoneTracks[TrackIndex];
				const FBoneReference& BoneRef = BoneReferences[TrackIndex];
				if (BoneRef.IsValidToEvaluate())
				{
					const FCompactPoseBoneIndex BoneIndex = BoneRef.CachedCompactPoseIndex;
					ValidBones.Add(BoneIndex.GetInt());
				}
			}
		}
		
		const int32 NumCompactBones = OutPose.GetNumBones();
		
		// Anim Scale Retargeting
		int32 const NumBonesToScaleRetarget = CachedRetargetInfo.BoneInfo.AnimScaleRetargetingPairs.Num();
		if (NumBonesToScaleRetarget > 0)
		{
			for (const BoneTrackPair& BonePair : CachedRetargetInfo.BoneInfo.AnimScaleRetargetingPairs)
			{
				const FCompactPoseBoneIndex BoneIndex(BonePair.AtomIndex); //Nasty, we break our type safety, code in the lower levels should be adjusted for this
				const int32 SourceSkeletonBoneIndex = BonePair.TrackIndex;

				auto CachedPtr = CachedRetargetInfo.CachedScaleTranslationMap.Find(BoneIndex.GetInt());
				if (CachedPtr != nullptr)
				{
					PendingOutPose[BoneIndex].ScaleTranslation(*CachedPtr);
				}
			}
		}


		// Anim Relative Retargeting
		int32 const NumBonesToRelativeRetarget = CachedRetargetInfo.BoneInfo.AnimRelativeRetargetingPairs.Num();
		if (NumBonesToRelativeRetarget > 0)
		{
			for (const BoneTrackPair& BonePair : CachedRetargetInfo.BoneInfo.AnimRelativeRetargetingPairs)
			{
				// todo..
				if (BonePair.AtomIndex == INDEX_NONE)
				{
					continue;
				}

				const FCompactPoseBoneIndex BoneIndex(BonePair.AtomIndex); //Nasty, we break our type safety, code in the lower levels should be adjusted for this
				const int32 SourceSkeletonBoneIndex = BonePair.TrackIndex;

				// 不是本地要计算的，忽略掉
				if(!ValidBones.Contains(BoneIndex.GetInt()))
				{
					continue;
				}
				
				auto CachedPtr = CachedRetargetInfo.CachedRelativeTransformMap.Find(BoneIndex.GetInt());
				if(CachedPtr == nullptr)
				{
					continue;
				}

				FTransform PendingDelta = *CachedPtr;
				auto CachedPtr2 = CachedRetargetInfo.CachedRelativeTransformMap2.Find(BoneIndex.GetInt());
				if(CachedPtr2 != nullptr)
				{
					PendingDelta.SetRotation(PendingDelta.GetRotation() * CachedPtr2->GetRotation());
					PendingDelta.SetTranslation(PendingDelta.GetTranslation() + CachedPtr2->GetTranslation());
					PendingDelta.SetScale3D(PendingDelta.GetScale3D() * CachedPtr2->GetScale3D());
				}

				// Apply the retargeting as if it were an additive difference between the current skeleton and the retarget skeleton. 
				PendingOutPose[BoneIndex].SetRotation(PendingOutPose[BoneIndex].GetRotation() * PendingDelta.GetRotation());
				PendingOutPose[BoneIndex].SetTranslation(PendingOutPose[BoneIndex].GetTranslation() + (PendingDelta.GetLocation()));
				PendingOutPose[BoneIndex].SetScale3D(PendingOutPose[BoneIndex].GetScale3D() * (PendingDelta.GetScale3D()));
				PendingOutPose[BoneIndex].NormalizeRotation();

			}
		}
		
		// Translation 'Orient and Scale' Translation Retargeting
		const int32 NumBonesToOrientAndScaleRetarget = CachedRetargetInfo.BoneInfo.OrientAndScaleRetargetingPairs.Num();
		if (NumBonesToOrientAndScaleRetarget > 0)
		{
			const FBoneContainer& RequiredBones = OutPose.GetBoneContainer();
			const auto& RetargetTransforms = CachedRetargetInfo.GetRetargetTransforms();
			const FSkeletonRemapping& SkeletonRemapping = UE::Anim::FSkeletonRemappingRegistry::Get().GetRemapping(
				CachedRetargetInfo.SourceSkeleton.Get(),
				CachedRetargetInfo.TargetSkeleton.Get());
			const FRetargetSourceCachedData& RetargetSourceCachedData = RequiredBones.GetRetargetSourceCachedData(CachedRetargetInfo.RetargetSource,
				SkeletonRemapping, RetargetTransforms);
			const TArray<FOrientAndScaleRetargetingCachedData>& OrientAndScaleDataArray = RetargetSourceCachedData.OrientAndScaleData;
			const TArray<int32>& CompactPoseIndexToOrientAndScaleIndex = RetargetSourceCachedData.CompactPoseIndexToOrientAndScaleIndex;

			// If we have any cached retargeting data.
			if (OrientAndScaleDataArray.Num() > 0 && CompactPoseIndexToOrientAndScaleIndex.Num() == NumCompactBones)
			{
				for (int32 Index = 0; Index < NumBonesToOrientAndScaleRetarget; Index++)
				{
					const BoneTrackPair& BonePair = CachedRetargetInfo.BoneInfo.OrientAndScaleRetargetingPairs[Index];
					const FCompactPoseBoneIndex CompactPoseBoneIndex(BonePair.AtomIndex);
					const int32 OrientAndScaleIndex = CompactPoseIndexToOrientAndScaleIndex[CompactPoseBoneIndex.GetInt()];
					if (OrientAndScaleIndex != INDEX_NONE)
					{
						const FOrientAndScaleRetargetingCachedData& OrientAndScaleData = OrientAndScaleDataArray[OrientAndScaleIndex];
						FTransform& BoneTransform = PendingOutPose[CompactPoseBoneIndex];
						const FVector AnimatedTranslation = BoneTransform.GetTranslation();

						// If Translation is not animated, we can just copy the TargetTranslation. No retargeting needs to be done.
						const FVector NewTranslation = (AnimatedTranslation - OrientAndScaleData.SourceTranslation).IsNearlyZero(BONE_TRANS_RT_ORIENT_AND_SCALE_PRECISION) ?
							OrientAndScaleData.TargetTranslation :
							OrientAndScaleData.TranslationDeltaOrient.RotateVector(AnimatedTranslation) * OrientAndScaleData.TranslationScale;

						BoneTransform.SetTranslation(NewTranslation);
					}
				}
			}
		}

		for (int32 TrackIndex = 0; TrackIndex < AnimationData.BoneTracks.Num(); TrackIndex++)
		{
			if (TrackIndex < BoneReferences.Num())
			{
				const FC7BoneAnimationTrack& Track = AnimationData.BoneTracks[TrackIndex];
				const FBoneReference& BoneRef = BoneReferences[TrackIndex];
				if (BoneRef.IsValidToEvaluate())
				{
					const FCompactPoseBoneIndex BoneIndex = BoneRef.CachedCompactPoseIndex;
					if (OutPose.IsValidIndex(BoneIndex))
					{
						auto CustomTransform = PendingOutPose[BoneIndex];
						auto Old = OutPose[BoneIndex];
						auto DeltaLoc = (Old.GetLocation() - CustomTransform.GetLocation()).Size(); 
						bErrorPos = false;
						bErrorRot = false;
						bErrorScale = false;
						if (DeltaLoc > GC7AnimDeltaPos)
						{
							bErrorPos = true;
						}
						auto DeltaDegrees = FMath::RadiansToDegrees(Old.GetRotation().AngularDistance(CustomTransform.GetRotation()));
						if (DeltaDegrees > GC7AnimDeltaRot)
						{
							bErrorRot = true;
						}
						auto DeltaScale = (Old.GetScale3D() - CustomTransform.GetScale3D()).Size();
						if (DeltaScale > GC7AnimDeltaScale)
						{
							bErrorScale = true;
						}
						if (GC7AnimStopRun == 0)
						{
							if(GC7AnimLogicSkipErrScale == 1 && bErrorScale)
							{
								
							}
							else
							{
								OutPose[BoneIndex] = LerpTransform(PendingOutPose[BoneIndex], OutPose[BoneIndex], BlendToEndWeight);								
							}
						}
					}
				}
			}
		}
		
	}
	
	OutPose.NormalizeRotations();
}

const TArray<FTransform>& FC7RetargetInfo::GetRetargetTransforms()
{
	const USkeleton* MySkeleton = SourceSkeleton.Get();
	if (MySkeleton)
	{
		return MySkeleton->GetRefLocalPoses(RetargetSource);
	}
	else
	{
		static TArray<FTransform> EmptyTransformArray;
		return EmptyTransformArray;
	}
}

const TArray<FTransform>& FC7RetargetInfo::GetRetargetTransformsOrigin()
{
	const USkeleton* MySkeleton = SourceSkeleton.Get();
	if (MySkeleton)
	{
		return MySkeleton->GetRefLocalPoses();
	}
	else
	{
		static TArray<FTransform> EmptyTransformArray;
		return EmptyTransformArray;
	}
}

void FAnimNode_AIFacePlayer::Evaluate_AnyThread_LogicV3(FPoseContext& Output)
{
	UAnimInstance* AnimInstance = CastChecked<UAnimInstance>(Output.AnimInstanceProxy->GetAnimInstanceObject());
	if(!AnimInstance
		|| !AnimInstance->GetSkelMeshComponent()
		|| !AnimInstance->GetSkelMeshComponent()->GetSkeletalMeshAsset()
		|| !AnimInstance->GetSkelMeshComponent()->GetSkeletalMeshAsset()->Skeleton)
	{
		return;
	}
	
	const USkeleton* SourceSkeleton = AnimInstance ? AnimInstance->GetSkelMeshComponent()->GetSkeletalMeshAsset()->Skeleton : nullptr;
	auto MySkeleton = SourceSkeleton;
    const FReferenceSkeleton& RefSkeleton = SourceSkeleton->GetReferenceSkeleton();


	// 应用自定义动画
	FCompactPose& OutPose = Output.Pose;
	FCompactPose PendingOutPose = Output.Pose;
	const FBoneContainer& RequiredBones = OutPose.GetBoneContainer();
	auto TargetSkeleton = RequiredBones.GetSkeletonAsset();
	// auto PoseContainer = Output.Pose.GetBoneContainer();
	if(!TargetSkeleton)
	{
		return;
	}

	const FSkeletonRemapping& SkeletonRemapping = UE::Anim::FSkeletonRemappingRegistry::Get().GetRemapping(SourceSkeleton, TargetSkeleton);
	auto RetargetSource = RetargetSourceName;

	
	auto GetRetargetTransforms = [SourceSkeleton, RetargetSource]()
	{
		const USkeleton* MySkeleton = SourceSkeleton;
		if (MySkeleton)
		{
			return MySkeleton->GetRefLocalPoses(RetargetSource);
		}
		else
		{
			static TArray<FTransform> EmptyTransformArray;
			return EmptyTransformArray;
		}
	};
	
	const auto& RetargetTransforms = GetRetargetTransforms();

	// 准备数据
	FGetBonePoseScratchAreaC7 ScratchArea;
	BoneTrackArray& RotationScalePairs = ScratchArea.RotationScalePairs;
	BoneTrackArray& TranslationPairs = ScratchArea.TranslationPairs;
	BoneTrackArray& AnimScaleRetargetingPairs = ScratchArea.AnimScaleRetargetingPairs;
	BoneTrackArray& AnimRelativeRetargetingPairs = ScratchArea.AnimRelativeRetargetingPairs;
	BoneTrackArray& OrientAndScaleRetargetingPairs = ScratchArea.OrientAndScaleRetargetingPairs;
	{		
		TSet<int> Processed;
		
		for (int32 TrackIndex = 0; TrackIndex < AnimationData.BoneTracks.Num(); TrackIndex++)
		{
			if (BoneReferences.IsValidIndex(TrackIndex))
			{
				const FC7BoneAnimationTrack& Track = AnimationData.BoneTracks[TrackIndex];
				const FBoneReference& BoneRef = BoneReferences[TrackIndex];
				if (BoneRef.IsValidToEvaluate())
				{
					const FCompactPoseBoneIndex SrcBoneIndex = BoneRef.CachedCompactPoseIndex;
					// if (OutPose.IsValidIndex(SrcBoneIndex))
					if(SrcBoneIndex.GetInt() != INDEX_NONE)
					{						
						const int32 SourceSkeletonBoneIndex = SrcBoneIndex.GetInt();
						const int32 TargetSkeletonBoneIndex = SkeletonRemapping.IsValid() ? SkeletonRemapping.GetTargetSkeletonBoneIndex(SourceSkeletonBoneIndex) : SourceSkeletonBoneIndex;
						if(TargetSkeletonBoneIndex == INDEX_NONE)
						{
							continue;
						}
						
						const FCompactPoseBoneIndex BoneIndex = RequiredBones.GetCompactPoseIndexFromSkeletonIndex(TargetSkeletonBoneIndex);

						// 
						Processed.Add(TargetSkeletonBoneIndex);
						
						const int32 CompactPoseBoneIndex = BoneIndex.GetInt();
						switch (TargetSkeleton->GetBoneTranslationRetargetingMode(TargetSkeletonBoneIndex, false))
						{
						case EBoneTranslationRetargetingMode::Animation:
							TranslationPairs.Add(BoneTrackPair(CompactPoseBoneIndex, TrackIndex));
							break;
						case EBoneTranslationRetargetingMode::AnimationScaled:
							TranslationPairs.Add(BoneTrackPair(CompactPoseBoneIndex, TrackIndex));
							AnimScaleRetargetingPairs.Add(BoneTrackPair(CompactPoseBoneIndex, SourceSkeletonBoneIndex));
							break;
						case EBoneTranslationRetargetingMode::AnimationRelative:
							TranslationPairs.Add(BoneTrackPair(CompactPoseBoneIndex, TrackIndex));
							{
								AnimRelativeRetargetingPairs.Add(BoneTrackPair(CompactPoseBoneIndex, SourceSkeletonBoneIndex));
							}
							break;
						case EBoneTranslationRetargetingMode::OrientAndScale:
							TranslationPairs.Add(BoneTrackPair(CompactPoseBoneIndex, TrackIndex));
							{
								OrientAndScaleRetargetingPairs.Add(BoneTrackPair(CompactPoseBoneIndex, SourceSkeletonBoneIndex));
							}
							break;
						}
					}
				}
			}
		}

		// 补偿
		TArray<int> Pending;
		const int MaxBoneCont = RefSkeleton.GetNum();
		for(int i=0; i<MaxBoneCont; i++)
		{
			FSkeletonPoseBoneIndex TempIndex(i);
			if(RequiredBones.IsSkeletonPoseIndexValid(TempIndex)
				&& !Processed.Contains(i))
			{
				Pending.Add(i);
			}			
		}
		
		for(auto It : Pending)
		{			
			int TrackIndex = -1;
			const int32 SourceSkeletonBoneIndex = It;
			const int32 TargetSkeletonBoneIndex = SkeletonRemapping.IsValid() ? SkeletonRemapping.GetTargetSkeletonBoneIndex(SourceSkeletonBoneIndex) : SourceSkeletonBoneIndex;
			const FCompactPoseBoneIndex BoneIndex = RequiredBones.GetCompactPoseIndexFromSkeletonIndex(TargetSkeletonBoneIndex);

			Processed.Add(TargetSkeletonBoneIndex);
						
			const int32 CompactPoseBoneIndex = BoneIndex.GetInt();
			if(CompactPoseBoneIndex == INDEX_NONE)
			{
				continue;
			}
			
			switch (TargetSkeleton->GetBoneTranslationRetargetingMode(TargetSkeletonBoneIndex, false))
			{
			case EBoneTranslationRetargetingMode::Animation:
				TranslationPairs.Add(BoneTrackPair(CompactPoseBoneIndex, TrackIndex));
				break;
			case EBoneTranslationRetargetingMode::AnimationScaled:
				TranslationPairs.Add(BoneTrackPair(CompactPoseBoneIndex, TrackIndex));
				AnimScaleRetargetingPairs.Add(BoneTrackPair(CompactPoseBoneIndex, SourceSkeletonBoneIndex));
				break;
			case EBoneTranslationRetargetingMode::AnimationRelative:
				TranslationPairs.Add(BoneTrackPair(CompactPoseBoneIndex, TrackIndex));
				{
					AnimRelativeRetargetingPairs.Add(BoneTrackPair(CompactPoseBoneIndex, SourceSkeletonBoneIndex));
				}
				break;
			case EBoneTranslationRetargetingMode::OrientAndScale:
				TranslationPairs.Add(BoneTrackPair(CompactPoseBoneIndex, TrackIndex));
				{
					OrientAndScaleRetargetingPairs.Add(BoneTrackPair(CompactPoseBoneIndex, SourceSkeletonBoneIndex));
				}
				break;
			}				
		}
		
	}

	for (int32 TrackIndex = 0; TrackIndex < AnimationData.BoneTracks.Num(); TrackIndex++)
	{
		if (BoneReferences.IsValidIndex(TrackIndex))
		{
			const FC7BoneAnimationTrack& Track = AnimationData.BoneTracks[TrackIndex];
			const FBoneReference& BoneRef = BoneReferences[TrackIndex];
			if (BoneRef.IsValidToEvaluate())
			{
				const FCompactPoseBoneIndex BoneIndex = BoneRef.CachedCompactPoseIndex;
				if (OutPose.IsValidIndex(BoneIndex))
				{
					const FSkeletonPoseBoneIndex SkeletonBoneIndex = FSkeletonPoseBoneIndex(SkeletonRemapping.IsValid() ? SkeletonRemapping.GetTargetSkeletonBoneIndex(BoneIndex.GetInt()) : BoneIndex.GetInt());
					const FCompactPoseBoneIndex PoseBoneIndex = RequiredBones.GetCompactPoseIndexFromSkeletonPoseIndex(SkeletonBoneIndex);
			
					// todo, GetBoneTransformAtTime效率不高，暂时先粗暴点，后续再改进
					// 获取当前时间的骨骼变换
					FTransform CustomTransform = GetBoneTransformAtTime(Track, PlayTime);
					// liubo, 调试，只应用rotation
					//CustomTransform.SetLocation(OutPose[BoneIndex].GetLocation());
			
					PendingOutPose[BoneIndex] = CustomTransform;
				}
			}
		}
	}

	// retarget
	if (GC7AnimStopRun == 0)
	{
		TSet<int> ValidBones;
		for (int32 TrackIndex = 0; TrackIndex < AnimationData.BoneTracks.Num(); TrackIndex++)
		{
			if (TrackIndex < BoneReferences.Num())
			{
				const FC7BoneAnimationTrack& Track = AnimationData.BoneTracks[TrackIndex];
				const FBoneReference& BoneRef = BoneReferences[TrackIndex];
				if (BoneRef.IsValidToEvaluate())
				{
					const FCompactPoseBoneIndex BoneIndex = BoneRef.CachedCompactPoseIndex;
					ValidBones.Add(BoneIndex.GetInt());
				}
			}
		}
		
		const int32 NumCompactBones = OutPose.GetNumBones();
		
		int32 const NumBonesToScaleRetarget = AnimScaleRetargetingPairs.Num();
		if (NumBonesToScaleRetarget > 0)
		{
			TArray<FTransform> const& AuthoredOnRefSkeleton = RetargetTransforms;

			for (const BoneTrackPair& BonePair : AnimScaleRetargetingPairs)
			{
				const FCompactPoseBoneIndex BoneIndex(BonePair.AtomIndex);
				const int32 SourceSkeletonBoneIndex = BonePair.TrackIndex;

				float const SourceTranslationLength = AuthoredOnRefSkeleton[SourceSkeletonBoneIndex].GetTranslation().Size();
				if (SourceTranslationLength > UE_KINDA_SMALL_NUMBER)
				{
					float const TargetTranslationLength = RequiredBones.GetRefPoseTransform(BoneIndex).GetTranslation().Size();
					PendingOutPose[BoneIndex].ScaleTranslation(TargetTranslationLength / SourceTranslationLength);
				}
			}
		}

		int32 const NumBonesToRelativeRetarget = AnimRelativeRetargetingPairs.Num();
		if (NumBonesToRelativeRetarget > 0)
		{
			TArray<FTransform> const& AuthoredOnRefSkeleton = RetargetTransforms;

			for (const BoneTrackPair& BonePair : AnimRelativeRetargetingPairs)
			{
				if (BonePair.AtomIndex == INDEX_NONE)
				{
					continue;
				}

				const FCompactPoseBoneIndex BoneIndex(BonePair.AtomIndex);
				const int32 SourceSkeletonBoneIndex = BonePair.TrackIndex;

				// 不是本地要计算的，忽略掉
				if(!ValidBones.Contains(BoneIndex.GetInt()))
				{
					continue;
				}
				
				const FTransform& RefPoseTransform = RequiredBones.GetRefPoseTransform(BoneIndex);

				const FTransform& RefBaseTransform = AuthoredOnRefSkeleton[SourceSkeletonBoneIndex];
				const FTransform* BaseTransform = &RefBaseTransform;
				FTransform RetargetBaseTransform;
				if (SkeletonRemapping.RequiresReferencePoseRetarget())
				{
					const int32 TargetSkeletonBoneIndex = SkeletonRemapping.GetTargetSkeletonBoneIndex(SourceSkeletonBoneIndex);
					RetargetBaseTransform = SkeletonRemapping.RetargetBoneTransformToTargetSkeleton(TargetSkeletonBoneIndex, RefBaseTransform);
					BaseTransform = &RetargetBaseTransform;
				}
 
				PendingOutPose[BoneIndex].SetRotation(PendingOutPose[BoneIndex].GetRotation() * BaseTransform->GetRotation().Inverse() * RefPoseTransform.GetRotation());
				PendingOutPose[BoneIndex].SetTranslation(PendingOutPose[BoneIndex].GetTranslation() + (RefPoseTransform.GetTranslation() - BaseTransform->GetTranslation()));
				PendingOutPose[BoneIndex].SetScale3D(PendingOutPose[BoneIndex].GetScale3D() * (RefPoseTransform.GetScale3D() * BaseTransform->GetSafeScaleReciprocal(BaseTransform->GetScale3D())));
				PendingOutPose[BoneIndex].NormalizeRotation();

			}
		}


		
		const int32 NumBonesToOrientAndScaleRetarget = OrientAndScaleRetargetingPairs.Num();
		if (NumBonesToOrientAndScaleRetarget > 0)
		{
			const FRetargetSourceCachedData& RetargetSourceCachedData = RequiredBones.GetRetargetSourceCachedData("SK_Base_F", SkeletonRemapping, RetargetTransforms);
			const TArray<FOrientAndScaleRetargetingCachedData>& OrientAndScaleDataArray = RetargetSourceCachedData.OrientAndScaleData;
			const TArray<int32>& CompactPoseIndexToOrientAndScaleIndex = RetargetSourceCachedData.CompactPoseIndexToOrientAndScaleIndex;

			if (OrientAndScaleDataArray.Num() > 0 && CompactPoseIndexToOrientAndScaleIndex.Num() == NumCompactBones)
			{
				for (int32 Index = 0; Index < NumBonesToOrientAndScaleRetarget; Index++)
				{
					const BoneTrackPair& BonePair = OrientAndScaleRetargetingPairs[Index];
					const FCompactPoseBoneIndex CompactPoseBoneIndex(BonePair.AtomIndex);
					const int32 OrientAndScaleIndex = CompactPoseIndexToOrientAndScaleIndex[CompactPoseBoneIndex.GetInt()];
					if (OrientAndScaleIndex != INDEX_NONE)
					{
						const FOrientAndScaleRetargetingCachedData& OrientAndScaleData = OrientAndScaleDataArray[OrientAndScaleIndex];
						FTransform& BoneTransform = PendingOutPose[CompactPoseBoneIndex];
						const FVector AnimatedTranslation = BoneTransform.GetTranslation();

						const FVector NewTranslation = (AnimatedTranslation - OrientAndScaleData.SourceTranslation).IsNearlyZero(BONE_TRANS_RT_ORIENT_AND_SCALE_PRECISION) ?
							OrientAndScaleData.TargetTranslation :
							OrientAndScaleData.TranslationDeltaOrient.RotateVector(AnimatedTranslation) * OrientAndScaleData.TranslationScale;

						BoneTransform.SetTranslation(NewTranslation);
					}
				}
			}
		}

		for (int32 TrackIndex = 0; TrackIndex < AnimationData.BoneTracks.Num(); TrackIndex++)
		{
			if (TrackIndex < BoneReferences.Num())
			{
				const FC7BoneAnimationTrack& Track = AnimationData.BoneTracks[TrackIndex];
				const FBoneReference& BoneRef = BoneReferences[TrackIndex];
				if (BoneRef.IsValidToEvaluate())
				{
					const FCompactPoseBoneIndex BoneIndex = BoneRef.CachedCompactPoseIndex;
					if (OutPose.IsValidIndex(BoneIndex))
					{
						auto CustomTransform = PendingOutPose[BoneIndex];
						auto Old = OutPose[BoneIndex];
						auto DeltaLoc = (Old.GetLocation() - CustomTransform.GetLocation()).Size();
						bErrorPos = false;
						bErrorRot = false;
						bErrorScale = false;
						if (DeltaLoc > GC7AnimDeltaPos)
						{
							bErrorPos = true;
						}
						auto DeltaDegrees = FMath::RadiansToDegrees(Old.GetRotation().AngularDistance(CustomTransform.GetRotation()));
						if (DeltaDegrees > GC7AnimDeltaRot)
						{
							bErrorRot = true;
						}
						auto DeltaScale = (Old.GetScale3D() - CustomTransform.GetScale3D()).Size(); 
						if (DeltaScale > GC7AnimDeltaScale)
						{
							bErrorScale = true;
						}
						if (GC7AnimStopRun ==  0)
						{
							OutPose[BoneIndex] = LerpTransform(PendingOutPose[BoneIndex], OutPose[BoneIndex], BlendToEndWeight);
						}
					}
				}
			}
		}		
	}
	
	OutPose.NormalizeRotations();
}

void FAnimNode_AIFacePlayer::GatherDebugData(FNodeDebugData& DebugData)
{
	FString DebugLine = DebugData.GetNodeName(this);
	DebugLine += FString::Printf(TEXT("(Time: %.3f)"), PlayTime);
	DebugData.AddDebugItem(DebugLine);
	BasePose.GatherDebugData(DebugData);
}

FTransform FAnimNode_AIFacePlayer::GetBoneTransformAtTime(const FC7BoneAnimationTrack& Track, float Time) const
{
	if (Track.Keyframes.Num() == 0)
	{
		return FTransform::Identity;
	}

	if (Track.Keyframes.Num() == 1)
	{
		const FBoneKeyframe& Keyframe = Track.Keyframes[0];
		return FTransform(FQuat(Keyframe.Rotation), Keyframe.Location, Keyframe.Scale);
	}

	// 找到时间范围内的关键帧
	int32 KeyIndex1 = 0;
	int32 KeyIndex2 = 0;

	for (int32 i = 0; i < Track.Keyframes.Num() - 1; i++)
	{
		if (Track.Keyframes[i].Time > Time)
		{
			KeyIndex2 = i;
			KeyIndex1 = FMath::Max(0, i - 1);
			break;
		}
		KeyIndex1 = i;
		KeyIndex2 = FMath::Min(i + 1, Track.Keyframes.Num() - 1);
	}

	const FBoneKeyframe& Key1 = Track.Keyframes[KeyIndex1];
	const FBoneKeyframe& Key2 = Track.Keyframes[KeyIndex2];

	if (KeyIndex1 == KeyIndex2)
	{
		return FTransform(FQuat(Key1.Rotation), Key1.Location, Key1.Scale);
	}

	if (GC7AnimLerp == 1)
	{
		return FTransform(FQuat(Key2.Rotation), Key2.Location, Key2.Scale);
	}
	else if (GC7AnimLerp == 2)
	{
		return FTransform(FQuat(Key1.Rotation), Key1.Location, Key1.Scale);
	}
	else if (GC7AnimLerp == 3)
	{
		auto Idx = KeyIndex2 - 1;
		if (!Track.Keyframes.IsValidIndex(Idx))
		{
			Idx = KeyIndex2;
		}
		const FBoneKeyframe& Key3 = Track.Keyframes[Idx];
		return FTransform(FQuat(Key3.Rotation), Key3.Location, Key3.Scale);
	}

	// 计算插值系数
	float TimeDelta = Key2.Time - Key1.Time;
	float alpha = (TimeDelta > 0.0f) ? (Time - Key1.Time) / TimeDelta : 0.0f;
	alpha = FMath::Clamp(alpha, 0.0f, 1.0f);

	// 插值计算 (UE5使用四元数插值)
	FVector Location;
	const FVector* FoundLocation = BoneLocationData.Find(Track.BoneName);
	if (Track.BoneName != TEXT("root") && FoundLocation != nullptr)
	{
		// 如果BoneLocationData里面有数据，就用BoneLocationData的数据
		Location = *FoundLocation;
	}
	else
	{
		// 否则使用插值计算
		Location = InterpolateVector(Key1.Location, Key2.Location, alpha);
	}

	FQuat Rotation = InterpolateRotation(FQuat(Key1.Rotation), FQuat(Key2.Rotation), alpha);
	FVector Scale = InterpolateVector(Key1.Scale, Key2.Scale, alpha);

	return FTransform(Rotation, Location, Scale);

}

FVector FAnimNode_AIFacePlayer::InterpolateVector(const FVector& A, const FVector& B, float alpha) const
{
	return FMath::Lerp(A, B, alpha);
}

FQuat FAnimNode_AIFacePlayer::InterpolateRotation(const FQuat& A, const FQuat& B, float alpha) const
{
	return FQuat::Slerp(A, B, alpha);
}

FTransform FAnimNode_AIFacePlayer::LerpTransform(const FTransform& Src, const FTransform& Dst, float Weight)
{
	if(Weight >= 1)
	{
		return Src;
	}
	else if(Weight <= 0)
	{
		return Dst;
	}
	const float T = 1 - Weight;
	FTransform Result = FTransform::Identity;
	Result.SetLocation(FMath::Lerp<FVector>(Src.GetLocation(), Dst.GetLocation(), T));
	Result.SetRotation(FQuat::Slerp(Src.GetRotation(), Dst.GetRotation(), T));
	Result.SetScale3D(FMath::Lerp<FVector>(Src.GetScale3D(), Dst.GetScale3D(), T));
	return Result;
}

void FAnimNode_AIFacePlayer::SetData()
{
	CachedRetargetInfo.bDirty = true;	
}

#undef LOCTEXT_NAMESPACE