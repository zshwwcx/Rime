#include "3C/Animation/AnimationGraphNode/AnimNode_WebSequencePlayer.h"
#include "Animation/AnimInstanceProxy.h"
#include "AnimEncoding.h"
#include "Animation/AnimBlueprintGeneratedClass.h"
#include "Animation/AnimTrace.h"
#include "Animation/AnimMontage.h"
#include "AnimationRuntime.h" // 添加AnimationRuntime头文件
#include "Misc/FileHelper.h" // 用于文件读取
#include "Serialization/JsonReader.h" // JSON读取
#include "Serialization/JsonSerializer.h"
#include "Misc/Base64.h" // Base64解码
#include "Dom/JsonObject.h"
#include "3C/Animation/BaseAnimInstance.h"
#include "Managers/KGWebAnimationManager.h"

#define LOCTEXT_NAMESPACE "AnimNode_WebSequencePlayer"


FAnimNode_WebSequencePlayer::FAnimNode_WebSequencePlayer()
{
	PlayTime = 0.0f;
	IsPlaying = false;
	IsPaused = false;
	PlaybackSpeed = 1.0f;
	BlendAlpha = 1.0f; // 默认完全使用Web动画
}

void FAnimNode_WebSequencePlayer::Initialize_AnyThread(const FAnimationInitializeContext& Context)
{
	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(Initialize_AnyThread)
	FAnimNode_Base::Initialize_AnyThread(Context);
	BasePose.Initialize(Context);
	PlayTime = 0.0f;
}

void FAnimNode_WebSequencePlayer::CacheBones_AnyThread(const FAnimationCacheBonesContext& Context)
{
	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(CacheBones_AnyThread)
	FAnimNode_Base::CacheBones_AnyThread(Context);
	BasePose.CacheBones(Context);

	// 缓存骨骼引用 (UE5版本)
	BoneReferences.Empty();
	const FBoneContainer& BoneContainer = Context.AnimInstanceProxy->GetRequiredBones();
	for (const FC7BoneAnimationTrack& Track : AnimationData.BoneTracks)
	{
		FBoneReference BoneRef;
		BoneRef.BoneName = FName(*Track.BoneName);
		BoneRef.Initialize(BoneContainer);
		BoneReferences.Add(BoneRef);
	}
}

void FAnimNode_WebSequencePlayer::Update_AnyThread(const FAnimationUpdateContext& Context)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_WebSequencePlayer::Update_AnyThread");
	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(Update_AnyThread)
	GetEvaluateGraphExposedInputs().Execute(Context);
	
	FAnimNode_Base::Update_AnyThread(Context);
	BasePose.Update(Context);

	if (!IsPlaying)
	{
		// 停止播放时清空骨骼引用
		if (!BoneReferences.IsEmpty())
		{
			BoneReferences.Empty();
		}
		return;
	}

	// 暂停时保持当前帧，不更新时间
	if (IsPaused)
	{
		return;
	}
	
	if (BoneReferences.Num() != AnimationData.BoneTracks.Num())
	{
		UE_LOG(LogTemp, Log, TEXT("WebSequencePlayer Update_AnyThread: Rebuild BoneReferences"));
		const FBoneContainer& BoneContainer = Context.AnimInstanceProxy->GetRequiredBones();
		for (const FC7BoneAnimationTrack& Track : AnimationData.BoneTracks)
		{
			FBoneReference BoneRef;
			BoneRef.BoneName = FName(*Track.BoneName);
			BoneRef.Initialize(BoneContainer);
			BoneReferences.Add(BoneRef);
		}
	}

	// 添加动画追踪 (UE5特性)
	TRACE_ANIM_NODE_VALUE(Context, TEXT("PlayTime"), PlayTime);
	TRACE_ANIM_NODE_VALUE(Context, TEXT("IsPlaying"), IsPlaying);
	TRACE_ANIM_NODE_VALUE(Context, TEXT("IsPaused"), IsPaused);
	TRACE_ANIM_NODE_VALUE(Context, TEXT("PlaybackSpeed"), PlaybackSpeed);
	if (AnimationData.Duration > 0.0f)
	{
		// 更新内部时间，应用倍速
		float ClampedSpeed = FMath::Clamp(PlaybackSpeed, 0.0f, 10.0f);
		PlayTime += Context.GetDeltaTime() * ClampedSpeed;

		if (Loop)
		{
			// 循环播放模式
			PlayTime = FMath::Fmod(PlayTime, AnimationData.Duration);
		}
		else
		{
			// 非循环播放模式
			if (PlayTime >= AnimationData.Duration)
			{
				// 播放结束，停止播放
				PlayTime = AnimationData.Duration;
				IsPlaying = false;
			}
		}
	}
}

void FAnimNode_WebSequencePlayer::Evaluate_AnyThread(FPoseContext& Output)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_WebSequencePlayer::Evaluate_AnyThread");

	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(Evaluate_AnyThread)

	BasePose.Evaluate(Output);
	if (!IsPlaying)
		return;

	// 如果BlendAlpha接近0，完全使用BasePose，无需计算Web动画
	if (BlendAlpha <= KINDA_SMALL_NUMBER)
	{
		return;
	}

	// 应用自定义动画
	FCompactPose& OutPose = Output.Pose;

	// 根据BlendArray动态调整BlendAlpha
	float EffectiveBlendAlpha = BlendAlpha;
	if (BlendArray.Num() > 0 && AnimationData.Duration > 0.0f && SampleRate > 0.0f)
	{
		// 计算当前帧索引
		int32 CurrentFrame = FMath::FloorToInt(PlayTime * SampleRate);
		int32 TotalFrames = FMath::FloorToInt(AnimationData.Duration * SampleRate);
		CurrentFrame = FMath::Clamp(CurrentFrame, 0, TotalFrames - 1);

		// BlendArray数据格式: [frame] 范围[0.0, 1.0]
		// 直接获取当前帧的融合权重
		if (CurrentFrame < BlendArray.Num())
		{
			float FrameBlendWeight = BlendArray[CurrentFrame];
			// 将BlendArray的权重与外部BlendAlpha相乘
			EffectiveBlendAlpha = BlendAlpha * FrameBlendWeight;
		}
	}

	// Clamp EffectiveBlendAlpha to [0, 1]
	float ClampedAlpha = FMath::Clamp(EffectiveBlendAlpha, 0.0f, 1.0f);

	// 如果EffectiveBlendAlpha接近0，完全使用BasePose，无需计算Web动画
	if (ClampedAlpha <= KINDA_SMALL_NUMBER)
		return;

	for (int32 TrackIndex = 0; TrackIndex < AnimationData.BoneTracks.Num(); TrackIndex++)
	{
		if (TrackIndex < BoneReferences.Num())
		{
			const FC7BoneAnimationTrack& Track = AnimationData.BoneTracks[TrackIndex];
			const FBoneReference& BoneRef = BoneReferences[TrackIndex];
			if (BoneRef.IsValidToEvaluate())
			{
				const FCompactPoseBoneIndex BoneIndex = BoneRef.CachedCompactPoseIndex;
				if (OutPose.IsValidIndex(BoneIndex))
				{
					// 获取当前时间的骨骼变换（Web动画）
					FTransform WebTransform = GetBoneTransformAtTime(Track, PlayTime);

					// 如果BlendAlpha接近1，完全使用Web动画
					if (ClampedAlpha >= 1.0f - KINDA_SMALL_NUMBER)
					{
						OutPose[BoneIndex] = WebTransform;
					}
					else
					{
						// 混合BasePose和Web动画
						FTransform BasePoseTransform = OutPose[BoneIndex];
						FTransform BlendedTransform;
						BlendedTransform.Blend(BasePoseTransform, WebTransform, ClampedAlpha);
						OutPose[BoneIndex] = BlendedTransform;
					}
				}
			}
		}
	}
}


void FAnimNode_WebSequencePlayer::GatherDebugData(FNodeDebugData& DebugData)
{
	FString DebugLine = DebugData.GetNodeName(this);
	DebugLine += FString::Printf(TEXT("(Time: %.3f)"), PlayTime);
	DebugData.AddDebugItem(DebugLine);
	BasePose.GatherDebugData(DebugData);
}

FTransform FAnimNode_WebSequencePlayer::GetBoneTransformAtTime(const FC7BoneAnimationTrack& Track, float Time) const
{
	if (Track.Keyframes.Num() == 0)
	{
		return FTransform::Identity;
	}

	if (Track.Keyframes.Num() == 1)
	{
		const FBoneKeyframe& Keyframe = Track.Keyframes[0];
		return FTransform(FQuat(Keyframe.Rotation), Keyframe.Location, Keyframe.Scale);
	}

	// 找到时间范围内的关键帧
	int32 KeyIndex1 = 0;
	int32 KeyIndex2 = 0;

	for (int32 i = 0; i < Track.Keyframes.Num() - 1; i++)
	{
		if (Track.Keyframes[i].Time > Time)
		{
			KeyIndex2 = i;
			KeyIndex1 = FMath::Max(0, i - 1);
			break;
		}
		KeyIndex1 = i;
		KeyIndex2 = FMath::Min(i + 1, Track.Keyframes.Num() - 1);
	}

	const FBoneKeyframe& Key1 = Track.Keyframes[KeyIndex1];
	const FBoneKeyframe& Key2 = Track.Keyframes[KeyIndex2];

	if (KeyIndex1 == KeyIndex2)
	{
		return FTransform(FQuat(Key1.Rotation), Key1.Location, Key1.Scale);
	}

	// 计算插值系数
	float TimeDelta = Key2.Time - Key1.Time;
	float alpha = (TimeDelta > 0.0f) ? (Time - Key1.Time) / TimeDelta : 0.0f;
	alpha = FMath::Clamp(alpha, 0.0f, 1.0f);

	// 插值计算 (UE5使用四元数插值)
	FVector Location;
	const FVector* FoundLocation = BoneLocationData.Find(Track.BoneName);
	if (Track.BoneName != TEXT("root") && FoundLocation != nullptr)
	{
		// 如果BoneLocationData里面有数据，就用BoneLocationData的数据
		Location = *FoundLocation;
	}
	else
	{
		// 否则使用插值计算
		Location = InterpolateVector(Key1.Location, Key2.Location, alpha);
	}

	FQuat Rotation = InterpolateRotation(FQuat(Key1.Rotation), FQuat(Key2.Rotation), alpha);
	FVector Scale = InterpolateVector(Key1.Scale, Key2.Scale, alpha);

	return FTransform(Rotation, Location, Scale);
}

FVector FAnimNode_WebSequencePlayer::InterpolateVector(const FVector& A, const FVector& B, float alpha) const
{
	return FMath::Lerp(A, B, alpha);
}

FQuat FAnimNode_WebSequencePlayer::InterpolateRotation(const FQuat& A, const FQuat& B, float alpha) const
{
	return FQuat::Slerp(A, B, alpha);
}

#undef LOCTEXT_NAMESPACE