#include "3C/Animation/LookAt/CutSceneAnimInstance.h"

UCutSceneAnimInstance::UCutSceneAnimInstance(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	/*LookAtLocation.Z = 180.f;
	LookAtLocation.Y = 50.f;*/
}