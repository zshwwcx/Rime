// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Animation/AnimNotify/AnimNotifyState_C7WaterWind.h"

#include "3C/Character/BaseCharacter.h"
#include "Manager/KGPlatformScalabilitySettings.h"
#include "Misc/KGPlatformUtils.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "3C/Animation/AnimNotify/AnimNotify_C7WaterWind.h"
#include "3C/Interactor/WorldManager.h"

void UAnimNotifyState_C7WaterWind::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7WaterWind::NotifyBegin");
	
	Super::NotifyBegin(MeshComp, Animation, TotalDuration, EventReference);
	
	UWorld* World = MeshComp ? MeshComp->GetWorld() : nullptr;
	if (!World)
	{
		return;
	}

	AActor* OwnerActor = MeshComp->GetOwner();
	if (!OwnerActor)
	{
		return;
	}

	ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(OwnerActor);
	if (!BaseCharacter)
	{
		return;
	}

	if (BaseCharacter->IsCrowdNpc())
	{
		return;
	}

	double CurrentTime = World->GetTimeSeconds();
	LastWaterTickTime = CurrentTime;
	LastWindTickTime = CurrentTime;

	AddWaterMotor(MeshComp, CurrentTime);
	AddWindMotor(MeshComp, CurrentTime);
}

void UAnimNotifyState_C7WaterWind::NotifyTick(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float FrameDeltaTime, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7WaterWind::NotifyTick");
	
	Super::NotifyTick(MeshComp, Animation, FrameDeltaTime, EventReference);

	AActor* OwnerActor = MeshComp->GetOwner();
	if (!OwnerActor)
	{
		return;
	}

	ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(OwnerActor);
	if (!BaseCharacter)
	{
		return;
	}

	if (BaseCharacter->IsCrowdNpc())
	{
		return;
	}

	UWorld* World = MeshComp ? MeshComp->GetWorld() : nullptr;
	if (!World)
	{
		return;
	}

	double CurrentTime = World->GetTimeSeconds();

	AddWaterMotor(MeshComp, CurrentTime);
	AddWindMotor(MeshComp, CurrentTime);
}

void UAnimNotifyState_C7WaterWind::AddWaterMotor(USkeletalMeshComponent* MeshComp, double CurrentTime)
{
	if (CurrentTime - LastWaterTickTime < WaterTimeGap)
	{
		return;
	}

	LastWaterTickTime = CurrentTime;
	
	if (!MeshComp)
	{
		return;
	}

	if (KGPlatformUtils::IsInLevelPreviewWorld(MeshComp))
	{
		return;
	}

	UWorldManager* WorldManager = UWorldManager::GetInstance(MeshComp);
	if (!WorldManager || !WorldManager->IsEnabledDynamicWaterWave())
	{
		return;
	}

	AActor* OwnerActor = MeshComp->GetOwner();
	if (!OwnerActor)
	{
		return;
	}

	ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(OwnerActor);
	if (!BaseCharacter)
	{
		return;	
	}

	UKGPlatformScalabilitySettings* PlatformScalabilitySettings = UKGPlatformScalabilitySettings::GetInstance(BaseCharacter);
	if (!PlatformScalabilitySettings)
	{
		return;
	}

	if (!PlatformScalabilitySettings->GetScalabilityLodValue<bool>(BaseCharacter->GetActorLOD(), "WaterWindMotor", "WaterWindLODControl"))
	{
		return;
	}

	URoleMovementComponent* RoleMovementComponent = OwnerActor->GetComponentByClass<URoleMovementComponent>();
	if (!RoleMovementComponent)
	{
		return;
	}

	if (RoleMovementComponent->GetIsInWater() || RoleMovementComponent->GetIsInWaterWalk())
	{
		int32 RequestID = WorldManager->GetGlobalWaterWaveRequestId();
		float OutPosX, OutPosY, OutYaw, OutDirX, OutDirY;
		UAnimNotify_C7WaterWind::CalcTransform(OwnerActor, MeshComp, WaterBaseSocket, WaterOffsetX, WaterOffsetY, WaterDirAngle, OutPosX, OutPosY, OutYaw, OutDirX, OutDirY);
		float WaveHeight = UAnimNotify_C7WaterWind::CalcWaveHeightByWaterDepth(RoleMovementComponent, WaveMaxHeight, MinWaveScalar);
		WorldManager->AddMotorForDynamicWaterWave(RequestID, MotorTextureID, OutPosX, OutPosY, OutYaw, WaterScaleX, WaterScaleY, WaveHeight, FoamScale, -1, OutDirX, OutDirY, 0);
	}
}

void UAnimNotifyState_C7WaterWind::AddWindMotor(USkeletalMeshComponent* MeshComp, double CurrentTime)
{
	if (CurrentTime - LastWindTickTime < WindTimeGap)
	{
		return;
	}

	LastWindTickTime = CurrentTime;
	
	if (!MeshComp)
	{
		return;
	}

	if (KGPlatformUtils::IsInLevelPreviewWorld(MeshComp))
	{
		return;
	}

	UWorldManager* WorldManager = UWorldManager::GetInstance(MeshComp);
	if (!WorldManager || !WorldManager->IsEnableLocalWindField())
	{
		return;
	}

	AActor* OwnerActor = MeshComp->GetOwner();
	if (!OwnerActor)
	{
		return;
	}

	ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(OwnerActor);
	if (!BaseCharacter)
	{
		return;	
	}

	UKGPlatformScalabilitySettings* PlatformScalabilitySettings = UKGPlatformScalabilitySettings::GetInstance(BaseCharacter);
	if (!PlatformScalabilitySettings)
	{
		return;
	}

	if (!PlatformScalabilitySettings->GetScalabilityLodValue<bool>(BaseCharacter->GetActorLOD(), "WaterWindMotor", "WaterWindLODControl"))
	{
		return;
	}

	URoleMovementComponent* RoleMovementComponent = OwnerActor->GetComponentByClass<URoleMovementComponent>();
	if (!RoleMovementComponent)
	{
		return;
	}

	// todo@shijingzhe: 风场应该改成检测到对应地形才触发
	if (!RoleMovementComponent->GetIsInWater() && !RoleMovementComponent->GetIsInWaterWalk())
	{
		float OutPosX, OutPosY, OutYaw, OutDirX, OutDirY;
		UAnimNotify_C7WaterWind::CalcTransform(OwnerActor, MeshComp, WindBaseSocket, WindOffsetX, WindOffsetY, WindDirAngle, OutPosX, OutPosY, OutYaw, OutDirX, OutDirY);
		WorldManager->AddMotorForLocalWindField(WindType, OutPosX, OutPosY, OutYaw, WindScaleX, WindScaleY, WindStrength, FanCenterAngle, WindBlendTime, WindBlendFreq);
		LastWindTickTime = CurrentTime;
	}
}
