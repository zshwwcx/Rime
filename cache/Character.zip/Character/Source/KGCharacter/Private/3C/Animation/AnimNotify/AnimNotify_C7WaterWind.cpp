// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Animation/AnimNotify/AnimNotify_C7WaterWind.h"

#include "3C/Character/BaseCharacter.h"
#include "Manager/KGPlatformScalabilitySettings.h"
#include "Misc/KGPlatformUtils.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "3C/Interactor/WorldManager.h"

void UAnimNotify_C7WaterWind::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotify_C7WaterWind::Notify");
	
	Super::Notify(MeshComp, Animation, EventReference);
	if (!MeshComp)
	{
		return;
	}

	if (KGPlatformUtils::IsInLevelPreviewWorld(MeshComp))
	{
		return;
	}
	
	UWorldManager* WorldManager = UWorldManager::GetInstance(MeshComp);
	if (!WorldManager || (!WorldManager->IsEnabledDynamicWaterWave() && !WorldManager->IsEnableLocalWindField()))
	{
		return;
	}

	AActor* OwnerActor = MeshComp->GetOwner();
	if (!OwnerActor)
	{
		return;
	}

	ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(OwnerActor);
	if (!BaseCharacter)
	{
		return;	
	}

	if (BaseCharacter->IsCrowdNpc())
	{
		return;
	}

	UKGPlatformScalabilitySettings* PlatformScalabilitySettings = UKGPlatformScalabilitySettings::GetInstance(BaseCharacter);
	if (!PlatformScalabilitySettings)
	{
		return;
	}

	if (!PlatformScalabilitySettings->GetScalabilityLodValue<bool>(BaseCharacter->GetActorLOD(), "WaterWindMotor", "WaterWindLODControl"))
	{
		return;
	}
	
	URoleMovementComponent* RoleMovementComponent = OwnerActor->GetComponentByClass<URoleMovementComponent>();
	if (!RoleMovementComponent)
	{
		return;
	}
	
	if (WorldManager->IsEnabledDynamicWaterWave() && (RoleMovementComponent->GetIsInWater() || RoleMovementComponent->GetIsInWaterWalk()))
	{
		// 水里只播水
		int32 RequestID = WorldManager->GetGlobalWaterWaveRequestId();
		float OutPosX, OutPosY, OutYaw, OutDirX, OutDirY;
		CalcTransform(OwnerActor, MeshComp, WaterBaseSocket, WaterOffsetX, WaterOffsetY, WaterDirAngle, OutPosX, OutPosY, OutYaw, OutDirX, OutDirY);
		float WaveHeight = CalcWaveHeightByWaterDepth(RoleMovementComponent, WaveMaxHeight, MinWaveScalar);
		WorldManager->AddMotorForDynamicWaterWave(RequestID, MotorTextureID, OutPosX, OutPosY, OutYaw, WaterScaleX, WaterScaleY, WaveHeight, FoamScale, TimeGap, OutDirX, OutDirY, MoveSpeed, WaveTimes - 1);
	}
	else if (WorldManager->IsEnableLocalWindField())
	{
		// todo@shijingzhe: 风场应该改成检测到对应地形才触发
		float OutPosX, OutPosY, OutYaw, OutDirX, OutDirY;
		CalcTransform(OwnerActor, MeshComp, WindBaseSocket, WindOffsetX, WindOffsetY, WindDirAngle, OutPosX, OutPosY, OutYaw, OutDirX, OutDirY);
		WorldManager->AddMotorForLocalWindField(WindType, OutPosX, OutPosY, OutYaw, WindScaleX, WindScaleY, WindStrength, FanCenterAngle, WindBlendTime, WindBlendFreq);
	}
}

void UAnimNotify_C7WaterWind::CalcTransform(const AActor* Actor, const USkeletalMeshComponent* MeshComp, const FName& BassSocket, const float OffsetX, const float OffsetY, const float OffsetAngle, float& OutX, float& OutY, float& OutYaw, float& OutDirX, float& OutDirY)
{
	if (!Actor || !MeshComp)
	{
		return;
	}

	// 基准位置&朝向
	const int32 BoneIndex = MeshComp->GetBoneIndex(BassSocket);
	FVector BaseLoc = BoneIndex == INDEX_NONE ? Actor->GetActorLocation() : MeshComp->GetBoneLocation(BassSocket);
	const FRotator BaseRot(0, Actor->GetActorRotation().Yaw, 0);

	// 叠加后位置
	const FVector Offset(OffsetX, OffsetY, 0);
	BaseLoc += BaseRot.RotateVector(Offset);

	// 叠加后朝向
	const float AngleRad = FMath::DegreesToRadians(OffsetAngle);
	const float MoveDirX = FMath::Cos(AngleRad);
    const float MoveDirY = FMath::Sin(AngleRad);
    const FVector MoveDir(MoveDirX, MoveDirY, 0);
	const FVector RotatedMoveDir = BaseRot.RotateVector(MoveDir);

	OutX = BaseLoc.X;
	OutY = BaseLoc.Y;
	OutYaw = FMath::Atan2(-RotatedMoveDir.Y, RotatedMoveDir.X);
	OutDirX = RotatedMoveDir.X;
	OutDirY = RotatedMoveDir.Y;
}

float UAnimNotify_C7WaterWind::CalcWaveHeightByWaterDepth(URoleMovementComponent* RoleMovementComp, float MaxWaveHeight, float MinWaveScalar)
{
	if (!RoleMovementComp || !RoleMovementComp->GetIsDetectWater())
	{
		return MaxWaveHeight;
	}

	float CurWaterDepth = RoleMovementComp->GetCurWaterDepth();
	float MaxWaterDepth = RoleMovementComp->GetInSwimDepthThreshold() * 0.7; // 先写死
	if (CurWaterDepth > MaxWaterDepth)
	{
		return MaxWaveHeight;
	}
	
	float RemappedScalar = MinWaveScalar + (CurWaterDepth / MaxWaterDepth) * (1 - MinWaveScalar);
	return FMath::Min(RemappedScalar * MaxWaveHeight, MaxWaveHeight);
}
