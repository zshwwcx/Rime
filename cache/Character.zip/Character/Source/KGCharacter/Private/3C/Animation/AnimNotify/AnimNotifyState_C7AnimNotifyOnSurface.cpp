// Copyright Epic Games, Inc. All Rights Reserved.

#include "3C/Animation/AnimNotify/AnimNotifyState_C7AnimNotifyOnSurface.h"

#include "Misc/KGPlatformUtils.h"
#include "3C/Movement/RoleMovementComponent.h"

UAnimNotifyState_C7AnimNotifyOnSurface::UAnimNotifyState_C7AnimNotifyOnSurface(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UAnimNotifyState_C7AnimNotifyOnSurface::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation,
	float TotalDuration)
{
	if (!ValidateParameters(MeshComp)) return;

	UWorld* World = GEngine->GetWorldFromContextObject(MeshComp, EGetWorldErrorMode::LogAndReturnNull);
	if (!World)
	{
		return;
	}
	
	if (KGPlatformUtils::IsInLevelPreviewWorld(World))
	{
		return;
	}
	
	UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(World);
	if (!EffectManager)
	{
		// in editor
#if WITH_EDITORONLY_DATA
		SpawnEffect(MeshComp, Animation);
#endif
		return;
	}

	AActor* Owner = MeshComp->GetOwner();
	if (!Owner)
	{
		return;
	}
	
	ABaseCharacter* TargetCharacter = Cast<ABaseCharacter>(Owner);
	if (TargetCharacter == nullptr)
	{
		return;
	}
	
	for (auto& Package : NiagaraSystemList)
	{
		// UE_CLOG(Package.Value.bNeedAttach && Package.Value.bNeedCheckGround,
		// 	LogTemp, Error, TEXT("UAnimNotifyState_C7AnimNotifyOnSurface::NotifyBegin, cannot check ground on attached niagara, %s, %s"),
		// 	*GetPathNameSafe(Animation), *Package.Value.TemplatePath.ToString());
		
		int32 EffectId = TargetCharacter->SpawnSurfaceEffect(Package, MeshComp);
		if (EffectId != 0)
		{
			auto& EffectIds = Mapping.FindOrAdd(TWeakObjectPtr<USkeletalMeshComponent>(MeshComp));
			if (Package.Value.TotalLifeSeconds <= 0)
			{
				EffectIds.Add(EffectId);
			}
		}
	}
}

void UAnimNotifyState_C7AnimNotifyOnSurface::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	if (!IsValid(MeshComp))
	{
		UE_LOG(LogEM, Error, TEXT("UAnimNotifyState_C7AnimNotifyOnSurface::NotifyEnd: MeshComp is invalid, %s"),
			IsValid(Animation) ? *Animation->GetPathName() : TEXT("null"));
		return;
	}
	
	if (const TArray<int32>* EffectIdsPtr = Mapping.Find(TWeakObjectPtr<USkeletalMeshComponent>(MeshComp)))
	{
		if (KGPlatformUtils::IsInLevelPreviewWorld(MeshComp))
		{
			return;
		}
		
		if (UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(MeshComp))
		{
			for (const auto EffectId : *EffectIdsPtr)
			{
				EffectManager->DestroyNiagaraSystem(EffectId);
			}
		}
		else
		{
			UE_LOG(LogTemp, Error, TEXT("UAnimNotifyState_C7TimedNiagaraEffect::NotifyEnd, cannot find effect manager"));	
		}
	}
	else
	{
#if WITH_EDITORONLY_DATA
		auto Array = MappingEditor.Find(MeshComp);
		if (Array) {
			for (const auto& Component : *Array) {
				if (Component.IsValid()) {
					Component->DestroyComponent();
				}
			}
			Array->Empty();
			MappingEditor.Remove(MeshComp);
		}
#endif
	}
}

bool UAnimNotifyState_C7AnimNotifyOnSurface::ValidateParameters(USkeletalMeshComponent* MeshComp) const
{
	if (NiagaraSystemList.IsEmpty())
	{
		return false;
	}
	
	auto TempSet = TSet<EAnimState>();
	for (auto& Package : NiagaraSystemList) 
	{
		if (Package.Value.TemplatePath.IsNull())
		{
			return false;
		}
		
		if (!MeshComp->DoesSocketExist(Package.Value.SocketName) && MeshComp->GetBoneIndex(Package.Value.SocketName) == INDEX_NONE)
		{
			return false;
		}
		
		if (TempSet.Contains(Package.Key))
		{
			return false;
		}
		
		TempSet.Add(Package.Key);
	}
	return true;
}

FString UAnimNotifyState_C7AnimNotifyOnSurface::GetNotifyName_Implementation() const
{
	for (auto& Package : NiagaraSystemList) {
		return Package.Value.TemplatePath.GetAssetName();
	}
	return FString("C7AnimNotifyOnSurface");
}


void UAnimNotifyState_C7AnimNotifyOnSurface::AddToMappingEditor(USkeletalMeshComponent* MeshComp, UNiagaraComponent* FXComponent)
{
#if WITH_EDITORONLY_DATA
	if (!MappingEditor.Find(MeshComp)) {
		MappingEditor.Add(MeshComp, {});
	}
	MappingEditor[MeshComp].Add(TWeakObjectPtr<UNiagaraComponent>(FXComponent));
#endif
}

void UAnimNotifyState_C7AnimNotifyOnSurface::SpawnEffect(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
#if WITH_EDITORONLY_DATA
	// Only spawn if we've got valid params
	if (NiagaraSystemList.IsEmpty()) return;
	for (auto& Package : NiagaraSystemList) {
		const auto& NiagaraConfig = Package.Value;
		auto TemplatePath = NiagaraConfig.TemplatePath;
		TemplatePath.LoadSynchronous();
		UNiagaraComponent* FXComponent = nullptr;
		if (NiagaraConfig.bNeedAttach) {
			FXComponent = UNiagaraFunctionLibrary::SpawnSystemAttached(
				TemplatePath.Get(),
				MeshComp,
				NiagaraConfig.SocketName,
				NiagaraConfig.Transform.GetLocation(),
				NiagaraConfig.Transform.Rotator(),
				NiagaraConfig.Transform.GetScale3D(),
				EAttachLocation::KeepRelativeOffset,
				true,
				ENCPoolMethod::None
			);
		}
		else
		{
			const auto& WorldTransform = NiagaraConfig.Transform * MeshComp->GetSocketTransform(NiagaraConfig.SocketName, RTS_World);
			FXComponent = UNiagaraFunctionLibrary::SpawnSystemAtLocation(
				MeshComp->GetWorld(),
				TemplatePath.Get(),
				WorldTransform.GetLocation(),
				WorldTransform.Rotator(),
				WorldTransform.GetScale3D(),
				true,
				true
			);
		}
		if (FXComponent)
		{
			FXComponent->SetAbsolute(false, NiagaraConfig.bAbsoluteRotation, NiagaraConfig.bAbsoluteScale);
			AddToMappingEditor(MeshComp, FXComponent);
		}
		
	}
#endif
}