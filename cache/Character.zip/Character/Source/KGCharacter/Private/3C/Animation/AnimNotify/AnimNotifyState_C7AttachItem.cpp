// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Animation/AnimNotify/AnimNotifyState_C7AttachItem.h"

#include "3C/RoleComposite/RoleCompositeManager.h"
#include "Components/SkeletalMeshComponent.h"

void UAnimNotifyState_C7AttachItem::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
}

void UAnimNotifyState_C7AttachItem::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
}
