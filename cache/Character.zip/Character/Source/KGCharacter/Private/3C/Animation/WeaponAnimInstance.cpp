// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Animation/WeaponAnimInstance.h"

#if WITH_EDITOR
void UWeaponAnimInstance::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	if (WeaponSkeleton && PropertyChangedEvent.Property && PropertyChangedEvent.Property->GetFName() == GET_MEMBER_NAME_CHECKED(UWeaponAnimInstance, WeaponMontageMap))
	{
		USkeleton* TargetSkeleton = WeaponSkeleton;// 获取目标骨架;
        
		for (auto& Pair : WeaponMontageMap)
		{
			if (Pair.Value.IsPending())
			{
				Pair.Value.LoadSynchronous();
			}
            
			UAnimationAsset* AnimAsset = Pair.Value.Get();
			if (AnimAsset && AnimAsset->GetSkeleton() != TargetSkeleton)
			{
				UE_LOG(LogTemp, Warning, TEXT("Animation asset %s does not match target skeleton!"), *AnimAsset->GetName());
				// 可以选择清除不匹配的条目
				WeaponMontageMap.Remove(Pair.Key);
				break; // 移除后需要退出循环，因为迭代器失效
			}
		}
	}
}
#endif

FString UWeaponAnimInstance::GetWeaponAnimPathByID(const FString& AnimID)
{
	if (TSoftObjectPtr<UAnimMontage>* ptr = WeaponMontageMap.Find(AnimID))
	{
		return ptr->ToSoftObjectPath().ToString();
	}
	else
	{
		return "";
	}
}
