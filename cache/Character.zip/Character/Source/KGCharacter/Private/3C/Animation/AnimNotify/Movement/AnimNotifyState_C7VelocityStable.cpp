// Copyright Epic Games, Inc. All Rights Reserved.

// #pragma once

#include "3C/Animation/AnimNotify/Movement/AnimNotifyState_C7VelocityStable.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Movement/RoleMovementComponent.h"



void UAnimNotifyState_C7VelocityStable::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference) 
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7VelocityStable::NotifyBegin");
	
	if (ABaseCharacter* Character = Cast<ABaseCharacter>(MeshComp->GetOwner()))
	{
		if (URoleMovementComponent* RoleMoveComp = Cast<URoleMovementComponent>(Character->GetMovementComponent()))
		{
			RoleMoveComp = GetMovementAuthorityControlRMC(RoleMoveComp);
			if (!Character->SaveC7VelocityStableRMCForAnimNotify(GetUniqueID(), RoleMoveComp))
			{
				UE_LOG(LogTemp, Warning, TEXT("[UAnimNotifyState_C7VelocityStable] Replicated NotifyBegin! %s, %s"), *MeshComp->GetName(), *Animation->GetName());
			}

			if (VelocityStableMode == EVelocityStableMode::ThrusterBlendInMode)
			{
				RoleMoveComp->GetRoleMP().LocoInputThrusterMC.StartVelocityBlendIn(TotalDuration, RoleMoveComp->GetMovementVelocity());
			}
			else
			{
				RoleMoveComp->GetRoleMP().GetMovementContext().StartMovementVelocityStable(VelocityDiffRatioTolerateRate, UseVelHistoryAvg);
			}
		}
	}
}

void UAnimNotifyState_C7VelocityStable::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) 
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7VelocityStable::NotifyEnd");
	
	if (ABaseCharacter* Character = Cast<ABaseCharacter>(MeshComp->GetOwner()))
	{
		URoleMovementComponent* RoleMoveComp = Character->GetAndClearC7VelocityStableRMCForAnimNotify(GetUniqueID());
		if (IsValid(RoleMoveComp))
		{
			if (VelocityStableMode == EVelocityStableMode::ThrusterBlendInMode)
			{
				RoleMoveComp->GetRoleMP().LocoInputThrusterMC.StartVelocityBlendIn(0, FVector::Zero());
			}
			else
			{
				RoleMoveComp->GetRoleMP().GetMovementContext().EndMovementVelocityStable(DelayEffectTime);
			}
		}
	}
}



