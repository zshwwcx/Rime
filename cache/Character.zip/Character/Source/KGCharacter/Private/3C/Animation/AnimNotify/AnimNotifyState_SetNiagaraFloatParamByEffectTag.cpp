#include "3C/Animation/AnimNotify/AnimNotifyState_SetNiagaraFloatParamByEffectTag.h"

#include "Misc/KGPlatformUtils.h"
#include "Animation/AnimSequenceBase.h"
#include "Components/SkeletalMeshComponent.h"
#include "3C/Effect/KGEffectManager.h"

void UAnimNotifyState_SetNiagaraFloatParamByEffectTag::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_SetNiagaraFloatParamByEffectTag::NotifyBegin");
	
	Super::NotifyBegin(MeshComp, Animation, TotalDuration, EventReference);
	
	if (!IsValid(MeshComp))
	{
		UE_LOG(LogTemp, Error, TEXT("UAnimNotifyState_SetNiagaraFloatParamByEffectTag::NotifyBegin, MeshComp is invalid, %s"),
			Animation ? *Animation->GetPathName() : TEXT("null"));
		return;
	}
	
	if (KGPlatformUtils::IsInLevelPreviewWorld(MeshComp))
	{
		return;
	}
	
	if (UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(MeshComp))
	{
		EffectManager->AddOrUpdateLinearSampleParamTargetValueByEffectTag(
			static_cast<EKGNiagaraEffectTag>(EffectTag), NiagaraParamName, LeaveTargetVal, EnterTargetVal, false, Duration);
	}
}

void UAnimNotifyState_SetNiagaraFloatParamByEffectTag::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_SetNiagaraFloatParamByEffectTag::NotifyEnd");
	
	if (IsValid(MeshComp))
	{
		if (!KGPlatformUtils::IsInLevelPreviewWorld(MeshComp))
		{
			if (UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(MeshComp))
			{
				EffectManager->AddOrUpdateLinearSampleParamTargetValueByEffectTag(
					static_cast<EKGNiagaraEffectTag>(EffectTag), NiagaraParamName, EnterTargetVal, LeaveTargetVal, false, Duration);
			}
		}
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("UAnimNotifyState_SetNiagaraFloatParamByEffectTag::NotifyEnd, MeshComp is invalid, %s"),
			Animation ? *Animation->GetPathName() : TEXT("null"));	
	}
	
	Super::NotifyEnd(MeshComp, Animation, EventReference);
}
