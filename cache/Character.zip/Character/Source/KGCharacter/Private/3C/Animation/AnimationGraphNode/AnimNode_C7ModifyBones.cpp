// Copyright Epic Games, Inc. All Rights Reserved.

#include "3C/Animation/AnimationGraphNode/AnimNode_C7ModifyBones.h"
#include "AnimationRuntime.h"
#include "Animation/AnimInstanceProxy.h"
#include "Animation/AnimStats.h"
#include "Animation/AnimTrace.h"
#include "AnimationCoreLibrary.h"
#include "TwoBoneIK.h"
#include "CommonAnimTypes.h"

DECLARE_CYCLE_STAT(TEXT("FAnimNode_C7ModifyBones Eval"), STAT_ModifyBones_Eval, STATGROUP_Anim);

/////////////////////////////////////////////////////
// FAnimNode_C7ModifyBones

FAnimNode_C7ModifyBones::FAnimNode_C7ModifyBones()
{
}

void FAnimNode_C7ModifyBones::GatherDebugData(FNodeDebugData& DebugData)
{
	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(GatherDebugData)
	FString DebugLine = DebugData.GetNodeName(this);

	DebugLine += "(";
	for (auto Param : BonesParam)
	{
		DebugLine += FString::Printf(TEXT(" Target: %s)"), *Param.Value.BoneToModify.ToString());	
	}
	DebugLine += FString::Printf(TEXT(" ArmAdditiveAlpha: %.2f)"), ArmAdditiveAlpha);
	DebugData.AddDebugItem(DebugLine);

	ComponentPose.GatherDebugData(DebugData);
}

void FAnimNode_C7ModifyBones::Initialize_AnyThread(const FAnimationInitializeContext& Context)
{
	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(Initialize_AnyThread)
	FAnimNode_Base::Initialize_AnyThread(Context);
	ComponentPose.Initialize(Context);
	ArmAdditive.Initialize(Context);
}

void FAnimNode_C7ModifyBones::CacheBones_AnyThread(const FAnimationCacheBonesContext& Context)
{
	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(CacheBones_AnyThread)
	FAnimNode_Base::CacheBones_AnyThread(Context);
	ComponentPose.CacheBones(Context);
	ArmAdditive.CacheBones(Context);
}


void FAnimNode_C7ModifyBones::Update_AnyThread(const FAnimationUpdateContext& Context)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_C7ModifyBones::Update_AnyThread");
	GetEvaluateGraphExposedInputs().Execute(Context);
	
	ComponentPose.Update(Context);
	if (!IsLODEnabled(Context.AnimInstanceProxy) || Alpha <= 0.001f)
	{
		return;
	}
	
}

void FAnimNode_C7ModifyBones::Evaluate_AnyThread(FPoseContext& Output)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_C7ModifyBones::Evaluate_AnyThread");

	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(FAnimNode_C7ModifyBones_Evaluate_AnyThread)
	SCOPE_CYCLE_COUNTER(STAT_ModifyBones_Eval);

	if (!IsLODEnabled(Output.AnimInstanceProxy) || Alpha <= 0.001f)
	{
		// todo 瞬切严重的话, 这里可能要做alpha的处理
		ComponentPose.Evaluate(Output);;
		return ;
	}

	// Evaluate the child and convert
	FPoseContext InputPose(Output.AnimInstanceProxy);

	// We need to preserve the node ID chain as we use the proxy-based constructor above
	InputPose.SetNodeIds(Output);

	ComponentPose.Evaluate(InputPose);;
	
	// 叠加需要在IK之前做
	if(FAnimWeight::IsRelevant(ArmAdditiveAlpha))
	{
		const bool bExpectsAdditivePose = true;
		FPoseContext AdditiveEvalContext(Output, bExpectsAdditivePose);
		ArmAdditive.Evaluate(AdditiveEvalContext);

		FAnimationPoseData OutAnimationPoseData(InputPose);
		const FAnimationPoseData AdditiveAnimationPoseData(AdditiveEvalContext);

		FAnimationRuntime::AccumulateAdditivePose(OutAnimationPoseData, AdditiveAnimationPoseData, ArmAdditiveAlpha, AAT_LocalSpaceBase);
		InputPose.Pose.NormalizeRotations();
	}
	

	// Evaluate the child and convert
	FComponentSpacePoseContext InputCSPose(Output.AnimInstanceProxy);
	// We need to preserve the node ID chain as we use the proxy-based constructor above
	InputCSPose.SetNodeIds(InputPose);

	InputCSPose.Pose.InitPose(MoveTemp(InputPose.Pose));
	InputCSPose.Curve = MoveTemp(InputPose.Curve);
	InputCSPose.CustomAttributes = MoveTemp(InputPose.CustomAttributes);

	// 进行批量modify bone的处理
	AlphaCurveValues.Reset();
	if(BonesParam.Num() > 0)
	{
		EvaluateBatchModifyBoneIK_AnyThread(InputCSPose, AlphaCurveValues);
	}


	if(BatchTwoBoneIKParams.Num() > 0)
	{
		EvaluateBatchTwoBoneIK_AnyThread(InputCSPose, AlphaCurveValues);
	}


	FCSPose<FCompactPose>::ConvertComponentPosesToLocalPoses(MoveTemp(InputCSPose.Pose), Output.Pose);
	Output.Curve = MoveTemp(InputCSPose.Curve);
	Output.CustomAttributes = MoveTemp(InputCSPose.CustomAttributes);
	
}
bool FAnimNode_C7ModifyBones::EvaluateBatchModifyBoneIK_AnyThread(FComponentSpacePoseContext& Output, TMap<FName, float>& CurveValueMap)
{

	TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_C7ModifyBones::EvaluateBatchModifyBoneIK_AnyThread");

	// the way we apply transform is same as FMatrix or FTransform
	// we apply scale first, and rotation, and translation
	// if you'd like to translate first, you'll need two nodes that first node does translate and second nodes to rotate.

	UAnimInstance* AnimInstance = Cast<UAnimInstance>(Output.AnimInstanceProxy->GetAnimInstanceObject());
	if (!AnimInstance)
	{
		return false;
	}
	
	const FBoneContainer& BoneContainer = Output.Pose.GetPose().GetBoneContainer();

	FTransform ComponentTransform = Output.AnimInstanceProxy->GetComponentTransform();
	for (auto const & Param : BonesParam)
	{
		FBoneReference MyBoneReference;
		MyBoneReference.BoneName = Param.Value.BoneToModify;
		// todo 这里要看一下, 是不是有明显性能问题,  有问题就要做cache, 并且使用的时候要判定valid
		if(!MyBoneReference.Initialize(BoneContainer))
		{
			continue;
		}
		
		FCompactPoseBoneIndex CompactPoseBoneToModify = MyBoneReference.GetCompactPoseIndex(BoneContainer);
		if (CompactPoseBoneToModify == INDEX_NONE)
		{
			// 存在Lod变更时动态修改了骨骼缓存拿不到正确的骨骼数据,后续逻辑不再做了 
			continue;
		}
		
		FTransform NewBoneTM = Output.Pose.GetComponentSpaceTransform(CompactPoseBoneToModify);
		
		if (Param.Value.ScaleMode != EC7BoneModificationMode::BMM_Ignore)
		{
			// Convert to Bone Space.
			FAnimationRuntime::ConvertCSTransformToBoneSpace(ComponentTransform, Output.Pose, NewBoneTM, CompactPoseBoneToModify, Param.Value.BoneControlSpace);

			if (Param.Value.ScaleMode == EC7BoneModificationMode::BMM_Additive)
			{
				NewBoneTM.SetScale3D(NewBoneTM.GetScale3D() * Param.Value.Transform.GetScale3D());
			}
			else
			{
				NewBoneTM.SetScale3D(Param.Value.Transform.GetScale3D());
			}

			// Convert back to Component Space.
			FAnimationRuntime::ConvertBoneSpaceTransformToCS(ComponentTransform, Output.Pose, NewBoneTM, CompactPoseBoneToModify, Param.Value.BoneControlSpace);
		}

		if (Param.Value.RotationMode != EC7BoneModificationMode::BMM_Ignore)
		{
			// Convert to Bone Space.
			FAnimationRuntime::ConvertCSTransformToBoneSpace(ComponentTransform, Output.Pose, NewBoneTM, CompactPoseBoneToModify, Param.Value.BoneControlSpace);

			const FQuat BoneQuat(Param.Value.Transform.GetRotation());
			if (Param.Value.RotationMode == EC7BoneModificationMode::BMM_Additive)
			{
				NewBoneTM.SetRotation(BoneQuat * NewBoneTM.GetRotation());
			}
			else
			{
				NewBoneTM.SetRotation(BoneQuat);
			}

			// Convert back to Component Space.
			FAnimationRuntime::ConvertBoneSpaceTransformToCS(ComponentTransform, Output.Pose, NewBoneTM, CompactPoseBoneToModify, Param.Value.BoneControlSpace);
		}
	
		if (Param.Value.TranslationMode != EC7BoneModificationMode::BMM_Ignore)
		{
			// Convert to Bone Space.
			FAnimationRuntime::ConvertCSTransformToBoneSpace(ComponentTransform, Output.Pose, NewBoneTM, CompactPoseBoneToModify, Param.Value.BoneControlSpace);

			if (Param.Value.TranslationMode == EC7BoneModificationMode::BMM_Additive)
			{
				NewBoneTM.AddToTranslation(Param.Value.Transform.GetTranslation());
			}
			else
			{
				NewBoneTM.SetTranslation(Param.Value.Transform.GetTranslation());
			}

			// Convert back to Component Space.
			FAnimationRuntime::ConvertBoneSpaceTransformToCS(ComponentTransform, Output.Pose, NewBoneTM, CompactPoseBoneToModify, Param.Value.BoneControlSpace);
		}

		FCompactPoseBoneIndex Index = MyBoneReference.GetCompactPoseIndex(BoneContainer);
		
		float BlendAlpha = Param.Value.BlendAlpha;
		FName AlphaCurveName = Param.Value.AlphaCurveName;
		if (AlphaCurveName != NAME_None)
		{
			if (CurveValueMap.Contains(AlphaCurveName))
			{
				BlendAlpha = CurveValueMap[AlphaCurveName];
			}
			else
			{
				AnimInstance->GetCurveValueWithDefault(AlphaCurveName, Param.Value.AlphaDefaultValue, BlendAlpha);
				CurveValueMap.Add(AlphaCurveName, BlendAlpha);
			}
		}
		
		// todo 需要还原回 极限值1 @sunya
		// const float BlendWeight = FMath::Clamp<float>(Alpha, 0.f, 1.f);
		const float BlendWeight = FMath::Clamp<float>(Alpha, 0.f, 0.999);

		BoneTransforms.Reset();
		BoneAlphas.Reset();
		
		BoneTransforms.Add( FBoneTransform(Index, NewBoneTM));
		BoneAlphas.Emplace(Index.GetInt(), BlendAlpha);
		// 备注: 这里每次骨骼更新都需要调用,因为存在骨骼空间位置依赖
		Output.Pose.LocalBlendCSBoneTransforms(BoneTransforms, BlendWeight, &BoneAlphas);
		
		TRACE_ANIM_NODE_VALUE(Output, TEXT("Target"), Param.Value.BoneToModify);
	}

	return true;
}


bool FAnimNode_C7ModifyBones::EvaluateBatchTwoBoneIK_AnyThread(FComponentSpacePoseContext& Output, TMap<FName, float>& CurveValueMap)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_C7ModifyBones::EvaluateBatchTwoBoneIK_AnyThread");

	UAnimInstance* AnimInstance = Cast<UAnimInstance>(Output.AnimInstanceProxy->GetAnimInstanceObject());
	if (!AnimInstance)
	{
		return false;
	}
	
	const FBoneContainer& BoneContainer = Output.Pose.GetPose().GetBoneContainer();
	FTransform ComponentTransform = Output.AnimInstanceProxy->GetComponentTransform();
	
	// 完全copy two bone IK 代码, 改成批量处理形式
	for (auto  & TwoBoneIKParamPair : BatchTwoBoneIKParams)
	{
		// 这里是需要每帧 Initialize的, 因为requires bone是可能变化的
		auto & OneTwoBoneIKParamValue = TwoBoneIKParamPair.Value;
		if(!OneTwoBoneIKParamValue.IKBone.Initialize(BoneContainer))
		{
			continue;
		}

		OneTwoBoneIKParamValue.EffectorTarget.Initialize(Output.AnimInstanceProxy);
		OneTwoBoneIKParamValue.EffectorTarget.InitializeBoneReferences(BoneContainer);
		OneTwoBoneIKParamValue.JointTarget.Initialize(Output.AnimInstanceProxy);
		OneTwoBoneIKParamValue.JointTarget.InitializeBoneReferences(BoneContainer);

		FCompactPoseBoneIndex IKBoneCompactPoseIndex = OneTwoBoneIKParamValue.IKBone.GetCompactPoseIndex(BoneContainer);
		FCompactPoseBoneIndex CachedLowerLimbIndex = FCompactPoseBoneIndex(INDEX_NONE);
		FCompactPoseBoneIndex CachedUpperLimbIndex = FCompactPoseBoneIndex(INDEX_NONE);
		if (IKBoneCompactPoseIndex != INDEX_NONE)
		{
			CachedLowerLimbIndex = BoneContainer.GetParentBoneIndex(IKBoneCompactPoseIndex);
			if (CachedLowerLimbIndex != INDEX_NONE)
			{
				CachedUpperLimbIndex = BoneContainer.GetParentBoneIndex(CachedLowerLimbIndex);
			}
		}
		if (IKBoneCompactPoseIndex == INDEX_NONE || CachedLowerLimbIndex == INDEX_NONE || CachedUpperLimbIndex == INDEX_NONE)
		{
			// 存在Lod变更时动态修改了骨骼缓存拿不到正确的骨骼数据,后续逻辑不再做了
			continue;
		}
		
		const bool bInBoneSpace = (OneTwoBoneIKParamValue.EffectorLocationSpace == BCS_ParentBoneSpace) || (OneTwoBoneIKParamValue.EffectorLocationSpace == BCS_BoneSpace);

		const FTransform EndBoneLocalTransform = Output.Pose.GetLocalSpaceTransform(IKBoneCompactPoseIndex);
		const FTransform LowerLimbLocalTransform = Output.Pose.GetLocalSpaceTransform(CachedLowerLimbIndex);
		const FTransform UpperLimbLocalTransform = Output.Pose.GetLocalSpaceTransform(CachedUpperLimbIndex);
		
		FTransform LowerLimbCSTransform = Output.Pose.GetComponentSpaceTransform(CachedLowerLimbIndex);
		FTransform UpperLimbCSTransform = Output.Pose.GetComponentSpaceTransform(CachedUpperLimbIndex);
		FTransform EndBoneCSTransform = Output.Pose.GetComponentSpaceTransform(IKBoneCompactPoseIndex);

		const FVector RootPos = UpperLimbCSTransform.GetTranslation();
		const FVector InitialJointPos = LowerLimbCSTransform.GetTranslation();
		const FVector InitialEndPos = EndBoneCSTransform.GetTranslation();
		
		FTransform EffectorTransform;
		if (OneTwoBoneIKParamValue.EffectorLocationMode == EC7TwoBoneIKModificationMode::TBMM_Additive)
		{
			EffectorTransform = EndBoneCSTransform;
			
			// Convert to Bone Space.
			FAnimationRuntime::ConvertCSTransformToBoneSpace(ComponentTransform, Output.Pose, EffectorTransform, IKBoneCompactPoseIndex, OneTwoBoneIKParamValue.EffectorLocationSpace);
			
			EffectorTransform.AddToTranslation(OneTwoBoneIKParamValue.EffectorLocation);
			
			// Convert back to Component Space.
			FAnimationRuntime::ConvertBoneSpaceTransformToCS(ComponentTransform, Output.Pose, EffectorTransform, IKBoneCompactPoseIndex, OneTwoBoneIKParamValue.EffectorLocationSpace);
		}
		else
		{
			// Transform EffectorLocation from EffectorLocationSpace to ComponentSpace.
			EffectorTransform = GetTargetTransform(
			Output.AnimInstanceProxy->GetComponentTransform(), Output.Pose,
			OneTwoBoneIKParamValue.EffectorTarget, OneTwoBoneIKParamValue.EffectorLocationSpace, OneTwoBoneIKParamValue.EffectorLocation);
		}

		// Get joint target (used for defining plane that joint should be in).
		FTransform JointTargetTransform = GetTargetTransform(
			Output.AnimInstanceProxy->GetComponentTransform(), Output.Pose,
			OneTwoBoneIKParamValue.JointTarget, OneTwoBoneIKParamValue.JointTargetLocationSpace, OneTwoBoneIKParamValue.JointTargetLocation);

		FVector	JointTargetPos = JointTargetTransform.GetTranslation();
		
		// This is our reach goal.
		FVector DesiredPos = EffectorTransform.GetTranslation();

		// IK solver
		UpperLimbCSTransform.SetLocation(RootPos);
		LowerLimbCSTransform.SetLocation(InitialJointPos);
		EndBoneCSTransform.SetLocation(InitialEndPos);

		AnimationCore::SolveTwoBoneIK(
			UpperLimbCSTransform, LowerLimbCSTransform, EndBoneCSTransform, JointTargetPos, DesiredPos,
			OneTwoBoneIKParamValue.bAllowStretching, OneTwoBoneIKParamValue.StartStretchRatio, OneTwoBoneIKParamValue.MaxStretchScale);

		if (!OneTwoBoneIKParamValue.bAllowTwist)
		{
			auto RemoveTwist = [this](const FTransform& InParentTransform, FTransform& InOutTransform, const FTransform& OriginalLocalTransform, const FVector& InAlignVector) 
			{
				FTransform LocalTransform = InOutTransform.GetRelativeTransform(InParentTransform);
				FQuat LocalRotation = LocalTransform.GetRotation();
				FQuat NewTwist, NewSwing;
				LocalRotation.ToSwingTwist(InAlignVector, NewSwing, NewTwist);
				NewSwing.Normalize();

				// get new twist from old local
				LocalRotation = OriginalLocalTransform.GetRotation();
				FQuat OldTwist, OldSwing;
				LocalRotation.ToSwingTwist(InAlignVector, OldSwing, OldTwist);
				OldTwist.Normalize();

				InOutTransform.SetRotation(InParentTransform.GetRotation() * NewSwing * OldTwist);
				InOutTransform.NormalizeRotation();
			};

			const FCompactPoseBoneIndex UpperLimbParentIndex = BoneContainer.GetParentBoneIndex(CachedUpperLimbIndex);
			FVector AlignDir = OneTwoBoneIKParamValue.TwistAxis.GetTransformedAxis(FTransform::Identity);
			if (UpperLimbParentIndex != INDEX_NONE)
			{
				FTransform UpperLimbParentTransform = Output.Pose.GetComponentSpaceTransform(UpperLimbParentIndex);
				RemoveTwist(UpperLimbParentTransform, UpperLimbCSTransform, UpperLimbLocalTransform, AlignDir);
			}
			
			RemoveTwist(UpperLimbCSTransform, LowerLimbCSTransform, LowerLimbLocalTransform, AlignDir);
		}

		
		float BlendAlpha = OneTwoBoneIKParamValue.BlendAlpha;
		FName AlphaCurveName = OneTwoBoneIKParamValue.AlphaCurveName;
		if (AlphaCurveName != NAME_None)
		{
			if (CurveValueMap.Contains(AlphaCurveName))
			{
				BlendAlpha = CurveValueMap[AlphaCurveName];
			}
			else
			{
				AnimInstance->GetCurveValueWithDefault(AlphaCurveName, OneTwoBoneIKParamValue.AlphaDefaultValue, BlendAlpha);
				CurveValueMap.Add(AlphaCurveName, BlendAlpha);
			}
		}

		BoneTransforms.Reset();
		BoneAlphas.Reset();
		
		// Update transform for upper bone.
		{
			// Order important. First bone is upper limb.
			BoneTransforms.Add( FBoneTransform(CachedUpperLimbIndex, UpperLimbCSTransform) );
			BoneAlphas.Emplace(CachedUpperLimbIndex.GetInt(), BlendAlpha);
		}

		// Update transform for lower bone.
		{
			// Order important. Second bone is lower limb.
			BoneTransforms.Add( FBoneTransform(CachedLowerLimbIndex, LowerLimbCSTransform) );
			BoneAlphas.Emplace(CachedLowerLimbIndex.GetInt(), BlendAlpha);
		}

		// Update transform for end bone.
		{
			// only allow bTakeRotationFromEffectorSpace during bone space
			if (bInBoneSpace && OneTwoBoneIKParamValue.bTakeRotationFromEffectorSpace)
			{
				EndBoneCSTransform.SetRotation(EffectorTransform.GetRotation());
			}
			else if (OneTwoBoneIKParamValue.bMaintainEffectorRelRot)
			{
				EndBoneCSTransform = EndBoneLocalTransform * LowerLimbCSTransform;
			}
			// Order important. Third bone is End Bone.
			BoneTransforms.Add(FBoneTransform(IKBoneCompactPoseIndex, EndBoneCSTransform));
			BoneAlphas.Emplace(IKBoneCompactPoseIndex.GetInt(), BlendAlpha);
		}

		// todo 需要还原回 极限值1 @sunya
		// const float BlendWeight = FMath::Clamp<float>(Alpha, 0.f, 1.f);
		const float BlendWeight = FMath::Clamp<float>(Alpha, 0.f, 0.999);
		// 备注: 这里每次骨骼更新都需要调用,因为存在骨骼空间位置依赖
		Output.Pose.LocalBlendCSBoneTransforms(BoneTransforms, BlendWeight, &BoneAlphas);
	}
	
	
	return true;
}




FTransform FAnimNode_C7ModifyBones::GetTargetTransform(const FTransform& InComponentTransform, FCSPose<FCompactPose>& MeshBases, FBoneSocketTarget& InTarget, EBoneControlSpace Space, const FVector& InOffset) 
{
	FTransform OutTransform;
	if (Space == BCS_BoneSpace)
	{
		OutTransform = InTarget.GetTargetTransform(InOffset, MeshBases, InComponentTransform);
	}
	else
	{
		// parent bone space still goes through this way
		// if your target is socket, it will try find parents of joint that socket belongs to
		OutTransform.SetLocation(InOffset);
		FAnimationRuntime::ConvertBoneSpaceTransformToCS(InComponentTransform, MeshBases, OutTransform, InTarget.GetCompactPoseBoneIndex(), Space);
	}

	return OutTransform;
}