// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Animation/AnimNotify/AnimNotifyState_C7LocoCameraSetting.h"

#include "3C/Character/BaseCharacter.h"
#include "3C/Character/C7Actor.h"
#include "Components/SkeletalMeshComponent.h"


void UAnimNotifyState_C7LocoCameraSetting::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7LocoCameraSetting::NotifyBegin");
	
	if(ABaseCharacter* TargetCharacter = Cast<ABaseCharacter>(MeshComp->GetOwner()))
	{
		ICppEntityInterface* CppEntity = UKGUEActorManager::GetLuaEntityByActor(MeshComp->GetOwner());
		if (!CppEntity || !CppEntity->GetIsMainPlayer())
		{
			return;
		}
		TargetCharacter->CallLuaEntity(TargetCharacter, TargetCharacter->GetEntityUID(), "KCB_OnAnimNotify_LocoCameraNotify", TargetCharacter->GetEntityUID(), true, ModifierID);
	}
}

void UAnimNotifyState_C7LocoCameraSetting::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7LocoCameraSetting::NotifyEnd");
	
	if(ABaseCharacter* TargetCharacter = Cast<ABaseCharacter>(MeshComp->GetOwner()))
	{
		ICppEntityInterface* CppEntity = UKGUEActorManager::GetLuaEntityByActor(MeshComp->GetOwner());
		if (!CppEntity || !CppEntity->GetIsMainPlayer())
		{
			return;
		}
		TargetCharacter->CallLuaEntity(TargetCharacter, TargetCharacter->GetEntityUID(), "KCB_OnAnimNotify_LocoCameraNotify", TargetCharacter->GetEntityUID(), false, ModifierID);
	}
}
