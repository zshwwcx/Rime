// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Animation/AnimNotify/AnimNotify_C7CommonEvent.h"
#include "3C/Animation/BaseAnimInstance.h"



void UAnimNotify_C7CommonEvent::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	UBaseAnimInstance* AnimIns = Cast<UBaseAnimInstance>(MeshComp->GetAnimInstance());

	if (AnimIns == nullptr)
	{
		return;
	}

	// ACharacter* OwnerCharacter = Cast<ACharacter>(AnimIns->TryGetPawnOwner());
	//
	// if (OwnerCharacter == nullptr)
	// {
	// 	return;
	// }
	//
	// URoleMovementComponent* RoleMovementComponent = Cast<URoleMovementComponent>(OwnerCharacter->GetMovementComponent());
	//
	// if (RoleMovementComponent != nullptr)
	// {
	// 	RoleMovementComponent->OnAnimCommonEvent(EventType);
	// }
}
