// Copyright Epic Games, Inc. All Rights Reserved.

// #pragma once

#include "3C/Animation/AnimNotify/Movement/AnimNotifyState_ALSRotationLerpAdjust.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Movement/RoleMovementComponent.h"



void UAnimNotifyState_ALSRotationLerpAdjust::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_ALSRotationLerpAdjust::NotifyBegin");
	
	if (ABaseCharacter* Character = Cast<ABaseCharacter>(MeshComp->GetOwner()))
	{
		if (URoleMovementComponent* RoleMoveComp = Cast<URoleMovementComponent>(Character->GetMovementComponent()))
		{
			if (RoleMoveComp->IsALSMovementMode())
			{
				RoleMoveComp->OverrideLerpSpeedForVelocityDirection = OverrideLerpSpeedForVelocityDirection;
			}
		}
	}
}

void UAnimNotifyState_ALSRotationLerpAdjust::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_ALSRotationLerpAdjust::NotifyEnd");
	
	if (ABaseCharacter* Character = Cast<ABaseCharacter>(MeshComp->GetOwner()))
	{
		if (URoleMovementComponent* RoleMoveComp = Cast<URoleMovementComponent>(Character->GetMovementComponent()))
		{
			RoleMoveComp->OverrideLerpSpeedForVelocityDirection = -1.0f;
		}
	}
}