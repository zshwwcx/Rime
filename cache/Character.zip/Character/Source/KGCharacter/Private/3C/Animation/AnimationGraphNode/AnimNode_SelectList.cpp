// Copyright Epic Games, Inc. All Rights Reserved.

#include "3C/Animation/AnimationGraphNode/AnimNode_SelectList.h"
#include "AnimationRuntime.h"
#include "Animation/AnimInertializationSyncScope.h"
#include "Animation/BlendProfile.h"
#include "Animation/AnimInstanceProxy.h"
#include "Animation/AnimNode_Inertialization.h"
#include "Animation/AnimTrace.h"
#include "Animation/SkeletonRemapping.h"
#include "Animation/SkeletonRemappingRegistry.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(AnimNode_SelectList)

/////////////////////////////////////////////////////
// FAnimNode_SelectList

void FAnimNode_SelectList::InitializeNodeStaticData()
{
	RangeValueList[0] = GET_ANIM_NODE_DATA(int32, IntIndexRange1);
	RangeValueList[1] = GET_ANIM_NODE_DATA(int32, IntIndexRange2);
	RangeValueList[2] = GET_ANIM_NODE_DATA(int32, IntIndexRange3);
	RangeValueList[3] = GET_ANIM_NODE_DATA(int32, BoolIndexRange1);
	RangeValueList[4] = GET_ANIM_NODE_DATA(int32, BoolIndexRange2);
	RangeValueList[5] = GET_ANIM_NODE_DATA(int32, BoolIndexRange3);
	IfAllowBlendList[0] = GET_ANIM_NODE_DATA(bool, bAllowBlendForIntChildIndex1);
	IfAllowBlendList[1] = GET_ANIM_NODE_DATA(bool, bAllowBlendForIntChildIndex2);
	IfAllowBlendList[2] = GET_ANIM_NODE_DATA(bool, bAllowBlendForIntChildIndex3);
	IfAllowBlendList[3] = GET_ANIM_NODE_DATA(bool, bAllowBlendForBoolChildIndex1);
	IfAllowBlendList[4] = GET_ANIM_NODE_DATA(bool, bAllowBlendForBoolChildIndex2);
	IfAllowBlendList[5] = GET_ANIM_NODE_DATA(bool, bAllowBlendForBoolChildIndex3);
	FinalBlendTimeIfAllowBlend = GET_ANIM_NODE_DATA(float, BlendTimeIfAllowBlend);
	for (int32 i = 0; i < IfUseCacheNodeValueList.Num(); i++)
	{
		IfUseCacheNodeValueList[i] = false;
	}
	for (int32 i = 0; i < CachedNodeValueList.Num(); i++)
	{
		CachedNodeValueList[i] = 0;
	}
	BlendDataList.SetNum(SelectPose.Num());
}

int32 FAnimNode_SelectList::GetChildIndexNodeDate(int32 Index)
{
	switch (Index)
	{
	case 0:
		return GET_ANIM_NODE_DATA(int32, ActiveIntChildIndex1);
	case 1:
		return GET_ANIM_NODE_DATA(int32, ActiveIntChildIndex2);
	case 2:
		return GET_ANIM_NODE_DATA(int32, ActiveIntChildIndex3);
	case 3:
		return GET_ANIM_NODE_DATA(bool, ActiveBoolChildIndex1) ? 1 : 0;
	case 4:
		return GET_ANIM_NODE_DATA(bool, ActiveBoolChildIndex2) ? 1 : 0;
	case 5:
		return GET_ANIM_NODE_DATA(bool, ActiveBoolChildIndex3) ? 1 : 0;
	default:
		return 0;
	}
}

int32 FAnimNode_SelectList::GetActiveChildIndex()
{
	int32 EffectedActiveValue = 0;
	int32 WeightValue = 1;

	int32 RangeValue = 0;
	for (int32 i = 0; i < 6; i++)
	{
		RangeValue = RangeValueList[i];
		if (RangeValue > 0)
		{
			int32 IndexValue = IfUseCacheNodeValueList[i] ? CachedNodeValueList[i] : FMath::Min(GetChildIndexNodeDate(i), RangeValue);
			EffectedActiveValue += WeightValue * IndexValue;
			WeightValue *= (RangeValue + 1);

			IfUseCacheNodeValueList[i] = !IfAllowBlendList[i];
			CachedNodeValueList[i] = IndexValue;
		}
	}

	return FMath::Clamp<int32>(EffectedActiveValue, 0, SelectPose.Num() - 1);
}

void FAnimNode_SelectList::UpdateForceUpdatePoseIndexList()
{
	ForceUpdatePoseIndexList.Empty();
	int32 WeightValue = 1;
	for (int32 PosIndex = 0; PosIndex < RangeValueList.Num(); PosIndex++)
	{
		int32 RangeValue = RangeValueList[PosIndex];
		if (RangeValue > 0)
		{
			// 不使用Cache值，说明会Blend
			if (!IfUseCacheNodeValueList[PosIndex])
			{
				if (ForceUpdatePoseIndexList.IsEmpty())
				{
					ForceUpdatePoseIndexList.Add(GetNonBlendIndex());
				}

				int32 StartNum = ForceUpdatePoseIndexList.Num();
				for (int32 i = 0; i < StartNum; i++)
				{
					for (int32 j = 0; j <= RangeValue; j++)
					{
						ForceUpdatePoseIndexList.AddUnique(FMath::Min(ForceUpdatePoseIndexList[i] + j * WeightValue, SelectPose.Num() - 1));
					}
				}
			}

			WeightValue *= (RangeValue + 1);
		}
	}

}

int32 FAnimNode_SelectList::GetNonBlendIndex()
{
	int32 EffectedActiveValue = 0;
	int32 WeightValue = 1;

	int32 RangeValue = 0;
	for (int32 i = 0; i < 6; i++)
	{
		RangeValue = RangeValueList[i];
		if (RangeValue > 0)
		{
			if (IfUseCacheNodeValueList[i])
			{
				int32 IndexValue = CachedNodeValueList[i];
				EffectedActiveValue += WeightValue * IndexValue;
			}
			WeightValue *= (RangeValue + 1);
		}
	}

	return FMath::Clamp<int32>(EffectedActiveValue, 0, SelectPose.Num() - 1);
}

void FAnimNode_SelectList::Initialize_AnyThread(const FAnimationInitializeContext& Context)
{
	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(Initialize_AnyThread)
	FAnimNode_Base::Initialize_AnyThread(Context);
	GetEvaluateGraphExposedInputs().Execute(Context);
	InitializeNodeStaticData();

	int32 CurActiveIndex = GetActiveChildIndex();
	LastActiveChildIndex = CurActiveIndex;
	SelectPose[CurActiveIndex].Initialize(Context);

	UpdateForceUpdatePoseIndexList();
	if (ForceUpdatePoseIndexList.Num() > 0)
	{
		for (int32 i = 0; i < ForceUpdatePoseIndexList.Num(); i++)
		{
			if (CurActiveIndex != ForceUpdatePoseIndexList[i])
			{
				SelectPose[ForceUpdatePoseIndexList[i]].Initialize(Context);
			}
		}

		for (int32 i = 0; i < BlendDataList.Num(); i++)
		{
			if (CurActiveIndex == i)
			{
				BlendDataList[i].SetValueRange(0.0f, 1.0f);
			}
			else
			{
				BlendDataList[i].SetValueRange(1.0f, 0.0f);
			}
			BlendDataList[i].SetAlpha(1.0f);
			BlendDataList[i].SetBlendTime(FinalBlendTimeIfAllowBlend);
		}
	}
}

void FAnimNode_SelectList::CacheBones_AnyThread(const FAnimationCacheBonesContext& Context)
{
	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(CacheBones_AnyThread)

	SelectPose[LastActiveChildIndex].CacheBones(Context);

	for (int32 i = 0; i < ForceUpdatePoseIndexList.Num(); i++)
	{
		if (LastActiveChildIndex != ForceUpdatePoseIndexList[i])
		{
			SelectPose[ForceUpdatePoseIndexList[i]].CacheBones(Context);
		}
	}
}

void FAnimNode_SelectList::Update_AnyThread(const FAnimationUpdateContext& Context)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_SelectList::Update_AnyThread ");

	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(Update_AnyThread)
	GetEvaluateGraphExposedInputs().Execute(Context);

	int32 CurActiveIndex = GetActiveChildIndex();
	if (ForceUpdatePoseIndexList.Num() > 0)
	{
		const float deltaTime = Context.GetDeltaTime();

		if (CurActiveIndex != LastActiveChildIndex)
		{
			BlendDataList[LastActiveChildIndex].SetDesiredValue(0.0f);
			BlendDataList[LastActiveChildIndex].Reset();
			BlendDataList[CurActiveIndex].SetDesiredValue(1.0f);
			BlendDataList[CurActiveIndex].Reset();
		}
		
		float TotalWeight = 0.0f;
		for (int32 i = 0; i < ForceUpdatePoseIndexList.Num(); i++)
		{
			BlendDataList[ForceUpdatePoseIndexList[i]].Update(deltaTime);
			TotalWeight += BlendDataList[ForceUpdatePoseIndexList[i]].GetBlendedValue();
		}

		if (TotalWeight > 0.0f)
		{
			for (int32 i = 0; i < ForceUpdatePoseIndexList.Num(); i++)
			{
				float Weight = BlendDataList[ForceUpdatePoseIndexList[i]].GetBlendedValue() / TotalWeight;
				if (Weight > ZERO_ANIMWEIGHT_THRESH)
				{
					SelectPose[ForceUpdatePoseIndexList[i]].Update(Context.FractionalWeight(Weight));
				}
			}
		}
	}
	else
	{
		// 没有Blend纯Select分支
		SelectPose[CurActiveIndex].Update(Context);
	}

	LastActiveChildIndex = CurActiveIndex;

#if ANIM_TRACE_ENABLED
	const int32 ChildIndex = GetActiveChildIndex();
	TRACE_ANIM_NODE_VALUE(Context, TEXT("Active Index"), ChildIndex);
#endif
}

void FAnimNode_SelectList::Evaluate_AnyThread(FPoseContext& Output)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_SelectList::Evaluate_AnyThread");

	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(Evaluate_AnyThread)
	ANIM_MT_SCOPE_CYCLE_COUNTER(BlendPosesInGraph, !IsInGameThread());
	
	if (ForceUpdatePoseIndexList.Num() > 0)
	{
		float TotalWeight = 0.0f;
		for (int32 i = 0; i < ForceUpdatePoseIndexList.Num(); i++)
		{
			TotalWeight += BlendDataList[ForceUpdatePoseIndexList[i]].GetBlendedValue();
		}
		if (TotalWeight <= 0.0f)
		{
			// 不应该到这里
			Output.ResetToRefPose();
			return;
		}

		// Build local arrays to pass to the BlendPosesTogether runtime
		TArray<int32, TInlineAllocator<8>> PosesToEvaluate;
		TArray<float, TInlineAllocator<8>> BlendWeights;
		TArray<FCompactPose, TInlineAllocator<8>> FilteredPoses;
		TArray<FBlendedCurve, TInlineAllocator<8>> FilteredCurve;
		TArray<UE::Anim::FStackAttributeContainer, TInlineAllocator<8>> FilteredAttributes;
		
		for (int32 i = 0; i < ForceUpdatePoseIndexList.Num(); i++)
		{
			float Weight = BlendDataList[ForceUpdatePoseIndexList[i]].GetBlendedValue() / TotalWeight;
			
			if (1 - Weight < ZERO_ANIMWEIGHT_THRESH)
			{
				// 直接全部输出
				SelectPose[ForceUpdatePoseIndexList[i]].Evaluate(Output);
				return;
			}
			else if (Weight > ZERO_ANIMWEIGHT_THRESH)
			{
				int32 CurBlendNum = PosesToEvaluate.Num();
				
				BlendWeights.Add(Weight);
				PosesToEvaluate.Add(CurBlendNum);

				FPoseContext EvaluateContext(Output);
				FPoseLink& CurrentPose = SelectPose[ForceUpdatePoseIndexList[i]];
				CurrentPose.Evaluate(EvaluateContext);

				FilteredPoses.Add(FCompactPose());
				FilteredPoses[CurBlendNum].MoveBonesFrom(EvaluateContext.Pose);
				FilteredCurve.Add(FBlendedCurve());
				FilteredCurve[CurBlendNum].MoveFrom(EvaluateContext.Curve);
				FilteredAttributes.Add(UE::Anim::FStackAttributeContainer());
				FilteredAttributes[CurBlendNum].MoveFrom(EvaluateContext.CustomAttributes);
			}
		}

		FAnimationPoseData OutAnimationPoseData(Output);
		FAnimationRuntime::BlendPosesTogether(FilteredPoses, FilteredCurve, FilteredAttributes, BlendWeights, PosesToEvaluate, OutAnimationPoseData);
	}
	else
	{
		// 没有Blend纯Select分支
		SelectPose[GetActiveChildIndex()].Evaluate(Output);
	}
}

void FAnimNode_SelectList::GatherDebugData(FNodeDebugData& DebugData)
{
	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(GatherDebugData)
	const int32 NumPoses = SelectPose.Num();
	const int32 ChildIndex = GetActiveChildIndex();

	FString DebugLine = GetNodeName(DebugData);
	DebugLine += FString::Printf(TEXT("(Active: (%i/%i) Weight: %.1f%% Time %.3f)"), ChildIndex + 1, NumPoses);

	DebugData.AddDebugItem(DebugLine);
}