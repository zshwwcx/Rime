#include "3C/Animation/FaceAnim/FaceAnimLipSync.h"
#include "Misc/Paths.h"
#include "HAL/FileManager.h"
#include "Engine/UserDefinedStruct.h"
#include "Engine/DataTable.h"
#include "Components/SkeletalMeshComponent.h"


UFaceAnimLipSync::UFaceAnimLipSync()
{
}

void UFaceAnimLipSync::InitLipSync(FLipSyncAssetInfo InSyncAssetInfo, class USkeletalMeshComponent* InMesh)
{
	VisemeAssetInfo = InSyncAssetInfo;
	Mesh = InMesh;
	VisemeStruct = VisemeAssetInfo.VisemeStruct;
	if (VisemeStruct == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("UFaceAnimLipSync::InitLipSync VisemeStruct InValid"));
		return ;
	}

	LoadAllAssetPath();
}

void UFaceAnimLipSync::Update(float DeltaTime)
{
	OnUpdate(DeltaTime);
}

void UFaceAnimLipSync::Reset()
{
	for (auto& Elem : CurVisemePlayMap)
	{
		Elem.Value = .0f;
	}
	OnReset();
}

void UFaceAnimLipSync::Play(const FString & VisemeFileName)
{
	FString* FilePathPtr = VisemeAssetPathMap.Find(VisemeFileName);
	if (!FilePathPtr)
	{
		return ;
	}

	LoadVisemeDataTable(*FilePathPtr);
	OnPlay(VisemeFileName);
}

void UFaceAnimLipSync::Pause()
{
	OnPause();
}

void UFaceAnimLipSync::Stop()
{
	OnStop();
}

void UFaceAnimLipSync::LoadAllAssetPath()
{
	VisemeAssetPathMap.Empty();

	for (auto& ElemP : VisemeAssetInfo.VisemeFolderList)
	{
		FString AssetFolder = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir());
		AssetFolder += ElemP.Path;

		TArray<FString> TempFilePath;
		IFileManager::Get().FindFiles(TempFilePath, *AssetFolder);

		AssetFolder = FPaths::ProjectContentDir();
		AssetFolder = ElemP.Path;
		for (auto& FileP : TempFilePath)
		{ 
			FString FileName = FPaths::GetBaseFilename(FileP);
			FString FilePath("");
			FilePath = "/Game";
			FilePath = FilePath / (AssetFolder / FileName);
			FilePath = FilePath + ".";
			FilePath += FileName;
			VisemeAssetPathMap.Add(FileName, FilePath);
		}
	}


	TriggerFacePathMap.Empty();
	for (auto& ElemT : VisemeAssetInfo.TriggerFaceFolderList)
	{
		FString AssetFolder = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir());
		AssetFolder += ElemT.Path;

		TArray<FString> TempFilePath;
		IFileManager::Get().FindFiles(TempFilePath, *AssetFolder);

		AssetFolder = FPaths::ProjectContentDir();
		AssetFolder = ElemT.Path;
		for (auto& FileP : TempFilePath)
		{
			FString FileName = FPaths::GetBaseFilename(FileP);
			FString FilePath("");
			FilePath = "/Game";
			FilePath = FilePath / (AssetFolder / FileName);
			FilePath = FilePath + ".";
			FilePath += FileName;
			TriggerFacePathMap.Add(FileName, FilePath);
		}
	}
}

void UFaceAnimLipSync::LoadVisemeDataTable(const FString& FilePath)
{
	UDataTable* DataTable = Cast<UDataTable>(StaticLoadObject(UDataTable::StaticClass(), NULL, *FilePath));

	if (DataTable == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("\tUFaceAnimLipSync::LoadVisemeDataTable  DataTable Error FilePath %s !")
			, *FilePath);
		return;
	}

	CurVisemeAssetDataMap.Empty();


	TArray<FName> RowName = DataTable->GetRowNames();
	//FVisemeFrameData FrameData;
	InternalParseDataTable(DataTable, RowName);

	//int32 FrameCount = 1;
	//for (auto it : DataTable->GetRowMap())
	//{
	//	it.Key;
	//	FTableRowBase* DatableRow = (FTableRowBase*)it.Value;

	//	//FVisemeFrameData FrameData;
	//	//UClass* CC = VisemeStruct->GetClass();
	//	//FString name1 = CC->GetName();

	//	//InternalParseDataTable(DatableRow, FrameData);

	//	//for (TFieldIterator<FProperty> It(VisemeStruct->GetClass(), EFieldIteratorFlags::ExcludeSuper); It; ++It)
	//	//{
	//	//	if (FProperty* pro = CastField<FProperty>(*It))
	//	//	{
	//	//		//for (int32 StaticIndex = 0; StaticIndex != pro->ArrayDim; ++StaticIndex)
	//	//		//{
	//	//			//const void* ValuePtr = pro->ContainerPtrToValuePtr<const void>(DatableRow);

	//	//			//FString KeyString = FString::Printf(TEXT("[%d]"), 0);
	//	//			//FString ValueString;
	//	//			////pro->ExportText_Direct(ValueString, ValuePtr, ValuePtr, nullptr, PPF_None);
	//	//			//if (!ValueString.IsEmpty())
	//	//			//{
	//	//			//	//FrameData.FrameViseme.Add(KeyString, FCString::Atof(*ValueString));
	//	//			//}
	//	//			
	//	//		//}
	//	//	}

	//	//	for (FProperty* CurrentProp : TFieldRange<FProperty>(VisemeStruct->GetClass()))
	//	//	{
	//	//		FString pro  = VisemeStruct->GetAuthoredNameForField(CurrentProp);
	//	//	}

	//	//	if (FFloatProperty* FloatProperty = CastField<FFloatProperty>(*It))
	//	//	{
	//	//		FString VisemeName = FloatProperty->GetName();
	//	//		float Value = FloatProperty->GetFloatingPointPropertyValue(FloatProperty->ContainerPtrToValuePtr<uint8>(DatableRow));

	//	//		FrameData.FrameViseme.Add(VisemeName, Value);
	//	//	}

	//	//	if (FStructProperty* StructProperty = CastField<FStructProperty>(*It))
	//	//	{
	//	//		for (int32 StaticIndex = 0; StaticIndex != StructProperty->ArrayDim; ++StaticIndex)
	//	//		{
	//	//			const void* ValuePtr = StructProperty->ContainerPtrToValuePtr<const void>(DatableRow, StaticIndex);

	//	//			FString KeyString = FString::Printf(TEXT("[%d]"), StaticIndex);
	//	//			FString ValueString;
	//	//			StructProperty->ExportText_Direct(ValueString, ValuePtr, ValuePtr, nullptr, PPF_None);

	//	//			FrameData.FrameViseme.Add(KeyString, FCString::Atof(*ValueString));
	//	//		}
	//	//	}


	//	//}



	//	//CurVisemeAssetDataMap.Add(FrameCount, FrameData);

	//	++FrameCount;
	//}
}

void UFaceAnimLipSync::LoadTriggerFaceDataTable(const FString & FilePath)
{

	UDataTable* DataTable = Cast<UDataTable>(StaticLoadObject(UDataTable::StaticClass(), NULL, *FilePath));

	if (DataTable == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("\tUFaceAnimLipSync::LoadTriggerFaceDataTable  DataTable Error FilePath %s !")
			, *FilePath);
		return;
	}

	CurTriggerFaceDataMap.Empty();

	TArray<FName> RowName = DataTable->GetRowNames();

	InternalTriggerFaceParseDataTable(DataTable, RowName);
}
