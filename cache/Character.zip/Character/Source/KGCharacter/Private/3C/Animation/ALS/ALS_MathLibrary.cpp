// Copyright:       Copyright (C) 2022 Doğa Can Yanıkoğlu
// Source Code:     https://github.com/dyanikoglu/ALS-Community


#include "3C/Animation/ALS/ALS_MathLibrary.h"

#include "Components/CapsuleComponent.h"


bool UALS_MathLibrary::AngleInRange(float Angle, float MinAngle, float MaxAngle, float Buffer, bool IncreaseBuffer)
{
	if (IncreaseBuffer)
	{
		return Angle >= MinAngle - Buffer && Angle <= MaxAngle + Buffer;
	}
	return Angle >= MinAngle + Buffer && Angle <= MaxAngle - Buffer;
}

EALS_MovementDirection UALS_MathLibrary::CalculateQuadrant(EALS_MovementDirection Current, float FRThreshold,
                                                         float FLThreshold,
                                                         float BRThreshold, float BLThreshold, float Buffer,
                                                         float Angle)
{
	// Take the input angle and determine its quadrant (direction). Use the current Movement Direction to increase or
	// decrease the buffers on the angle ranges for each quadrant.
	if (AngleInRange(Angle, FLThreshold, FRThreshold, Buffer,
	                 Current != EALS_MovementDirection::Forward && Current != EALS_MovementDirection::Backward))
	{
		return EALS_MovementDirection::Forward;
	}

	if (AngleInRange(Angle, FRThreshold, BRThreshold, Buffer,
	                 Current != EALS_MovementDirection::Right && Current != EALS_MovementDirection::Left))
	{
		return EALS_MovementDirection::Right;
	}

	if (AngleInRange(Angle, BLThreshold, FLThreshold, Buffer,
	                 Current != EALS_MovementDirection::Right && Current != EALS_MovementDirection::Left))
	{
		return EALS_MovementDirection::Left;
	}

	return EALS_MovementDirection::Backward;
}
