// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Animation/AnimNotify/AnimNotifyState_TerrainNiagara.h"

#include "3C/Animation/AnimNotify/AnimNotify_TerrainNiagara.h"
#include "3C/Audio/C7AnimNotify_FootStepAkEvent.h"
#include "Misc/KGPlatformUtils.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "3C/Effect/KGEffectManager.h"
#include "3C/Interactor/WorldManager.h"
#include "3C/Util/KGUtils.h"

void UAnimNotifyState_TerrainNiagara::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_TerrainNiagara::NotifyBegin");
	
	if (KGPlatformUtils::IsInLevelPreviewWorld(MeshComp))
	{
		return;
	}

	if (!MeshComp)
	{
		return;
	}

	AActor* OwnerActor = MeshComp->GetOwner();
	if (!OwnerActor)
	{
		return;
	}

	URoleMovementComponent* RoleMovementComp = OwnerActor->GetComponentByClass<URoleMovementComponent>();
	if (!RoleMovementComp)
	{
		return;
	}

	UWorldManager* WorldManager = UWorldManager::GetInstance(OwnerActor);
	if (!WorldManager)
	{
		return;
	}

	// 水深检测
	if (RoleMovementComp->GetIsInWater() && !WorldManager->IsInLegalWaterDepth(RoleMovementComp->GetCurWaterDepth()))
	{
		return;
	}

	FString TerrainName = UC7AnimNotify_FootStepAkEvent::GetNiagaraTerrainName(OwnerActor);
	if (TerrainName.IsEmpty())
	{
		return;
	}

	if (!Terrain2Niagara.Contains(TerrainName))
	{
		return;
	}

	const FTerrainNiagaraParams& Params = Terrain2Niagara[TerrainName];

	UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(OwnerActor);
	if (!EffectManager)
	{
		return;
	}

	KGObjectID ActorID = KGUtils::GetIDByObject(OwnerActor);

	FKGPlayNiagaraParams PlayNiagaraParams;
	PlayNiagaraParams.NiagaraEffectPath = Params.Niagara.ToString();
	PlayNiagaraParams.SpawnerID = ActorID;
	
	// 贴地设置
	if (RoleMovementComp->GetIsInWater() || RoleMovementComp->GetIsInWaterWalk())
	{
		PlayNiagaraParams.StickGroundType = Params.bNiagaraStickGround ? EKGNiagaraStickGroundType::StickToWaterSurface : EKGNiagaraStickGroundType::DoNotStickToGround;
	}
	else
	{
		PlayNiagaraParams.StickGroundType = Params.bNiagaraStickGround ? EKGNiagaraStickGroundType::StickToGround : EKGNiagaraStickGroundType::DoNotStickToGround;
	}
	
	if (!Params.bNiagaraAttach)
	{
		FKGUnattachedNiagaraSpawnInfo UnattachedNiagaraSpawnInfo;
		UnattachedNiagaraSpawnInfo.SearchSpawnLocationType = EKGNiagaraSearchSpawnLocationType::UseCustomSpawnTrans;
		UnattachedNiagaraSpawnInfo.WorldOrRelativeTrans = Params.NiagaraTransform * MeshComp->GetSocketTransform(Params.NiagaraBaseSocket, RTS_World);
		PlayNiagaraParams.SetUnattachedSpawnInfo(UnattachedNiagaraSpawnInfo);
	}
	else
	{
		FKGAttachedNiagaraSpawnInfo AttachedNiagaraSpawnInfo;
		AttachedNiagaraSpawnInfo.RelativeTrans = Params.NiagaraTransform;
		AttachedNiagaraSpawnInfo.SearchAttachComponentType = EKGNiagaraSearchAttachComponentType::UseMainMeshComponent;
		AttachedNiagaraSpawnInfo.AttachPointName = Params.NiagaraBaseSocket;
		AttachedNiagaraSpawnInfo.bAbsoluteRotation = Params.bNiagaraUseAbsoluteRotation;
		PlayNiagaraParams.SetAttachedSpawnInfo(AttachedNiagaraSpawnInfo);
	}

	int32 TerrainNiagaraID = EffectManager->CreateNiagaraSystem(PlayNiagaraParams);
	ActorID2TerrainNiagaraID.Emplace(ActorID, TerrainNiagaraID);
}

void UAnimNotifyState_TerrainNiagara::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_TerrainNiagara::NotifyEnd");
	
	if (KGPlatformUtils::IsInLevelPreviewWorld(MeshComp))
	{
		return;
	}

	if (!MeshComp)
	{
		return;
	}

	AActor* OwnerActor = MeshComp->GetOwner();
	if (!OwnerActor)
	{
		return;
	}

	UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(MeshComp);
	if (!EffectManager)
	{
		return;
	}

	KGObjectID ActorID = KGUtils::GetIDByObject(OwnerActor);
	if (int32* TerrainNiagaraID = ActorID2TerrainNiagaraID.Find(ActorID))
	{
		EffectManager->DeactivateNiagaraSystem(*TerrainNiagaraID);
	}
}
