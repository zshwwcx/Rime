/**
 * Auth :   liubo
 * Date :   2026-02-07 15:21
 * Comment: 实验功能，有很多临时代码，不要正式使用
 */
 
#include "3C/Animation/AnimationGraphNode/AnimNode_AIBodyPlayer.h"
#include "Animation/AnimMontage.h"

#define LOCTEXT_NAMESPACE "AnimNode_AIBodyPlayer"


FAnimNode_AIBodyPlayer::FAnimNode_AIBodyPlayer()
{

}

void FAnimNode_AIBodyPlayer::ChangeAnim(UAnimSequenceBase* NewAnim)
{
	SetSequence(NewAnim);
	SetAccumulatedTime(0);
}

#undef LOCTEXT_NAMESPACE