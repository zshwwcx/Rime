// Fill out your copyright notice in the Description page of Project Settings.
#include "3C/Animation/AnimNotify/AnimNotify_C7ChangeMaterialTexture.h"

#include "Misc/KGPlatformUtils.h"
#include "3C/RoleComposite/RoleCompositeManager.h"
#include "Animation/AnimSequenceBase.h"
#include "Components/SkeletalMeshComponent.h"
#include "3C/Material/KGMaterialManager.h"
#include "Materials/MaterialInstanceDynamic.h"

void UAnimNotify_C7ChangeMaterialTexture::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float InTotalDuration, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotify_C7ChangeMaterialTexture::NotifyBegin");
	Super::NotifyBegin(MeshComp, Animation, InTotalDuration, EventReference);

	if (!IsValid(MeshComp))
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UAnimNotify_C7ChangeMaterialTexture::NotifyBegin: MeshComp is invalid, %s"),
			IsValid(Animation) ? *Animation->GetPathName() : TEXT("null"));
		return;
	}

	if (KGPlatformUtils::IsInLevelPreviewWorld(MeshComp))
	{
		return;
	}
	
	if (UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(MeshComp))
	{
		FKGChangeMaterialParamRequest ChangeMaterialParamRequest;
		if (!bFindWithOutTag)
		{
			ChangeMaterialParamRequest.SearchMeshType = EKGSearchMeshType::SearchMeshByName;
			ChangeMaterialParamRequest.SearchMeshName = URoleCompositeMgr::AvatarBodyPartEnumToName(static_cast<int32>(ComponentTag));
		}

		ChangeMaterialParamRequest.SearchMaterialType = EKGSearchMaterialType::SearchMaterialBySlots;
		ChangeMaterialParamRequest.MaterialSlotNames.Add(SlotName);
		ChangeMaterialParamRequest.OwnerActor = MeshComp->GetOwner();
		
		ChangeMaterialParamRequest.ScalarRuntimeCurveParams.Reserve(FacialMaterialParams.Num());
		for (const auto& ParamPair : FacialMaterialParams)
		{
			const auto& ParamName = ParamPair.Key;
			const auto& ParamInfo = ParamPair.Value;
			
			if (ParamInfo.ParamType == EKGFacialMaterialParamType::ScalarConst)
			{
				ChangeMaterialParamRequest.ScalarParams.Add(ParamName, ParamInfo.ScalarConst);
			}
			else if (ParamInfo.ParamType == EKGFacialMaterialParamType::Curve)
			{
				auto& RuntimeCurveParams = ChangeMaterialParamRequest.ScalarRuntimeCurveParams.Add(ParamName);
				RuntimeCurveParams.RuntimeFloatCurve = ParamInfo.RuntimeFloatCurve;
				RuntimeCurveParams.bLoop = ParamInfo.bLoop;
				// 目前很多ChangeMaterialTexture AnimNotify配置不规范, AnimNotify的时长会超过整体动画时长, 这里先兼容下
				RuntimeCurveParams.bNeedRemap = true;
				float RemapTime = InTotalDuration;
				if (Animation)
				{
					RemapTime = FMath::Min(RemapTime, Animation->GetPlayLength());
				}
				RuntimeCurveParams.RemapTime = RemapTime;
			}
		}

		if (!TextureParameterNameA.IsNone() && NewTextureA)
		{
			ChangeMaterialParamRequest.TextureParams.Add(TextureParameterNameA, NewTextureA.ToString());	
		}

		const auto ReqID = MaterialManager->ChangeMaterialParam(ChangeMaterialParamRequest);
		ChangeMaterialReqIds.Add(MeshComp, ReqID);
	}
#if WITH_EDITOR
	else
	{
		HandleNotifyBeginEditorPreview(MeshComp, Animation, InTotalDuration, EventReference);
	}
#endif
}

void UAnimNotify_C7ChangeMaterialTexture::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotify_C7ChangeMaterialTexture::NotifyEnd");
	if (IsValid(MeshComp))
	{
		if (!KGPlatformUtils::IsInLevelPreviewWorld(MeshComp))
		{
			if (UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(MeshComp))
			{
				TWeakObjectPtr<USkeletalMeshComponent> MeshCompPtr(MeshComp);
				if (ChangeMaterialReqIds.Contains(MeshCompPtr))
				{
					MaterialManager->RevertMaterialParam(ChangeMaterialReqIds[MeshCompPtr]);
					ChangeMaterialReqIds.Remove(MeshCompPtr);
				}
			}
#if WITH_EDITOR
			else
			{
				HandleNotifyEndEditorPreview(MeshComp, Animation);
			}
#endif
		}
	}
	else
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UAnimNotify_C7ChangeMaterialTexture::NotifyEnd: MeshComp is invalid, %s"),
			IsValid(Animation) ? *Animation->GetPathName() : TEXT("null"));
	}
	
	Super::NotifyEnd(MeshComp, Animation, EventReference);
}

#if WITH_EDITOR
void UAnimNotify_C7ChangeMaterialTexture::HandleNotifyBeginEditorPreview(
	USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float InTotalDuration, const FAnimNotifyEventReference& EventReference)
{
#if WITH_EDITORONLY_DATA
	AActor* OwnerActor = MeshComp->GetOwner();
	if (!IsValid(OwnerActor))
	{
		UE_LOG(LogTemp, Warning, TEXT("UAnimNotify_C7ChangeMaterialTexture Mesh Owner is Valid!!!"));
		return;
	}

	TArray<USkeletalMeshComponent*> Result;
	if (bFindWithOutTag)
	{
		OwnerActor->GetComponents<USkeletalMeshComponent>(Result);
	}
	else
	{
		const auto& ComponentTagName = URoleCompositeMgr::AvatarBodyPartEnumToName(static_cast<int32>(ComponentTag));
		for (auto* SKMesh : OwnerActor->GetComponentsByTag(USkeletalMeshComponent::StaticClass(), ComponentTagName))
		{
			Result.Emplace(Cast<USkeletalMeshComponent>(SKMesh));
		}
	}
	
	auto& MaterialInstances = OverrideMaterialInstances.Add(OwnerActor);

	for (auto* TargetMesh : Result)
	{
		if (TargetMesh->GetSkinnedAsset() != nullptr)
		{
			const TArray<FSkeletalMaterial>& SkeletalMeshMaterials = TargetMesh->GetSkinnedAsset()->GetMaterials();
			for (int32 MaterialIndex = 0; MaterialIndex < SkeletalMeshMaterials.Num(); ++MaterialIndex)
			{
				const FSkeletalMaterial& SkeletalMaterial = SkeletalMeshMaterials[MaterialIndex];
				if (SkeletalMaterial.MaterialSlotName == SlotName)
				{
					UMaterialInterface* TargetMaterial = SkeletalMaterial.MaterialInterface;
					UMaterialInstanceDynamic* TargetDynamicMaterial = Cast<UMaterialInstanceDynamic>(TargetMaterial);
					if (TargetDynamicMaterial == nullptr)
					{
						TargetDynamicMaterial = TargetMesh->CreateAndSetMaterialInstanceDynamic(MaterialIndex);
					}

					if (!TargetDynamicMaterial)
					{
						continue;
					}

					MaterialInstances.Add(TargetDynamicMaterial);
					
					if (UTexture* Texture = NewTextureA.LoadSynchronous())
					{
						if (!TextureParameterNameA.IsNone())
						{
							UE_LOG(LogKGMaterial, Log, TEXT("UAnimNotify_C7ChangeMaterialTexture::HandleNotifyBeginEditorPreview: Set Texture Param %s %s %s %s %s %s"), 
								Animation ? *Animation->GetPathName() : TEXT("NULL"), 
								*OwnerActor->GetName(),
								*TargetMesh->GetName(),
								*TargetDynamicMaterial->GetName(), 
								*TextureParameterNameA.ToString(), 
								*Texture->GetPathName());
							TargetDynamicMaterial->SetTextureParameterValue(TextureParameterNameA, Texture);
						}
					}
					
					for (const auto& ScalarParamPair : FacialMaterialParams)
					{
						const FName& ParamName = ScalarParamPair.Key;
						const auto& ParamInfo = ScalarParamPair.Value;
						if (ParamInfo.ParamType == EKGFacialMaterialParamType::ScalarConst)
						{
							UE_LOG(LogKGMaterial, Log, TEXT("UAnimNotify_C7ChangeMaterialTexture::HandleNotifyBeginEditorPreview: Set Scalar Param %s %s %s %s %s %f"), 
								Animation ? *Animation->GetPathName() : TEXT("NULL"), 
								*OwnerActor->GetName(),
								*TargetMesh->GetName(),
								*TargetDynamicMaterial->GetName(), 
								*TextureParameterNameA.ToString(), 
								ParamInfo.ScalarConst);
							TargetDynamicMaterial->SetScalarParameterValue(ParamName, ParamInfo.ScalarConst);	
						}
					}
				}
			}
		}
	}
#endif
}

void UAnimNotify_C7ChangeMaterialTexture::NotifyTick(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float FrameDeltaTime, const FAnimNotifyEventReference& EventReference)
{
	Super::NotifyTick(MeshComp, Animation, FrameDeltaTime, EventReference);
	
#if WITH_EDITORONLY_DATA
	if (MeshComp != nullptr)
	{
		auto* MaterialInstancesPtr = OverrideMaterialInstances.Find(MeshComp->GetOwner());
		if (MaterialInstancesPtr != nullptr && MaterialInstancesPtr->Num() > 0)
		{
			float AnimTime = EventReference.GetCurrentAnimationTime();
			if (auto* AnimNotify = EventReference.GetNotify())
			{
				AnimTime -= AnimNotify->GetTriggerTime();
			}
		
			for (auto OverrideMaterialInstance : *MaterialInstancesPtr)
			{
				if (OverrideMaterialInstance.IsValid())
				{
					for (const auto& ScalarParamPair : FacialMaterialParams)
					{
						const FName& ParamName = ScalarParamPair.Key;
						const auto& ParamInfo = ScalarParamPair.Value;
						if (ParamInfo.ParamType == EKGFacialMaterialParamType::Curve)
						{
							const FRuntimeFloatCurve& FloatCurve = ParamInfo.RuntimeFloatCurve;
							const float ParamValue = FloatCurve.GetRichCurveConst()->Eval(AnimTime);
							OverrideMaterialInstance->SetScalarParameterValue(ParamName, ParamValue);	
						}
					}
				}
			}		
		}	
	}
#endif
}

void UAnimNotify_C7ChangeMaterialTexture::HandleNotifyEndEditorPreview(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
#if WITH_EDITORONLY_DATA
	if (!MeshComp)
	{
		return;
	}
	
	AActor* OwnerActor = MeshComp->GetOwner();
	if (!IsValid(OwnerActor))
	{
		return;
	}
	
	auto* MaterialInstancesPtr = OverrideMaterialInstances.Find(OwnerActor);
	if (MaterialInstancesPtr == nullptr)
	{
		return;
	}
	
	for (auto OverrideMaterialInstance : *MaterialInstancesPtr)
	{
		if (OverrideMaterialInstance.IsValid())
		{
			if (!TextureParameterNameA.IsNone())
			{
				UE_LOG(LogKGMaterial, Log, TEXT("UAnimNotify_C7ChangeMaterialTexture::HandleNotifyEndEditorPreview: Remove Texture Param %s %s %s %s %s"), 
					Animation ? *Animation->GetPathName() : TEXT("NULL"),
					*GetNameSafe(OwnerActor),
					*MeshComp->GetName(),
					*OverrideMaterialInstance->GetName(),
					*TextureParameterNameA.ToString());
				OverrideMaterialInstance->RemoveScalarParameter(TextureParameterNameA);
			}
			
			for (const auto& ScalarParamPair : FacialMaterialParams)
			{
				const FName& ParamName = ScalarParamPair.Key;
				UE_LOG(LogKGMaterial, Log, TEXT("UAnimNotify_C7ChangeMaterialTexture::HandleNotifyEndEditorPreview: Remove Scalar Param %s %s %s %s %s"), 
					Animation ? *Animation->GetPathName() : TEXT("NULL"),
					*GetNameSafe(OwnerActor),
					*MeshComp->GetName(),
					*OverrideMaterialInstance->GetName(), 
					*ParamName.ToString());
				OverrideMaterialInstance->RemoveScalarParameter(ParamName);	
			}
		}
	}
	OverrideMaterialInstances.Remove(OwnerActor);
#endif
}
#endif

void UAnimNotify_C7ChangeMaterialTexture::SetChangeMaterialTextureParams(UTexture* InNewTextureA, UTexture* InNewTextureB, bool bInFindWithOutTag, EAvatarBodyPartType InComponentTag, const FName& InSlotName, const FName& InTextureParameterNameA, const FName& InTextureParameterNameB, const FName& InScalarParameterName, float InAlpha, float InFadeInTime, float InFadeOutTime)
{
	NewTextureA = InNewTextureA;
	bFindWithOutTag = bInFindWithOutTag;
	ComponentTag = InComponentTag;
	SlotName = InSlotName;
	TextureParameterNameA = InTextureParameterNameA;
}
