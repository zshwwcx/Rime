#include "3C/Animation/AnimNotify/AnimNotifyState_C7HideMesh.h"

#include "Misc/KGPlatformUtils.h"
#include "Animation/AnimSequenceBase.h"
#include "Components/SkeletalMeshComponent.h"
#include "Logging/MessageLog.h"
#include "3C/Material/KGMaterialManager.h"

void UAnimNotifyState_C7HideMesh::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7HideMesh::NotifyBegin");
	
	Super::NotifyBegin(MeshComp, Animation, TotalDuration, EventReference);

	if (!IsValid(MeshComp))
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UAnimNotifyState_C7HideMesh::NotifyBegin: Invalid MeshComp, Animation:%s"),
			Animation ? *Animation->GetPathName() : TEXT("nullptr"));
		return;
	}

	if (KGPlatformUtils::IsInLevelPreviewWorld(MeshComp))
	{
		return;
	}
	
	UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(MeshComp);
	if (!IsValid(MaterialManager))
	{
		// 暂不支持动画编辑器预览
		return;
	}
	
	AActor* OwnerActor = MeshComp->GetOwner();
	if (!IsValid(OwnerActor))
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UAnimNotifyState_C7HideMesh::NotifyBegin: Invalid OwnerActor, MeshComp:%s, Animation:%s"),
			*MeshComp->GetPathName(), Animation ? *Animation->GetPathName() : TEXT("nullptr"));
		return;
	}

	if (FMath::IsNearlyZero(TargetAlpha))
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UAnimNotifyState_C7HideMesh::NotifyBegin: Invalid target alpha, Animation:%s"),
			Animation ? *Animation->GetPathName() : TEXT("nullptr"));
		return;
	}

	FKGChangeMaterialParamRequest Request;
	Request.OwnerActor = OwnerActor;
	Request.EffectType = EKGMaterialEffectType::Dissolve;
	float TotalLifeTimeSeconds;
	if (LifeTimeMode == EKGHideMeshLifeTimeMode::FixedTime)
	{
		TotalLifeTimeSeconds = FadeInTime + Duration + FadeOutTime;
	}
	else
	{
		TotalLifeTimeSeconds = TotalDuration;
	}
	Request.TotalLifeTimeMs = TotalLifeTimeSeconds * 1000.0f;

	if (FadeInTime + FadeOutTime > TotalLifeTimeSeconds)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UAnimNotifyState_C7HideMesh::NotifyBegin: FadeInTime + FadeOutTime > TotalLifeTimeSeconds, Animation:%s"),
			Animation ? *Animation->GetPathName() : TEXT("nullptr"));
		return;
	}
	
	const auto& DitherAlphaParamName = MaterialManager->GetCharacterDitherAlphaParamName();
	auto& Params = Request.LinearBlendParams.Add(DitherAlphaParamName);
	Params.StartVal = 0.0f;
	Params.EndVal = TargetAlpha;
	Params.BlendInTime = FadeInTime;
	Params.BlendOutTime = FadeOutTime;
	Params.Duration = TotalLifeTimeSeconds;
	
	const auto ReqID = MaterialManager->ChangeMaterialParam(Request);
	if (LifeTimeMode == EKGHideMeshLifeTimeMode::BindState)
	{
		ReqIDsMapping.Add(TWeakObjectPtr(MeshComp), ReqID);
	}
}

void UAnimNotifyState_C7HideMesh::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7HideMesh::NotifyEnd");
	
	if (IsValid(MeshComp))
	{
		if (KGPlatformUtils::IsInLevelPreviewWorld(MeshComp))
		{
			return;
		}
		
		auto MeshCompPtr = TWeakObjectPtr(MeshComp);
		auto* ReqIDPtr = ReqIDsMapping.Find(MeshCompPtr);
		if (ReqIDPtr != nullptr)
		{
			UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(MeshComp);
			if (IsValid(MaterialManager))
			{
				MaterialManager->RevertMaterialParam(*ReqIDPtr);
			}
			else
			{
				UE_LOG(LogKGMaterial, Error, TEXT("UAnimNotifyState_C7HideMesh::NotifyEnd: Invalid MaterialManager, MeshComp:%s, Animation:%s"),
					*MeshComp->GetPathName(), Animation ? *Animation->GetPathName() : TEXT("nullptr"));
			}
			ReqIDsMapping.Remove(MeshCompPtr);
		}
	}
	else
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UAnimNotifyState_C7HideMesh::NotifyEnd: Invalid MeshComp, Animation:%s"),
			Animation ? *Animation->GetPathName() : TEXT("nullptr"));
	}
	
	Super::NotifyEnd(MeshComp, Animation, EventReference);
}

#if WITH_EDITOR
void UAnimNotifyState_C7HideMesh::ValidateAssociatedAssets()
{
	if (UAnimSequenceBase* AnimSeq = GetTypedOuter<UAnimSequenceBase>())
	{
		float AnimNotifyStateDuration = -1.0f;
		for (const auto& Notify : AnimSeq->Notifies)
		{
			if (Notify.NotifyStateClass == this)
			{
				AnimNotifyStateDuration = Notify.GetDuration();
			}
		}

		if (AnimNotifyStateDuration >= 0.0f && LifeTimeMode == EKGHideMeshLifeTimeMode::BindState)
		{
			if (FadeInTime + FadeOutTime > AnimNotifyStateDuration)
			{
				FMessageLog AssetCheckLog("AssetCheck");

				const FText MessageLooping = FText::Format(
					NSLOCTEXT("AnimNotify", "HideMeshBlendTimeInvalid", "BindState AnimNotifyState_HideMesh in {0} found FadeInTime{1} + FadeOutTime{2} > AnimNotifyStateDuration{3}."),
					FText::AsCultureInvariant(AnimSeq->GetPathName()), FadeInTime, FadeOutTime, AnimNotifyStateDuration);
				AssetCheckLog.Warning()
					->AddToken(FTextToken::Create(MessageLooping));

				if (GIsEditor)
				{
					AssetCheckLog.Notify(MessageLooping, EMessageSeverity::Warning, /*bForce=*/ true);
				}
			}
		}
	}
}
#endif
