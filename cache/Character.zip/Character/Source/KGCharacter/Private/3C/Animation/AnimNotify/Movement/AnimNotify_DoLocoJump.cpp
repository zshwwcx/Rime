// Copyright Epic Games, Inc. All Rights Reserved.

// #pragma once

#include "3C/Animation/AnimNotify/Movement/AnimNotify_DoLocoJump.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Movement/RoleMovementComponent.h"



UAnimNotify_DoLocoJump::UAnimNotify_DoLocoJump(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
#if WITH_EDITORONLY_DATA
	bShouldFireInEditor = false;
#endif // WITH_EDITORONLY_DATA
}

void UAnimNotify_DoLocoJump::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotify_DoLocoJump::Notify");
	
	if (ABaseCharacter* Character = Cast<ABaseCharacter>(MeshComp->GetOwner()))
	{
		if (URoleMovementComponent* RoleMoveComp = Cast<URoleMovementComponent>(Character->GetMovementComponent()))
		{
			URoleMovementComponent* MovementControlViewProxy = GetMovementAuthorityControlRMC(RoleMoveComp);
			// 脚本显式开启LocoControl，这个机制才允许生效
  			if (MovementControlViewProxy->GetEnableLocoContol())
			{
				if (bUseDefaultJumpZVelocity)
				{
					MovementControlViewProxy->DoLocoJump();
				}
				else
				{
					float OldJumpZVelocity = MovementControlViewProxy->JumpZVelocity;
					MovementControlViewProxy->SetJumpZVelocity(OverrideJumpZVelocity);
					MovementControlViewProxy->DoLocoJump();
					MovementControlViewProxy->SetJumpZVelocity(OldJumpZVelocity);
				}
			}
		}
	}
}
#if WITH_EDITOR
void UAnimNotify_DoLocoJump::OnAnimNotifyCreatedInEditor(FAnimNotifyEvent& ContainingAnimNotifyEvent)
{
	ContainingAnimNotifyEvent.TriggerWeightThreshold = 1.0f;

	Super::OnAnimNotifyCreatedInEditor(ContainingAnimNotifyEvent);
}
#endif
