/**
 * Auth :   liubo
 * Date :   2026-02-07 15:21
 * Comment: 实验功能，有很多临时代码，不要正式使用
 */
#include "3C/Animation/AIFaceAnimInstance.h"

#include "3C/Animation/AnimationGraphNode/AnimNode_AIBodyPlayer.h"
#include "3C/Animation/AnimationGraphNode/AnimNode_AIFacePlayer.h"

void FLerpValue::Reset(float InV, float InTime)
{
	bEnable = true;
	TotalTime = InTime;
	if (TotalTime > 0)
	{
		Speed = (InV - V) / TotalTime;
	}
	else
	{
		Speed = 0;
		V = InV;
	}
	PendingV = InV;
	Time = 0;
}
void FLerpValue::Tick(float DeltaTime)
{
	Time += DeltaTime;
	if (Time >= TotalTime)
	{
		V = PendingV;
	}
	else
	{
		// lerp过去
		V += Speed * DeltaTime;
	}
}


UAIFaceAnimInstance::UAIFaceAnimInstance(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}
void UAIFaceAnimInstance::PreUpdateAnimation(float DeltaSeconds)
{
	UAnimInstance::PreUpdateAnimation(DeltaSeconds);

	if (PengingFaceAnimWeight.IsEnable())
	{
		PengingFaceAnimWeight.Tick(DeltaSeconds);
		FaceAnimWeight = PengingFaceAnimWeight.Get();
	}
}

void UAIFaceAnimInstance::NotifyBodyAnimAction(int N, bool bOnStart)
{

}

void UAIFaceAnimInstance::SetEnableFaceAnim(bool b)
{
	if (b == bFaceAnim)
	{
		return;
	}
	bFaceAnim = b;
	if (bFaceAnim)
	{
		PengingFaceAnimWeight.Reset(1, FaceAnimLerpTime);
	}
	else
	{
		PengingFaceAnimWeight.Reset(0, FaceAnimLerpTime);
	}
}

void UAIFaceAnimInstance::SetWebSequenceAsset(const FCustomAnimationData& InAnimationData, float StartTime)
{
	FAnimInstanceProxy& Proxy = GetProxyOnAnyThread<FAnimInstanceProxy>();

	if (!Proxy.GetAnimClassInterface())
	{
#if !UE_BUILD_SHIPPING
		UE_LOG(LogTemp, Warning, TEXT("UBaseAnimInstance::SetWebSequenceAsset  Invalid Animation Proxy"));
#endif
		return;
	}
	const TArray<FStructProperty*>& AnimNodeProperties = Proxy.GetAnimClassInterface()->GetAnimNodeProperties();

	// FAnimNode_AIFacePlayer
	for (auto E : AnimNodeProperties)
	{
		FStructProperty* MachineInstanceProperty = E;
		if (!MachineInstanceProperty->Struct->IsChildOf(FAnimNode_AIFacePlayer::StaticStruct()))
		{
			continue;
		}
		FAnimNode_AIFacePlayer* Player = MachineInstanceProperty->ContainerPtrToValuePtr<FAnimNode_AIFacePlayer>(Proxy.GetAnimInstanceObject());
		if (!Player)
		{
			continue;
		}

		{
			{
				Player->AnimationData = InAnimationData;
				Player->PlayTime = StartTime;
			}
		}
		Player->IsPlaying = InAnimationData.Duration > 0 && InAnimationData.BoneTracks.Num() > 0;
		// debug用
		Player->Loop = false;//Player->IsPlaying;
		Player->SetData();
	}
}

void UAIFaceAnimInstance::BodyAnimBlendChange(TObjectPtr<UAnimSequence> NewAnim)
{
	if(NewAnim == nullptr)
	{
		BodyAnimBlend_Index = -1; // 播放idle	
		return;
	}
	
	auto BodyAnimBlend_Array = GetNodes<FAnimNode_AIBodyPlayer>();
	BodyAnimBlend_Array.RemoveAll([](FAnimNode_AIBodyPlayer* Player)
	{
		static FName BodyBlend("BodyBlend");
		return !Player || Player->Tag != BodyBlend;
	});
	if(BodyAnimBlend_Array.Num() == 0)
	{
		return;
	}

	auto OldIdx = BodyAnimBlend_Index; 
	OldIdx++; // 循环播放array中的元素。
	OldIdx %= BodyAnimBlend_Array.Num();
	BodyAnimBlend_Array[OldIdx]->ChangeAnim(NewAnim);
	
	BodyAnimBlend_Index = OldIdx; // todo，验证是否能同步到动画线程中。
}
