#include "3C/Animation/CarrierAnimInstance.h"

#include "3C/Character/BaseCharacter.h"
#include "Misc/MathFormula.h"
#include "Components/CapsuleComponent.h"
#include "Kismet/KismetMathLibrary.h"

DEFINE_LOG_CATEGORY_STATIC(LogUCarrierAnimInstance, Log, All);

UCarrierAnimInstance::UCarrierAnimInstance(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer) {
}


void UCarrierAnimInstance::NativeInitializeAnimation()
{
	Super::NativeInitializeAnimation();

	TraceArr.Add(UEngineTypes::ConvertToObjectType(BlockChannel));
}

void UCarrierAnimInstance::NativeUpdateAnimation(float DeltaSeconds)
{
	Super::NativeUpdateAnimation(DeltaSeconds);

	if (bNeedCalculateMountPos)
	{
		CalculateMountPosture(DeltaSeconds);	
	}
	ApplyMountPosture();
}

void UCarrierAnimInstance::SetBikeOffset(float InHeadOffset, float InSeatOffset)
{
	BikeHeadOffset = InHeadOffset;
	BikeSeatOffset = InSeatOffset;

	EC7BoneModificationMode Ignore = EC7BoneModificationMode::BMM_Ignore;
	EC7BoneModificationMode Additive = EC7BoneModificationMode::BMM_Additive;
	UpdateModifyBoneAutoAdd(MountIKConfig.Bike_Handle, Additive, Ignore, Ignore, EBoneControlSpace::BCS_BoneSpace, BikeHeadOffset, 0, 0,
	0, 0, 0, 1, 1, 1, NAME_None, 0, 1);
	UpdateModifyBoneAutoAdd(MountIKConfig.Bike_Seat, Additive, Ignore, Ignore, EBoneControlSpace::BCS_BoneSpace, BikeSeatOffset, 0, 0,
		0, 0, 0, 1, 1, 1, NAME_None, 0, 1);
}

void UCarrierAnimInstance::CalculateMountPosture(float DeltaTime)
{
	switch (MountIKType)
	{
	case EMountIKType::None:
		break;
	case EMountIKType::BikeIK:
		CalculateRideBikePosture(DeltaTime);
		break;
	case EMountIKType::CommonVehicleIK:
		CalculateDriveCarPosture(DeltaTime);
		break;
	default:
		break;
	}
}

void UCarrierAnimInstance::ApplyMountPosture()
{
	switch (MountIKType)
	{
	case EMountIKType::None:
		break;
	case EMountIKType::BikeIK:
		ApplyBikePosture();
		break;
	case EMountIKType::CommonVehicleIK:
		ApplyFourWheelCarPosture();
		break;
	default:
		break;
	}
}

void UCarrierAnimInstance::ApplyBikePosture()
{
	EC7BoneModificationMode Ignore = EC7BoneModificationMode::BMM_Ignore;
	EC7BoneModificationMode Additive = EC7BoneModificationMode::BMM_Additive;
	
	UpdateModifyBoneAutoAdd(MountIKConfig.Bike_Wheel_F, Ignore, Additive, Ignore, EBoneControlSpace::BCS_BoneSpace, 0, 0, 0,
		0, 0, AttachmentInfo.MountFrontMoveAngle, 1, 1, 1, NAME_None, 0, 1);
	UpdateModifyBoneAutoAdd(MountIKConfig.Bike_Wheel_B, Ignore, Additive, Ignore, EBoneControlSpace::BCS_BoneSpace, 0, 0, 0,
		0, 0, AttachmentInfo.MountEndMoveAngle, 1, 1, 1, NAME_None, 0, 1);
	UpdateModifyBoneAutoAdd(MountIKConfig.Bike_Root, Additive, Additive, Ignore, EBoneControlSpace::BCS_ComponentSpace, 0, 0, MountRootOffset,
		0, 0, MountPitch, 1, 1, 1, NAME_None, 0, 1);
}

void UCarrierAnimInstance::ApplyFourWheelCarPosture()
{
	EC7BoneModificationMode Ignore = EC7BoneModificationMode::BMM_Ignore;
	EC7BoneModificationMode Additive = EC7BoneModificationMode::BMM_Additive;

	// 前轮旋转
	for (int i=0; i<FrontScrollWheelArray.Num(); i++)
	{
		float Pitch = FrontScrollWheelArray[i].Axis.X * AttachmentInfo.MountFrontMoveAngle;
		float Yaw = FrontScrollWheelArray[i].Axis.Y * AttachmentInfo.MountFrontMoveAngle;
		float Roll = FrontScrollWheelArray[i].Axis.Z * AttachmentInfo.MountFrontMoveAngle;
		
		UpdateModifyBoneAutoAdd(FrontScrollWheelArray[i].IKBone.BoneName, Ignore, Additive, Ignore, EBoneControlSpace::BCS_BoneSpace, 0, 0, 0,
			Pitch, Yaw, Roll, 1, 1, 1, NAME_None, 0, 1);
	}

	// 后轮旋转
	for (int i=0; i<BackScrollWheelArray.Num(); i++)
	{
		float Pitch = BackScrollWheelArray[i].Axis.X * AttachmentInfo.MountEndMoveAngle;
		float Yaw = BackScrollWheelArray[i].Axis.Y * AttachmentInfo.MountEndMoveAngle;
		float Roll = BackScrollWheelArray[i].Axis.Z * AttachmentInfo.MountEndMoveAngle;
		
		UpdateModifyBoneAutoAdd(BackScrollWheelArray[i].IKBone.BoneName, Ignore, Additive, Ignore, EBoneControlSpace::BCS_BoneSpace, 0, 0, 0,
			Pitch, Yaw, Roll, 1, 1, 1, NAME_None, 0, 1);
	}

	// 轮胎转向列表
	for (int i=0; i<RotateWheelArray.Num(); i++)
	{
		float Pitch = RotateWheelArray[i].Axis.X * AttachmentInfo.RealMountDirYawToActorYawDelta;
		float Yaw = RotateWheelArray[i].Axis.Y * AttachmentInfo.RealMountDirYawToActorYawDelta;
		float Roll = RotateWheelArray[i].Axis.Z * AttachmentInfo.RealMountDirYawToActorYawDelta;
		
		UpdateModifyBoneAutoAdd(RotateWheelArray[i].IKBone.BoneName, Ignore, Additive, Ignore, EBoneControlSpace::BCS_BoneSpace, 0, 0, 0,
			Pitch, Yaw, Roll, 1, 1, 1, NAME_None, 0, 1);
	}
	
	// 俯仰姿态
	UpdateModifyBoneAutoAdd(RootBoneName, Ignore, Additive, Ignore, EBoneControlSpace::BCS_ComponentSpace, 0, 0, 0,
		MountRoll, 0, MountPitch, 1, 1, 1, NAME_None, 0, 1);
}

void UCarrierAnimInstance::CalculateRideBikePosture(float DeltaTime)
{
	const ABaseCharacter* OwnerPtr = Cast<ABaseCharacter>(GetOwningActor());
	if (!OwnerPtr) return;

	if (BikeInfo.FrontWheelName.IsNone() || BikeInfo.RearWheelName.IsNone()) return;

	if (bNeedInitData)
	{
		InitData();
	}
	
	const USkeletalMeshComponent* MeshPtr = GetSkelMeshComponent();
	if (!MeshPtr) return;
	
	const FVector FrontWheelLoc = MeshPtr->GetBoneLocation(BikeInfo.FrontWheelName);
	const FVector RearWheelLoc = MeshPtr->GetBoneLocation(BikeInfo.RearWheelName);
	const float RiderPitch = MountPitch;
	const float BikePitch = UKismetMathLibrary::FindLookAtRotation(FrontWheelLoc, RearWheelLoc).Pitch;
	
 	const float FrontWheelRadius = BikeInfo.MountFrontRadius;
	const float RearWheelRadius = BikeInfo.MountEndRadius;
	const float FrontLength = BikeInfo.MountFrontLength;
	const float RearLength = BikeInfo.MountEndLength;
	const float VehicleLength = FrontLength + RearLength + FrontWheelRadius + RearWheelRadius;
	const float Radius = OwnerPtr->GetCapsuleComponent()->GetScaledCapsuleRadius();
	
	const FVector ActorLocation = OwnerPtr->GetActorLocation();
	const FVector FrontTracLoc = ActorLocation + OwnerPtr->GetActorForwardVector() * Radius;
	const FVector RearTraceLoc = ActorLocation - OwnerPtr->GetActorForwardVector() * Radius;
	
	TArray<AActor*> IgnoreActor;
	// 计算载具俯仰角
	FHitResult FrontOutHit;
	FHitResult RearOutHit;
	
	bool bFrontHit = UKismetSystemLibrary::LineTraceSingleForObjects(OwnerPtr, FrontTracLoc, FrontTracLoc + FVector::DownVector * VehicleLength,
		TraceArr, false, IgnoreActor, DebugTrace, FrontOutHit, true);
	bool bRearHit = UKismetSystemLibrary::LineTraceSingleForObjects(OwnerPtr, RearTraceLoc, RearTraceLoc + FVector::DownVector * VehicleLength,
		TraceArr, false, IgnoreActor, DebugTrace, RearOutHit, true);
	
	if (!bAirPitchAdjust)
	{
		bAirPitchAdjust = !bFrontHit && !bRearHit;
	}

	bExtraAdjust = false;
	if (bAirPitchAdjust)
	{
		// 跳跃时根据自行车额外Pitch进行反向补偿
		bFrontHit = UKismetSystemLibrary::LineTraceSingleForObjects(OwnerPtr, FrontWheelLoc, FrontWheelLoc + FVector::DownVector * FrontWheelRadius * 1.2,
			TraceArr, false, IgnoreActor, DebugTrace, FrontOutHit, true);
		bRearHit = UKismetSystemLibrary::LineTraceSingleForObjects(OwnerPtr, RearWheelLoc, RearWheelLoc + FVector::DownVector * RearWheelRadius * 1.2,
			TraceArr, false, IgnoreActor, DebugTrace, RearOutHit, true);

		bool bFrontHitFirst = bFrontHit && !bRearHit;
		bool bRearHitFirst = !bFrontHit && bRearHit;

		if (bFrontHitFirst)
		{
			bAirPitchAdjust = false;
		}
		else if (bRearHitFirst && !bExtraAdjust)
		{
			bExtraAdjust = true;
		}
		
		if (bExtraAdjust)
		{
			float OldPitchExtraCorrect = PitchExtraCorrect;
			PitchExtraCorrect = MathFormula::DecayValue(PitchExtraCorrect, BikePitch - RiderPitch, BikeInfo.MountPitchHalfTime, DeltaTime);
			MountPitch = MountPitch - PitchExtraCorrect + OldPitchExtraCorrect;
		}
		else
		{
			float NewPitch = MathFormula::DecayValue(MountPitch, 0.f, BikeInfo.MountPitchHalfTime, DeltaTime);
			float NewRootOffset = MathFormula::DecayValue(MountRootOffset, 0.f, BikeInfo.MountRootOffsetHalfTime, DeltaTime);
			MountPitch = NewPitch;
			MountRootOffset = NewRootOffset;
		}
		
		if (FMath::Abs(RiderPitch - BikePitch) < 2 * InitDeltaPitch)
		{
			bAirPitchAdjust = false;
		}
	}
	else if (bFrontHit && bRearHit) 
	{
		bAirPitchAdjust = false;
		PitchExtraCorrect = 0.f;
		
		float OldPitch = MountPitch;
		float OldRootOffset = MountRootOffset;
		
		DestPitch = UKismetMathLibrary::FindLookAtRotation(FrontOutHit.ImpactPoint, RearOutHit.ImpactPoint).Pitch;
		MountPitch = MathFormula::DecayValue(OldPitch, DestPitch, BikeInfo.MountPitchHalfTime, DeltaTime);

		// 计算载具Root调整值
		const FTransform RootTransform = OwnerPtr->GetMesh()->GetBoneTransform(RootBoneName);
		const FVector MeshUpVector =  RootTransform.GetUnitAxis( EAxis::Z );
		
		bFrontHit = UKismetSystemLibrary::LineTraceSingleForObjects(OwnerPtr, FrontWheelLoc, FrontWheelLoc - MeshUpVector * VehicleLength,
			TraceArr, false, IgnoreActor, DebugTrace, FrontOutHit, true);
		bRearHit = UKismetSystemLibrary::LineTraceSingleForObjects(OwnerPtr, RearWheelLoc, RearWheelLoc - MeshUpVector * VehicleLength,
			TraceArr, false, IgnoreActor, DebugTrace, RearOutHit, true);
			
		// 计算载具Root调整值
		float FNeedUpDis = 0.f;
		float RNeedUpDis = 0.f;
		if (FrontWheelRadius > FrontOutHit.Distance)
		{
			FNeedUpDis = FrontWheelRadius - FrontOutHit.Distance;
		}
		else
		{
			FNeedUpDis = OldRootOffset - (FrontOutHit.Distance - FrontWheelRadius);
		}

		if (RearWheelRadius > RearOutHit.Distance)
		{
			RNeedUpDis = RearWheelRadius - RearOutHit.Distance;
		}
		else
		{
			RNeedUpDis = OldRootOffset - (RearOutHit.Distance - RearWheelRadius);
		}

		DestRootOffset = FMath::Max(FNeedUpDis, RNeedUpDis);
		const float TempRootOffset = FMath::Min(FMath::Abs(DestRootOffset), FMath::Abs(MountPitch));
		DestRootOffset = DestRootOffset > 0 ? TempRootOffset : -TempRootOffset;
		MountRootOffset = MathFormula::DecayValue(OldRootOffset, DestRootOffset, BikeInfo.MountRootOffsetHalfTime, DeltaTime);
	}
}

void UCarrierAnimInstance::CalculateDriveCarPosture(float DeltaTime)
{
	const ABaseCharacter* OwnerPtr = Cast<ABaseCharacter>(GetOwningActor());
	if (!OwnerPtr) return;

	const USkeletalMeshComponent* MeshPtr = GetSkelMeshComponent();
	if (!MeshPtr) return;
	
	const FVector ActorLocation = OwnerPtr->GetActorLocation();
	if(!LastMountLoc.Equals(ActorLocation, 1))
	{
		// 数据初始化
		LastMountLoc = ActorLocation;
		DestPitch = 0.f;
		DestRoll = 0.f;
		
		const float Radius = OwnerPtr->GetCapsuleComponent()->GetScaledCapsuleRadius();	
		const FVector LeftTracLoc = ActorLocation - OwnerPtr->GetActorRightVector() * Radius;
		const FVector RightTraceLoc = ActorLocation + OwnerPtr->GetActorRightVector() * Radius;
		
		// 射线检测
		TArray<AActor*> IgnoreActor;
		TArray<FHitResult> FrontHitResultArray;
		for (int i=0; i<FrontWheelArray.Num(); i++)
		{
			FHitResult HitResult;
			const FVector WheelLocCache =  MeshPtr->GetBoneLocation(FrontWheelArray[i].IKBone.BoneName);
			UKismetSystemLibrary::SphereTraceSingleForObjects(OwnerPtr, WheelLocCache, WheelLocCache + FVector::DownVector * TraceLength, FrontWheelArray[i].SphereTraceRadius,
					TraceArr, false, IgnoreActor, DebugTrace, HitResult, true);
			FrontHitResultArray.Add(HitResult);
		}

		TArray<FHitResult> BackHitResultArray;
		for (int i=0; i<BackWheelArray.Num(); i++)
		{
			FHitResult HitResult;
			const FVector WheelLocCache =  MeshPtr->GetBoneLocation(BackWheelArray[i].IKBone.BoneName);
			UKismetSystemLibrary::SphereTraceSingleForObjects(OwnerPtr, WheelLocCache, WheelLocCache + FVector::DownVector * TraceLength, FrontWheelArray[i].SphereTraceRadius,
					TraceArr, false, IgnoreActor, DebugTrace, HitResult, true);
			BackHitResultArray.Add(HitResult);
		}
		
		// Pitch 计算
		if (bApplyPitchPosture)
		{
			// 轮胎检测结果
			// 如果配置了前后轮胎，先用前后轮胎做Pitch计算
			if (FrontHitResultArray.Num() > 0 && BackHitResultArray.Num() > 0)
			{
				if (FrontHitResultArray[0].bBlockingHit && BackHitResultArray[0].bBlockingHit)
				{
					float TempDestPitch = UKismetMathLibrary::FindLookAtRotation(FrontHitResultArray[0].ImpactPoint, BackHitResultArray[0].ImpactPoint).Pitch;
					if (FMath::Abs(TempDestPitch) < ApplyMaxPitch)
					{
						DestPitch = TempDestPitch;
					}
				}
				if (FrontHitResultArray.Num() > 1 || BackHitResultArray.Num() > 1)
				{
					FHitResult& TempFront = FrontHitResultArray.Num() > 1 ? FrontHitResultArray[1] : FrontHitResultArray[0];
					FHitResult& TempBack = BackHitResultArray.Num() > 1 ? BackHitResultArray[1] : BackHitResultArray[0];
					if (TempFront.bBlockingHit && TempBack.bBlockingHit)
					{
						float TempDestPitch = UKismetMathLibrary::FindLookAtRotation(TempFront.ImpactPoint, TempBack.ImpactPoint).Pitch;
						if (FMath::Abs(TempDestPitch) > FMath::Abs(DestPitch) && FMath::Abs(TempDestPitch) < ApplyMaxPitch)
						{
							DestPitch = TempDestPitch;
						}
					}
				}
			}

			// 胶囊体周围检测
			const FVector FrontTracLoc = ActorLocation + OwnerPtr->GetActorForwardVector() * Radius;
			const FVector RearTraceLoc = ActorLocation - OwnerPtr->GetActorForwardVector() * Radius;

			FHitResult FrontOutHit, RearOutHit;
			bool bFrontHit = UKismetSystemLibrary::LineTraceSingleForObjects(OwnerPtr, FrontTracLoc, FrontTracLoc + FVector::DownVector * TraceLength,
				TraceArr, false, IgnoreActor, DebugTrace, FrontOutHit, true);
			bool bRearHit = UKismetSystemLibrary::LineTraceSingleForObjects(OwnerPtr, RearTraceLoc, RearTraceLoc + FVector::DownVector * TraceLength,
				TraceArr, false, IgnoreActor, DebugTrace, RearOutHit, true);
			
			float CapsuleCheckDestPitch = bFrontHit && bRearHit ? UKismetMathLibrary::FindLookAtRotation(FrontOutHit.ImpactPoint, RearOutHit.ImpactPoint).Pitch :  0.f;
			if (FMath::Abs(CapsuleCheckDestPitch - DestPitch) > PostureAngleCheckLimit && FMath::Abs(CapsuleCheckDestPitch) < ApplyMaxPitch)
			{
				DestPitch = CapsuleCheckDestPitch;
			}
		}

		// Roll 计算
		if (bApplyRollPosture)
		{
			bool bNeedCalculateFront = true;
			if (BackHitResultArray.Num() > 1)
			{
				FHitResult& TempLeft = BackHitResultArray[0];
				FHitResult& TempRight = BackHitResultArray[1];
				if (TempLeft.bBlockingHit && TempRight.bBlockingHit)
				{
					float TempDestRoll = UKismetMathLibrary::FindLookAtRotation(TempRight.ImpactPoint, TempLeft.ImpactPoint).Pitch;
					if (FMath::Abs(TempDestRoll) <= ApplyMaxRoll)
					{
						DestRoll = TempDestRoll;
						bNeedCalculateFront = false;
					}
				}
			}
			
			if (FrontHitResultArray.Num() > 1 && bNeedCalculateFront)
			{
				FHitResult& TempLeft = FrontHitResultArray[0];
				FHitResult& TempRight = FrontHitResultArray[1];
				if (TempLeft.bBlockingHit && TempRight.bBlockingHit)
				{
					float TempDestRoll = UKismetMathLibrary::FindLookAtRotation(TempRight.ImpactPoint, TempLeft.ImpactPoint).Pitch;
					if (FMath::Abs(TempDestRoll) <= ApplyMaxRoll)
					{
						DestRoll = TempDestRoll;
					}
				}
			}

			FHitResult LeftOutHit, RightOutHit;
			bool bLeftHit = UKismetSystemLibrary::LineTraceSingleForObjects(OwnerPtr, LeftTracLoc, LeftTracLoc + FVector::DownVector * TraceLength,
				TraceArr, false, IgnoreActor, DebugTrace, LeftOutHit, true);
			bool bRightHit = UKismetSystemLibrary::LineTraceSingleForObjects(OwnerPtr, RightTraceLoc, RightTraceLoc + FVector::DownVector * TraceLength,
				TraceArr, false, IgnoreActor, DebugTrace, RightOutHit, true);
		
			float CapsuleCheckDestRoll = bLeftHit && bRightHit ? UKismetMathLibrary::FindLookAtRotation(RightOutHit.ImpactPoint, LeftOutHit.ImpactPoint).Pitch : 0.f;
			if (FMath::Abs(CapsuleCheckDestRoll - DestRoll) > PostureAngleCheckLimit && FMath::Abs(CapsuleCheckDestRoll) <= ApplyMaxRoll)
			{
				DestRoll = CapsuleCheckDestRoll;
			}
		}
		
		// 计算载具Root调整值
		// DestRootOffset = 0.f;
		// if (bFrontLHit && FLOutHit.Distance)
		// {
		// 	DestRootOffset = FrontWheelRadius - FVector::Distance(FLOutHit.TraceStart, FLOutHit.ImpactPoint);
		// }
		// if (bFrontRHit && FROutHit.Distance)
		// {
		// 	float TempOffset = FrontWheelRadius - FVector::Distance(FROutHit.TraceStart, FROutHit.ImpactPoint);
		// 	if (FMath::Abs(TempOffset) > DestRootOffset)
		// 	{
		// 		DestRootOffset = TempOffset;
		// 	}
		// }
		// if (bRearLHit && RLOutHit.Distance)
		// {
		// 	float TempOffset = RearWheelRadius - FVector::Distance(RLOutHit.TraceStart, RLOutHit.ImpactPoint);
		// 	if (FMath::Abs(TempOffset) > DestRootOffset)
		// 	{
		// 		DestRootOffset = TempOffset;
		// 	}
		// }
		// if (bRearRHit && RROutHit.Distance)
		// {
		// 	float TempOffset = RearWheelRadius - FVector::Distance(RROutHit.TraceStart, RROutHit.ImpactPoint);
		// 	if (FMath::Abs(TempOffset) > DestRootOffset)
		// 	{
		// 		DestRootOffset = TempOffset;
		// 	}
		// }
	}

	
	MountPitch = MathFormula::DecayValue(MountPitch, DestPitch, PitchHalfTime, DeltaTime);
	MountRoll = MathFormula::DecayValue(MountRoll, DestRoll, RollHalfTime, DeltaTime);
	// MountRootOffset = MathFormula::DecayValue(MountRootOffset, DestRootOffset, CarInfo.RootOffsetHalfTime, DeltaTime);
}

void UCarrierAnimInstance::InitData()
{
	const USkeletalMeshComponent* MeshPtr = GetSkelMeshComponent();
	if (!MeshPtr) return;
	
	const FVector FrontWheelLoc = MeshPtr->GetBoneLocation(BikeInfo.FrontWheelName);
	const FVector RearWheelLoc = MeshPtr->GetBoneLocation(BikeInfo.RearWheelName);
	const float RiderPitch = MountPitch;
	const float BikePitch = UKismetMathLibrary::FindLookAtRotation(FrontWheelLoc, RearWheelLoc).Pitch;
	
	// 初始化前后轮角度差
	InitDeltaPitch = FMath::Abs(RiderPitch - BikePitch);
	bNeedInitData = false;
}

void UCarrierAnimInstance::UpdateMountPostureParam(const float& Pitch, const float& Roll, const float& RootOffset)
{
	MountPitch = Pitch;
	MountRoll = Roll;
	MountRootOffset = RootOffset;
	bNeedCalculateMountPos = false;
}

void UCarrierAnimInstance::SetRelLocToRider(const float& DeltaX, const float& DeltaY, const float& DeltaZ)
{
	RelLocToRider = FVector(DeltaX, DeltaY, DeltaZ);
}

void UCarrierAnimInstance::InitMountBornPitch()
{
	switch (MountIKType)
	{
	case EMountIKType::BikeIK:
	case EMountIKType::CommonVehicleIK:
		CalculateRideBikePosture(0.f);
	case EMountIKType::None:
		break;
	default:
		break;
	}

	MountPitch = DestPitch;
	MountRootOffset = 0.f;
}
