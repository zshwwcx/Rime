#include "3C/Animation/AnimationGraphNode/AnimNode_ThreeLayerPostureBlend.h"
#include "Animation/AnimInstanceProxy.h"
#include "AnimEncoding.h"
#include "Animation/AnimTrace.h"
#include "Animation/AnimTypes.h"
#include "Animation/AnimData/BoneMaskFilter.h"


#define LOCTEXT_NAMESPACE "AnimNode_ThreeLayerPostureBlend"

/////////////////////////////////////////////////////
// FAnimSequencePlayerNode

#define TOLERATE_SMALL_WEIGHT  0.001f
#define ALMOST_FULL_WEIGHT  0.99f

void FAnimNode_ThreeLayerPostureBlend::GatherDebugData(FNodeDebugData& DebugData)
{
	FString DebugLine = DebugData.GetNodeName(this);
	
	DebugLine += FString::Printf(TEXT("(bAlwaysUpdateLocoPose: %s)\n"), (CurPostureParam.bAlwaysUpdateLocoPose) ? TEXT("true") : TEXT("false"));
	DebugLine += FString::Printf(TEXT("(ActionBlendTime: %.3f)"), CurPostureParam.ActionBlendTime);
	DebugLine += FString::Printf(TEXT("(PerformBlendTime: %.3f)"), CurPostureParam.PerformBlendTime);
	DebugLine += FString::Printf(TEXT("(bActionWorking: %s)\n"), (CurPostureParam.bActionWorking) ? TEXT("true") : TEXT("false"));
	DebugLine += FString::Printf(TEXT("(ActionBlendRule: %s)"), CurPostureParam.ActionBlendRule == EActionBlendRule::FullBodyOverride ? TEXT("FullBodyOverride") :
		(CurPostureParam.ActionBlendRule == EActionBlendRule::PartBodyOverride ? TEXT("PartBodyOverride") : TEXT("PartBodyOverrideOnlyWhenMoving")));
	DebugLine += FString::Printf(TEXT("(PerformBlendRule: %s)"), CurPostureParam.PerformBlendRule == EActionBlendRule::FullBodyOverride ? TEXT("FullBodyOverride") :
		(CurPostureParam.PerformBlendRule == EActionBlendRule::PartBodyOverride ? TEXT("PartBodyOverride") : TEXT("PartBodyOverrideOnlyWhenMoving")));
	DebugLine += FString::Printf(TEXT("(bLocoMoving: %s)\n"), (CurPostureParam.bLocoMoving) ? TEXT("true") : TEXT("false"));
	DebugLine += FString::Printf(TEXT("(TargetIsLocoMoving: %s)\n"), (TargetIsLocoMoving) ? TEXT("true") : TEXT("false"));
	DebugLine += FString::Printf(TEXT("(bActionMeshSpaceBlend: %s)\n"), (CurPostureParam.bActionMeshSpaceBlend) ? TEXT("true") : TEXT("false"));
	DebugLine += FString::Printf(TEXT("(ActionFilterBoneName: %s)\n"), *CurPostureParam.ActionFilterBoneName.ToString());
	DebugLine += FString::Printf(TEXT("(ActionFilterBoneDepth: %hhu)"), CurPostureParam.ActionFilterBoneDepth);
	DebugLine += FString::Printf(TEXT("(bPerformWorking: %s)\n"), (CurPostureParam.bPerformWorking) ? TEXT("true") : TEXT("false"));
	DebugLine += FString::Printf(TEXT("(PerformFilterBoneName: %s)\n"), *CurPostureParam.PerformFilterBoneName.ToString());
	DebugLine += FString::Printf(TEXT("(PerformFilterBoneDepth: %hhu)"), CurPostureParam.PerformFilterBoneDepth);
	DebugLine += FString::Printf(TEXT("(AdditiveAlpha: %.3f)"), CurPostureParam.AdditiveAlpha);

	DebugLine += FString::Printf(TEXT("(------------Runtime Member--------------)"));
	DebugLine += FString::Printf(TEXT("(ActionBlend: %.3f)  (PerformBlend: %.3f)"), ActionBlend.GetBlendedValue(), PerformBlend.GetBlendedValue());
	DebugLine += FString::Printf(TEXT("(ActionPartBodyWhenMovingBlend: %.3f)  (PerformPartBodyWhenMovingBlend: %.3f)"), ActionPartBodyWhenMovingBlend.GetBlendedValue(), PerformPartBodyWhenMovingBlend.GetBlendedValue());
	
	DebugData.AddDebugItem(DebugLine, true);

}

void FAnimNode_ThreeLayerPostureBlend::Initialize_AnyThread(const FAnimationInitializeContext& Context)
{
	CurrentActionBoneRootName = NAME_None;
	CurrentActionBoneDepth = 1;

	CurrentPerformBoneRootName = NAME_None;
	CurrentPerformBoneDepth = 1;

	TargetActionWorking = false;
	TargetPerformWorking = false;
	TargetIsLocoMoving = false;

	ActionBlend.SetValueRange(1.0f, 0.0f);
	ActionBlend.SetAlpha(1.0f);
	// (0.0f, 1.0f) when TargetIsLocoMoving is false
	ActionPartBodyWhenMovingBlend.SetValueRange(0.0f, 1.0f);
	ActionPartBodyWhenMovingBlend.SetAlpha(1.0f);


	PerformBlend.SetValueRange(1.0f, 0.0f);
	PerformBlend.SetAlpha(1.0f);
	PerformPartBodyWhenMovingBlend.SetValueRange(0.0f, 1.0f);
	PerformPartBodyWhenMovingBlend.SetAlpha(1.0f);

	LocomotionPose.Initialize(Context);
	ActionPose.Initialize(Context);
	PerformAdditivePose.Initialize(Context);

}

void FAnimNode_ThreeLayerPostureBlend::CacheBones_AnyThread(const FAnimationCacheBonesContext& Context)
{
	LocomotionPose.CacheBones(Context);
	ActionPose.CacheBones(Context);
	PerformAdditivePose.CacheBones(Context);

}

bool FAnimNode_ThreeLayerPostureBlend::EnsureBlendWeights(const FBoneContainer& RequiredBones, const USkeleton * skePtr, const ThreeLayerBlendFilterKeyStruct & keyStruct,  const FName& boneName, uint8 boneDepth, TArray<FPerBoneBlendWeight> & outWeights) {
	if (CachedBlendBoneWeights.Contains(keyStruct)) {
		outWeights = CachedBlendBoneWeights[keyStruct];
		return false;
	}
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_ThreeLayerPostureBlend::Update_AnyThread_CreateMaskWeights ");
	TArray<FPerBoneBlendWeight> outBlendWeights;
	TArray<FInputBlendPose> LayerSetup;
	LayerSetup.AddDefaulted();
	FBranchFilter fbFilter;
	fbFilter.BoneName = boneName;
	fbFilter.BlendDepth = boneDepth;
	LayerSetup[0].BranchFilters.Add(fbFilter);
	// it's a code trick for creating a arg used by BlendPosesPerBoneFilter interface
	// blend weight always from action or perform layer. They always are 0st element in the array, so its sourceIndex always is 0
	FAnimationRuntime::CreateMaskWeights(outBlendWeights, LayerSetup, skePtr);
	
	outWeights.Reset();
	const TArray<FBoneIndexType>& RequiredBoneIndices = RequiredBones.GetBoneIndicesArray();
	const int32 NumRequiredBones = RequiredBoneIndices.Num();
	outWeights.Reserve(NumRequiredBones);
	outWeights.AddZeroed(NumRequiredBones);

	for (int32 RequiredBoneIndex = 0; RequiredBoneIndex < NumRequiredBones; RequiredBoneIndex++)
	{
		const int32 SkeletonBoneIndex = RequiredBones.GetSkeletonIndex(FCompactPoseBoneIndex(RequiredBoneIndex));
		if (ensure(SkeletonBoneIndex != INDEX_NONE))
		{
			outWeights[RequiredBoneIndex] = outBlendWeights[SkeletonBoneIndex];
		}
	}

	CachedBlendBoneWeights.Add(keyStruct, outWeights);

	return true;
}


void FAnimNode_ThreeLayerPostureBlend::Update_AnyThread(const FAnimationUpdateContext& Context)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_ThreeLayerPostureBlend::Update_AnyThread");

	GetEvaluateGraphExposedInputs().Execute(Context);

	if (!Context.AnimInstanceProxy || !Context.AnimInstanceProxy->GetSkeleton()) {
		ensureMsgf(false, TEXT("unexpected null ptr  AnimInstanceProxy:%d"), Context.AnimInstanceProxy);
		return;
	}

	CurPostureParam = GET_ANIM_NODE_DATA(FThreeLayerPostureParam, ThreeLayerPostureParam);

	const bool isActionBlendComplete = ActionBlend.IsComplete();
	const bool isPerformBlendComplete = PerformBlend.IsComplete();
	const bool isBlendTransiting = !isActionBlendComplete || !isPerformBlendComplete;

	const bool isBlendWorking = CurPostureParam.bActionWorking || CurPostureParam.bPerformWorking;

	const bool isActionWorkChanged = CurPostureParam.bActionWorking != TargetActionWorking;
	const bool isPerformWorkChanged = CurPostureParam.bPerformWorking != TargetPerformWorking;
	
	const bool isActionBlendWorking = CurPostureParam.bActionWorking || !isActionBlendComplete;
	const bool isPerformBlendWorking = CurPostureParam.bPerformWorking || !isPerformBlendComplete;

	if (!isBlendWorking && !isBlendTransiting && !isActionWorkChanged && !isPerformWorkChanged) {
		TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_ThreeLayerPostureBlend::Update_AnyThread::Pose Update");
		TargetIsLocoMoving = false;
		LocomotionPose.Update(Context.FractionalWeight(1.0f));
		return;
	}

	float deltaTime = Context.GetDeltaTime();
	
	// 1. compute layer blend transiting 
	bool hasActionWorkingChanged = false;
	if (isActionWorkChanged) {
		TargetActionWorking = CurPostureParam.bActionWorking;
		hasActionWorkingChanged = true;
		ActionBlend.SetBlendTime(CurPostureParam.ActionBlendTime);
		// open blend
		if (TargetActionWorking) {
			ActionBlend.SetValueRange(0.0f, 1.0f);
		}
		else {
		// close blend
			ActionBlend.SetValueRange(1.0f, 0.0f);
		}
		
		CachedActionLayerWeight = -1.0f;

	}
	
	bool hasPerformWorkingChanged = false;
	if (isPerformWorkChanged) {
		TargetPerformWorking = CurPostureParam.bPerformWorking;
		hasPerformWorkingChanged = true;
		PerformBlend.SetBlendTime(CurPostureParam.PerformBlendTime);
		// open blend
		if (TargetPerformWorking) {
			PerformBlend.SetValueRange(0.0f, 1.0f);
		}
		else {
			// close blend
			PerformBlend.SetValueRange(1.0f, 0.0f);
		}

		CachedPerformLayerWeight = -1.0f;
	}
	
	bool hasLocoMoveChanged = CurPostureParam.bLocoMoving != TargetIsLocoMoving;
	if (hasLocoMoveChanged) {
		TargetIsLocoMoving = CurPostureParam.bLocoMoving;
	}

	if (CurPostureParam.ActionBlendRule == EActionBlendRule::PartBodyOverrideOnlyWhenMoving && isActionBlendWorking) {
		// 有可能先移动了, 然后Action被打断, 然后马上再启动action, 这里的LocoMoveChanged是false,  这样就漏刷逻辑了, 所以也要看ActionWorkChanged
		if (hasLocoMoveChanged || isActionWorkChanged) {
			ActionPartBodyWhenMovingBlend.SetBlendTime(CurPostureParam.ActionBlendTime);
			if (TargetIsLocoMoving) {
				ActionPartBodyWhenMovingBlend.SetValueRange(1.0f, 0.0f);
			}
			else {
				ActionPartBodyWhenMovingBlend.SetValueRange(0.0f, 1.0f);
			}
			
			// Initilize the part body weights directly to final blended value, when action starts to work
			if (hasActionWorkingChanged && TargetActionWorking == true) {
				ActionPartBodyWhenMovingBlend.SetAlpha(1.0f);
			}

			CachedActionPartBodyWeight = -1.0f;
		}

		ActionPartBodyWhenMovingBlend.Update(deltaTime);
	}

	if (CurPostureParam.PerformBlendRule == EActionBlendRule::PartBodyOverrideOnlyWhenMoving && isPerformBlendWorking) {
		if (hasLocoMoveChanged) {
			PerformPartBodyWhenMovingBlend.SetBlendTime(CurPostureParam.PerformBlendTime);
			if (TargetIsLocoMoving) {
				PerformPartBodyWhenMovingBlend.SetValueRange(1.0f, 0.0f);
			}
			else {
				PerformPartBodyWhenMovingBlend.SetValueRange(0.0f, 1.0f);
			}

			// Initilize the part body weights directly to final blended value, when action starts to work
			if (hasPerformWorkingChanged && TargetPerformWorking == true) {
				PerformPartBodyWhenMovingBlend.SetAlpha(1.0f);
			}

			CachedPerformPartBodyWeight = -1.0f;
		}
		PerformPartBodyWhenMovingBlend.Update(deltaTime);
	}


	ActionBlend.Update(deltaTime);
	PerformBlend.Update(deltaTime);

	
	// 2.1 try refresh Action bone weights from realtime node evaluation
	float actionBlendWeight = ActionBlend.GetBlendedValue();
	float performBlendWeight = PerformBlend.GetBlendedValue();
	
	float locomotionUpdateWeight = (1.0f - actionBlendWeight);

	if (actionBlendWeight > 0) {
		// Using weight 1.0f for locomotion when blending body part with action, and no RootMotion from action
		if (!IsActionFullBodyOverride()) {
			locomotionUpdateWeight = 1.0f ;
		}
	}

	if(CurPostureParam.bAlwaysUpdateLocoPose || locomotionUpdateWeight > TOLERATE_SMALL_WEIGHT)
	{
		TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_ThreeLayerPostureBlend::Update_AnyThread::Pose Update");
		LocomotionPose.Update(Context.FractionalWeight(locomotionUpdateWeight));
	}
	

	if (actionBlendWeight > 0.0f) {
		TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_ThreeLayerPostureBlend::Update_AnyThread::Pose Update");
		// loco and action blend from input montage source
		ActionPose.Update(Context.FractionalWeight(actionBlendWeight));
	}
	
	//  try refresh Perform bone weights from realtime node evaluation
	if (performBlendWeight > 0.0f) {
		// additive, always weight 1.0
		{
			TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_ThreeLayerPostureBlend::Update_AnyThread::Pose Update");
			PerformAdditivePose.Update(Context.FractionalWeight(performBlendWeight));
		}
		
	}

}

void FAnimNode_ThreeLayerPostureBlend::Evaluate_AnyThread(FPoseContext& Output)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_ThreeLayerPostureBlend::Evaluate_AnyThread");
	
	float actionBlendWeight = ActionBlend.GetBlendedValue();
	float performBlendWeight = PerformBlend.GetBlendedValue();
	if(actionBlendWeight < TOLERATE_SMALL_WEIGHT && performBlendWeight <= TOLERATE_SMALL_WEIGHT) {
		TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_ThreeLayerPostureBlend::Evaluate_AnyThread::Pose Evaluate");
		LocomotionPose.Evaluate(Output);
		return;
	}

	// only evaluate action
	if (IsActionFullBodyOverride() && actionBlendWeight >= ALMOST_FULL_WEIGHT && performBlendWeight <= TOLERATE_SMALL_WEIGHT) {
		TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_ThreeLayerPostureBlend::Evaluate_AnyThread::Pose Evaluate");
		ActionPose.Evaluate(Output);
		return;
	}

	// Require Bones Maybe Changed After Update, Calculate BlendWeights in Evaluate
	if (actionBlendWeight > 0.0f) {

		// only calculate new blend mask when non-full body blend needed
		if (!IsActionFullBodyOverride()) {
			ensureMsgf(CurPostureParam.ActionFilterBoneName != NAME_None, TEXT("Invalid None Name for Actoin"));

			auto* skeletonPtr = Output.AnimInstanceProxy->GetSkeleton();
			ThreeLayerBlendFilterKeyStruct keyStruct(
				skeletonPtr->GetGuid(),skeletonPtr->GetVirtualBoneGuid(),
				CurPostureParam.ActionFilterBoneName, CurPostureParam.ActionFilterBoneDepth,
				Output.AnimInstanceProxy->GetRequiredBones().GetCompactPoseNumBones(),
				Output.AnimInstanceProxy->GetLODLevel()
				);

			// Update TemplateActionBlendWeights when config changed
			bool isActionBoneChanged = (CurPostureParam.ActionFilterBoneName != CurrentActionBoneRootName) || (CurPostureParam.ActionFilterBoneDepth != CurrentActionBoneDepth);
			
			// Update TemplateActionBlendWeights when adding a refresh new one
			if (EnsureBlendWeights(Output.AnimInstanceProxy->GetRequiredBones(), skeletonPtr, keyStruct, CurPostureParam.ActionFilterBoneName, CurPostureParam.ActionFilterBoneDepth, TemplateActionBlendWeights)
				|| CurrentActionBlendWeights.Num()!=TemplateActionBlendWeights.Num()
				|| isActionBoneChanged)
			{
				CurrentActionBoneRootName = CurPostureParam.ActionFilterBoneName;
				CurrentActionBoneDepth = CurPostureParam.ActionFilterBoneDepth;
				CurrentActionBlendWeights.Reset();
				CurrentActionBlendWeights.SetNum(TemplateActionBlendWeights.Num());
				CachedActionLayerWeight = -1;
			}
		}
	}
	
	if (performBlendWeight > 0.0f) {
		ensureMsgf(CurPostureParam.PerformFilterBoneName != NAME_None, TEXT("Invalid None Name for Perform"));

		auto* skeletonPtr = Output.AnimInstanceProxy->GetSkeleton();
		ThreeLayerBlendFilterKeyStruct keyStruct(
			skeletonPtr->GetGuid(), skeletonPtr->GetVirtualBoneGuid(), CurPostureParam.PerformFilterBoneName,
			CurPostureParam.PerformFilterBoneDepth,
			Output.AnimInstanceProxy->GetRequiredBones().GetCompactPoseNumBones(),
			Output.AnimInstanceProxy->GetLODLevel()
			);

		// Update TemplateActionBlendWeights when config changed
		bool isPerformBoneChanged = (CurPostureParam.PerformFilterBoneName != CurrentPerformBoneRootName) || (CurPostureParam.PerformFilterBoneDepth != CurrentPerformBoneDepth);
		
		// Update TemplateActionBlendWeights when adding a refresh new one
		if (EnsureBlendWeights(Output.AnimInstanceProxy->GetRequiredBones(), skeletonPtr, keyStruct, CurPostureParam.PerformFilterBoneName, CurPostureParam.PerformFilterBoneDepth, TemplatePerformBlendWeights)
			|| CurrentPerformBlendWeights.Num()!=TemplatePerformBlendWeights.Num()
			|| isPerformBoneChanged)
		{
			CurrentPerformBoneRootName = CurPostureParam.PerformFilterBoneName;
			CurrentPerformBoneDepth = CurPostureParam.PerformFilterBoneDepth;
			CurrentPerformBlendWeights.Reset();
			CurrentPerformBlendWeights.SetNum(TemplatePerformBlendWeights.Num());
			CachedPerformLayerWeight = -1;
		}
	}

	// 1. construction weights
	TArray<FCompactPose> flteredPoses;
	TArray<FBlendedCurve> filteredCurve;
	TArray<UE::Anim::FStackAttributeContainer> filteredAttributes;

	const int ALL_LAYER_COUNT = 3;
	const int LOCO_LAYER_INDEX = 0;
	const int ACTION_LAYER_INDEX = 1;
	const int PERFORM_LAYER_INDEX = 2;


	TArray<float> layerWeights;
	layerWeights.Add(1.0f - actionBlendWeight);
	layerWeights.Add(actionBlendWeight);
	layerWeights.Add(performBlendWeight);

	TArray< FPoseLink> threeLayerPoses{ LocomotionPose, ActionPose, PerformAdditivePose };

	if (!IsActionFullBodyOverride()) {
		layerWeights[LOCO_LAYER_INDEX] = 1.0f;
	}

	// 2. evaluate by weights
	TArray<int32, TInlineAllocator<8>> PosesToEvaluate;
	for (int index = 0; index < ALL_LAYER_COUNT; ++index) {
		if (layerWeights[index] <= TOLERATE_SMALL_WEIGHT) {
			continue;
		}
		PosesToEvaluate.Add(index);
	}
	
	int actualEvaluateCount = PosesToEvaluate.Num();
	flteredPoses.SetNum(ALL_LAYER_COUNT, false);
	filteredCurve.SetNum(ALL_LAYER_COUNT, false);
	filteredAttributes.SetNum(ALL_LAYER_COUNT, false);
	
	
	for (int index = 0; index < actualEvaluateCount; ++index) {
		
		int evaluateIndex = PosesToEvaluate[index];
		FPoseContext CurrentPoseContext(Output, evaluateIndex == PERFORM_LAYER_INDEX);
		{
			TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_ThreeLayerPostureBlend::Evaluate_AnyThread::Pose Evaluate");
			threeLayerPoses[evaluateIndex].Evaluate(CurrentPoseContext);
		}
		flteredPoses[evaluateIndex].MoveBonesFrom(CurrentPoseContext.Pose);
		filteredCurve[evaluateIndex].MoveFrom(CurrentPoseContext.Curve);
		filteredAttributes[evaluateIndex].MoveFrom(CurrentPoseContext.CustomAttributes);
	}
	
	// 3. blend posture
	// AllCase :
	//	[1] loco + action
	//  [2] loco + perform
	//  [3] action + perform
	//  [4] loco + action + perform

	ensureMsgf(PosesToEvaluate.Num() > 1, TEXT("Unexpected layer count to blend before consume perform  :%d"), PosesToEvaluate.Num());
	
	TArray<FCompactPose> finalFilteredPoses;
	TArray<FBlendedCurve> finalFilteredCurve;
	TArray<UE::Anim::FStackAttributeContainer> finalFilteredAttributes;
	

	// 3.1 Try Get Additive Delta Pose
	bool hasPerformAdditiveApply = false;
	FPoseContext performAdditiveContext(Output.AnimInstanceProxy, true);
	FAnimationPoseData performOutAnimationPoseData(performAdditiveContext);
	if (TemplatePerformBlendWeights.Num() == flteredPoses[PosesToEvaluate[0]].GetNumBones() && PosesToEvaluate.Contains(PERFORM_LAYER_INDEX)) {
		FCompactPose identityPoseForAdditiveBlend;
		identityPoseForAdditiveBlend.SetBoneContainer(&flteredPoses[PERFORM_LAYER_INDEX].GetBoneContainer());
		identityPoseForAdditiveBlend.ResetToAdditiveIdentity();
		
		int evaluatedPerformIndex = PosesToEvaluate[PosesToEvaluate.Num() - 1];
		finalFilteredPoses.Add(std::move(flteredPoses[evaluatedPerformIndex]));
		finalFilteredCurve.Add(std::move(filteredCurve[evaluatedPerformIndex]));
		finalFilteredAttributes.Add(std::move(filteredAttributes[evaluatedPerformIndex]));
		FBlendedCurve tempCurve;
		UE::Anim::FStackAttributeContainer tempAttributes;

		float performLayerWeight = layerWeights[PERFORM_LAYER_INDEX];
		float performPartBlendValue = PerformPartBodyWhenMovingBlend.GetBlendedValue();

		if (CachedPerformLayerWeight != performLayerWeight || CachedPerformPartBodyWeight != performPartBlendValue) {
			CachedPerformLayerWeight = performLayerWeight;
			CachedPerformPartBodyWeight = performPartBlendValue;

			if (CurPostureParam.PerformBlendRule == EActionBlendRule::FullBodyOverride) {
				for (int index = 0; index < CurrentPerformBlendWeights.Num(); ++index) {
					CurrentPerformBlendWeights[index].BlendWeight = performLayerWeight;
				}
			}
			else if (CurPostureParam.PerformBlendRule == EActionBlendRule::PartBodyOverride) {
				for (int index = 0; index < CurrentPerformBlendWeights.Num(); ++index) {
					CurrentPerformBlendWeights[index].BlendWeight = TemplatePerformBlendWeights[index].BlendWeight * performLayerWeight;
				}
			}
			// CurPostureParam.ActionBlendRule == EActionBlendRule::PartBodyOverrideOnlyWhenMoving)
			else {
				for (int index = 0; index < CurrentPerformBlendWeights.Num(); ++index) {
					CurrentPerformBlendWeights[index].BlendWeight = TemplatePerformBlendWeights[index].BlendWeight;
					float curPartBoneWeight = CurrentPerformBlendWeights[index].BlendWeight;
					// retains the weights which already are 1.0f, and blend the left ones to 1.0f for blending final posture as full body weights
					CurrentPerformBlendWeights[index].BlendWeight = curPartBoneWeight + (1.0f - curPartBoneWeight) * performPartBlendValue;
					CurrentPerformBlendWeights[index].BlendWeight = CurrentPerformBlendWeights[index].BlendWeight * performLayerWeight;
				}

			}
		}

	
		{
			TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_ThreeLayerPostureBlend::Evaluate_AnyThread::Do Pose Blend");
			FAnimationRuntime::BlendPosesPerBoneFilter(
				identityPoseForAdditiveBlend, finalFilteredPoses,
				tempCurve, finalFilteredCurve,
				tempAttributes, finalFilteredAttributes,
				performOutAnimationPoseData, CurrentPerformBlendWeights,
				FAnimationRuntime::EBlendPosesPerBoneFilterFlags::None, ECurveBlendOption::Type::BlendByWeight);
		}
		// consume perform layer
		PosesToEvaluate.Remove(evaluatedPerformIndex);
		hasPerformAdditiveApply = true;
	}
	
	ensureMsgf((PosesToEvaluate.Num() >= 1 && PosesToEvaluate.Num() <= 2), TEXT("Unexpected layer count to blend after consume perform :%d"), PosesToEvaluate.Num());
	// 3.2 remain loco + action need to blend
	FPoseContext baseBlendedPostureContext(Output.AnimInstanceProxy, false);
	if (PosesToEvaluate.Num() == 2) {
		// using override blend directly for loco + action
		FAnimationPoseData baseBlendedPosturePoseData(baseBlendedPostureContext);

		// full body override
		if (IsActionFullBodyOverride()) {
			finalFilteredPoses.Reset();
			finalFilteredCurve.Reset();
			finalFilteredAttributes.Reset();
			
			for (int index = 0; index < PosesToEvaluate.Num(); ++index) {
				int sourceEvaluateIndex = PosesToEvaluate[index];
				finalFilteredPoses.Add(std::move(flteredPoses[sourceEvaluateIndex]));
				finalFilteredCurve.Add(std::move(filteredCurve[sourceEvaluateIndex]));
				finalFilteredAttributes.Add(std::move(filteredAttributes[sourceEvaluateIndex]));

			}

			{
				TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_ThreeLayerPostureBlend::Evaluate_AnyThread::Do Pose Blend");
				// todo support dynamic full body blend with loco start
				FAnimationRuntime::BlendPosesTogether(finalFilteredPoses, finalFilteredCurve, finalFilteredAttributes, layerWeights, PosesToEvaluate, baseBlendedPosturePoseData);
			}
		}
		// part body layered override
		else {
			
			// invalid weights for action blend, using locomotion as the base blended pose
			if (TemplateActionBlendWeights.Num() != flteredPoses[PosesToEvaluate[0]].GetNumBones()) {
				ensureMsgf(false, TEXT("Unexpected bone count to blend :%s,  EvaluateIndex:%d  FilteredCount:%d  %d %d"),
					*(Output.AnimInstanceProxy->GetSkeleton()->GetFName().ToString()), PosesToEvaluate[0], flteredPoses.Num(), filteredCurve.Num(), filteredAttributes.Num()
				);
				// Get Data As A Reference Variable, For More Accurate Crash Info
				// https://docs.corp.kuaishou.com/d/home/fcADxpdVlByd9xliMMAbnHn-M, [MEM-1] Problem
				auto & FilteredPose = flteredPoses[PosesToEvaluate[0]];
				baseBlendedPostureContext.Pose.MoveBonesFrom(FilteredPose);
				baseBlendedPostureContext.Curve.MoveFrom(filteredCurve[PosesToEvaluate[0]]);
				baseBlendedPostureContext.CustomAttributes.MoveFrom(filteredAttributes[PosesToEvaluate[0]]);
			}
			else {

				FAnimationRuntime::EBlendPosesPerBoneFilterFlags blendFlags = FAnimationRuntime::EBlendPosesPerBoneFilterFlags::None;
				if (CurPostureParam.bActionMeshSpaceBlend) {
					blendFlags = FAnimationRuntime::EBlendPosesPerBoneFilterFlags::MeshSpaceRotation | FAnimationRuntime::EBlendPosesPerBoneFilterFlags::MeshSpaceScale;;
				}

				finalFilteredPoses.Reset();
				finalFilteredCurve.Reset();
				finalFilteredAttributes.Reset();

				int blendTargetEvaluateIndex = PosesToEvaluate[1];
				int sourceEvaluateIndex = PosesToEvaluate[0];
				finalFilteredPoses.Add(std::move(flteredPoses[blendTargetEvaluateIndex]));
				finalFilteredCurve.Add(std::move(filteredCurve[blendTargetEvaluateIndex]));
				finalFilteredAttributes.Add(std::move(filteredAttributes[blendTargetEvaluateIndex]));
				
				float actionLayerBlendValue = layerWeights[blendTargetEvaluateIndex];
				float actionPartBlendValue = ActionPartBodyWhenMovingBlend.GetBlendedValue();
				if (CachedActionLayerWeight != actionLayerBlendValue || CachedActionPartBodyWeight != actionPartBlendValue) {
					CachedActionLayerWeight = actionLayerBlendValue;
					CachedActionPartBodyWeight = actionPartBlendValue;

					bool isActionPartBlendWhenMoving = CurPostureParam.ActionBlendRule == EActionBlendRule::PartBodyOverrideOnlyWhenMoving;
				
					for (int index = 0; index < CurrentActionBlendWeights.Num(); ++index) {
						CurrentActionBlendWeights[index].BlendWeight = TemplateActionBlendWeights[index].BlendWeight;
						float curPartBoneWeight = CurrentActionBlendWeights[index].BlendWeight;
						// retains the weights which already are 1.0f, and blend the left ones to 1.0f for blending final posture as full body weights
						if (isActionPartBlendWhenMoving) {
							CurrentActionBlendWeights[index].BlendWeight = curPartBoneWeight + (1.0f - curPartBoneWeight) * actionPartBlendValue;
						}

						CurrentActionBlendWeights[index].BlendWeight = CurrentActionBlendWeights[index].BlendWeight * actionLayerBlendValue;
					}
				}
				{
					TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_ThreeLayerPostureBlend::Evaluate_AnyThread::Do Pose Blend");
					FAnimationRuntime::BlendPosesPerBoneFilter(
						flteredPoses[sourceEvaluateIndex], finalFilteredPoses,
						filteredCurve[sourceEvaluateIndex], finalFilteredCurve,
						filteredAttributes[sourceEvaluateIndex], finalFilteredAttributes,
						baseBlendedPosturePoseData, CurrentActionBlendWeights, blendFlags, ECurveBlendOption::Type::UseMaxValue);
				}
			}
		}

	}
	else {

		// 0st item is the base posture, if only if there is one element in the array
		baseBlendedPostureContext.Pose.MoveBonesFrom(flteredPoses[PosesToEvaluate[0]]);
		baseBlendedPostureContext.Curve.MoveFrom(filteredCurve[PosesToEvaluate[0]]);
		baseBlendedPostureContext.CustomAttributes.MoveFrom(filteredAttributes[PosesToEvaluate[0]]);
	}

	// 3.3 blend base blended pose and perform additive pose
	if (!hasPerformAdditiveApply) {
		Output.Pose.MoveBonesFrom(baseBlendedPostureContext.Pose);
		Output.Curve.MoveFrom(baseBlendedPostureContext.Curve);
		Output.CustomAttributes.MoveFrom(baseBlendedPostureContext.CustomAttributes);
		return;
	}

	Output.Pose.MoveBonesFrom(baseBlendedPostureContext.Pose);
	Output.Curve.MoveFrom(baseBlendedPostureContext.Curve);
	Output.CustomAttributes.MoveFrom(baseBlendedPostureContext.CustomAttributes);

	FAnimationPoseData finalOutAnimationPoseData(Output);
	{
		TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_ThreeLayerPostureBlend::Evaluate_AnyThread::Do Pose Blend");
		FAnimationRuntime::AccumulateAdditivePose(finalOutAnimationPoseData, performOutAnimationPoseData, CurPostureParam.AdditiveAlpha, AAT_LocalSpaceBase);
	}
	Output.Pose.NormalizeRotations();

}

bool FAnimNode_ThreeLayerPostureBlend::IsAnyBlendWorking() {
	return CurPostureParam.bActionWorking || CurPostureParam.bPerformWorking || ActionBlend.GetBlendedValue() > TOLERATE_SMALL_WEIGHT || PerformBlend.GetBlendedValue() > TOLERATE_SMALL_WEIGHT;
}

#undef LOCTEXT_NAMESPACE