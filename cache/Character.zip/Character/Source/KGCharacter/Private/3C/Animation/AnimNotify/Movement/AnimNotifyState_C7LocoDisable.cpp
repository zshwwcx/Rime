// Copyright Epic Games, Inc. All Rights Reserved.

// #pragma once

#include "3C/Animation/AnimNotify/Movement/AnimNotifyState_C7LocoDisable.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Movement/RoleMovementComponent.h"



void UAnimNotifyState_C7LocoDisable::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference) 
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7LocoDisable::NotifyBegin");
	
	if (ABaseCharacter* Character = Cast<ABaseCharacter>(MeshComp->GetOwner()))
	{
		if (!Character->DoLocoDisableFromAnimNotify(GetUniqueID(), bDisableAllMove, bDisableLocoMove, bDisableLocoStart, bForceLocoStart,
			bDisableLocoJump, bDisableLocoDodge, bForceLocoGroundSupport, bForceIgnoreLocoGroundSupport))
		{
			UE_LOG(LogTemp, Warning, TEXT("[AnimNotifyState_C7LocoDisable] Replicated NotifyBegin! %s, %s"), *MeshComp->GetName(), *Animation->GetName());
		}
	}
}

void UAnimNotifyState_C7LocoDisable::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) 
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7LocoDisable::NotifyEnd");
	
	if (ABaseCharacter* Character = Cast<ABaseCharacter>(MeshComp->GetOwner()))
	{
		Character->UnDoLocoDisableFromAnimNotify(GetUniqueID(), bDisableAllMove, bDisableLocoMove, bDisableLocoStart, bForceLocoStart,
			bDisableLocoJump, bDisableLocoDodge, bForceLocoGroundSupport, bForceIgnoreLocoGroundSupport);
	}
}


#if WITH_EDITOR
void UAnimNotifyState_C7LocoDisable::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	if (PropertyChangedEvent.GetPropertyName().IsEqual(TEXT("bDisableLocoStart")))
	{
		if (bDisableLocoStart)
		{
			bForceLocoStart = false;
		}
	}
	else if (PropertyChangedEvent.GetPropertyName().IsEqual(TEXT("bForceLocoStart")))
	{
		if (bForceLocoStart)
		{
			bDisableLocoStart = false;
		}
	}
	else if (PropertyChangedEvent.GetPropertyName().IsEqual(TEXT("bDisableAllMove")))
	{
		if (bDisableAllMove)
		{
			bDisableLocoMove = false;
		}
	}
	else if (PropertyChangedEvent.GetPropertyName().IsEqual(TEXT("bForceLocoGroundSupport")))
	{
		if (bForceLocoGroundSupport)
		{
			bForceIgnoreLocoGroundSupport = false;
		}
	}
	else if (PropertyChangedEvent.GetPropertyName().IsEqual(TEXT("bForceIgnoreLocoGroundSupport")))
	{
		if (bForceIgnoreLocoGroundSupport)
		{
			bForceLocoGroundSupport = false;
		}
	}
}

#endif
