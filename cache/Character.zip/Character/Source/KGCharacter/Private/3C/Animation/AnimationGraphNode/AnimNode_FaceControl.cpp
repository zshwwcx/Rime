#include "3C/Animation/AnimationGraphNode/AnimNode_FaceControl.h"
#include "AnimationRuntime.h"
#include "Animation/AnimTrace.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(AnimNode_FaceControl)

/////////////////////////////////////////////////////
// FAnimNode_FaceControl

FAnimNode_FaceControl::FAnimNode_FaceControl()
{
}

void FAnimNode_FaceControl::Initialize_AnyThread(const FAnimationInitializeContext& Context)
{
	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(Initialize_AnyThread)
	FAnimNode_Base::Initialize_AnyThread(Context);

	Base.Initialize(Context);
}

void FAnimNode_FaceControl::CacheBones_AnyThread(const FAnimationCacheBonesContext& Context)
{
	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(CacheBones_AnyThread)
	Base.CacheBones(Context);
}

void FAnimNode_FaceControl::Update_AnyThread(const FAnimationUpdateContext& Context)
{
	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(Update_AnyThread)
	Base.Update(Context.FractionalWeight(1.f));

	GetEvaluateGraphExposedInputs().Execute(Context);
}

void FAnimNode_FaceControl::Evaluate_AnyThread(FPoseContext& Output)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_FaceControl::Evaluate_AnyThread");
	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(Evaluate_AnyThread)

	FPoseContext BaseEvalContext(Output);

	Base.Evaluate(BaseEvalContext);

	FPoseContext SourcePose(Output);

	for (auto& FaceChannelPair : FaceChannelValueMap)
	{
		const float& ActualAlpha = FaceChannelPair.Value;

		if (UAnimSequenceBase** SeqPtr = FaceAnimMap.Find(FaceChannelPair.Key))
		{
			if (UAnimSequenceBase* AnimSeq = *SeqPtr)
			{
				FAnimationPoseData AnimPoseData(SourcePose);
				AnimSeq->GetAnimationPose(AnimPoseData, FAnimExtractContext(static_cast<double>(0), false, {}, true));

				FPoseContext AdditivePose(SourcePose);
				AdditivePose = SourcePose;
				FAnimationRuntime::ConvertPoseToAdditive(AdditivePose.Pose, BaseEvalContext.Pose);
				AdditivePose.Curve.ConvertToAdditive(BaseEvalContext.Curve);

				UE::Anim::Attributes::ConvertToAdditive(BaseEvalContext.CustomAttributes, AdditivePose.CustomAttributes);

				FAnimationPoseData BaseAnimationPoseData(Output);
				const FAnimationPoseData AdditiveAnimationPoseData(AdditivePose);
				FAnimationRuntime::AccumulateAdditivePose(BaseAnimationPoseData, AdditiveAnimationPoseData, ActualAlpha, AAT_LocalSpaceBase);
			}
		}
	}
}

void FAnimNode_FaceControl::GatherDebugData(FNodeDebugData& DebugData)
{
	FString DebugLine = DebugData.GetNodeName(this);
	DebugData.AddDebugItem(DebugLine);
	Base.GatherDebugData(DebugData);
}

