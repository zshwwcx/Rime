// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Animation/AnimNotify/AnimNotifyState_C7HurdleHandIK.h"

#include "3C/Animation/BaseAnimInstance.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Character/C7Actor.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "Interfaces/ITargetDevice.h"


void UAnimNotifyState_C7HurdleHandIK::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation,
                                                  float TotalDuration, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7HurdleHandIK::NotifyBegin");
	
	if(EffectBone.IsNone() || JointBone.IsNone())
	{
		return;
	}
	if(ABaseCharacter* TargetCharacter = Cast<ABaseCharacter>(MeshComp->GetOwner()))
	{
		ICppEntityInterface* CppEntity = UKGUEActorManager::GetLuaEntityByActor(MeshComp->GetOwner());
		if (CppEntity && CppEntity->GetIsMainPlayer())
		{
			if(UBaseAnimInstance* BaseAnimInstance = Cast<UBaseAnimInstance>(MeshComp->GetAnimInstance()))
			{
				// 按照两骨骼方向检测
				if(URoleMovementComponent* RoleMC = Cast<URoleMovementComponent>(TargetCharacter->GetMovementComponent()))
				{
					FTransform EffectTransform = MeshComp->GetSocketTransform(EffectBone, ERelativeTransformSpace::RTS_Component);
					EffectTransform.SetLocation(EffectTransform.GetLocation() + DetectOffsetComponentSpace);
					EffectTransform = EffectTransform * MeshComp->GetComponentToWorld();
					FVector HandIKLocation = FVector::ZeroVector;
					if (RoleMC->GetHurdleHandIKLocation(EffectTransform.GetLocation(), HandIKLocation, DetectDepth))
					{
						HandIKLocation += MeshComp->GetComponentToWorld().TransformVector(IKLocationOffsetComponentSpace);
						BaseAnimInstance->AddAndResetTwoBoneIKParamSimply(EffectBone, JointBone, HandIKLocation.X, HandIKLocation.Y, HandIKLocation.Z, NAME_None, 0.f, JointTargetLocation);
					}
				}
			}
		}
	}
}

void UAnimNotifyState_C7HurdleHandIK::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation,
	const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7HurdleHandIK::NotifyEnd");
	
	if(EffectBone.IsNone() || JointBone.IsNone())
	{
		return;
	}
	if(ABaseCharacter* _ = Cast<ABaseCharacter>(MeshComp->GetOwner()))
	{
		ICppEntityInterface* CppEntity = UKGUEActorManager::GetLuaEntityByActor(MeshComp->GetOwner());
		if (CppEntity && CppEntity->GetIsMainPlayer())
		{
			if(UBaseAnimInstance* BaseAnimInstance = Cast<UBaseAnimInstance>(MeshComp->GetAnimInstance()))
			{
				if (BaseAnimInstance->HasTwoBoneIK(EffectBone))
				{
					BaseAnimInstance->RemoveTwoBoneIKParam(EffectBone);
				}
			}
		}
	}
}

void UAnimNotifyState_C7HurdleHandIK::NotifyTick(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation,
	float FrameDeltaTime, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7HurdleHandIK::NotifyTick");
	
	if(EffectBone.IsNone() || JointBone.IsNone())
	{
		return;
	}
	if(ABaseCharacter* _ = Cast<ABaseCharacter>(MeshComp->GetOwner()))
	{
		ICppEntityInterface* CppEntity = UKGUEActorManager::GetLuaEntityByActor(MeshComp->GetOwner());
		if (CppEntity && CppEntity->GetIsMainPlayer())
		{
			if(UBaseAnimInstance* BaseAnimInstance = Cast<UBaseAnimInstance>(MeshComp->GetAnimInstance()))
			{
				if (BaseAnimInstance->HasTwoBoneIK(EffectBone))
				{
					float Alpha = 1.f;
					float RunningTime = EventReference.GetCurrentAnimationTime() - EventReference.GetNotify()->GetTriggerTime();
					float Duration = EventReference.GetNotify()->Duration;
					float RemainingTime = FMath::Abs(Duration - RunningTime);
					if(BlendInTime > 0.f && RunningTime < BlendInTime)
					{
						Alpha *= RunningTime / BlendInTime;
					}
					if(BlendOutTime > 0.f && RemainingTime < BlendOutTime)
					{
						Alpha *= RemainingTime / BlendOutTime;
					}
					BaseAnimInstance->UpdateTwoBoneIKParamSimplyOnlyAlpha(EffectBone, Alpha);
				}
			}
		}
	}
}
