#include "3C/Animation/LookAt/LookAtComponent.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Animation/FaceAnim/FaceAnim.h"
#include "Components/SkeletalMeshComponent.h"
#include "Animation/AnimInstance.h"
#include "3C/Animation/LookAt/CutSceneAnimInstance.h"

ULookAtComponent::ULookAtComponent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer), bAutoLoadAnimLayer(false), bLoadedAnimLayer(false)
{
	PrimaryComponentTick.bCanEverTick = true;
	bWantsInitializeComponent = true;
}

void ULookAtComponent::InitializeComponent()
{
	Super::InitializeComponent();
}

void ULookAtComponent::BeginPlay()
{
	Super::BeginPlay();

	if (GetOwner())
	{
		Character = Cast<ABaseCharacter>(GetOwner());
	}
}

void ULookAtComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{

	QUICK_SCOPE_CYCLE_COUNTER(FaceAnimComponent_Tick);
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("ULookAtComponent_TickComponent");

	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (bAutoLoadAnimLayer && !bLoadedAnimLayer)
	{
		if (AActor *Owner = GetOwner())
		{
			if (ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(Owner))
			{
				if (AnimLayerClass && UKismetSystemLibrary::IsValidClass(AnimLayerClass) && BaseCharacter->GetMesh())
				{
					BaseCharacter->GetMesh()->LinkAnimClassLayers(AnimLayerClass);

					bLoadedAnimLayer = true;
				}
			}
		}
	}
}

void ULookAtComponent::UpdateProperty()
{
	if(Character == nullptr)
	{
		if (GetOwner())
		{
			Character = Cast<ABaseCharacter>(GetOwner());
		}
	}
	if (AnimLayerClass == nullptr || !UKismetSystemLibrary::IsValidClass(AnimLayerClass))
	{
		return;
	}
	if (USkeletalMeshComponent* SkeletalMeshComponent = Character->GetMesh())
	{
		if(!bLoadedAnimLayer)
		{
			SkeletalMeshComponent->LinkAnimClassLayers(AnimLayerClass);
			bLoadedAnimLayer = true;
		}
		UAnimInstance* AnimInstance = SkeletalMeshComponent->GetLinkedAnimLayerInstanceByClass(AnimLayerClass);
		if (UCutSceneAnimInstance* CutSceneAnimInstance = Cast<UCutSceneAnimInstance>(AnimInstance))
		{
			//UE_LOG(LogTemp, Warning, TEXT("UpdateProperty befor =>Eye:%f %f %f, Head:%f %f %f , body:%f %f %f "), CutSceneAnimInstance->Eye.Pitch, CutSceneAnimInstance->Eye.Yaw, CutSceneAnimInstance->Eye.Roll, CutSceneAnimInstance->Head.Pitch, CutSceneAnimInstance->Head.Yaw, CutSceneAnimInstance->Head.Roll, CutSceneAnimInstance->Body.Pitch, CutSceneAnimInstance->Body.Yaw, CutSceneAnimInstance->Body.Roll);
			CutSceneAnimInstance->Eye = Eye;
			CutSceneAnimInstance->EyeScale = EyeScale;
			CutSceneAnimInstance->Head = Head;
			CutSceneAnimInstance->Body = Body;
			CutSceneAnimInstance->Spine_01 = Spine_01;
			CutSceneAnimInstance->Spine_02 = Spine_02;
			CutSceneAnimInstance->Spine_03 = Spine_03;
			//UE_LOG(LogTemp, Warning, TEXT("UpdateProperty update =>Eye:%f %f %f, Head:%f %f %f , body:%f %f %f "), CutSceneAnimInstance->Eye.Pitch, CutSceneAnimInstance->Eye.Yaw, CutSceneAnimInstance->Eye.Roll, CutSceneAnimInstance->Head.Pitch, CutSceneAnimInstance->Head.Yaw, CutSceneAnimInstance->Head.Roll, CutSceneAnimInstance->Body.Pitch, CutSceneAnimInstance->Body.Yaw, CutSceneAnimInstance->Body.Roll);

			// Restore pose after unbinding to force the restored pose
			// SkeletalMeshComponent->SetUpdateAnimationInEditor(true);
			// SkeletalMeshComponent->SetUpdateClothInEditor(true);
			// SkeletalMeshComponent->TickAnimation(0.f, false);

			// SkeletalMeshComponent->RefreshBoneTransforms();
			// SkeletalMeshComponent->RefreshFollowerComponents();
			// SkeletalMeshComponent->UpdateComponentToWorld();
			// SkeletalMeshComponent->FinalizeBoneTransform();
			// SkeletalMeshComponent->MarkRenderTransformDirty();
			// SkeletalMeshComponent->MarkRenderDynamicDataDirty();
		}
	}
}

