// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Animation/AnimNotify/AnimNotifyState_C7ChangeAnimPosture.h"

#include "3C/Animation/BaseAnimInstance.h"
#include "3C/Character/BaseCharacter.h"

void UAnimNotifyState_C7ChangeAnimPosture::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation,
												float TotalDuration)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7ChangeAnimPosture::NotifyBegin");
	
	AActor* Owner = MeshComp->GetOwner();
	if (!Owner) {
		return;
	}
	
	ABaseCharacter* TargetCharacter = Cast<ABaseCharacter>(Owner);
	if (TargetCharacter == nullptr)
	{
		return;
	}
	TargetCharacter->CallLuaEntity(TargetCharacter, TargetCharacter->GetEntityUID(), "KCB_OnAnimNotify_C7ChangeAnimPosture", AnimPostureName, TargetValue);

}
