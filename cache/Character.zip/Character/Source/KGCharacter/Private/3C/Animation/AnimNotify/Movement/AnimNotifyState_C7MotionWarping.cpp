// Copyright Epic Games, Inc. All Rights Reserved.

// #pragma once

#include "Animation/AnimSequence.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Animation/AnimNotify/Movement/AnimNotifyState_C7MotionWarping.h"
#include "3C/Animation/BaseAnimInstance.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "UObject/ObjectSaveContext.h"

#if WITH_EDITOR
#include "InputDialog/KGInputDialog.h"
#endif



DEFINE_LOG_CATEGORY_STATIC(C7MotionWarpingLog, Log, All);

void UAnimNotifyState_C7MotionWarping::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference) {
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7MotionWarping::NotifyBegin");
	
	// 编辑器下不做逻辑
#if WITH_EDITORONLY_DATA
	if (MeshComp->GetWorld()->IsPreviewWorld()) {
		return;
	}
#endif
	
	UBaseAnimInstance* AnimIns = Cast<UBaseAnimInstance>(MeshComp->GetAnimInstance());

 	if (AnimIns == nullptr)
	{
		return;
	}

	ABaseCharacter* character = Cast<ABaseCharacter>(AnimIns->TryGetPawnOwner());
	if (character == nullptr) {
		return;
	}
 	URoleMovementComponent* rmc = Cast<URoleMovementComponent>(character->GetMovementComponent());

	rmc = GetMovementAuthorityControlRMC(rmc);
	if (rmc == nullptr || !rmc->GetIsEnableExecuteMotionWarp()) {
		return;
	}

	//CurrentWorkRMC = rmc;
	
	FMovementCorrectorManager& mcm = rmc->GetRoleMP().MovementCorrectorManager;
	// Locomotion控制部分, 输入是这里设置, 其他部分大多数都是程序代码设置
	if (bUsingLocoInput) {
		ensureAlways(LocoInputQueryTime > 0.0f);
		if (LocoInputQueryTime < 0.0f) {
			LocoInputQueryTime = 0.05f;
		}
		int MotionWarpMCToken = rmc->ObtainRotationWarpWithLocoInputMode(ECorrectorObtainPriority::Locomotion, LocoInputQueryTime, WarpTargetRotationSource);
		if (MotionWarpMCToken <= 0)
		{
			// 可能有更高优先级的MoveCorrector抢占，这时可以直接忽略本次MotionWarp
			// Todo：后续需要区分位移和旋转的MoveCorrector抢占，这里UsingLocoInput方式可以认为只会使用旋转的MoveCorrector
			return;
		}
		if (!character->SaveMotionWarpMCTokenForAnimNotify(GetUniqueID(), MotionWarpMCToken))
		{
			UE_LOG(LogTemp, Warning, TEXT("[UAnimNotifyState_C7MotionWarping] Replicated NotifyBegin! %s, %s"), *MeshComp->GetName(), *Animation->GetName());
		}
	}

	float starttime = EventReference.GetNotify()->GetTriggerTime();
	float endtime = EventReference.GetNotify()->GetEndTriggerTime();
	//\Engine\Source\Editor\Persona\Private\SAnimNotifyPanel.cpp 1952 
	// AnimNotifyEvent->TriggerTimeOffset = GetTriggerTimeOffsetForType(Offset)
	// 这个通过枚举存储的值有Bug, 可能会小于0, 加了个保底
	starttime = FMath::Clamp(starttime, .0f, endtime);
	FTransform startTrans, endTrans;
	bool isGetSuccess = false;
	float duration = 0.0f;
	UAnimSequenceBase * WarpedAnim = nullptr;
	if (const UAnimMontage* AnimMontage = Cast<UAnimMontage>(Animation))
	{
		if (const FAnimSegment* Segment = AnimMontage->SlotAnimTracks[0].AnimTrack.GetSegmentAtTime(starttime))
		{
			if (UAnimSequence* AnimSequence = Cast<UAnimSequence>(Segment->GetAnimReference()))
			{
				starttime = Segment->ConvertTrackPosToAnimPos(starttime);
				startTrans = AnimSequence->ExtractRootTrackTransform(starttime, nullptr);
				endtime = Segment->ConvertTrackPosToAnimPos(endtime);
				endTrans = AnimSequence->ExtractRootTrackTransform(endtime, nullptr);
				isGetSuccess = true;
				duration = fabs(endtime - starttime); // Montage中可能使用倒播速率
				WarpedAnim = AnimSequence;
			}
		}
	}
	else 
	{
		// 可能是sequence或者sequenceComposite
		startTrans = Animation->ExtractRootTrackTransform(starttime, nullptr);
		endTrans = Animation->ExtractRootTrackTransform(endtime, nullptr);
		isGetSuccess = true;
		duration = endtime - starttime;
		WarpedAnim = Animation;
	}
	
	if (!isGetSuccess) {
		return;
	}

	// obtain可能是脚本逻辑进行设置的(例如技能中)
	mcm.StartMotionWarp(
		duration,
		starttime,
		WrapRotationDirection,
		startTrans, endTrans, WarpedAnim, WarpTargetName
	);

	rmc->SetHitMotionWarpToken(rmc->GetRoleMP().MovementCorrectorManager.GetCorrectorCurToken(EMovementCorrectorType::MotionWarpCorrector));
	// UE_LOG(LogTemp, Log, TEXT("C7MotionWarp Start Name:%s"), *WarpTargetName.ToString())
}
void UAnimNotifyState_C7MotionWarping::NotifyTick(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float FrameDeltaTime, const FAnimNotifyEventReference& EventReference)
{
	// UE_LOG(LogTemp, Log, TEXT("C7MotionWarp Tick Name:%s"), *WarpTargetName.ToString())
}
void UAnimNotifyState_C7MotionWarping::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) {
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7MotionWarping::NotifyEnd");
	
	// 编辑器下不做逻辑

#if WITH_EDITORONLY_DATA
	if (MeshComp->GetWorld()->IsPreviewWorld()) {
		return;
	}
#endif


	UBaseAnimInstance* AnimIns = Cast<UBaseAnimInstance>(MeshComp->GetAnimInstance());

	if (AnimIns == nullptr)
	{
		return;
	}

	ABaseCharacter* character = Cast<ABaseCharacter>(AnimIns->TryGetPawnOwner());
	if (character == nullptr) {
		return;
	}

	URoleMovementComponent* rmc = Cast<URoleMovementComponent>(character->GetMovementComponent());

	rmc = GetMovementAuthorityControlRMC(rmc);
	if (rmc == nullptr || !rmc->GetIsEnableExecuteMotionWarp()) {
		return;
	}

	if (rmc->GetCurrentIsNetSimulate()) {
		return;
	}

	if (bUsingLocoInput)
	{
		int obtainedMCToken = character->GetAndClearMotionWarpMCTokenForAnimNotify(GetUniqueID());
		if (obtainedMCToken <= 0) {
			return;
		}

		rmc->GetRoleMP().MovementCorrectorManager.ReleaseMotionWarp(obtainedMCToken);
	}
	else
	{
		int CurrentToken = rmc->GetRoleMP().MovementCorrectorManager.GetCorrectorCurToken(EMovementCorrectorType::MotionWarpCorrector);
		int RecordedStartToken = rmc->GetHitMotionWarpToken();
		if (bNeedReset)
		{
			if (CurrentToken == RecordedStartToken)
			{
				rmc->GetRoleMP().MovementCorrectorManager.StopMotionWarp(WarpTargetName);
			}
		}
	}
	// UE_LOG(LogTemp, Log, TEXT("C7MotionWarp End Name:%s"), *WarpTargetName.ToString())
}

void UAnimNotifyState_C7MotionWarping::PreSave(FObjectPreSaveContext ObjectSaveContext) {
	Super::PreSave(ObjectSaveContext);
}
