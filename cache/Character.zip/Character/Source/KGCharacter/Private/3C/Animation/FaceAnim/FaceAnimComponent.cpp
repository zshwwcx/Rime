#include "3C/Animation/FaceAnim/FaceAnimComponent.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Animation/FaceAnim/FaceAnim.h"
#include "Components/SkeletalMeshComponent.h"
#include "3C/Animation/BaseAnimInstance.h"


static TAutoConsoleVariable<bool> CVarCharacterFaceAnim(
	TEXT("c7.Character.FaceAnim"),
	true,
	TEXT("c7.Character.FaceAnim"),
	ECVF_Default);


UFaceAnimComponent::UFaceAnimComponent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer), bAutoLoadFaceAnimLayer(false), bLoadedFaceAnimLayer(false)
{
	PrimaryComponentTick.bCanEverTick = true;
	bWantsInitializeComponent = true;
}

void UFaceAnimComponent::InitializeComponent()
{
	Super::InitializeComponent();
	InitFaceAnim();

#ifdef DISABLE_FACE_CLIP_SYNC
	TSubclassOf<UFaceAnimLipSync> LipSyncClass(UFaceAnimLipSync::StaticClass());
	if (FaceLipSyncClass)
	{
		LipSyncClass = FaceLipSyncClass;
	}
	FaceLipSync = NewObject<UFaceAnimLipSync>(this, LipSyncClass, FName("LipSync"));
#endif
}

void UFaceAnimComponent::BeginPlay()
{
	Super::BeginPlay();
	if (GetOwner())
	{
		Character = Cast<ABaseCharacter>(GetOwner());
	}
	
#ifdef DISABLE_FACE_CLIP_SYNC
	LipSyncInit();
	EyeControlInit();
#endif
}

void UFaceAnimComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	QUICK_SCOPE_CYCLE_COUNTER(FaceAnimComponent_Tick);
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UFaceAnimComponent_TickComponent");

	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	
	if (FaceAnim)
	{
		FaceAnim->Update(DeltaTime);
	}
}

void UFaceAnimComponent::InitFaceAnim()
{
	if (!IsValid(FaceAnim))
	{
		TSubclassOf<UFaceAnim> InFaceAnimClass(UFaceAnim::StaticClass());
		if (FaceAnimClass)
		{
			InFaceAnimClass = FaceAnimClass;
		}

		FaceAnim = NewObject<UFaceAnim>(this, InFaceAnimClass, FName("AnimFace"));
	}
}

UFaceAnimLayer* UFaceAnimComponent::InitFaceAnimLayer(USkeletalMeshComponent* CachedMeshComp, EFaceAnimSexType Sex)
{
	if (!UKismetSystemLibrary::IsValid(CachedMeshComp))
	{
		return nullptr;
	}

	if (Sex != EFaceAnimSexType::Male)
	{
		if (FaceAnimLayerClass && UKismetSystemLibrary::IsValidClass(FaceAnimLayerClass))
		{
			CurFaceAnimLayerClass = FaceAnimLayerClass;
		}
	}
	else
	{
		if (ManFaceAnimLayerClass && UKismetSystemLibrary::IsValidClass(ManFaceAnimLayerClass))
		{
			CurFaceAnimLayerClass = ManFaceAnimLayerClass;
		}
	}

	if (AActor* Owner = GetOwner())
	{
		if (ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(Owner))
		{
			if (CurFaceAnimLayerClass && UKismetSystemLibrary::IsValidClass(CurFaceAnimLayerClass))
			{
				if (UBaseAnimInstance* AnimIns = Cast<UBaseAnimInstance>(CachedMeshComp->GetAnimInstance()))
				{
					UFaceAnimLayer* FaceLayer = Cast<UFaceAnimLayer>(AnimIns->GetFeatureAnimLayer(FName(FaceAnimLayerTag)));
					if(!IsValid(FaceLayer))
					{
						FaceLayer = Cast<UFaceAnimLayer>(AnimIns->LinkFeatureAnimLayer(FName(FaceAnimLayerTag), CurFaceAnimLayerClass));
					}
					if(IsValid(FaceLayer))
					{
						FaceLayer->SetDefaultPerformMode(1);
						return FaceLayer;
					}
				}
			}
		}
	}

	return nullptr;
}

void UFaceAnimComponent::PlayLipFaceAnim(USkeletalMeshComponent* CachedMeshComp, const FString& FaceAnimID, float FixTime, EFaceAnimSexType Sex/* = EFaceAnimSexType::None*/)
{
#if !UE_BUILD_SHIPPING
	if(!CVarCharacterFaceAnim->GetBool())
	{
		return;
	}
#endif
	
	InitFaceAnim();

	if(!FaceAnim || !UKismetSystemLibrary::IsValid(CachedMeshComp))
		return ;
	
	UFaceAnimLayer* FaceLayerPtr = InitFaceAnimLayer(CachedMeshComp, Sex);
	FaceAnim->Init(CachedMeshComp, FaceLayerPtr, EFaceAnimModeType::Tick, FaceAnimLayerTag);
	FaceAnim->Play(FaceAnimID, FixTime);
}

void UFaceAnimComponent::SetLipBlend(float blendRatio) {
	if (!FaceAnim) {
		return;
	}
	FaceAnim->SetLipBlend(blendRatio);
}

void UFaceAnimComponent::SetFaceFloatParam(const FName& key, float value) {
	
	if (!FaceAnim) {
		return;
	}

	FaceAnim->SetFaceFloatParam(key, value);
}

void UFaceAnimComponent::SetLipFaceAnimFrame(USkeletalMeshComponent* CachedMeshComp, const FString& FaceAnimID, float FixTime, float LipBlend, EFaceAnimSexType Sex/* = EFaceAnimSexType::None*/)
{
#if !UE_BUILD_SHIPPING
	if(!CVarCharacterFaceAnim->GetBool())
	{
		return;
	}
#endif
	
	InitFaceAnim();

	if (!FaceAnim || !IsValid(CachedMeshComp))
		return;

	UFaceAnimLayer* FaceLayerPtr = InitFaceAnimLayer(CachedMeshComp, Sex);
	FaceAnim->Init(CachedMeshComp, FaceLayerPtr, EFaceAnimModeType::Frame, FaceAnimLayerTag);

	FString FinalFaceID(FaceAnimID);

	switch(Sex)
	{
		case EFaceAnimSexType::Male:
			FinalFaceID += SexName_Male;
			break;
		case EFaceAnimSexType::Female:
			FinalFaceID += SexName_Female;
			break;
	}

	FaceAnim->Play(FinalFaceID, FixTime, LipBlend);
}

void UFaceAnimComponent::SetLipFaceAnimCurFrameTime(float CurTime)
{
	if (FaceAnim)
	{
		FaceAnim->UpdateFrame(CurTime);
	}
}

void UFaceAnimComponent::OnCharacterAkEvent(class ABaseCharacter* InCharacter, const FString& in_EventName)
{
	//if(!FaceLipSync)
	//	return ;
	//FaceLipSync->Play(in_EventName);
}

void UFaceAnimComponent::LipSyncInit()
{
	if(!Character.IsValid())
		return ;

	//UCharacterEventDispatcher* EventDispatcher = Character->GetCharacterEventDispatcher();
	//if (EventDispatcher)
	//{
	//	FScriptDelegate AkEvent;
	//	AkEvent.BindUFunction(this, FName("OnCharacterAkEvent"));
	//	EventDispatcher->AkEventNotifyMD.AddUnique(AkEvent);
	//}

	if (!FaceLipSync)
		return ;

	FaceLipSync->InitLipSync(VisemeAssetInfo, Character->GetMesh());
}

void UFaceAnimComponent::LipSyncUpdate(float DeltaTime)
{
	if(!FaceLipSync)
		return ;
	FaceLipSync->Update(DeltaTime);
}

void UFaceAnimComponent::EyeControlInit()
{
}

void UFaceAnimComponent::EyeControlUpdate(float DeltaTime)
{
}