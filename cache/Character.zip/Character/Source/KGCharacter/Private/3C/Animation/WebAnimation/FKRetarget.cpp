// FKRetarget.cpp
// Forward Kinematics based motion retargeting for UE5
// Using UE5 FMatrix for rotation calculations
// Ported from Python implementation

#include "3C/Animation/WebAnimation/FKRetarget.h"
#include "Misc/FileHelper.h"
#include "Misc/Base64.h"
#include "Serialization/JsonSerializer.h"

// ============================================================================
// FFKRetarget Implementation
// ============================================================================

FFKRetarget::FFKRetarget()
    : bIsInitialized(false)
{
    InitializeJointNames();
}

FFKRetarget::~FFKRetarget()
{
}

void FFKRetarget::InitializeJointNames()
{
    // 初始化SMPL关节名称
    SMPLJoints = {
        TEXT("pelvis"), TEXT("left_hip"), TEXT("right_hip"), TEXT("spine1"),
        TEXT("left_knee"), TEXT("right_knee"), TEXT("spine2"), TEXT("left_ankle"),
        TEXT("right_ankle"), TEXT("spine3"), TEXT("left_foot"), TEXT("right_foot"),
        TEXT("neck"), TEXT("left_collar"), TEXT("right_collar"), TEXT("head"),
        TEXT("left_shoulder"), TEXT("right_shoulder"), TEXT("left_elbow"), TEXT("right_elbow"),
        TEXT("left_wrist"), TEXT("right_wrist"), TEXT("left_index1"), TEXT("left_index2"),
        TEXT("left_index3"), TEXT("left_middle1"), TEXT("left_middle2"), TEXT("left_middle3"),
        TEXT("left_pinky1"), TEXT("left_pinky2"), TEXT("left_pinky3"), TEXT("left_ring1"),
        TEXT("left_ring2"), TEXT("left_ring3"), TEXT("left_thumb1"), TEXT("left_thumb2"),
        TEXT("left_thumb3"), TEXT("right_index1"), TEXT("right_index2"), TEXT("right_index3"),
        TEXT("right_middle1"), TEXT("right_middle2"), TEXT("right_middle3"), TEXT("right_pinky1"),
        TEXT("right_pinky2"), TEXT("right_pinky3"), TEXT("right_ring1"), TEXT("right_ring2"),
        TEXT("right_ring3"), TEXT("right_thumb1"), TEXT("right_thumb2"), TEXT("right_thumb3")
    };

    // 初始化Skel关节名称
    SkelJoints = {
        TEXT("pelvis"), TEXT("thigh_l"), TEXT("thigh_r"), TEXT("spine_01"),
        TEXT("calf_l"), TEXT("calf_r"), TEXT("spine_02"), TEXT("ball_l"),
        TEXT("ball_r"), TEXT("spine_03"), TEXT("foot_l"), TEXT("foot_r"),
        TEXT("neck_01"), TEXT("clavicle_l"), TEXT("clavicle_r"), TEXT("head"),
        TEXT("upperarm_l"), TEXT("upperarm_r"), TEXT("lowerarm_l"), TEXT("lowerarm_r"),
        TEXT("hand_l"), TEXT("hand_r"), TEXT("index_01_l"), TEXT("index_02_l"),
        TEXT("index_03_l"), TEXT("middle_01_l"), TEXT("middle_02_l"), TEXT("middle_03_l"),
        TEXT("pinky_01_l"), TEXT("pinky_02_l"), TEXT("pinky_03_l"), TEXT("ring_01_l"),
        TEXT("ring_02_l"), TEXT("ring_03_l"), TEXT("thumb_01_l"), TEXT("thumb_02_l"),
        TEXT("thumb_03_l"), TEXT("index_01_r"), TEXT("index_02_r"), TEXT("index_03_r"),
        TEXT("middle_01_r"), TEXT("middle_02_r"), TEXT("middle_03_r"), TEXT("pinky_01_r"),
        TEXT("pinky_02_r"), TEXT("pinky_03_r"), TEXT("ring_01_r"), TEXT("ring_02_r"),
        TEXT("ring_03_r"), TEXT("thumb_01_r"), TEXT("thumb_02_r"), TEXT("thumb_03_r")
    };

    // 初始化Skel到SMPL的映射
    SkelToSMPLMap.Add(TEXT("pelvis"), TEXT("pelvis"));
    SkelToSMPLMap.Add(TEXT("spine_01"), TEXT("spine1"));
    SkelToSMPLMap.Add(TEXT("spine_02"), TEXT("spine2"));
    SkelToSMPLMap.Add(TEXT("spine_03"), TEXT("spine3"));
    SkelToSMPLMap.Add(TEXT("neck_01"), TEXT("neck"));
    SkelToSMPLMap.Add(TEXT("head"), TEXT("head"));
    SkelToSMPLMap.Add(TEXT("clavicle_l"), TEXT("left_collar"));
    SkelToSMPLMap.Add(TEXT("clavicle_r"), TEXT("right_collar"));
    SkelToSMPLMap.Add(TEXT("upperarm_l"), TEXT("left_shoulder"));
    SkelToSMPLMap.Add(TEXT("upperarm_r"), TEXT("right_shoulder"));
    SkelToSMPLMap.Add(TEXT("lowerarm_l"), TEXT("left_elbow"));
    SkelToSMPLMap.Add(TEXT("lowerarm_r"), TEXT("right_elbow"));
    SkelToSMPLMap.Add(TEXT("hand_l"), TEXT("left_wrist"));
    SkelToSMPLMap.Add(TEXT("hand_r"), TEXT("right_wrist"));
    SkelToSMPLMap.Add(TEXT("thigh_l"), TEXT("left_hip"));
    SkelToSMPLMap.Add(TEXT("thigh_r"), TEXT("right_hip"));
    SkelToSMPLMap.Add(TEXT("calf_l"), TEXT("left_knee"));
    SkelToSMPLMap.Add(TEXT("calf_r"), TEXT("right_knee"));
    SkelToSMPLMap.Add(TEXT("foot_l"), TEXT("left_ankle"));
    SkelToSMPLMap.Add(TEXT("foot_r"), TEXT("right_ankle"));
    SkelToSMPLMap.Add(TEXT("ball_l"), TEXT("left_foot"));
    SkelToSMPLMap.Add(TEXT("ball_r"), TEXT("right_foot"));
    SkelToSMPLMap.Add(TEXT("index_01_l"), TEXT("left_index1"));
    SkelToSMPLMap.Add(TEXT("index_02_l"), TEXT("left_index2"));
    SkelToSMPLMap.Add(TEXT("index_03_l"), TEXT("left_index3"));
    SkelToSMPLMap.Add(TEXT("middle_01_l"), TEXT("left_middle1"));
    SkelToSMPLMap.Add(TEXT("middle_02_l"), TEXT("left_middle2"));
    SkelToSMPLMap.Add(TEXT("middle_03_l"), TEXT("left_middle3"));
    SkelToSMPLMap.Add(TEXT("pinky_01_l"), TEXT("left_pinky1"));
    SkelToSMPLMap.Add(TEXT("pinky_02_l"), TEXT("left_pinky2"));
    SkelToSMPLMap.Add(TEXT("pinky_03_l"), TEXT("left_pinky3"));
    SkelToSMPLMap.Add(TEXT("ring_01_l"), TEXT("left_ring1"));
    SkelToSMPLMap.Add(TEXT("ring_02_l"), TEXT("left_ring2"));
    SkelToSMPLMap.Add(TEXT("ring_03_l"), TEXT("left_ring3"));
    SkelToSMPLMap.Add(TEXT("thumb_01_l"), TEXT("left_thumb1"));
    SkelToSMPLMap.Add(TEXT("thumb_02_l"), TEXT("left_thumb2"));
    SkelToSMPLMap.Add(TEXT("thumb_03_l"), TEXT("left_thumb3"));
    SkelToSMPLMap.Add(TEXT("index_01_r"), TEXT("right_index1"));
    SkelToSMPLMap.Add(TEXT("index_02_r"), TEXT("right_index2"));
    SkelToSMPLMap.Add(TEXT("index_03_r"), TEXT("right_index3"));
    SkelToSMPLMap.Add(TEXT("middle_01_r"), TEXT("right_middle1"));
    SkelToSMPLMap.Add(TEXT("middle_02_r"), TEXT("right_middle2"));
    SkelToSMPLMap.Add(TEXT("middle_03_r"), TEXT("right_middle3"));
    SkelToSMPLMap.Add(TEXT("pinky_01_r"), TEXT("right_pinky1"));
    SkelToSMPLMap.Add(TEXT("pinky_02_r"), TEXT("right_pinky2"));
    SkelToSMPLMap.Add(TEXT("pinky_03_r"), TEXT("right_pinky3"));
    SkelToSMPLMap.Add(TEXT("ring_01_r"), TEXT("right_ring1"));
    SkelToSMPLMap.Add(TEXT("ring_02_r"), TEXT("right_ring2"));
    SkelToSMPLMap.Add(TEXT("ring_03_r"), TEXT("right_ring3"));
    SkelToSMPLMap.Add(TEXT("thumb_01_r"), TEXT("right_thumb1"));
    SkelToSMPLMap.Add(TEXT("thumb_02_r"), TEXT("right_thumb2"));
    SkelToSMPLMap.Add(TEXT("thumb_03_r"), TEXT("right_thumb3"));
}

bool FFKRetarget::LoadRefPose(const FString& JsonString, TMap<FString, FRetargetJointRefPose>& OutRefPose)
{
    TSharedPtr<FJsonObject> JsonObject;
    TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(JsonString);
    
    if (!FJsonSerializer::Deserialize(Reader, JsonObject) || !JsonObject.IsValid())
    {
        UE_LOG(LogTemp, Error, TEXT("Failed to parse JSON in reference pose file"));
        return false;
    }

    OutRefPose.Empty();

    for (const auto& Pair : JsonObject->Values)
    {
        const FString& JointName = Pair.Key;
        const TSharedPtr<FJsonObject>& JointObj = Pair.Value->AsObject();

        FRetargetJointRefPose RefPose;
        RefPose.Name = JointName;
        if (!JointObj->TryGetStringField(TEXT("parent"), RefPose.Parent))
        {
            RefPose.Parent = TEXT("");
            UE_LOG(LogTemp, Log, TEXT("Joint '%s' has no valid 'parent' field. Defaulting to empty."), *JointName);
        }
        
        const TArray<TSharedPtr<FJsonValue>>& RotationArray = JointObj->GetArrayField(TEXT("rotation"));
		if (RotationArray.Num() == 3)
		{
            RefPose.Rotation = FVector(
                RotationArray[0]->AsNumber(),
                RotationArray[1]->AsNumber(),
                RotationArray[2]->AsNumber()
            );
		}
        OutRefPose.Add(JointName, RefPose);
    }

    return true;
}

bool FFKRetarget::Initialize(
    const FString& SourceRefPosePath,
    const FString& TargetRefPosePath)
{
    UE_LOG(LogTemp, Log, TEXT("Initializing FK Retargeter..."));

    FString SourceRefPoseJson;
    FString TargetRefPoseJson;
    if (!FFileHelper::LoadFileToString(SourceRefPoseJson, *SourceRefPosePath))
    {
        UE_LOG(LogTemp, Error, TEXT("Failed to load source reference pose from JSON file: %s"), *SourceRefPosePath);
        return false;
    }
    if (!FFileHelper::LoadFileToString(TargetRefPoseJson, *TargetRefPosePath))
    {
        UE_LOG(LogTemp, Error, TEXT("Failed to load target reference pose from JSON file: %s"), *TargetRefPosePath);
        return false;
    }
    return InitializeFromJson(SourceRefPoseJson, TargetRefPoseJson);
}

bool FFKRetarget::InitializeFromJson(
    const FString& SourceRefPoseJson,
    const FString& TargetRefPoseJson)
{
    UE_LOG(LogTemp, Log, TEXT("Initializing FK Retargeter from JSON..."));
    
    // 加载参考姿态
    if (!LoadRefPose(SourceRefPoseJson, SourceRefPose))
    {
        UE_LOG(LogTemp, Error, TEXT("Failed to load source reference pose from JSON"));
        return false;
    }
    
    if (!LoadRefPose(TargetRefPoseJson, TargetRefPose))
    {
        UE_LOG(LogTemp, Error, TEXT("Failed to load target reference pose from JSON"));
        return false;
    }

    // 预计算参考姿态的旋转矩阵
    SourceRefLocalRotMats.Empty();
    TargetRefLocalRotMats.Empty();
    
    for (const auto& Pair : SourceRefPose)
    {
        FMatrix RotMat = FUE5RotationUtils::EulerToMatrix(Pair.Value.Rotation);
        SourceRefLocalRotMats.Add(Pair.Key, RotMat);
    }
    
    for (const auto& Pair : TargetRefPose)
    {
        FMatrix RotMat = FUE5RotationUtils::EulerToMatrix(Pair.Value.Rotation);
        TargetRefLocalRotMats.Add(Pair.Key, RotMat);
    }
    
    bIsInitialized = true;
    UE_LOG(LogTemp, Log, TEXT("FK Retargeter initialized successfully"));
    UE_LOG(LogTemp, Log, TEXT("  Source joints: %d"), SourceRefPose.Num());
    UE_LOG(LogTemp, Log, TEXT("  Target joints: %d"), TargetRefPose.Num());
    return true;
}


void FFKRetarget::DecodeBase64ToFloatArray(const FString& Base64String, TArray<float>& FloatArray)
{
	// 解码Base64
	TArray<uint8> BinaryData;
	FBase64::Decode(Base64String, BinaryData);

	// 将二进制数据转换为float数组
	int32 NumFloats = BinaryData.Num() / sizeof(float);
	FloatArray.Reserve(NumFloats);

	const float* FloatPtr = reinterpret_cast<const float*>(BinaryData.GetData());
	for (int32 i = 0; i < NumFloats; i++)
	{
		FloatArray.Add(FloatPtr[i]);
	}
}

FString FFKRetarget::EncodeFloatArrayToBase64(const TArray<float>& FloatArray)
{
	// 将float数组转换为二进制数据
	TArray<uint8> BinaryData;
	BinaryData.SetNum(FloatArray.Num() * sizeof(float));
	FMemory::Memcpy(BinaryData.GetData(), FloatArray.GetData(), BinaryData.Num());
	
	// 编码为Base64
	FString Base64String = FBase64::Encode(BinaryData);
	return Base64String;
}

bool FFKRetarget::LoadPoseData(
    const FString& FilePath,
    TArray<float>& OutPoseData,
    int32& OutNumPeople,
    int32& OutNumFrames,
    TSharedPtr<FJsonObject>& OutOriginalJson)
{
    FString JsonString;
    if (!FFileHelper::LoadFileToString(JsonString, *FilePath))
    {
        UE_LOG(LogTemp, Error, TEXT("Failed to load pose data file: %s"), *FilePath);
        return false;
    }

    TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(JsonString);
    
    if (!FJsonSerializer::Deserialize(Reader, OutOriginalJson) || !OutOriginalJson.IsValid())
    {
        UE_LOG(LogTemp, Error, TEXT("Failed to parse JSON in pose data file: %s"), *FilePath);
        return false;
    }

    const TSharedPtr<FJsonObject>& ResultObj = OutOriginalJson->GetObjectField(TEXT("result"));
    
    FString PoseBase64 = ResultObj->GetStringField(TEXT("pose"));
    OutNumPeople = ResultObj->GetIntegerField(TEXT("num_people"));
    OutNumFrames = ResultObj->GetIntegerField(TEXT("num_frames"));
    DecodeBase64ToFloatArray(PoseBase64, OutPoseData);
    return true;
}

bool FFKRetarget::SaveRetargetedPose(
    const FString& FilePath,
    const TArray<float>& PoseData,
    int32 NumPeople,
    int32 NumFrames,
    int32 NumJoints,
    const TSharedPtr<FJsonObject>& OriginalJson)
{
    // 创建新的result对象，复制原始数据
    TSharedPtr<FJsonObject> NewResultObj = MakeShareable(new FJsonObject());
    const TSharedPtr<FJsonObject>& OriginalResultObj = OriginalJson->GetObjectField(TEXT("result"));
    
    // 复制所有字段
    for (const auto& Pair : OriginalResultObj->Values)
    {
        NewResultObj->SetField(Pair.Key, Pair.Value);
    }

    // 更新pose相关字段
    NewResultObj->SetNumberField(TEXT("num_people"), NumPeople);
    NewResultObj->SetNumberField(TEXT("num_frames"), NumFrames);
    NewResultObj->SetNumberField(TEXT("num_joints"), NumJoints);

    FString PoseBase64 = EncodeFloatArrayToBase64(PoseData);
    NewResultObj->SetStringField(TEXT("pose"), PoseBase64);

    // 创建输出JSON
    TSharedPtr<FJsonObject> OutputJson = MakeShareable(new FJsonObject());
    OutputJson->SetObjectField(TEXT("result"), NewResultObj);

    // 序列化为字符串
    FString OutputString;
    TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&OutputString);
    FJsonSerializer::Serialize(OutputJson.ToSharedRef(), Writer);

    // 保存文件
    if (!FFileHelper::SaveStringToFile(OutputString, *FilePath))
    {
        UE_LOG(LogTemp, Error, TEXT("Failed to save retargeted pose to file: %s"), *FilePath);
        return false;
    }

    UE_LOG(LogTemp, Log, TEXT("Retargeted pose saved to: %s"), *FilePath);
    return true;
}

FMatrix FFKRetarget::GetSourceLocalRotation(
    const FString& JointName,
    TMap<FString, FMatrix>& SourceLocalRotMats)
{
    if (SourceLocalRotMats.Contains(JointName))
    {
        return SourceLocalRotMats[JointName];
    }

    FMatrix RotMat = SourceRefLocalRotMats[JointName];
    SourceLocalRotMats.Add(JointName, RotMat);
    return RotMat;
}

FMatrix FFKRetarget::GetSourceWorldRotation(
    const FString& JointName,
    TMap<FString, FMatrix>& SourceWorldRotMats,
    TMap<FString, FMatrix>& SourceLocalRotMats)
{
    if (JointName.IsEmpty())
    {
        return FMatrix::Identity;
    }

    if (SourceWorldRotMats.Contains(JointName))
    {
        return SourceWorldRotMats[JointName];
    }

    const FString& ParentName = SourceRefPose[JointName].Parent;
    FMatrix ParentRotMat = GetSourceWorldRotation(
        ParentName, SourceWorldRotMats, SourceLocalRotMats
    );

    FMatrix WorldRotMat = ParentRotMat * GetSourceLocalRotation(
        JointName, SourceLocalRotMats
    );
    
    SourceWorldRotMats.Add(JointName, WorldRotMat);
    return WorldRotMat;
}

FMatrix FFKRetarget::GetTargetWorldRotation(
    const FString& JointName,
    TMap<FString, FMatrix>& TargetWorldRotMats,
    TMap<FString, FMatrix>& TargetLocalRotMats,
    const TMap<FString, FString>& TargetToSourceNameMap,
    TMap<FString, FMatrix>& SourceWorldRotMats,
    TMap<FString, FMatrix>& SourceLocalRotMats)
{
    if (JointName.IsEmpty())
    {
        return FMatrix::Identity;
    }

    if (TargetWorldRotMats.Contains(JointName))
    {
        return TargetWorldRotMats[JointName];
    }

    const FString& ParentName = TargetRefPose[JointName].Parent;
    FMatrix ParentRotMat = GetTargetWorldRotation(
        ParentName, TargetWorldRotMats, TargetLocalRotMats,
        TargetToSourceNameMap, SourceWorldRotMats, SourceLocalRotMats
    );

    FMatrix WorldRotMat = ParentRotMat * GetTargetLocalRotation(
        JointName, TargetToSourceNameMap, TargetLocalRotMats,
        SourceWorldRotMats, SourceLocalRotMats, TargetWorldRotMats
    );
    
    TargetWorldRotMats.Add(JointName, WorldRotMat);
    return WorldRotMat;
}

FMatrix FFKRetarget::GetTargetLocalRotation(
    const FString& JointName,
    const TMap<FString, FString>& TargetToSourceNameMap,
    TMap<FString, FMatrix>& TargetLocalRotMats,
    TMap<FString, FMatrix>& SourceWorldRotMats,
    TMap<FString, FMatrix>& SourceLocalRotMats,
    TMap<FString, FMatrix>& TargetWorldRotMats)
{
    if (TargetLocalRotMats.Contains(JointName))
    {
        return TargetLocalRotMats[JointName];
    }

    if (!TargetToSourceNameMap.Contains(JointName))
    {
        FMatrix RotMat = TargetRefLocalRotMats[JointName];
        TargetLocalRotMats.Add(JointName, RotMat);
        return RotMat;
    }

    const FString& SrcName = TargetToSourceNameMap[JointName];
    const FString& SrcParentName = SourceRefPose[SrcName].Parent;
    const FString& TgtParentName = TargetRefPose[JointName].Parent;

    // 核心重定向公式
    FMatrix TargetLocalRotMat = 
        GetTargetWorldRotation(TgtParentName, TargetWorldRotMats, TargetLocalRotMats,
            TargetToSourceNameMap, SourceWorldRotMats, SourceLocalRotMats).GetTransposed()
        * GetSourceWorldRotation(SrcParentName, SourceWorldRotMats, SourceLocalRotMats)
        * GetSourceLocalRotation(SrcName, SourceLocalRotMats)
        * SourceRefLocalRotMats[SrcName].GetTransposed()
        * GetSourceWorldRotation(SrcParentName, SourceWorldRotMats, SourceLocalRotMats).GetTransposed()
        * GetTargetWorldRotation(TgtParentName, TargetWorldRotMats, TargetLocalRotMats,
            TargetToSourceNameMap, SourceWorldRotMats, SourceLocalRotMats)
        * TargetRefLocalRotMats[JointName];

    TargetLocalRotMats.Add(JointName, TargetLocalRotMat);
    return TargetLocalRotMat;
}

void FFKRetarget::RetargetOneFrame(
    const TArray<FVector>& SourcePoseOneFrame,
    const TArray<FString>& SourceJointNames,
    const TArray<FString>& TargetJointNames,
    const TMap<FString, FString>& TargetToSourceNameMap,
    TArray<FVector>& OutTargetPoseOneFrame)
{
    // 初始化缓存字典
    TMap<FString, FMatrix> SourceWorldRotMats;
    TMap<FString, FMatrix> SourceLocalRotMats;
    TMap<FString, FMatrix> TargetWorldRotMats;
    TMap<FString, FMatrix> TargetLocalRotMats;

    // 初始化源骨骼的局部旋转
    for (const auto& Pair : SourceRefPose)
    {
        const FString& Name = Pair.Key;
        int32 Idx = SourceJointNames.Find(Name);
        
        if (Idx == INDEX_NONE)
        {
            SourceLocalRotMats.Add(Name, SourceRefLocalRotMats[Name]);
        }
        else
        {
            FVector RotVec = SourcePoseOneFrame[Idx];
            FMatrix RotMat = FUE5RotationUtils::RotVecToMatrix(RotVec);
            SourceLocalRotMats.Add(Name, RotMat);
        }
    }

    // 计算所有目标关节的局部旋转
    for (const FString& Name : TargetJointNames)
    {
        GetTargetLocalRotation(
            Name, TargetToSourceNameMap, TargetLocalRotMats,
            SourceWorldRotMats, SourceLocalRotMats, TargetWorldRotMats
        );
    }

    // 转换为角轴表示
    OutTargetPoseOneFrame.SetNum(TargetJointNames.Num());
    for (int32 i = 0; i < TargetJointNames.Num(); i++)
    {
        const FString& Name = TargetJointNames[i];
        FMatrix RotMat = TargetLocalRotMats[Name];
        FVector RotVec = FUE5RotationUtils::MatrixToRotVec(RotMat);
        OutTargetPoseOneFrame[i] = RotVec;
    }
}

bool FFKRetarget::RetargetMotion(
    const FString& InputPath,
    const FString& OutputPath)
{
    // 检查是否已初始化
    if (!bIsInitialized)
    {
        UE_LOG(LogTemp, Error, TEXT("FK Retargeter is not initialized. Please call Initialize() first."));
        return false;
    }

    // 加载姿态数据
    TArray<float> PoseData;
    int32 NumPeople, NumFrames;
    TSharedPtr<FJsonObject> OriginalJson;
    
    UE_LOG(LogTemp, Log, TEXT("Loading pose data from %s..."), *InputPath);
    if (!LoadPoseData(InputPath, PoseData, NumPeople, NumFrames, OriginalJson))
    {
        return false;
    }

    UE_LOG(LogTemp, Log, TEXT("Loaded %d people, %d frames"), NumPeople, NumFrames);

    // 准备输出数据
    int32 TargetNumJoints = SkelJoints.Num();
    TArray<float> OutputPoseData;
    RetargetMotionCore(
        PoseData, OutputPoseData, NumFrames, NumPeople, TargetNumJoints, TargetNumJoints
    );
    
    // 保存结果
    UE_LOG(LogTemp, Log, TEXT("Saving retargeted pose to %s..."), *OutputPath);
    if (!SaveRetargetedPose(OutputPath, OutputPoseData, NumPeople, NumFrames, TargetNumJoints, OriginalJson))
    {
        return false;
    }
	return true;
}

bool FFKRetarget::RetargetMotionCore(
    const TArray<float>& PoseData,
    TArray<float>& OutputPoseData,
    int32 NumFrames,
    int32 NumPeople,
    int32 SourceNumJoints,
    int32 TargetNumJoints
)
{
    OutputPoseData.SetNum(NumPeople * NumFrames * TargetNumJoints * 3);
    
	if (PoseData.Num() != NumPeople * NumFrames * SourceNumJoints * 3)
    {
        UE_LOG(LogTemp, Error, TEXT("Invalid pose data size. Expected %d, got %d"), 
            NumPeople * NumFrames * SourceNumJoints * 3, PoseData.Num());
        return false;
    }

    // 处理每个人的数据
    for (int32 PersonIdx = 0; PersonIdx < NumPeople; PersonIdx++)
    {
        // 处理每一帧
        for (int32 FrameIdx = 0; FrameIdx < NumFrames; FrameIdx++)
        {
            // 提取当前帧的源姿态
            TArray<FVector> SourcePoseOneFrame;
            SourcePoseOneFrame.SetNum(SMPLJoints.Num());
            
            for (int32 JointIdx = 0; JointIdx < SMPLJoints.Num(); JointIdx++)
            {
                int32 BaseIdx = (PersonIdx * NumFrames * SourceNumJoints + FrameIdx * SourceNumJoints + JointIdx) * 3;
                SourcePoseOneFrame[JointIdx] = FVector(
                    PoseData[BaseIdx + 0],
                    PoseData[BaseIdx + 1],
                    PoseData[BaseIdx + 2]
                );
            }

            // 执行重定向
            TArray<FVector> TargetPoseOneFrame;
            RetargetOneFrame(
                SourcePoseOneFrame, SMPLJoints, SkelJoints,
                SkelToSMPLMap, TargetPoseOneFrame
            );

            // 保存结果
            int32 OutputPersonIdx = PersonIdx;
            for (int32 JointIdx = 0; JointIdx < TargetNumJoints; JointIdx++)
            {
                int32 OutputBaseIdx = (OutputPersonIdx * NumFrames * TargetNumJoints + FrameIdx * TargetNumJoints + JointIdx) * 3;
                OutputPoseData[OutputBaseIdx + 0] = TargetPoseOneFrame[JointIdx].X;
                OutputPoseData[OutputBaseIdx + 1] = TargetPoseOneFrame[JointIdx].Y;
                OutputPoseData[OutputBaseIdx + 2] = TargetPoseOneFrame[JointIdx].Z;
            }
        }
    }
    return true;
}

void FFKRetarget::TestRotationFunctions()
{
    UE_LOG(LogTemp, Warning, TEXT("=== Testing FMatrix Rotation Functions ==="));
    
    // Test 1: 单位矩阵
    {
        FMatrix Identity = FMatrix::Identity;
        FVector Euler = FUE5RotationUtils::MatrixToEuler(Identity);
        UE_LOG(LogTemp, Warning, TEXT("Test 1 - Identity Matrix -> Euler: (%.6f, %.6f, %.6f)"),
            Euler.X, Euler.Y, Euler.Z);
    }
    
    // Test 2: 欧拉角往返
    {
        FVector OrigEuler(30.0f, 45.0f, 60.0f);
        FMatrix Mat = FUE5RotationUtils::EulerToMatrix(OrigEuler);
        FVector RecoveredEuler = FUE5RotationUtils::MatrixToEuler(Mat);
        
        UE_LOG(LogTemp, Warning, TEXT("Test 2 - Euler Roundtrip:"));
        UE_LOG(LogTemp, Warning, TEXT("  Original: (%.6f, %.6f, %.6f)"), 
            OrigEuler.X, OrigEuler.Y, OrigEuler.Z);
        UE_LOG(LogTemp, Warning, TEXT("  Recovered: (%.6f, %.6f, %.6f)"),
            RecoveredEuler.X, RecoveredEuler.Y, RecoveredEuler.Z);
        UE_LOG(LogTemp, Warning, TEXT("  Matrix:"));
        UE_LOG(LogTemp, Warning, TEXT("    [%.6f, %.6f, %.6f]"), Mat.M[0][0], Mat.M[0][1], Mat.M[0][2]);
        UE_LOG(LogTemp, Warning, TEXT("    [%.6f, %.6f, %.6f]"), Mat.M[1][0], Mat.M[1][1], Mat.M[1][2]);
        UE_LOG(LogTemp, Warning, TEXT("    [%.6f, %.6f, %.6f]"), Mat.M[2][0], Mat.M[2][1], Mat.M[2][2]);
    }
    
    // Test 3: 角轴向量往返 - 详细版本
    {
        FVector OrigRotVec(0.5f, 0.3f, 0.8f);
        float OrigAngle = OrigRotVec.Size();
        
        UE_LOG(LogTemp, Warning, TEXT("Test 3 - RotVec Roundtrip:"));
        UE_LOG(LogTemp, Warning, TEXT("  Original RotVec: (%.6f, %.6f, %.6f)"),
            OrigRotVec.X, OrigRotVec.Y, OrigRotVec.Z);
        UE_LOG(LogTemp, Warning, TEXT("  Angle: %.6f rad = %.2f deg"), 
            OrigAngle, FMath::RadiansToDegrees(OrigAngle));
        
        // 转换为矩阵
        FMatrix Mat = FUE5RotationUtils::RotVecToMatrix(OrigRotVec);
        
        UE_LOG(LogTemp, Warning, TEXT("  Matrix:"));
        UE_LOG(LogTemp, Warning, TEXT("    [%.6f, %.6f, %.6f]"), Mat.M[0][0], Mat.M[0][1], Mat.M[0][2]);
        UE_LOG(LogTemp, Warning, TEXT("    [%.6f, %.6f, %.6f]"), Mat.M[1][0], Mat.M[1][1], Mat.M[1][2]);
        UE_LOG(LogTemp, Warning, TEXT("    [%.6f, %.6f, %.6f]"), Mat.M[2][0], Mat.M[2][1], Mat.M[2][2]);
        
        // 计算 trace
        float Trace = Mat.M[0][0] + Mat.M[1][1] + Mat.M[2][2];
        UE_LOG(LogTemp, Warning, TEXT("  Trace: %.6f"), Trace);
        
        // 转换回角轴
        FVector RecoveredRotVec = FUE5RotationUtils::MatrixToRotVec(Mat);
        float RecoveredAngle = RecoveredRotVec.Size();
        
        UE_LOG(LogTemp, Warning, TEXT("  Recovered RotVec: (%.6f, %.6f, %.6f)"),
            RecoveredRotVec.X, RecoveredRotVec.Y, RecoveredRotVec.Z);
        UE_LOG(LogTemp, Warning, TEXT("  Recovered Angle: %.6f rad = %.2f deg"),
            RecoveredAngle, FMath::RadiansToDegrees(RecoveredAngle));
    }
    
    // Test 4: 与 Python 对比
    {
        FVector TestEuler(30.0f, 45.0f, 60.0f);
        FMatrix Mat = FUE5RotationUtils::EulerToMatrix(TestEuler);
        
        UE_LOG(LogTemp, Warning, TEXT("Test 4 - Compare with Python scipy:"));
        UE_LOG(LogTemp, Warning, TEXT("  Input Euler: (%.6f, %.6f, %.6f)"),
            TestEuler.X, TestEuler.Y, TestEuler.Z);
        UE_LOG(LogTemp, Warning, TEXT("  Matrix:"));
        UE_LOG(LogTemp, Warning, TEXT("    [%.6f, %.6f, %.6f]"), Mat.M[0][0], Mat.M[0][1], Mat.M[0][2]);
        UE_LOG(LogTemp, Warning, TEXT("    [%.6f, %.6f, %.6f]"), Mat.M[1][0], Mat.M[1][1], Mat.M[1][2]);
        UE_LOG(LogTemp, Warning, TEXT("    [%.6f, %.6f, %.6f]"), Mat.M[2][0], Mat.M[2][1], Mat.M[2][2]);
    }
    
    UE_LOG(LogTemp, Warning, TEXT("=== FMatrix Rotation Function Tests Complete ==="));
}



// ============================================================================
// FUE5RotationUtils Implementation
// ============================================================================

FMatrix FUE5RotationUtils::EulerToMatrix(const FVector& EulerDegrees)
{
    // 保持与原实现相同的XYZ顺序
    float X = FMath::DegreesToRadians(EulerDegrees.X);
    float Y = FMath::DegreesToRadians(EulerDegrees.Y);
    float Z = FMath::DegreesToRadians(EulerDegrees.Z);

    float CosX = FMath::Cos(X), SinX = FMath::Sin(X);
    float CosY = FMath::Cos(Y), SinY = FMath::Sin(Y);
    float CosZ = FMath::Cos(Z), SinZ = FMath::Sin(Z);

    // 外旋 XYZ 顺序: R = Rz(Z) * Ry(Y) * Rx(X)
    FMatrix Result = FMatrix::Identity;
    
    // 第一行
    Result.M[0][0] = CosY * CosZ;
    Result.M[0][1] = SinY * SinX * CosZ - SinZ * CosX;
    Result.M[0][2] = SinY * CosX * CosZ + SinZ * SinX;
    Result.M[0][3] = 0.0f;
    
    // 第二行
    Result.M[1][0] = CosY * SinZ;
    Result.M[1][1] = SinY * SinX * SinZ + CosZ * CosX;
    Result.M[1][2] = SinY * CosX * SinZ - SinX * CosZ;
    Result.M[1][3] = 0.0f;
    
    // 第三行
    Result.M[2][0] = -SinY;
    Result.M[2][1] = CosY * SinX;
    Result.M[2][2] = CosY * CosX;
    Result.M[2][3] = 0.0f;
    
    // 第四行（平移，保持为0）
    Result.M[3][0] = Result.M[3][1] = Result.M[3][2] = 0.0f;
    Result.M[3][3] = 1.0f;

    return Result;
}

FVector FUE5RotationUtils::MatrixToEuler(const FMatrix& Matrix)
{
    // 与原实现保持一致的提取逻辑
    float SinY = FMath::Clamp(-Matrix.M[2][0], -1.0f, 1.0f);
    float Y = FMath::Asin(SinY);
    float X, Z;
    
    float CosY = FMath::Cos(Y);
    
    if (FMath::Abs(CosY) < 1e-6f)
    {
        // Gimbal lock 情况
        Z = 0.0f;
        if (SinY > 0)
        {
            X = FMath::Atan2(-Matrix.M[1][2], Matrix.M[1][1]);
        }
        else
        {
            X = FMath::Atan2(Matrix.M[1][2], Matrix.M[1][1]);
        }
    }
    else
    {
        X = FMath::Atan2(Matrix.M[2][1], Matrix.M[2][2]);
        Z = FMath::Atan2(Matrix.M[1][0], Matrix.M[0][0]);
    }
    
    return FVector(
        FMath::RadiansToDegrees(X),
        FMath::RadiansToDegrees(Y),
        FMath::RadiansToDegrees(Z)
    );
}

FMatrix FUE5RotationUtils::RotVecToMatrix(const FVector& RotVec)
{
    // 使用相同的Rodrigues公式实现
    float Theta = RotVec.Size();

    if (Theta < 1e-6f)
    {
        return FMatrix::Identity;
    }

    FVector K = RotVec / Theta;
    float CosTheta = FMath::Cos(Theta);
    float SinTheta = FMath::Sin(Theta);
    float OneMinusCos = 1.0f - CosTheta;

    FMatrix Result = FMatrix::Identity;
    
    // Rodrigues公式的矩阵形式
    Result.M[0][0] = CosTheta + OneMinusCos * K.X * K.X;
    Result.M[0][1] = OneMinusCos * K.X * K.Y - SinTheta * K.Z;
    Result.M[0][2] = OneMinusCos * K.X * K.Z + SinTheta * K.Y;
    
    Result.M[1][0] = OneMinusCos * K.Y * K.X + SinTheta * K.Z;
    Result.M[1][1] = CosTheta + OneMinusCos * K.Y * K.Y;
    Result.M[1][2] = OneMinusCos * K.Y * K.Z - SinTheta * K.X;
    
    Result.M[2][0] = OneMinusCos * K.Z * K.X - SinTheta * K.Y;
    Result.M[2][1] = OneMinusCos * K.Z * K.Y + SinTheta * K.X;
    Result.M[2][2] = CosTheta + OneMinusCos * K.Z * K.Z;

    return Result;
}


// 在 FUE5RotationUtils 中添加矩阵正交化函数
FMatrix FUE5RotationUtils::OrthonormalizeMatrix(const FMatrix& Matrix)
{
    FMatrix Result = Matrix;
    
    // 获取三个轴向量
    FVector X(Result.M[0][0], Result.M[1][0], Result.M[2][0]);
    FVector Y(Result.M[0][1], Result.M[1][1], Result.M[2][1]);
    FVector Z(Result.M[0][2], Result.M[1][2], Result.M[2][2]);
    
    // Gram-Schmidt正交化
    X.Normalize();
    Y = Y - FVector::DotProduct(Y, X) * X;
    Y.Normalize();
    Z = FVector::CrossProduct(X, Y);
    Z.Normalize();
    
    // 重新构建矩阵
    Result.M[0][0] = X.X; Result.M[0][1] = Y.X; Result.M[0][2] = Z.X;
    Result.M[1][0] = X.Y; Result.M[1][1] = Y.Y; Result.M[1][2] = Z.Y;
    Result.M[2][0] = X.Z; Result.M[2][1] = Y.Z; Result.M[2][2] = Z.Z;
    
    return Result;
}

FVector FUE5RotationUtils::MatrixToRotVec(const FMatrix& Matrix)
{
    // 首先确保矩阵是正交的
    FMatrix OrthMatrix = OrthonormalizeMatrix(Matrix);
    
    float Trace = OrthMatrix.M[0][0] + OrthMatrix.M[1][1] + OrthMatrix.M[2][2];
    float CosTheta = FMath::Clamp((Trace - 1.0f) * 0.5f, -1.0f, 1.0f);
    float Theta = FMath::Acos(CosTheta);

    // 增加更严格的阈值检查
    const float EPSILON = 1e-8f;
    
    if (Theta < EPSILON)
    {
        return FVector::ZeroVector;
    }

    // 改进180度情况的处理
    if (FMath::Abs(Theta - PI) < EPSILON)
    {
        // 找到最大的对角元素
        int32 MaxIndex = 0;
        float MaxDiag = OrthMatrix.M[0][0];
        
        if (OrthMatrix.M[1][1] > MaxDiag)
        {
            MaxIndex = 1;
            MaxDiag = OrthMatrix.M[1][1];
        }
        if (OrthMatrix.M[2][2] > MaxDiag)
        {
            MaxIndex = 2;
            MaxDiag = OrthMatrix.M[2][2];
        }
        
        FVector K = FVector::ZeroVector;
        float Sqrt2 = FMath::Sqrt(2.0f);
        
        switch (MaxIndex)
        {
        case 0:
            K.X = FMath::Sqrt(FMath::Max(0.0f, (OrthMatrix.M[0][0] + 1.0f) * 0.5f));
            if (K.X > EPSILON)
            {
                K.Y = OrthMatrix.M[0][1] / (2.0f * K.X);
                K.Z = OrthMatrix.M[0][2] / (2.0f * K.X);
            }
            break;
        case 1:
            K.Y = FMath::Sqrt(FMath::Max(0.0f, (OrthMatrix.M[1][1] + 1.0f) * 0.5f));
            if (K.Y > EPSILON)
            {
                K.X = OrthMatrix.M[0][1] / (2.0f * K.Y);
                K.Z = OrthMatrix.M[1][2] / (2.0f * K.Y);
            }
            break;
        case 2:
            K.Z = FMath::Sqrt(FMath::Max(0.0f, (OrthMatrix.M[2][2] + 1.0f) * 0.5f));
            if (K.Z > EPSILON)
            {
                K.X = OrthMatrix.M[0][2] / (2.0f * K.Z);
                K.Y = OrthMatrix.M[1][2] / (2.0f * K.Z);
            }
            break;
        }
        
        return K * Theta;
    }

    // 一般情况 - 增加数值稳定性检查
    float SinTheta = FMath::Sin(Theta);
    if (FMath::Abs(SinTheta) < EPSILON)
    {
        return FVector::ZeroVector;
    }
    
    float Factor = Theta / (2.0f * SinTheta);
    
    FVector K(
        (OrthMatrix.M[2][1] - OrthMatrix.M[1][2]) * Factor,
        (OrthMatrix.M[0][2] - OrthMatrix.M[2][0]) * Factor,
        (OrthMatrix.M[1][0] - OrthMatrix.M[0][1]) * Factor
    );
    
    // 确保结果的数值稳定性
    if (K.SizeSquared() < EPSILON * EPSILON)
    {
        return FVector::ZeroVector;
    }
    
    return K;
}

