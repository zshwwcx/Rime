#include "3C/Animation/AnimNotify/AnimNotifyState_C7EnablePerfectDodge.h"

#include "KGCharacterModule.h"
#include "Misc/KGPlatformUtils.h"
#include "3C/Core/KGUEActorManager.h"
#include "Animation/AnimSequenceBase.h"
#include "3C/Component/PerfectDodgeComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Managers/KGCombatSettingsManager.h"

// 策划配置时只配置帧数, 运行时转化为时间, 这里留个cvar方便后续可能的调整
static int32 FrameCountPerSecond = 30;
static FAutoConsoleVariableRef CVarFrameCountPerSecond(
	TEXT("kg.PerfectDodge.FrameCountPerSecond"),
	FrameCountPerSecond,
	TEXT("FrameCountPerSecond."),
	ECVF_Default
);

void UAnimNotifyState_C7EnablePerfectDodge::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration,
	const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7EnablePerfectDodge::NotifyBegin");
	
	Super::NotifyBegin(MeshComp, Animation, TotalDuration, EventReference);

	if (!IsValid(MeshComp))
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAnimNotifyState_C7EnablePerfectDodge::NotifyBegin: MeshComp is invalid, %s"),
			IsValid(Animation) ? *Animation->GetPathName() : TEXT("null"));
		return;
	}

	if (KGPlatformUtils::IsInLevelPreviewWorld(MeshComp))
	{
		return;
	}
	
	UKGCombatSettingsManager* CombatSettingsManager = UKGCombatSettingsManager::GetInstance(MeshComp);
	if (!CombatSettingsManager)
	{
		return;
	}

	if (!CombatSettingsManager->IsPerfectDodgeEnabled())
	{
		UE_LOG(LogKGCombat, Log, TEXT("UAnimNotifyState_C7EnablePerfectDodge::NotifyBegin: PerfectDodge is disabled, %s"),
			IsValid(Animation) ? *Animation->GetPathName() : TEXT("null"));
		return;
	}

	AActor* OwnerActor = MeshComp->GetOwner();
	if (!IsValid(OwnerActor))
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAnimNotifyState_C7EnablePerfectDodge::NotifyBegin: MeshComp has no owner, %s"),
			*MeshComp->GetName());
		return;
	}
	
	// 只给主角开放
	auto* Entity = UKGUEActorManager::GetLuaEntityByActor(OwnerActor);
	if (!Entity)
	{
		return;
	}
	
	if (!Entity->GetIsMainPlayer())
	{
		return;
	}

	UPerfectDodgeComponent* PerfectDodgeComp = OwnerActor->FindComponentByClass<UPerfectDodgeComponent>();
	if (!PerfectDodgeComp)
	{
		PerfectDodgeComp = NewObject<UPerfectDodgeComponent>(OwnerActor);
		if (!IsValid(PerfectDodgeComp))
		{
			UE_LOG(LogKGCombat, Error, TEXT("UAnimNotifyState_C7EnablePerfectDodge::NotifyBegin: Create PerfectDodgeComponent failed, %s"),
				*OwnerActor->GetName());
			return;
		}
		PerfectDodgeComp->RegisterComponent();
	}

	const bool bResult = PerfectDodgeComp->EnablePerfectDodge(ActiveFrames / static_cast<float>(FrameCountPerSecond));
	if (bResult)
	{
		EnabledPerfectDodgeComps.Add(MeshComp);
	}
	else
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAnimNotifyState_C7EnablePerfectDodge::NotifyBegin: EnablePerfectDodge failed, %s, %s"),
			*OwnerActor->GetName(), IsValid(Animation) ? *Animation->GetPathName() : TEXT("null"));
	}
}

void UAnimNotifyState_C7EnablePerfectDodge::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation,
	const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7EnablePerfectDodge::NotifyEnd");
	
	EndPerfectDodge(MeshComp, Animation);
	
	Super::NotifyEnd(MeshComp, Animation, EventReference);
}

void UAnimNotifyState_C7EnablePerfectDodge::EndPerfectDodge(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	if (!IsValid(MeshComp))
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAnimNotifyState_C7EnablePerfectDodge::EndPerfectDodge: MeshComp is invalid, %s"),
			IsValid(Animation) ? *Animation->GetPathName() : TEXT("null"));
		return;
	}
	
	if (KGPlatformUtils::IsInLevelPreviewWorld(MeshComp))
	{
		return;
	}

	if (!EnabledPerfectDodgeComps.Contains(MeshComp))
	{
		return;
	}
	EnabledPerfectDodgeComps.Remove(MeshComp);
	
	AActor* OwnerActor = MeshComp->GetOwner();
	if (!IsValid(OwnerActor))
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAnimNotifyState_C7EnablePerfectDodge::EndPerfectDodge: MeshComp has no owner, %s"),
			*MeshComp->GetName());
		return;
	}
	
	auto* Entity = UKGUEActorManager::GetLuaEntityByActor(OwnerActor);
	if (!Entity)
	{
		return;
	}
	
	if (!Entity->GetIsMainPlayer())
	{
		return;
	}

	UPerfectDodgeComponent* PerfectDodgeComp = OwnerActor->FindComponentByClass<UPerfectDodgeComponent>();
	if (!PerfectDodgeComp)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAnimNotifyState_C7EnablePerfectDodge::EndPerfectDodge: owner has no perfect dodge component, %s"),
			*MeshComp->GetName());
		return;
	}

	const bool bResult = PerfectDodgeComp->DisablePerfectDodge();
	UE_CLOG(!bResult, LogKGCombat, Error, TEXT("UAnimNotifyState_C7EnablePerfectDodge::EndPerfectDodge: DisablePerfectDodge failed, %s, %s"),
		*OwnerActor->GetName(), IsValid(Animation) ? *Animation->GetPathName() : TEXT("null"));
}
