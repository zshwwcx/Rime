#include "3C/Animation/AnimLayer/BaseAnimLayer.h"


UBaseAnimLayer::UBaseAnimLayer(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer){
}
