// Copyright Epic Games, Inc. All Rights Reserved.

// #pragma once

#include "3C/Movement/RoleMovementComponent.h"
#include "3C/Animation/AnimNotify/Movement/IAnimNotify_MovementControlInterface.h"


URoleMovementComponent* IAnimNotify_MovementControlInterface::GetMovementAuthorityControlRMC(URoleMovementComponent* NotifyRMC)
{
	if(NotifyRMC == nullptr)
	{
		return nullptr;
	}
	return NotifyRMC->GetRealMovementControlViewProxy();
}
