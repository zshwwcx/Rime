#include "3C/Animation/AnimCommon.h"

#include "3C/Character/BaseCharacter.h"
#include "UObject/ObjectRedirector.h"
#include "3C/RoleComposite/RoleCompositeManager.h"
#include "3C/Util/3CSettings.h"
#include "Animation/AnimInstance.h"
#include "Animation/AnimMontage.h"
#include "Animation/AnimSequenceBase.h"
#include "Components/SkeletalMeshComponent.h"


#if WITH_EDITOR
void GetEnumString(FSoftObjectPath AssetRef, TArray<FString>& OutNameList)
{
	FTopLevelAssetPath AssetRefPathNamePreResolve = AssetRef.GetAssetPath();
	UObject* Obj = AssetRef.ResolveObject();
	if (Obj == nullptr)
	{
		Obj = AssetRef.TryLoad();
	}

	if (Obj != nullptr)
	{
		UEnum* Enum = Cast<UEnum>(Obj);
		if (Enum != nullptr)
		{
			int32 Num = Enum->NumEnums();
			for (int32 i(0); i < Num - 1; ++i)
			{
				OutNameList.Add(Enum->GetDisplayNameTextByIndex(i).ToString());
			}
		}

		UObjectRedirector* Redirector = FindObject<UObjectRedirector>(nullptr, *AssetRefPathNamePreResolve.ToString());
		bool bRedirectorFollowed = Redirector && (Redirector->DestinationObject == Obj);
		if (!bRedirectorFollowed && Obj->GetPathName() != AssetRefPathNamePreResolve.ToString())
		{
			UE_LOG(LogTemp, Warning, TEXT("GetAnimAssetNameList parameter/payload enum has moved from where it was in settings (this may cause errors at runtime): Was: \"%s\" Now: \"%s\""), *AssetRefPathNamePreResolve.ToString(), *Obj->GetPathName());
		}
	}
}


void FAnimAssetID::GetAnimAssetNameList(int AssetCategory, TArray<FString>& OutNameList)
{
	U3CSettings* GameSettings = GetMutableDefault<U3CSettings>(U3CSettings::StaticClass());
	if (!GameSettings)
		return;

	TArray<FString> NameList;

	FSoftObjectPath* SoftObjP = GameSettings->EAnimIDMap.Find(GameSettings->LocoEnumCategoryIndexToString(AssetCategory));
	if (SoftObjP)
	{
		GetEnumString(*SoftObjP, NameList);
	}

	OutNameList.Append(NameList);
}

void FAnimAssetID::GetAnimCategoryList(TArray<FString>& OutNameList)
{
	TArray<FString> NameList;

	U3CSettings* GameSettings = GetMutableDefault<U3CSettings>(U3CSettings::StaticClass());
	if (!GameSettings)
	{
		return;
	}

	UObject* LocoEnumCategory = GameSettings->AnimLocoEnumCategory.ResolveObject();
	if (LocoEnumCategory == nullptr)
	{
		LocoEnumCategory = GameSettings->AnimLocoEnumCategory.TryLoad();
	}

	if(UEnum* CategoryEnum = Cast<UEnum>(LocoEnumCategory))
	{
		int Max = CategoryEnum->NumEnums();
		for(int Index = 0; Index < Max - 1; ++Index)
		{
			OutNameList.Emplace(CategoryEnum->GetDisplayNameTextByIndex(Index).ToString());
		}
	}

}

#endif

bool UAnimCommonUtility::IsLeftFootState(const float& CurFootCurveValue, const float& LastFootCurveValue)
{
	return (CurFootCurveValue - LastFootCurveValue) > 0;
}

void UAnimCommonUtility::AddMetaDataCurveRuntime(UAnimSequenceBase* Anim,FName& CurveName)
{
	if(Anim)
	{
		Anim->AddMetaDataCurveRuntime(CurveName);
	}
}


//void UAnimCommonUtility::DestoryObject(UObject* Obj)
//{
//	if(!Obj)
//		return ;
//
//	Obj->MarkAsGarbage();
//	Obj->ConditionalBeginDestroy();
//}

class UAnimMontage* UAnimCommonUtility::CreateDynamicMontage(const FDynamicMontageParam& CreateParam)
{
	 UAnimMontage* DM = UAnimMontage::CreateSlotAnimationAsDynamicMontage(CreateParam.Asset, CreateParam.SlotNodeName,
	   CreateParam.BlendInTime, CreateParam.BlendOutTime, CreateParam.InPlayRate,
	   CreateParam.LoopCount, CreateParam.BlendOutTriggerTime, CreateParam.InTimeToStartMontageAt);
	if (DM)
	{
		for(auto CurveName:CreateParam.MetaCurves)
		{
			DM->AddMetaDataCurveRuntime(CurveName);
		}
	}
	return DM;
}




UAnimLayerSharedData::UAnimLayerSharedData(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}


void UAnimLayerSharedData::Reset(UAnimLayerContext* InLayerContext)
{
	AnimLayerContext = InLayerContext;
	MarkRefreshedSet.Empty();
}

bool UAnimLayerSharedData::CheckRefreshed(int64 Address)
{
	return MarkRefreshedSet.Contains(Address);
}

void UAnimLayerSharedData::MarkRefreshed(int64 Address)
{
	MarkRefreshedSet.Add(Address);
}

UAnimLayerContext::UAnimLayerContext(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	AnimLayerSharedData = CreateDefaultSubobject<UAnimLayerSharedData>(TEXT("AnimLayerSharedData"));
}

void FSharedMovementInfo::FreshData(const UAnimLayerContext* InLayerContext)
{
	if(!InLayerContext || !InLayerContext->Character.IsValid())
		return ;

	TWeakObjectPtr<AActor> Character = InLayerContext->Character;

	if (InLayerContext->BaseCharacter.IsValid())
	{
		VelocityDir = InLayerContext->BaseCharacter->GetVelocity();
		Speed = VelocityDir.Size();
		VelocityDir = VelocityDir.GetSafeNormal();
	}

	Pos = Character->GetActorLocation();
	FRotator Rotator = Character->GetActorRotation();
	UpDir = FRotationMatrix(Rotator).GetScaledAxis(EAxis::Z);
	ForwardDir = Rotator.Vector();
	RightDir = FRotationMatrix(Rotator).GetScaledAxis(EAxis::Y);
}

//
//
// void FSharedBoneTransformInfo::FreshData(const UAnimLayerContext* InLayerContext)
// {
// 	if(!InLayerContext || !InLayerContext->SMC.IsValid())
// 		return ;
//
// 	const TWeakObjectPtr<class USkeletalMeshComponent>& Smc = InLayerContext->SMC;
//
// 	int32 RootIndex = Smc->GetBoneIndex(FName("Root"));
// 	FRotator RootRotator = Smc->GetBoneTransform(RootIndex).GetRelativeTransform(Smc->GetComponentTransform()).Rotator();
// 	FName FaceBoneName("head");
// 	// if (RootRotator.Pitch < -45 || RootRotator.Pitch > 45)
// 	// {
// 	// 	FaceBoneName = FName("FaceDir");
// 	// }
//
// 	FTransform FaceTf = Smc->GetSocketTransform(FaceBoneName, ERelativeTransformSpace::RTS_World);
// 	FaceRotator = FaceTf.GetRotation().Rotator();
// 	FacePos = FaceTf.GetTranslation();
//
// 	RootPos = Smc->GetSocketLocation("Root");
// 	IKFootLTF = Smc->GetSocketTransform("ik_foot_l", ERelativeTransformSpace::RTS_World);
// 	IKFootRTF = Smc->GetSocketTransform("ik_foot_r", ERelativeTransformSpace::RTS_World);
//
// 	Eye_l = Smc->GetSocketTransform("lf_eyeBall_01", ERelativeTransformSpace::RTS_World);
// 	Eye_R = Smc->GetSocketTransform("rt_eyeBall_01", ERelativeTransformSpace::RTS_World);
// }

int32 UAnimLayerContext::GetPropValue(const FString& PropName)
{
	int32* Value = PropIntValueMap.Find(PropName);
	if (Value)
	{
		return *Value;
	}

	return 0;
}


