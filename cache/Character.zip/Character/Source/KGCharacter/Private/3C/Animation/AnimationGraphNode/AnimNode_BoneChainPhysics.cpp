#include "3C/Animation/AnimationGraphNode/AnimNode_BoneChainPhysics.h"
#include "Animation/AnimInstanceProxy.h"
#include "Kismet/KismetMathLibrary.h"

//PRAGMA_DISABLE_OPTIMIZATION

void FAnimNode_BoneChainPhysics::Initialize_AnyThread(const FAnimationInitializeContext & Context)
{
	FAnimNode_SkeletalControlBase::Initialize_AnyThread(Context);
	FBoneContainer& RequiredBones = Context.AnimInstanceProxy->GetRequiredBones();

	InitializeBoneReferences(RequiredBones);
	
	PhysicsBoneData.Empty();

	DeltaTime = .0f;

	LastDeltaTime = 0.03f;

	WindWaveElapsedTime = .0f;
}


void FAnimNode_BoneChainPhysics::UpdateInternal(const FAnimationUpdateContext & Context)
{
	FAnimNode_SkeletalControlBase::UpdateInternal(Context);

	DeltaTime = Context.GetDeltaTime();
}

void FAnimNode_BoneChainPhysics::EvaluateSkeletalControl_AnyThread(FComponentSpacePoseContext & Output, TArray<FBoneTransform>& OutBoneTransforms)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimNode_BoneChainPhysics::EvaluateSkeletalControl_AnyThread");
	if (DeltaTime <= 0.0f || RootBone.CachedCompactPoseIndex == INDEX_NONE)
		return ;

	const FBoneContainer& BoneContainer = Output.Pose.GetPose().GetBoneContainer();
	FTransform ComponentTransform = Output.AnimInstanceProxy->GetComponentTransform();

	CurGravity = ComponentTransform.InverseTransformVector(Gravity);

	if (PhysicsBoneData.Num() <= 0)
	{
		InitChainBoneInfo(Output, BoneContainer);

		LastCompTransform = ComponentTransform;
	}

	CurCompRotation = ComponentTransform.InverseTransformRotation(LastCompTransform.GetRotation());
	CurCompMoveVector = ComponentTransform.InverseTransformPosition(LastCompTransform.GetLocation());

	LastCompTransform = ComponentTransform;

	CompleteCalculate(Output);

	ApplyCalculateResult(Output, OutBoneTransforms);

}

bool FAnimNode_BoneChainPhysics::IsValidToEvaluate(const USkeleton * Skeleton, const FBoneContainer & RequiredBones)
{
	return true;
}

void FAnimNode_BoneChainPhysics::InitializeBoneReferences(const FBoneContainer & RequiredBones)
{
	RootBone.Initialize(RequiredBones);
}

void FAnimNode_BoneChainPhysics::InitChainBoneInfo(FComponentSpacePoseContext& Output, const FBoneContainer & RequiredBones)
{
	PhysicsBoneData.Empty();

	USkeleton* Skeleton = RequiredBones.GetSkeletonAsset();
	if(!Skeleton)
		return ;

	FTransform ComponentTransform = Output.AnimInstanceProxy->GetComponentTransform();

	const FReferenceSkeleton& RefSkeleton = Skeleton->GetReferenceSkeleton();

	int32 RootIndex = RefSkeleton.FindBoneIndex(RootBone.BoneName);

	TArray<int32> ChildList;
	ChildList.Add(RootIndex);
	GetRootChildList(RefSkeleton, RootIndex, ChildList);

	//PhysicsBoneData.SetNum(ChildList.Num());
	 
	for (int32 i(0); i < ChildList.Num(); ++i)
	{
		const int32& BoneIndex = ChildList[i];

		FPhysicsBoneData BoneData;

		FBoneReference BoneRef;
		BoneRef.BoneName = RefSkeleton.GetBoneName(BoneIndex);

		BoneData.Bone = BoneRef;
		if(!BoneData.Bone.Initialize(RequiredBones))
			continue;

		// 可能因为lod cull掉骨骼, 上面Inialize是成功的, 但是真正的骨骼运行时索引是没有的
		// 这里好像没有用, 下面计算的时候, 都没有用到这些数据
		if(INDEX_NONE != BoneData.Bone.CachedCompactPoseIndex)
		{
			const FTransform& BoneCSTransform = Output.Pose.GetComponentSpaceTransform(BoneData.Bone.CachedCompactPoseIndex);
			const FTransform& BoneLocTransform = Output.Pose.GetLocalSpaceTransform(BoneData.Bone.CachedCompactPoseIndex);
			BoneData.LocPos = BoneLocTransform.GetLocation();
			BoneData.wPos = ComponentTransform.TransformPosition(BoneCSTransform.GetLocation());
			BoneData.LocRot = BoneLocTransform.GetRotation();
			BoneData.wRot = ComponentTransform.TransformRotation(BoneCSTransform.GetRotation());

			BoneData.CPos = BoneCSTransform.GetLocation();
			BoneData.CRot = BoneCSTransform.GetRotation();
			BoneData.BoneScale = BoneCSTransform.GetScale3D();
		}
	
		//
		{
			BoneData.PhysicsConfig = PhysicsConfig;

			const FBoneInfoConfig* BoneIC = BoneChainConfig.Find(BoneData.Bone.BoneName);
			if (BoneIC)
			{
				BoneData.BoneConfig = *BoneIC;
			}
			
		}

		PhysicsBoneData.Add(BoneData);
	}

	for (int32 i(1); i < PhysicsBoneData.Num(); ++i)
	{
		FPhysicsBoneData& BoneData = PhysicsBoneData[i - 1];
		const FPhysicsBoneData& ChildBoneData = PhysicsBoneData[i];
		BoneData.CurCalwPos = BoneData.CPos;
		BoneData.LastCalwPos = BoneData.CPos;
		BoneData.SpringLen = (BoneData.wPos - ChildBoneData.wPos).Size();
	}
}

void FAnimNode_BoneChainPhysics::CompleteCalculate(FComponentSpacePoseContext & Output)
{
	float sqDt = DeltaTime * DeltaTime;
	if(sqDt <= .0f)
		return ;

	WindWaveElapsedTime += DeltaTime * WindWaveSpeed;
	if (WindWaveElapsedTime > 360)
	{
		WindWaveElapsedTime = 0;
	}

	FTransform ComponentTransform = Output.AnimInstanceProxy->GetComponentTransform();

	FVector ParentPos = FVector::ZeroVector;
	FQuat ParentRot = FQuat::Identity;
	FVector ParentCPos = FVector::ZeroVector;
	FQuat ParentCRot = FQuat::Identity;
	FVector ParentOrPos = FVector::ZeroVector;
	FQuat ParentOrRot = FQuat::Identity;

	FVector CurWindDir(WindDir);
	if (Coordinate == EWindCoordinateSystem::World)
	{
		CurWindDir = ComponentTransform.InverseTransformVector(WindDir);
	}

	for (int32 i(0); i < PhysicsBoneData.Num(); ++i)
	{
		FPhysicsBoneData& BD = PhysicsBoneData[i];

		// 需要每次去拿, 因为lod会变, 导致CachedCompactPoseIndex结果有变动
		if(!BD.Bone.Initialize(Output.AnimInstanceProxy->GetRequiredBones()))
			continue;
		
		if(BD.Bone.CachedCompactPoseIndex == INDEX_NONE)
		{
			continue;
		}
		
		const FTransform& BoneCSTransform = Output.Pose.GetComponentSpaceTransform(BD.Bone.CachedCompactPoseIndex);
		if (i == 0)
		{
			BD.wPos = ComponentTransform.TransformPosition(BoneCSTransform.GetLocation());
			BD.wRot = ComponentTransform.TransformRotation(BoneCSTransform.GetRotation());

			//BD.CPos = ComponentTransform.InverseTransformPosition(BD.wPos);
			//BD.CRot = ComponentTransform.InverseTransformRotation(BD.wRot);
			BD.CPos = BoneCSTransform.GetTranslation();
			BD.CRot = BoneCSTransform.GetRotation();
			ParentPos = BD.wPos;
			ParentRot = BD.wRot;
			ParentCPos = BD.CPos;
			ParentCRot = BD.CRot;
			ParentOrPos = BD.CPos;
			ParentOrRot = BD.CRot;
			continue;
		}

		const FPhysicsConfig& C = BD.PhysicsConfig;
		const FBoneInfoConfig& BInfo = BD.BoneConfig;

		//BD.CPos = ComponentTransform.InverseTransformPosition(BD.wPos);
		FVector CPos = BD.CPos;
		//BD.CRot = ComponentTransform.InverseTransformRotation(BD.wRot);
		FVector LastCPos = BD.CurCalwPos;

		FVector OrPos = Output.Pose.GetComponentSpaceTransform(BD.Bone.CachedCompactPoseIndex).GetLocation();
		FQuat OrRot = Output.Pose.GetComponentSpaceTransform(BD.Bone.CachedCompactPoseIndex).GetRotation();

		BD.CurCalwPos = CPos;
		FVector fDir = (BD.CPos - LastCPos) / LastDeltaTime;
		fDir *= (1 - C.Drag) ;

		if (EnableWind)
		{
			FVector WindVelocity = CurWindDir * WindStrength;
			float Angle = WindWaveElapsedTime;
			float WindForce(1.0f);
			if (WindWaveCurve)
			{
				WindForce = WindWaveCurve->GetFloatValue(Angle);
			}
			else
			{
				WindForce = FMath::Sin(FMath::DegreesToRadians(Angle));
			}
			
			WindForce = FMath::Clamp<float>(WindForce, 0, 1);

			WindVelocity *= WindForce;
			
			fDir += WindVelocity;
		}

		BD.CPos += fDir * DeltaTime;

		//BD.CPos += CurCompMoveVector * ( 1 - Damp);

		FVector fCent =  (CurCompRotation.RotateVector(LastCPos) - LastCPos) *  C.RotationDamp;
		BD.CPos += fCent;
		fCent = LastCPos.GetSafeNormal2D() * fCent.Size() * C.Centrifugal;
		BD.CPos += fCent;

		BD.CPos += Gravity * DeltaTime;

		

		FVector TCPos = ParentCPos + ( OrPos - ParentOrPos);
		BD.CPos += (TCPos - BD.CPos) * (1 - FMath::Pow(1.0f - C.Stiffness, 60 * DeltaTime));

		BD.CPos = (BD.CPos - TCPos) * BInfo.Weight + TCPos;

		BD.CPos = (BD.CPos - ParentCPos).GetSafeNormal() * BD.SpringLen + ParentCPos;

		FVector OrDir = OrPos - ParentOrPos;
		FVector CurDir = BD.CPos - ParentCPos;

		BD.CRot = FQuat::FindBetweenVectors(OrDir, CurDir) * ParentOrRot;

		//FVector LocPos = BD.LocPos * BD.BoneScale;
		//FQuat LocRot = BD.LocRot;

		//FVector wPos = ParentPos + ParentRot * LocPos;
		//FQuat wRot = ParentRot * LocRot;

		//const FPhysicsConfig& C = BD.Config;

		//FVector fDir = (wRot * (C.BoneAxis * C.Stiffness)) / sqDt;
		//fDir += (BD.LastCalwPos - BD.CurCalwPos) * C.Drag / sqDt;
		//fDir += C.SpringForce / sqDt;

		////fDir += CurGravity / sqDt;

		//FVector TCurwPos = BD.CurCalwPos;
		//
		//FPhysicsBoneData TBD = BD;

		//TBD.CurCalwPos = (TBD.CurCalwPos - TBD.LastCalwPos) + TBD.CurCalwPos + (fDir * sqDt);
		//
		////TBD.CurCalwPos += (CurCompRotation.RotateVector(TBD.CPos) - TBD.CPos) * (1.0f - Damp);

		//TBD.CurCalwPos = (TBD.CurCalwPos - wPos).GetSafeNormal() * TBD.SpringLen + wPos;

		//
		//TBD.LastCalwPos = TCurwPos;

		//FVector A = (ParentRot * C.BoneAxis).GetSafeNormal();
		//FVector B = (TBD.CurCalwPos - wPos).GetSafeNormal();
		//float ABLen = (A - B).Size();


		//FQuat TargetRot = UKismetMathLibrary::FindLookAtRotation(A, B).Quaternion();

		//TargetRot = FQuat::FindBetweenVectors(A, B);

		//FVector C1 = TargetRot * A;


		//TBD.wPos = ParentPos + ParentRot * LocPos;
		//TBD.wRot = FQuat::FastLerp(TBD.wRot, ParentRot * TargetRot, 1);

		//ParentPos = TBD.wPos;
		//ParentRot = TBD.wRot;
		ParentCPos = BD.CPos;
		ParentCRot = BD.CRot;

		ParentOrPos = OrPos;
		ParentOrRot = OrRot;
		//BD = TBD;

		//BD.CPos = ComponentTransform.InverseTransformPosition(BD.wPos);
		//BD.CRot = ComponentTransform.InverseTransformRotation(BD.wRot);

		LastDeltaTime = DeltaTime;
	}
}

void FAnimNode_BoneChainPhysics::ApplyCalculateResult(FComponentSpacePoseContext& Output, TArray<FBoneTransform>& OutBoneTransforms)
{
	for (int32 i(0); i < PhysicsBoneData.Num(); ++i)
	{
		FPhysicsBoneData& BD = PhysicsBoneData[i];
		if (BD.CPos.ContainsNaN())
		{
			BD.CPos = BD.LocPos;
		}
		OutBoneTransforms.Add(FBoneTransform(BD.Bone.CachedCompactPoseIndex,
			FTransform(BD.CRot, BD.CPos, BD.BoneScale)));
	}

	OutBoneTransforms.Sort(FCompareBoneTransformIndex());
}


void FAnimNode_BoneChainPhysics::GetRootChildList(const FReferenceSkeleton& RefSkeleton, int32 ParentBoneIndex, TArray<int32>& ChildList)
{
	const int32 NumBones = RefSkeleton.GetNum();
	for (int32 ChildIndex = ParentBoneIndex + 1; ChildIndex < NumBones; ChildIndex++)
	{
		if (ParentBoneIndex == RefSkeleton.GetParentIndex(ChildIndex))
		{
			ChildList.AddUnique(ChildIndex);
			GetRootChildList(RefSkeleton, ChildIndex, ChildList);
			break;
		}
	}
}

//PRAGMA_ENABLE_OPTIMIZATION