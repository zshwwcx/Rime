#include "3C/Animation/AnimNotify/AnimNotifyState_C7ChangeMaterial.h"

#include "Misc/KGPlatformUtils.h"
#include "3C/RoleComposite/RoleCompositeManager.h"
#include "Components/SkeletalMeshComponent.h"
#include "3C/Material/KGMaterialManager.h"

void UAnimNotifyState_C7ChangeMaterial::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7ChangeMaterial::NotifyBegin");
	
	Super::NotifyBegin(MeshComp, Animation, TotalDuration, EventReference);

	if (!IsValid(MeshComp))
	{
		UE_LOG(LogKGMaterial, Error, TEXT("UAnimNotifyState_C7ChangeMaterial::NotifyBegin: MeshComp is invalid, %s"),
			IsValid(Animation) ? *Animation->GetPathName() : TEXT("null"));
		return;
	}

	if (KGPlatformUtils::IsInLevelPreviewWorld(MeshComp))
	{
		return;
	}
	
	if (UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(MeshComp))
	{
		FKGChangeMaterialRequest ChangeMaterialRequest;
		ChangeMaterialRequest.MaterialPath = MaterialPath.ToString();
		ChangeMaterialRequest.SearchMeshType = SearchMeshType;
		if (SearchMeshType == EKGSearchMeshType::SearchMeshByName)
		{
			ChangeMaterialRequest.SearchMeshName = URoleCompositeMgr::AvatarBodyPartEnumToName(static_cast<int32>(ComponentTag));
		}

		ChangeMaterialRequest.SearchMaterialType = SearchMaterialType;
		if (SearchMaterialType == EKGSearchMaterialType::SearchMaterialBySlots)
		{
			ChangeMaterialRequest.MaterialSlotNames = MaterialSlotNames;
		}
		ChangeMaterialRequest.OwnerActor = MeshComp->GetOwner();
		ChangeMaterialRequest.Priority = Priority;
		
		if (LifeTimeMode == EKGChangeMaterialLifeTimeMode::FixedTime)
		{
			ChangeMaterialRequest.TotalLifeTimeMs = Duration * 1000.0f;
		}

		const auto ReqID = MaterialManager->ChangeMaterial(ChangeMaterialRequest);
		if (LifeTimeMode == EKGChangeMaterialLifeTimeMode::BindState)
		{
			ReqIDsMapping.Add(MeshComp, ReqID);	
		}
	}
#if !WITH_EDITOR // 编辑器环境下不支持预览, 预览时MaterialManager并不存在
	else
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("UAnimNotifyState_C7ChangeMaterial::NotifyBegin: Not found MaterialManager, MeshComp:%s, Animation:%s"),
			*MeshComp->GetPathName(), Animation ? *Animation->GetPathName() : TEXT("nullptr"));
	}
#endif
}

void UAnimNotifyState_C7ChangeMaterial::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_C7ChangeMaterial::NotifyEnd");
	
	if (LifeTimeMode == EKGChangeMaterialLifeTimeMode::BindState)
	{
		if (!IsValid(MeshComp))
		{
			UE_LOG(LogKGMaterial, Error, TEXT("UAnimNotifyState_C7ChangeMaterial::NotifyEnd: MeshComp is invalid, %s"),
				IsValid(Animation) ? *Animation->GetPathName() : TEXT("null"));
			return;
		}

		if (KGPlatformUtils::IsInLevelPreviewWorld(MeshComp))
		{
			return;
		}
		
		if (UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(MeshComp))
		{
			TWeakObjectPtr<USkeletalMeshComponent> MeshCompPtr(MeshComp);
			if (ReqIDsMapping.Contains(MeshCompPtr))
			{
				MaterialManager->RevertMaterial(ReqIDsMapping[MeshCompPtr]);
				ReqIDsMapping.Remove(MeshCompPtr);
			}
			else
			{
				UE_LOG(LogKGMaterial, Warning, TEXT("UAnimNotifyState_C7ChangeMaterial::NotifyEnd: Not found ReqID, MeshComp:%s, Animation:%s"),
					*MeshComp->GetPathName(), Animation ? *Animation->GetPathName() : TEXT("nullptr"));
			}
		}
#if !WITH_EDITOR // 编辑器环境下不支持预览, 预览时MaterialManager并不存在
		else
		{
			UE_LOG(LogKGMaterial, Warning, TEXT("UAnimNotifyState_C7ChangeMaterial::NotifyEnd: Not found MaterialManager, MeshComp:%s, Animation:%s"),
				*MeshComp->GetPathName(), Animation ? *Animation->GetPathName() : TEXT("nullptr"));
		}
#endif
	}
	
	Super::NotifyEnd(MeshComp, Animation, EventReference);
}
