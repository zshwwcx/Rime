// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Animation/AnimNotify/Movement/AnimNotifyState_BikeShakeAkEvent.h"

#include "3C/Audio/C7AnimNotify_ActionAkEvent.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "3C/Core/KGUEActorManager.h"

#include "Manager/KGAkAudioManager.h"

void UAnimNotifyState_BikeShakeAkEvent::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_BikeShakeAkEvent::NotifyBegin");
	
	Super::NotifyBegin(MeshComp, Animation, TotalDuration, EventReference);
	//UKGAkAudioManager::ReceivedAkEventNotifyStateBegin(MeshComp, BeginAkEvent);
	
	auto* CppEntity = UKGUEActorManager::GetLuaEntityByActor(MeshComp->GetOwner());
	if (!CppEntity) {
		return;
	}
	bool isMainPlayer = CppEntity->GetIsMainPlayer();
	if (ABaseCharacter* Character = Cast<ABaseCharacter>(MeshComp->GetOwner()))
	{
		if (bMainPlayerOnly && !isMainPlayer)
		{
			return;
		}

		if (URoleMovementComponent* RoleMoveComp = Cast<URoleMovementComponent>(Character->GetMovementComponent()))
		{
			int64 UniqueID = GetUniqueID();
			if (!Character->SaveBikeShakeAkEventRMCForAnimNotify(UniqueID, RoleMoveComp))
			{
				UE_LOG(LogTemp, Warning, TEXT("[UAnimNotifyState_BikeShakeAkEvent] Replicated NotifyBegin! %s, %s"), *MeshComp->GetName(), *Animation->GetName());
			}
			Character->SaveCurTriggerEventCoolDownForAnimNotify(UniqueID, -1);
			Character->InitHistoryDeltaPitchListForAnimNotify(UniqueID);
			Character->SaveLastPitchValueForAnimNotify(UniqueID, RoleMoveComp->GetRoleMP().GetMovementContext().GetMountPitch());
		}
	}
	
}

void UAnimNotifyState_BikeShakeAkEvent::NotifyTick(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float FrameDeltaTime, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_BikeShakeAkEvent::NotifyTick");
	
	Super::NotifyTick(MeshComp, Animation, FrameDeltaTime, EventReference);
	if (ABaseCharacter* Character = Cast<ABaseCharacter>(MeshComp->GetOwner()))
	{
		int64 UniqueID = GetUniqueID();
		URoleMovementComponent* RoleMoveComp = Character->GetBikeShakeAkEventRMCForAnimNotify(UniqueID);
		if (IsValid(RoleMoveComp))
		{
			TArray<float>* HistoryDeltaPitchList = Character->GetHistoryDeltaPitchListForAnimNotify(UniqueID);
			if (HistoryDeltaPitchList)
			{
				float OldLastPitchValue = Character->GetLastPitchValueForAnimNotify(UniqueID);
				float NewPitchValue = RoleMoveComp->GetRoleMP().GetMovementContext().GetMountPitch();
				Character->SaveLastPitchValueForAnimNotify(UniqueID, NewPitchValue);
				float CurTriggerEventCoolDown = Character->GetCurTriggerEventCoolDownForAnimNotify(UniqueID);

				if (FrameDeltaTime > 0.0f)
				{
					// 计算历史的DeltaPitch平均值
					float HistoryAvePitchDelta = 0.0f;
					if (HistoryDeltaPitchList->Num() > 0)
					{
						for (int32 i = 0; i < HistoryDeltaPitchList->Num(); i++)
						{
							HistoryAvePitchDelta += (*HistoryDeltaPitchList)[i];
						}
						HistoryAvePitchDelta /= HistoryDeltaPitchList->Num();
					}

					// 插入新值，删除旧值，最多保留10个
					float DeltaPitchSpeed = FMath::Abs(OldLastPitchValue - NewPitchValue) / FrameDeltaTime;
					HistoryDeltaPitchList->Add(DeltaPitchSpeed);
					if (HistoryDeltaPitchList->Num() > 10)
					{
						HistoryDeltaPitchList->RemoveAt(0);
					}

					/*if (DeltaPitchSpeed > 50.0f)
					{
						UE_LOG(LogTemp, Warning, TEXT("[szk]NewPitch:%f, OldPitch:%f, DeltaPitchVel:%f, DeltaTime:%f"), LastPitchValue, OldLastPitchValue, DeltaPitchSpeed, FrameDeltaTime);
					}*/
					
					if (CurTriggerEventCoolDown < 0.0f && DeltaPitchSpeed > TriggerEventDeltaPitchSpeed && HistoryAvePitchDelta < 50.0f)
					{
						// 对于在斜坡上原地打转的情况，也会触发这个音效，因此通过历史平均PitchDelta来剔除这种情况
						UC7AnimNotify_ActionAkEvent::RealPostActionAkEvent(MeshComp, BikeShakeAkEvent, bMainPlayerOnly);
						Character->SaveCurTriggerEventCoolDownForAnimNotify(UniqueID, TriggerEventCoolDown);
						CurTriggerEventCoolDown = TriggerEventCoolDown;
						return;
					}
					else if(CurTriggerEventCoolDown > 0.0f)
					{
						CurTriggerEventCoolDown -= FrameDeltaTime;
					}
				}
				else
				{
					float LastPitchValue = Character->GetLastPitchValueForAnimNotify(UniqueID);
					if (CurTriggerEventCoolDown < 0.0f && FMath::Abs(OldLastPitchValue - LastPitchValue) > 0.0f)
					{
						UC7AnimNotify_ActionAkEvent::RealPostActionAkEvent(MeshComp, BikeShakeAkEvent, bMainPlayerOnly);
						CurTriggerEventCoolDown = TriggerEventCoolDown;
						return;
					}
				}
				Character->SaveCurTriggerEventCoolDownForAnimNotify(UniqueID, CurTriggerEventCoolDown);
			}
		}
	}	
}

void UAnimNotifyState_BikeShakeAkEvent::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAnimNotifyState_BikeShakeAkEvent::NotifyEnd");
	
	Super::NotifyEnd(MeshComp, Animation, EventReference);

	if (ABaseCharacter* Character = Cast<ABaseCharacter>(MeshComp->GetOwner()))
	{
		int64 UniqueID = GetUniqueID();
		if (URoleMovementComponent* RoleMoveComp = Character->GetBikeShakeAkEventRMCForAnimNotify(UniqueID))
		{
			Character->ClearBikeShakeAkEventRMCForAnimNotify(UniqueID);
			Character->ClearLastPitchValueForAnimNotify(UniqueID);
			Character->ClearCurTriggerEventCoolDownForAnimNotify(UniqueID);
			Character->ClearHistoryDeltaPitchListForAnimNotify(UniqueID);
		}
	}
}
