#include "3C/Animation/FaceAnim/FaceAnim.h"
#include "Components/SkeletalMeshComponent.h"
#include "Misc/Paths.h"
#include "HAL/FileManager.h"
#include "Misc/FileHelper.h"
#include "Kismet/KismetMathLibrary.h"
#include "3C/Animation/BaseAnimInstance.h"
#include "Engine/Engine.h"
#include "Serialization/JsonSerializer.h"

UFaceAnim::UFaceAnim()
{
	Reset();
}

void UFaceAnim::Init(USkeletalMeshComponent* InMesh,  UFaceAnimLayer* FaceLayerPtr, EFaceAnimModeType Type,const FString & faceAnimLayerTag)
{
	Reset();
	FaceLayer = FaceLayerPtr;
	FaceAnimLayerTag = faceAnimLayerTag;
	MeshCom = InMesh;
	PlayType = Type;
}

void UFaceAnim::Update(float DeltaTime)
{
	if (!RunState.bRunning || bPause || PlayType == EFaceAnimModeType::Frame)
	{
		return;
	}

	if (RunState.CurFixTime >= 0)
	{
		RunState.CurFixTime -= DeltaTime;
		return;
	}

	UpdateLipsValue(DeltaTime, 0.0f);

	OnUpdate();
}

void UFaceAnim::UpdateFrame(float CurFrameTime)
{
	if (!RunState.bRunning || bPause || PlayType == EFaceAnimModeType::Tick)
	{
		return;
	}

	if (RunState.CurFixTime >= CurFrameTime)
	{
		return;
	}

	UpdateLipsValue(.0f, CurFrameTime);

	OnUpdate();
}

void UFaceAnim::SetLipBlend(float lipBlend) {
	RunState.LipBlend = lipBlend;
}

void UFaceAnim::SetFaceFloatParam(const FName& key, float value) {
	
	if (!MeshCom.IsValid() || !MeshCom->GetAnimInstance())
		return;

	if (UBaseAnimInstance* AnimIns = Cast<UBaseAnimInstance>(MeshCom->GetAnimInstance()))
	{
		AnimIns->SetFeatureAnimLayerFloatProperty(FName(FaceAnimLayerTag), key, value);
	}
}

void UFaceAnim::Reset()
{
	CurPlayFaceSeqData.Reset();
	BlendLipValues.Reset();
	FFaceAnimSeqMap.Empty();
	bPause = false;
	RunState.Reset();
	PlayType = EFaceAnimModeType::Tick;
}

void UFaceAnim::Play(const FString& FaceAnimID, float FixTime/* = 0.0f*/, float LipBlend/* = 1.0f*/)
{
	if (CurPlayFaceSeqData.Name != FaceAnimID)
	{
		CurPlayFaceSeqData = InnerLoadFaceFile(FaceAnimID);
	}

	bPause = false;
	RunState.bRunning = true;
	RunState.FixTime = FixTime;
	RunState.CurFixTime = FixTime;
	RunState.LipBlend = LipBlend;
	RunState.EndFrame = CurPlayFaceSeqData.FaceAnimFrames.Num();
	RunState.Frame = 0;
	RunState.ElapsedTime = 0;
	RunState.DeltaTime = CurPlayFaceSeqData.FpsTime;

	if (Override_FpsTime > 0)
	{
		RunState.DeltaTime = Override_FpsTime;
	}
}

void UFaceAnim::Pause()
{
	bPause = true;
}

void UFaceAnim::Stop()
{
	Reset();
}

void UFaceAnim::OnUpdate_Implementation()
{
	if(!MeshCom.IsValid() || !MeshCom->GetAnimInstance())
		return;

	if (UBaseAnimInstance* AnimIns = Cast<UBaseAnimInstance>(MeshCom->GetAnimInstance()))
	{
		AnimIns->SetFeatureAnimLayerFloatPropertys(FName(FaceAnimLayerTag), BlendLipValues);
		AnimIns->SetFeatureAnimLayerFloatProperty(FName(FaceAnimLayerTag), FName("LipBlend"), RunState.LipBlend);

		if (bDebugPrintAnimInfo)
		{
			DebugAnimInfos.Reset();
			AnimIns->GetAllActiveAnimationMessages(DebugAnimInfos);
			FString DebugStr;
			for (auto& Elem : DebugAnimInfos)
			{
				DebugStr += Elem;
				DebugStr += "\n";
			}

			GEngine->AddOnScreenDebugMessage(90001, .1, FColor::Green, *DebugStr, true);
		}
	}
}

void UFaceAnim::InnerPlay(FFaceAnimSeqData InFaceSeq)
{
	CurPlayFaceSeqData = InFaceSeq;

	bPause = false;
	RunState.bRunning = true;
	RunState.FixTime = InFaceSeq.FixTime;
	RunState.CurFixTime = InFaceSeq.FixTime;
	RunState.EndFrame = CurPlayFaceSeqData.FaceAnimFrames.Num();
	RunState.Frame = 0;
	RunState.ElapsedTime = 0;
	RunState.DeltaTime = CurPlayFaceSeqData.FpsTime;

	if (Override_FpsTime  > 0)
	{
		RunState.DeltaTime = Override_FpsTime;
	}
}

FString UFaceAnim::LoadTextFromFile(FString InPath)
{
	FString ResultContent;

	FString Path = FPaths::ProjectContentDir() + InPath;
	if (!IFileManager::Get().FileExists(*Path))
	{
		return ResultContent;
	}

	FFileHelper::LoadFileToString(ResultContent, *Path);

	return ResultContent;
}

void UFaceAnim::UpdateLipsValue(float InDeltaTime, float CurFrameTime)
{
	RunState.EndFrame = CurPlayFaceSeqData.FaceAnimFrames.Num();
	
	float DeltaTime(InDeltaTime);
	if (PlayType == EFaceAnimModeType::Frame)
	{
		DeltaTime = CurFrameTime - RunState.ElapsedTime;
		RunState.ElapsedTime = CurFrameTime;
	}
	else if (PlayType == EFaceAnimModeType::Tick)
	{
		RunState.ElapsedTime += InDeltaTime;
	}

	int32 CurFrame = RunState.ElapsedTime / RunState.DeltaTime;

	CurFrame = FMath::Clamp(CurFrame, 1, RunState.EndFrame);

	if (CurFrame >= RunState.EndFrame || CurPlayFaceSeqData.FaceAnimFrames.Num() < CurFrame)
	{
		if (PlayType == EFaceAnimModeType::Tick)
		{
			Stop();
		}
		
		if(FaceLayer.IsValid())
		{
			FaceLayer->SetDefaultPerformMode(0);
		}
		return;
	}
	
	if(FaceLayer.IsValid())
	{
		FaceLayer->SetDefaultPerformMode(1);
	}
	
	const FFaceAnimFrameData& FrameData = CurPlayFaceSeqData.FaceAnimFrames[CurFrame - 1];
	for (auto& Elem : FrameData.Lips.LibValues)
	{
		const FName& Name = Elem.Key;
		float Value = Elem.Value;

		float* BlendSpeed = LipBlendSpeed.Find(Name);
		float& CurValue = BlendLipValues.FindOrAdd(Name);
		if (BlendSpeed)
		{
			CurValue = UKismetMathLibrary::FInterpTo(CurValue, Value, DeltaTime, *BlendSpeed);
		}
		else
		{
			CurValue = Value;
		}
	}
}

FFaceAnimSeqData UFaceAnim::InnerLoadFaceFile(const FString& FaceAnimID)
{
	FFaceAnimSeqData NewSeqData;

	TArray<FAudio2FaceFrameData> OutLips = InnerLoadLipFile(FaceAnimID);

	NewSeqData.Name = FaceAnimID;

	int32 LipsNum = OutLips.Num();
	for (int32 i(0); i < LipsNum; ++i)
	{
		FFaceAnimFrameData FAnimD;
		FAnimD.Lips = OutLips[i];
		NewSeqData.FaceAnimFrames.Push(FAnimD);
	}

	return NewSeqData;
}

//todo 这里的加载和序列化有性能问题 @hujianglong
TArray<FAudio2FaceFrameData>  UFaceAnim::InnerLoadLipFile(const FString& FileName)
{
	QUICK_SCOPE_CYCLE_COUNTER(FaceAnim_InnerLoadLipFile);
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UFaceAnim_InnerLoadLipFile");
	
	TArray<FAudio2FaceFrameData> FrameDatas;
	FString LipFilePath = LipsPath + FileName + ".json";
	FString JsonStr = LoadTextFromFile(LipFilePath);
	if (JsonStr.IsEmpty() || JsonStr.Len() <= 2)
	{
		return FrameDatas;
	}
	constexpr const TCHAR* weightMatKeyName = TEXT("weightMat");
	constexpr const TCHAR* facsNamesKeyName = TEXT("facsNames");
	const TSharedRef<TJsonReader<TCHAR>> JsonReader = TJsonReaderFactory<TCHAR>::Create(JsonStr);
	TSharedPtr<FJsonObject> JsonObject;
	if (FJsonSerializer::Deserialize(JsonReader, JsonObject))
	{
		TArray<FString> Names;
		if (JsonObject->TryGetStringArrayField(facsNamesKeyName, Names))
		{
			const TArray<TSharedPtr<FJsonValue>>* OutweightMatArray = nullptr;
			if (JsonObject->TryGetArrayField(weightMatKeyName, OutweightMatArray))
			{
				for (const TSharedPtr<FJsonValue>& FrameWeights : *OutweightMatArray)
				{
					const TArray<TSharedPtr<FJsonValue>>* OutweightArray = nullptr;

					if(FrameWeights->TryGetArray(OutweightArray))
					{
						FAudio2FaceFrameData FrameData;
						for (int32 i(0); i < (*OutweightArray).Num(); ++i)
						{
							if (!Names.IsValidIndex(i))
							{
								continue;
							}

							const TSharedPtr<FJsonValue>& Weight = (*OutweightArray)[i];

							float WeightValue(0);
							if (Weight->TryGetNumber(WeightValue))
							{
								FrameData.LibValues.Add(FName(Names[i]), WeightValue);
							}
						}

						FrameDatas.Add(FrameData);
					}
				}
			}
		}
	}

	return FrameDatas;
}