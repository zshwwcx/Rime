﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Animation/AnimContainer/CachedAnimMontage.h"


FCachedAnimMontage::FCachedAnimMontage()
	: MainPlayerMontageCacheCapacity(20), DefaultMontageCacheCapacity(20), MainPlayerMontageCachesMap(),
	  DefaultMontageCachesMap()
{
}

FCachedAnimMontage::FCachedAnimMontage(SIZE_T InMainPlayerCapacity, SIZE_T InDefaultCapacity)
	: MainPlayerMontageCacheCapacity(InMainPlayerCapacity), DefaultMontageCacheCapacity(InDefaultCapacity),
	  MainPlayerMontageCachesMap(), DefaultMontageCachesMap()
{
}

FCachedAnimMontage::~FCachedAnimMontage()
{
	EmptyMontageCacheAll();
	UnregisterGCObject();
}


void FCachedAnimMontage::AddReferencedObjects(FReferenceCollector& Collector)
{
	for(auto& MontageCaches : MainPlayerMontageCachesMap)
	{
		for(auto& MontageCache : MontageCaches.Value)
		{
			Collector.AddReferencedObject(MontageCache);
		}
	}

	for(auto& MontageCaches : DefaultMontageCachesMap)
	{
		for(auto& MontageCache : MontageCaches.Value)
		{
			Collector.AddReferencedObject(MontageCache);
		}
	}
}


void FCachedAnimMontage::AddMontageCache(int CachePoolType, const FString& Key, UAnimMontage* Value)
{
	if(Value)
	{
		FName Slot = DefaultSlotName;
		if(Value->SlotAnimTracks.Num() > 0)
		{
			Slot = Value->SlotAnimTracks[0].SlotName;
		}
		switch (CachePoolType)
		{
		case 1:
			if(!MainPlayerMontageCachesMap.Contains(Slot))
			{
				MainPlayerMontageCachesMap.Add(Slot, MainPlayerMontageCacheCapacity);
			}
			MainPlayerMontageCachesMap[Slot].Add(Key, Value);
			break;
		default:
			if(!DefaultMontageCachesMap.Contains(Slot))
			{
				DefaultMontageCachesMap.Add(Slot, DefaultMontageCacheCapacity);
			}
			DefaultMontageCachesMap[Slot].Add(Key, Value);
		}	
	}
}

UAnimMontage* FCachedAnimMontage::CreateAndAddMontageCache(int CachePoolType, const FString& Key, UAnimSequenceBase* Value, const FName& AnimSlotName, float BlendInTime, float BlendOutTime, int LoopCount, bool bAddCache)
{
	if(UAnimMontage* CachedMontage = GetMontageCache(CachePoolType, Key, AnimSlotName))
	{
		return CachedMontage;
	}

	UAnimMontage* Montage = Cast<UAnimMontage>(Value);
	if(!Montage)
	{
		if(BlendOutTime < 0) BlendOutTime = 0.2f;
		if(BlendInTime < 0) BlendInTime = 0.2f;
		Montage = UAnimMontage::CreateSlotAnimationAsDynamicMontage(Value, AnimSlotName, BlendInTime, BlendOutTime, 1, LoopCount);
	}

	if(Montage && bAddCache)
	{
		switch (CachePoolType)
		{
		case 1:
			if(!MainPlayerMontageCachesMap.Contains(AnimSlotName))
			{
				MainPlayerMontageCachesMap.Add(AnimSlotName, MainPlayerMontageCacheCapacity);
			}
			MainPlayerMontageCachesMap[AnimSlotName].Add(Key, Montage);
			break;
		default:
			if(!DefaultMontageCachesMap.Contains(AnimSlotName))
			{
				DefaultMontageCachesMap.Add(AnimSlotName, DefaultMontageCacheCapacity);
			}
			DefaultMontageCachesMap[AnimSlotName].Add(Key, Montage);
		}
	}

	return Montage;
}

UAnimMontage* FCachedAnimMontage::GetMontageCache(int CachePoolType, const FString& Key, const FName& AnimSlotName)
{
	TWeakObjectPtr<UAnimMontage> Result = nullptr;
	switch (CachePoolType)
	{
	case 1:
		if(MainPlayerMontageCachesMap.Contains(AnimSlotName))
		{
			auto& MainPlayerMontageCaches = MainPlayerMontageCachesMap[AnimSlotName];
			if(MainPlayerMontageCaches.Contains(Key))
			{
				Result = MainPlayerMontageCaches.FindAndTouchRef(Key);
				++MainHitCnt;
			}
			else
			{
				++MainMissCnt;
			}
		}
		break;
	default:
		if(DefaultMontageCachesMap.Contains(AnimSlotName))
		{
			auto& DefaultMontageCaches = DefaultMontageCachesMap[AnimSlotName];
			if(DefaultMontageCaches.Contains(Key))
			{
				Result = DefaultMontageCaches.FindAndTouchRef(Key);
				++DefaultHitCnt;
			}
			else
			{
				++DefaultMissCnt;
			}
		}
		break;
	}

	if(Result == nullptr)
	{
		return nullptr;
	}

	return Result.Get();
}

void FCachedAnimMontage::EmptyMontageCache(int CachePoolType)
{
	switch (CachePoolType)
	{
	case 1:
		for(auto& MainPlayerMontageCaches : MainPlayerMontageCachesMap)
		{
			MainPlayerMontageCaches.Value.Empty(MainPlayerMontageCacheCapacity);
		}
		MainHitCnt = 0;
		MainMissCnt = 0;
		break;
	default:
		for(auto& DefaultMontageCaches : DefaultMontageCachesMap)
		{
			DefaultMontageCaches.Value.Empty(DefaultMontageCacheCapacity);
		}
		DefaultHitCnt = 0;
		DefaultMissCnt = 0;
	}
}

void FCachedAnimMontage::EmptyMontageCacheAll()
{
	EmptyMontageCache(1);
	EmptyMontageCache(0);
}

void FCachedAnimMontage::ChangeMainPlayerMontageCacheCapacity(int NewCapacity)
{
	MainPlayerMontageCacheCapacity = NewCapacity;
	EmptyMontageCache(1);
}

void FCachedAnimMontage::ChangeDefaultMontageCacheCapacity(int NewCapacity)
{
	DefaultMontageCacheCapacity = NewCapacity;
	EmptyMontageCache(0);
}

void FCachedAnimMontage::ChangeMontageCachesCapacity(int NewCapacity)
{
	MainPlayerMontageCacheCapacity = NewCapacity;
	DefaultMontageCacheCapacity = NewCapacity;
	EmptyMontageCacheAll();
}

float FCachedAnimMontage::GetMainCacheHitRate() const
{
	if(MainHitCnt + MainMissCnt == 0)
	{
		return 0.f;
	}
	return MainHitCnt * 1.f / (MainHitCnt * 1.f + MainMissCnt * 1.f);
}

float FCachedAnimMontage::GetDefaultCacheHitRate() const
{
	if(DefaultHitCnt + DefaultMissCnt == 0)
	{
		return 0.f;
	}
	return DefaultHitCnt * 1.f / (DefaultHitCnt * 1.f + DefaultMissCnt * 1.f);
}
