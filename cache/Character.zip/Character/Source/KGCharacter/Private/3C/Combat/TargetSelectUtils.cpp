#include "3C/Combat/TargetSelectUtils.h"

#include "3C/Util/AbilityCollisionUtil.h"
#include "3C/Core/C7ActorInterface.h"
#include "3C/Camera/CameraManager.h"
#include "DrawDebugHelpers.h"
#include "ICppEntity.h"
#include "KGCharacterModule.h"
#include "3C/Core/KGUEActorManager.h"
#include "Algo/RandomShuffle.h"
#include "Components/CapsuleComponent.h"
#include "GameFramework/Character.h"
#include "Managers/KGCombatSettingsManager.h"
#include "Managers/KGDataCacheManager.h"

#define KG_ENABLE_TARGET_SELECT_DRAW_DEBUG (!UE_BUILD_SHIPPING && !UE_BUILD_TEST)
#define KG_ENABLE_TARGET_SELECT_DEBUG_LOG (!UE_BUILD_SHIPPING && !UE_BUILD_TEST)
#define KG_TARGET_SELECT_DRAW_DEBUG_SEGMENTS (30)
#define KG_TARGET_SELECT_DRAW_DEBUG_THICKNESS (2.0)

static bool GEnableTargetSelectDrawDebug = false;
static FAutoConsoleVariableRef CVarEnableTargetSelectDrawDebug(
	TEXT("gp.EnableTargetSelectDrawDebug"),
	GEnableTargetSelectDrawDebug,
	TEXT("EnableTargetSelectDrawDebug."),
	ECVF_Default
);

static float GTargetSelectDrawDebugDuration = 5.0f;
static FAutoConsoleVariableRef CVarTargetSelectDrawDebugDuration(
	TEXT("gp.TargetSelectDrawDebugDuration"),
	GTargetSelectDrawDebugDuration,
	TEXT("TargetSelectDrawDebugDuration."),
	ECVF_Default
);

static FColor GetRangeDrawDebugColor(int32 ReentranceNum)
{
	static TArray RangeDrawDebugColors = {
		FColor::Red,
		FColor::Orange,
		FColor::Blue,
		FColor::Yellow,
	};

	return RangeDrawDebugColors[ReentranceNum % RangeDrawDebugColors.Num()];
}

struct FKGTargetSelectSort_Default
{
	struct OrderData
	{
		float Distance;
		float Angle;
	};
	
	FKGTargetSelectSort_Default(TMap<KGEntityID, OrderData>& InOrderDataMap, float InAttackSelectDefaultDistance, float InAttackSelectDefaultAngle) : 
		OrderDataMap(InOrderDataMap), AttackSelectDefaultDistance(InAttackSelectDefaultDistance), AttackSelectDefaultAngle(InAttackSelectDefaultAngle) {}
	
	bool operator()(const KGEntityID& A, const KGEntityID& B) const
	{
		const OrderData* AData = OrderDataMap.Find(A);
		const OrderData* BData = OrderDataMap.Find(B);
		
		if (A == B || !AData || !BData)
		{
			return false;
		}

		if (AData->Distance < BData->Distance)
		{
			if (BData->Distance < AttackSelectDefaultDistance || AData->Distance >= AttackSelectDefaultDistance)
			{
				return BData->Angle >= AttackSelectDefaultAngle || AData->Angle < AttackSelectDefaultAngle;
			}
			
			return true;
		}
		
		if (AData->Distance < AttackSelectDefaultDistance || BData->Distance >= AttackSelectDefaultDistance)
		{
			return AData->Angle < AttackSelectDefaultAngle && BData->Angle >= AttackSelectDefaultAngle;
		}
		
		return false;
	}
	
	TMap<KGEntityID, OrderData>& OrderDataMap;
	float AttackSelectDefaultDistance = 400.f;
	float AttackSelectDefaultAngle = 60.f;
};

struct FKGTargetSelectSort_Distance
{
	FKGTargetSelectSort_Distance(TMap<KGEntityID, float>& InDistanceMap, bool bInIncOrder) : bIncOrder(bInIncOrder), DistanceMap(InDistanceMap) {}
	
	bool operator()(const KGEntityID& A, const KGEntityID& B) const
	{
		const float* AData = DistanceMap.Find(A);
		const float* BData = DistanceMap.Find(B);
		if (A == B || !AData || !BData)
		{
			return false;
		}
		
		return bIncOrder ? *AData < *BData : *AData > *BData;
	}
	
	bool bIncOrder = true;
	TMap<KGEntityID, float> DistanceMap;
};

struct FKGTargetSelectSort_CameraDir
{
	struct OrderData
	{
		float Distance;
		float Angle;
	};
	
	FKGTargetSelectSort_CameraDir(TMap<KGEntityID, OrderData>& InOrderDataMap) : OrderDataMap(InOrderDataMap) {}
	
	bool operator()(const KGEntityID& A, const KGEntityID& B) const
	{
		const OrderData* AData = OrderDataMap.Find(A);
		const OrderData* BData = OrderDataMap.Find(B);
		if (A == B || !AData || !BData)
		{
			return false;
		}
		
		if (FMath::IsNearlyEqual(AData->Angle, BData->Angle))
		{
			return AData->Distance < BData->Distance;
		}
		
		return AData->Angle < BData->Angle;
	}
	
	TMap<KGEntityID, OrderData>& OrderDataMap;
};

FKGTargetSelectParams::FKGTargetSelectParams(const FKGTargetSelectParamsSimple& InParams)
{
	BaseEntity = InParams.BaseEntity;
	TargetEntity = InParams.TargetEntity;
	CenterPos = InParams.CenterPos;
	Yaw = InParams.Yaw;
	SearchPos = InParams.SearchPos;
	SearchTargetID = InParams.SearchTargetID;
	InputPos = InParams.InputPos;
	InputYaw = InParams.InputYaw;
	SkillID = InParams.SkillID;
	bIsEditor = InParams.bIsEditor;
	bDrawQueryResults = InParams.bDrawQueryResults;
	OverrideClockwiseRotation = InParams.OverrideClockwiseRotation;
	OverrideCoordinateOffset = InParams.OverrideCoordinateOffset;
	OverrideCoordinateType = InParams.OverrideCoordinateType;
}

bool FKGTargetSelectContext::Initialize()
{
	BaseActor = TargetSelectParams.BaseEntity.IsValid() ? TargetSelectParams.BaseEntity->GetBindedActor() : nullptr;
	if (!BaseActor.IsValid())
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectContext::Initialize, invalid BaseActor"));
		return false;
	}
	
	AActor* BaseActorPtr = BaseActor.Get();
	
	// target actor可以为空
	TargetActor = TargetSelectParams.TargetEntity.IsValid() ? TargetSelectParams.TargetEntity->GetBindedActor() : nullptr;
	
	CombatSettingsManager = UKGCombatSettingsManager::GetInstance(BaseActorPtr);
	if (!CombatSettingsManager.IsValid())
	{
		UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::Initialize, invalid CombatSettingsManager"));
		return false;
	}
	
	ActorManager = UKGUEActorManager::GetInstance(BaseActorPtr);
	if (!ActorManager.IsValid())
	{
		UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::Initialize, invalid ActorManager"));
		return false;
	}
	
	DataCacheManager = UKGDataCacheManager::GetInstance(BaseActorPtr);
	if (!DataCacheManager.IsValid())
	{
		UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::Initialize, invalid DataCacheManager"));
		return false;
	}
	
	uint32 AoeMaxNum = CombatSettingsManager->GetAoeMaxTargetSelectNum();
	if (TargetSelectParams.MaxNum == 0)
	{
		MaxNumUsed = AoeMaxNum;
	}
	else if (TargetSelectParams.MaxNum > 0)
	{
		MaxNumUsed = FMath::Min<uint32>(TargetSelectParams.MaxNum, AoeMaxNum);
	}
	
	return true;
}

FString FKGTargetSelectContext::GetDebugInfo() const
{
	return FString::Printf(TEXT("BaseActor: %s(%lld)"), 
		*GetNameSafe(BaseActor.Get()), 
		TargetSelectParams.BaseEntity.IsValid() ? TargetSelectParams.BaseEntity->GetLuaEntityBase()->GetEntityID() : KG_INVALID_ENTITY_ID);
}

ICppEntityInterface* FKGTargetSelectContext::GetBaseEntityInstigator()
{
	if (BaseEntityInstigator.IsValid())
	{
		return BaseEntityInstigator.Get();
	}
	
	if (!TargetSelectParams.BaseEntity.IsValid())
	{
		return nullptr;
	}

	BaseEntityInstigator = TargetSelectorUtils::GetEntityInstigator(TargetSelectParams.BaseEntity.Get(), ActorManager.Get());
	return BaseEntityInstigator.Get();
}

ACameraManager* FKGTargetSelectContext::GetCameraManager()
{
	if (CamaraManager.IsValid())
	{
		return CamaraManager.Get();
	}
	
	if (!BaseActor.IsValid())
	{
		return nullptr;
	}
	
	CamaraManager = Cast<ACameraManager>(UGameplayStatics::GetPlayerCameraManager(BaseActor->GetWorld(), 0));
	return CamaraManager.Get();
}

APlayerController* FKGTargetSelectContext::GetPlayerController()
{
	if (PlayerController.IsValid())
	{
		return PlayerController.Get();
	}
	
	if (!BaseActor.IsValid())
	{
		return nullptr;
	}
	
	PlayerController = Cast<APlayerController>(UGameplayStatics::GetPlayerController(BaseActor->GetWorld(), 0));
	return PlayerController.Get();
}

AActor* FKGTargetSelectContext::GetMainPlayerActor()
{
	if (MainPlayerActor.IsValid())
	{
		return MainPlayerActor.Get();
	}
	
	if (!ActorManager.IsValid())
	{
		return nullptr;
	}
	
	auto EntityID = ActorManager->GetMainPlayerEntityID();
	if (EntityID == KG_INVALID_ENTITY_ID)
	{
		return nullptr;
	}
	
	auto* Entity = ActorManager->GetLuaEntity(EntityID);
	if (!Entity)
	{
		return nullptr;
	}
	
	MainPlayerActor = Entity->GetBindedActor();
	return MainPlayerActor.Get();
}

bool TargetSelectorUtils::QueryEntities(FKGTargetSelectParams&& InParams, FKGTargetSelectResult& OutResult)
{
	SCOPED_NAMED_EVENT(TargetSelectorUtils_QueryEntities, FColor::Red);
	
	if (!InParams.BaseEntity.IsValid())
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::QueryEntities, invalid base actor"));
		return false;
	}
	
	if (!InParams.SearchRangeParams.RangeData.IsShapeParamsValid())
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::QueryEntities, invalid shape params, %s"),
			*InParams.SearchRangeParams.RangeData.GetShapeParamsInfo());
		return false;
	}
	
	FKGTargetSelectContext Context;
	Context.TargetSelectParams = MoveTemp(InParams);
	if (!Context.Initialize())
	{
		UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::QueryEntities, failed to initialize TargetSelectContext"));
		return false;
	}
	
	const auto& Params = Context.TargetSelectParams;
	if (!Context.CombatSettingsManager.IsValid())
	{
		UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::QueryEntities, invalid CombatSettingsManager"));
		return false;
	}
	
	if (Params.BackupSearchReentranceNum > Context.CombatSettingsManager->GetMaxTargetSelectReentranceNum())
	{
		UE_LOG(LogKGCombat, Log, TEXT("TargetSelectorUtils::QueryEntities, exceeded max BackupSearchReentranceNum %d"),
			Context.TargetSelectParams.BackupSearchReentranceNum);
		return false;
	}
	
	UE_LOG(LogKGCombat, Log, TEXT("TargetSelectorUtils::QueryEntities, start target select, %s, shape %s, BackupSearchReentranceNum: %d"),
		*Context.GetDebugInfo(), *Params.SearchRangeParams.RangeData.GetShapeParamsInfo(), Params.BackupSearchReentranceNum);
	
	QueryEntitiesInSingleRange(Context, Context.TargetSelectParams.SearchRangeParams.RangeData, OutResult);
	
	if (Context.MaxNumUsed > 0 && 
		Context.TargetSelectParams.BackupRuleID > 0 && 
		OutResult.EntityIDs.Num() < Context.MaxNumUsed)
	{
		DoBackupQuery(Context, OutResult);
	}
	
	// 因为backup query在sort阶段未做数量限制, 因此这里需要额外做一次
	if (OutResult.bSortDone && 
		Params.BackupSearchReentranceNum == 0 &&
		Context.MaxNumUsed > 0)
	{
		int32 CurNum = OutResult.EntityIDs.Num();
		if (CurNum > Context.MaxNumUsed)
		{
			OutResult.EntityIDs.RemoveAt(Context.MaxNumUsed, CurNum - Context.MaxNumUsed);
		}
	}
	
#if KG_ENABLE_TARGET_SELECT_DRAW_DEBUG
	if (GEnableTargetSelectDrawDebug && Params.BackupSearchReentranceNum == 0)
	{
		if (Params.bDrawQueryResults)
		{
			for (int32 i = 0; i < OutResult.EntityIDs.Num(); i++)
			{
				auto EntityID = OutResult.EntityIDs[i];
				DrawDebugSequenceInfo(Context.ActorManager.Get(), EntityID, i + 1);
				DrawDebugEntityCapsule(Context.ActorManager.Get(), EntityID, FColor::Green, GTargetSelectDrawDebugDuration, KG_TARGET_SELECT_DRAW_DEBUG_THICKNESS);
			}
		}
		
		for (auto EntityID : OutResult.OtherEntityIDs)
		{
			DrawDebugEntityCapsule(Context.ActorManager.Get(), EntityID, FColor::Black, GTargetSelectDrawDebugDuration, KG_TARGET_SELECT_DRAW_DEBUG_THICKNESS);
		}
	}
#endif
	
	return true;
}

bool TargetSelectorUtils::QueryEntitiesBySelectRuleID(const FKGTargetSelectParamsSimple& InParams, uint32 TargetSelectRuleID, FKGTargetSelectResult& OutResult)
{
	SCOPED_NAMED_EVENT(TargetSelectorUtils_QueryEntitiesBySelectRuleID, FColor::Red);
	
	if (TargetSelectRuleID == 0)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::QueryEntitiesBySelectRuleID, invalid TargetSelectRuleID"));
		return false;
	}
	
	if (!InParams.BaseEntity.IsValid())
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::QueryEntitiesBySelectRuleID, invalid base entity"));
		return false;
	}
	
	AActor* BaseActor = InParams.BaseEntity->GetBindedActor();
	if (!BaseActor)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::QueryEntitiesBySelectRuleID, invalid base actor, %lld"), 
			InParams.BaseEntity->GetLuaEntityBase()->GetEntityID());
		return false;
	}
	
	UKGDataCacheManager* DataCacheManager = UKGDataCacheManager::GetInstance(BaseActor);
	if (!DataCacheManager)
	{
		UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::QueryEntitiesBySelectRuleID, invalid DataCacheManager"));
		return false;
	}
	
	auto* TargetSelectRuleData = DataCacheManager->GetTargetSelectRuleData(TargetSelectRuleID);
	if (!TargetSelectRuleData)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::QueryEntitiesBySelectRuleID, failed to get TargetSelectRuleData, %d"), 
			TargetSelectRuleID);
		return false;
	}
	
	UE_LOG(LogKGCombat, Log, TEXT("TargetSelectorUtils::QueryEntitiesBySelectRuleID, using TargetSelectRuleData, %d"), TargetSelectRuleID);
	
	FKGTargetSelectParams TargetSelectParams(InParams);
	TargetSelectParams.SearchRangeParams = TargetSelectRuleData->RangeParams;
	TargetSelectParams.SearchTargetParams = TargetSelectRuleData->SearchTargetParams;
	TargetSelectParams.MaxNum = TargetSelectRuleData->MaxNum;
	TargetSelectParams.BackupRuleID = TargetSelectRuleData->BackupRuleID;
	TargetSelectParams.BackupMode = TargetSelectRuleData->BackupMode;
	TargetSelectParams.SortStrategy = TargetSelectRuleData->SortType;
	TargetSelectParams.bDistanceSortUseIncOrder = TargetSelectRuleData->bDistanceSortUseIncOrder;
	
	return QueryEntities(MoveTemp(TargetSelectParams), OutResult);
}

bool TargetSelectorUtils::QueryEntitiesBySkillID(
	const FKGTargetSelectParamsSimple& InParams, uint32 SkillID, FKGTargetSelectResult& OutResult)
{
	SCOPED_NAMED_EVENT(TargetSelectorUtils_QueryEntitiesBySkillID, FColor::Red);
	if (SkillID == 0)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::QueryEntitiesBySkillID, invalid SkillID"));
		return false;
	}
	
	if (!InParams.BaseEntity.IsValid())
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::QueryEntitiesBySkillID, invalid base entity"));
		return false;
	}
	
	AActor* BaseActor = InParams.BaseEntity->GetBindedActor();
	if (!BaseActor)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::QueryEntitiesBySkillID, invalid base actor, %lld"), 
			InParams.BaseEntity->GetLuaEntityBase()->GetEntityID());
		return false;
	}
	
	UKGDataCacheManager* DataCacheManager = UKGDataCacheManager::GetInstance(BaseActor);
	if (!DataCacheManager)
	{
		UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::QueryEntitiesBySkillID, invalid DataCacheManager"));
		return false;
	}
	
	auto* SkillData = DataCacheManager->GetSkillData(SkillID);
	if (!SkillData)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::QueryEntitiesBySkillID, failed to get SkillData, %d"), SkillID);
		return false;
	}
	
	if (!SkillData->bHasRangeParams)
	{
		UE_LOG(LogKGCombat, Log, TEXT("TargetSelectorUtils::QueryEntitiesBySkillID, SkillData has no range params, %d"), SkillID);
		return false;
	}
	
	UE_LOG(LogKGCombat, Log, TEXT("TargetSelectorUtils::QueryEntitiesBySkillID, using SkillData range params, %d"), SkillID);
	
	FKGTargetSelectParams TargetSelectParams(InParams);
	if (InParams.TargetEntity.IsValid() ||
		(SkillData->RangeParams.RangeData.CoordinateType != EKGTargetSelectCoordinateType::Target &&
		 SkillData->RangeParams.RangeData.CoordinateType != EKGTargetSelectCoordinateType::TargetOffset &&
		 SkillData->RangeParams.RangeData.CoordinateType != EKGTargetSelectCoordinateType::SelfToTarget &&
		 SkillData->RangeParams.RangeData.CoordinateType != EKGTargetSelectCoordinateType::TargetToSelf))
	{
		TargetSelectParams.SearchRangeParams = SkillData->RangeParams;
	}
	else if (SkillData->bHasBackupRangeParams)
	{
		TargetSelectParams.SearchRangeParams = SkillData->BackupRangeParams;
	}
	else
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::QueryEntitiesBySkillID, SkillData has no valid range params for target select, %d"), SkillID);
		return false;
	}

	TargetSelectParams.SearchTargetParams = SkillData->SearchTargetParams;
	TargetSelectParams.MaxNum = SkillData->TargetNum;
	
	return QueryEntities(MoveTemp(TargetSelectParams), OutResult);
}

bool TargetSelectorUtils::QueryEntitiesBySpellFieldID(const FKGTargetSelectParamsSimple& InParams, uint32 SpellFieldID, FKGTargetSelectResult& OutResult)
{
	SCOPED_NAMED_EVENT(TargetSelectorUtils_QueryEntitiesBySpellFieldID, FColor::Red);
	if (SpellFieldID == 0)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::QueryEntitiesBySpellFieldID, invalid SkillID"));
		return false;
	}
	
	if (!InParams.BaseEntity.IsValid())
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::QueryEntitiesBySpellFieldID, invalid base entity"));
		return false;
	}
	
	AActor* BaseActor = InParams.BaseEntity->GetBindedActor();
	if (!BaseActor)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::QueryEntitiesBySpellFieldID, invalid base actor, %lld"), 
			InParams.BaseEntity->GetLuaEntityBase()->GetEntityID());
		return false;
	}
	
	UKGDataCacheManager* DataCacheManager = UKGDataCacheManager::GetInstance(BaseActor);
	if (!DataCacheManager)
	{
		UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::QueryEntitiesBySpellFieldID, invalid DataCacheManager"));
		return false;
	}
	
	auto* SpellFieldData = DataCacheManager->GetSpellFieldData(SpellFieldID);
	if (!SpellFieldData)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::QueryEntitiesBySpellFieldID, failed to get SpellFieldData, %d"), SpellFieldID);
		return false;
	}
	
	if (!SpellFieldData->bHasRangeParams)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::QueryEntitiesBySpellFieldID, SpellFieldData has no range params, %d"), SpellFieldID);
		return false;
	}
	
	FKGTargetSelectParams TargetSelectParams(InParams);
	TargetSelectParams.SearchRangeParams = SpellFieldData->RangeParams;
	TargetSelectParams.SearchTargetParams = SpellFieldData->SearchTargetParams;
	TargetSelectParams.MaxNum = SpellFieldData->TargetNum;
	
	return QueryEntities(MoveTemp(TargetSelectParams), OutResult);
}

bool TargetSelectorUtils::IsValidTarget(const FKGSearchTargetParams& InParams, ICppEntityInterface* BaseEntity, KGEntityID TargetEntityID, bool bIsEditor)
{
	if (!BaseEntity)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::IsValidTarget, invalid base entity"));
		return false;
	}
	
	AActor* BaseActor = BaseEntity->GetBindedActor();
	if (!BaseActor)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::IsValidTarget, invalid base actor, %lld"),
			BaseEntity->GetLuaEntityBase()->GetEntityID());
		return false;
	}
	
	if (TargetEntityID == KG_INVALID_ENTITY_ID)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::IsValidTarget, invalid target entity id"));
		return false;
	}
	
	UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(BaseActor);
	if (!ActorManager)
	{
		UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::IsValidTarget, invalid ActorManager"));
		return false;
	}
	
	ICppEntityInterface* TargetEntity = ActorManager->GetLuaEntity(TargetEntityID);
	if (!TargetEntity)
	{
		UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::IsValidTarget, invalid target entity"));
		return false;
	}
	
	FKGTargetSelectContext Context;
	auto& TargetSelectParams = Context.TargetSelectParams;
	TargetSelectParams.BaseEntity = BaseEntity;
	TargetSelectParams.SearchTargetParams = InParams;
	TargetSelectParams.bIsEditor = bIsEditor;
	if (!Context.Initialize())
	{
		UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::IsValidTarget, failed to initialize TargetSelectContext"));
		return false;
	}
	
	return IsValidFightTarget(BaseEntity, TargetEntity, Context);
}

ICppEntityInterface* TargetSelectorUtils::GetEntityInstigator(ICppEntityInterface* InEntity, UKGUEActorManager* ActorManager)
{
	if (!InEntity || !ActorManager)
	{
		return nullptr;
	}
	
	const auto& EntityData = InEntity->GetEntityData();
	if (EntityData.FinalOwnerID == KG_INVALID_ENTITY_ID)
	{
		return InEntity;
	}
	
	if (auto* Instigator = ActorManager->GetLuaEntity(EntityData.FinalOwnerID))
	{
		return Instigator;
	}
	
	return InEntity;
}

void TargetSelectorUtils::DrawDebugSortResultFromLua(ICppEntityInterface* BaseEntity, const TArray<KGEntityID>& SortedEntityIDs)
{
#if KG_ENABLE_TARGET_SELECT_DRAW_DEBUG
	if (!GEnableTargetSelectDrawDebug)
	{
		return;
	}
	
	if (!BaseEntity)
	{
		return;
	}
	
	AActor* BindActor = BaseEntity->GetBindedActor();
	if (!BindActor)
	{
		return;
	}
	
	auto* ActorManager = UKGUEActorManager::GetInstance(BindActor);
	if (!ActorManager)
	{
		return;
	}
	
	for (int32 i = 0; i < SortedEntityIDs.Num(); i++)
	{
		auto EntityID = SortedEntityIDs[i];
		DrawDebugSequenceInfo(ActorManager, EntityID, i + 1);
		DrawDebugEntityCapsule(ActorManager, EntityID, FColor::Green, GTargetSelectDrawDebugDuration, KG_TARGET_SELECT_DRAW_DEBUG_THICKNESS);
	}
#endif
}

// void TargetSelectorUtils::MergeQueryResult(const TSet<KGEntityID>& EntityIDsFoundCurRange, TSet<KGEntityID>& FinalEntityIDs, EKGSelectionSetOperateType OperateType)
// {
// 	if (EntityIDsFoundCurRange.Num() == 0)
// 	{
// 		return;
// 	}
// 	
// 	if (OperateType == EKGSelectionSetOperateType::Union)
// 	{
// 		FinalEntityIDs = FinalEntityIDs.Union(EntityIDsFoundCurRange);
// 	}
// 	else if (OperateType == EKGSelectionSetOperateType::Intersect)
// 	{
// 		FinalEntityIDs = FinalEntityIDs.Intersect(EntityIDsFoundCurRange);
// 	}
// 	else if (OperateType == EKGSelectionSetOperateType::Except)
// 	{
// 		FinalEntityIDs = FinalEntityIDs.Difference(EntityIDsFoundCurRange);
// 	}
// }

bool TargetSelectorUtils::QueryEntitiesInSingleRange(
	FKGTargetSelectContext& InOutContext, const FKGSingleRangeData& RangeData, FKGTargetSelectResult& OutResult)
{
	SCOPED_NAMED_EVENT(TargetSelectorUtils_QueryEntitiesInSingleRange, FColor::Red);
	
	auto* CombatSettingsManager = InOutContext.CombatSettingsManager.Get();
	if (!CombatSettingsManager)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::QueryEntitiesInSingleRange, invalid CombatSettingsManager"));
		return false;
	}
	
	AActor* BaseActor = InOutContext.BaseActor.Get();
	if (!BaseActor)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::QueryEntitiesInSingleRange, invalid BaseActor"));
		return false;
	}
	
	FVector AttackBoxCenter;
	float AttackBoxYaw;
	if (!CalcRangeBasePosAndYaw(InOutContext, RangeData, AttackBoxCenter, AttackBoxYaw))
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::QueryEntitiesInSingleRange, failed to calculate base pos and yaw"));
		return false;
	}
	
	const auto& Params = InOutContext.TargetSelectParams;
	FVector CenterPos = AttackBoxCenter;
	FRotator Rotation = FRotator(0.0f, AttackBoxYaw, 0.0f);
	const auto& ObjectTypes = CombatSettingsManager->GetSceneQueryObjectTypes(Params.SearchTargetParams.GlobalTargetTypeMask);
	TArray<AActor*> QueryResultActors;
	
	float ZRangeMin = 0.0f;
	float ZRangeMax = 0.0f;
	if (RangeData.ShapeType == EKGTargetSelectShapeType::Cuboid)
	{
		float Length, Width, Height;
		if (!RangeData.GetShapeParamsAsCuboid(Length, Width, Height, ZRangeMin, ZRangeMax))
		{
			UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::QueryEntitiesInSingleRange, invalid cuboid shape params"));
			return false;
		}
		
		CenterPos.Z = CenterPos.Z + (ZRangeMax + ZRangeMin) * 0.5f;
		FVector BoxExtent(Length * 0.5f, Width * 0.5f, Height * 0.5f);
		
#if KG_ENABLE_TARGET_SELECT_DRAW_DEBUG
		if (GEnableTargetSelectDrawDebug)
		{
			UKismetSystemLibrary::DrawDebugBox(BaseActor, CenterPos, BoxExtent, GetRangeDrawDebugColor(Params.BackupSearchReentranceNum), Rotation, GTargetSelectDrawDebugDuration);
		}
#endif
		
		UAbilityCollisionUtil::BoxCheck(
			BaseActor, BoxExtent, CenterPos, AttackBoxYaw, ObjectTypes, QueryResultActors, false);
	}
	else if (RangeData.ShapeType == EKGTargetSelectShapeType::Cylinder)
	{
		float Radius, Height;
		if (!RangeData.GetShapeParamsAsCylinder(Radius, Height, ZRangeMin, ZRangeMax))
		{
			UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::QueryEntitiesInSingleRange, invalid cylinder shape params"));
			return false;
		}
		
		CenterPos.Z = CenterPos.Z + (ZRangeMax + ZRangeMin) * 0.5f;
		
#if KG_ENABLE_TARGET_SELECT_DRAW_DEBUG
		if (GEnableTargetSelectDrawDebug)
		{
			FVector StartPos(CenterPos.X, CenterPos.Y, CenterPos.Z - Height * 0.5f);
			FVector EndPos(CenterPos.X, CenterPos.Y, CenterPos.Z + Height * 0.5f);
			UKismetSystemLibrary::DrawDebugCylinder(
				BaseActor, StartPos, EndPos, Radius, KG_TARGET_SELECT_DRAW_DEBUG_SEGMENTS, 
				GetRangeDrawDebugColor(Params.BackupSearchReentranceNum), GTargetSelectDrawDebugDuration);
		}
#endif
		
		UAbilityCollisionUtil::CapsuleCheck(
			BaseActor, Height * 0.5f, Radius, CenterPos, ObjectTypes, QueryResultActors, false);
	}
	else if (RangeData.ShapeType == EKGTargetSelectShapeType::Fan3d)
	{
		float InnerRadius, OuterRadius, Height, AngleDegree;
		if (!RangeData.GetShapeParamsAsFan3d(InnerRadius, OuterRadius, Height, AngleDegree, ZRangeMin, ZRangeMax))
		{
			UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::QueryEntitiesInSingleRange, invalid fan3d shape params"));
			return false;
		}
		
		CenterPos.Z = CenterPos.Z + (ZRangeMax + ZRangeMin) * 0.5f;
#if KG_ENABLE_TARGET_SELECT_DRAW_DEBUG
		if (GEnableTargetSelectDrawDebug)
		{
			DrawDebugFan3D(BaseActor->GetWorld(), CenterPos, InnerRadius, OuterRadius, KG_TARGET_SELECT_DRAW_DEBUG_SEGMENTS, Rotation,
				AngleDegree * 0.5f, Height, GetRangeDrawDebugColor(Params.BackupSearchReentranceNum), GTargetSelectDrawDebugDuration, KG_TARGET_SELECT_DRAW_DEBUG_THICKNESS);
		}
#endif
		
		UAbilityCollisionUtil::FanCheck(
			BaseActor, InnerRadius, OuterRadius, Height, AngleDegree, CenterPos, AttackBoxYaw, ObjectTypes, QueryResultActors, false);
	}
	else if (RangeData.ShapeType == EKGTargetSelectShapeType::Annular3d)
	{
		float InnerRadius, OuterRadius, Height;
		if (!RangeData.GetShapeParamsAsAnnular3d(InnerRadius, OuterRadius, Height, ZRangeMin, ZRangeMax))
		{
			UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::QueryEntitiesInSingleRange, invalid Annular3d shape params"));
			return false;
		}
		
		CenterPos.Z = CenterPos.Z + (ZRangeMax + ZRangeMin) * 0.5f;
#if KG_ENABLE_TARGET_SELECT_DRAW_DEBUG
		if (GEnableTargetSelectDrawDebug)
		{
			FVector StartPos(CenterPos.X, CenterPos.Y, CenterPos.Z - Height * 0.5f);
			FVector EndPos(CenterPos.X, CenterPos.Y, CenterPos.Z + Height * 0.5f);
			if (InnerRadius > UE_KINDA_SMALL_NUMBER)
			{
				UKismetSystemLibrary::DrawDebugCylinder(
					BaseActor, StartPos, EndPos, InnerRadius, KG_TARGET_SELECT_DRAW_DEBUG_SEGMENTS, 
					GetRangeDrawDebugColor(Params.BackupSearchReentranceNum), GTargetSelectDrawDebugDuration);
			}
			UKismetSystemLibrary::DrawDebugCylinder(
				BaseActor, StartPos, EndPos, OuterRadius, KG_TARGET_SELECT_DRAW_DEBUG_SEGMENTS, 
				GetRangeDrawDebugColor(Params.BackupSearchReentranceNum), GTargetSelectDrawDebugDuration);
		}
#endif
		
		UAbilityCollisionUtil::FanCheck(
			BaseActor, InnerRadius, OuterRadius, Height, 360.0f, CenterPos, AttackBoxYaw, ObjectTypes, QueryResultActors, false);
	}
	else
	{
		UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::QueryEntitiesInSingleRange, unsupported shape type %d"), RangeData.ShapeType);
		return false;
	}
	
	UE_LOG(LogKGCombat, Log, TEXT("TargetSelectorUtils::QueryEntitiesInSingleRange, found %d targets, %s"), 
		QueryResultActors.Num(), *InOutContext.GetDebugInfo());
#if KG_ENABLE_TARGET_SELECT_DEBUG_LOG
	for (AActor* Actor : QueryResultActors)
	{
		UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::QueryEntitiesInSingleRange, found Actor: %s(%lld)"), 
			*GetNameSafe(Actor), Cast<IC7ActorInterface>(Actor) ? Cast<IC7ActorInterface>(Actor)->GetEntityUID() : 0);
	}
#endif
	
	if (QueryResultActors.Num() == 0)
	{
		return true;
	}
	
	CheckTargetAndFillResult(InOutContext, QueryResultActors, OutResult);
	
	UE_LOG(LogKGCombat, Log, TEXT("TargetSelectorUtils::QueryEntitiesInSingleRange, found %d valid targets and %d invalid, %s"), 
		OutResult.EntityIDs.Num(), OutResult.OtherEntityIDs.Num(), *InOutContext.GetDebugInfo());
#if KG_ENABLE_TARGET_SELECT_DEBUG_LOG
	for (auto EntityID : OutResult.EntityIDs)
	{
		UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::QueryEntitiesInSingleRange, found valid entity: %lld"), EntityID);
	}
#endif
	
	SortTargetEntities(InOutContext, CenterPos, OutResult);
#if KG_ENABLE_TARGET_SELECT_DEBUG_LOG
	for (auto EntityID : OutResult.EntityIDs)
	{
		UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::QueryEntitiesInSingleRange, sort valid entity: %lld"), EntityID);
	}
#endif
	
	return true;
}

bool TargetSelectorUtils::CalcRangeBasePosAndYaw(FKGTargetSelectContext& InOutContext, const FKGSingleRangeData& RangeData, FVector& OutBasePos, float& OutBaseYaw)
{
	AActor* BaseActor = InOutContext.BaseActor.Get();
	if (!BaseActor)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::CalcRangeBasePosAndYaw, invalid BaseActor"));
		return false;
	}
	
	auto* ActorManager = InOutContext.ActorManager.Get();
	if (!ActorManager)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::CalcRangeBasePosAndYaw, invalid ActorManager"));
		return false;
	}
	
	auto* DataCacheManager = InOutContext.DataCacheManager.Get();
	if (!DataCacheManager)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::CalcRangeBasePosAndYaw, invalid DataCacheManager"));
		return false;
	}
	
	const auto& Params = InOutContext.TargetSelectParams;
	if (Params.CenterPos.IsSet() && Params.Yaw.IsSet())
	{
		OutBasePos = Params.CenterPos.GetValue();
		OutBaseYaw = Params.Yaw.GetValue();
		return true;
	}
	
	UE_CLOG(Params.CenterPos.IsSet() != Params.Yaw.IsSet(),
		LogKGCombat, Warning, TEXT("TargetSelectorUtils::CalcRangeBasePosAndYaw, invalid CenterPos/Yaw input"));
	
	FVector SelfPos;
	if (!GetFloorPosition(BaseActor, SelfPos))
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::CalcRangeBasePosAndYaw, failed to get BaseActor floor position"));
		return false;
	}
	
	float SelfYaw = BaseActor->GetActorRotation().Yaw;
	bool bNeedOffset = false;
	EKGTargetSelectCoordinateType CoordinateType = Params.OverrideCoordinateType.IsSet() ? Params.OverrideCoordinateType.GetValue() : RangeData.CoordinateType;
	const FVector& CoordinateOffset = Params.OverrideCoordinateOffset.IsSet() ? Params.OverrideCoordinateOffset.GetValue() : RangeData.CoordinateOffset;
	if (CoordinateType == EKGTargetSelectCoordinateType::Self ||
		CoordinateType == EKGTargetSelectCoordinateType::SelfOffset)
	{
		OutBasePos = SelfPos;
		OutBaseYaw = SelfYaw;
		bNeedOffset = CoordinateType == EKGTargetSelectCoordinateType::SelfOffset;
	}
	else if (CoordinateType == EKGTargetSelectCoordinateType::Target ||
		CoordinateType == EKGTargetSelectCoordinateType::TargetOffset)
	{
		if (!InOutContext.TargetActor.IsValid())
		{
			UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::CalcRangeBasePosAndYaw, invalid TargetActor for Target coordinate type %d"),
				CoordinateType);
			return false;
		}
		
		GetFloorPosition(InOutContext.TargetActor.Get(), OutBasePos);
		OutBaseYaw = InOutContext.TargetActor->GetActorRotation().Yaw;
		bNeedOffset = CoordinateType == EKGTargetSelectCoordinateType::TargetOffset;
	}
	else if (CoordinateType == EKGTargetSelectCoordinateType::TargetToSelf)
	{
		if (!InOutContext.TargetActor.IsValid())
		{
			UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::CalcRangeBasePosAndYaw, invalid TargetActor for Target coordinate type %d"),
				CoordinateType);
			return false;
		}
		
		GetFloorPosition(InOutContext.TargetActor.Get(), OutBasePos);
		OutBaseYaw = (SelfPos - OutBasePos).Rotation().Yaw;
		bNeedOffset = true;
	}
	else if (CoordinateType == EKGTargetSelectCoordinateType::SelfToTarget)
	{
		if (!InOutContext.TargetActor.IsValid())
		{
			UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::CalcRangeBasePosAndYaw, invalid TargetActor for Target coordinate type %d"),
				CoordinateType);
			return false;
		}
		
		OutBasePos = SelfPos;
		FVector TargetPos;
		GetFloorPosition(InOutContext.TargetActor.Get(), TargetPos);
		OutBaseYaw = (TargetPos - SelfPos).Rotation().Yaw;
		bNeedOffset = true;
	}
	else if (CoordinateType == EKGTargetSelectCoordinateType::WorldPos)
	{
		OutBasePos = CoordinateOffset;
		OutBaseYaw = 0.0f;
	}
	else if (CoordinateType == EKGTargetSelectCoordinateType::PosList)
	{
		if (!Params.SearchPos.IsSet())
		{
			UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::CalcRangeBasePosAndYaw, invalid search pos"));
			return false;
		}
		
		OutBasePos = Params.SearchPos.GetValue();
		OutBaseYaw = 0.0f;
	}
	else if (CoordinateType == EKGTargetSelectCoordinateType::TargetList)
	{
		if (Params.SearchTargetID == KG_INVALID_ENTITY_ID)
		{
			UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::CalcRangeBasePosAndYaw, invalid SearchTargetID"));
			return false;
		}
		
		auto* TargetActor = ActorManager->GetActorByEntityID(Params.SearchTargetID);
		if (!TargetActor)
		{
			UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::CalcRangeBasePosAndYaw, invalid TargetActor, %lld"), Params.SearchTargetID);
			return false;
		}
		
		GetFloorPosition(TargetActor, OutBasePos);
		OutBaseYaw = TargetActor->GetActorRotation().Yaw;
	}
	else if (CoordinateType == EKGTargetSelectCoordinateType::Location)
	{
		if (Params.InputYaw.IsSet())
		{
			OutBaseYaw = Params.InputYaw.GetValue();
		}
		else
		{
			OutBaseYaw = 0.0f;
		}
		
		if (Params.InputPos.IsSet())
		{
			OutBasePos = Params.InputPos.GetValue();
		}
		else
		{
			auto* SkillConfig = DataCacheManager->GetSkillData(Params.SkillID);
			if (!SkillConfig)
			{
				UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::CalcRangeBasePosAndYaw, invalid SkillConfig for SkillID %d"), Params.SkillID);
				return false;
			}
			
			OutBasePos = SelfPos + FRotator(0.0f, SelfYaw, 0.0f).Vector() * SkillConfig->Dist;
		}
	}
	else if (CoordinateType == EKGTargetSelectCoordinateType::SelfInput)
	{
		OutBasePos = SelfPos;
		if (Params.InputYaw.IsSet())
		{
			OutBaseYaw = Params.InputYaw.GetValue();
		}
		else
		{
			OutBaseYaw = SelfYaw;
		}
		bNeedOffset = true;
	}
	else
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::CalcRangeBasePosAndYaw, unsupported CoordinateType %d"),
			static_cast<uint8>(CoordinateType));
		return false;
	}
	
	const float ClockwiseRotation = Params.OverrideClockwiseRotation.IsSet() ? 
		Params.OverrideClockwiseRotation.GetValue() : RangeData.ClockwiseRotation;
	OutBaseYaw += ClockwiseRotation;
	OutBaseYaw = FMath::UnwindDegrees(OutBaseYaw);
	
	if (bNeedOffset)
	{
		OutBasePos += FRotator(0.0f, OutBaseYaw, 0.0f).RotateVector(
			FVector(CoordinateOffset.X, CoordinateOffset.Y, 0.0f));
	}
	
	return true;
}

bool TargetSelectorUtils::GetFloorPosition(AActor* InActor, FVector& OutFloorPosition)
{
	if (!InActor)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::GetFloorPosition, invalid actor"));
		return false;
	}
	
	OutFloorPosition = InActor->GetActorLocation();
	if (ACharacter* Character = Cast<ACharacter>(InActor))
	{
		if (auto* CapsuleComponent = Character->GetCapsuleComponent())
		{
			OutFloorPosition.Z = OutFloorPosition.Z - CapsuleComponent->GetScaledCapsuleHalfHeight();
		}
	}
	else
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::GetFloorPosition, actor is not ACharacter, using actor location as floor position"));
	}
	return true;
}

void TargetSelectorUtils::CheckTargetAndFillResult(FKGTargetSelectContext& InOutContext, const TArray<AActor*>& TargetActors, FKGTargetSelectResult& OutResult)
{
	SCOPED_NAMED_EVENT(TargetSelectorUtils_CheckTargetAndFillResult, FColor::Red);
	
	auto* CombatSettingsManager = InOutContext.CombatSettingsManager.Get();
	if (!CombatSettingsManager)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::CheckTargetAndFillResult, invalid CombatSettingsManager"));
		return;
	}
	
	auto* ActorManager = InOutContext.ActorManager.Get();
	if (!ActorManager)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::CheckTargetAndFillResult, invalid ActorManager"));
		return;
	}
	
	auto* BaseEntity = InOutContext.TargetSelectParams.BaseEntity.Get();
	if (!BaseEntity)
	{
		UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::CheckTargetAndFillResult, invalid BaseEntity"));
		return;
	}
	
	// 客户端的目标筛选必然有一方是主角, 如果BaseActor不是主角的话, target entity或者 target entity instigator必然需要为主角, 否则可以直接跳过
	bool bIsSourceMainPlayer = BaseEntity->GetIsMainPlayer();
	if (!bIsSourceMainPlayer)
	{
		if (auto* SourceInstigator = InOutContext.GetBaseEntityInstigator())
		{
			bIsSourceMainPlayer = SourceInstigator->GetIsMainPlayer();
		}
	}
	
	uint32 CurTargetNum = 0;
	for (auto* TargetActor : TargetActors)
	{
		if (!TargetActor)
		{
			UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::CheckTargetAndFillResult, invalid TargetActor in QueryResultActors"));
			continue;
		}
		
		auto* TargetEntity = ActorManager->GetLuaEntityByActor(TargetActor);
		if (!TargetEntity)
		{
			continue;
		}
		
		if (!bIsSourceMainPlayer)
		{
			if (!TargetEntity->GetIsMainPlayer())
			{
				auto* TargetEntityInstigator = GetEntityInstigator(TargetEntity, ActorManager);
				if (TargetEntityInstigator == nullptr || !TargetEntityInstigator->GetIsMainPlayer())
				{
					UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::CheckTargetAndFillResult, neither source nor target is main player, skip target, %s, %s"),
						*InOutContext.GetDebugInfo(), *GetNameSafe(TargetActor));
					continue;
				}
			}
		}
		
		const auto EntityID = TargetEntity->GetLuaEntityBase()->GetEntityID();
		if (InOutContext.AllEntityIDSet.Contains(EntityID))
		{
			continue;
		}
		InOutContext.AllEntityIDSet.Add(EntityID);
		
		if (IsValidFightTarget(InOutContext.TargetSelectParams.BaseEntity.Get(), TargetEntity, InOutContext))
		{
			UE_LOG(LogKGCombat, Log, TEXT("TargetSelectorUtils::QueryEntitiesInSingleRange, %s is valid target, %s"), 
				*GetNameSafe(TargetEntity->GetBindedActor()), *InOutContext.GetDebugInfo());
			OutResult.EntityIDs.Add(EntityID);
			CurTargetNum++;
		}
		else
		{
			UE_LOG(LogKGCombat, Log, TEXT("TargetSelectorUtils::QueryEntitiesInSingleRange, %s is not valid target, %s"), 
				*GetNameSafe(TargetEntity->GetBindedActor()), *InOutContext.GetDebugInfo());
			OutResult.OtherEntityIDs.Add(EntityID);
		}
		
		if (CurTargetNum > CombatSettingsManager->GetAoeMaxTargetSelectNum())
		{
			UE_LOG(LogKGCombat, Log, TEXT("TargetSelectorUtils::CheckTargetAndFillResult, current target num %d exceeds %d, stop checking more targets, %s"),
				CurTargetNum, CombatSettingsManager->GetAoeMaxTargetSelectNum(), *InOutContext.GetDebugInfo());
			break;
		}
	}
}

void TargetSelectorUtils::DoBackupQuery(FKGTargetSelectContext& InOutContext, FKGTargetSelectResult& OutResult)
{
	const auto& Params = InOutContext.TargetSelectParams;
	if (Params.BackupRuleID == 0)
	{
		UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::DoBackupQuery, invalid BackupRuleID"));
		return;
	}
	
	if (!InOutContext.DataCacheManager.IsValid())
	{
		UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::DoBackupQuery, invalid DataCacheManager"));
		return;
	}
	
	auto* BackupRuleConfig = InOutContext.DataCacheManager->GetTargetSelectRuleData(Params.BackupRuleID);
	if (!BackupRuleConfig)
	{
		UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::DoBackupQuery, invalid BackupRuleConfig for RuleID %d"), Params.BackupRuleID);
		return;
	}
	
	FKGTargetSelectParams NewTargetSelectParams(Params);
	NewTargetSelectParams.BackupSearchReentranceNum += 1;
	if (Params.BackupMode == EKGTargetSelectBackupMode::UseNewSelectRule)
	{
		NewTargetSelectParams.SearchRangeParams = BackupRuleConfig->RangeParams;
		NewTargetSelectParams.SearchTargetParams = BackupRuleConfig->SearchTargetParams;
		NewTargetSelectParams.BackupRuleID = BackupRuleConfig->BackupRuleID;
		NewTargetSelectParams.BackupMode = BackupRuleConfig->BackupMode;
	}
	else if (Params.BackupMode == EKGTargetSelectBackupMode::UseNewShape)
	{
		NewTargetSelectParams.SearchRangeParams = BackupRuleConfig->RangeParams;
	}
	else if (Params.BackupMode == EKGTargetSelectBackupMode::UseNewFilter)
	{
		NewTargetSelectParams.SearchTargetParams = BackupRuleConfig->SearchTargetParams;
		NewTargetSelectParams.BackupRuleID = BackupRuleConfig->BackupRuleID;
		NewTargetSelectParams.BackupMode = BackupRuleConfig->BackupMode;
	}
	else
	{
		UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::DoBackupQuery, invalid BackupMode %d"),
			static_cast<uint8>(Params.BackupMode));
		return;
	}
	
	FKGTargetSelectResult Result;
	if (QueryEntities(MoveTemp(NewTargetSelectParams), Result))
	{
		OutResult.EntityIDs = Result.EntityIDs;
		OutResult.bSortDone = Result.bSortDone;
	}
}

void TargetSelectorUtils::SortTargetEntities(FKGTargetSelectContext& InOutContext, const FVector& CenterPos, FKGTargetSelectResult& OutResult)
{
	SCOPED_NAMED_EVENT(TargetSelectorUtils_SortTargetEntities, FColor::Red);
	
	if (OutResult.EntityIDs.Num() <= 1)
	{
		return;
	}
	
	const auto& Params = InOutContext.TargetSelectParams;
	if (Params.SortStrategy == EKGTargetSortStrategy::None)
	{
		if (InOutContext.CombatSettingsManager.IsValid() && 
			InOutContext.CombatSettingsManager->IsDefaultSortEnabled() && 
			!Params.bIsEditor)
		{
			DoDefaultSort(InOutContext, OutResult);
		}
	}
	else if (Params.SortStrategy == EKGTargetSortStrategy::ByDistance)
	{
		DoDistanceSort(InOutContext, CenterPos, OutResult);
	}
	else if (Params.SortStrategy == EKGTargetSortStrategy::Random)
	{
		DoRandomSort(InOutContext, OutResult);
	}
	else if (Params.SortStrategy == EKGTargetSortStrategy::ByCameraDir)
	{
		DoCameraDirSort(InOutContext, CenterPos, OutResult);
	}
	else if (Params.SortStrategy == EKGTargetSortStrategy::ByHpRate ||
		Params.SortStrategy == EKGTargetSortStrategy::BySortMethod)
	{
		// 回到lua中排序
		OutResult.bSortDone = false;
		OutResult.MaxNumUsed = InOutContext.MaxNumUsed;
		UE_LOG(LogKGCombat, Log, TEXT("TargetSelectorUtils::SortTargetEntities, sort by HpRate/SortMethod in lua, %d"),
			static_cast<uint8>(Params.SortStrategy));
	}
	else
	{
		UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::SortTargetEntities, invalid SortStrategy %d"),
			static_cast<uint8>(Params.SortStrategy));
		return;
	}
	
	if (OutResult.bSortDone && 
		Params.BackupSearchReentranceNum == 0 &&
		InOutContext.MaxNumUsed > 0)
	{
		int32 CurNum = OutResult.EntityIDs.Num();
		if (CurNum > InOutContext.MaxNumUsed)
		{
			OutResult.EntityIDs.RemoveAt(InOutContext.MaxNumUsed, CurNum - InOutContext.MaxNumUsed);
		}
	}
}

void TargetSelectorUtils::DoDefaultSort(FKGTargetSelectContext& InOutContext, FKGTargetSelectResult& OutResult)
{
	auto* PlayerController = InOutContext.GetPlayerController();
	if (!PlayerController)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::DoDefaultSort, invalid PlayerController"));
		return;
	}
	
	if (!InOutContext.ActorManager.IsValid())
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::DoDefaultSort, invalid ActorManager"));
		return;
	}
	
	if (!InOutContext.CombatSettingsManager.IsValid())
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::DoDefaultSort, invalid CombatSettingsManager"));
		return;
	}
	
	const FVector& CurrentControlDir = PlayerController->GetControlRotation().Vector().GetSafeNormal2D();
	auto* MainPlayerActor = InOutContext.GetMainPlayerActor();
	if (!MainPlayerActor)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::DoDefaultSort, invalid MainPlayerActor"));
		return;
	}
	
	const auto& MainPlayerPos = MainPlayerActor->GetActorLocation();
#if KG_ENABLE_TARGET_SELECT_DRAW_DEBUG
	if (GEnableTargetSelectDrawDebug)
	{
		const auto& LineEnd = MainPlayerPos + CurrentControlDir * 500.0f;
		UKismetSystemLibrary::DrawDebugArrow(PlayerController->GetWorld(), MainPlayerPos, LineEnd, 50.0f, 
			FColor::Magenta, GTargetSelectDrawDebugDuration, 10.0f);
	}
#endif
	
	TMap<KGEntityID, FKGTargetSelectSort_Default::OrderData> OrderDataMap;
	OrderDataMap.Reserve(OutResult.EntityIDs.Num());
	for (auto EntityID : OutResult.EntityIDs)
	{
		auto* Entity = InOutContext.ActorManager->GetLuaEntity(EntityID);
		if (!Entity)
		{
			UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::DoDefaultSort, invalid Entity for EntityID %lld"), EntityID);
			continue;
		}

		const auto& EntityPosition = Entity->GetLocation();
		const auto& MainPlayerToEntityVec3 = EntityPosition - MainPlayerPos;
		
		float CosTheta = FVector::DotProduct(CurrentControlDir, MainPlayerToEntityVec3.GetSafeNormal2D());
		float Angle = FMath::RadiansToDegrees(FMath::Acos(CosTheta));

		auto& OrderData = OrderDataMap.Add(EntityID);
		OrderData.Distance = MainPlayerToEntityVec3.Size();
		OrderData.Angle = Angle;
	}
	
	Algo::Sort(OutResult.EntityIDs, FKGTargetSelectSort_Default(OrderDataMap, InOutContext.CombatSettingsManager->GetAttackSelectDefaultDistance(),
		InOutContext.CombatSettingsManager->GetAttackSelectDefaultAngle()));
	
#if KG_ENABLE_TARGET_SELECT_DEBUG_LOG
	for (auto& EntityID : OutResult.EntityIDs)
	{
		UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::QueryEntitiesInSingleRange, default sort, entity: %lld, distance: %f, angle: %f"),
			EntityID, OrderDataMap.Contains(EntityID) ? OrderDataMap[EntityID].Distance : -1, 
			OrderDataMap.Contains(EntityID) ? OrderDataMap[EntityID].Angle : -1);
	}
#endif
}

void TargetSelectorUtils::DoDistanceSort(FKGTargetSelectContext& InOutContext, const FVector& CenterPos, FKGTargetSelectResult& OutResult)
{
	if (!InOutContext.ActorManager.IsValid())
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::DoDistanceSort, invalid ActorManager"));
		return;
	}
	
	TMap<KGEntityID, float> DistanceMap;
	DistanceMap.Reserve(OutResult.EntityIDs.Num());
	for (auto EntityID : OutResult.EntityIDs)
	{
		auto* Entity = InOutContext.ActorManager->GetLuaEntity(EntityID);
		if (!Entity)
		{
			UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::DoDistanceSort, invalid Entity for EntityID %lld"), EntityID);
			continue;
		}
		
		float Distance = FVector::Dist(Entity->GetLocation(), CenterPos);
		if (ACharacter* BindCharacter = Cast<ACharacter>(Entity->GetBindedActor()))
		{
			if (auto* CapsuleComponent = BindCharacter->GetCapsuleComponent())
			{
				Distance -= CapsuleComponent->GetScaledCapsuleRadius();
			}
		}
		
		DistanceMap.Add(EntityID, Distance);
	}
	
	Algo::Sort(OutResult.EntityIDs, FKGTargetSelectSort_Distance(DistanceMap, InOutContext.TargetSelectParams.bDistanceSortUseIncOrder));
	
#if KG_ENABLE_TARGET_SELECT_DEBUG_LOG
	for (auto& EntityID : OutResult.EntityIDs)
	{
		UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::QueryEntitiesInSingleRange, distance sort, entity: %lld, distance: %f"),
			EntityID, DistanceMap.Contains(EntityID) ? DistanceMap[EntityID] : -1);	
	}
#endif
}

void TargetSelectorUtils::DoRandomSort(FKGTargetSelectContext& InOutContext, FKGTargetSelectResult& OutResult)
{
	Algo::RandomShuffle(OutResult.EntityIDs);
}

void TargetSelectorUtils::DoCameraDirSort(FKGTargetSelectContext& InOutContext, const FVector& CenterPos, FKGTargetSelectResult& OutResult)
{
	auto* CameraManager = InOutContext.GetCameraManager();
	if (!CameraManager)
	{
		UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::DoCameraDirSort, invalid CameraManager"));
		return;
	}
	
	const FVector& CameraForward = CameraManager->GetCameraRotation().Vector().GetSafeNormal2D();
#if KG_ENABLE_TARGET_SELECT_DRAW_DEBUG
	if (GEnableTargetSelectDrawDebug)
	{
		FVector LineStart(CenterPos);
		if (InOutContext.BaseActor.IsValid())
		{
			LineStart.Z = InOutContext.BaseActor->GetActorLocation().Z;
		}
		
		const auto& LineEnd = LineStart + CameraForward * 500.0f;
		UKismetSystemLibrary::DrawDebugArrow(CameraManager->GetWorld(), LineStart, LineEnd, 50.0f, 
			FColor::Magenta, GTargetSelectDrawDebugDuration, 10.0f);
	}
#endif
	
	TMap<KGEntityID, FKGTargetSelectSort_CameraDir::OrderData> OrderDataMap;
	OrderDataMap.Reserve(OutResult.EntityIDs.Num());
	for (auto EntityID : OutResult.EntityIDs)
	{
		auto* Entity = InOutContext.ActorManager->GetLuaEntity(EntityID);
		if (!Entity)
		{
			UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::DoCameraDirSort, invalid Entity for EntityID %lld"), EntityID);
			continue;
		}
		
		const auto& CenterPosToEntityPos = Entity->GetLocation() - CenterPos;
		float Distance = CenterPosToEntityPos.Size();
		
		auto& OrderData = OrderDataMap.Add(EntityID);
		OrderData.Distance = Distance;
		if (FMath::IsNearlyZero(Distance))
		{
			OrderData.Angle = 0.0f;
		}
		else
		{
			float CosTheta = FVector::DotProduct(CameraForward, CenterPosToEntityPos.GetSafeNormal2D());
			OrderData.Angle = FMath::RadiansToDegrees(FMath::Acos(CosTheta));
		}
	}
	
	Algo::Sort(OutResult.EntityIDs, FKGTargetSelectSort_CameraDir(OrderDataMap));
	
#if KG_ENABLE_TARGET_SELECT_DEBUG_LOG
	for (auto& EntityID : OutResult.EntityIDs)
	{
		UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::QueryEntitiesInSingleRange, camera dir sort, entity: %lld, distance: %f, angle: %f"),
			EntityID, OrderDataMap.Contains(EntityID) ? OrderDataMap[EntityID].Distance : -1, 
			OrderDataMap.Contains(EntityID) ? OrderDataMap[EntityID].Angle : -1);
	}
#endif
}

bool TargetSelectorUtils::IsValidFightTarget(ICppEntityInterface* SourceEntity, ICppEntityInterface* TargetEntity, FKGTargetSelectContext& InOutContext)
{
	if (!SourceEntity || !TargetEntity)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::IsValidFightTarget, invalid source or target entity, %s"), 
			*InOutContext.GetDebugInfo());
		return false;
	}
	
	auto* SourceInstigator = InOutContext.GetBaseEntityInstigator();
	if (!SourceInstigator)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::IsValidFightTarget, invalid source instigator %s"),
			*InOutContext.GetDebugInfo());
		return false;
	}
	
	const auto& Params = InOutContext.TargetSelectParams;
	const auto& TargetParams = Params.SearchTargetParams;
	if (Params.bIsEditor)
	{
		if (((TargetParams.FactionMask & static_cast<uint32>(EKGFactionType::Self)) == 0) && SourceEntity == TargetEntity ||
			(SourceInstigator == TargetEntity))
		{
			UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::IsValidFightTarget, editor mode, target == self"));
			return false;
		}
	}
	
	const auto& TargetEntityData = TargetEntity->GetEntityData();
	if (TargetEntityData.ObserverType != EKGObserverType::NONE)
	{
		UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::IsValidFightTarget, target observer type is not none, %s, %s"), 
			*InOutContext.GetDebugInfo(), *GetNameSafe(TargetEntity->GetBindedActor()));
		return false;
	}
	
	const auto& SourceInstigatorEntityData = SourceInstigator->GetEntityData();
	if (SourceInstigatorEntityData.BattleZoneID != TargetEntityData.BattleZoneID)
	{
		UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::IsValidFightTarget, target in different battle zone, %s, %s, %s"), 
			*GetNameSafe(TargetEntity->GetBindedActor()), 
			*SourceInstigatorEntityData.BattleZoneID.ToString(),
			*TargetEntityData.BattleZoneID.ToString());
		return false;
	}
	
	if (!IsValidFightTargetFaction(SourceEntity, TargetEntity, InOutContext))
	{
		UE_LOG(LogKGCombat, Log, TEXT("TargetSelectorUtils::IsValidFightTarget, target faction filter failed, %s, %s"),
			*InOutContext.GetDebugInfo(), *GetNameSafe(TargetEntity->GetBindedActor()));
		return false;
	}

	if (!IsValidFightTargetTargetType(SourceEntity, TargetEntity, InOutContext))
	{
		UE_LOG(LogKGCombat, Log, TEXT("TargetSelectorUtils::IsValidFightTarget, target type filter failed, %s, %s"),
			*InOutContext.GetDebugInfo(), *GetNameSafe(TargetEntity->GetBindedActor()));
		return false;
	}
	
	if (!IsValidFightTargetClassType(TargetEntity, InOutContext))
	{
		UE_LOG(LogKGCombat, Log, TEXT("TargetSelectorUtils::IsValidFightTargetTargetType, target class type filter failed, %s, %s"),
			*InOutContext.GetDebugInfo(), *GetNameSafe(TargetEntity->GetBindedActor()));
		return false;
	}
	
	if (!IsValidFightTargetReviseType(SourceEntity, TargetEntity, InOutContext))
	{
		UE_LOG(LogKGCombat, Log, TEXT("TargetSelectorUtils::IsValidFightTarget, revise type filter failed, %s, %s"),
			*InOutContext.GetDebugInfo(), *GetNameSafe(TargetEntity->GetBindedActor()));
		return false;
	}
	
	return true;
}

bool TargetSelectorUtils::IsValidFightTargetFaction(ICppEntityInterface* SourceEntity, ICppEntityInterface* TargetEntity, FKGTargetSelectContext& InOutContext)
{
	if (!SourceEntity || !TargetEntity)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::IsValidFightTargetFaction, invalid source or target entity"));
		return false;
	}
	
	const auto& Params = InOutContext.TargetSelectParams;
	const auto& TargetParams = Params.SearchTargetParams;
	
	if (TargetParams.QuerySelfType == EKGQuerySelfType::ExcludeAll)
	{
		UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::CheckTargetFaction, faction check failed(exclude all), %s, target: %s"),
			*InOutContext.GetDebugInfo(), *GetNameSafe(TargetEntity->GetBindedActor()));
		return false;
	}
	
	if (TargetParams.QuerySelfType == EKGQuerySelfType::ExcludeSelf && (SourceEntity == TargetEntity))
	{
		UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::CheckTargetFaction, faction check failed(exclude self), %s, target: %s"),
			*InOutContext.GetDebugInfo(), *GetNameSafe(TargetEntity->GetBindedActor()));
		return false;
	}
	
	if (TargetParams.QuerySelfType == EKGQuerySelfType::OnlySelf && (SourceEntity != TargetEntity))
	{
		UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::CheckTargetFaction, faction check failed(only self), %s, target: %s"),
			*InOutContext.GetDebugInfo(), *GetNameSafe(TargetEntity->GetBindedActor()));
		return false;
	}
	
	if (TargetParams.QuerySelfType == EKGQuerySelfType::OnlyOwner)
	{
		UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::IsValidFightTargetFaction, OnlyOwner is not supported"));
		return false;
	}
	
	return CheckTargetFaction(SourceEntity, TargetEntity, InOutContext, TargetParams.FactionMask);
}

bool TargetSelectorUtils::IsValidFightTargetTargetType(ICppEntityInterface* SourceEntity, ICppEntityInterface* TargetEntity, FKGTargetSelectContext& InOutContext)
{
	if (!SourceEntity || !TargetEntity)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::IsValidFightTargetTargetType, invalid source or target entity"));
		return false;
	}
	
	const auto& Params = InOutContext.TargetSelectParams;
	const auto& TargetParams = Params.SearchTargetParams;
	
	// 客户端交互物都不算做valid target, 后续需要补充tag的筛选
	if (TargetEntity->GetIsLocalPerformPet() || TargetEntity->GetIsInteractor())
	{
		UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::IsValidFightTargetTargetType, target is local perform pet or interactor, %s, %s"),
			*InOutContext.GetDebugInfo(), *GetNameSafe(TargetEntity->GetBindedActor()));
		return false;
	}
	
	if (TargetParams.TargetTypeMask == 0)
	{
		UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::IsValidFightTargetFaction, no target type mask, skip target type check, %s"),
			*InOutContext.GetDebugInfo());
		return true;
	}
	
	uint64 TargetType = static_cast<uint64>(EKGTargetActorType::None);
	const auto& TargetEntityData = TargetEntity->GetEntityData();
	if (TargetEntity->GetIsAvatar() || TargetEntity->GetIsMainPlayer())
	{
		TargetType = static_cast<uint64>(EKGTargetActorType::Player);
	}
	else if (TargetEntity->GetIsNpc())
	{
		if (TargetEntityData.BossType == EBossType::NoMonster)
		{
			if (TargetEntityData.NpcType == ENpcType::Task)
			{
				TargetType = static_cast<uint64>(EKGTargetActorType::TaskNpc);
			}
			else if (TargetEntityData.NpcType == ENpcType::CombatVehicle)
			{
				// 攻城车刚创建
				TargetType = static_cast<uint64>(EKGTargetActorType::Vehicle);
			}
		}
		if (TargetEntityData.BossType == EBossType::CREEP)
		{
			TargetType = static_cast<uint64>(EKGTargetActorType::NormalMonster);
		}
		else if (TargetEntityData.BossType == EBossType::Elite)
		{
			TargetType = static_cast<uint64>(EKGTargetActorType::EliteMonster);
		}
		else if (TargetEntityData.BossType == EBossType::BOSS)
		{
			TargetType = static_cast<uint64>(EKGTargetActorType::Boss);
		}
		else if (TargetEntityData.BossType == EBossType::Building)
		{
			TargetType = static_cast<uint64>(EKGTargetActorType::Building);
		}
		else if (TargetEntityData.BossType == EBossType::Create)
		{
			TargetType = static_cast<uint64>(EKGTargetActorType::CreateMonster);
		}
		else if (TargetEntityData.BossType == EBossType::Vehicle)
		{
			// 攻城车变成monster后
			TargetType = static_cast<uint64>(EKGTargetActorType::Vehicle);
		}
		
		if (TargetEntity->GetIsSummon())
		{
			TargetType = TargetType + static_cast<uint64>(EKGTargetActorType::Summon);
		}
	}
	else if (TargetEntity->GetIsInteractor())
	{
		TargetType = static_cast<uint64>(EKGTargetActorType::Interactor);
	}
	
	if (TargetType == static_cast<uint64>(EKGTargetActorType::None))
	{
		UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::IsValidFightTargetTargetType, %s target type is None, %s"),
			*GetNameSafe(TargetEntity->GetBindedActor()), *InOutContext.GetDebugInfo());
		return false;
	}
	
	bool bTargetTypeCheckResult = (TargetParams.TargetTypeMask & TargetType) > 0;
	
	UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::IsValidFightTargetTargetType, target type check %s, %s, target: %s, target type: %lld, target type mask: %lld"),
		bTargetTypeCheckResult ? TEXT("passed") : TEXT("failed"),
		*InOutContext.GetDebugInfo(), *GetNameSafe(TargetEntity->GetBindedActor()), 
		TargetType, TargetParams.TargetTypeMask);
	
	return bTargetTypeCheckResult;
}

bool TargetSelectorUtils::IsValidFightTargetClassType(ICppEntityInterface* TargetEntity, FKGTargetSelectContext& InOutContext)
{
	const auto ClassTypeMask = InOutContext.TargetSelectParams.SearchTargetParams.ClassTypeMask;
	if (ClassTypeMask == 0)
	{
		UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::IsValidFightTargetClassType, no class type mask, skip class type check, %s"),
			*InOutContext.GetDebugInfo());
		return true;
	}
	
	if (!TargetEntity)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::IsValidFightTargetClassType, invalid target entity"));
		return false;
	}
	
	if (!TargetEntity->GetIsMainPlayer() && !TargetEntity->GetIsAvatar())
	{
		UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::IsValidFightTargetClassType, target instigator is not main player or avatar, %s, %s"),
			*InOutContext.GetDebugInfo(), *GetNameSafe(TargetEntity->GetBindedActor()));
		return false;
	}
	
	const auto& TargetEntityData = TargetEntity->GetEntityData();
	const bool bResult = (ClassTypeMask & TargetEntityData.PlayerClassTypeMask) > 0;
	
	UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::IsValidFightTargetClassType, target class type check %s, %s, target: %s, target class type: %d, class type mask: %d"),
		bResult ? TEXT("passed") : TEXT("failed"),
		*InOutContext.GetDebugInfo(), *GetNameSafe(TargetEntity->GetBindedActor()), 
		TargetEntityData.PlayerClassTypeMask, ClassTypeMask);
	
	return bResult;
}

bool TargetSelectorUtils::IsValidFightTargetReviseType(ICppEntityInterface* SourceEntity, ICppEntityInterface* TargetEntity, FKGTargetSelectContext& InOutContext)
{
	if (!SourceEntity || !TargetEntity)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::IsValidFightTargetReviseType, invalid source or target entity"));
		return false;
	}
	
	const auto& Params = InOutContext.TargetSelectParams;
	const auto& TargetParams = Params.SearchTargetParams;
	const bool bTargetIsDead = TargetEntity->IsDead();
	if (TargetParams.EntityAliveType == EKGEntityAliveType::Alive && bTargetIsDead)
	{
		UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::IsValidFightTargetReviseType, target is dead but need alive, %s, %s"),
			*InOutContext.GetDebugInfo(), *GetNameSafe(TargetEntity->GetBindedActor()));
		return false;
	}
	
	if (TargetParams.EntityAliveType == EKGEntityAliveType::Dead && !bTargetIsDead)
	{
		UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::IsValidFightTargetReviseType, target is alive but need dead, %s, %s"),
			*InOutContext.GetDebugInfo(), *GetNameSafe(TargetEntity->GetBindedActor()));
		return false;
	}
	
	const bool bCanHitTarget = CanTargetBeHit(SourceEntity, TargetEntity, InOutContext);
	if (TargetParams.HitLimitType == EKGHitLimitType::NonLimit && !bCanHitTarget)
	{
		UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::IsValidFightTargetReviseType, target cannot be hit and no limit, %s, %s"),
			*InOutContext.GetDebugInfo(), *GetNameSafe(TargetEntity->GetBindedActor()));
		return false;
	}
	
	if (TargetParams.HitLimitType == EKGHitLimitType::Limit && bCanHitTarget)
	{
		UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::IsValidFightTargetReviseType, target can be hit and with limit, %s, %s"),
			*InOutContext.GetDebugInfo(), *GetNameSafe(TargetEntity->GetBindedActor()));
		return false;
	}
	
	UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::IsValidFightTargetReviseType, hit limit type check passed, %s, target: %s"),
		*InOutContext.GetDebugInfo(), *GetNameSafe(TargetEntity->GetBindedActor()));
	
	return true;
}

bool TargetSelectorUtils::CanTargetBeHit(ICppEntityInterface* SourceEntity, ICppEntityInterface* TargetEntity, FKGTargetSelectContext& InOutContext)
{
	if (!SourceEntity || !TargetEntity)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::CanTargetBeHit, invalid source or target entity"));
		return false;
	}
	
	const auto& Params = InOutContext.TargetSelectParams;
	if (Params.bIsEditor)
	{
		return true;
	}
	
	auto* SourceInstigator = InOutContext.GetBaseEntityInstigator();
	if (!SourceInstigator)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::CanTargetBeHit, invalid source instigator %s"),
			*InOutContext.GetDebugInfo());
		return false;
	}

	const auto& SourceInstigatorEntityData = SourceInstigator->GetEntityData();
	const auto& TargetEntityData = TargetEntity->GetEntityData();
	if (!SourceInstigatorEntityData.BattleZoneID.IsNone() && !TargetEntityData.BattleZoneID.IsNone() &&
		SourceInstigatorEntityData.BattleZoneID != TargetEntityData.BattleZoneID)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::CanTargetBeHit, battle zone id is not same %s"),
			*InOutContext.GetDebugInfo());
		return false;
	}	
	
	if (TargetEntityData.bIsLockLimit)
	{
		if (CheckTargetFaction(SourceEntity, TargetEntity, InOutContext, TargetEntityData.LockLimitCamp))
		{
			return false;
		}
	}
	
	return true;
}

bool TargetSelectorUtils::CheckTargetFaction(
	ICppEntityInterface* SourceEntity, ICppEntityInterface* TargetEntity, FKGTargetSelectContext& InOutContext, uint32 FactionMask)
{
	if (!SourceEntity || !TargetEntity)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::CheckTargetFaction, invalid source or target entity"));
		return false;
	}
	
	if (FactionMask == 0)
	{
		UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::CheckTargetFaction, no faction mask, skip faction check, %s"),
			*InOutContext.GetDebugInfo());
		return true;
	}
	
	if ((FactionMask & static_cast<uint32>(EKGFactionType::SelfExclusive)) && SourceEntity != TargetEntity)
	{
		UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::CheckTargetFaction, SelfExclusive check failed, %s"),
			*InOutContext.GetDebugInfo());
		return false;
	}
	
	const auto& SourceEntityData = SourceEntity->GetEntityData();
	const auto& TargetEntityData = TargetEntity->GetEntityData();
	if ((FactionMask & static_cast<uint32>(EKGFactionType::Self)) && (SourceEntityData.FinalOwnerID == TargetEntityData.FinalOwnerID))
	{
		UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::CheckTargetFaction, self check passed, %s"),
			*InOutContext.GetDebugInfo());
		return true;
	}
	
	// if (FactionMask & static_cast<uint32>(EKGFactionType::SelfSibling))
	// {
	// 	UE_LOG(LogKGCombat, Error, TEXT("TargetSelectorUtils::CheckTargetFaction, SelfSibling faction type is not supported"));
	// 	return false;
	// }
	
	// 在客户端应用场景下, source或者target至少有一个是主角
	auto* SourceInstigator = InOutContext.GetBaseEntityInstigator();
	if (!SourceInstigator)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::CheckTargetFaction, invalid source instigator %s"),
			*InOutContext.GetDebugInfo());
		return false;
	}
	
	auto* TargetInstigator = GetEntityInstigator(TargetEntity, InOutContext.ActorManager.Get());
	if (!TargetInstigator)
	{
		UE_LOG(LogKGCombat, Log, TEXT("TargetSelectorUtils::CheckTargetFaction, target instigator is invalid, use target entity, %s, %s"),
			*InOutContext.GetDebugInfo(), *GetNameSafe(TargetEntity->GetBindedActor()));
		return false;
	}
	
	FCppEntityData* NonMainPlayerEntityDataPtr; 
	if (SourceInstigator->GetIsMainPlayer())
	{
		NonMainPlayerEntityDataPtr = &TargetInstigator->GetEntityData();
	}
	else if (TargetInstigator->GetIsMainPlayer())
	{
		NonMainPlayerEntityDataPtr = &SourceInstigator->GetEntityData();
	}
	else
	{
		UE_LOG(LogKGCombat, Warning, TEXT("TargetSelectorUtils::CheckTargetFaction, neither source nor target is main player, %s, %s"),
			*InOutContext.GetDebugInfo(), *GetNameSafe(TargetEntity->GetBindedActor()));
		return false;
	}
	
	ECampType CampTypeWithMainPlayer = NonMainPlayerEntityDataPtr->CampType;
	bool bIsMainPlayerTeammate = NonMainPlayerEntityDataPtr->bIsMainPlayerTeammate;
	bool bIsMainPlayerGroupMember = NonMainPlayerEntityDataPtr->bIsMainPlayerGroupMember;
	
	EKGFactionType FactionType;
	if (CampTypeWithMainPlayer == ECampType::Enemy)
	{
		FactionType = EKGFactionType::Enemy;
	}
	else if (CampTypeWithMainPlayer == ECampType::Neutral)
	{
		FactionType = EKGFactionType::Neutral;
	}
	else if (bIsMainPlayerTeammate || SourceInstigator == TargetInstigator)
	{
		FactionType = EKGFactionType::TeamMate;
	}
	else if (bIsMainPlayerGroupMember)
	{
		FactionType = EKGFactionType::GroupMate;
	}
	else
	{
		FactionType = EKGFactionType::Allies;
	}
	
	bool bFactionCheckResult = FactionMask & static_cast<uint32>(FactionType);
	
	UE_LOG(LogKGCombat, Verbose, TEXT("TargetSelectorUtils::CheckTargetFaction, faction check %s, %s, target: %s, faction type: %d, faction mask: %d"),
		bFactionCheckResult ? TEXT("passed") : TEXT("failed"),
		*InOutContext.GetDebugInfo(), *GetNameSafe(TargetEntity->GetBindedActor()), static_cast<uint32>(FactionType), FactionMask);
	
	return bFactionCheckResult;
}

void TargetSelectorUtils::DrawDebugEntityCapsule(UKGUEActorManager* ActorManager, KGEntityID EntityID, const FColor& Color, float Duration, float Thickness)
{
	if (!ActorManager)
	{
		return;
	}
	
	auto* Entity = ActorManager->GetLuaEntity(EntityID);
	if (!Entity)
	{
		return;
	}
	
	AActor* BindedActor = Entity->GetBindedActor();
	if (!BindedActor)
	{
		return;
	}
	
	UCapsuleComponent* CapsuleComponent;
	if (ACharacter* BindCharacter = Cast<ACharacter>(BindedActor))
	{
		CapsuleComponent = BindCharacter->GetCapsuleComponent();
	}
	else
	{
		CapsuleComponent = BindedActor->FindComponentByClass<UCapsuleComponent>();
	}
	
	const auto& ActorLocation = BindedActor->GetActorLocation();
	if (CapsuleComponent)
	{
		DrawDebugCapsule(
			ActorManager->GetWorld(),
			ActorLocation,
			CapsuleComponent->GetScaledCapsuleHalfHeight(),
			CapsuleComponent->GetScaledCapsuleRadius(),
			BindedActor->GetActorRotation().Quaternion(),
			Color,
			false,
			Duration,
			0,
			Thickness
		);
		return;
	}
	
	// 找不到capsule 直接DrawActorBounds
	const auto& ActorBounds = BindedActor->GetActorBounds();
	const float HalfHeight = ActorBounds.GetExtent().Z;
	const float Radius = ActorBounds.GetExtent().Size2D();
	DrawDebugCylinder(
		ActorManager->GetWorld(),
		ActorLocation - FVector(0.0f, 0.0f, HalfHeight),
		ActorLocation + FVector(0.0f, 0.0f, HalfHeight),
		Radius, 12, Color,
		false,
		Duration,
		0,
		Thickness
	);
}

void TargetSelectorUtils::DrawDebugSequenceInfo(UKGUEActorManager* ActorManager, KGEntityID EntityID, int32 SeqID)
{
	if (!ActorManager)
	{
		return;
	}
	
	auto* Entity = ActorManager->GetLuaEntity(EntityID);
	if (!Entity)
	{
		return;
	}
	
	AActor* BindedActor = Entity->GetBindedActor();
	if (!BindedActor)
	{
		return;
	}
	
	DrawDebugString(ActorManager->GetWorld(), BindedActor->GetActorLocation(), 
		FString::Printf(TEXT("%d"), SeqID), nullptr, FColor::Red, GTargetSelectDrawDebugDuration, false, 2.0f);
}

void TargetSelectorUtils::DrawDebugFan3D(
	UWorld* WorldContext, const FVector& Center, float InnerRadius, float OuterRadius, int32 Segments, const FRotator& Rotation,
	float HalfAngle, float Height, const FColor& Color, float Duration, float Thickness)
{
	if (!WorldContext)
	{
		return;
	}
	
    // Convert angles from degrees to radians
    float FacingAngleInRadians = FMath::DegreesToRadians(Rotation.Yaw);
    float HalfAngleInRadians = FMath::DegreesToRadians(HalfAngle);
    float TotalAngle = HalfAngleInRadians * 2;

    FVector AxisX(1.0f, 0.0f, 0.0f);
    FVector AxisY(0.0f, 1.0f, 0.0f);

    float AngleStep = TotalAngle / Segments;
    float Angle = FacingAngleInRadians - HalfAngleInRadians;

    bool IsFirst = true;
    int32 RemainingSegments = Segments;

    FVector CenterPosBottom = FVector(Center.X, Center.Y, Center.Z - Height / 2.0f);
    FVector CenterPosTop = FVector(Center.X, Center.Y, Center.Z + Height / 2.0f);

    FVector Vertex1Inner, Vertex1Outer, Vertex1InnerTop, Vertex1OuterTop;
    FVector Vertex2Inner, Vertex2Outer, Vertex2InnerTop, Vertex2OuterTop;

    while (RemainingSegments > 0)
    {
        // Calculate vertices for the current segment
        Vertex1Inner = CenterPosBottom + (AxisX * FMath::Cos(Angle) + AxisY * FMath::Sin(Angle)) * InnerRadius;
        Vertex1Outer = CenterPosBottom + (AxisX * FMath::Cos(Angle) + AxisY * FMath::Sin(Angle)) * OuterRadius;
        Vertex1InnerTop = CenterPosTop + (AxisX * FMath::Cos(Angle) + AxisY * FMath::Sin(Angle)) * InnerRadius;
        Vertex1OuterTop = CenterPosTop + (AxisX * FMath::Cos(Angle) + AxisY * FMath::Sin(Angle)) * OuterRadius;

        Angle += AngleStep;

        Vertex2Inner = CenterPosBottom + (AxisX * FMath::Cos(Angle) + AxisY * FMath::Sin(Angle)) * InnerRadius;
        Vertex2Outer = CenterPosBottom + (AxisX * FMath::Cos(Angle) + AxisY * FMath::Sin(Angle)) * OuterRadius;
        Vertex2InnerTop = CenterPosTop + (AxisX * FMath::Cos(Angle) + AxisY * FMath::Sin(Angle)) * InnerRadius;
        Vertex2OuterTop = CenterPosTop + (AxisX * FMath::Cos(Angle) + AxisY * FMath::Sin(Angle)) * OuterRadius;

        // Draw lines for the inner circle (bottom and top)
        DrawDebugLine(WorldContext, Vertex1Inner, Vertex2Inner, Color, false, Duration, 0, Thickness);
        DrawDebugLine(WorldContext, Vertex1InnerTop, Vertex2InnerTop, Color, false, Duration, 0, Thickness);

        // Draw lines for the outer circle (bottom and top)
        DrawDebugLine(WorldContext, Vertex1Outer, Vertex2Outer, Color, false, Duration, 0, Thickness);
        DrawDebugLine(WorldContext, Vertex1OuterTop, Vertex2OuterTop, Color, false, Duration, 0, Thickness);

        RemainingSegments--;

        if (IsFirst)
        {
            // Draw fan's left side (bottom and top)
            DrawDebugLine(WorldContext, Vertex1Inner, Vertex1Outer, Color, false, Duration, 0, Thickness);
            DrawDebugLine(WorldContext, Vertex1InnerTop, Vertex1OuterTop, Color, false, Duration, 0, Thickness);

            // Draw fan's left side (bottom to top inner and outer)
            DrawDebugLine(WorldContext, Vertex1Inner, Vertex1InnerTop, Color, false, Duration, 0, Thickness);
            DrawDebugLine(WorldContext, Vertex1Outer, Vertex1OuterTop, Color, false, Duration, 0, Thickness);

            IsFirst = false;
        }

        if (RemainingSegments <= 0)
        {
            // Draw fan's right side (bottom and top)
            DrawDebugLine(WorldContext, Vertex2Inner, Vertex2Outer, Color, false, Duration, 0, Thickness);
            DrawDebugLine(WorldContext, Vertex2InnerTop, Vertex2OuterTop, Color, false, Duration, 0, Thickness);

            // Draw fan's right side (bottom to top inner and outer)
            DrawDebugLine(WorldContext, Vertex2Inner, Vertex2InnerTop, Color, false, Duration, 0, Thickness);
            DrawDebugLine(WorldContext, Vertex2Outer, Vertex2OuterTop, Color, false, Duration, 0, Thickness);
        }
    }
}
