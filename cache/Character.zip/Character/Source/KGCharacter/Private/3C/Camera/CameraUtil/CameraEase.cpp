// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Camera/CameraUtil/CameraEase.h"
#include "Misc/MathFormula.h"
#include "Curves/CurveFloat.h"

FRotator FCameraEaseCalculate::LerpRotationWithShortestPath(const FRotator& Source, const FRotator& Target,
                                                            float BlendPct)
{
	FRotator TargetRotation = Target;
	FRotator Result;
	Result.Pitch = FRotator::NormalizeAxis(Source.Pitch);
	Result.Yaw = FRotator::NormalizeAxis(Source.Yaw);
	Result.Roll = FRotator::NormalizeAxis(Source.Roll);

	TargetRotation.Pitch = MathFormula::SameSignAngle(Result.Pitch, TargetRotation.Pitch);
	TargetRotation.Yaw = MathFormula::SameSignAngle(Result.Yaw, TargetRotation.Yaw);
	TargetRotation.Roll = MathFormula::SameSignAngle(Result.Roll, TargetRotation.Roll);

	const FRotator DeltaAng = (TargetRotation - Result).GetNormalized();
	Result = Result + BlendPct * DeltaAng;
	Result.Normalize();
	return Result;
}

float FCameraEaseCalculate::GetCurveNormalPct(UCurveFloat* Curve, float Pct)
{
	if(Curve == nullptr)
	{
		return Pct;
	}

	float MinTime = 0, MaxTime = 0;
	float MinValue = 0, MaxValue = 0;
	Curve->GetTimeRange(MinTime, MaxTime);
	Curve->GetValueRange(MinValue, MaxValue);
	if(MaxValue - MinValue == 0 || MaxTime - MinTime == 0)
	{
		return 1;
	}
	const float CurveValue = Curve->GetFloatValue(Pct * (MaxTime - MinTime) + MinTime);
	return (CurveValue - MinValue) / (MaxValue - MinValue);
}

void FCatmullRomSplineSmoothCurve::Init(const TArray<FVector>& InWorldLocations, float InAlpha, float InTension)
{
	if(InWorldLocations.Num() < 2)
	{
		bValid = false;
		return;
	}

	WorldLocation.Empty();
	WorldLocation.Emplace(InWorldLocations[0]);
	WorldLocation.Append(InWorldLocations);
	WorldLocation.Emplace(InWorldLocations.Last());

	NumSegments = WorldLocation.Num() - 3;
	Alpha = InAlpha;
	Tension = InTension;
}

void FCatmullRomSplineSmoothCurve::Evaluate(float Pct, FVector& OutResult)
{
	if(bValid)
	{
		if(WorldLocation.Num() == 1)
		{
			OutResult = WorldLocation[0];
		}
		return;
	}

	Pct = FMath::Clamp(Pct, 0.f, 1.f);
	float SegmentFloat = Pct * (NumSegments);
	int32 SegmentIndex = FMath::Clamp(FMath::FloorToInt(SegmentFloat), 0, NumSegments - 1);
	float T = SegmentFloat - SegmentIndex;
	// UE_LOG(LogTemp, Log, TEXT("FCatmullRomSplineSmoothCurve Pct:%f T:%f SegmentIndex:%d"), Pct, T, SegmentIndex);

	FVector& P0 = WorldLocation[SegmentIndex];
	FVector& P1 = WorldLocation[SegmentIndex + 1];
	FVector& P2 = WorldLocation[SegmentIndex + 2];
	FVector& P3 = WorldLocation[SegmentIndex + 3];

	const float EPS = 1e-6f;
	if ((P1 - P2).SizeSquared() < EPS)
	{
		OutResult = FMath::Lerp(P1, P2, T);
		return;
	}
	
	float T01 = FMath::Pow(FMath::Max(FVector::Distance(P0, P1), EPS), Alpha);
	float T12 = FMath::Pow(FMath::Max(FVector::Distance(P1, P2), EPS), Alpha);
	float T23 = FMath::Pow(FMath::Max(FVector::Distance(P2, P3), EPS), Alpha);

	FVector M1 = (1.f - Tension) * (P2 - P1 + T12 * ((P1 - P0) / T01 - (P2 - P0) / (T01 + T12)));
	FVector M2 = (1.f - Tension) * (P2 - P1 + T12 * ((P3 - P2) / T23 - (P3 - P1) / (T12 + T23)));

	OutResult =
		(2.f * (P1 - P2) + M1 + M2) * T * T * T +
		(-3.f * (P1 - P2) - M1 - M1 - M2) * T * T +
		M1 * T +
		P1;
}
