#include "3C/Camera/PostProcessNew/PostProcessInstance/PPMaterialBase.h"

#include "Manager/KGCppAssetManager.h"
#include "3C/Material/KGMaterialCommon.h"
#include "3C/Material/KGMaterialManager.h"
#include "3C/Core/KGUEActorManager.h"
#include "3C/Camera/PostProcessNew/PostProcessManager.h"
#include "Engine/Texture.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Materials/MaterialInterface.h"

void KGPPMaterialBase::InitParams(const FKGPPCommonParams& CommonParams, EKGPostProcessType InPPType, const FString& InMaterialPath, const FString& InPlaneMeshMaterialPath,
	int32 InViewPriority, const FName& InIntensityParamName, const FKGPPMaterialParams& InParams, TWeakObjectPtr<UPostProcessManager> InPPManager)
{
	KGPPBase::InitParams(CommonParams, InPPManager);
	PPType = InPPType;
	MaterialPath = InMaterialPath;
	PlaneMeshMaterialPath = InPlaneMeshMaterialPath;
	ViewPriority = InViewPriority;
	IntensityParamName = InIntensityParamName;
	PPMaterialParams = InParams;
}

bool KGPPMaterialBase::OnTaskStart()
{
	if (!KGPPBase::OnTaskStart())
	{
		return false;
	}
	
	MaterialManager = UKGMaterialManager::GetInstance(PostProcessManager.Get());
	if (!MaterialManager.IsValid())
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialBase::OnTaskStart: MaterialManager is null, %s"), *GetDebugInfo());
		return false;
	}

	if (PostProcessManager.IsValid())
	{
		const bool bUsePlaneMesh = !PlaneMeshMaterialPath.IsEmpty() && PostProcessManager->IsPlaneMeshPostProcessEnabled();
		if (bUsePlaneMesh)
		{
			if (PostProcessManager->UseViewportPlaneMeshHandler())
			{
				PlaneMeshHandler = MakeShared<KGPPPlaneMeshHandlerViewport>();
			}
			else
			{
				PlaneMeshHandler = MakeShared<KGPPPlaneMeshHandlerCameraManager>();
			}
			// 这里要在 OnTaskStart 的时候设置, 避免存在获取 PlaneMeshDistance 时, 其他PlaneMesh PPInstance的PlaneMeshDistance还没准备好
			PlaneMeshDistance = PostProcessManager->GetPlaneMeshDistance(this);
		}	
	}
	
	TryLoadAssets();
	
	return true;
}

void KGPPMaterialBase::OnTaskTick(float DeltaTime)
{
	KGPPBase::OnTaskTick(DeltaTime);

	if (PlaneMeshHandler.IsValid())
	{
		PlaneMeshHandler->UpdatePlaneMeshOnPPInstanceUpdate();

		if (auto* PlaneMeshComponent = PlaneMeshHandler->GetPlaneMeshComponent())
		{
			const bool bIsPlaneMeshVisible = PlaneMeshComponent->IsVisible();
			const bool bCanOutputPostProcess = CanOutputPostProcess();
			if (bIsPlaneMeshVisible != bCanOutputPostProcess)
			{
				PlaneMeshComponent->SetVisibility(bCanOutputPostProcess);
			}
		}
	}
}

void KGPPMaterialBase::OnTaskEnd(EKGPostProcessStopReason StopReason)
{
	if (AssetLoadID != 0)
	{
		UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(PostProcessManager.Get());
		if (AssetManager)
		{
			AssetManager->CancelAsyncLoadByLoadID(AssetLoadID);
		}
		else
		{
			UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialBase::OnTaskEnd: AssetManager is null, %s"), *GetDebugInfo());
		}
		AssetLoadID = 0;
	}

	if (MaterialParamUpdateTaskIDs.Num() > 0)
	{
		if (MaterialManager.IsValid())
		{
			for (const auto& Kvp : MaterialParamUpdateTaskIDs)
			{
				MaterialManager->RemoveMaterialParamUpdateTask(Kvp.Value);
			}
		}
		else
		{
			UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialBase::OnTaskEnd: MaterialManager is null, %s"), *GetDebugInfo());
		}
		
		MaterialParamUpdateTaskIDs.Empty();
	}

	if (PlaneMeshHandler.IsValid())
	{
		PlaneMeshHandler->DestroyPlaneMeshHandler();
	}

	PPMaterial.Reset();
	ParamNameToAssets.Empty();
	
	KGPPBase::OnTaskEnd(StopReason);
}

FString KGPPMaterialBase::GetDebugInfo() const
{
	return FString::Printf(TEXT("[%s] ID[%d] m[%s][%s] %f/%f"),
		PostProcessManager.IsValid() ? *PostProcessManager->GetPPTypeName(GetPPType()) : TEXT("[invalid]"),
		PostProcessID, PlaneMeshHandler.IsValid() ? TEXT("Mesh") : TEXT("PP"), *GetMaterialPath(), AccumulateLifeTimeSeconds, TotalLifeTimeSeconds);
}

FString KGPPMaterialBase::GetMaterialParamDebugInfo()
{
	TArray<FName> ScalarParamNames;
	TArray<FName> VectorParamNames;
	TArray<FName> TextureParamNames;
				
	TArray<FName> TempParamNames;
	PPMaterialParams.ScalarParams.GenerateKeyArray(TempParamNames);
	ScalarParamNames.Append(TempParamNames);
	PPMaterialParams.ScalarLinearSampleParams.GenerateKeyArray(TempParamNames);
	ScalarParamNames.Append(TempParamNames);
	PPMaterialParams.ScalarLinearBlendParams.GenerateKeyArray(TempParamNames);
	ScalarParamNames.Append(TempParamNames);
	if (!IntensityParamName.IsNone())
	{
		ScalarParamNames.AddUnique(IntensityParamName);
	}
	
	PPMaterialParams.VectorParams.GenerateKeyArray(TempParamNames);
	VectorParamNames.Append(TempParamNames);
	PPMaterialParams.VectorLinearSampleParams.GenerateKeyArray(TempParamNames);
	VectorParamNames.Append(TempParamNames);
	PPMaterialParams.ActorLocationParams.GenerateKeyArray(TempParamNames);
	VectorParamNames.Append(TempParamNames);
	PPMaterialParams.EntityLocationParams.GenerateKeyArray(TempParamNames);
	VectorParamNames.Append(TempParamNames);

	PPMaterialParams.TextureParams.GenerateKeyArray(TempParamNames);
	TextureParamNames.Append(TempParamNames);
				
	for (const auto& ParamKvp : PPMaterialParams.CurveParams)
	{
		if (!ParamNameToAssets.Contains(ParamKvp.Key))
		{
			continue;
		}
		UCurveBase* CurveBase = Cast<UCurveBase>(ParamNameToAssets[ParamKvp.Key].Get());
		if (!CurveBase)
		{
			UE_LOG(LogKGMaterial, Error, TEXT("KGPPMaterialBase::GetMaterialParamDebugInfo, invalid curve asset %s"), *ParamKvp.Key.ToString());
			continue;
		}
		if (CurveBase->IsA(UCurveFloat::StaticClass()))
		{
			ScalarParamNames.Add(ParamKvp.Key);
		}
		else
		{
			VectorParamNames.Add(ParamKvp.Key);
		}
	}

	return KGMaterialUtils::GetMaterialParamInfoDebugUsage(PPMaterial.Get(), ScalarParamNames, VectorParamNames, TextureParamNames);
}

bool KGPPMaterialBase::CanOutputPostProcess() const
{
	return KGPPBase::CanOutputPostProcess() && PPMaterial.IsValid();
}

bool KGPPMaterialBase::GetPostProcessResult(FPostProcessSettings& OutPPSettings, float& OutPPBlendWeight, EViewTargetBlendOrder& OutPPBlendOrder) const
{
	if (PlaneMeshHandler.IsValid())
	{
		return false;
	}
	
	if (!CanOutputPostProcess())
	{
		return false;
	}
	
	FWeightedBlendable Blendable;
	Blendable.Weight = 1.0f;
	Blendable.Object = PPMaterial.Get();
	OutPPSettings.WeightedBlendables.Array.Add(Blendable);
	OutPPBlendWeight = 1.0f;
	OutPPBlendOrder = VTBlendOrder_Base;

	return true;
}

void KGPPMaterialBase::OnBlendWeightChanged()
{
	if (IntensityParamName.IsNone())
	{
		return;
	}
	
	UpdateScalarParam(IntensityParamName, BlendWeightCalculator.CurrentBlendWeight);
}

bool KGPPMaterialBase::IsPlaneMeshVisible() const
{
	if (PlaneMeshHandler.IsValid())
	{
		if (auto* PlaneMeshComponent = PlaneMeshHandler->GetPlaneMeshComponent())
		{
			return PlaneMeshComponent->IsVisible();
		}
	}

	return false;
}

void KGPPMaterialBase::AdvancePPTime(float DeltaTime)
{
	KGPPBase::AdvancePPTime(DeltaTime);
	
	if (PPMaterial.IsValid() && MaterialManager.IsValid())
	{
		for (const auto& Kvp : MaterialParamUpdateTaskIDs)
		{
			MaterialManager->AdvanceUpdateTask(Kvp.Value, DeltaTime);
		}
	}
}

void KGPPMaterialBase::UpdateScalarParam(const FName& ParamName, float ParamValue)
{
	PPMaterialParams.ScalarParams.Add(ParamName, ParamValue);
	
	if (PPMaterial.IsValid()) 
	{
		PPMaterial->SetScalarParameterValue(ParamName, ParamValue);
	}
}

void KGPPMaterialBase::UpdateVectorParam(const FName& ParamName, const FLinearColor& ParamValue)
{
	PPMaterialParams.VectorParams.Add(ParamName, ParamValue);
	
	if (PPMaterial.IsValid())
	{
		PPMaterial->SetVectorParameterValue(ParamName, ParamValue);
	}
}

void KGPPMaterialBase::UpdateActorLocationParam(const FName& ParamName, TWeakObjectPtr<AActor> ParamValue)
{
	PPMaterialParams.ActorLocationParams.Add(ParamName, ParamValue);

	if (PPMaterialParams.EntityLocationParams.Contains(ParamName))
	{
		PPMaterialParams.EntityLocationParams.Remove(ParamName);
	}
	
	if (!PPMaterial.IsValid())
	{
		return;
	}
	
	if (!MaterialManager.IsValid())
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialBase::UpdateActorLocationParam: MaterialManager is null, %s"), *GetDebugInfo());
		return;
	}
	
	if (MaterialParamUpdateTaskIDs.Contains(ParamName))
	{
		MaterialManager->RemoveMaterialParamUpdateTask(MaterialParamUpdateTaskIDs[ParamName]);
	}
	
	const auto TaskID = MaterialManager->AddActorLocationParamByDynamicMaterialInstance(
		ParamName, PPMaterial.Get(), ParamValue.Get(), true);
	MaterialParamUpdateTaskIDs.Add(ParamName, TaskID);
}

void KGPPMaterialBase::RemoveActorLocationParam(const FName& ParamName)
{
	if (!PPMaterialParams.ActorLocationParams.Contains(ParamName))
	{
		UE_LOG(LogKGPP, Log, TEXT("KGPPMaterialBase::RemoveActorLocationParam: Param %s not found in ActorLocationParams, %s"), *ParamName.ToString(), *GetDebugInfo());
		return;
	}
	PPMaterialParams.ActorLocationParams.Remove(ParamName);

	if (!PPMaterial.IsValid())
	{
		return;
	}
	
	if (!MaterialManager.IsValid())
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialBase::RemoveActorLocationParam: MaterialManager is null, %s"), *GetDebugInfo());
		return;
	}
	
	if (MaterialParamUpdateTaskIDs.Contains(ParamName))
	{
		MaterialManager->RemoveMaterialParamUpdateTask(MaterialParamUpdateTaskIDs[ParamName]);
		MaterialParamUpdateTaskIDs.Remove(ParamName);
	}
}

void KGPPMaterialBase::UpdateEntityLocationParams(const FName& ParamName, KGEntityID EntityID)
{
	PPMaterialParams.EntityLocationParams.Add(ParamName, EntityID);

	if (PPMaterialParams.ActorLocationParams.Contains(ParamName))
	{
		PPMaterialParams.ActorLocationParams.Remove(ParamName);
	}
	
	if (!PPMaterial.IsValid())
	{
		return;
	}
	
	if (!MaterialManager.IsValid())
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialBase::UpdateEntityLocationParams: MaterialManager is null, %s"), *GetDebugInfo());
		return;
	}

	UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(PostProcessManager.Get());
	if (!ActorManager)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialBase::UpdateEntityLocationParams: ActorManager is null, %s"), *GetDebugInfo());
		return;
	}
	
	if (MaterialParamUpdateTaskIDs.Contains(ParamName))
	{
		MaterialManager->RemoveMaterialParamUpdateTask(MaterialParamUpdateTaskIDs[ParamName]);
	}
	
	DoAddEntityLocationUpdateTask(ParamName, EntityID, ActorManager);
}

void KGPPMaterialBase::RemoveEntityLocationParam(const FName& ParamName)
{
	if (!PPMaterialParams.EntityLocationParams.Contains(ParamName))
	{
		UE_LOG(LogKGPP, Log, TEXT("KGPPMaterialBase::RemoveEntityLocationParam: Param %s not found in ActorLocationParams, %s"), *ParamName.ToString(), *GetDebugInfo());
		return;
	}
	PPMaterialParams.EntityLocationParams.Remove(ParamName);
	
	if (!PPMaterial.IsValid())
	{
		return;
	}
	
	if (!MaterialManager.IsValid())
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialBase::RemoveEntityLocationParam: MaterialManager is null, %s"), *GetDebugInfo());
		return;
	}
	
	if (MaterialParamUpdateTaskIDs.Contains(ParamName))
	{
		MaterialManager->RemoveMaterialParamUpdateTask(MaterialParamUpdateTaskIDs[ParamName]);
		MaterialParamUpdateTaskIDs.Remove(ParamName);
	}
}

void KGPPMaterialBase::UpdateScalarLinearSampleParamTargetValue(const FName& ParamName, float TargetValue, bool bUseNewDuration, float InNewDuration)
{
	auto* LinearSampleParamsPtr = PPMaterialParams.ScalarLinearSampleParams.Find(ParamName);
	if (LinearSampleParamsPtr == nullptr)
	{
		UE_LOG(LogKGPP, Error,
			TEXT("KGPPMaterialBase::UpdateScalarLinearSampleParamTargetValue, invalid linear sample param %s, %s"),
			*ParamName.ToString(), *GetDebugInfo());
		return;
	}

	if (!PPMaterial.IsValid())
	{
		if (FMath::IsNearlyEqual(LinearSampleParamsPtr->StartVal, LinearSampleParamsPtr->EndVal))
		{
			UE_LOG(LogKGPP, Error, 
				TEXT("KGPPMaterialBase::UpdateScalarLinearSampleParamTargetValue, invalid linear sample param with same start and end value %s, %s"),
				*ParamName.ToString(), *GetDebugInfo());
			return;
		}
		LinearSampleParamsPtr->NewDuration = bUseNewDuration ? InNewDuration : (FMath::Abs((
			TargetValue - LinearSampleParamsPtr->StartVal) / (LinearSampleParamsPtr->EndVal - LinearSampleParamsPtr->StartVal)) * LinearSampleParamsPtr->Duration);
		LinearSampleParamsPtr->CurTargetVal = TargetValue;
		return;
	}
	
	// 如果外部调用方式如下
	// 1, 在StartPP之前先设置了线性插值的材质参数更新任务, 材质参数EndVal不为0
	// 2, 在Material加载完成之前, 将材质参数的目标值设置为0
	// 3, 等到ApplyPPMaterialParams时发现, 材质参数的StartVal和EndVal是一样的, 此时就不会添加材质参数更新的Task了, 而是直接作为常量值设置对应的材质参数
	// 4, 后续再调用UpdateScalarLinearSampleParamTargetValue更新目标值时, 发现没有对应的材质参数更新Task了
	// 就目前来看其实这个是合理的case, 因此此时直接认定TaskID为0即可
	uint32 TaskID = 0;
	auto* TaskIDPtr = MaterialParamUpdateTaskIDs.Find(ParamName);
	if (TaskIDPtr != nullptr)
	{
		UE_LOG(LogKGPP, Log, 
			TEXT("KGPPMaterialBase::UpdateScalarLinearSampleParamTargetValue: Found existing TaskID %d for Param %s, TargetValue: %f, bUseNewDuration: %d, NewDuration: %f, %s"),
			*TaskIDPtr, *ParamName.ToString(), TargetValue, bUseNewDuration, InNewDuration, *GetDebugInfo());
		TaskID = *TaskIDPtr;
	}

	if (!MaterialManager.IsValid())
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialBase::UpdateScalarLinearSampleParamTargetValue: MaterialManager is null, %s"), *GetDebugInfo());
		return;
	}
	
	float OriginTargetVal = LinearSampleParamsPtr->CurTargetVal.IsSet() ? LinearSampleParamsPtr->CurTargetVal.GetValue() : LinearSampleParamsPtr->EndVal;
	const auto NewTaskID = MaterialManager->UpdateOrAddLinearSampleParamTargetValue(TaskID, ParamName, PPMaterial.Get(),
		LinearSampleParamsPtr->StartVal, LinearSampleParamsPtr->EndVal, LinearSampleParamsPtr->Duration,
		OriginTargetVal, TargetValue, bUseNewDuration, InNewDuration);
	if (NewTaskID != 0)
	{
		LinearSampleParamsPtr->CurTargetVal = TargetValue;
		MaterialParamUpdateTaskIDs.Add(ParamName, NewTaskID);
	}
}

void KGPPMaterialBase::AddOrUpdateScalarLinearSampleParamTargetValue(
	const FName& ParamName, float StartValue, float TargetValue, bool bUseNewDuration, float NewDuration)
{
	UE_LOG(LogKGPP, Log,
		TEXT("KGPPMaterialBase::AddOrUpdateScalarLinearSampleParamTargetValue: Param %s, StartValue: %f, TargetValue: %f, bUseNewDuration: %d, NewDuration: %f, %s"),
		*ParamName.ToString(), StartValue, TargetValue, bUseNewDuration, NewDuration, *GetDebugInfo());
	
	if (bUseNewDuration && FMath::IsNearlyZero(NewDuration))
	{
		UE_LOG(LogKGPP, Error,
			TEXT("KGPPMaterialBase::AddOrUpdateScalarLinearSampleParamTargetValue: NewDuration is nearly zero for Param %s, %s"),
			*ParamName.ToString(), *GetDebugInfo());
		return;
	}
	
	if (PPMaterialParams.ScalarLinearSampleParams.Contains(ParamName))
	{
		UpdateScalarLinearSampleParamTargetValue(ParamName, TargetValue, bUseNewDuration, NewDuration);
	}
	else
	{
		auto& LinearSampleParams = PPMaterialParams.ScalarLinearSampleParams.Add(ParamName);
		LinearSampleParams.StartVal = StartValue;
		LinearSampleParams.EndVal = FMath::IsNearlyEqual(StartValue, TargetValue) ? TargetValue + 0.001f : TargetValue;
		LinearSampleParams.Duration = NewDuration;

		if (PPMaterial.IsValid() && MaterialManager.IsValid())
		{
			const auto TaskID = MaterialManager->AddScalarLinearSampleParamByDynamicMaterialInstance(
				ParamName, PPMaterial.Get(), LinearSampleParams.StartVal, LinearSampleParams.EndVal, NewDuration, false);
			if (TaskID != 0)
			{
				MaterialParamUpdateTaskIDs.Add(ParamName, TaskID);
			}
		}
	}
}

void KGPPMaterialBase::AddScalarLinearSampleParamTargetValue(const FName& ParamName, float StartValue, float EndVal, float Duration)
{
	if (Duration <= UE_KINDA_SMALL_NUMBER)
	{
		UE_LOG(LogKGPP, Log, 
			TEXT("KGPPMaterialBase::AddScalarLinearSampleParamTargetValue: Duration is nearly zero, directly set param value, Param %s, StartValue: %f, EndVal: %f, %s"),
			*ParamName.ToString(), StartValue, EndVal, *GetDebugInfo());
		UpdateScalarParam(ParamName, EndVal);
	}
	else if (FMath::IsNearlyEqual(StartValue, EndVal))
	{
		UE_LOG(LogKGPP, Log, 
			TEXT("KGPPMaterialBase::AddScalarLinearSampleParamTargetValue: StartValue equals EndVal, directly set param value, Param %s, StartValue: %f, EndVal: %f, %s"),
			*ParamName.ToString(), StartValue, EndVal, *GetDebugInfo());
		UpdateScalarParam(ParamName, EndVal);
	}
	else
	{
		auto& LinearSampleParams = PPMaterialParams.ScalarLinearSampleParams.Add(ParamName);
		LinearSampleParams.StartVal = StartValue;
		LinearSampleParams.EndVal = EndVal;
		LinearSampleParams.Duration = Duration;

		if (PPMaterial.IsValid() && MaterialManager.IsValid())
		{
			uint32* TaskIDPtr = MaterialParamUpdateTaskIDs.Find(ParamName);
			if (TaskIDPtr != nullptr)
			{
				MaterialManager->RemoveMaterialParamUpdateTask(*TaskIDPtr);
			}
			
			const auto TaskID = MaterialManager->AddScalarLinearSampleParamByDynamicMaterialInstance(
				ParamName, PPMaterial.Get(), LinearSampleParams.StartVal, LinearSampleParams.EndVal, Duration, false);
			if (TaskID != 0)
			{
				MaterialParamUpdateTaskIDs.Add(ParamName, TaskID);
			}
		}
	}
}

void KGPPMaterialBase::TryLoadAssets()
{
	UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(PostProcessManager.Get());
	if (!AssetManager)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialBase::TryLoadAssets: AssetManager is null"));
		return;
	}

	const FString& MaterialToUse = GetMaterialPath();
	AssetsToLoad.Add(MaterialToUse);
	for (const auto& Kvp : PPMaterialParams.TextureParams)
	{
		AssetsToLoad.Add(Kvp.Value);
		ParamNamesNeedLoadAssets.Add(Kvp.Key);
	}
	for (const auto& Kvp : PPMaterialParams.CurveParams)
	{
		AssetsToLoad.Add(Kvp.Value.CurvePath);
		ParamNamesNeedLoadAssets.Add(Kvp.Key);
	}

	UE_LOG(LogKGPP, Log, TEXT("KGPPMaterialBase::TryLoadAssets: %s, found total %d assets to load, %s"),
		*GetDebugInfo(), AssetsToLoad.Num(), *MaterialToUse);
	
	AssetLoadID = AssetManager->AsyncLoadAsset(
		AssetsToLoad, FAsyncLoadListCompleteDelegate::CreateRaw(this, &KGPPMaterialBase::OnAssetsLoaded));
}

void KGPPMaterialBase::OnAssetsLoaded(int InLoadID, const TArray<UObject*>& Assets)
{
	UE_LOG(LogKGPP, Log, TEXT("KGPPMaterialBase::OnAssetsLoaded: %s, %d assets loaded"), *GetDebugInfo(), Assets.Num());

	AssetLoadID = 0;
	
	if (Assets.Num() == 0)
	{
		UE_LOG(LogKGPP, Error,
			TEXT("KGPPMaterialBase::OnAssetsLoaded, %s, %d assets loaded, %d assets expected"), *GetDebugInfo(), Assets.Num(), AssetsToLoad.Num());
		return;
	}

	if ((ParamNamesNeedLoadAssets.Num() != Assets.Num() - 1) || (Assets.Num() != AssetsToLoad.Num()))
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialBase::OnAssetsLoaded, assets num not match, %s, %d, %d, %d"),
			*GetDebugInfo(), Assets.Num(), AssetsToLoad.Num(), ParamNamesNeedLoadAssets.Num());
		for (auto* Asset : Assets)
		{
			UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialBase::OnAssetsLoaded, Asset %s"), Asset ? *Asset->GetPathName() : TEXT("invalid"));
		}
		for (const auto& AssetToLoad : AssetsToLoad)
		{
			UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialBase::OnAssetsLoaded, AssetToLoad %s"), *AssetToLoad);
		}
		for (const auto& ParamName : ParamNamesNeedLoadAssets)
		{
			UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialBase::OnAssetsLoaded, ParamName %s"), *ParamName.ToString());
		}
		return;
	}
	
	UMaterialInterface* MaterialInterface = Cast<UMaterialInterface>(Assets[0]);
	if (MaterialInterface == nullptr)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialBase::OnAssetsLoaded: MaterialInterface is null, %s"), *GetDebugInfo());
		return;
	}

	if (!PostProcessManager.IsValid())
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialBase::OnAssetsLoaded: PostProcessManager is null, %s"), *GetDebugInfo());
		return;
	}
	
	UMaterialInstanceDynamic* MaterialInstanceDynamic = KGMaterialUtils::CreateDynamicMaterialInstance(MaterialInterface);
	if (!MaterialInstanceDynamic)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialBase::OnAssetsLoaded, failed to create dynamic material instance, %s"), *GetDebugInfo());
		return;
	}
	
	PPMaterial = TStrongObjectPtr(MaterialInstanceDynamic);
	for (int32 i = 1; i < Assets.Num(); ++i)
	{
		UObject* Asset = Assets[i];
		if (Asset == nullptr)
		{
			UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialBase::OnAssetsLoaded: Asset is null, %s, %s"), *GetDebugInfo(), *AssetsToLoad[i]);
			continue;
		}

		ParamNameToAssets.Add(ParamNamesNeedLoadAssets[i - 1], TStrongObjectPtr(Asset));
	}

	ApplyPPMaterialParams();

	if (PlaneMeshHandler.IsValid())
	{
		const bool bResult = PlaneMeshHandler->InitPlaneMeshHandler(PostProcessManager, PPMaterial.Get(), PlaneMeshDistance);
		UE_CLOG(!bResult, LogKGPP, Error,
			TEXT("KGPPMaterialBase::OnAssetsLoaded: Failed to init plane mesh handler, %s"), *GetDebugInfo());

		if (!IsActivated())
		{
			if (auto* PlaneMeshComponent = PlaneMeshHandler->GetPlaneMeshComponent())
			{
				PlaneMeshComponent->SetVisibility(false);
			}	
		}
	}
}

void KGPPMaterialBase::ApplyPPMaterialParams()
{
	if (!PPMaterial.IsValid())
	{
		return;
	}

	UE_LOG(LogKGPP, Log, TEXT("KGPPMaterialBase::ApplyPPMaterialParams: %s"), *GetDebugInfo());
	
	InitConstMaterialParams();

	if (MaterialManager.IsValid())
	{
		for (const auto& Kvp : PPMaterialParams.ScalarLinearSampleParams)
		{
			uint32 TaskID = 0;
			if (Kvp.Value.CurTargetVal.IsSet() && Kvp.Value.NewDuration.IsSet())
			{
				if (FMath::IsNearlyEqual(Kvp.Value.StartVal, Kvp.Value.CurTargetVal.GetValue()) || FMath::IsNearlyZero(Kvp.Value.NewDuration.GetValue()))
				{
					PPMaterial->SetScalarParameterValue(Kvp.Key, Kvp.Value.StartVal);
				}
				else
				{
					TaskID = MaterialManager->AddScalarLinearSampleParamByDynamicMaterialInstance(Kvp.Key, PPMaterial.Get(),
						Kvp.Value.StartVal, Kvp.Value.CurTargetVal.GetValue(), Kvp.Value.NewDuration.GetValue(), false);
				}
			}
			else
			{
				TaskID = MaterialManager->AddScalarLinearSampleParamByDynamicMaterialInstance(
					Kvp.Key, PPMaterial.Get(), Kvp.Value.StartVal, Kvp.Value.EndVal, Kvp.Value.Duration, false);
			}
			
			if (TaskID != 0)
			{
				MaterialParamUpdateTaskIDs.Add(Kvp.Key, TaskID);
			}
		}

		for (const auto& Kvp : PPMaterialParams.ScalarLinearBlendParams)
		{
			const auto TaskID = MaterialManager->AddLinearBlendParamByDynamicMaterialInstance(
				Kvp.Key, PPMaterial.Get(), Kvp.Value.StartVal, Kvp.Value.EndVal,
				Kvp.Value.BlendInTime, Kvp.Value.BlendOutTime, Kvp.Value.Duration, false);
			if (TaskID != 0)
			{
				MaterialParamUpdateTaskIDs.Add(Kvp.Key, TaskID);
			}
		}

		for (const auto& Kvp : PPMaterialParams.VectorLinearSampleParams)
		{
			const auto TaskID = MaterialManager->AddVectorLinearSampleParamByDynamicMaterialInstance(
				Kvp.Key, PPMaterial.Get(), Kvp.Value.StartVal, Kvp.Value.EndVal, Kvp.Value.Duration, false);
			if (TaskID != 0)
			{
				MaterialParamUpdateTaskIDs.Add(Kvp.Key, TaskID);
			}
		}

		for (const auto& Kvp : PPMaterialParams.CurveParams)
		{
			// 资源加载失败是这里没有数据
			if (ParamNameToAssets.Contains(Kvp.Key))
			{
				if (UCurveBase* Curve = Cast<UCurveBase>(ParamNameToAssets[Kvp.Key].Get()))
				{
					const auto TaskID = MaterialManager->AddCurveParamByDynamicMaterialInstance(
						Kvp.Key, PPMaterial.Get(), Curve, Kvp.Value.bNeedRemap, Kvp.Value.RemapTime, Kvp.Value.bLoop, false);
					if (TaskID != 0)
					{
						MaterialParamUpdateTaskIDs.Add(Kvp.Key, TaskID);
					}
				}
				else
				{
					UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialBase::ApplyPPMaterialParams: Curve is null, %s, %s"), *GetDebugInfo(), *Kvp.Key.ToString());	
				}	
			}
		}

		for (const auto& Kvp : PPMaterialParams.ActorLocationParams)
		{
			const auto TaskID = MaterialManager->AddActorLocationParamByDynamicMaterialInstance(
				Kvp.Key, PPMaterial.Get(), Kvp.Value.Get(), false);
			if (TaskID != 0)
			{
				MaterialParamUpdateTaskIDs.Add(Kvp.Key, TaskID);
			}
		}

		if (PPMaterialParams.EntityLocationParams.Num() > 0)
		{
			if (UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(PostProcessManager.Get()))
			{
				for (const auto& Kvp : PPMaterialParams.EntityLocationParams)
				{
					DoAddEntityLocationUpdateTask(Kvp.Key, Kvp.Value, ActorManager);
				}
			}
		}
		
		if (AccumulateLifeTimeSeconds > UE_KINDA_SMALL_NUMBER)
		{
			for (const auto& Kvp : MaterialParamUpdateTaskIDs)
        	{
        		MaterialManager->AdvanceUpdateTask(Kvp.Value, AccumulateLifeTimeSeconds);
        	}	
		}
	}
	else
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialBase::ApplyPPMaterialParams: MaterialManager is invalid, %s"), *GetDebugInfo());
	}
}

void KGPPMaterialBase::InitConstMaterialParams()
{
	if (!PPMaterial.IsValid())
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialBase::InitConstMaterialParams: PPMaterial is null, %s"), *GetDebugInfo());
		return;
	}

	UMaterialInstanceDynamic* MaterialInstanceDynamic = PPMaterial.Get();
	BATCH_DMIPARAM_SCOPE(MaterialInstanceDynamic);
	
	for (const auto& Kvp : PPMaterialParams.ScalarParams)
	{
		PPMaterial->SetGameScalarParameterValue(Kvp.Key, Kvp.Value);
	}

	for (const auto& Kvp : PPMaterialParams.VectorParams)
	{
		PPMaterial->SetGameVectorParameterValue(Kvp.Key, Kvp.Value);
	}

	for (const auto& Kvp : PPMaterialParams.TextureParams)
	{
		if (ParamNameToAssets.Contains(Kvp.Key))
		{
			if (UTexture* Texture = Cast<UTexture>(ParamNameToAssets[Kvp.Key].Get()))
			{
				PPMaterial->SetGameTextureParameterValue(Kvp.Key, Texture);
			}
			else
			{
				UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialBase::ApplyPPMaterialParams: Texture is null, %s, %s"), *GetDebugInfo(), *Kvp.Key.ToString());
			}
		}
		else
		{
			UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialBase::ApplyPPMaterialParams: asset missing, %s, %s"), *GetDebugInfo(), *Kvp.Key.ToString());
		}
	}
}

uint32 KGPPMaterialBase::DoAddEntityLocationUpdateTask(const FName& ParamName, KGEntityID EntityID, UKGUEActorManager* ActorManager)
{
	const auto EntityPtr = ActorManager->GetLuaEntity(EntityID);
	if (!EntityPtr)
	{
		UE_LOG(LogKGPP, Log, TEXT("KGPPMaterialBase::DoAddEntityLocationUpdateTask: Entity is null, %s, %lld"), *GetDebugInfo(), EntityID);
		return 0;
	}

	auto& TaskIDs = EntityIDToParamNames.FindOrAdd(EntityID);
	TaskIDs.Add(ParamName);
		
	const auto TaskID = MaterialManager->AddEntityLocationParamByDynamicMaterialInstance(
		ParamName, PPMaterial.Get(), EntityID, false);
	if (TaskID != 0)
	{
		MaterialParamUpdateTaskIDs.Add(ParamName, TaskID);
	}

	return TaskID;
}
