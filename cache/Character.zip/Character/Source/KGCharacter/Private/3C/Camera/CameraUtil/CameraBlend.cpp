// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Camera/CameraUtil/CameraBlend.h"

#include "3C/Camera/CameraAction/CameraViewOffsetEffect.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/PlayerController.h"


void FCameraBlend::SetViewBlendType(ECameraViewBlendFunction::Type NewBlendType)
{
	BlendType = NewBlendType;
}

void FCameraBlend::CustomBlendPOV(FCameraSnapShot& OutSnapShot, const FCameraSnapShot& Source, const FCameraSnapShot& Target, float BlendPct, bool bHasRotationInput, bool bHasModifyRotation, bool& bDoDotBlendRot, ACameraManager* CameraManager)
{
	switch(BlendType) {
	case ECameraViewBlendFunction::Liner:
		BlendPOV_Liner(OutSnapShot, Source, Target, BlendPct);
		break;
	case ECameraViewBlendFunction::Polar:
		BlendPOV_RotateWithTarget(OutSnapShot, Source, Target, BlendPct, false, bHasRotationInput, bHasModifyRotation, bDoDotBlendRot, CameraManager);
		break;
	case ECameraViewBlendFunction::PolarWithPivotLerp:
		BlendPOV_RotateWithTarget(OutSnapShot, Source, Target, BlendPct, true, bHasRotationInput, bHasModifyRotation, bDoDotBlendRot, CameraManager);
		break;
	}
}

void FCameraBlend::BlendPOV_Liner(FCameraSnapShot& OutSnapShot, const FCameraSnapShot& Source, const FCameraSnapShot& Target, float BlendPct)
{
	auto& OutPOV = OutSnapShot.POV;
	const auto& SourcePOV = Source.POV;
	const auto& TargetPOV = Target.POV;
	OutPOV.Location = FMath::Lerp(SourcePOV.Location, TargetPOV.Location, BlendPct);

	const FRotator DeltaAng = (TargetPOV.Rotation - SourcePOV.Rotation).GetNormalized();
	OutPOV.Rotation = SourcePOV.Rotation + BlendPct * DeltaAng;

	BlendNormalParams(OutSnapShot, Source, Target, BlendPct);
}

void FCameraBlend::BlendPOV_RotateWithTarget(FCameraSnapShot& OutSnapShot, const FCameraSnapShot& Source, const FCameraSnapShot& Target, float BlendPct, bool bForcePivotLerp, bool bHasRotationInput, bool bHasModifyRotation, bool& bDoDotBlendRot, ACameraManager* CameraManager)
{
	BlendNormalParams(OutSnapShot, Source, Target, BlendPct);
	OutSnapShot.CameraTarget = Target.CameraTarget;

	auto& OutPOV = OutSnapShot.POV;

	if(ABaseCamera* CameraA = Cast<ABaseCamera>(Source.CameraTarget))
	{
		if(ABaseCamera* CameraB = Cast<ABaseCamera>(Target.CameraTarget))
		{
			FVector PivotLocation = FVector::ZeroVector;
			if(bForcePivotLerp || (!Source.LookAtActor.IsValid() || !Target.LookAtActor.IsValid() || Source.LookAtActor != Target.LookAtActor))
			{
				PivotLocation = FMath::Lerp(Source.PivotLocation, Target.PivotLocation, BlendPct);
				OutSnapShot.LookAtActorLocation = FMath::Lerp(Source.LookAtActorLocation, Target.LookAtActorLocation, BlendPct);
			}
			else
			{
				OutSnapShot.LookAtActorLocation = Target.LookAtActorLocation;
				PivotLocation = Target.LookAtActorLocation + FMath::Lerp(Source.PivotLocation - Source.LookAtActorLocation, Target.PivotLocation - Target.LookAtActorLocation, BlendPct);
			}
			OutSnapShot.LookAtActor = Target.LookAtActor;
			OutSnapShot.PivotLocation = PivotLocation;

			FRotator PivotRotation = Target.PivotRotation;
			if (!bDoDotBlendRot)
			{
				FRotator DeltaAng = (Target.PivotRotation - Source.PivotRotation).GetNormalized();
				PivotRotation = Source.PivotRotation + BlendPct * DeltaAng;
				if (bHasModifyRotation)
				{ 
					if (CameraManager && CameraManager->PCOwner)
					{
						CameraManager->PCOwner->SetControlRotation(PivotRotation);
						UE_LOG(LogTemp, Log, TEXT("[ACameraManager]Camera Modify Rotation While Blend Set Rot To:%s"), *PivotRotation.ToString());
					}
					bDoDotBlendRot = true;
				}
			}
			OutSnapShot.PivotRotation = PivotRotation;

			float RealArmLen = FMath::Lerp(Source.RealArmLen, Target.RealArmLen, BlendPct);
			OutSnapShot.RealArmLen = RealArmLen;

			FVector2D ScreenCoDecayOffset = FMath::Lerp(Source.ScreenOffset, Target.ScreenOffset, BlendPct);
			// UE_LOG(LogTemp, Log, TEXT("Camera Blend ScreenOffset Source:%s, Target:%s"), *Source.ScreenOffset.ToString(), *Target.ScreenOffset.ToString())
			OutSnapShot.ScreenOffset = ScreenCoDecayOffset;

			const float HalfHorizontalFOV = OutSnapShot.POV.DesiredFOV / 2.0f;
			static FVector PivotOffsetForScreenCoOff = FVector::ZeroVector;
			int ScreenX = 1;
			int ScreenY = 1;
			if(OutSnapShot.PlayerController.IsValid())
			{
				OutSnapShot.PlayerController->GetViewportSize(ScreenX, ScreenY);
			}
			PivotOffsetForScreenCoOff.X = 0;
			float Ratio = FMath::Tan(HalfHorizontalFOV * PI / 180.f) * RealArmLen * 9.f / 16.f;
			PivotOffsetForScreenCoOff.Y = -(ScreenCoDecayOffset.X * ScreenY) * 2 * Ratio / static_cast<float>(ScreenY) /* / static_cast<float>(ScreenX) * static_cast<float>(ScreenX) */;
			PivotOffsetForScreenCoOff.Z = ScreenCoDecayOffset.Y * 2 * Ratio;

			PivotLocation += FRotationMatrix(PivotRotation).TransformVector(PivotOffsetForScreenCoOff);

			PivotLocation -= PivotRotation.Vector() * RealArmLen;

			OutSnapShot.SocketOffset = FMath::Lerp(Source.SocketOffset, Target.SocketOffset, BlendPct);
			PivotLocation += FRotationMatrix(PivotRotation).TransformVector(OutSnapShot.SocketOffset);

			// TODO 碰撞
			FRotator DeltaAng = (Target.SocketRotOffset - Source.SocketRotOffset).GetNormalized();
			OutSnapShot.SocketRotOffset = Source.SocketRotOffset + BlendPct * DeltaAng;
			PivotRotation = (PivotRotation.Quaternion() * (OutSnapShot.SocketRotOffset).Quaternion()).Rotator();

			OutPOV.Location = PivotLocation;
			OutPOV.Rotation = PivotRotation;
			return;
		}
	}

	const auto& SourcePOV = Source.POV;
	const auto& TargetPOV = Target.POV;
	float SourceRadiusLength = 0.f;
	FVector SourceCameraPivotLocation = SourcePOV.Location;
	float TargetRadiusLength = 0.f;
	FVector TargetCameraPivotLocation = TargetPOV.Location;
	if(ABaseCamera* Camera = Cast<ABaseCamera>(Source.CameraTarget))
	{
		SourceRadiusLength = Source.RealArmLen;
		SourceCameraPivotLocation = SourcePOV.Location + SourceRadiusLength * SourcePOV.Rotation.Vector();
	}
	if(ABaseCamera* Camera = Cast<ABaseCamera>(Target.CameraTarget))
	{
		TargetRadiusLength = Camera->GetCameraArmComponent()->GetRealCameraArmLen();
		TargetCameraPivotLocation = TargetPOV.Location + TargetRadiusLength * TargetPOV.Rotation.Vector();
	} 
	
	const float Radius = FMath::Lerp(SourceRadiusLength, TargetRadiusLength, BlendPct);
	OutSnapShot.RealArmLen = Radius;
	FRotator RotationLerp = FCameraEaseCalculate::LerpRotationWithShortestPath(SourcePOV.Rotation, TargetPOV.Rotation, BlendPct);
	OutSnapShot.PivotRotation = RotationLerp;
	const FVector PivotLocation = FMath::Lerp(SourceCameraPivotLocation, TargetCameraPivotLocation, BlendPct);
	OutSnapShot.PivotLocation = PivotLocation;
	OutPOV.Location = PivotLocation - Radius * RotationLerp.Vector();
	
	RotationLerp.Roll = FMath::Lerp(SourcePOV.Rotation.Roll, TargetPOV.Rotation.Roll, BlendPct);
	OutPOV.Rotation = RotationLerp;
	
	OutSnapShot.ScreenOffset = FVector2D::ZeroVector;
	OutSnapShot.SocketRotOffset = FRotator::ZeroRotator;
	OutSnapShot.SocketOffset = FVector::ZeroVector;
}

void FCameraBlend::BlendNormalParams(FCameraSnapShot& OutSnapShot, const FCameraSnapShot& Source,
                                     const FCameraSnapShot& Target, float BlendPct)
{
	auto& OutPOV = OutSnapShot.POV;
	const auto& SourcePOV = Source.POV;
	const auto& TargetPOV = Target.POV;

	OutPOV.FOV = FMath::Lerp(SourcePOV.FOV, TargetPOV.FOV, BlendPct);
	OutPOV.DesiredFOV = FMath::Lerp(SourcePOV.DesiredFOV, TargetPOV.DesiredFOV, BlendPct);
	OutPOV.OrthoWidth = FMath::Lerp(SourcePOV.OrthoWidth, TargetPOV.OrthoWidth, BlendPct);
	OutPOV.OrthoNearClipPlane = FMath::Lerp(SourcePOV.OrthoNearClipPlane, TargetPOV.OrthoNearClipPlane, BlendPct);
	OutPOV.OrthoFarClipPlane = FMath::Lerp(SourcePOV.OrthoFarClipPlane, TargetPOV.OrthoFarClipPlane, BlendPct);
	OutPOV.PerspectiveNearClipPlane = FMath::Lerp(SourcePOV.PerspectiveNearClipPlane, TargetPOV.PerspectiveNearClipPlane, BlendPct);
	OutPOV.OffCenterProjectionOffset = FMath::Lerp(SourcePOV.OffCenterProjectionOffset, TargetPOV.OffCenterProjectionOffset, BlendPct);

	OutPOV.AspectRatio = FMath::Lerp(SourcePOV.AspectRatio, TargetPOV.AspectRatio, BlendPct);
	OutPOV.bConstrainAspectRatio |= TargetPOV.bConstrainAspectRatio;
	OutPOV.bUseFieldOfViewForLOD |= TargetPOV.bUseFieldOfViewForLOD;
}
