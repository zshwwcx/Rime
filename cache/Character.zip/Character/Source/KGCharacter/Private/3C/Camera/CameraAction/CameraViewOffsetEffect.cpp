#include "3C/Camera/CameraAction/CameraViewOffsetEffect.h"
#include "GameFramework/PlayerController.h"


void UCameraViewOffsetEffect::ModifyParams(float CoordX, float CoordY, float InBlendInTime)
{
	RotationBase = LastRotationDelta;
	FocusScreenCoord.X = CoordX;
	FocusScreenCoord.Y = CoordY;
	RunningTime = 0.f;
	BlendInTime = InBlendInTime;
}

void UCameraViewOffsetEffect::Init(float CoordX, float CoordY, float InBlendInTime, float InBlendOutTime,
                                   ECameraEaseFunction::Type InBlendInType, ECameraEaseFunction::Type InBlendOutType,
                                   int64 InBlendInCurve, int64 InBlendOutCurve)
{
	RotationBase = FRotator::ZeroRotator;
	Duration = -1.f;
	SetEaseInType(InBlendInType, InBlendInTime, InBlendInCurve);
	SetEaseOutType(InBlendOutType, InBlendOutTime, InBlendOutCurve);
	FocusScreenCoord.X = CoordX;
	FocusScreenCoord.Y = CoordY;
}

void UCameraViewOffsetEffect::ModifyViewPOV(float DeltaTime, FMinimalViewInfo& InOutPOV)
{
	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return;
	}

	int SizeX, SizeY;
	PlayerController->GetViewportSize(SizeX, SizeY);

	float Ratio = static_cast<float>(SizeY) / static_cast<float>(SizeX);

	float VertAngle = FMath::DegreesToRadians(InOutPOV.FOV * Ratio / 2.f);

	float HorRatio = FMath::Clamp((FocusScreenCoord.X - 0.5) / 0.5,-1,1);
	float VertRatio = FMath::Clamp((FocusScreenCoord.Y - 0.5) / 0.5,-1,1);
	float YawDelta = FMath::RadiansToDegrees(FMath::Atan( FMath::Tan(VertAngle) * HorRatio));
	float PitchDelta = FMath::RadiansToDegrees(FMath::Atan( FMath::Tan(VertAngle) * VertRatio));

	const FRotator AngDelta = (FRotator(-PitchDelta, -YawDelta, 0) - RotationBase).GetNormalized();
	LastRotationDelta = RotationBase + FMath::Clamp(Alpha, 0.f, 1.f) * AngDelta;
	InOutPOV.Rotation = (InOutPOV.Rotation.Quaternion() * LastRotationDelta.Quaternion()).Rotator();
}

void UCameraViewOffsetEffect::Play()
{
	Super::Play();
	PlayerController = CameraManager->GetOwningPlayerController();
}

void UCameraViewOffsetEffect::Abort()
{
	Super::Abort();
	FocusScreenCoord = FVector2D::ZeroVector;
}

void UCameraViewOffsetEffect::DisableAction(bool bImmediate)
{
	Super::DisableAction(bImmediate);
	RotationBase = FRotator::ZeroRotator;
}
