#include "3C/Camera/CameraAction/CameraActionBase.h"
#include "3C/Camera/CameraAction/CameraActionHandler.h"
#include "3C/Util/KGUtils.h"
#include "Engine/Engine.h"



UCameraActionBase::UCameraActionBase(const FObjectInitializer& ObjectInitializer): Super(ObjectInitializer)
{
	if (UCameraActionHandler* Outer = Cast<UCameraActionHandler>(GetOuter()))
	{
		ActionHandlerOwner = Outer;
		CameraManager = Outer->CameraManagerOwner;
	}
}

void UCameraActionBase::SetEaseInType(ECameraEaseFunction::Type NewEaseInType, float NewBlendInTime, KGActorID CurveID)
{
	if(NewEaseInType == ECameraEaseFunction::Decay || NewEaseInType == ECameraEaseFunction::Spring)
	{
		UE_LOG(LogTemp, Error, TEXT("[UCameraActionBase]Action:%s Ease Type Do Not Support Decay And Spring"), *this->GetName());
		NewEaseInType = ECameraEaseFunction::Linear;
	}
	BlendInType = NewEaseInType;
	BlendInTime = FMath::Max(NewBlendInTime, 0.f);
	BlendInCurve = Cast<UCurveFloat>(KGUtils::GetObjectByID(CurveID));
}

void UCameraActionBase::SetEaseOutType(ECameraEaseFunction::Type NewEaseOutType, float NewBlendOutTime, KGActorID CurveID)
{
	if(NewEaseOutType == ECameraEaseFunction::Decay || NewEaseOutType == ECameraEaseFunction::Spring)
	{
		UE_LOG(LogTemp, Error, TEXT("[UCameraActionBase]Action:%s Ease Type Do Not Support Decay And Spring"), *this->GetName());
		NewEaseOutType = ECameraEaseFunction::Linear;
	}
	BlendOutType = NewEaseOutType;
	BlendOutTime = FMath::Max(NewBlendOutTime, 0.f);
	BlendOutCurve = Cast<UCurveFloat>(KGUtils::GetObjectByID(CurveID));
}

void UCameraActionBase::DisableAction(bool bImmediate)
{
	if(bFinished)
	{
		return;
	}

	UE_LOG(LogTemp, Log, TEXT("CameraManger:DisableCameraAction Action:%s Immediate:%d ActionID:%lld"), *this->GetName(), bImmediate, ActionID);
	if(bImmediate)
	{
		Duration = RunningTime;
		bFinished = true;
		InnerUpdateAlpha(0.f);
	}
	else if(!bFinished)
	{
		if(!bStartBlendOut)
		{
			if(!bRecover)
			{
				Duration = RunningTime;
				bFinished = true;
				InnerUpdateAlpha(0.f);
			}
			else
			{
				Duration = RunningTime + BlendOutTime;
			}
		}
	}
}

void UCameraActionBase::Play()
{
	bFinished = false;
	RunningTime = 0;
	Alpha = 0.f;
	bStartBlendOut = false;
	bStartBlendIn = false;
}

void UCameraActionBase::UpdateAlpha(float DeltaTime)
{
	if(bTickCurrentFrame)
	{
		return;
	}
	bTickCurrentFrame = true;

	if(bPause)
	{
		return;
	}
	RunningTime += DeltaTime * PlayRate;
	InnerUpdateAlpha(DeltaTime);
}

void UCameraActionBase::UpdateAfterFrame()
{
	bTickCurrentFrame = false;
	if(RunningTime > Duration && Duration >= 0.f)
	{
		DisableAction(true);
	}
	else if(bAutoExitWhileModeDeActive && !CameraMode.IsValid())
	{
		DisableAction(true);
	}
}

void UCameraActionBase::ModifyCamera(float DeltaTime)
{
}

void UCameraActionBase::ModifyViewPOV(float DeltaTime, FMinimalViewInfo& InOutPOV)
{
}

bool UCameraActionBase::ProcessViewRotation(AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch,
                                            double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot)
{
	return false;
}

void UCameraActionBase::Abort()
{
	Duration = 0.f;
	BlendInTime = 0.f;
	BlendOutTime = 0.f;
	BlendInCurve = nullptr;
	BlendOutCurve = nullptr;

	if(ActionHandlerOwner.IsValid())
	{
		ActionHandlerOwner->OnActionAbort(ActionID);
	}
}

void UCameraActionBase::DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode)
{
	CameraMode = ActivateCameraMode;
}

void UCameraActionBase::InnerUpdateAlpha(float DeltaTime)
{
	if (BlendInTime > 0 && RunningTime < BlendInTime)
	{
		bStartBlendIn = true;
		if (BlendInType == ECameraEaseFunction::Curve)
		{
			Alpha = FCameraEaseCalculate::GetCurveNormalPct(BlendInCurve, RunningTime / BlendInTime);
		}
		else
		{
			Alpha = FCameraEaseCalculate::Evaluate(BlendInType, 0.f, 1.f, RunningTime / BlendInTime);
		}
	}
	else
	{
		bStartBlendIn = false;
		Alpha = 1.f;
	}

	if (bRecover && Duration >= 0.f && RunningTime >= (Duration - BlendOutTime))
	{
		bStartBlendOut = true;
		float TimeAfterBlendOut = RunningTime - (Duration - BlendOutTime);
		if (BlendOutType == ECameraEaseFunction::Curve)
		{
			Alpha *= FCameraEaseCalculate::GetCurveNormalPct(BlendOutCurve, 1.f - TimeAfterBlendOut / BlendOutTime);
		}
		else
		{
			Alpha *= FCameraEaseCalculate::Evaluate(BlendInType, 1.f, 0.f, TimeAfterBlendOut / BlendOutTime);
		}

		if(RunningTime >= Duration)
		{
			Alpha = 0.f;
		}
	}


	Alpha = FMath::Clamp(Alpha, 0.f, 1.f);
}
