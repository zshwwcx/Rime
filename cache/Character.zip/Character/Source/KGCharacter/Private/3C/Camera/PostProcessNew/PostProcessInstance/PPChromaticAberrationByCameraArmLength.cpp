﻿#include "3C/Camera/PostProcessNew/PostProcessInstance/PPChromaticAberrationByCameraArmLength.h"

#include "3C/Camera/KgCameraMode.h"
#include "Kismet/GameplayStatics.h"
#include "3C/Camera/PostProcessNew/PostProcessManager.h"
#include "3C/Camera/CameraManager.h"

void KGPPChromaticAberrationByCameraArmLength::InitParams(
	const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType, 
	float InMinCameraArmLength, float InMaxCameraArmLength, float InMinChromaticAberrationIntensity, float InMaxChromaticAberrationIntensity)
{
	KGPPNonMaterialBase::InitParams(CommonParams, InPPManager, InPPType);
	
	MinCameraArmLength = InMinCameraArmLength;
	MaxCameraArmLength = InMaxCameraArmLength;
	MinChromaticAberrationIntensity = InMinChromaticAberrationIntensity;
	MaxChromaticAberrationIntensity = InMaxChromaticAberrationIntensity;
}

bool KGPPChromaticAberrationByCameraArmLength::OnTaskStart()
{
	CameraManager = Cast<ACameraManager>(UGameplayStatics::GetPlayerCameraManager(PostProcessManager.Get(), 0));
	if (!CameraManager.IsValid())
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPChromaticAberrationByCameraArmLength::OnTaskStart, invalid camera manager"));
		return false;
	}
	
	if (MinCameraArmLength > MaxCameraArmLength || FMath::IsNearlyEqual(MinCameraArmLength, MaxCameraArmLength))
	{
		UE_LOG(LogKGPP, Warning, TEXT("KGPPChromaticAberrationByCameraArmLength::OnTaskStart, invalid camera arm length %f, %f, %s"),
			MinCameraArmLength, MaxCameraArmLength, *GetDebugInfo());
		return false;
	}
	
	return KGPPNonMaterialBase::OnTaskStart();
}

void KGPPChromaticAberrationByCameraArmLength::OnTaskTick(float DeltaTime)
{
	KGPPNonMaterialBase::OnTaskTick(DeltaTime);
	
	PostProcessSettings.bOverride_SceneFringeIntensity = false;
	
	if (!CameraManager.IsValid())
	{
		return;
	}
	
	auto* CameraMode = CameraManager->GetCurCameraMode();
	if (!CameraMode)
	{
		return;
	}
	
	auto* CameraArmComp = CameraMode->GetCameraArmComponent();
	if (!CameraArmComp)
	{
		return;
	}
	
	if (FMath::IsNearlyEqual(MinCameraArmLength, MaxCameraArmLength))
	{
		UE_LOG(LogKGPP, Warning, TEXT("KGPPChromaticAberrationByCameraArmLength::OnTaskTick, invalid camera arm length %f, %f, %s"),
			MinCameraArmLength, MaxCameraArmLength, *GetDebugInfo());
		return;
	}
	
	const float CurArmLen = CameraArmComp->GetRealCameraArmLen();
	const float ArmLenClamped = FMath::Clamp(CurArmLen, MinCameraArmLength, MaxCameraArmLength);
	const float Alpha = FMath::Clamp((ArmLenClamped - MinCameraArmLength) / (MaxCameraArmLength - MinCameraArmLength), 0.0f, 1.0f);
	PostProcessSettings.bOverride_SceneFringeIntensity = true;
	PostProcessSettings.SceneFringeIntensity = MinChromaticAberrationIntensity + (MaxChromaticAberrationIntensity - MinChromaticAberrationIntensity) * Alpha;
}

FString KGPPChromaticAberrationByCameraArmLength::GetDebugInfo() const
{
	return FString::Printf(TEXT("%s, Intensity: %f"), *KGPPNonMaterialBase::GetDebugInfo(), PostProcessSettings.SceneFringeIntensity);
}
