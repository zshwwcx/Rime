// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Camera/CameraAction/CameraZoomAction.h"

void UCameraZoomAction::Init(float Zoom, float ZoomOffset, bool bInRecover, bool bInCanInterrupt, float InBlendInTime,
	float InBlendOutTime, float InDuration, ECameraEaseFunction::Type InBlendInType,
	ECameraEaseFunction::Type InBlendOutType, int64 InBlendInCurve, int64 InBlendOutCurve)
{
	TargetZoom = Zoom;
	TargetZoomOffset = ZoomOffset;

	bRecover = bInRecover;
	bCanInterrupt = bInCanInterrupt;

	SetEaseInType(InBlendInType, InBlendInTime, InBlendInCurve);
	SetEaseOutType(InBlendOutType, InBlendOutTime, InBlendOutCurve);
	Duration = InDuration;
}

void UCameraZoomAction::Play()
{
	Super::Play();
	InitParams();
}

void UCameraZoomAction::ModifyCamera(float DeltaTime)
{
	Super::ModifyCamera(DeltaTime);

	if(CameraMode.IsValid())
	{
		if(TargetZoom >= 0.f)
		{
			CameraMode->SetOverrideZoomSetting(FMath::Lerp(bStartBlendOut ? CameraMode->GetOverrideZoomBelowPriority(Priority, ZoomBase) : ZoomBase, TargetZoom, Alpha), Priority);
		}

		if(TargetZoomOffset != 0.f)
		{
			CameraMode->AddZoomDelta(FMath::Lerp(ZoomOffsetBase, TargetZoomOffset, FMath::Clamp(Alpha, 0.f, 1.f)));
		}
	}
}

void UCameraZoomAction::Abort()
{
	Super::Abort();

	if(CameraMode.IsValid())
	{
		if(TargetZoom >= 0.f)
		{
			CameraMode->RemoveOverrideZoomSetting(Priority);
		}

		if(TargetZoomOffset != 0.f)
		{
			CameraMode->AddZoomDelta(FMath::Lerp(ZoomOffsetBase, TargetZoomOffset, FMath::Clamp(Alpha, 0.f, 1.f)));
		}
	}
}

void UCameraZoomAction::DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode)
{
	Super::DoWhenEffectModeActivate(ActivateCameraMode);
	InitParams();
}

bool UCameraZoomAction::IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType)
{
	if(ControlType == ECameraManualControlType::ManualZoom)
	{
		return bCanInterrupt;
	}

	return false;
}

void UCameraZoomAction::InitParams()
{
	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return;
	}

	if(UCameraArmComponent* Arm = CameraMode->GetCameraArmComponent())
	{
		ZoomBase = Arm->GetTargetCameraZoomLen();
	}
}
