#include "3C/Camera/CameraMode/ThirdCameraMode.h"


UThirdCameraModeBase::UThirdCameraModeBase(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bEnableTick = true;
}
