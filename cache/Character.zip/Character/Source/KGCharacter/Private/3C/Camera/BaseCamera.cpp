#include "3C/Camera/BaseCamera.h"

#include "3C/Core/C7ActorInterface.h"
#include "3C/Core/KGUEActorManager.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "3C/Camera/KgCameraMode.h"
#include "3C/Util/KGUtils.h"
#include "TimerManager.h"
#include "Camera/CameraComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/Character.h"

ABaseCamera::ABaseCamera(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = false;
	// PrimaryActorTick.TickGroup = TG_PostPhysics;
	// PrimaryActorTick.bHighPriority = true;

	UCameraComponent* CameraCom = GetCameraComponent();

	if (RootComponent && CameraCom)
	{
		CameraArmComponent = CreateDefaultSubobject<UCameraArmComponent>(TEXT("CameraArmComponent"));
		CameraArmComponent->SetupAttachment(RootComponent);

		CameraCom->SetupAttachment(CameraArmComponent, UCameraArmComponent::SocketName);
	}
}

void ABaseCamera::Tick(float DeltaSeconds)
{
	TickCamera(DeltaSeconds);
	if(UCameraArmComponent* Arm = GetCameraArmComponent())
	{
		Arm->UpdateArms(DeltaSeconds);
	}
}

void ABaseCamera::TickCamera(float DeltaSeconds)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("Camera Update Camera");

	bHasRotationInput = false;
	
	if (!RotationInput.IsNearlyZero())
	{
		FRotator ActorRot = this->GetActorRotation();
		ActorRot += RotationInput;
		if (bLimitedPitchRot)
		{
			ActorRot.Pitch = FMath::ClampAngle(ActorRot.Pitch, PitchMin, PitchMax);
			ActorRot.Pitch = FRotator::ClampAxis(ActorRot.Pitch);
		}
		if (bLimitedYawRot)
		{
			ActorRot.Yaw = FMath::ClampAngle(ActorRot.Yaw, YawMin, YawMax);
			ActorRot.Yaw = FRotator::ClampAxis(ActorRot.Yaw);
		}
		SetActorRotation(ActorRot);
		bHasRotationInput = true;
		RotationInput = FRotator::ZeroRotator;
	}
	
	if(bManualControl)
	{
		FVector CameraActorLoc = this->GetActorLocation();
		if(!CameraActorLoc.Equals(TargetLoc))
		{
			this->SetActorLocation(CameraActorLoc);
		}
	}
	else
	{
		if(LookAtTarget.IsValid())
		{
			if(!LookAtBoneName.IsNone())
			{
				if(IC7ActorInterface* C7Actor = Cast<IC7ActorInterface>(LookAtTarget))
				{
					if(USkeletalMeshComponent* SKMesh = C7Actor->GetMainMesh())
					{
						FVector ResultLocation = FVector::ZeroVector;
						if(SKMesh->DoesSocketExist(LookAtBoneName))
						{
							ResultLocation = SKMesh->GetSocketLocation(LookAtBoneName);
							if (bOnlyUseBoneZ)
							{
								float BoneZ = ResultLocation.Z;
								ResultLocation = LookAtTarget->GetActorLocation();
								ResultLocation.Z = BoneZ;
							}
						}
						else
						{
							ResultLocation = LookAtTarget->GetActorLocation();
							if(UCapsuleComponent* Capsule = C7Actor->GetCapsule())
							{
								ResultLocation.Z += Capsule->GetScaledCapsuleHalfHeight() * 0.8f;
							}
						}
						switch(TransformSpace)
						{
						case RTS_World:
							ResultLocation += BoneOffset;
							break;
						default:
							ResultLocation += LookAtTarget->GetActorRotation().RotateVector(BoneOffset);
							break;
						}
						if(bSplineControl)
						{
							ResultLocation.X = FollowSplineMoveLocation.X;
							ResultLocation.Y = FollowSplineMoveLocation.Y;
						}
						if(!PreviousCameraLocation.Equals(ResultLocation))
						{
							this->SetActorLocation(ResultLocation);
							PreviousCameraLocation = ResultLocation;
						}
						return;
					}
				}
			}
	
			FVector ResultLocation = LookAtTarget->GetActorLocation();
			switch(TransformSpace)
			{
			case RTS_World:
				ResultLocation += BoneOffset;
				break;
			default:
				ResultLocation += LookAtTarget->GetActorRotation().RotateVector(BoneOffset);
				break;
			}
			if(bSplineControl)
			{
				ResultLocation.X = FollowSplineMoveLocation.X;
				ResultLocation.Y = FollowSplineMoveLocation.Y;
			}
			if(!PreviousCameraLocation.Equals(ResultLocation))
			{
				this->SetActorLocation(ResultLocation);
				PreviousCameraLocation = ResultLocation;
			}
		}
	}
}

void ABaseCamera::SetControlledTarget(AActor* Target)
{
	TargetActor = Target;
	if (CameraArmComponent)
	{
		CameraArmComponent->ControlActor = Target;
	}

	SetArmUsingAbsoluteRotation(TargetActor != nullptr);
}

void ABaseCamera::SetLookAtTargetByID(int64 TargetID)
{
	AActor* Target = KGUtils::GetActorByID(TargetID);
	LookAtTarget = Target;
}

void ABaseCamera::SetLookAtTarget(AActor* InTargetActor, AActor* ControlActor, const FName& NewBoneName, const FVector& Offset, ERelativeTransformSpace InTransformSpace)
{
	SetControlledTarget(ControlActor);
	LookAtTarget = InTargetActor;
	if (CameraArmComponent)
	{
		CameraArmComponent->LookAtTarget = InTargetActor;
		if(auto* CppEntity = UKGUEActorManager::GetLuaEntityByActor(InTargetActor))
		{
			CameraArmComponent->bLookAtMainPlayer = CppEntity->GetIsMainPlayer();
		}
	}
	TransformSpace = InTransformSpace;
	BoneOffset = Offset;
	LookAtBoneName = NewBoneName;
}

AActor* ABaseCamera::GetLookAtTarget()
{
	return LookAtTarget.Get();
}

void ABaseCamera::SetBoneOffset(const FVector& Offset, ERelativeTransformSpace InTransformSpace)
{
	TransformSpace = InTransformSpace;
	BoneOffset = Offset;
}

void ABaseCamera::SetBoneOffsetZ(float NewZ)
{
	BoneOffset.Z = NewZ;
}

void ABaseCamera::SetArmUsingAbsoluteRotation(bool bInAbsoluteRotation)
{
	if (CameraArmComponent)
	{
		CameraArmComponent->SetUsingAbsoluteRotation(bInAbsoluteRotation);
	}
}

void ABaseCamera::BeginPlay()
{
	AActor::BeginPlay();
	CameraTickProxy.Reset();
	CameraTickProxy = MakeUnique<FCameraProxyTickableObject>(this);
}

void ABaseCamera::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	CameraTickProxy.Reset();
	Super::EndPlay(EndPlayReason);
}

void ABaseCamera::SetControlConfig(UKgCameraMode* TargetMode)
{
	CurActivateMode = TargetMode;
}

void ABaseCamera::ResetConfig()
{
	bManualControl = false;
	bOnlyUseBoneZ = false;
	TargetActor.Reset();
	BoneOffset = FVector::ZeroVector;
	PreviousCameraLocation = FVector::ZeroVector;
	LookAtBoneName = NAME_None;
	
	if (UCameraComponent* CameraComp = GetCameraComponent())
	{
		CameraComp->SetRelativeTransform(FTransform::Identity);
	}
	if (CameraArmComponent != nullptr)
	{
		CameraArmComponent->ResetConfig();
	}
	
	CurActivateMode = nullptr;

	CancelFollowLookAtSpineMove();
}

UKgCameraMode* ABaseCamera::GetCurActivateMode() const
{
	return CurActivateMode.Get();
}

bool ABaseCamera::IsLinkedTarget() const
{
	return TargetActor.IsValid();
}

FVector ABaseCamera::GetCameraLocation()
{
	if(const UCameraComponent* Camera = GetCameraComponent())
	{
		return Camera->GetComponentLocation();
	}

	return FVector::ZeroVector;
}

FRotator ABaseCamera::GetCameraRotation()
{
	if(const UCameraComponent* Camera = GetCameraComponent())
	{
		return Camera->GetComponentRotation();
	}

	return FRotator::ZeroRotator;
}

void ABaseCamera::LookUp_Axis(float Value)
{
	RotationInput.Pitch += Value;
}

void ABaseCamera::Turn_Axis(float Value)
{
	RotationInput.Yaw += Value;
}

void ABaseCamera::ForceUpdateCamera(bool bDoTrace)
{
	TickCamera(0.f);
	if(CameraArmComponent != nullptr)
	{
		CameraArmComponent->ForceUpdate(bDoTrace);
	}
}

void ABaseCamera::ForceUpdateCameraWithBaseCollision()
{
	TickCamera(0.f);
	if(CameraArmComponent != nullptr)
	{
		CameraArmComponent->ForceUpdateWithBaseCollision();
	}
}

void ABaseCamera::EnableCameraTick(bool bEnable)
{
	if(CameraTickProxy.IsValid())
	{
		CameraTickProxy->bCanCameraTick = bEnable;
	}
	// SetActorTickEnabled(bEnable);
	// if(CameraArmComponent != nullptr)
	// {
	// 	CameraArmComponent->SetComponentTickEnabled(bEnable);
	// }
}

void ABaseCamera::InitManualMove(bool bEnable, bool bLimitRot, float NewPitchMin, float NewPitchMax, float NewYawMin,
	float NewYawMax)
{
	bManualControl = bEnable;
	TargetLoc = this->GetActorLocation();
	InitLimitRot(bLimitRot, NewPitchMin, NewPitchMax, NewYawMin, NewYawMax);
}

void ABaseCamera::InitLimitRot(bool bLimitRot, float NewPitchMin, float NewPitchMax, float NewYawMin, float NewYawMax)
{
	bLimitedPitchRot = bLimitRot;
	bLimitedYawRot = bLimitRot;
	if(bLimitRot)
	{
		PitchMax = NewPitchMax;
		PitchMin = NewPitchMin;
		YawMin = NewYawMin;
		YawMax = NewYawMax;
	}
}

void ABaseCamera::InitLimitPitchRot(bool bLimitRot, float NewPitchMin, float NewPitchMax)
{
	bLimitedPitchRot = bLimitRot;
	if(bLimitRot)
	{
		PitchMax = NewPitchMax;
		PitchMin = NewPitchMin;
	}
}

void ABaseCamera::Move_X(float Value, bool bLimit)
{
	const FRotator ActorRot = this->GetActorRotation();
	const FVector ForwardDir = ActorRot.RotateVector(FVector::ForwardVector);
	TargetLoc += ForwardDir * Value;
}

void ABaseCamera::Move_Y(float Value, bool bLimit)
{
	const FRotator ActorRot = this->GetActorRotation();
	const FVector RightDir = ActorRot.RotateVector(FVector::RightVector);
	TargetLoc += RightDir * Value;
}

void ABaseCamera::Move_Z(float Value, bool bLimit)
{
	const FRotator ActorRot = this->GetActorRotation();
	const FVector UpDir = ActorRot.RotateVector(FVector::UpVector);
	TargetLoc += UpDir * Value;
}

void ABaseCamera::Move_ZToXOY(float Value, bool bLimit)
{
	const FRotator ActorRot = this->GetActorRotation();
	FVector UpDir = ActorRot.RotateVector(FVector::UpVector);
	if(UpDir == FVector::UpVector)
	{
		UpDir = FVector::UpVector ^ ActorRot.RotateVector(FVector::RightVector);
	}
	else
	{
		UpDir.Z = 0;
		UpDir = UpDir.GetSafeNormal();
	}
	TargetLoc += UpDir * Value;
}

void ABaseCamera::SetCameraFOV(float NewFOV)
{
	GetCameraComponent()->SetFieldOfView(NewFOV);
}

float ABaseCamera::GetCameraFOV()
{
	if(const auto CameraCom = GetCameraComponent())
	{
		return CameraCom->FieldOfView;
	}
	return 90;
}

void ABaseCamera::MarkDeActiveByMode()
{
	GetCameraArmComponent()->MarkDeActiveByMode();
}

void ABaseCamera::InitFollowLookAtSpineMove()
{
	bSplineControl = true;
}

void ABaseCamera::CancelFollowLookAtSpineMove()
{
	bSplineControl = false;
}

void ABaseCamera::RemoveLookAtBoneRemainOffset()
{
	if (LookAtTarget.IsValid())
	{
		FVector CameraToLookAt = PreviousCameraLocation - LookAtTarget->GetActorLocation();
		LookAtBoneName = NAME_None;
		TransformSpace = ERelativeTransformSpace::RTS_Actor;
		CameraToLookAt = LookAtTarget->GetActorTransform().InverseTransformVector(CameraToLookAt);
		BoneOffset = CameraToLookAt;
	}
}

