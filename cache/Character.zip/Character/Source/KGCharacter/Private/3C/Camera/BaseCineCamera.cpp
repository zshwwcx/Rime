#include "3C/Camera/BaseCineCamera.h"

#include "CineCameraComponent.h"

ABaseCineCamera::ABaseCineCamera(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer.SetDefaultSubobjectClass<UCineCameraComponent>(TEXT("CameraComponent")))
{
}

UCineCameraComponent* ABaseCineCamera::GetCineCameraComponent()
{
	return Cast<UCineCameraComponent>(GetCameraComponent());
}
