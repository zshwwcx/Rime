﻿#include "3C/Camera/PostProcessNew/PostProcessInstance/PPPhotoWhiteTemp.h"

#include "Util/ColorConstants.h"

void KGPPPhotoWhiteTemp::InitParams(
	const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType, const FString& InWhiteTempCurvePath)
{
	KGPPNonMaterialBase::InitParams(CommonParams, InPPManager, InPPType);
	WhiteTempID = RegisterManualWeightCurve(InWhiteTempCurvePath, EKGManualWeightCurveType::FloatCurve);
}

void KGPPPhotoWhiteTemp::SetManualWeightCurveValue(float Weight)
{
	KGPPNonMaterialBase::SetManualWeightCurveValue(Weight);
	KG_PP_SET_FLOAT_CURVE_PARAM(WhiteTemp);
}
