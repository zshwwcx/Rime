#include "3C/Camera/PostProcessNew/PostProcessInstance/PPPhotoFilter.h"
#include "Manager/KGCppAssetManager.h"
#include "3C/Camera/PostProcessNew/PostProcessManager.h"

void KGPPPhotoFilter::InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType,
	const FString& InPhotoFilterDataAssetPath)
{
	KGPPBase::InitParams(CommonParams, InPPManager);
	PPType = InPPType;
	PhotoFilterDataAssetPath = InPhotoFilterDataAssetPath;
}

bool KGPPPhotoFilter::OnTaskStart()
{
	if (!KGPPNonMaterialBase::OnTaskStart())
	{
		return false;
	}

	if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(PostProcessManager.Get()))
	{
		AssetLoadID = AssetManager->AsyncLoadAsset(
			PhotoFilterDataAssetPath, FAsyncLoadCompleteDelegate::CreateRaw(this, &KGPPPhotoFilter::OnDataAssetLoaded));
	}	
	
	return true;
}

void KGPPPhotoFilter::OnTaskEnd(EKGPostProcessStopReason StopReason)
{
	if (AssetLoadID != 0)
	{
		if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(PostProcessManager.Get()))
		{
			AssetManager->CancelAsyncLoadByLoadID(AssetLoadID);
		}
		else
		{
			UE_LOG(LogKGPP, Error, TEXT("KGPPPhotoFilter::OnTaskEnd failed, AssetManager is nullptr, %s"), *GetDebugInfo());
		}
	}
	
	KGPPNonMaterialBase::OnTaskEnd(StopReason);
}

bool KGPPPhotoFilter::CanOutputPostProcess() const
{
	if (!DataAsset.IsValid())
	{
		return false;
	}
	
	return KGPPNonMaterialBase::CanOutputPostProcess();
}

void KGPPPhotoFilter::OnDataAssetLoaded(int InLoadID, UObject* Asset)
{
	AssetLoadID = 0;
	UKGPhotoFilterPostProcessDataAsset* TempDataAsset = Cast<UKGPhotoFilterPostProcessDataAsset>(Asset);
	if (TempDataAsset == nullptr)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPPhotoFilter::OnDataAssetLoaded failed, asset load failed, %s, %s"), *PhotoFilterDataAssetPath, *GetDebugInfo());
		return;
	}

	UE_LOG(LogKGPP, Log, TEXT("KGPPPhotoFilter::OnDataAssetLoaded, %s, %s"), *PhotoFilterDataAssetPath, *GetDebugInfo());
	DataAsset = TStrongObjectPtr(TempDataAsset);
	DataAsset->ApplyToPostProcessSettings(PostProcessSettings);
}
