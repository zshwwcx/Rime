﻿#include "3C/Camera/PostProcessNew/PostProcessInstance/PPMaterialMultiTargetFog.h"

#include "TimerManager.h"
#include "3C/Camera/PostProcessNew/PostProcessManager.h"

void KGPPMaterialMultiTargetFog::InitParams(const FKGPPCommonParams& CommonParams,
    EKGPostProcessType InPPType, const FString& InMaterialPath, const FString& InPlaneMeshMaterialPath, int32 InViewPriority,
    const FName& InIntensityParamName, const FKGPPMaterialParams& InParams, TWeakObjectPtr<UPostProcessManager> InPPManager,
    float InBlendTimeSeconds, float InFogDistanceInMeters, float InHeadInfoHiddenDist, int32 InMaxExtraTargetNum)
{
	KGPPMaterialFog::InitParams(
		CommonParams, InPPType, InMaterialPath, InPlaneMeshMaterialPath, InViewPriority, InIntensityParamName, InParams, InPPManager,
		false, 0, InFogDistanceInMeters, InHeadInfoHiddenDist, InBlendTimeSeconds);

	MaxExtraTargetNum = InMaxExtraTargetNum;
}

void KGPPMaterialMultiTargetFog::AddOrUpdateFogTarget(
	KGEntityID EntityID, const FName& AvoidDistanceParamNamePrefix, float AvoidDistanceInMeters, const FName& AvoidSmoothDistParamNamePrefix, float AvoidSmoothDist,
	const FName& FogOpacityParamPrefix, const FName& EntityPosParamNamePrefix, float InBlendTimeSeconds)
{
	InBlendTimeSeconds = FMath::Max(InBlendTimeSeconds, 0.001f);
	
	if (FogTargetInfos.Contains(EntityID))
	{
		uint32 CurrentSlotIndex = FogTargetInfos[EntityID].SlotIndex;
		const FName AvoidDistanceParamName = GetParamNameBySlotIndex(AvoidDistanceParamNamePrefix, CurrentSlotIndex);
		UpdateScalarLinearSampleParamTargetValue(AvoidDistanceParamName, AvoidDistanceInMeters, true, InBlendTimeSeconds);
		
		const FName AvoidSmoothDistParamName = GetParamNameBySlotIndex(AvoidSmoothDistParamNamePrefix, CurrentSlotIndex);
		UpdateScalarLinearSampleParamTargetValue(AvoidSmoothDistParamName, AvoidSmoothDist, true, InBlendTimeSeconds);
		return;
	}

	uint32 CurrentSlotIndex = 0;
	if (!GetAvailableSlotIndex(CurrentSlotIndex))
	{
		UE_LOG(LogKGPP, Warning, TEXT("KGPPMaterialMultiTargetFog::AddOrUpdateFogTarget: no free slot left, %s"), *GetDebugInfo());
		return;
	}
	FKGMultiTargetFogTargetInfo TargetInfo;
	TargetInfo.SlotIndex = CurrentSlotIndex;
	FogTargetInfos.Add(EntityID, TargetInfo);

	const FName EntityPosParamName = GetParamNameBySlotIndex(EntityPosParamNamePrefix, CurrentSlotIndex);
	UpdateEntityLocationParams(EntityPosParamName, EntityID);
	
	const FName AvoidDistanceParamName = GetParamNameBySlotIndex(AvoidDistanceParamNamePrefix, CurrentSlotIndex);
	AddOrUpdateScalarLinearSampleParamTargetValue(AvoidDistanceParamName, 0.0f, AvoidDistanceInMeters, true, InBlendTimeSeconds);
	
	const FName AvoidSmoothDistParamName = GetParamNameBySlotIndex(AvoidSmoothDistParamNamePrefix, CurrentSlotIndex);
	AddOrUpdateScalarLinearSampleParamTargetValue(AvoidSmoothDistParamName, 0.0f, AvoidSmoothDist, true, InBlendTimeSeconds);
	
	const FName FogOpacityParam = GetParamNameBySlotIndex(FogOpacityParamPrefix, CurrentSlotIndex);
	AddOrUpdateScalarLinearSampleParamTargetValue(FogOpacityParam, 0.0f, 1.0f, true, InBlendTimeSeconds);
}

void KGPPMaterialMultiTargetFog::RemoveFogTarget(KGEntityID EntityID, const FName& FogOpacityParamPrefix, float InBlendTimeSeconds)
{
	if (!FogTargetInfos.Contains(EntityID))
	{
		return;
	}

	auto& TargetInfo = FogTargetInfos[EntityID];
	const uint32 CurrentSlotIndex = TargetInfo.SlotIndex;
	const FName FogOpacityParam = GetParamNameBySlotIndex(FogOpacityParamPrefix, CurrentSlotIndex);
	UpdateScalarLinearSampleParamTargetValue(FogOpacityParam, 0.0f, true, InBlendTimeSeconds);

	if (InBlendTimeSeconds < UE_KINDA_SMALL_NUMBER)
	{
		InternalRemoveFogTarget(EntityID);
	}
	else
	{
		if (!PostProcessManager.IsValid())
		{
			UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialMultiTargetFog::RemoveFogTarget: PostProcessManager is null, %s"), *GetDebugInfo());
			return;
		}
		
		UWorld* World = PostProcessManager->GetWorld();
		if (!World)
		{
			UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialMultiTargetFog::RemoveFogTarget: World is null, %s"), *GetDebugInfo());
			return;
		}

		World->GetTimerManager().ClearTimer(TargetInfo.RemoveTimerHandle);
		World->GetTimerManager().SetTimer(TargetInfo.RemoveTimerHandle,
			FTimerDelegate::CreateRaw(this, &KGPPMaterialMultiTargetFog::OnTargetFogOpacityReachZero, EntityID),
			InBlendTimeSeconds, false);
	}
}

void KGPPMaterialMultiTargetFog::OnTaskEnd(EKGPostProcessStopReason StopReason)
{
	if (PostProcessManager.IsValid())
	{
		if (UWorld* World = PostProcessManager->GetWorld())
		{
			for (auto& Kvp : FogTargetInfos)
			{
				World->GetTimerManager().ClearTimer(Kvp.Value.RemoveTimerHandle);
			}
		}
		else
		{
			UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialMultiTargetFog::OnTaskEnd: PostProcessManager's world is invalid, cannot clear target remove timers, %s"), *GetDebugInfo());
		}
	}
	else
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialMultiTargetFog::OnTaskEnd: PostProcessManager is invalid, cannot clear target remove timers, %s"), *GetDebugInfo());
	}
	
	KGPPMaterialFog::OnTaskEnd(StopReason);
}

bool KGPPMaterialMultiTargetFog::GetAvailableSlotIndex(uint32& OutSlotIndex)
{
	if (FogTargetInfos.Num() >= MaxExtraTargetNum)
	{
		UE_LOG(LogKGPP, Warning, TEXT("KGPPMaterialMultiTargetFog::GetAvailableSlotIndex: exceed max target num %d, %s"),
			MaxExtraTargetNum, *GetDebugInfo());
		return false;
	}
	
	TSet<uint32> SlotIndexSet;
	for (const auto& Kvp : FogTargetInfos)
	{
		SlotIndexSet.Add(Kvp.Value.SlotIndex);
	}
	
	for (int32 i = 1; i <= MaxExtraTargetNum; i++)
	{
		if (!SlotIndexSet.Contains(i))
		{
			OutSlotIndex = i;
			return true;
		}
	}

	UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialMultiTargetFog::GetAvailableSlotIndex: should never reach here, %s"), *GetDebugInfo());
	for (const auto& Kvp : FogTargetInfos)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialMultiTargetFog::GetAvailableSlotIndex: TargetID %lld -> SlotIndex %d, %s"),
			Kvp.Key, Kvp.Value.SlotIndex, *GetDebugInfo());
	}
	return false;
}

void KGPPMaterialMultiTargetFog::OnTargetFogOpacityReachZero(KGEntityID EntityID)
{
	UE_LOG(LogKGPP, Log, TEXT("KGPPMaterialMultiTargetFog::OnTargetFogOpacityReachZero: Target fog opacity reached zero, EntityID %lld, %s"),
		EntityID, *GetDebugInfo());
	InternalRemoveFogTarget(EntityID);
}

void KGPPMaterialMultiTargetFog::InternalRemoveFogTarget(KGEntityID EntityID)
{
	if (!FogTargetInfos.Contains(EntityID))
	{
		return;
	}

	auto& TargetInfo = FogTargetInfos[EntityID];
	if (PostProcessManager.IsValid())
	{
		if (UWorld* World = PostProcessManager->GetWorld())
		{
			World->GetTimerManager().ClearTimer(TargetInfo.RemoveTimerHandle);
		}
	}

	FogTargetInfos.Remove(EntityID);
}
