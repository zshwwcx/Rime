#include "3C/Camera/CameraAction/CameraLockLookForward.h"
#include "3C/Util/KGUtils.h"

void UCameraLockLookForward::Init(int64 ActorID, float InRotSpeed)
{
	ForwardActor = KGUtils::GetActorByID(ActorID);
	RotSpeed = InRotSpeed;
	Duration = -1;
	bRecover = false;
}

bool UCameraLockLookForward::ProcessViewRotation(AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch,
	double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot)
{
	if(!ForwardActor.IsValid())
	{
		DisableAction(true);
		return false;
	}

	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return false;
	}

	bOutChangeYaw = true;
	float Yaw = ForwardActor->GetActorRotation().Yaw;
	OutYaw = FRotator::NormalizeAxis(OutYaw);
	Yaw = MathFormula::SameSignAngle(OutYaw, Yaw);
	OutYaw = FMath::FInterpTo(OutYaw, Yaw, DeltaTime, RotSpeed);
	OutDeltaRot.Yaw = 0.f;
	return true;
}

void UCameraLockLookForward::Play()
{
	Super::Play();

	if(!ForwardActor.IsValid())
	{
		DisableAction(true);
	}
}
