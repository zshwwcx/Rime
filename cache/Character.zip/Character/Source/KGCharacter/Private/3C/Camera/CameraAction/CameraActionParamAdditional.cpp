// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Camera/CameraAction/CameraActionParamAdditional.h"

#include "UMG/Animation/KGSequencerComponentTypes.h"
#include "3C/Util/KGUtils.h"


void UCameraActionParamAdditional::InitParamAdditional(float InFadeInTime, float InDurationTime,
                                                       float InFadeOutTime, float InYawOffSet, float InPitchOffSet,
                                                       float InZoomOffSet, float InFOVOffSet,
                                                       ECameraEaseFunction::Type InBlendInMode,
                                                       ECameraEaseFunction::Type InBlendOutMode,
                                                       int64 InFadeInCurveID, int64 InFadeOutCurveID,
                                                       bool InbDisableLimitView)
{
	SetEaseInType(InBlendInMode, InFadeInTime, InFadeInCurveID);
	SetEaseOutType(InBlendOutMode, InFadeOutTime, InFadeOutCurveID);
	Duration = InDurationTime;

	bDisableLimitView = false;
	bRowDisableLimitView = InbDisableLimitView;

	RotationOffSet = FRotator::ZeroRotator;
	RotationOffSet.Pitch = InPitchOffSet;
	RotationOffSet.Yaw = InYawOffSet;

	ZoomOffset = InZoomOffSet;
	FOVOffset = InFOVOffSet;
}

void UCameraActionParamAdditional::Play()
{
	Super::Play();

	if(bRowDisableLimitView && CameraMode.IsValid())
	{
		CameraManager->DisableViewLimit(false);
		bDisableLimitView = true;
	}
	else
	{
		bDisableLimitView = false;
	}
}

void UCameraActionParamAdditional::ModifyCamera(float DeltaTime)
{
	Super::ModifyCamera(DeltaTime);

	if(CameraMode.IsValid() && CameraMode->IsActivate())
	{
		if(FOVOffset != 0)
		{
			CameraMode->AddFOVDelta(FOVBase + FMath::Clamp(Alpha, 0.f, 1.f) * FOVOffset);
		}

		if(ZoomOffset != 0)
		{
			CameraMode->AddZoomDelta(ZoomBase + FMath::Clamp(Alpha, 0.f, 1.f) * ZoomOffset);
		}

		if (!RotationOffSet.IsNearlyZero())
		{
			const FRotator DeltaAng = (RotationOffSet - RotationBase).GetNormalized();
			FRotator Result = RotationBase + FMath::Clamp(Alpha, 0.f, 1.f) * DeltaAng;
			CameraMode->AddRotDelta(Result);
		}
	}
}

void UCameraActionParamAdditional::Abort()
{
	if(bDisableLimitView)
	{
		CameraManager->DisableViewLimit(false);
	}

	Super::Abort();
}

