// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Camera/CameraAction/CameraFollowMove.h"

#include "3C/Character/BaseCharacter.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "Components/CapsuleComponent.h"

void UCameraFollowMove::Init(float InYawBlendParam, float InYawBlendSubParam, float InPitchBlendParam,
	float InVelocityThreshold, float InLookPitchOffset, float InContinuousInputDurationThreshold,
	float InPitchSampleDuration, float InActionCD, float InInputThreshold)
{
	YawBlendParam = InYawBlendParam;
	YawBlendSubParam = InYawBlendSubParam;
	PitchBlendParam = InPitchBlendParam;
	VelocityThreshold = InVelocityThreshold;

	LookPitchOffset = InLookPitchOffset;
	ActionCD = InActionCD;
	InputThreshold = InInputThreshold;
	ContinuousInputDurationThreshold = InContinuousInputDurationThreshold;
	PitchSampleDuration = InPitchSampleDuration;

	Duration = -1;
	MoveComponent.Reset();
	LookAt.Reset();

	bRecover = false;
}

void UCameraFollowMove::Play()
{
	Super::Play();
	CurrentCDTime = ActionCD + CDCorrect;
	CurrentInputDuration = 0.f;

	InitParams();
}

void UCameraFollowMove::Abort()
{
	Super::Abort();
	YawSmoothSpeed = 0.f;
	YawBlend = 0.f;
	LookAt.Reset();
}

bool UCameraFollowMove::ProcessViewRotation(AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch,
	double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot)
{
	if(!MoveComponent.IsValid() || !LookAt.IsValid())
	{
		return false;
	}

	if(!CameraMode.IsValid() || !CameraMode->IsActivate() || CameraMode->IsBlending())
	{
		return false;
	}

	CurrentCDTime = FMath::Min(CurrentCDTime + DeltaTime, ActionCD + CDCorrect);
	if(CurrentCDTime < ActionCD)
	{
		return false;
	}

	// if(!MoveComponent->IsMovingOnGround())
	// {
	// 	return false;
	// }

	TRACE_CPUPROFILER_EVENT_SCOPE_STR("CameraActon:FollowMove");

	OutDeltaRot.Pitch = 0.f;
	OutDeltaRot.Yaw = 0.f;
	
	FVector MoveVelocity = MoveComponent->GetMovementVelocity();
	bool bAccelerate = true;
	bool bWalk = MoveComponent->IsMovingOnGround() || MoveComponent->IsSwimming();
	bool bHasInput = MoveComponent->GetHasRawLocoInput();
	bool bIsDodge = MoveComponent->GetIsDodgeLocoState(MoveComponent->GetLocomotionStateFromMask());
	if(!bHasInput || !MoveComponent->GetIsLocoStart() || MoveVelocity.SizeSquared() < VelocityThreshold * VelocityThreshold)
	{
		bAccelerate = false;
		// YawBlend = FMath::Max(0, YawBlend - YawBlendSubParam * DeltaTime);
		YawBlend = 0.f;

		CurrentInputDuration = 0.f;
		MoveNormal = FVector::ZeroVector;
		MoveNormalQueue.Empty();
		MoveNormalTimeStampQueue.Empty();
	}
	else
	{
		ELocoInputSemantic InputSemantic = MoveComponent->GetLocoInputSemantic();
		FVector MoveForward = MoveVelocity.GetSafeNormal2D();
		
		if (InputSemantic == ELocoInputSemantic::OnGroundSemantic)
		{
			float RowInputX, RowInputY, RowInputZ;
			MoveComponent->GetSplitRowInputVector(RowInputX, RowInputY, RowInputZ);
			if(!FMath::IsNearlyZero(RowInputY, InputThreshold) && !bIsDodge)
			{
				YawBlend = FMath::Min(YawBlendParam, YawBlend + YawBlendSubParam * DeltaTime);
			}
			else
			{
				// YawBlend = FMath::Max(0, YawBlend - YawBlendSubParam * DeltaTime);
				YawBlend = 0.f;
			}
		}
		else
		{
			FRotator CameraRot{OutPitch, OutYaw, OutRoll};
			FVector MoveForwardToCamera = CameraRot.UnrotateVector(MoveForward);
			// UE_LOG(LogTemp, Log, TEXT("CameraFollow MoveForwardToCamera:%s MoveForward:%s"), *MoveForwardToCamera.ToString(), *MoveForward.ToString())
			if(!FMath::IsNearlyZero(MoveForwardToCamera.Y, InputThreshold) && !bIsDodge)
			{
				YawBlend = FMath::Min(YawBlendParam, YawBlend + YawBlendSubParam * DeltaTime);
			}
			else
			{
				// YawBlend = FMath::Max(0, YawBlend - YawBlendSubParam * DeltaTime);
				YawBlend = 0.f;
			}
		}

		if(bWalk)
		{
			CurrentInputDuration = FMath::Min(CurrentInputDuration + DeltaTime, ContinuousInputDurationThreshold + CDCorrect);
			static FRotator DetectRot1 = FRotator(0, 120.f, 0);
			static FRotator DetectRot2 = FRotator(0, 240.f, 0);
			FVector BaseLocation = LookAt->GetActorLocation();
			FVector FloorTraceStartLocation1 = BaseLocation - CapsuleRadius * DetectRot1.RotateVector(MoveForward);
			FVector FloorTraceStartLocation2 = BaseLocation - CapsuleRadius * DetectRot2.RotateVector(MoveForward);
			FVector FloorTraceEndLocation = BaseLocation + 3 * CapsuleRadius * MoveForward;
			FVector FloorStartLocation1 = FloorTraceStartLocation1;
			FVector FloorStartLocation2 = FloorTraceStartLocation1;
			FVector FloorEndLocation = FloorTraceEndLocation;
			FVector Normal = FVector::UpVector;
			if(LookAt->SimpleGetAndCheckStickGroundLocationFromSpecificLocation(FloorTraceStartLocation1, FloorStartLocation1)
				&& LookAt->SimpleGetAndCheckStickGroundLocationFromSpecificLocation(FloorTraceEndLocation, FloorEndLocation)
				&& LookAt->SimpleGetAndCheckStickGroundLocationFromSpecificLocation(FloorTraceStartLocation2, FloorStartLocation2))
			{
				FVector VectorCA = FloorEndLocation - FloorStartLocation1;
				FVector VectorCB = FloorEndLocation - FloorStartLocation2;

				Normal = FVector::CrossProduct(VectorCB, VectorCA).GetSafeNormal(UE_SMALL_NUMBER, FVector::UpVector);
			}
			MoveNormalQueue.Enqueue(Normal);
			MoveNormalTimeStampQueue.Enqueue(RunningTime);
			MoveNormal += Normal;
			while(float* Time = MoveNormalTimeStampQueue.Peek())
			{
				if(*Time < (RunningTime - PitchSampleDuration))
				{
					MoveNormalTimeStampQueue.Pop();
					MoveNormalQueue.Dequeue(Normal);
					MoveNormal -= Normal;
				}
				else
				{
					break;
				}
			}
		}
		else
		{
			CurrentInputDuration = 0.f;
			MoveNormal = FVector::ZeroVector;
			MoveNormalQueue.Empty();
			MoveNormalTimeStampQueue.Empty();
		}
	}

	float CurrentYaw = FRotator::NormalizeAxis(OutYaw);
	float YawStamp = 0.f;
	if(bAccelerate)
	{
		FRotator MoveVelocityDir = MoveVelocity.Rotation();
		float TargetYaw = MathFormula::SameSignAngle(CurrentYaw, MoveVelocityDir.Yaw);
		float DeltaAng = TargetYaw - CurrentYaw;
		YawSign = FMath::Sign(DeltaAng);
		MoveVelocity.Z = 0.f;
		YawStamp = YawBlend * MoveVelocity.Size();
		YawStamp = FMath::Min(FMath::Abs(DeltaAng), YawStamp) * YawSign;
	}
	else
	{
		YawStamp = YawSign * YawBlend;
	}
	OutYaw = CurrentYaw + YawStamp;
	// UE_LOG(LogTemp, Log, TEXT("Camera Navigation Yaw:%f YawBlend:%f bAccelerate:%d YawStamp:%f RowInputY:%f Velocity:%s Value:%f"), OutViewRotation.Yaw, YawBlend, bAccelerate, YawStamp, RowInputY, *MoveVelocity.ToString(), MoveVelocity.Length());
	bOutChangeYaw = !FMath::IsNearlyZero(YawBlend);
	
	float CurrentPitch = FRotator::NormalizeAxis(OutPitch);
	float TargetPitch = CurrentPitch;
	bOutChangePitch = false;
	if(CurrentInputDuration > ContinuousInputDurationThreshold)
	{
		FVector Normal = MoveNormal.GetSafeNormal();
		FVector CameraRotDir = CameraMode->GetCameraRotation().Vector();
		FVector DesiredCameraRotDir = (CameraRotDir -  (CameraRotDir | Normal)).GetSafeNormal();

		TargetPitch = MathFormula::SameSignAngle(CurrentPitch, DesiredCameraRotDir.Rotation().Pitch + LookPitchOffset);
		bOutChangePitch = true;
		// UE_LOG(LogTemp, Log, TEXT("Camera Navigation TargetPitch:%f PitchBlend:%f MoveNormal:%s"), TargetPitch, PitchBlend, *Normal.ToString())
	}
	OutPitch = FMath::IsNearlyZero(PitchBlendParam) ? TargetPitch : TargetPitch + (CurrentPitch - TargetPitch) * FMath::Pow(0.5f, DeltaTime / PitchBlendParam);

	return bOutChangePitch || bOutChangeYaw;
}

bool UCameraFollowMove::IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType)
{
	if(ControlType == ECameraManualControlType::ManualRot)
	{
		CurrentCDTime = 0.f;
	}

	return false;
}

void UCameraFollowMove::DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode)
{
	Super::DoWhenEffectModeActivate(ActivateCameraMode);
	InitParams();
}

void UCameraFollowMove::InitParams()
{
	MoveComponent.Reset();
	LookAt.Reset();
	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return;
	}

	if(UCameraArmComponent* Arm = CameraMode->GetCameraArmComponent())
	{
		if(Arm->LookAtTarget.IsValid())
		{
			if(URoleMovementComponent* RoleMove = Arm->LookAtTarget->GetComponentByClass<URoleMovementComponent>())
			{
				MoveComponent = RoleMove;

				if(UCapsuleComponent* Capsule = Arm->LookAtTarget->GetComponentByClass<UCapsuleComponent>())
				{
					CapsuleRadius = Capsule->GetScaledCapsuleRadius();
					CapsuleHalfHeight = Capsule->GetScaledCapsuleHalfHeight();
					LookAt = Cast<ABaseCharacter>(Arm->LookAtTarget);
				}
			}
		}
	}
}
