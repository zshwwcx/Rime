#include "3C/Camera/PostProcessNew/PostProcessInstance/PPMaterialPhantom.h"

#include "3C/Effect/KGEffectManager.h"
#include "3C/Core/KGUEActorManager.h"
#include "3C/Util/KGUtils.h"
#include "3C/Camera/PostProcessNew/PostProcessManager.h"

KGPPMaterialPhantom::KGPPMaterialPhantom(uint32 InCustomPPID)
{
	PostProcessID = InCustomPPID;
	SequenceID = InCustomPPID;
}

void KGPPMaterialPhantom::InitParams(const FKGPPCommonParams& CommonParams, const FString& InNiagaraPath, EKGPostProcessQuality InPPQualityThreshold,
	const FName& InAttachSocketName, const TWeakObjectPtr<AActor>& InAttachActor, const TWeakObjectPtr<USceneComponent> InAttachComponent,
	KGEntityID InCustomDepthEntityID, int32 InCustomDepthLogicType, int32 InCustomDepthPriority, int32 InCustomDepthStencilValue,
	EKGPostProcessType InPPType, const FString& InMaterialPath, const FString& InPlaneMeshMaterialPath, int32 InViewPriority,
	const FName& InIntensityParamName, const FKGPPMaterialParams& InParams, TWeakObjectPtr<UPostProcessManager> InPPManager)
{
	KGPPMaterialBase::InitParams(CommonParams, InPPType, InMaterialPath, InPlaneMeshMaterialPath, InViewPriority, InIntensityParamName, InParams, InPPManager);
	NiagaraPath = InNiagaraPath;
	AttachSocketName = InAttachSocketName;
	AttachActor = InAttachActor;
	AttachComponent = InAttachComponent;
	CustomDepthEntityID = InCustomDepthEntityID;
	CustomDepthStencilValue = InCustomDepthStencilValue;
	CustomDepthLogicType = InCustomDepthLogicType;
	CustomDepthPriority = InCustomDepthPriority;
	PPQualityThreshold = InPPQualityThreshold;
}

bool KGPPMaterialPhantom::OnTaskStart()
{
	if (!KGPPMaterialBase::OnTaskStart())
	{
		return false;
	}

	RegisterPostProcessQualityChangedDelegate();
	
	return true;
}

void KGPPMaterialPhantom::OnTaskEnd(EKGPostProcessStopReason StopReason)
{
	UnregisterPostProcessQualityChangedDelegate();
	
	KGPPMaterialBase::OnTaskEnd(StopReason);
}

void KGPPMaterialPhantom::OnTaskActivated()
{
	KGPPMaterialBase::OnTaskActivated();

	if (PostProcessManager.IsValid())
	{
		const auto CurrentPostProcessQuality = PostProcessManager->GetPostProcessQuality();
		RefreshEffect(CurrentPostProcessQuality);
	}
}

void KGPPMaterialPhantom::OnTaskDeactivated()
{
	if (NiagaraEffectID != 0)
	{
		if (UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(PostProcessManager.Get()))
		{
			EffectManager->DeactivateNiagaraSystem(NiagaraEffectID);
			NiagaraEffectID = 0;
		}
		else
		{
			UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialPhantom::OnTaskDeactivated: EffectManager is invalid, %s"), *GetDebugInfo());
		}
	}
	
	KGPPMaterialBase::OnTaskDeactivated();
}

void KGPPMaterialPhantom::OnPostProcessQualityChanged(EKGPostProcessQuality NewQuality)
{
	RefreshEffect(NewQuality);
}

bool KGPPMaterialPhantom::CanOutputPostProcess() const
{
	return bEnablePostProcess && KGPPMaterialBase::CanOutputPostProcess();
}

FString KGPPMaterialPhantom::GetDebugInfo() const
{
	if (bEnablePostProcess)
	{
		return KGPPMaterialBase::GetDebugInfo();
	}

	return FString::Printf(TEXT("[Phantom] %d, %s, %f, %f"), PostProcessID, *NiagaraPath, AccumulateLifeTimeSeconds, TotalLifeTimeSeconds);
}

void KGPPMaterialPhantom::RefreshEffect(EKGPostProcessQuality CurrentQuality)
{
	if (PostProcessManager.IsValid())
	{
		const auto bNewEnablePostProcess = UsePostProcess(CurrentQuality);
		const bool bNewEnableNiagara = !bNewEnablePostProcess;
		UE_LOG(LogKGPP, Log, TEXT("KGPPMaterialPhantom::RefreshEffect: %s, %d %d"), *GetDebugInfo(), bNewEnablePostProcess, bEnablePostProcess);
		
		UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(PostProcessManager.Get());
		if (!EffectManager)
		{
			UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialPhantom::RefreshEffect: EffectManager is invalid, %s"), *GetDebugInfo());
			return;
		}
		
		if (bNewEnableNiagara && bNewEnableNiagara != bEnableNiagara)
		{
			if (!AttachActor.IsValid())
			{
				UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialPhantom::RefreshEffect: AttachActor is invalid, %s"), *GetDebugInfo());
				return;
			}
			
			if (!AttachComponent.IsValid())
            {
            	UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialPhantom::RefreshEffect: AttachComponent is invalid, %s"), *GetDebugInfo());
            	return;
            }
			
			FKGPlayNiagaraParams PlayNiagaraParams;
			FKGAttachedNiagaraSpawnInfo SpawnInfo;
			SpawnInfo.AttachPointName = AttachSocketName;
			SpawnInfo.SearchAttachComponentType = EKGNiagaraSearchAttachComponentType::UseCustomAttachComponent;
			SpawnInfo.CustomAttachComponent = AttachComponent;
			PlayNiagaraParams.SetAttachedSpawnInfo(SpawnInfo);
			PlayNiagaraParams.NiagaraEffectPath = NiagaraPath;
			PlayNiagaraParams.SpawnerID = KGUtils::GetIDByObject(AttachActor.Get());
				
			NiagaraEffectID = EffectManager->CreateNiagaraSystem(PlayNiagaraParams);
			
			RevertEntityCustomDepth(CustomDepthEntityID);
		}
		else if (bNewEnablePostProcess && bNewEnablePostProcess != bEnablePostProcess)
		{
			if (NiagaraEffectID != 0)
			{
				EffectManager->DeactivateNiagaraSystem(NiagaraEffectID);
                NiagaraEffectID = 0;
			}
			
			SetEntityCustomDepth(CustomDepthEntityID, CustomDepthLogicType, CustomDepthPriority, true, CustomDepthStencilValue, false);
		}

		bEnableNiagara = bNewEnableNiagara;
		bEnablePostProcess = bNewEnablePostProcess;
	}
	else
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialPhantom::RefreshEffect: PostProcessManager is invalid, %s"), *GetDebugInfo());
	}
}
