#include "3C/Camera/PostProcessNew/PostProcessInstance/PPMaterialFog.h"

#include "3C/Camera/PostProcessNew/PostProcessManager.h"
#include "TimerManager.h"
#include "C7/WorldWidget2/WorldWidgetManager2.h"

void KGPPMaterialFog::InitParams(const FKGPPCommonParams& CommonParams,
	EKGPostProcessType InPPType, const FString& InMaterialPath, const FString& InPlaneMeshMaterialPath, int32 InViewPriority,
	const FName& InIntensityParamName, const FKGPPMaterialParams& InParams, TWeakObjectPtr<UPostProcessManager> InPPManager,
	bool bInOverrideClimate, int32 InOverrideClimateID, float InFogDistanceInMeters, float InHeadInfoHiddenDist, float InBlendTimeSeconds)
{
	KGPPMaterialBase::InitParams(CommonParams, InPPType, InMaterialPath, InPlaneMeshMaterialPath, InViewPriority, InIntensityParamName, InParams, InPPManager);
	bOverrideClimate = bInOverrideClimate;
	OverrideClimateID = InOverrideClimateID;
	FogDistanceInMeters = InFogDistanceInMeters;
	HeadInfoHiddenDistInMeters = InHeadInfoHiddenDist;
	BlendTimeSeconds = InBlendTimeSeconds;
}

void KGPPMaterialFog::OnTaskEnd(EKGPostProcessStopReason StopReason)
{
	if (PostProcessManager.IsValid())
	{
		if (UWorld* World = PostProcessManager->GetWorld())
		{
			World->GetTimerManager().ClearTimer(OpacityReachZeroTimerHandle);
		}
		else
		{
			UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialFog::OnTaskEnd: PostProcessManager's world is invalid, cannot clear OpacityReachZeroTimerHandle, %s"), *GetDebugInfo());
		}
	}
	else
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialFog::OnTaskEnd: PostProcessManager is invalid, cannot clear OpacityReachZeroTimerHandle, %s"), *GetDebugInfo());
	}
	
	KGPPMaterialBase::OnTaskEnd(StopReason);
}

void KGPPMaterialFog::OnTaskActivated()
{
	KGPPMaterialBase::OnTaskActivated();

	if (HeadInfoHiddenDistInMeters > 0.0f)
	{
		if (UWorldWidgetManager2* WorldWidgetManager = UWorldWidgetManager2::GetInstance(PostProcessManager.Get()))
		{
			WorldWidgetManager->SetFogShowDistance(HeadInfoHiddenDistInMeters * 100.0f);
		}	
	}

	if (bOverrideClimate && PostProcessManager.IsValid())
	{
		PostProcessManager->KCB_ChangeClimate(OverrideClimateID);
	}
}

void KGPPMaterialFog::OnTaskDeactivated()
{
	if (UWorldWidgetManager2* WorldWidgetManager = UWorldWidgetManager2::GetInstance(PostProcessManager.Get()))
	{
		WorldWidgetManager->SetFogShowDistance(-1);
	}

	if (bOverrideClimate && PostProcessManager.IsValid())
	{
		PostProcessManager->KCB_ResetCurrentClimate();
	}
	
	KGPPMaterialBase::OnTaskDeactivated();
}

void KGPPMaterialFog::UpdateFogDistance(const FName& FogDistanceParamName, float InFogDistance, float InHeadInfoHiddenDist, bool bOverrideBlendTime, float NewBlendTime)
{
	InternalUpdateFogDistance(FogDistanceParamName, InFogDistance, InHeadInfoHiddenDist, bOverrideBlendTime, NewBlendTime);
}

void KGPPMaterialFog::UpdateFogOpacity(const FName& FogOpacityParamName, float TargetFogOpacity, float NewDuration)
{
	if (FMath::IsNearlyZero(NewDuration))
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialFog::UpdateFogOpacity: Blend time is nearly zero, %s"), *GetDebugInfo());
		return;
	}
	
	UpdateScalarLinearSampleParamTargetValue(FogOpacityParamName, TargetFogOpacity, true, NewDuration);
	
	if (PostProcessManager.IsValid())
	{
		if (UWorld* World = PostProcessManager->GetWorld())
		{
			World->GetTimerManager().ClearTimer(OpacityReachZeroTimerHandle);

			if (FMath::IsNearlyZero(TargetFogOpacity))
			{
				World->GetTimerManager().SetTimer(OpacityReachZeroTimerHandle, FTimerDelegate::CreateRaw(
					this, &KGPPMaterialFog::OnOpacityReachZero), NewDuration, false);
				UE_LOG(LogKGPP, Log, TEXT("KGPPMaterialFog::UpdateFogOpacity: Opacity will reach zero in %f seconds, %s"), NewDuration, *GetDebugInfo());
			}
		}
	}
}

void KGPPMaterialFog::UpdateFogParams(
	float HeadInfoHideDistInMeters, bool bInOverrideClimate, int32 InOverrideClimateID, float InBlendTimeSeconds,
	const FName& FogOpacityParamName, float FogOpacityTargetVal,
	const FName& MaxDistParamName, float MaxDistInMetersTargetVal,
	const FName& FogColorParamName, float FogColorR, float FogColorG, float FogColorB, float FogColorA,
	const FName& SmoothDistParamName, float SmoothDistInMetersTargetVal)
{
	if (FMath::IsNearlyZero(InBlendTimeSeconds))
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialFog::UpdateFogParams: Blend time is nearly zero, %s"), *GetDebugInfo());
		return;
	}

	BlendOutTime = InBlendTimeSeconds;
	
	UpdateFogDistance(MaxDistParamName, MaxDistInMetersTargetVal, HeadInfoHideDistInMeters, true, InBlendTimeSeconds);
	UpdateFogOpacity(FogOpacityParamName, FogOpacityTargetVal, InBlendTimeSeconds);

	UpdateScalarLinearSampleParamTargetValue(SmoothDistParamName, SmoothDistInMetersTargetVal, true, InBlendTimeSeconds);
	
	FLinearColor Color(FogColorR, FogColorG, FogColorB, FogColorA);
	check(!FVector4(Color).ContainsNaN());
	UpdateVectorParam(FogColorParamName, Color);

	bOverrideClimate = bInOverrideClimate;
	OverrideClimateID = InOverrideClimateID;
	if (IsActivated() && bOverrideClimate && PostProcessManager.IsValid())
	{
		PostProcessManager->KCB_ChangeClimate(OverrideClimateID);
	}
}

void KGPPMaterialFog::InternalUpdateFogDistance(const FName& FogDistanceParamName, float InFogDistance, float InHeadInfoHiddenDist, bool bOverrideBlendTime, float NewBlendTime)
{
	const float Duration = bOverrideBlendTime ? NewBlendTime : BlendTimeSeconds;
	if (FMath::IsNearlyZero(Duration))
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialFog::InternalUpdateFogDistance: Blend time is nearly zero, %s"), *GetDebugInfo());
		return;
	}
	
	UpdateScalarLinearSampleParamTargetValue(FogDistanceParamName, InFogDistance, bOverrideBlendTime, NewBlendTime);

	FogDistanceInMeters = InFogDistance;
	HeadInfoHiddenDistInMeters = InHeadInfoHiddenDist;
	
	if (IsActivated() && HeadInfoHiddenDistInMeters > 0.0f)
	{
		if (UWorldWidgetManager2* WorldWidgetManager = UWorldWidgetManager2::GetInstance(PostProcessManager.Get()))
		{
			WorldWidgetManager->SetFogShowDistance(HeadInfoHiddenDistInMeters * 100.0f);
		}
	}
}

void KGPPMaterialFog::OnOpacityReachZero()
{
	UE_LOG(LogKGPP, Log, TEXT("KGPPMaterialFog::OnOpacityReachZero: Opacity reached zero, %s"), *GetDebugInfo());
	if (PostProcessManager.IsValid())
	{
		PostProcessManager->StopPostProcess(GetPostProcessID(), EKGPostProcessStopReason::LifeTimeEnd);
	}
}

