#include "3C/Camera/PostProcessNew/PostProcessInstance/PPMaterialClip.h"

#include "3C/Camera/CameraManager.h"
#include "3C/Material/KGMaterialCommon.h"
#include "3C/Camera/PostProcessNew/PostProcessManager.h"
#include "Kismet/GameplayStatics.h"

void KGPPMaterialClip::OnTaskActivated()
{
	KGPPMaterialBase::OnTaskActivated();

	if (ACameraManager* CameraManager = Cast<ACameraManager>(UGameplayStatics::GetPlayerCameraManager(PostProcessManager.Get(), 0)))
	{
		CameraManager->KAPI_Camera_EnableCameraDitherFade(static_cast<int>(EKGCameraDitherModifyReason::ClipPP), true);
	}
	else
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialClip::OnTaskEnd, invalid camera manager"));
	}
}

void KGPPMaterialClip::OnTaskDeactivated()
{
	if (ACameraManager* CameraManager = Cast<ACameraManager>(UGameplayStatics::GetPlayerCameraManager(PostProcessManager.Get(), 0)))
	{
		CameraManager->KAPI_Camera_EnableCameraDitherFade(static_cast<int>(EKGCameraDitherModifyReason::ClipPP), true);
	}
	else
	{
		// 退出游戏时没有CameraManager是合理的
		UE_LOG(LogKGPP, Log, TEXT("KGPPMaterialClip::OnTaskEnd, invalid camera manager"));
	}
	
	KGPPMaterialBase::OnTaskDeactivated();
}
