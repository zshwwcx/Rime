#include "3C/Camera/PostProcessNew/PostProcessInstance/PPPlaneMeshHandler.h"

#include "3C/Camera/PostProcessNew/PostProcessManager.h"
#include "3C/Camera/PostProcessNew/PPCommon.h"
#include "Components/StaticMeshComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Camera/PlayerCameraManager.h"
#include "Materials/MaterialInstanceDynamic.h"

bool KGPPPlaneMeshHandlerCameraManager::InitPlaneMeshHandler(TWeakObjectPtr<UPostProcessManager> PostProcessManager, UMaterialInstanceDynamic* PPMaterial, float PlaneMeshDistance)
{
	CachedCameraManager = UGameplayStatics::GetPlayerCameraManager(PostProcessManager.Get(), 0);
	if (!CachedCameraManager.IsValid())
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPPlaneMeshHandlerCameraManager::InitPlaneMeshHandler: CameraManager is null"));
		return false;
	}

	if (!PPMaterial || !PostProcessManager.IsValid())
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPPlaneMeshHandlerCameraManager::InitPlaneMeshHandler: invalid PPMaterial or PostProcessManager"));
		return false;
	}

	UStaticMesh* PlaneMesh = PostProcessManager->GetPlaneMeshAsset();
	if (PlaneMesh == nullptr)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPPlaneMeshHandlerCameraManager::InitPlaneMeshHandler: PlaneMesh is null"));
		return false;
	}
	
	if (!CachedCameraManager.IsValid())
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPPlaneMeshHandlerCameraManager::InitPlaneMeshHandler, invalid PlayerCameraManager"));
		return false;
	}

	USceneComponent* RootComponent = CachedCameraManager->GetRootComponent();
	if (!RootComponent)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPPlaneMeshHandlerCameraManager::InitPlaneMeshHandler, invalid camera manager RootComponent"));
		return false;
	}
	
	UStaticMeshComponent* NewPlaneMeshComponent = NewObject<UStaticMeshComponent>(CachedCameraManager.Get(), UStaticMeshComponent::StaticClass());
	if (NewPlaneMeshComponent == nullptr)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPPlaneMeshHandlerCameraManager::InitPlaneMeshHandler: Failed to create new plane mesh component"));
		return false;
	}

	// 后处理面片会以组件的形式挂接在camera manager上, 为了避免面片看不见, 需要设置camera manager可见
	if (CachedCameraManager->IsHidden())
	{
		CachedCameraManager->SetHidden(false);	
	}
	
	NewPlaneMeshComponent->RegisterComponent();
	NewPlaneMeshComponent->SetStaticMesh(PlaneMesh);
	NewPlaneMeshComponent->SetRelativeLocation(FVector(PlaneMeshDistance, 0.0f, 0.0f));
	NewPlaneMeshComponent->SetRelativeRotation(PostProcessManager->GetPlaneMeshRotation());
	InitMeshComponentScale = PostProcessManager->GetPlaneMeshScale();
	NewPlaneMeshComponent->SetRelativeScale3D(InitMeshComponentScale);
	NewPlaneMeshComponent->SetMaterial(0, PPMaterial);
	NewPlaneMeshComponent->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	ULowLevelFunctions::EnableOverlapOptimization(NewPlaneMeshComponent, true);
	NewPlaneMeshComponent->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);
#if WITH_EDITOR
	CachedCameraManager->AddInstanceComponent(NewPlaneMeshComponent);
#endif
	PlaneMeshComponent = TStrongObjectPtr(NewPlaneMeshComponent);
	return true;
}

void KGPPPlaneMeshHandlerCameraManager::DestroyPlaneMeshHandler()
{
	if (PlaneMeshComponent.IsValid())
	{
		PlaneMeshComponent->DestroyComponent();
		PlaneMeshComponent.Reset();
	}
}

void KGPPPlaneMeshHandlerCameraManager::UpdatePlaneMeshOnPPInstanceUpdate()
{
	if (PlaneMeshComponent.IsValid() && CachedCameraManager.IsValid())
	{
		float FOV = CachedCameraManager->GetFOVAngle();
		if (CacheCameraFOV <= 0.0f || !FMath::IsNearlyEqual(CacheCameraFOV, FOV))
		{
			CacheCameraFOV = FOV;
			const float HalfAngle = FMath::DegreesToRadians(FOV * 0.5f);
			const float Scale = FMath::Tan(HalfAngle);
			PlaneMeshComponent->SetRelativeScale3D(FVector(InitMeshComponentScale.X * Scale, InitMeshComponentScale.Y * Scale, InitMeshComponentScale.Z));
		}
	}
}

bool KGPPPlaneMeshHandlerViewport::InitPlaneMeshHandler(TWeakObjectPtr<UPostProcessManager> PostProcessManager, UMaterialInstanceDynamic* PPMaterial, float InPlaneMeshDistance)
{
	if (!PPMaterial || !PostProcessManager.IsValid())
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPPlaneMeshHandlerViewport::InitPlaneMeshHandler: invalid PPMaterial or PostProcessManager"));
		return false;
	}

	UStaticMesh* PlaneMesh = PostProcessManager->GetPlaneMeshAsset();
	if (PlaneMesh == nullptr)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPPlaneMeshHandlerViewport::InitPlaneMeshHandler: PlaneMesh is null"));
		return false;
	}

	UWorld* World = PostProcessManager->GetWorld();
	if (!World)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPPlaneMeshHandlerViewport::InitPlaneMeshHandler: World is null"));
		return false;
	}
		
	PlaneMeshActor = World->SpawnActor(AKGPlaneMeshActor::StaticClass());
	if (!PlaneMeshActor.IsValid())
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPPlaneMeshHandlerViewport::InitPlaneMeshHandler: spawn actor failed"));
		return false;
	}

	UStaticMeshComponent* NewPlaneMeshComponent = Cast<UStaticMeshComponent>(
		PlaneMeshActor->AddComponentByClass(UStaticMeshComponent::StaticClass(), false, FTransform::Identity, false));
	if (NewPlaneMeshComponent == nullptr)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPPlaneMeshHandlerViewport::InitPlaneMeshHandler: Failed to create new plane mesh component"));
		return false;
	}

	RelativeTransform.SetLocation(FVector(InPlaneMeshDistance, 0.0f, 0.0f));
	RelativeTransform.SetRotation(PostProcessManager->GetPlaneMeshRotation().Quaternion());
	InitMeshComponentScale = PostProcessManager->GetPlaneMeshScale();
	RelativeTransform.SetScale3D(InitMeshComponentScale);
	
	NewPlaneMeshComponent->RegisterComponent();
	NewPlaneMeshComponent->SetStaticMesh(PlaneMesh);
	NewPlaneMeshComponent->SetMaterial(0, PPMaterial);
	NewPlaneMeshComponent->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	ULowLevelFunctions::EnableOverlapOptimization(NewPlaneMeshComponent, true);
#if WITH_EDITOR
	PlaneMeshActor->AddInstanceComponent(NewPlaneMeshComponent);
#endif
	PlaneMeshComponent = TStrongObjectPtr(NewPlaneMeshComponent);
	return true;
}

void KGPPPlaneMeshHandlerViewport::DestroyPlaneMeshHandler()
{
	if (PlaneMeshActor.IsValid())
	{
		PlaneMeshActor->Destroy();
	}
}

void KGPPPlaneMeshHandlerViewport::UpdatePlaneMeshOnViewportUpdate(const FVector& Pos, const FRotator& Rot, float NewFOV)
{
	if (PlaneMeshActor.IsValid())
	{
		FTransform ViewportTrans = FTransform(Rot, Pos, FVector::OneVector);
		if (CacheCameraFOV <= 0.0f || !FMath::IsNearlyEqual(CacheCameraFOV, NewFOV))
		{
			CacheCameraFOV = NewFOV;
			const float HalfAngle = FMath::DegreesToRadians(NewFOV * 0.5f);
			const float Scale = FMath::Tan(HalfAngle);
			RelativeTransform.SetScale3D(InitMeshComponentScale * FVector(Scale, Scale, 1.0f));
		}
		
		PlaneMeshActor->SetActorTransform(RelativeTransform * ViewportTrans);
	}
}
