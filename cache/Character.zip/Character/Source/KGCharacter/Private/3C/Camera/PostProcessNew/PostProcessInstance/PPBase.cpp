#include "3C/Camera/PostProcessNew/PostProcessInstance/PPBase.h"
#include "3C/Core/KGUEActorManager.h"
#include "3C/Camera/PostProcessNew/PostProcessManager.h"

void FKGPPBlendWeightCalculator::StartBlendIn(float BlendInTime)
{
	bBlendActive = true;
	AccumulatedTime = 0.0f;
	TargetBlendWeight = KG_PP_INTENSITY_MAX;
	StartBlendWeight = CurrentBlendWeight;
	BlendTime = BlendInTime * FMath::Abs(KG_PP_INTENSITY_MAX - CurrentBlendWeight);
}

void FKGPPBlendWeightCalculator::StartBlendOut(float BlendOutTime)
{
	bBlendActive = true;
	AccumulatedTime = 0.0f;
	BlendTime = BlendOutTime * FMath::Abs(CurrentBlendWeight - KG_PP_INTENSITY_MIN);
	TargetBlendWeight = KG_PP_INTENSITY_MIN;
	StartBlendWeight = CurrentBlendWeight;
}

void FKGPPBlendWeightCalculator::Tick(float DeltaTime)
{
	if (bBlendActive)
	{
		if (BlendTime > KINDA_SMALL_NUMBER)
		{
			AccumulatedTime += DeltaTime;
			float BlendScale = FMath::Clamp(AccumulatedTime / BlendTime, 0.0, 1.0);
			CurrentBlendWeight = FMath::Clamp(StartBlendWeight + (TargetBlendWeight - StartBlendWeight) * BlendScale, KG_PP_INTENSITY_MIN, KG_PP_INTENSITY_MAX);
			if (AccumulatedTime >= BlendTime)
			{
				bBlendActive = false;
			}
		}
		else
		{
			CurrentBlendWeight = TargetBlendWeight;
			bBlendActive = false;
		}
	}
}

KGPPBase::KGPPBase()
{
	const uint32 PPID = KGPPUtils::GeneratePPID();
	PostProcessID = PPID;
	SequenceID = PPID;
}

void KGPPBase::InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager)
{
	Priority = CommonParams.Priority; 
	TotalLifeTimeSeconds = CommonParams.TotalLifeTimeSeconds; 
	bDestroyWhenLeaveSpace = CommonParams.bDestroyWhenLeaveSpace; 
	SourceType = CommonParams.SourceType; 
	BlendInTime = CommonParams.BlendInTime; 
	BlendOutTime = CommonParams.BlendOutTime; 
	PostProcessManager = InPPManager; 
	
	if (CommonParams.bUsePPTag)
	{
		PPTags.Add(CommonParams.PPTag);
	}
}

bool KGPPBase::StartBlendInPP(bool bOverrideBlendInTime, float NewBlendInTime, EKGPostProcessBlendReason InBlendReason)
{
	UE_LOG(LogKGPP, Log, TEXT("KGPPBase::StartBlendInPP, %s, %d, %f, %d"), *GetDebugInfo(), bOverrideBlendInTime, NewBlendInTime, InBlendReason);
	
	if (CurrentBlendReason > InBlendReason)
	{
		UE_LOG(LogKGPP, Log,
			TEXT("KGPPBase::StartBlendInPP, cannot use %d blend out when current blend %d is active, %s"),
			InBlendReason, CurrentBlendReason, *GetDebugInfo());
		return false;
	}

	if (!CanUseCommonBlend())
	{
		UE_LOG(LogKGPP, Log, TEXT("KGPPBase::StartBlendInPP, cannot use common blend, %s"), *GetDebugInfo());
		return false;
	}
	
	if (InBlendReason == EKGPostProcessBlendReason::TaskActivationStateChange && !CanActivateMultiPPInstance())
	{
		UE_LOG(LogKGPP, Log,
			TEXT("KGPPBase::StartBlendInPP, cannot blend out on task activation state changed, %s"),
			*GetDebugInfo());
		SetCurrentBlendWeight(KG_PP_INTENSITY_MAX);
		return false;
	}

	float BlendInTimeUsed = bOverrideBlendInTime ? NewBlendInTime : BlendInTime;
	if (BlendInTimeUsed < KINDA_SMALL_NUMBER)
	{
		SetCurrentBlendWeight(KG_PP_INTENSITY_MAX);
		return false;
	}
	
	BlendWeightCalculator.StartBlendIn(BlendInTimeUsed);
	CurrentBlendReason = InBlendReason;
	
	return true;
}

bool KGPPBase::StartBlendOutPP(bool bOverrideBlendOutTime, float NewBlendOutTime, EKGPostProcessBlendReason InBlendReason)
{
	UE_LOG(LogKGPP, Log, TEXT("KGPPBase::StartBlendOutPP, %s, %d, %f, %d"), *GetDebugInfo(), bOverrideBlendOutTime, NewBlendOutTime, InBlendReason);
	
	if (CurrentBlendReason > InBlendReason)
	{
		UE_LOG(LogKGPP, Log,
			TEXT("KGPPBase::StartBlendOutPP, cannot use %d blend out when current blend out %d is active, %s"),
			InBlendReason, CurrentBlendReason, *GetDebugInfo());
		return false;
	}

	if (!CanUseCommonBlend())
	{
		UE_LOG(LogKGPP, Log, TEXT("KGPPBase::StartBlendOutPP, cannot use common blend, %s"), *GetDebugInfo());
		return false;
	}
	
	const bool bCanActivateMultiPPInstance = CanActivateMultiPPInstance();
	const auto PPType = GetPPType();
	const auto PPInstanceNum = PostProcessManager.IsValid() ? PostProcessManager->GetPPNumByPPType(PPType) : 0;
	if (!bCanActivateMultiPPInstance)
	{
		if (InBlendReason == EKGPostProcessBlendReason::TaskActivationStateChange)
		{
			UE_LOG(LogKGPP, Log,
				TEXT("KGPPBase::StartBlendOutPP, cannot blend out on task activation state changed, %s"),
				*GetDebugInfo());
			SetCurrentBlendWeight(KG_PP_INTENSITY_MIN);
			return false;
		}

		if (InBlendReason == EKGPostProcessBlendReason::TaskInterrupted && PPInstanceNum > 1)
		{
			UE_LOG(LogKGPP, Log,
				TEXT("KGPPBase::StartBlendOutPP, cannot blend out on task interrupt with multiple pp instance, %s"),
				*GetDebugInfo());
			SetCurrentBlendWeight(KG_PP_INTENSITY_MIN);
			return false;
		}
	}

	float BlendOutTimeUsed = bOverrideBlendOutTime ? NewBlendOutTime : BlendOutTime;
	if (BlendOutTimeUsed < KINDA_SMALL_NUMBER)
	{
		SetCurrentBlendWeight(KG_PP_INTENSITY_MIN);
		return false;
	}
	
	BlendWeightCalculator.StartBlendOut(BlendOutTimeUsed);
	CurrentBlendReason = InBlendReason;

	if (InBlendReason == EKGPostProcessBlendReason::TaskInterrupted)
	{
		if (!bCanActivateMultiPPInstance && PPInstanceNum == 1)
		{
			PostProcessState = EKGPostProcessState::InterruptedBlendingOut_Activated;
		}
		else
		{
			PostProcessState = EKGPostProcessState::InterruptedBlendingOut_PendingDeactivated;
		}

		UE_LOG(LogKGPP, Log, TEXT("KGPPBase::StartBlendOutPP, interrupted blend out, set pp state %d, %s"), PostProcessState, *GetDebugInfo());
	}
	
	return true;
}

bool KGPPBase::DoTaskStart()
{
	if (PostProcessState != EKGPostProcessState::UnInitialized)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPBase::DoTaskStart: invalid PostProcessState %d, %s"), PostProcessState, *GetDebugInfo());
		return false;
	}

	return OnTaskStart();
}

void KGPPBase::DoTaskEnd(EKGPostProcessStopReason StopReason)
{
	if (PostProcessState == EKGPostProcessState::Ended || PostProcessState == EKGPostProcessState::UnInitialized)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPBase::DoTaskEnd: invalid PostProcessState %d, %s"), PostProcessState, *GetDebugInfo());
		return;
	}

	OnTaskEnd(StopReason);
}

void KGPPBase::DoTaskActivated()
{
	if (PostProcessState != EKGPostProcessState::Deactivated)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPBase::DoTaskActivated: invalid PostProcessState %d, %s"), PostProcessState, *GetDebugInfo());
		return;
	}

	OnTaskActivated();
}

void KGPPBase::DoTaskDeactivated()
{
	if (PostProcessState != EKGPostProcessState::Activated &&
		PostProcessState != EKGPostProcessState::InterruptedBlendingOut_Activated &&
		PostProcessState != EKGPostProcessState::InterruptedBlendingOut_ActivatedFinished &&
		PostProcessState != EKGPostProcessState::InterruptedBlendingOut_PendingDeactivated)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPBase::DoTaskDeactivated: invalid PostProcessState %d, %s"), PostProcessState, *GetDebugInfo());
		return;
	}

	OnTaskDeactivated();
}

void KGPPBase::DoTaskTick(float DeltaTime)
{
	if (PostProcessState == EKGPostProcessState::UnInitialized ||
		PostProcessState == EKGPostProcessState::Ended)
	{
		return;
	}
	
	OnTaskTick(DeltaTime);
}

void KGPPBase::AdvancePPTime(float DeltaTime)
{
	if (DeltaTime >= UE_KINDA_SMALL_NUMBER)
	{
		AccumulateLifeTimeSeconds += DeltaTime;	
	}
}

bool KGPPBase::OnTaskStart()
{
	UE_LOG(LogKGPP, Log, TEXT("KGPPBase::OnTaskStart, %s"), *GetDebugInfo());
	PostProcessState = EKGPostProcessState::Deactivated;
	PPStartFrame = GFrameCounter;
	return PostProcessManager.IsValid();
}

void KGPPBase::OnTaskEnd(EKGPostProcessStopReason StopReason)
{
	UE_LOG(LogKGPP, Log, TEXT("KGPPBase::OnTaskEnd, %s, StopReason: %d"), *GetDebugInfo(), StopReason);
	PostProcessState = EKGPostProcessState::Ended;
}

void KGPPBase::OnTaskActivated()
{
	PostProcessState = EKGPostProcessState::Activated;
	UE_LOG(LogKGPP, Log, TEXT("KGPPBase::OnTaskActivated, %s"), *GetDebugInfo());

	if (CustomDepthEntityIDs.Num() > 0)
	{
		// 清理所有CustomDepth
		for (const auto& Pair : CustomDepthEntityIDs)
		{
			const KGEntityID EntityID = Pair.Key;
			InternalSetCustomDepthInfo(EntityID);
		}
	}
	
	if (PPStartFrame == GFrameCounter)
	{
		StartBlendInPP(false, 0.0f, EKGPostProcessBlendReason::LifeTimeBlend);
	}
	else
	{
		StartBlendInPP(true, PostProcessManager->GetPPBlendOutTimeOnInterrupt(), EKGPostProcessBlendReason::TaskActivationStateChange);
	}
}

void KGPPBase::OnTaskDeactivated()
{
	if (PostProcessState == EKGPostProcessState::InterruptedBlendingOut_PendingDeactivated)
	{
		PostProcessState = EKGPostProcessState::InterruptedBlendingOut_Deactivated;
	}
	else
	{
		PostProcessState = EKGPostProcessState::Deactivated;
	}
	
	UE_LOG(LogKGPP, Log, TEXT("KGPPBase::OnTaskDeactivated, %s"), *GetDebugInfo());

	if (CustomDepthEntityIDs.Num() > 0)
	{
		// 清理所有CustomDepth
		for (const auto& Pair : CustomDepthEntityIDs)
		{
			const KGEntityID EntityID = Pair.Key;
			InternalRevertCustomDepthInfo(EntityID);
		}
	}

	if (PostProcessManager.IsValid())
	{
		StartBlendOutPP(true, PostProcessManager->GetPPBlendOutTimeOnInterrupt(), EKGPostProcessBlendReason::TaskActivationStateChange);
	}
}

void KGPPBase::OnTaskTick(float DeltaTime)
{
	// uninitialized 以及 disable状态下 OnTaskTick也会执行, 确保生命周期的累积不会因为后效被屏蔽而停止
	if (TotalLifeTimeSeconds > 0 && AccumulateLifeTimeSeconds < TotalLifeTimeSeconds)
	{
		AccumulateLifeTimeSeconds += DeltaTime;
		
		if (BlendOutTime > 0 &&
			AccumulateLifeTimeSeconds > (TotalLifeTimeSeconds - BlendOutTime) &&
			!BlendWeightCalculator.bBlendActive &&
			BlendWeightCalculator.CurrentBlendWeight > KINDA_SMALL_NUMBER)
		{
			const float BlendOutTImeLeft = FMath::Max(0.0f, TotalLifeTimeSeconds - AccumulateLifeTimeSeconds);
			const float BlendOutTimeUsed = FMath::Min(BlendOutTime, BlendOutTImeLeft);
			StartBlendOutPP(true, BlendOutTimeUsed, EKGPostProcessBlendReason::LifeTimeBlend);
		}
	}

	if (BlendWeightCalculator.bBlendActive)
	{
		BlendWeightCalculator.Tick(DeltaTime);
		OnBlendWeightChanged();
	}

	if (CurrentBlendReason != EKGPostProcessBlendReason::None && !IsBlendActive())
	{
		if (PostProcessState == EKGPostProcessState::InterruptedBlendingOut_Activated)
		{
			PostProcessState = EKGPostProcessState::InterruptedBlendingOut_ActivatedFinished;
		}
		else if (PostProcessState == EKGPostProcessState::InterruptedBlendingOut_Deactivated)
		{
			PostProcessState = EKGPostProcessState::InterruptedBlendingOut_DeactivatedFinished;
		}
		CurrentBlendReason = EKGPostProcessBlendReason::None;
		UE_LOG(LogKGPP, Log, TEXT("KGPPBase::OnBlendFinished, %s"), *GetDebugInfo());
	}
}

void KGPPBase::RegisterPostProcessQualityChangedDelegate()
{
	if (PostProcessManager.IsValid())
	{
		PostProcessManager->GetOnPostProcessQualityChanged().AddRaw(this, &KGPPBase::OnPostProcessQualityChanged);
	}
}

void KGPPBase::UnregisterPostProcessQualityChangedDelegate()
{
	if (PostProcessManager.IsValid())
	{
		PostProcessManager->GetOnPostProcessQualityChanged().RemoveAll(this);
	}
}

void KGPPBase::SetEntityCustomDepth(KGEntityID EntityID, int32 LogicType, int32 InPriority, bool bRenderCustomDepth, int32 CustomDepthStencilValue, bool bNiagaraRenderCustomDepth)
{
	UE_LOG(LogKGPP, Log, TEXT("KGPPBase::SetEntityCustomDepth, %lld, %d, %d, %d, %s"),
		EntityID, LogicType, bRenderCustomDepth, CustomDepthStencilValue, *GetDebugInfo());
	
	FKGPPCustomStencilInfo CustomDepthInfo(LogicType, InPriority, bRenderCustomDepth, CustomDepthStencilValue, bNiagaraRenderCustomDepth);
	CustomDepthEntityIDs.Add(EntityID, CustomDepthInfo);

	if (IsActivated())
	{
		InternalSetCustomDepthInfo(EntityID);
	}
}

void KGPPBase::RevertEntityCustomDepth(KGEntityID EntityID)
{
	UE_LOG(LogKGPP, Log, TEXT("KGPPBase::RevertEntityCustomDepth, %lld, %s"), EntityID, *GetDebugInfo());
	
	if (CustomDepthEntityIDs.Contains(EntityID))
	{
		if (IsActivated())
		{
			InternalRevertCustomDepthInfo(EntityID);
		}

		CustomDepthEntityIDs.Remove(EntityID);
	}
}

void KGPPBase::InternalSetCustomDepthInfo(KGEntityID EntityID)
{
	UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(PostProcessManager.Get());
	if (!ActorManager)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPBase::InternalSetCustomDepthInfo: ActorManager is invalid, %s"), *GetDebugInfo());
		return;
	}

	auto* CustomDepthInfoPtr = CustomDepthEntityIDs.Find(EntityID);
	if (CustomDepthInfoPtr == nullptr)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPBase::InternalSetCustomDepthInfo: CustomDepthInfoPtr is null, %s, %lld"), *GetDebugInfo(), EntityID);
		return;
	}
	
	if (auto* Entity = ActorManager->GetLuaEntity(EntityID))
	{
		Entity->OverrideCustomDepth(
			CustomDepthInfoPtr->LogicType, CustomDepthInfoPtr->Priority, CustomDepthInfoPtr->bRenderCustomDepth,
			CustomDepthInfoPtr->CustomDepthStencilValue, CustomDepthInfoPtr->bNiagaraRenderCustomDepth, false, 0.0f);
	}
	else
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPBase::InternalSetCustomDepthInfo: Entity is null, %s, %lld"), *GetDebugInfo(), EntityID);
	}
}

void KGPPBase::InternalRevertCustomDepthInfo(KGEntityID EntityID)
{
	UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(PostProcessManager.Get());
	if (!ActorManager)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPBase::InternalRevertCustomDepthInfo: ActorManager is invalid, %s"), *GetDebugInfo());
		return;
	}

	auto* CustomDepthInfoPtr = CustomDepthEntityIDs.Find(EntityID);
	if (CustomDepthInfoPtr == nullptr)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPBase::InternalRevertCustomDepthInfo: CustomDepthInfoPtr is null, %s, %lld"), *GetDebugInfo(), EntityID);
		return;
	}
	
	if (auto* Entity = ActorManager->GetLuaEntity(EntityID))
	{
		Entity->RevertCustomDepth(CustomDepthInfoPtr->LogicType);
	}
	else
	{
		// 后效切换场景时保底清理这里为空是合理的
		UE_LOG(LogKGPP, Log, TEXT("KGPPBase::InternalRevertCustomDepthInfo: Entity is null, %s, %lld"), *GetDebugInfo(), EntityID);
	}
}
