#include "3C/Camera/PostProcessNew/PostProcessInstance/PPNonMaterialBase.h"

#include "Manager/KGCppAssetManager.h"
#include "3C/Camera/PostProcessNew/PostProcessManager.h"
#include "Curves/CurveLinearColor.h"

FString KGPPNonMaterialBase::GetDebugInfo() const
{
	return FString::Printf(TEXT("[%s] ID[%d], w[%f], %f/%f"),
		PostProcessManager.IsValid() ? *PostProcessManager->GetPPTypeName(GetPPType()) : TEXT("[invalid]"),
		PostProcessID, GetCurrentBlendWeight(), AccumulateLifeTimeSeconds, TotalLifeTimeSeconds);
}

void KGPPNonMaterialBase::InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType,
	const FPostProcessSettings& InPostProcessSettings)
{
	KGPPBase::InitParams(CommonParams, InPPManager);
	PPType = InPPType;
	PostProcessSettings = InPostProcessSettings;
}

void KGPPNonMaterialBase::InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType)
{
	KGPPBase::InitParams(CommonParams, InPPManager);
	PPType = InPPType;
}

void KGPPNonMaterialBase::OnTaskEnd(EKGPostProcessStopReason StopReason)
{
	if (UKGCppAssetManager* CppAssetManager = UKGCppAssetManager::GetInstance(PostProcessManager.Get()))
	{
		for (const auto& Kvp : ManualWeightCurveInfos)
		{
			if (Kvp.Value.AssetLoadID != 0)
			{
				CppAssetManager->CancelAsyncLoadByLoadID(Kvp.Value.AssetLoadID);
			}
		}
	}
	else
	{
		UE_LOG(LogKGPP, Log, TEXT("KGPPNonMaterialBase::OnTaskEnd failed, invalid CppAssetManager"));
	}
	
	KGPPBase::OnTaskEnd(StopReason);
}

bool KGPPNonMaterialBase::GetPostProcessResult(FPostProcessSettings& OutPPSettings, float& OutPPBlendWeight, EViewTargetBlendOrder& OutPPBlendOrder) const
{
	if (CanOutputPostProcess())
	{
		OutPPSettings = PostProcessSettings;
		OutPPBlendWeight = GetCurrentBlendWeight();
		OutPPBlendOrder = VTBlendOrder_Base;
		return true;
	}
	
	return false;
}

float KGPPNonMaterialBase::GetCurrentBlendWeight() const
{
	if (ManualBlendWeight.IsSet())
	{
		return ManualBlendWeight.GetValue();
	}

#if WITH_EDITOR
	const float ForcePPBlendWeight = CVarForcePPBlendWeight.GetValueOnGameThread();
	if (ForcePPBlendWeight >= 0.0f)
	{
		return ForcePPBlendWeight;
	}
#endif
	
	return BlendWeightCalculator.CurrentBlendWeight;
}

uint32 KGPPNonMaterialBase::RegisterManualWeightCurve(const FString& CurvePath, EKGManualWeightCurveType CurveType)
{
	if (CurvePath.IsEmpty())
	{
		UE_LOG(LogKGPP, Warning, TEXT("KGPPNonMaterialBase::RegisterFloatManualWeightCurve failed, invalid CurvePath"));
		return 0;
	}

	UKGCppAssetManager* CppAssetManager = UKGCppAssetManager::GetInstance(PostProcessManager.Get());
	if (!CppAssetManager)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPNonMaterialBase::RegisterFloatManualWeightCurve failed, invalid CppAssetManager"));
		return 0;
	}
	
	const int32 AssetLoadID = CppAssetManager->AsyncLoadAsset(
		CurvePath, FAsyncLoadCompleteDelegate::CreateRaw(this, &KGPPNonMaterialBase::OnManualWeightCurveLoaded));
	auto& ManualWeightCurveInfo = ManualWeightCurveInfos.Add(AssetLoadID);
	ManualWeightCurveInfo.CurvePath = CurvePath;
	ManualWeightCurveInfo.AssetLoadID = AssetLoadID;
	ManualWeightCurveInfo.CurveType = CurveType;
	return AssetLoadID;
}

bool KGPPNonMaterialBase::GetFloatCurveValue(int32 CurveParamID, float& OutValue)
{
	FKGManualWeightCurveInfo* CurveInfoPtr = ManualWeightCurveInfos.Find(CurveParamID);
	if (!CurveInfoPtr)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPNonMaterialBase::GetFloatCurveValue failed, invalid CurveParamID %d"), CurveParamID);
		return false;
	}

	UCurveFloat* Curve = Cast<UCurveFloat>(CurveInfoPtr->CurveInfo.Get());
	if (!Curve)
	{
		// 正在加载中
		return false;
	}

	OutValue = Curve->GetFloatValue(CurManualWeight);
	return true;
}

bool KGPPNonMaterialBase::GetLinearColorCurveValue(int32 CurveParamID, FLinearColor& OutValue)
{
	FKGManualWeightCurveInfo* CurveInfoPtr = ManualWeightCurveInfos.Find(CurveParamID);
	if (!CurveInfoPtr)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPNonMaterialBase::GetLinearColorCurveValue failed, invalid CurveParamID %d"), CurveParamID);
		return false;
	}

	UCurveLinearColor* Curve = Cast<UCurveLinearColor>(CurveInfoPtr->CurveInfo.Get());
	if (!Curve)
	{
		// 正在加载中
		return false;
	}

	OutValue = Curve->GetLinearColorValue(CurManualWeight);
	return true;
}

void KGPPNonMaterialBase::OnManualWeightCurveLoaded(int InLoadID, UObject* Asset)
{
	FKGManualWeightCurveInfo* CurveInfoPtr = ManualWeightCurveInfos.Find(InLoadID);
	if (!CurveInfoPtr)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPNonMaterialBase::OnManualWeightCurveLoaded failed, invalid LoadID %d"), InLoadID);
		return;
	}

	CurveInfoPtr->AssetLoadID = 0;
	
	if (CurveInfoPtr->CurveType == EKGManualWeightCurveType::FloatCurve)
	{
		UCurveFloat* Curve = Cast<UCurveFloat>(Asset);
		if (!Curve)
		{
			UE_LOG(LogKGPP, Error, TEXT("KGPPNonMaterialBase::OnManualWeightCurveLoaded failed, invalid Asset, LoadID %d, %s"),
				InLoadID, *CurveInfoPtr->CurvePath);
			return;
		}
		CurveInfoPtr->CurveInfo = TStrongObjectPtr(Curve);
	}
	else if (CurveInfoPtr->CurveType == EKGManualWeightCurveType::ColorCurve)
	{
		UCurveLinearColor* Curve = Cast<UCurveLinearColor>(Asset);
		if (!Curve)
		{
			UE_LOG(LogKGPP, Error, TEXT("KGPPNonMaterialBase::OnManualWeightCurveLoaded failed, invalid Asset, LoadID %d, %s"),
				InLoadID, *CurveInfoPtr->CurvePath);
			return;
		}
		CurveInfoPtr->CurveInfo = TStrongObjectPtr(Curve);
	}
	else
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPNonMaterialBase::OnManualWeightCurveLoaded failed, invalid CurveType, LoadID %d, %s"),
			InLoadID, *CurveInfoPtr->CurvePath);
		return;
	}
	
	// 刷新一次当前参数
	SetManualWeightCurveValue(CurManualWeight);
}
