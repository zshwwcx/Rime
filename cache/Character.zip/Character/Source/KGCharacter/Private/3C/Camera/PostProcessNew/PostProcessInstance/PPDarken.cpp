#include "3C/Camera/PostProcessNew/PostProcessInstance/PPDarken.h"

#include "3C/Light/CharacterLightManager.h"
#include "3C/Camera/PostProcessNew/PostProcessManager.h"

void KGPPDarken::InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType,
	const FPostProcessSettings& InPostProcessSettings, float InBaseExposureBias)
{
	KGPPNonMaterialBase::InitParams(CommonParams, InPPManager, InPPType, InPostProcessSettings);
	BaseExposureBias = InBaseExposureBias;
}

void KGPPDarken::OnTaskActivated()
{
	KGPPNonMaterialBase::OnTaskActivated();

	if (UCharacterLightManager* CharacterLightManager = UCharacterLightManager::GetInstance(PostProcessManager.Get()))
	{
		if (PostProcessSettings.bOverride_AdditionalAutoExposureBias)
		{
			CharacterLightManager->StartExposureBlend(PostProcessSettings.AdditionalAutoExposureBias + BaseExposureBias, BlendInTime);
		}
		else if (PostProcessSettings.bOverride_AutoExposureBias)
		{
			CharacterLightManager->StartExposureBlend(PostProcessSettings.AutoExposureBias, BlendInTime);
		}
	}
	else
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPDarken::OnTaskActivated: CharacterLightManager is null"));
	}
}

void KGPPDarken::OnTaskDeactivated()
{
	if (UCharacterLightManager* CharacterLightManager = UCharacterLightManager::GetInstance(PostProcessManager.Get()))
	{
		CharacterLightManager->StartExposureBlend(BaseExposureBias, BlendOutTime);
	}
	else
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPDarken::OnTaskDeactivated: CharacterLightManager is null"));
	}
	
	KGPPNonMaterialBase::OnTaskDeactivated();
}

FString KGPPDarken::GetDebugInfo() const
{
	return FString::Printf(TEXT("[KGPPDarken] ID[%d], w[%f], ExposureBias[%f(%d)], %f/%f"),
		PostProcessID, GetCurrentBlendWeight(),
		PostProcessSettings.bOverride_AdditionalAutoExposureBias ? PostProcessSettings.AdditionalAutoExposureBias : PostProcessSettings.AutoExposureBias,
		PostProcessSettings.bOverride_AdditionalAutoExposureBias,
		AccumulateLifeTimeSeconds, TotalLifeTimeSeconds);
}
