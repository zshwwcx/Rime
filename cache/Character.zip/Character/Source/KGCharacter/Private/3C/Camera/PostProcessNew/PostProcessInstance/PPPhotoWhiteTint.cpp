﻿#include "3C/Camera/PostProcessNew/PostProcessInstance/PPPhotoWhiteTint.h"

#include "Util/ColorConstants.h"

void KGPPPhotoWhiteTint::InitParams(
	const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType, const FString& InWhiteTintCurvePath)
{
	KGPPNonMaterialBase::InitParams(CommonParams, InPPManager, InPPType);
	WhiteTintID = RegisterManualWeightCurve(InWhiteTintCurvePath, EKGManualWeightCurveType::FloatCurve);
}

void KGPPPhotoWhiteTint::SetManualWeightCurveValue(float Weight)
{
	KGPPNonMaterialBase::SetManualWeightCurveValue(Weight);
	KG_PP_SET_FLOAT_CURVE_PARAM(WhiteTint);
}
