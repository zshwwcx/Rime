﻿#include "3C/Camera/PostProcessNew/PostProcessInstance/PPMaterialBlackFog.h"

#include "TimerManager.h"
#include "C7/WorldWidget2/WorldWidgetManager2.h"
#include "3C/Camera/PostProcessNew/PostProcessManager.h"

void KGPPMaterialBlackFog::InitParams(const FKGPPCommonParams& CommonParams, EKGPostProcessType InPPType, const FString& InMaterialPath, 
	const FString& InPlaneMeshMaterialPath, int32 InViewPriority, const FName& InIntensityParamName, const FKGPPMaterialParams& InParams, 
	TWeakObjectPtr<UPostProcessManager> InPPManager, const FKGFogParams& InFogParams)
{
	KGPPMaterialBase::InitParams(CommonParams, InPPType, InMaterialPath, InPlaneMeshMaterialPath,
		InViewPriority, InIntensityParamName, InParams, InPPManager);
	
	FogParams = InFogParams;
}

void KGPPMaterialBlackFog::UpdateBlackFogParams(
	float BlendTime, bool bOverrideCenterPos, const FVector& CenterPos, 
	bool bOverrideFogOpacity, float FogOpacity, bool bOverrideFogColor, const FLinearColor& FogColor,
	bool bOverrideSmoothDist, float SmoothDistInMeters, EKGFogShapeType ShapeType, float CircleRadius, float RingPercent, float RingOuterRadius,
	float CrossLength, float CrossWidth, float HalfFieldWidth, bool bOverrideRangeSpawnRotation, float RangeSpawnRotation)
{
	if (FMath::IsNearlyZero(BlendTime))
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialFog::UpdateBlackFogParams: Blend time is nearly zero, %s"), *GetDebugInfo());
		return;
	}
	
	UWorld* World = PostProcessManager.IsValid() ? PostProcessManager->GetWorld() : nullptr;
	if (!World)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialFog::UpdateBlackFogParams: invalid world, %s"), *GetDebugInfo());
		return;
	}

	BlendOutTime = BlendTime;
	
	if (bOverrideFogOpacity)
	{
		World->GetTimerManager().ClearTimer(OpacityReachZeroTimerHandle);

		if (FMath::IsNearlyZero(FogOpacity))
		{
			World->GetTimerManager().SetTimer(OpacityReachZeroTimerHandle, FTimerDelegate::CreateRaw(
				this, &KGPPMaterialBlackFog::OnOpacityReachZero), BlendTime, false);
			UE_LOG(LogKGPP, Log, TEXT("KGPPMaterialBlackFog::UpdateBlackFogParams: Opacity will reach zero in %f seconds, %s"), BlendTime, *GetDebugInfo());
		}
	}
	
	if (bOverrideCenterPos)
	{
		UpdateVectorParam(FogParams.FogCenterPosParamName, FLinearColor(CenterPos));
	}
	
	if (bOverrideFogColor)
	{
		UpdateVectorParam(FogParams.FogColorParamName, FogColor);
	}
	
	if (bOverrideSmoothDist)
	{
		AddOrUpdateScalarLinearSampleParamTargetValue(FogParams.SmoothDistParamName, 
			0.0f, SmoothDistInMeters, true, BlendTime);
	}
	
	if (bOverrideFogOpacity)
	{
		AddOrUpdateScalarLinearSampleParamTargetValue(FogParams.FogOpacityParamName, 
			0.0f, FogOpacity, true, BlendTime);
	}
	
	UpdateScalarParam(FogParams.ShapeTypeName, static_cast<float>(CurShapeType));
	
	UpdateScalarParam(FogParams.ShapeTypeBName, static_cast<float>(ShapeType));
	AddScalarLinearSampleParamTargetValue(FogParams.ShapeLerpName, 0.0f, 1.0f, BlendTime);
	
	// 初次设置或者形状未变化, 使用伸缩方式进行渐变
	if (ShapeType == EKGFogShapeType::Circle)
	{
		AddOrUpdateScalarLinearSampleParamTargetValue(FogParams.CircleRadiusName, 0.0f, CircleRadius, true, BlendTime);
	}
	else if (ShapeType == EKGFogShapeType::Ring)
	{
		AddOrUpdateScalarLinearSampleParamTargetValue(FogParams.RingOuterRadiusName, 0.0f, RingOuterRadius, true, BlendTime);
		AddOrUpdateScalarLinearSampleParamTargetValue(FogParams.RingPercentName, 0.0f, RingPercent, true, BlendTime);
	}
	else if (ShapeType == EKGFogShapeType::Cross)
	{
		AddOrUpdateScalarLinearSampleParamTargetValue(FogParams.CrossLengthName, 0.0f, CrossLength, true, BlendTime);
		AddOrUpdateScalarLinearSampleParamTargetValue(FogParams.CrossWidthName, 0.0f, CrossWidth, true, BlendTime);
		if (bOverrideRangeSpawnRotation)
		{
			UpdateScalarParam(FogParams.RangeSpawnRotationName, RangeSpawnRotation);	
		}
	}
	else if (ShapeType == EKGFogShapeType::HalfField)
	{
		AddOrUpdateScalarLinearSampleParamTargetValue(FogParams.HalfFieldWidthName, 0.0f, HalfFieldWidth, true, BlendTime);
		if (bOverrideRangeSpawnRotation)
		{
			UpdateScalarParam(FogParams.RangeSpawnRotationName, RangeSpawnRotation);	
		}
	}
	
	CurShapeType = ShapeType;
}

void KGPPMaterialBlackFog::OnTaskEnd(EKGPostProcessStopReason StopReason)
{
	if (PostProcessManager.IsValid())
	{
		if (UWorld* World = PostProcessManager->GetWorld())
		{
			World->GetTimerManager().ClearTimer(OpacityReachZeroTimerHandle);
		}
		else
		{
			UE_LOG(LogKGPP, Warning, TEXT("KGPPMaterialBlackFog::OnTaskEnd: PostProcessManager's world is invalid, cannot clear OpacityReachZeroTimerHandle, %s"), *GetDebugInfo());
		}
	}
	else
	{
		UE_LOG(LogKGPP, Warning, TEXT("KGPPMaterialBlackFog::OnTaskEnd: PostProcessManager is invalid, cannot clear OpacityReachZeroTimerHandle, %s"), *GetDebugInfo());
	}
	
	KGPPMaterialBase::OnTaskEnd(StopReason);
}

void KGPPMaterialBlackFog::OnOpacityReachZero()
{
	UE_LOG(LogKGPP, Log, TEXT("KGPPMaterialBlackFog::OnOpacityReachZero: Opacity reached zero, %s"), *GetDebugInfo());
	if (PostProcessManager.IsValid())
	{
		PostProcessManager->StopPostProcess(GetPostProcessID(), EKGPostProcessStopReason::LifeTimeEnd);
	}
}

