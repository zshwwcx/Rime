// Fill out your copyright notice in the Description page of Project Settings.

#include "3C/Camera/CameraAction/CameraActionBattleLockCorrection.h"

#include "3C/Core/KGUEActorManager.h"
#include "Camera/CameraComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Misc/TextFilterExpressionEvaluator.h"
#include "3C/Util/KGUtils.h"

const FName UCameraActionBattleLockCorrection::CameraLookBoneName = TEXT("Camera_Look");

void UCameraActionBattleLockCorrection::Init(int64 LockActorID, int InBlendType, float InScreenThresholdUp,
	float InScreenThresholdDown, float InYawBlendParam, float InPitchBlendParam, float InSafeLockPitch,
	float InSafePitchMin, float InSafePitchMax, float InActionCD, float InRaisePitchOffsetMax,
	float InDropPitchOffsetMax, bool bClearCD)
{
	bRecover = false;
	LockSKMesh.Reset();
	LockActor.Reset();

	if(AActor* LockTarget = KGUtils::GetActorByID(LockActorID))
	{
		LockActor = LockTarget;
		if(USkeletalMeshComponent* SKMesh = LockTarget->FindComponentByClass<USkeletalMeshComponent>())
		{
			LockSKMesh = SKMesh;
			if(!SKMesh->DoesSocketExist(CameraLookBoneName))
			{
				LockSKMesh = nullptr;
			}
		}
	}

	bUseSafeLockPitch = true;
	BlendType = InBlendType;
	ScreenThresholdUp = InScreenThresholdUp + ScreenThresholdCorrect;
	ScreenThresholdDown = InScreenThresholdDown + ScreenThresholdCorrect;
	YawBlendParam = InYawBlendParam;
	PitchBlendParam = InPitchBlendParam;
	SafeLockPitch = InSafeLockPitch;
	SafePitchMin = InSafePitchMin;
	SafePitchMax = InSafePitchMax;
	ActionCD = InActionCD;
	RaisePitchOffsetMax = InRaisePitchOffsetMax;
	DropPitchOffsetMax = InDropPitchOffsetMax;
	Duration = -1;

	if(bClearCD)
	{
		CurrentCDTime = ActionCD + CDCorrect;
	}
}

void UCameraActionBattleLockCorrection::Refresh(int64 LockActorID)
{
	LockSKMesh.Reset();
	LockActor.Reset();

	if(AActor* LockTarget = KGUtils::GetActorByID(LockActorID))
	{
		LockActor = LockTarget;
		if(USkeletalMeshComponent* SKMesh = LockTarget->FindComponentByClass<USkeletalMeshComponent>())
		{
			LockSKMesh = SKMesh;
			if(!SKMesh->DoesSocketExist(CameraLookBoneName))
			{
				LockSKMesh = nullptr;
			}
		}
	}
}

void UCameraActionBattleLockCorrection::Play()
{
	Super::Play();
	bStartFinish = false;
	if(CurrentCDTime < 0.f)
	{
		CurrentCDTime = ActionCD + CDCorrect;
	}

	InitParams();
}

void UCameraActionBattleLockCorrection::Abort()
{
	Super::Abort();
	CurrentCDTime = -1.f;
	YawSmoothSpeed = 0.f;
	PitchSmoothSpeed = 0.f;
	PitchOffsetSmoothSpeed = 0.f;
	if(CameraMode.IsValid())
	{
		CameraMode->RemoveCameraSocketRotOffsetSetting(Priority);
	}
}

bool UCameraActionBattleLockCorrection::ProcessViewRotation(AActor* ViewTarget, float DeltaTime,
	bool& bOutChangePitch, double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll,
	FRotator& OutDeltaRot)
{
if(bStartFinish == true)
	{
		return false;
	}

	bNeedPitchOffset = false;

	if(!LockSKMesh.IsValid() && !LockActor.IsValid())
	{
		return false;
	}

	if(!CameraMode.IsValid() || !CameraMode->IsActivate() || !CameraManager.IsValid())
	{
		return false;
	}

	APlayerController* PC = CameraManager->PCOwner;
	if(PC == nullptr)
	{
		return false;
	}
	
	UCameraArmComponent* Arm = CameraMode->GetCameraArmComponent();
	if(Arm == nullptr)
	{
		return false;
	}

	UCameraComponent* Camera = CameraMode->GetCameraComponent();
	if(Camera == nullptr)
	{
		return false;
	}
	
	CurrentCDTime = FMath::Min(CurrentCDTime + DeltaTime, ActionCD + CDCorrect);
	if(CurrentCDTime < ActionCD)
	{
		return false;
	}

	OutDeltaRot.Pitch = 0.f;
	OutDeltaRot.Yaw = 0.f;
	bOutChangePitch = true;
	bOutChangeYaw = true;

	float CameraToLookProjection = Arm->GetRealCameraArmLen();
	FVector CameraLookLocation = Arm->GetCachedPivotLocation();
	CameraLockLocation = LockSKMesh.IsValid() ? LockSKMesh->GetSocketLocation(CameraLookBoneName) : LockActor->GetActorLocation();
	FVector LookToLock = CameraLockLocation - CameraLookLocation;
	float TargetYaw = LookToLock.Rotation().Yaw;
	float TargetPitch = bUseSafeLockPitch ? SafeLockPitch : OutPitch;
	// 依据屏幕坐标调整Pitch
	FRotator CameraRot = Arm->GetCachedPivotRotation();
	float RowPitch = CameraRot.Pitch;
	CameraRot.Yaw = TargetYaw;
	CameraRot.Pitch = SafeLockPitch;
	FTransform WorldCameraTM{CameraRot, Arm->GetCachedPivotLocation() - CameraRot.Vector() * CameraToLookProjection};
	FVector LockRelativeLocationToCamera = WorldCameraTM.InverseTransformPosition(CameraLockLocation);
	float CurrentScreenTan = LockRelativeLocationToCamera.Z / FMath::Abs(LockRelativeLocationToCamera.X);
	float VerticalFOVTan = 9.f * FMath::Tan(FMath::DegreesToRadians(Camera->FieldOfView / 2.f)) / 16.f;
	float CurrentScreenRatio = (- CurrentScreenTan / VerticalFOVTan + 1.f) / 2.f;
	if(ScreenThresholdDown >= CurrentScreenRatio && CurrentScreenRatio >= ScreenThresholdUp)
	{
		TargetPitch = SafeLockPitch;
		bUseSafeLockPitch = false;
	}
	else 
	{
		CameraRot.Pitch = RowPitch;
		WorldCameraTM.SetLocation(Arm->GetCachedPivotLocation() - CameraRot.Vector() * CameraToLookProjection);
		WorldCameraTM.SetRotation(CameraRot.Quaternion());
		LockRelativeLocationToCamera = WorldCameraTM.InverseTransformPosition(CameraLockLocation);
		CurrentScreenTan = LockRelativeLocationToCamera.Z / FMath::Abs(LockRelativeLocationToCamera.X);
		VerticalFOVTan = 9.f * FMath::Tan(FMath::DegreesToRadians(Camera->FieldOfView / 2.f)) / 16.f;
		CurrentScreenRatio = (- CurrentScreenTan / VerticalFOVTan + 1.f) / 2.f;
	
		float StandardFOVRad = FMath::DegreesToRadians(Camera->FieldOfView);
		float LookToLockProjection = LookToLock.Length();
		float TargetThreshold;
		if(CurrentScreenRatio > ScreenThresholdDown || CurrentScreenRatio < ScreenThresholdUp)
		{
			bUseSafeLockPitch = false;
			if(CurrentScreenRatio > ScreenThresholdDown)
			{
				TargetThreshold = ScreenThresholdDown;
			}
			else
			{
				TargetThreshold = ScreenThresholdUp;
			}
			ScreenThresholdRad = FMath::Atan(9.f * 2.f * FMath::Tan(StandardFOVRad / 2.f) * FMath::Abs((TargetThreshold - 0.5f) / 16.f));
			float SinScreen = FMath::Sin(ScreenThresholdRad);
			float CosScreen = FMath::Cos(ScreenThresholdRad);
			float FormulaDelta = LookToLockProjection * LookToLockProjection - CameraToLookProjection * CameraToLookProjection * SinScreen * SinScreen;
			if(FormulaDelta < 0)
			{
				//需要额外偏移
				TargetPitch = TargetThreshold == ScreenThresholdDown ? SafePitchMin : SafePitchMax;
				bNeedPitchOffset = true;
				bRaiseOffset = TargetThreshold != ScreenThresholdDown;
			}
			else
			{
				float CosAlpha = (CameraToLookProjection * SinScreen * SinScreen - CosScreen * FMath::Sqrt(FormulaDelta)) / LookToLockProjection;
				float LookToLockPitch = LookToLock.Rotation().Pitch;
				TargetPitch = TargetThreshold > 0.5f ? FRotator::NormalizeAxis(LookToLockPitch - FMath::RadiansToDegrees(FMath::Acos(CosAlpha)) + 180.f) : FRotator::NormalizeAxis(LookToLockPitch + FMath::RadiansToDegrees(FMath::Acos(CosAlpha)) - 180.f);
				if(TargetPitch < SafePitchMin)
				{
					// 需要额外偏移
					if(TargetThreshold == ScreenThresholdDown)
					{
						bNeedPitchOffset = true;
						bRaiseOffset = false;
					}
				}
				else if(TargetPitch > SafePitchMax)
				{
					if(TargetThreshold == ScreenThresholdUp)
					{
						bNeedPitchOffset = true;
						bRaiseOffset = true;
					}
				}
			}
		}
		else
		{
			TargetPitch = FRotator::NormalizeAxis(TargetPitch);
			if(TargetPitch < SafeLockPitch)
			{
				TargetThreshold = ScreenThresholdDown;
			}
			else
			{
				TargetThreshold = ScreenThresholdUp;
			}
			ScreenThresholdRad = FMath::Atan(9.f * 2.f * FMath::Tan(StandardFOVRad / 2.f) * FMath::Abs((TargetThreshold - 0.5f) / 16.f));
			float SinScreen = FMath::Sin(ScreenThresholdRad);
			float CosScreen = FMath::Cos(ScreenThresholdRad);
			float FormulaDelta = LookToLockProjection * LookToLockProjection - CameraToLookProjection * CameraToLookProjection * SinScreen * SinScreen;
			if(FormulaDelta < 0)
			{
				// 应该算异常
				UE_LOG(LogTemp, Error, TEXT("UCameraActionBattleLockCorrection Error"));
			}
			else
			{
				float CosAlpha = (CameraToLookProjection * SinScreen * SinScreen - CosScreen * FMath::Sqrt(FormulaDelta)) / LookToLockProjection;
				float LookToLockPitch = LookToLock.Rotation().Pitch;
				TargetPitch = TargetThreshold > 0.5f ? FRotator::NormalizeAxis(LookToLockPitch - FMath::RadiansToDegrees(FMath::Acos(CosAlpha)) + 180.f) : FRotator::NormalizeAxis(LookToLockPitch + FMath::RadiansToDegrees(FMath::Acos(CosAlpha)) - 180.f);
			}
		}
	}

	TargetPitch = FMath::ClampAngle(TargetPitch, SafePitchMin, SafePitchMax);
	
	float CurrentYaw = FRotator::NormalizeAxis(OutYaw);
	float CurrentPitch = FRotator::NormalizeAxis(OutPitch);
	TargetYaw = MathFormula::SameSignAngle(CurrentYaw, TargetYaw);
	TargetPitch = MathFormula::SameSignAngle(CurrentPitch, TargetPitch);

	CachedTargetPitch = TargetPitch;
	CachedTargetYaw = TargetYaw;
	
	if(BlendType == 0)
	{
		if(FMath::IsNearlyZero(YawBlendParam))
		{
			OutYaw = TargetYaw;
		}
		else
		{
			OutYaw = TargetYaw + (CurrentYaw - TargetYaw) * FMath::Pow(0.5f, DeltaTime / YawBlendParam);
		}
		if(FMath::IsNearlyZero(PitchBlendParam))
		{
			OutPitch = TargetPitch;
		}
		else
		{
			OutPitch = TargetPitch + (CurrentPitch - TargetPitch) * FMath::Pow(0.5f, DeltaTime / PitchBlendParam);
		}
	}
	else
	{
		// SmoothDamp
		FMath::SpringDamperSmoothing<float>(CurrentYaw, YawSmoothSpeed, TargetYaw, 0, DeltaTime, YawBlendParam, 1.f);
		FMath::SpringDamperSmoothing<float>(CurrentPitch, PitchSmoothSpeed, TargetPitch, 0, DeltaTime, PitchBlendParam, 1.f);
		OutPitch = CurrentPitch;
		OutYaw = CurrentYaw;
	}

	return true;
}

void UCameraActionBattleLockCorrection::ModifyCamera(float DeltaTime)
{
	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return;
	}

	UCameraArmComponent* Arm = CameraMode->GetCameraArmComponent();
	if(Arm == nullptr)
	{
		return;
	}

	float TargetPitchOff = bStartFinish ? CameraMode->GetCameraSocketRotOffsetBelowPriority(Priority, FRotator::ZeroRotator).Pitch : 0.f;
	if(bNeedPitchOffset)
	{
		FRotator CameraDesiredRot{CachedTargetPitch, CachedTargetYaw, 0};
		FTransform WorldCameraTM{CameraDesiredRot, Arm->GetCachedPivotLocation() - CameraDesiredRot.Vector() * Arm->GetRealCameraArmLen()};
		FVector LockRelativeLocationToCamera = WorldCameraTM.InverseTransformPosition(CameraLockLocation);
		float CurrentScreenTan = LockRelativeLocationToCamera.Z / LockRelativeLocationToCamera.X;
	
		float CurrentScreenTanDegree = FMath::RadiansToDegrees(FMath::Atan(CurrentScreenTan));
		float ScreenThresholdPitch = FMath::RadiansToDegrees(ScreenThresholdRad);
		TargetPitchOff = bRaiseOffset ? FMath::Min(RaisePitchOffsetMax, FMath::Abs(CurrentScreenTanDegree - ScreenThresholdPitch)) : -FMath::Min(DropPitchOffsetMax, FMath::Abs(CurrentScreenTanDegree - ScreenThresholdPitch));
		// UE_LOG(LogTemp, Log, TEXT("CameraLock TargetPitchOff:%f CachedTargetPitch:%f"), TargetPitchOff, CachedTargetPitch);
	}

	FRotator SocketRotOff = CameraMode->GetCameraSocketRotOffsetBelowPriority(Priority, FRotator::ZeroRotator);
	if(BlendType == 0)
	{
		if(FMath::IsNearlyZero(PitchBlendParam) || bFinished)
		{
			CurrentOffsetPitch = TargetPitchOff;
		}
		else
		{
			CurrentOffsetPitch = TargetPitchOff + (CurrentOffsetPitch - TargetPitchOff) * FMath::Pow(0.5f, DeltaTime / PitchBlendParam);
		}
	}
	else
	{
		// SmoothDamp
		if(bFinished)
		{
			CurrentOffsetPitch = TargetPitchOff;
		}
		else
		{
			FMath::SpringDamperSmoothing<double>(CurrentOffsetPitch, PitchOffsetSmoothSpeed, TargetPitchOff, 0, DeltaTime, PitchBlendParam, 1.f);
		}
	}
	SocketRotOff.Pitch = CurrentOffsetPitch;
	CameraMode->SetCameraSocketRotOffsetSetting(SocketRotOff, Priority);
	if(bStartFinish && FMath::IsNearlyEqual(CurrentOffsetPitch, TargetPitchOff, UE_KINDA_SMALL_NUMBER))
	{
		SocketRotOff.Pitch = TargetPitchOff;
		CameraMode->SetCameraSocketRotOffsetSetting(SocketRotOff, Priority);
		DisableAction(true);
	}

	bNeedPitchOffset = false;
}

void UCameraActionBattleLockCorrection::DisableAction(bool bImmediate)
{
	if(bFinished)
	{
		return;
	}

	UE_LOG(LogTemp, Log, TEXT("CameraManger:DisableCameraAction Action:%s Immediate:%d ActionID:%lld"), *this->GetName(), bImmediate, ActionID);
	if(bImmediate)
	{
		Duration = RunningTime;
		bFinished = true;
		InnerUpdateAlpha(0.f);
	}
	else if(!bFinished)
	{
		bStartFinish = true;
	}
}

bool UCameraActionBattleLockCorrection::IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType)
{
	if(ControlType == ECameraManualControlType::ManualRot)
	{
		CurrentCDTime = 0.f;
	}

	return false;
}

void UCameraActionBattleLockCorrection::DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode)
{
	Super::DoWhenEffectModeActivate(ActivateCameraMode);
	InitParams();
}

void UCameraActionBattleLockCorrection::InitParams()
{
	if(CameraMode.IsValid() && CameraMode->IsActivate())
	{
		CurrentOffsetPitch = CameraMode->GetCameraSocketRotOffsetSetting().Pitch;
	}
}


