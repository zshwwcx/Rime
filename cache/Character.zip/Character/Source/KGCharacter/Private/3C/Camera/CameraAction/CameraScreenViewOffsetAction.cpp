// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Camera/CameraAction/CameraScreenViewOffsetAction.h"

void UCameraScreenViewOffsetAction::Init(float InOffsetX, float InOffsetY, float InBlendInTime, float InBlendOutTime,
	float InDuration, ECameraEaseFunction::Type InBlendInType, ECameraEaseFunction::Type InBlendOutType,
	int64 InBlendInCurve, int64 InBlendOutCurve)
{
	Offset.X = InOffsetX;
	Offset.Y = InOffsetY;

	Duration = InDuration;
	SetEaseInType(InBlendInType, InBlendInTime, InBlendInCurve);
	SetEaseOutType(InBlendOutType, InBlendOutTime, InBlendOutCurve);
}

void UCameraScreenViewOffsetAction::Play()
{
	Super::Play();

	InitParams();
}

void UCameraScreenViewOffsetAction::ModifyCamera(float DeltaTime)
{
	Super::ModifyCamera(DeltaTime);

	if(CameraMode.IsValid() && CameraMode->IsActivate())
	{
		FVector2D Result = FMath::Lerp(bStartBlendOut ? CameraMode->GetPivotOffsetBelowPriority(Priority, BaseOffset) : BaseOffset, Offset, FMath::Clamp(Alpha, 0.f, 1.f));
		CameraMode->SetPivotOffsetFromScreenCoOffsetSetting(Result.X, Result.Y, Priority);
	}
}

void UCameraScreenViewOffsetAction::Abort()
{
	Super::Abort();

	if(CameraMode.IsValid())
	{
		CameraMode->RemovePivotOffsetFromScreenCoOffsetSetting(Priority);
	}
}

void UCameraScreenViewOffsetAction::DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode)
{
	Super::DoWhenEffectModeActivate(ActivateCameraMode);

	InitParams();
}

void UCameraScreenViewOffsetAction::InitParams()
{
	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return;
	}

	BaseOffset = CameraMode->GetPivotOffsetSetting();
}
