#include "3C/Camera/PostProcessNew/PostProcessInstance/PPDummy.h"

#include "3C/Camera/PostProcessNew/PostProcessManager.h"

void KGPPDummy::InitParams(int32 InPriority, TWeakObjectPtr<UPostProcessManager> InPPManager, int32 InSourcePPID, EKGPostProcessType InSourcePPType, EKGPostProcessType InTargetPPType)
{
	Priority = InPriority;
	PostProcessManager = InPPManager;
	SourcePPID = InSourcePPID;
	SourcePPType = InSourcePPType;
	TargetPPType = InTargetPPType;
	TotalLifeTimeSeconds = -1;
}

FString KGPPDummy::GetDebugInfo() const
{
	FString SourcePPTypeName;
	FString TargetPPTypeName;
	if (PostProcessManager.IsValid())
	{
		if (SourcePPType != EKGPostProcessType::KG_PP_None)
		{
			SourcePPTypeName = PostProcessManager->GetPPTypeName(SourcePPType);
		}
		
		if (TargetPPType != EKGPostProcessType::KG_PP_None)
		{
			TargetPPTypeName = PostProcessManager->GetPPTypeName(TargetPPType);
		}
	}
	return FString::Printf(TEXT("DummyPP, PPID: %d, SourcePPID: %d, SourceType: %s, TargetType: %s"),
		PostProcessID, SourcePPID, *SourcePPTypeName, *TargetPPTypeName);
}
