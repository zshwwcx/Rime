// #include "CameraLookAtEffect.h"
// #include "3C/Util/KGUtils.h"
// #include "GameFramework/PlayerController.h"
//
// bool UCameraLookAtEffect::ProcessViewRotation(AActor* ViewTarget, float DeltaTime, FRotator& OutViewRotation, FRotator& OutDeltaRot)
// {
// 	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
// 	{
// 		return false;
// 	}
//
// 	FRotator Dir = (LookAtActor.IsValid() ? (LookAtActor->GetActorLocation() - CameraMode->GetCameraLocation()).ToOrientationRotator() : (LookAtLoc - CameraMode->GetCameraLocation()).ToOrientationRotator()) + TargetRotDelta;
// 	// UE_LOG(LogTemp, Log, TEXT("Camera Look At Desired Rot:%s"), *Dir.ToString());
// 	const FRotator DeltaAng = (Dir - OriginRotation).GetNormalized();
// 	CurTargetDir = OriginRotation + FMath::Clamp(Alpha, 0.f, 1.f) * DeltaAng;
//
// 	OutViewRotation.Yaw = CurTargetDir.Yaw;
// 	OutDeltaRot.Yaw = 0.f;
// 	if(!bUseManualControlPitch)
// 	{
// 		OutViewRotation.Pitch = CurTargetDir.Pitch;
// 		OutDeltaRot.Pitch = 0.f;
// 	}
// 	// UE_LOG(LogTemp, Log, TEXT("Camera Look At Current Rot:%s"), *OutViewRotation.ToString());
// 	return true;
// }
//
// void UCameraLookAtEffect::DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode)
// {
// 	Super::DoWhenEffectModeActivate(ActivateCameraMode);
// 	InitParams();
// }
//
// bool UCameraLookAtEffect::IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType)
// {
// 	if(ControlType == ECameraManualControlType::ManualRot)
// 	{
// 		return bCanInterrupt && !bUseManualControlPitch;
// 	}
//
// 	return false;
// }
//
// void UCameraLookAtEffect::InitParams()
// {
// 	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
// 	{
// 		return;
// 	}
//
// 	OriginRotation = CameraMode->GetCameraRotation();
// }
//
// void UCameraLookAtEffect::InitParams(const FVector& InLookAtLoc, int64 LookAtActorID, float InBlendInTime, float InBlendOutTime, float InDuration, bool bInRecover, const FRotator& InTargetRotDelta, bool bInUseManualControlPitch, bool bInCanInterrupt, ECameraEaseFunction::Type InBlendInMode, ECameraEaseFunction::Type InBlendOutMode, int64 BlendInCurveID, int64 BlendOuTCurveID)
// {
// 	SetEaseInType(InBlendInMode, InBlendInTime, BlendInCurveID);
// 	SetEaseOutType(InBlendOutMode, InBlendOutTime, BlendOuTCurveID);
// 	Duration = InDuration;
// 	bRecover = bInRecover;
// 	TargetRotDelta = InTargetRotDelta;
// 	bCanInterrupt = bInCanInterrupt;
//
// 	LookAtLoc = InLookAtLoc;
// 	LookAtActor = KGUtils::GetActorByID(LookAtActorID);
//
// 	bUseManualControlPitch = bInUseManualControlPitch;
// 	bCanInterrupt = bInCanInterrupt;
// }
//
// void UCameraLookAtEffect::Play()
// {
// 	Super::Play();
//
// 	InitParams();
// }


#include "3C/Camera/CameraAction/CameraLookAtEffect.h"
#include "ICppEntity.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Camera/CameraAction/CameraActionHandler.h"
#include "3C/Util/KGUtils.h"
#include "Components/SkeletalMeshComponent.h"

void UCameraLookAtEffect::DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode)
{
	Super::DoWhenEffectModeActivate(ActivateCameraMode);
	InitParams();
}

bool UCameraLookAtEffect::IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType)
{
	if(ControlType == ECameraManualControlType::ManualRot)
	{
		return bCanInterrupt && !bUseManualControlPitch;
	}

	return false;
}

void UCameraLookAtEffect::InitParams()
{
	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return;
	}

	OriginRotation = CameraMode->GetCameraRotation();
	CalDesiredRot(true);
}

void UCameraLookAtEffect::CalDesiredRot(bool bInit)
{
	if(CameraMode.IsValid() && CameraMode->IsActivate())
	{
		FVector TargetLocation = LookAtActor.IsValid() ? LookAtActor->GetActorLocation() : LookAtLoc;

		if (LookAtActor.IsValid())
		{
			// 防止LookAtActor突然丢失或销毁时的异常表现
			LookAtLoc = TargetLocation;
		}

		if (LookAtActor.IsValid() && BoneName.IsValid())
		{
			if (ABaseCharacter * BaseCharacter = Cast<ABaseCharacter>(LookAtActor.Get()))
			{
				if (USkeletalMeshComponent* SkMeshComp = BaseCharacter->GetMainMesh())
				{
					int32 BoneIndex = SkMeshComp->GetBoneIndex(BoneName);
					if (BoneIndex != INDEX_NONE)
					{
						TargetLocation = SkMeshComp->GetBoneLocation(BoneName);
					}
				}
			}
		}
		
		if (UCameraArmComponent* Arm = CameraMode->GetCameraArmComponent())
		{
			FVector LookAtLocation = Arm->GetCachedPivotLocation();
			FVector Offset = Arm->GetRelativeCachedPivotOffset();
			float Radius = Offset.Y;
			if(bInit)
			{
				FRotator CamRot = CameraMode->GetCameraRotation();
				BaseYaw = CamRot.Yaw;
				BasePitch = CamRot.Pitch;
			}

			if(CameraMode->BasicConfig.ViewOffset.GetValue().X == 0 || FMath::IsNearlyZero(Radius))
			{
				const FVector PivotToLockDir = (TargetLocation - LookAtLocation).GetSafeNormal();
				const FRotator PivotToLockDirRot = PivotToLockDir.ToOrientationRotator();
				DesiredYaw = PivotToLockDirRot.Yaw;
			}
			else
			{
				const FVector LockLocation = TargetLocation;
				FVector LookAtToTargetProjection = LockLocation - LookAtLocation;
				LookAtToTargetProjection.Z = 0.f;
				float Distance = LookAtToTargetProjection.Length();
				if(FMath::Abs(Radius) > Distance)
				{
					float YawOffset = Radius > 0 ? -90 : 90;
					DesiredYaw = LookAtToTargetProjection.ToOrientationRotator().Yaw + YawOffset;
				}
				else
				{
					float YawOffset = FMath::RadiansToDegrees(FMath::Acos(Radius / Distance));
					float RadiusYaw = LookAtToTargetProjection.ToOrientationRotator().Yaw + YawOffset;
					LookAtLocation.X += Radius * FMath::Cos(FMath::DegreesToRadians(RadiusYaw));
					LookAtLocation.Y += Radius * FMath::Sin(FMath::DegreesToRadians(RadiusYaw));
					DesiredYaw = (LockLocation - LookAtLocation).ToOrientationRotator().Yaw;
				}
			}

			Radius = Offset.Z;
			if(CameraMode->BasicConfig.ViewOffset.GetValue().Y == 0 || FMath::IsNearlyZero(Radius))
			{
				const FVector PivotToLockDir = (TargetLocation - LookAtLocation).GetSafeNormal();
				const FRotator PivotToLockDirRot = PivotToLockDir.ToOrientationRotator();
				DesiredPitch = PivotToLockDirRot.Pitch;
			}
			else
			{
				Offset.Z = 0.f;
				const FVector LockLocation = TargetLocation;
				FRotator CamRot = CameraMode->GetCameraRotation();
				CamRot.Yaw = DesiredYaw;
				FVector LookAtToTargetProjection = LockLocation - (Arm->GetCachedPivotLocation() + FRotationMatrix(CamRot).TransformVector(Offset));
				float Distance = LookAtToTargetProjection.Length();
				if(FMath::Abs(Radius) > Distance)
				{
					float PitchOffset = Radius > 0 ? -90 : 90;
					DesiredPitch = LookAtToTargetProjection.ToOrientationRotator().Pitch + PitchOffset;
				}
				else
				{
					float PitchOffset = FMath::RadiansToDegrees(FMath::Asin(Radius / Distance));
					float RadiusYaw = LookAtToTargetProjection.ToOrientationRotator().Pitch - PitchOffset;
					DesiredPitch = RadiusYaw;
				}
			}
		}
	}
}

void UCameraLookAtEffect::Init(const FVector& InLookAtLoc, int64 LookAtActorID, float InBlendInTime,
	float InBlendOutTime, float InDuration, bool bInRecover, const FRotator& InTargetRotDelta,
	bool bInUseManualControlPitch, bool bInCanInterrupt, ECameraEaseFunction::Type InBlendInMode,
	ECameraEaseFunction::Type InBlendOutMode, int64 BlendInCurveID, int64 BlendOuTCurveID, const FString& InBoneName,
	bool bContinue)
{
	bUseActor = false;
	bCppEntity = false;

	SetEaseInType(InBlendInMode, InBlendInTime, BlendInCurveID);
	SetEaseOutType(InBlendOutMode, InBlendOutTime, BlendOuTCurveID);
	Duration = InDuration;
	bRecover = bInRecover;
	TargetRotDelta = InTargetRotDelta;
	bCanInterrupt = bInCanInterrupt;
	BoneName = FName(InBoneName);

	LookAtLoc = InLookAtLoc;
	LookAtActor = KGUtils::GetActorByID(LookAtActorID);

	if (LookAtActor.IsValid())
	{
		bUseActor = true;
		if (ICppEntityInterface* CppEntity = UKGUEActorManager::GetLuaEntityByActor(LookAtActor.Get()))
		{
			bCppEntity = true;
		}
	}

	bUseManualControlPitch = bInUseManualControlPitch;
	bCanInterrupt = bInCanInterrupt;
	bActionContinueDetect = bContinue;
}

void UCameraLookAtEffect::Play()
{
	Super::Play();
	InitParams();
}

bool UCameraLookAtEffect::ProcessViewRotation(AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch,
	double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot)
{
	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return false;
	}

	if (bActionContinueDetect && !bStartBlendOut)
	{
		if (bUseActor)
		{
			if (!LookAtActor.IsValid())
			{
				DisableAction(true);
				return false;
			}

			if (bCppEntity)
			{
				if (ICppEntityInterface* CppEntity = UKGUEActorManager::GetLuaEntityByActor(LookAtActor.Get()))
				{
					if (CppEntity->IsDead())
					{
						DisableAction(true);
						return false;
					}
				}
				else
				{
					DisableAction(true);
					return false;
				}
			}
		}
		CalDesiredRot(false);
	}

	float Roll = 0.f;
	if(bStartBlendOut && bRecover)
	{
		if(ActionHandlerOwner.IsValid())
		{
			ActionHandlerOwner->GetRotationRecoverTo(Priority, BasePitch, BaseYaw, Roll);
		}
	}

	FRotator BaseRot{BasePitch, BaseYaw, Roll};
	CameraRotation.Yaw = DesiredYaw + TargetRotDelta.Yaw;
	OutDeltaRot.Yaw = 0.f;
	bOutChangeYaw = true;
	if(!bUseManualControlPitch)
	{
		CameraRotation.Pitch = DesiredPitch + TargetRotDelta.Pitch;
		OutDeltaRot.Pitch = 0.f;
		bOutChangePitch = true;
	}

	// if (!bStartBlendOut && !bStartBlendIn)
	// {
	// 	OutYaw = FRotator::NormalizeAxis(OutYaw);
	// 	CameraRotation.Yaw = FRotator::NormalizeAxis(CameraRotation.Yaw);
	// 	BaseRot.Yaw = CameraRotation.Yaw + (OutYaw - CameraRotation.Yaw) * FMath::Pow(0.5f, DeltaTime / 0.1f);
	// 	if(!bUseManualControlPitch)
	// 	{
	// 		OutPitch = FRotator::NormalizeAxis(OutPitch);
	// 		CameraRotation.Pitch = FRotator::NormalizeAxis(CameraRotation.Pitch);
	// 		BaseRot.Pitch = CameraRotation.Pitch + (OutPitch - CameraRotation.Pitch) * FMath::Pow(0.5f, DeltaTime / 0.1f);
	// 	}
	// }
	// else
	// {
	// 	const FRotator DeltaAng = (CameraRotation - BaseRot).GetNormalized();
	// 	BaseRot = BaseRot + FMath::Clamp(Alpha, 0.f, 1.f) * DeltaAng;
	// }

	const FRotator DeltaAng = (CameraRotation - BaseRot).GetNormalized();
	BaseRot = BaseRot + FMath::Clamp(Alpha, 0.f, 1.f) * DeltaAng;

	// UE_LOG(LogTemp, Log, TEXT("Camera LookAt BaseYaw:%f TargetYaw"), BaseRot.Yaw)

	OutYaw = BaseRot.Yaw;
	if(!bUseManualControlPitch)
	{
		OutPitch = BaseRot.Pitch;
	}
	return true;
}
