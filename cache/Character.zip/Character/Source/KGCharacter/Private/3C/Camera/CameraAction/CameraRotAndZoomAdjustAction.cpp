// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Camera/CameraAction/CameraRotAndZoomAdjustAction.h"

#include "3C/Camera/CameraAction/CameraActionHandler.h"


void UCameraRotAndZoomAdjustAction::Init(float Pitch, float Yaw, float Zoom, float InBlendInTime, float InBlendOutTime,
                                         float InDuration, bool bInRecover, ECameraEaseFunction::Type InBlendInType, ECameraEaseFunction::Type InBlendOutType,
                                         int64 InBlendInCurve, int64 InBlendOutCurve)
{
	TargetRotation.Pitch = Pitch;
	TargetRotation.Yaw = Yaw;
	TargetZoom = Zoom;
	SetEaseInType(InBlendInType, InBlendInTime, InBlendInCurve);
	SetEaseOutType(InBlendOutType, InBlendOutTime, InBlendOutCurve);
	Duration = InDuration;
	bRecover = bInRecover;
}

void UCameraRotAndZoomAdjustAction::Play()
{
	Super::Play();
	InitParams();
}

void UCameraRotAndZoomAdjustAction::ModifyCamera(float DeltaTime)
{
	Super::ModifyCamera(DeltaTime);

	if(CameraMode.IsValid())
	{
		CameraMode->SetOverrideZoomSetting(FMath::Lerp(bStartBlendOut ? CameraMode->GetOverrideZoomBelowPriority(Priority, ZoomBase) : ZoomBase, TargetZoom, Alpha), Priority);
	}
}

bool UCameraRotAndZoomAdjustAction::ProcessViewRotation(class AActor* ViewTarget, float DeltaTime,
	bool& bOutChangePitch, double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll,
	FRotator& OutDeltaRot)
{
	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return false;
	}
	FRotator Result = RotateBase;
	if(bStartBlendOut && bRecover)
	{
		if(ActionHandlerOwner.IsValid())
		{
			ActionHandlerOwner->GetRotationRecoverTo(Priority, RotateBase);
		}
	}
	const FRotator DeltaAng = (TargetRotation - RotateBase).GetNormalized();
	Result = RotateBase + FMath::Clamp(Alpha, 0.f, 1.f) * DeltaAng;

	bOutChangePitch = true;
	bOutChangeYaw = true;
	OutPitch = Result.Pitch;
	OutYaw = Result.Yaw;

	OutDeltaRot.Pitch = 0.f;
	OutDeltaRot.Yaw = 0.f;
	return true;
}

void UCameraRotAndZoomAdjustAction::DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode)
{
	Super::DoWhenEffectModeActivate(ActivateCameraMode);
	InitParams();
}

void UCameraRotAndZoomAdjustAction::Abort()
{
	Super::Abort();
	if(CameraMode.IsValid())
	{
		CameraMode->RemoveOverrideZoomSetting(Priority);
	}
}

void UCameraRotAndZoomAdjustAction::InitParams()
{
	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return;
	}

	if (UCameraArmComponent* Arm = CameraMode->GetCameraArmComponent())
	{
		ZoomBase = 	Arm->GetTargetCameraZoomLen();
		RotateBase = CameraMode->GetCameraRotation();	
	}
}
