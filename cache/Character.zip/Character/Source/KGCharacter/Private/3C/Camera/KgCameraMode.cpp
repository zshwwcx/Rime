#include "3C/Camera/KgCameraMode.h"
#include "3C/Camera/BaseCamera.h"
#include "3C/Core/C7ActorInterface.h"
#include "3C/Camera/CameraArmComponent.h"
#include "3C/Camera/CameraManager.h"
#include "GameSessionSettings.h"
#include "3C/Util/KGUtils.h"
#include "Camera/CameraComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Kismet/GameplayStatics.h"

UKgCameraMode::UKgCameraMode(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer), bEnableTick(false)
{
}

void UKgCameraMode::UpdateControlData(float DeltaTime)
{
	if (CurCameraPtr.IsValid())
	{
		ACameraManager* CM = Cast<ACameraManager>(CurCameraMgr);
		ABaseCamera* CurCamera = Cast<ABaseCamera>(CurCameraPtr);
		if (CM && CurCamera)
		{
			UCameraArmComponent* Arm = CurCamera->GetCameraArmComponent();
			float ZoomLen = Arm->GetCameraCurrentBaseZoomLen();

			if (TargetLocationOffsetCurve != nullptr)
			{
				FVector NewLocOffset = TargetLocationOffsetCurve->GetVectorValue(ZoomLen);
				CurCamera->GetCameraArmComponent()->SetTargetOffset(NewLocOffset);
			}

			if (FOVCurve != nullptr)
			{
				float NewFOV = FOVCurve->GetFloatValue(ZoomLen);
				SetFOVSetting(NewFOV, ACameraManager::CAMERA_BASE_SETTING_PRIORITY);
			}

			float ZoomMin = BasicConfig.ZoomMinLen.GetValue();
			float ZoomMax = BasicConfig.ZoomMaxLen.GetValue();
			float PreviousZoom = Arm->GetCameraCachedBaseArmLen();
			float TargetZoom = Arm->GetTargetCameraZoomLen();

			if(bAdaptiveViewOffset)
			{
				float ZoomRatio = ZoomMin != ZoomMax ? (TargetZoom - ZoomMin) / (ZoomMax - ZoomMin): 1.f;
				ZoomRatio = FMath::Clamp(ZoomRatio, 0.f, 1.f);
				FVector2D CurViewOff = Arm->GetPivotOffsetFromScreenCoOffset();
				float Alpha = FMath::IsNearlyZero(AdaptiveViewOffsetHalfLife) ? 0 : FMath::Pow(0.5f, DeltaTime / AdaptiveViewOffsetHalfLife);
				float TargetOffsetX = FMath::Lerp(AdaptiveViewOffsetXWithZoom.X, AdaptiveViewOffsetXWithZoom.Y, ZoomRatio);
				float TargetOffsetY = FMath::Lerp(AdaptiveViewOffsetYWithZoom.X, AdaptiveViewOffsetYWithZoom.Y, ZoomRatio);
				Arm->SetPivotOffsetFromScreenCoOffset(
					TargetOffsetX + (CurViewOff.X - TargetOffsetX) * Alpha,
					TargetOffsetY + (CurViewOff.Y - TargetOffsetY) * Alpha
				);
			}

			if(bAdsorptionZoom)
			{
				float AMinZoom = FMath::Max(AdsorptionMinZoom, ZoomMin);
				float AMaxZoom = FMath::Min(AdsorptionMaxZoom, ZoomMax);
				if(ZoomLen < PreviousZoom)
				{
					if(AMinZoom != AMaxZoom)
					{
						float LastPct = FCameraEaseCalculate::Evaluate(AdsorptionEaseType, 0.f, 1.f, (PreviousZoom - AMinZoom) / (AMaxZoom - AMinZoom));
						float CurPct = FCameraEaseCalculate::Evaluate(AdsorptionEaseType, 0.f, 1.f, (ZoomLen - AMinZoom) / (AMaxZoom - AMinZoom));
						int ScreenX, ScreenY;
						CurCameraMgr->PCOwner->GetViewportSize(ScreenX, ScreenY);
						ScreenOff.X = (MouseCoPos.X - (BasicConfig.ViewOffset.GetValue().X * ScreenY + ScreenX / 2.f)) / (ScreenY * 1.f);
						ScreenOff.Y = MouseCoPos.Y / (ScreenY * 1.f) - 0.5;
						float SocketY = Arm->GetSocketOffsetY();
						SocketY = FMath::Clamp(SocketY + FMath::Clamp(ScreenOff.X * AdsorptionSpeed.X, -AdsorptionSpeedThreshold.X, AdsorptionSpeedThreshold.X) * (LastPct - CurPct), -AdsorptionSpeedThreshold.X, AdsorptionSpeedThreshold.X);
						float SocketZ = Arm->GetSocketOffsetZ();
						SocketZ = FMath::Clamp(SocketZ + FMath::Clamp(-ScreenOff.Y * AdsorptionSpeed.Y, -AdsorptionSpeedThreshold.Z, AdsorptionSpeedThreshold.Y) * (LastPct - CurPct), -AdsorptionSpeedThreshold.Z, AdsorptionSpeedThreshold.Y);
						Arm->SetSocketOffset(0,  SocketY, SocketZ);
					}
				}
				else if(ZoomLen > PreviousZoom)
				{
					if(RevertZoom != AMaxZoom && bRevertZoom)
					{
						if(!FMath::IsNearlyEqual(PreviousZoom, ZoomLen, 0.01f))
						{
							float LastPct = FCameraEaseCalculate::Evaluate(ECameraEaseFunction::Linear, 0.f, 1.f, (PreviousZoom - RevertZoom) / (AMaxZoom - RevertZoom));
                        	float CurPct = FCameraEaseCalculate::Evaluate(ECameraEaseFunction::Linear, 0.f, 1.f, (ZoomLen - RevertZoom) / (AMaxZoom - RevertZoom));
                        	Arm->AddSocketOffsetByVector((FVector::ZeroVector - RevertSocketOffset) * FMath::Min((CurPct - LastPct), 1.f));
						}
					}
				}
			}
			if(bRotWithRecover)
			{
				float DesiredRecoverPct = 1 - (PreviousZoom - ZoomMin) / (ZoomMax - ZoomMin);
				float Pct = FCameraEaseCalculate::Evaluate(RecoverEaseType, 0.f, 1.f, DesiredRecoverPct);
				CurCamera->SetBoneOffset(Pct * OffWithRecover, ERelativeTransformSpace::RTS_World);
				Arm->SetTargetRotOffsetByRotator(Pct * RotWithRecover);
			}
			if(bCustomRoleMode)
			{
				float ThresholdRatio = ZoomMin != CustomRoleThresholdZoom ? FMath::Clamp((PreviousZoom - ZoomMin) / (CustomRoleThresholdZoom - ZoomMin), 0.f, 1.f) : 1.f;
				float BoneOffsetZ = FCameraEaseCalculate::Evaluate(ECameraEaseFunction::EaseInOutSine, LookAtZOffset + CloseUpZOffset, LookAtZOffset, ThresholdRatio);
				float Alpha = FMath::IsNearlyZero(CustomRoleViewOffsetHalfLife) ? 0 : FMath::Pow(0.5f, DeltaTime / CustomRoleViewOffsetHalfLife);
				CurCamera->SetBoneOffsetZ(BoneOffsetZ);
				Arm->SetTargetRotOffsetByRotator(FMath::Lerp(CustomRoleCloseUpRot, CustomRoleLookAtRot, ThresholdRatio));

				FRotator Rot = CurCamera->GetActorRotation();
				float PitchMax = FMath::Lerp(CustomRoleMaxPitchCloseUp, CustomRoleMaxPitchThreshold, ThresholdRatio);
				if(Rot.Pitch > PitchMax)
				{
					Rot.Pitch = PitchMax;
					CurCamera->SetActorRotation(Rot);
				}

				float DeltaPitch = Rot.Pitch - CustomRolePreviousPitch;
				CustomRolePreviousPitch = Rot.Pitch;
				CM->KCB_NotifyCustomRoleCameraRot(DeltaPitch);

				FVector ViewOffset = BasicConfig.ViewOffset.GetValue();
				float TargetOffsetX = FMath::Lerp(CustomRoleCloseUpViewOffset.X, ViewOffset.X, ThresholdRatio);
				float TargetOffsetY = FMath::Lerp(CustomRoleCloseUpViewOffset.Y, ViewOffset.Y, ThresholdRatio);
				FVector2D CurViewOff = Arm->GetPivotOffsetFromScreenCoOffset();
				Arm->SetPivotOffsetFromScreenCoOffset(TargetOffsetX + (CurViewOff.X - TargetOffsetX) * Alpha, TargetOffsetY + (CurViewOff.Y - TargetOffsetY) * Alpha);
				// UE_LOG(LogTemp, Log, TEXT("Camera UpdateControlData: BoneOffsetZ:%f ScreenOffsetX:%f ScreenOffsetY:%f"), CurCamera->GetBoneOffsetZ(), FMath::Lerp(CustomRoleCloseUpViewOffset.X, ViewOffset.X, ThresholdRatio), FMath::Lerp(CustomRoleCloseUpViewOffset.Y, ViewOffset.Y, ThresholdRatio));
			}
		}
	}
}

void UKgCameraMode::Update(float DeltaTime)
{
	if(bEnableTick)
	{
		OnModeUpdate(DeltaTime);
	}
}

void UKgCameraMode::SetCurCamera(AActor* Camera)
{
	CurCameraPtr = Camera;
	CameraWeakPtr = Cast<ABaseCamera>(CurCameraPtr);
	if (CameraWeakPtr.IsValid())
	{
		ArmWeakPtr = CameraWeakPtr->GetCameraArmComponent();
	}
	if(ABaseCamera* BaseCamera = Cast<ABaseCamera>(Camera))
	{
		BaseCamera->SetControlConfig(this);
		BaseCamera->GetCameraArmComponent()->SetControlConfig(this);
	}
}

void UKgCameraMode::SetCurCameraByID(int64 CameraActorID)
{
	AActor* Camera = KGUtils::GetActorByID(CameraActorID);
	SetCurCamera(Camera);
}

void UKgCameraMode::UpdateCameraZoomLenClamp(float ZoomMax, float ZoomMin)
{
	BasicConfig.ZoomMaxLen = ZoomMax;
	BasicConfig.ZoomMinLen = ZoomMin;
	if (ABaseCamera* Cam = Cast<ABaseCamera>(CurCameraPtr))
	{
		Cam->GetCameraArmComponent()->SetZoomSetting(ZoomMin,ZoomMax);
	}
}

void UKgCameraMode::SetCameraTargetLocationOffsetCurveFromID(int64 TargetLocationOffsetCurveID)
{
	if(UCurveVector* InTargetLocationOffsetCurve = Cast<UCurveVector>(KGUtils::GetObjectByID(TargetLocationOffsetCurveID)))
	{
		TargetLocationOffsetCurve = InTargetLocationOffsetCurve;
	}
}

void UKgCameraMode::SetCameraFOVCurveFromID(int64 FOVCurveID)
{
	if(UCurveFloat* InFOVCurve = Cast<UCurveFloat>(KGUtils::GetObjectByID(FOVCurveID)))
	{
		FOVCurve = InFOVCurve;
	}
}

AActor* UKgCameraMode::GetCurCamera()
{
	if (CurCameraPtr.IsValid())
	{
		return CurCameraPtr.Get();
	}
	return nullptr;
}

ABaseCamera* UKgCameraMode::GetCamera()
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(CurCameraPtr.Get()))
	{
		return Camera;
	}
	return nullptr;
}

UCameraComponent* UKgCameraMode::GetCameraComponent()
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(CurCameraPtr.Get()))
	{
		return Camera->GetCameraComponent();
	}
	return nullptr;
}

UCameraArmComponent* UKgCameraMode::GetCameraArmComponent()
{
	if (ABaseCamera* Camera = Cast<ABaseCamera>(CurCameraPtr.Get()))
	{
		return Camera->GetCameraArmComponent();
	}
	return nullptr;
}

#define RESET_TO_CDO_VALUE(NAME)  NAME = CDO->NAME

void UKgCameraMode::ResetToDefault()
{
	UObject* StaticCls = GetClass()->GetDefaultObject();
	if (UKgCameraMode* CDO = Cast<UKgCameraMode>(StaticCls))
	{
		RESET_TO_CDO_VALUE(bEnableTick);
		RESET_TO_CDO_VALUE(BasicConfig);
		RESET_TO_CDO_VALUE(TargetLocationOffsetCurve);
		RESET_TO_CDO_VALUE(FOVCurve);
		RESET_TO_CDO_VALUE(CameraModePriority);
		RESET_TO_CDO_VALUE(YawSensitivity);
		RESET_TO_CDO_VALUE(PitchSensitivity);

		RESET_TO_CDO_VALUE(AdsorptionSpeed);
		RESET_TO_CDO_VALUE(bRevertZoom);
		RESET_TO_CDO_VALUE(RevertZoom);
		RESET_TO_CDO_VALUE(RevertSocketOffset);
	}

	CurCameraPtr.Reset();
	CameraWeakPtr.Reset();
	ArmWeakPtr.Reset();
}

int64 UKgCameraMode::GetActorID()
{
	return KGUtils::GetIDByObject(this);
}

FRotator UKgCameraMode::GetCameraRotation()
{
	if(UCameraComponent* Cam = GetCameraComponent())
	{
		if (CurCameraMgr.IsValid() && CurCameraMgr->PendingViewTarget.Target != nullptr && CurCameraMgr->PendingViewTarget.Target == CameraWeakPtr.Get())
		{
			return CurCameraMgr->GetCameraRotation();
		}
		return Cam->GetComponentRotation();
	}

	return FRotator::ZeroRotator;
}

FVector UKgCameraMode::GetCameraLocation()
{
	if(UCameraComponent* Cam = GetCameraComponent())
	{
		return Cam->GetComponentLocation();
	}

	return FVector::ZeroVector;
}

void UKgCameraMode::MarkActivate(bool Value)
{
	bActivate = Value;
	if(!bActivate)
	{
		BasicConfig.DefaultFOV.Reset(90);
		BasicConfig.ZoomMinLen.Reset(0);
		BasicConfig.ZoomMaxLen.Reset(0);
		BasicConfig.ZoomLagEaseParam.Reset(0);
		BasicConfig.ZLagEaseParam.Reset(0);
		BasicConfig.SoftZoneRadiusZ.Reset(0);
		BasicConfig.XOYLagEaseParam.Reset(0);
		BasicConfig.RotationLagEaseParam.Reset(0);
		BasicConfig.SoftZoneRadiusXOY.Reset(0);
		BasicConfig.ReleaseLagEaseParam.Reset(0);
		BasicConfig.CompressLagEaseParam.Reset(0);
		BasicConfig.ViewOffset.Reset({0, 0, 0});
		YawSensitivity.Reset(1);
		PitchSensitivity.Reset(1);
		if(ABaseCamera* Camera = GetCamera())
		{
			Camera->MarkDeActiveByMode();
		}

		EnableApplyPOVPostProcess(true);
		ClearModeModifyDataAfterFrame();
	}
}

bool UKgCameraMode::IsActivate() const
{
	if (!CameraWeakPtr.IsValid() || !ArmWeakPtr.IsValid())
	{
		return false;
	}

	return bActivate;
}

bool UKgCameraMode::IsBlending()
{
	if (!IsActivate())
	{
		return false;
	}

	if (CurCameraMgr.IsValid())
	{
		if (ACameraManager* CameraMgr = GetCameraManager())
		{
			if (CameraMgr->IsBlending() && CameraMgr->PendingViewTarget.Target == CurCameraPtr.Get())
			{
				return true;
			}
		}
		else
		{
			if (CurCameraMgr->PendingViewTarget.Target != nullptr && CurCameraMgr->PendingViewTarget.Target == CurCameraPtr.Get())
			{
				return true;
			}
		}
	}

	return false;
}

void UKgCameraMode::EnableApplyPOVPostProcess(bool bEnable)
{
	if(bEnable != bApplyPOVPostProcess)
	{
		bApplyPOVPostProcess = bEnable;
		if(ACameraManager* Mgr = Cast<ACameraManager>(CurCameraMgr.Get()))
		{
			Mgr->KAPI_Camera_EnablePOVPostProcess(bEnable, CameraModeTag);
		}
	}
}

void UKgCameraMode::CopyAndRefreshControlData(UKgCameraMode* OtherCameraMode, int InPriority)
{
	if (OtherCameraMode == nullptr)
	{
		return;
	}

	const FCameraModeConfig& OtherBasicConfig = OtherCameraMode->BasicConfig;

	CameraModePriority = InPriority;
	BasicConfig = OtherBasicConfig;

	YawSensitivity = OtherCameraMode->YawSensitivity;
	PitchSensitivity = OtherCameraMode->PitchSensitivity;

	FOVCurve = OtherCameraMode->FOVCurve;
	TargetLocationOffsetCurve = OtherCameraMode->TargetLocationOffsetCurve;
 
	bAdsorptionZoom = false;
	bRevertZoom = false;
	bCustomRoleMode = false;
	bAdaptiveViewOffset = false;

	OverrideZoom = OtherCameraMode->OverrideZoom;
	RotDelta = OtherCameraMode->RotDelta;
	FOVDelta = OtherCameraMode->FOVDelta;
	if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
	{
		Camera->ResetConfig();
		auto* Arm = Camera->GetCameraArmComponent();
		Arm->SetZoomSetting(BasicConfig.ZoomMinLen, BasicConfig.ZoomMaxLen);
		Arm->SetOverrideZoom(OverrideZoom.GetValue());
		Arm->SetZoomOffset(ZoomDelta);
		Arm->SetTargetRotOffsetByRotator(RotDelta);
		Camera->SetCameraFOV(GetDesiredFOV());
		Arm->InitArmLagParam(static_cast<ECameraEaseFunction::Type>(BasicConfig.ZoomLagEaseType), BasicConfig.ZoomLagEaseParam, BasicConfig.ZoomLagEaseCurveID);
		Arm->InitLocationLagParamForZ(static_cast<ECameraEaseFunction::Type>(BasicConfig.ZLagEaseType), BasicConfig.ZLagEaseParam, BasicConfig.ZLagEaseCurveID, BasicConfig.SoftZoneRadiusZ);
		Arm->InitLocationLagParamForXOY(static_cast<ECameraEaseFunction::Type>(BasicConfig.XOYLagEaseType), BasicConfig.XOYLagEaseParam, BasicConfig.XOYLagEaseCurveID, BasicConfig.SoftZoneRadiusXOY);
		Arm->InitCollisionReleaseLagParam(static_cast<ECameraEaseFunction::Type>(BasicConfig.ReleaseLagEaseType), BasicConfig.ReleaseLagEaseParam, BasicConfig.ReleaseLagEaseCurveID);
		Arm->InitCollisionCompressLagParam(static_cast<ECameraEaseFunction::Type>(BasicConfig.CompressLagEaseType), BasicConfig.CompressLagEaseParam, BasicConfig.CompressLagEaseCurveID);
		FVector ViewOffset = BasicConfig.ViewOffset.GetValue();
		Arm->SetPivotOffsetFromScreenCoOffset(ViewOffset.X, ViewOffset.Y);
		Arm->EnableDitherFade(BasicConfig.bEnableDitherFade, BasicConfig.DitherFadeObjectTypesForStatic, BasicConfig.DitherFadeObjectTypesForDynamic, BasicConfig.DetectType, BasicConfig.DetectRadius, BasicConfig.DetectPitch, BasicConfig.DitherFadeStaticDetectInterval, BasicConfig.DitherFadeDynamicDetectInterval, BasicConfig.CameraPosDiffThreshold);

		Camera->SetControlConfig(this);
		Camera->GetCameraArmComponent()->SetControlConfig(this);
	}
}

void UKgCameraMode::RefreshControlData(
	int InPriority,
	float ZoomMin, float ZoomMax, float ZoomStep, float NewFOV,
	int EaseTypeZoomLag, float ParamZoomLag, int64 CurveIDZoomLag,
	int EaseTypeZLag, float ParamZLag, int64 CurveIDZLag, float NewSoftZoneRadiusZ,
	int EaseTypeXOYLag, float ParamXOYLag, int64 CurveIDXOYLag, float NewSoftZoneRadiusXOY,
	int EaseTypeRelease, float ParamRelease, int64 CurveIDRelease,
	int EaseTypeCompress, float ParamCompress, int64 CurveIDCompress,
	float ViewOffX, float ViewOffY,
	bool bEnableDitherFade, const TArray<int>& NewDitherFadeObjectTypesForStatic, const TArray<int>& NewDitherFadeObjectTypesForDynamic,
	int DetectType, float DetectRadius, float DetectPitch, float StaticDetectInterval, float DynamicDetectInterval, float CameraPosDiffThreshold,
	float InInitArmLen, const FRotator& InInitRot,
	float InYawSensitivity, float InPitchSensitivity, int64 TargetLocationOffsetCurveID, int64 FOVCurveID
)
{
	CameraModePriority = InPriority;
	BasicConfig.DefaultFOV.SetValueByPriority(NewFOV);
	BasicConfig.ZoomMinLen.SetValueByPriority(ZoomMin);
	BasicConfig.ZoomMaxLen.SetValueByPriority(ZoomMax);
	BasicConfig.ZoomStep = ZoomStep;
	BasicConfig.ArmInitZoomLen = InInitArmLen;
	BasicConfig.ArmInitRotation = InInitRot;
	BasicConfig.ZoomLagEaseType = static_cast<ECameraEaseFunction::Type>(EaseTypeZoomLag);
	BasicConfig.ZoomLagEaseParam.SetValueByPriority(ParamZoomLag);
	BasicConfig.ZoomLagEaseCurveID = CurveIDZoomLag;
	BasicConfig.ZLagEaseType = static_cast<ECameraEaseFunction::Type>(EaseTypeZLag);
	BasicConfig.ZLagEaseParam.SetValueByPriority(ParamZLag);
	BasicConfig.ZLagEaseCurveID = CurveIDZLag;
	BasicConfig.SoftZoneRadiusZ.SetValueByPriority(NewSoftZoneRadiusZ);
	BasicConfig.XOYLagEaseType = static_cast<ECameraEaseFunction::Type>(EaseTypeXOYLag);
	BasicConfig.XOYLagEaseParam.SetValueByPriority(ParamXOYLag);
	BasicConfig.XOYLagEaseCurveID = CurveIDXOYLag;
	BasicConfig.RotationLagEaseParam = ECameraEaseFunction::Decay;
	BasicConfig.RotationLagEaseParam.SetValueByPriority(0);
	BasicConfig.RotationLagEaseCurveID = KG_INVALID_ID;
	BasicConfig.SoftZoneRadiusXOY.SetValueByPriority(NewSoftZoneRadiusXOY);
	BasicConfig.ReleaseLagEaseType = static_cast<ECameraEaseFunction::Type>(EaseTypeRelease);
	BasicConfig.ReleaseLagEaseParam.SetValueByPriority(ParamRelease);
	BasicConfig.ReleaseLagEaseCurveID = CurveIDRelease;
	BasicConfig.CompressLagEaseType = static_cast<ECameraEaseFunction::Type>(EaseTypeCompress);
	BasicConfig.CompressLagEaseParam.SetValueByPriority(ParamCompress);
	BasicConfig.CompressLagEaseCurveID = CurveIDCompress;
	BasicConfig.ViewOffset.SetValueByPriority({ViewOffX, ViewOffY, 0});
	BasicConfig.bEnableDitherFade = bEnableDitherFade;
	BasicConfig.DitherFadeObjectTypesForStatic = NewDitherFadeObjectTypesForStatic;
	BasicConfig.DitherFadeObjectTypesForDynamic = NewDitherFadeObjectTypesForDynamic;
	BasicConfig.DitherFadeStaticDetectInterval = StaticDetectInterval;
	BasicConfig.DitherFadeDynamicDetectInterval = DynamicDetectInterval;
	BasicConfig.CameraPosDiffThreshold = CameraPosDiffThreshold;
	BasicConfig.DetectType = static_cast<EDitherFadeDetectType>(DetectType);
	BasicConfig.DetectRadius = DetectRadius;
	BasicConfig.DetectPitch = DetectPitch;

	YawSensitivity.SetValueByPriority(InYawSensitivity);
	PitchSensitivity.SetValueByPriority(InPitchSensitivity);

	SetCameraFOVCurveFromID(FOVCurveID);
	SetCameraTargetLocationOffsetCurveFromID(TargetLocationOffsetCurveID);

	bAdsorptionZoom = false;
	bRevertZoom = false;
	bCustomRoleMode = false;
	bAdaptiveViewOffset = false;

	if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
	{
		Camera->ResetConfig();
		auto* Arm = Camera->GetCameraArmComponent();
		Arm->SetZoomSetting(BasicConfig.ZoomMinLen, BasicConfig.ZoomMaxLen);
		Arm->SetOverrideZoom(OverrideZoom.GetValue());
		Arm->SetZoomOffset(ZoomDelta);
		Arm->SetTargetRotOffsetByRotator(RotDelta);
		Camera->SetCameraFOV(GetDesiredFOV());
		Arm->InitArmLagParam(static_cast<ECameraEaseFunction::Type>(EaseTypeZoomLag), ParamZoomLag, CurveIDZoomLag);
		Arm->InitLocationLagParamForZ(static_cast<ECameraEaseFunction::Type>(EaseTypeZLag), ParamZLag, CurveIDZLag, NewSoftZoneRadiusZ);
		Arm->InitLocationLagParamForXOY(static_cast<ECameraEaseFunction::Type>(EaseTypeXOYLag), ParamXOYLag, CurveIDXOYLag, NewSoftZoneRadiusXOY);
		Arm->InitCollisionReleaseLagParam(static_cast<ECameraEaseFunction::Type>(EaseTypeRelease), ParamRelease, CurveIDRelease);
		Arm->InitCollisionCompressLagParam(static_cast<ECameraEaseFunction::Type>(EaseTypeCompress), ParamCompress, CurveIDCompress);
		Arm->SetPivotOffsetFromScreenCoOffset(ViewOffX, ViewOffY);
		Arm->EnableDitherFade(bEnableDitherFade, NewDitherFadeObjectTypesForStatic, NewDitherFadeObjectTypesForDynamic, DetectType, DetectRadius, DetectPitch, StaticDetectInterval, DynamicDetectInterval, CameraPosDiffThreshold);

		Camera->SetControlConfig(this);
		Camera->GetCameraArmComponent()->SetControlConfig(this);
	}
}

void UKgCameraMode::SetInitArmLenAndDir(float TargetArmLen, const FRotator& TargetRot, const FRotator& BaseSpace,
                                        bool bSyncPlayerController)
{
	FQuat Result = BaseSpace.Quaternion() * TargetRot.Quaternion();
	if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
	{
		Camera->GetCameraArmComponent()->OnUpdateZoom(TargetArmLen, true);
		Camera->GetCameraArmComponent()->SetZoomOffset(ZoomDelta);
	}

	if(ACameraActor* CameraActor = Cast<ACameraActor>(GetCurCamera()))
	{
		CameraActor->SetActorRotation(Result);
	}

	if(bSyncPlayerController && CurCameraMgr.IsValid())
	{
		if(APlayerController* PC = CurCameraMgr->PCOwner)
		{
			PC->SetControlRotation(Result.Rotator());
		}
	}

	if (UCameraArmComponent* Arm = GetCameraArmComponent())
	{
		Arm->SetTargetRotOffsetByRotator(RotDelta);
	}
}

void UKgCameraMode::InitRotationLagParam(bool bNewEnableCameraRotationLag, ECameraEaseFunction::Type EaseType,
                                         float Param, int64 CurveID)
{
	BasicConfig.RotationLagEaseType = static_cast<ECameraEaseFunction::Type>(EaseType);
	BasicConfig.RotationLagEaseParam = Param;
	BasicConfig.RotationLagEaseCurveID = CurveID;
	
	if(UCameraArmComponent* Arm = GetCameraArmComponent())
	{
		Arm->InitRotationLagParam(bNewEnableCameraRotationLag, EaseType, Param, CurveID);
	}
}

void UKgCameraMode::ForceUpdate(bool bDoTrace)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(CurCameraPtr.Get()))
	{
		Camera->ForceUpdateCamera(bDoTrace);
	}
}

void UKgCameraMode::ForceUpdateWithBaseCollision()
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(CurCameraPtr.Get()))
	{
		Camera->ForceUpdateCameraWithBaseCollision();
	}
}

void UKgCameraMode::SetCameraRotSensitivity(float Yaw, float Pitch, int InPriority)
{
	YawSensitivity.SetValueByPriority(Yaw, InPriority);
	PitchSensitivity.SetValueByPriority(Pitch, InPriority);
}

void UKgCameraMode::RemoveCameraRotSensitivity(int InPriority)
{
	if(InPriority != 0)
	{
		YawSensitivity.RemoveValueByPriority(InPriority);
		PitchSensitivity.RemoveValueByPriority(InPriority);
	}
}

float UKgCameraMode::GetCameraRotYawSensitivity()
{
	return YawSensitivity.GetValue();
}

float UKgCameraMode::GetCameraRotPitchSensitivity()
{
	return PitchSensitivity.GetValue();
}

void UKgCameraMode::SetZoomSetting(float Min, float Max, int InPriority)
{
	BasicConfig.ZoomMinLen.SetValueByPriority(Min, InPriority);
	BasicConfig.ZoomMaxLen.SetValueByPriority(Max, InPriority);

	if(bActivate)
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
		{
			Camera->GetCameraArmComponent()->SetZoomSetting(BasicConfig.ZoomMinLen, BasicConfig.ZoomMaxLen);
		}	
	}
}

void UKgCameraMode::GetZoomSetting(float& Min, float& Max) const
{
	Min = BasicConfig.ZoomMinLen.GetValue();
	Max = BasicConfig.ZoomMaxLen.GetValue();
}

void UKgCameraMode::SetZoomMaxSetting(float Max, int InPriority)
{
	BasicConfig.ZoomMaxLen.SetValueByPriority(Max, InPriority);

	if(bActivate)
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
		{
			Camera->GetCameraArmComponent()->SetZoomSetting(BasicConfig.ZoomMinLen, BasicConfig.ZoomMaxLen);
		}
	}
}

void UKgCameraMode::RemoveZoomSetting(int InPriority, bool bNeedZoomFix)
{
	BasicConfig.ZoomMinLen.RemoveValueByPriority(InPriority);
	BasicConfig.ZoomMaxLen.RemoveValueByPriority(InPriority);

	if(bActivate)
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
		{
			// 目前需求 在回到Base设置的时候看bNeedZoomFix 做恢复
			if(bNeedZoomFix && InPriority != 0 && (BasicConfig.ZoomMinLen.GetTopPriority() == 0 || BasicConfig.ZoomMaxLen.GetTopPriority() == 0))
			{
				Camera->GetCameraArmComponent()->SetZoomSetting(BasicConfig.ZoomMinLen, BasicConfig.ZoomMaxLen, true);
			}
			else
			{
				Camera->GetCameraArmComponent()->SetZoomSetting(BasicConfig.ZoomMinLen, BasicConfig.ZoomMaxLen);
			}
		}
	}
}

void UKgCameraMode::SetFOVSetting(float NewFOV, int InPriority)
{
	BasicConfig.DefaultFOV.SetValueByPriority(NewFOV, InPriority);

	if(BasicConfig.DefaultFOV.IsTopPriority(InPriority))
	{
		if(bActivate)
		{
			if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
			{
				Camera->SetCameraFOV(GetDesiredFOV());
			}	
		}
	}
}

float UKgCameraMode::GetFOVBelowPriority(int InPriority, float DefaultValue)
{
	return BasicConfig.DefaultFOV.GetValueBelowPriority(InPriority, DefaultValue);
}

void UKgCameraMode::AddFOVDelta(float NewFOVDelta)
{
	if(bActivate)
	{
		FOVDelta += NewFOVDelta;
		if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
		{
			Camera->SetCameraFOV(GetDesiredFOV());
		}
	}
}

void UKgCameraMode::AddZoomDelta(float NewZoomDelta)
{
	if(bActivate)
	{
		ZoomDelta += NewZoomDelta;
		if(UCameraArmComponent* ArmComponent = GetCameraArmComponent())
		{
			ArmComponent->SetZoomOffset(ZoomDelta);
		}
	}
}

void UKgCameraMode::RemoveFOVSetting(int InPriority)
{
	bool bIsTopPriority = BasicConfig.DefaultFOV.IsTopPriority(InPriority);
	BasicConfig.DefaultFOV.RemoveValueByPriority(InPriority);

	if(bIsTopPriority)
	{
		float TargetFOV = GetDesiredFOV();

		if(bActivate)
		{
			if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
			{
				Camera->SetCameraFOV(TargetFOV);
			}
		}
	}
}

void UKgCameraMode::SetCameraLookAt(int64 TargetActorID, int64 ControlActorID, const FName& NewBoneName, float NewBoneOffsetX,
                                    float NewBoneOffsetY, float NewBoneOffsetZ, ERelativeTransformSpace InTransformSpace)
{
	AActor* Target = KGUtils::GetActorByID(TargetActorID);
	AActor* Control = KGUtils::GetActorByID(ControlActorID);
	BasicConfig.LookAtTarget = Target;
	BasicConfig.ControlTarget = Control;
	BasicConfig.LookAtBoneName = NewBoneName;
	BasicConfig.LookAtBoneOffset = {NewBoneOffsetX, NewBoneOffsetY, NewBoneOffsetZ};
	BasicConfig.BoneOffsetTransSpace = InTransformSpace;

	if(bActivate)
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
		{
			Camera->SetLookAtTarget(Target, Control, BasicConfig.LookAtBoneName, BasicConfig.LookAtBoneOffset, BasicConfig.BoneOffsetTransSpace);
		}
	}
}

void UKgCameraMode::SetCameraLookAtWithStaticBoneOffsetZ(int64 TargetActorID, int64 ControlActorID,
	const FName& NewBoneName, float NewBoneOffsetX, float NewBoneOffsetY, float NewBoneOffsetZ,
	ERelativeTransformSpace InTransformSpace)
{
	AActor* Target = KGUtils::GetActorByID(TargetActorID);
	AActor* Control = KGUtils::GetActorByID(ControlActorID);
	BasicConfig.LookAtTarget = Target;
	BasicConfig.ControlTarget = Control;
	BasicConfig.LookAtBoneName = NAME_None;
	BasicConfig.LookAtBoneOffset = {NewBoneOffsetX, NewBoneOffsetY, NewBoneOffsetZ};
	BasicConfig.BoneOffsetTransSpace = InTransformSpace;

	if (Target != nullptr)
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(CurCameraPtr.Get()))
		{
			if(USkeletalMeshComponent* SKMesh = Target->GetComponentByClass<USkeletalMeshComponent>())
			{
				if (SKMesh->DoesSocketExist(NewBoneName))
				{
					FVector LookAtBoneLoc = SKMesh->GetSocketLocation(NewBoneName);
					BasicConfig.LookAtBoneOffset.Z += LookAtBoneLoc.Z - Target->GetActorLocation().Z;
				}
			}
		}
	}

	if(bActivate)
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
		{
			Camera->SetLookAtTarget(Target, Control, BasicConfig.LookAtBoneName, BasicConfig.LookAtBoneOffset, BasicConfig.BoneOffsetTransSpace);
		}
	}
}

AActor* UKgCameraMode::GetCameraLookAt()
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
	{
		return Camera->GetLookAtTarget();
	}
	return nullptr;
}

void UKgCameraMode::SetCameraLookAtWithWorldLoc(int64 TargetActorID, int64 ControlActorID, const FVector& WorldLoc)
{
	AActor* Target = KGUtils::GetActorByID(TargetActorID);
	AActor* Control = KGUtils::GetActorByID(ControlActorID);
	BasicConfig.LookAtTarget = Target;
	BasicConfig.ControlTarget = Control;
	BasicConfig.LookAtBoneName = NAME_None;
	BasicConfig.LookAtBoneOffset = FVector::ZeroVector;
	BasicConfig.BoneOffsetTransSpace = ERelativeTransformSpace::RTS_World;

	if(bActivate)
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
		{
			Camera->SetLookAtTarget(Target, Control, BasicConfig.LookAtBoneName, BasicConfig.LookAtBoneOffset, BasicConfig.BoneOffsetTransSpace);
			Camera->SetActorLocation(WorldLoc);
			Camera->ForceUpdateCamera(true);
		}
	}
}

void UKgCameraMode::SetCameraLookAtWithPivotLoc(int64 TargetActorID, int64 ControlActorID, const FVector& WorldPivotLoc,
                                                const FRotator& CameraRot, float Zoom)
{
	AActor* Target = KGUtils::GetActorByID(TargetActorID);
	AActor* Control = KGUtils::GetActorByID(ControlActorID);
	BasicConfig.LookAtTarget = Target;
	BasicConfig.ControlTarget = Control;
	BasicConfig.LookAtBoneName = NAME_None;
	BasicConfig.LookAtBoneOffset = FVector::ZeroVector;
	BasicConfig.BoneOffsetTransSpace = ERelativeTransformSpace::RTS_World;

	if(bActivate)
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
		{
			if(Target == nullptr)
			{
				Camera->SetLookAtTarget(Target, Control, BasicConfig.LookAtBoneName, BasicConfig.LookAtBoneOffset, BasicConfig.BoneOffsetTransSpace);
				Camera->SetActorLocation(WorldPivotLoc);
				SetInitArmLenAndDir(Zoom, CameraRot, FRotator::ZeroRotator, false);
			}
			else
			{
				FRotator NormalizeRot = CameraRot;
				FVector ActorLoc = Target->GetActorLocation();
				NormalizeRot.Pitch = 0;
				SetInitArmLenAndDir(Zoom, CameraRot, FRotator::ZeroRotator, false);
				Camera->SetLookAtTarget(Target, Control, BasicConfig.LookAtBoneName, BasicConfig.LookAtBoneOffset, BasicConfig.BoneOffsetTransSpace);
				Camera->GetCameraArmComponent()->SetTargetOffset(FTransform(NormalizeRot).InverseTransformVector(WorldPivotLoc - ActorLoc));
			}
			Camera->ForceUpdateCamera(true);
		}
	}
}

void UKgCameraMode::SetCameraRotationLagSetting(float Param, int InPriority)
{
	BasicConfig.RotationLagEaseParam.SetValueByPriority(Param, InPriority);
	if(bActivate)
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
		{
			Camera->GetCameraArmComponent()->SetRotationLagParam(BasicConfig.RotationLagEaseParam.GetValue());
		}
	}
}

void UKgCameraMode::RemoveCameraRotationLagSetting(int InPriority)
{
	BasicConfig.RotationLagEaseParam.RemoveValueByPriority(InPriority);
	if(bActivate)
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
		{
			Camera->GetCameraArmComponent()->SetRotationLagParam(BasicConfig.RotationLagEaseParam.GetValue());
		}
	}
}

void UKgCameraMode::SetCameraXOYLagSetting(float Param, int InPriority)
{
	BasicConfig.XOYLagEaseParam.SetValueByPriority(Param, InPriority);
	if(bActivate)
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
		{
			Camera->GetCameraArmComponent()->SetLocationLagParamForXOY(BasicConfig.XOYLagEaseParam.GetValue());
		}
	}
}

float UKgCameraMode::GetXOYLagBelowPriority(int InPriority, float DefaultValue)
{
	return BasicConfig.XOYLagEaseParam.GetValueBelowPriority(InPriority, DefaultValue);
}

void UKgCameraMode::RemoveCameraXOYLagSetting(int InPriority)
{
	BasicConfig.XOYLagEaseParam.RemoveValueByPriority(InPriority);
	if(bActivate)
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
		{
			Camera->GetCameraArmComponent()->SetLocationLagParamForXOY(BasicConfig.XOYLagEaseParam.GetValue());
		}
	}
}

void UKgCameraMode::SetCameraZLagSetting(float Param, int InPriority)
{
	BasicConfig.ZLagEaseParam.SetValueByPriority(Param, InPriority);
	if(bActivate)
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
		{
			Camera->GetCameraArmComponent()->SetLocationLagParamForZ(BasicConfig.ZLagEaseParam.GetValue());
		}
	}
}

float UKgCameraMode::GetZLagBelowPriority(int InPriority, float DefaultValue)
{
	return BasicConfig.ZLagEaseParam.GetValueBelowPriority(InPriority, DefaultValue);
}

void UKgCameraMode::RemoveCameraZLagSetting(int InPriority)
{
	BasicConfig.ZLagEaseParam.RemoveValueByPriority(InPriority);
	if(bActivate)
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
		{
			Camera->GetCameraArmComponent()->SetLocationLagParamForZ(BasicConfig.ZLagEaseParam.GetValue());
		}
	}
}

void UKgCameraMode::SetCameraXOYSoftRadiusSetting(float Param, int InPriority)
{
	BasicConfig.SoftZoneRadiusXOY.SetValueByPriority(Param, InPriority);
	if(bActivate)
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
		{
			Camera->GetCameraArmComponent()->SetLocationSoftRadiusParamForXOY(BasicConfig.SoftZoneRadiusXOY.GetValue());
		}
	}
}

float UKgCameraMode::GetXOYSoftRadiusBelowPriority(int InPriority, float DefaultValue)
{
	return BasicConfig.SoftZoneRadiusXOY.GetValueBelowPriority(InPriority, DefaultValue);
}

void UKgCameraMode::RemoveCameraXOYSoftRadiusSetting(int InPriority)
{
	BasicConfig.SoftZoneRadiusXOY.RemoveValueByPriority(InPriority);
	if(bActivate)
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
		{
			Camera->GetCameraArmComponent()->SetLocationSoftRadiusParamForXOY(BasicConfig.SoftZoneRadiusXOY.GetValue());
		}
	}
}

void UKgCameraMode::SetCameraZSoftRadiusSetting(float Param, int InPriority)
{
	BasicConfig.SoftZoneRadiusZ.SetValueByPriority(Param, InPriority);
	if(bActivate)
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
		{
			Camera->GetCameraArmComponent()->SetLocationSoftRadiusParamForZ(BasicConfig.SoftZoneRadiusZ.GetValue());
		}
	}
}

float UKgCameraMode::GetZSoftRadiusBelowPriority(int InPriority, float DefaultValue)
{
	return BasicConfig.SoftZoneRadiusZ.GetValueBelowPriority(InPriority, DefaultValue);
}

void UKgCameraMode::RemoveCameraZSoftRadiusSetting(int InPriority)
{
	BasicConfig.SoftZoneRadiusZ.RemoveValueByPriority(InPriority);
	if(bActivate)
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
		{
			Camera->GetCameraArmComponent()->SetLocationLagParamForZ(BasicConfig.ZLagEaseParam.GetValue());
		}
	}
}


void UKgCameraMode::SetViewAngleSetting(float InViewPitchMin, float InViewPitchMax, float InViewYawMin,
                                        float InViewYawMax, float InViewRollMin, float InViewRollMax,
                                        int InPriority)
{
	SetViewPitchSetting(InViewPitchMin, InViewPitchMax, InPriority);
	SetViewYawSetting(InViewYawMin, InViewYawMax, InPriority);
	SetViewRollSetting(InViewRollMin, InViewRollMax, InPriority);
}

void UKgCameraMode::RemoveViewAngleSetting(int InPriority)
{
	BasicConfig.CustomViewPitchMin.RemoveValueByPriority(InPriority);
	BasicConfig.CustomViewPitchMax.RemoveValueByPriority(InPriority);
	BasicConfig.CustomViewYawMin.RemoveValueByPriority(InPriority);
	BasicConfig.CustomViewYawMax.RemoveValueByPriority(InPriority);
	BasicConfig.CustomViewRollMin.RemoveValueByPriority(InPriority);
	BasicConfig.CustomViewRollMax.RemoveValueByPriority(InPriority);
}

void UKgCameraMode::SetViewPitchSetting(float Min, float Max, int InPriority)
{
	BasicConfig.CustomViewPitchMin.SetValueByPriority(Min, InPriority);
	BasicConfig.CustomViewPitchMax.SetValueByPriority(Max, InPriority);
}

void UKgCameraMode::SetPivotOffsetFromScreenCoOffsetSetting(float OffX, float OffY, int InPriority)
{
	BasicConfig.ViewOffset.SetValueByPriority({OffX, OffY, 0}, InPriority);
	if(BasicConfig.ViewOffset.IsTopPriority(InPriority))
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
		{
			auto Offset = BasicConfig.ViewOffset.GetValue();
			Camera->GetCameraArmComponent()->SetPivotOffsetFromScreenCoOffset(Offset.X, Offset.Y);
		}
	}
}

void UKgCameraMode::RemovePivotOffsetFromScreenCoOffsetSetting(int InPriority)
{
	bool bIsTop = BasicConfig.ViewOffset.IsTopPriority(InPriority);
	BasicConfig.ViewOffset.RemoveValueByPriority(InPriority);
	if(bIsTop)
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
		{
			auto Offset = BasicConfig.ViewOffset.GetValue();
			Camera->GetCameraArmComponent()->SetPivotOffsetFromScreenCoOffset(Offset.X, Offset.Y);
		}
	}
}

FVector2D UKgCameraMode::GetPivotOffsetBelowPriority(int InPriority, const FVector2D& DefaultValue)
{
	FVector Default;
	Default.X = DefaultValue.X;
	Default.Y = DefaultValue.Y;
	Default = BasicConfig.ViewOffset.GetValueBelowPriority(InPriority, Default);
	return {Default.X, Default.Y};
}

FVector2D UKgCameraMode::GetPivotOffsetSetting()
{
	FVector Result = BasicConfig.ViewOffset.GetValue();
	return {Result.X, Result.Y};
}

void UKgCameraMode::SetCameraSocketRotOffsetSetting(const FRotator& Offset, int InPriority)
{
	BasicConfig.CameraSocketRotOffset.SetValueByPriority(Offset, InPriority);
	if(BasicConfig.CameraSocketRotOffset.IsTopPriority(InPriority))
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
		{
			Camera->GetCameraArmComponent()->SetSocketRotOffset(BasicConfig.CameraSocketRotOffset.GetValue());
		}
	}
}

void UKgCameraMode::RemoveCameraSocketRotOffsetSetting(int InPriority)
{
	bool bIsTop = BasicConfig.CameraSocketRotOffset.IsTopPriority(InPriority);
	BasicConfig.CameraSocketRotOffset.RemoveValueByPriority(InPriority);
	if(bIsTop)
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
		{
			auto Offset = BasicConfig.CameraSocketRotOffset.GetValue();
			Camera->GetCameraArmComponent()->SetSocketRotOffset(Offset);
		}
	}
}

FRotator UKgCameraMode::GetCameraSocketRotOffsetBelowPriority(int InPriority, const FRotator& DefaultValue)
{
	return BasicConfig.CameraSocketRotOffset.GetValueBelowPriority(InPriority, DefaultValue);
}

FRotator UKgCameraMode::GetCameraSocketRotOffsetSetting()
{
	return BasicConfig.CameraSocketRotOffset.GetValue();
}

void UKgCameraMode::SetZoomWithAdsorption(float InAdsorptionSpeedX, float InAdsorptionSpeedXY, float InMaxX, float InMaxY, float InMaxYNeg, int EaseType, float InAdsorptionMinZoom, float InAdsorptionMaxZoom)
{
	bAdsorptionZoom = true;
	AdsorptionSpeed.X = InAdsorptionSpeedX;
	AdsorptionSpeed.Y = InAdsorptionSpeedXY;
	AdsorptionSpeedThreshold.X = InMaxX;
	AdsorptionSpeedThreshold.Y = InMaxY;
	AdsorptionSpeedThreshold.Z = InMaxYNeg;
	AdsorptionEaseType = static_cast<ECameraEaseFunction::Type>(EaseType);

	AdsorptionMinZoom = InAdsorptionMinZoom;
	AdsorptionMaxZoom = InAdsorptionMaxZoom;
}

void UKgCameraMode::CancelZoomAdsorption()
{
	bAdsorptionZoom = false;
	bRevertZoom = false;
	if(bActivate)
	{
		if(UCameraArmComponent* Arm = GetCameraArmComponent())
		{
			Arm->SetSocketOffset(0, 0, 0);
		}
	}
}

void UKgCameraMode::SetCustomRotAndOffWithRecover(float DesiredPitch, float DesiredYaw, float DesiredRoll, float X,
                                                  float Y, float Z, float BasePitch, float BaseYaw, float BaseRoll,
                                                  ECameraEaseFunction::Type InRecoverEaseType)
{
	bRotWithRecover = true;
	FRotator BaseRot = {BasePitch, BaseYaw, BaseRoll};

	RotWithRecover.Pitch = DesiredPitch;
	RotWithRecover.Yaw = DesiredYaw;
	RotWithRecover.Roll = DesiredRoll;
	RotWithRecover = (RotWithRecover - BaseRot).GetNormalized();

	OffWithRecover.X = X;
	OffWithRecover.Y = Y;
	OffWithRecover.Z = Z;

	RecoverEaseType = InRecoverEaseType;
	if(bActivate)
	{
		if(ABaseCamera* Camera = GetCamera())
		{
			Camera->SetBoneOffset(OffWithRecover, ERelativeTransformSpace::RTS_World);
			GetCameraArmComponent()->SetTargetRotOffsetByRotator(RotWithRecover);
		}
	}
}

void UKgCameraMode::CancelCustomRotAndOffWithRecover()
{
	bRotWithRecover = false;
	RotWithRecover = FRotator::ZeroRotator;
	OffWithRecover = FVector::ZeroVector;
	if(bActivate)
	{
		if(ABaseCamera* Camera = GetCamera())
		{
			Camera->SetBoneOffset(OffWithRecover, ERelativeTransformSpace::RTS_World);
			GetCameraArmComponent()->SetTargetRotOffsetByRotator(RotWithRecover);
		}
	}
}

void UKgCameraMode::AddRotDelta(const FRotator& NewZoomDelta)
{
	if(bActivate)
	{
		RotDelta += NewZoomDelta;
		if(UCameraArmComponent* ArmComponent = GetCameraArmComponent())
		{
			ArmComponent->SetTargetRotOffsetByRotator(RotDelta);
		}
	}
}

void UKgCameraMode::UpdateZoomWithPivotAdsorption(float TargetZoom)
{
	if(!CurCameraMgr.IsValid())
	{
		return;
	}

	CurCameraMgr->PCOwner->GetMousePosition(MouseCoPos.X, MouseCoPos.Y);
	if(UCameraArmComponent* Arm = GetCameraArmComponent())
	{
		float CurrentBaseZoomLen = Arm->GetCameraCurrentBaseZoomLen();
		if(TargetZoom > CurrentBaseZoomLen)
		{
			bRevertZoom = true;
			if(!FMath::IsNearlyEqual(CurrentBaseZoomLen, TargetZoom, 0.01f))
			{
				RevertZoom = Arm->GetCameraCurrentBaseZoomLen();
				RevertSocketOffset = Arm->GetSocketOffset();
			}
		}
		else if(bRevertZoom && TargetZoom <= CurrentBaseZoomLen)
		{
			bRevertZoom = false;
		}
		Arm->OnUpdateZoom(TargetZoom);
	}
}

void UKgCameraMode::AddSocketOffZWithPivotAdsorption(float Value)
{
	if(bAdsorptionZoom)
	{
		if(bActivate)
		{
			if(UCameraArmComponent* Arm = GetCameraArmComponent())
			{
				float SocketZ = Arm->GetSocketOffsetZ();
				Arm->SetSocketOffsetZ(SocketZ + Value);
			}
		}
	}
}

void UKgCameraMode::GetAdsorptionUpAndDownThreshold(float Height, float& DownThreshold, float& UpThreshold)
{
	AActor* LookAt = BasicConfig.LookAtTarget.Get();
	if(LookAt == nullptr)
	{
		DownThreshold = Height / 2.f;
		UpThreshold = Height / 2.f;
	}
	FName LookAtName = BasicConfig.LookAtBoneName;
	float LookAtZ = 0.f;
	if(LookAt != nullptr)
	{
		if(IC7ActorInterface* C7Actor = Cast<IC7ActorInterface>(LookAt))
		{
			if(USkeletalMeshComponent* SKMesh = C7Actor->GetMainMesh())
			{
				LookAtZ = LookAt->GetActorLocation().Z - SKMesh->GetComponentLocation().Z;
				if(!LookAtName.IsNone() && SKMesh->DoesSocketExist(LookAtName))
				{
					FTransform LookAtTM = SKMesh->GetSocketTransform(LookAtName, ERelativeTransformSpace::RTS_Component);
					LookAtZ = LookAtTM.GetLocation().Z;
				}
			}
		}
	}
	DownThreshold = LookAtZ;
	UpThreshold = Height - LookAtZ;
}

void UKgCameraMode::SetCustomRoleLookAtBone(int64 LookAtTargetID, const FName& LookAtBone, float LookAtScreenX,
                                            float LookAtScreenY, const FName& CloseUpBone, float CloseUpScreenX, float CloseUpScreenY, float ViewOffsetHalfLife,
                                            float MaxZoom, float MinZoom, float ThresholdZoom, float InitZoom, float LookAtYaw, float CloseUpYaw,
                                            float InitPitch, float InitRoll, float PitchMin, float PitchMaxCloseUp, float PitchMaxThreshold, float YawMin,
                                            float YawMax)
{
	// 计算两个骨骼 Z轴Offset
	if(AActor* LookAtActor = KGUtils::GetActorByID(LookAtTargetID))
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(CurCameraPtr.Get()))
		{
			if(USkeletalMeshComponent* SKMesh = LookAtActor->GetComponentByClass<USkeletalMeshComponent>())
			{
				CustomRoleViewOffsetHalfLife = ViewOffsetHalfLife;
				FVector LookAtBoneLoc = SKMesh->GetSocketLocation(LookAtBone);
				FVector CloseUpBoneLoc = SKMesh->GetSocketLocation(CloseUpBone);
				CloseUpZOffset = CloseUpBoneLoc.Z - LookAtBoneLoc.Z;
				CustomRoleThresholdZoom = ThresholdZoom;
				CustomRoleLookAtRot.Yaw = LookAtYaw;
				CustomRoleCloseUpRot.Yaw = CloseUpYaw;
				CustomRoleCloseUpViewOffset.X = CloseUpScreenX;
				CustomRoleCloseUpViewOffset.Y = CloseUpScreenY;
				CustomRoleZoomDynamicMaxZoom = MaxZoom;

				BasicConfig.LookAtTarget = LookAtActor;
				BasicConfig.ControlTarget.Reset();
				BasicConfig.LookAtBoneName = NAME_None;
				LookAtZOffset = LookAtBoneLoc.Z - LookAtActor->GetActorLocation().Z;
				BasicConfig.LookAtBoneOffset = {0, 0, LookAtZOffset};
				BasicConfig.BoneOffsetTransSpace = ERelativeTransformSpace::RTS_Actor;
				bCustomRoleMode = true;
				float ThresholdRatio = MinZoom != ThresholdZoom ? FMath::Clamp((InitZoom - MinZoom) / (ThresholdZoom - MinZoom), 0.f, 1.f) : 1.f;
				CachedThresholdRatio = ThresholdRatio;
				// 初始化起始视角
				if(bActivate)
				{
					UCameraArmComponent* Arm = Camera->GetCameraArmComponent();
					Camera->SetLookAtTarget(LookAtActor, nullptr, BasicConfig.LookAtBoneName, BasicConfig.LookAtBoneOffset, BasicConfig.BoneOffsetTransSpace);
					float BoneOffsetZ = FMath::Lerp(LookAtZOffset + CloseUpZOffset, LookAtZOffset, ThresholdRatio);
					Camera->SetBoneOffsetZ(BoneOffsetZ);
					Arm->SetTargetRotOffsetByRotator(FMath::Lerp(CustomRoleLookAtRot, CustomRoleCloseUpRot, ThresholdRatio));
					SetPivotOffsetFromScreenCoOffsetSetting(LookAtScreenX, LookAtScreenY, 0);
					Arm->SetPivotOffsetFromScreenCoOffset(FMath::Lerp(CustomRoleCloseUpViewOffset.X, LookAtScreenX, ThresholdRatio), FMath::Lerp(CustomRoleCloseUpViewOffset.Y, LookAtScreenY, ThresholdRatio));
					Camera->ForceUpdateCamera(true);
					float PitchMax = FMath::Lerp(PitchMaxCloseUp, PitchMaxThreshold, ThresholdRatio);
					InitPitch = FMath::Clamp(InitPitch, PitchMin, PitchMax);
					CustomRoleMaxPitchCloseUp = PitchMaxCloseUp;
					CustomRoleMaxPitchThreshold = PitchMaxThreshold;
					Camera->InitLimitRot(true, PitchMin, FMath::Max(PitchMaxCloseUp, PitchMaxThreshold), YawMin, YawMax);
					FRotator Rot = Camera->GetActorRotation();
					Rot.Pitch = InitPitch;
					Rot.Roll = InitRoll;
					Camera->SetActorRotation(Rot);
					CustomRolePreviousPitch = InitPitch;
				}
			}
		}
	}
}

void UKgCameraMode::SetAdaptiveViewOffsetWithZoom(float ViewOffXWithZoomMax, float ViewOffXWithZoomMin,
	float ViewOffYWithZoomMax, float ViewOffYWithZoomMin, float HalfLife)
{
	bAdaptiveViewOffset = true;
	AdaptiveViewOffsetXWithZoom.X = ViewOffXWithZoomMin;
	AdaptiveViewOffsetXWithZoom.Y = ViewOffXWithZoomMax;
	AdaptiveViewOffsetYWithZoom.X = ViewOffYWithZoomMin;
	AdaptiveViewOffsetYWithZoom.Y = ViewOffYWithZoomMax;
	AdaptiveViewOffsetHalfLife = HalfLife;
}

void UKgCameraMode::CancelAdaptiveViewOffsetWithZoom()
{
	bAdaptiveViewOffset = false;
	if(bActivate)
	{
		if(ABaseCamera* Camera = Cast<ABaseCamera>(GetCurCamera()))
		{
			auto Offset = BasicConfig.ViewOffset.GetValue();
			Camera->GetCameraArmComponent()->SetPivotOffsetFromScreenCoOffset(Offset.X, Offset.Y);
		}
	}
}

void UKgCameraMode::ClearModeModifyDataAfterFrame()
{
	FOVDelta = 0.f;
	ZoomDelta = 0.f;
	RotDelta = FRotator::ZeroRotator;
	OverrideZoom.Reset(-1.f);

	if(bActivate)
	{
		if(UCameraArmComponent* Arm = GetCameraArmComponent())
		{
			Arm->SetOverrideZoom(OverrideZoom.GetValue());
			Arm->SetZoomOffset(ZoomDelta);
			Arm->SetTargetRotOffsetByRotator(RotDelta);
		}
	}
}

void UKgCameraMode::SetOverrideZoomSetting(float Value, int Priority)
{
	OverrideZoom.SetValueByPriority(Value, Priority);
	if(bActivate)
	{
		if(UCameraArmComponent* Arm = GetCameraArmComponent())
		{
			Arm->SetOverrideZoom(OverrideZoom.GetValue());
		}
	}
}

void UKgCameraMode::ClampZoomWithZoomSetting(float& Value)
{
	Value = FMath::Clamp(Value, BasicConfig.ZoomMinLen.GetValue(), BasicConfig.ZoomMaxLen.GetValue());
}

void UKgCameraMode::ManualSetZoom(float Value)
{
	if(bActivate)
	{
		if(UCameraArmComponent* Arm = GetCameraArmComponent())
		{
			Arm->ManualSetZoom(Value);
		}
	}
}

float UKgCameraMode::GetOverrideZoomBelowPriority(int Priority, float DefaultValue)
{
	float Result = OverrideZoom.GetValueBelowPriority(Priority, DefaultValue);
	return Result < 0.f ? DefaultValue : Result;
}

void UKgCameraMode::RemoveOverrideZoomSetting(int Priority)
{
	OverrideZoom.RemoveValueByPriority(Priority);
	if(bActivate)
	{
		if(UCameraArmComponent* Arm = GetCameraArmComponent())
		{
			Arm->SetOverrideZoom(OverrideZoom.GetValue());
		}
	}
}

void UKgCameraMode::SetViewYawSetting(float Min, float Max, int InPriority)
{
	BasicConfig.CustomViewYawMin.SetValueByPriority(Min, InPriority);
	BasicConfig.CustomViewYawMax.SetValueByPriority(Max, InPriority);
}

void UKgCameraMode::SetViewRollSetting(float Min, float Max, int InPriority)
{
	BasicConfig.CustomViewRollMin.SetValueByPriority(Min, InPriority);
	BasicConfig.CustomViewRollMax.SetValueByPriority(Max, InPriority);
}

void UKgCameraMode::RemoveLookAtBoneRemainOffset()
{
	if (CameraWeakPtr.IsValid())
	{
		CameraWeakPtr->RemoveLookAtBoneRemainOffset();
	}
}

void UKgCameraMode::RecoverLookAt()
{
	if (CameraWeakPtr.IsValid())
	{
		CameraWeakPtr->SetLookAtTarget(BasicConfig.LookAtTarget.Get(), BasicConfig.ControlTarget.Get(), BasicConfig.LookAtBoneName, BasicConfig.LookAtBoneOffset, BasicConfig.BoneOffsetTransSpace);
	}
}

ACameraManager* UKgCameraMode::GetCameraManager()
{
	if (CurCameraManager.IsValid())
	{
		return CurCameraManager.Get();
	}

	if (CurCameraMgr.IsValid())
	{
		CurCameraManager = Cast<ACameraManager>(CurCameraMgr.Get());
		return CurCameraManager.Get();
	}

	return nullptr;
}
