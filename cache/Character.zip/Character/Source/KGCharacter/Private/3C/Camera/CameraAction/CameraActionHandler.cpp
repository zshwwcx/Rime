#include "3C/Camera/CameraAction/CameraActionHandler.h"
#include "3C/Camera/KgCameraMode.h"
#include "3C/Camera/CameraAction/CameraActionBattleCorrection.h"
#include "3C/Camera/CameraAction/CameraActionBattleLockCorrection.h"
#include "3C/Camera/CameraAction/CameraActionParamAdditional.h"
#include "3C/Camera/CameraAction/CameraActionParamOverride.h"
#include "3C/Camera/CameraAction/CameraActionTurnToLock.h"
#include "3C/Camera/CameraAction/CameraAIMove.h"
#include "3C/Camera/CameraAction/CameraFollowMove.h"
#include "3C/Camera/CameraAction/CameraFOVAction.h"
#include "3C/Camera/CameraAction/CameraLagAction.h"
#include "3C/Camera/CameraAction/CameraLockLookForward.h"
#include "3C/Camera/CameraAction/CameraLookAtEffect.h"
#include "3C/Camera/CameraAction/CameraMoveFollowLookAtSplineMove.h"
#include "3C/Camera/CameraAction/CameraNavigationMoveAction.h"
#include "3C/Camera/CameraAction/CameraRotAndZoomAdjustAction.h"
#include "3C/Camera/CameraAction/CameraRotateAction.h"
#include "3C/Camera/CameraAction/CameraScreenViewOffsetAction.h"
#include "3C/Camera/CameraAction/CameraViewOffsetEffect.h"
#include "3C/Camera/CameraAction/CameraZoomAction.h"
#include "3C/Camera/CameraAction/KGCameraAnimationModifier.h"
#include "3C/Util/KGUtils.h"
#include "Misc/LowLevelFunctions.h"
#include "Components/SplineComponent.h"


UCameraActionHandler::UCameraActionHandler(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	if (ACameraManager* Outer = Cast<ACameraManager>(GetOuter()))
	{
		CameraManagerOwner = Outer;
	}
}

void UCameraActionHandler::Init()
{
	CameraAnimModifier = NewObject<UKGCameraAnimationCameraModifier>(CameraManagerOwner);
	CameraAnimModifier->AddedToCamera(CameraManagerOwner);
	CameraAnimModifier->SetActionHandlerOwner(this);

	ControllerRotation_Pitch.Reset(0.f);
	ControllerRotation_Yaw.Reset(0.f);
	ControllerRotation_Roll.Reset(0.f);
}

void UCameraActionHandler::GetRotationRecoverTo(int Priority, float& OutPitch, float& OutYaw, float& OutRoll) const
{
	OutPitch = LastStrongSetPitchPriority > RecoverRotation_Pitch.GetTopPriorityBelowPriority(Priority) ? ControllerRotation_Pitch.GetValueBelowOrEqualPriority(Priority, OutPitch) : RecoverRotation_Pitch.GetValueBelowPriority(Priority, OutPitch);
	OutYaw = LastStrongSetYawPriority > RecoverRotation_Yaw.GetTopPriorityBelowPriority(Priority) ? ControllerRotation_Yaw.GetValueBelowOrEqualPriority(Priority, OutYaw) : RecoverRotation_Yaw.GetValueBelowPriority(Priority, OutYaw);
	OutRoll = LastStrongSetRollPriority > RecoverRotation_Roll.GetTopPriorityBelowPriority(Priority) ? ControllerRotation_Roll.GetValueBelowOrEqualPriority(Priority, OutRoll) : RecoverRotation_Roll.GetValueBelowPriority(Priority, OutRoll);
}

void UCameraActionHandler::GetRotationRecoverTo(int Priority, FRotator& OutRot) const
{
	OutRot.Pitch = LastStrongSetPitchPriority > RecoverRotation_Pitch.GetTopPriorityBelowPriority(Priority) ? ControllerRotation_Pitch.GetValueBelowOrEqualPriority(Priority, OutRot.Pitch) : RecoverRotation_Pitch.GetValueBelowPriority(Priority, OutRot.Pitch);
	OutRot.Yaw = LastStrongSetYawPriority > RecoverRotation_Yaw.GetTopPriorityBelowPriority(Priority) ? ControllerRotation_Yaw.GetValueBelowOrEqualPriority(Priority, OutRot.Yaw) : RecoverRotation_Yaw.GetValueBelowPriority(Priority, OutRot.Yaw);
	OutRot.Roll = LastStrongSetRollPriority > RecoverRotation_Roll.GetTopPriorityBelowPriority(Priority) ? ControllerRotation_Roll.GetValueBelowOrEqualPriority(Priority, OutRot.Roll) : RecoverRotation_Roll.GetValueBelowPriority(Priority, OutRot.Roll);
}

void UCameraActionHandler::KAPI_Camera_StopAllAction()
{
	for(auto Action : ActiveCameraActions)
	{
		Action->DisableAction(true);
	}
	CameraAnimModifier->StopAllCameraAnimations(true);
}

int64 UCameraActionHandler::KAPI_Camera_StartBattleCameraCorrectAction(int Priority,
	const TArray<int>& EffectCameraModesTag, int64 TargetActorID, float BufferYawLeft, float SafeYawLeft,
	float SafeYawRight, float BufferYawRight, float BufferPitchHigh, float SafePitchHigh, float SafePitchLow,
	float BufferPitchLow, float NewBlendTime, int NewBlendInType, int64 NewCurveID, float NewAdaptiveRatio)
{
	if(UCameraActionBattleCorrection* CA = Cast<UCameraActionBattleCorrection>(CreateCameraAction(UCameraActionBattleCorrection::StaticClass(), Priority, EffectCameraModesTag)))
	{
		CA->Init(TargetActorID, BufferYawLeft, SafeYawLeft, SafeYawRight, BufferYawRight, BufferPitchHigh, SafePitchHigh, SafePitchLow, BufferPitchLow, NewBlendTime, NewBlendInType, NewCurveID, NewAdaptiveRatio);
		StartCameraAction(CA);
		return CA->ActionID;
	}

	return KG_INVALID_ID;
}

int64 UCameraActionHandler::KAPI_Camera_ReStartBattleCameraCorrectAction(int64 ActionID, int Priority,
	const TArray<int>& EffectCameraModesTag, int64 TargetActorID, float BufferYawLeft, float SafeYawLeft,
	float SafeYawRight, float BufferYawRight, float BufferPitchHigh, float SafePitchHigh, float SafePitchLow,
	float BufferPitchLow, float NewBlendTime, int NewBlendInType, int64 NewCurveID, float NewAdaptiveRatio)
{
	if(UCameraActionBattleCorrection* CA = Cast<UCameraActionBattleCorrection>(GetActionByID(ActionID)))
	{
		RefreshActionModeParams(CA, Priority, EffectCameraModesTag);
		CA->Init(TargetActorID, BufferYawLeft, SafeYawLeft, SafeYawRight, BufferYawRight, BufferPitchHigh, SafePitchHigh, SafePitchLow, BufferPitchLow, NewBlendTime, NewBlendInType, NewCurveID, NewAdaptiveRatio);
		StartCameraAction(CA);
		return CA->ActionID;
	}
	return KG_INVALID_ID;
}

int64 UCameraActionHandler::KAPI_Camera_StartCameraParamAdditionalAction(int Priority,
	const TArray<int>& EffectCameraModesTag, float InFadeInTime, float InDurationTime, float InFadeOutTime,
	float InYawOffSet, float InPitchOffSet, float InZoomOffSet, float InFOVOffSet, ECameraEaseFunction::Type InBlendInMode,
	ECameraEaseFunction::Type InBlendOutMode, int64 InFadeInCurveID, int64 InFadeOutCurveID, bool InbDisableLimitView)
{
	if(UCameraActionParamAdditional* CA = Cast<UCameraActionParamAdditional>(CreateCameraAction(UCameraActionParamAdditional::StaticClass(), Priority, EffectCameraModesTag)))
	{
		CA->InitParamAdditional(InFadeInTime, InDurationTime, InFadeOutTime, InYawOffSet, InPitchOffSet, InZoomOffSet, InFOVOffSet, InBlendInMode, InBlendOutMode, InFadeInCurveID, InFadeOutCurveID, InbDisableLimitView);
		StartCameraAction(CA);
		return CA->ActionID;
	}

	return KG_INVALID_ID;
}

int64 UCameraActionHandler::KAPI_Camera_StartCameraParamOverrideAction(int Priority,
	const TArray<int>& EffectCameraModesTag, float InFadeInTime, float InDurationTime, float InFadeOutTime,
	int64 ViewActorIDForRotator, bool bInUseYawAdjust, float TargetYaw, bool bInUsePitchAdjust, float TargetPitch,
	bool bInUseRollAdjust, float TargetRoll, float InArmLength, float InFOV, float XOYLag, float ZLag,
	float XOYSoftRadius, float ZSoftRadius, bool bInUseViewOffsetAdjust, float ViewOffsetX, float ViewOffsetY,
	ECameraEaseFunction::Type InBlendInMode,
	ECameraEaseFunction::Type InBlendOutMode, int64 InFadeInCurveID, int64 InFadeOutCurveID, bool InbDisableLimitView)
{
	if(UCameraActionParamOverride* CA = Cast<UCameraActionParamOverride>(CreateCameraAction(UCameraActionParamOverride::StaticClass(), Priority, EffectCameraModesTag)))
	{
		FRotator PlayerRotator = FRotator::ZeroRotator;
		if(AActor* ViewActor = KGUtils::GetActorByID(ViewActorIDForRotator))
		{
			PlayerRotator = ViewActor->GetActorRotation();
		}
		CA->InitParamOverride(InFadeInTime, InDurationTime, InFadeOutTime, PlayerRotator, bInUseYawAdjust, TargetYaw, bInUsePitchAdjust, TargetPitch, bInUseRollAdjust, TargetRoll, InArmLength, InFOV, XOYLag, ZLag, XOYSoftRadius, ZSoftRadius, bInUseViewOffsetAdjust, ViewOffsetX, ViewOffsetY, InBlendInMode, InBlendOutMode, InFadeInCurveID, InFadeOutCurveID, InbDisableLimitView);
		StartCameraAction(CA);
		return CA->ActionID;
	}

	return KG_INVALID_ID;
}

int64 UCameraActionHandler::KAPI_Camera_StartCameraTurnToLockAction(int Priority,
	const TArray<int>& EffectCameraModesTag, int64 TargetComID, float NewYawDemarcation, float NewWideAngleBlendTime,
	float NewNarrowAngleBlendTime)
{
	if(UCameraActionTurnToLock* CA = Cast<UCameraActionTurnToLock>(CreateCameraAction(UCameraActionTurnToLock::StaticClass(), Priority, EffectCameraModesTag)))
	{
		CA->Init(TargetComID, NewYawDemarcation, NewWideAngleBlendTime, NewNarrowAngleBlendTime);
		StartCameraAction(CA);
		return CA->ActionID;
	}

	return KG_INVALID_ID;
}

int64 UCameraActionHandler::KAPI_Camera_ReStartCameraTurnToLockAction(int64 ActionID, int Priority,
	const TArray<int>& EffectCameraModesTag, int64 TargetComID, float NewYawDemarcation,float NewWideAngleBlendTime,
	float NewNarrowAngleBlendTime)
{
	if(UCameraActionTurnToLock* CA = Cast<UCameraActionTurnToLock>(GetActionByID(ActionID)))
	{
		RefreshActionModeParams(CA, Priority, EffectCameraModesTag);
		CA->Init(TargetComID, NewYawDemarcation, NewWideAngleBlendTime, NewNarrowAngleBlendTime);
		StartCameraAction(CA);
		return CA->ActionID;
	}
	return KG_INVALID_ID;
}

int64 UCameraActionHandler::KAPI_Camera_StartCameraLockActorForwardAction(int Priority,
	const TArray<int>& EffectCameraModesTag, int64 ActorID, float InRotSpeed)
{
	if(UCameraLockLookForward* CA = Cast<UCameraLockLookForward>(CreateCameraAction(UCameraLockLookForward::StaticClass(), Priority, EffectCameraModesTag)))
	{
		CA->Init(ActorID, InRotSpeed);
		StartCameraAction(CA);
		return CA->ActionID;
	}

	return KG_INVALID_ID;
}

int64 UCameraActionHandler::KAPI_Camera_StartCameraLookAtAction(int Priority,
	const TArray<int>& EffectCameraModesTag, float LookAtX, float LookAtY, float LookAtZ, int64 LookAtActorID, float InBlendInTime,
	float InBlendOutTime, float InDuration, bool bInRecover, float PitchOff, float YawOff, float RollOff,
	bool bInUseManualControlPitch, bool bInCanInterrupt, bool bContinue, ECameraEaseFunction::Type InBlendInMode,
	ECameraEaseFunction::Type InBlendOutMode, int64 BlendInCurveID, int64 BlendOutCurveID, const FString& BoneName)
{
	if(UCameraLookAtEffect* CA = Cast<UCameraLookAtEffect>(CreateCameraAction(UCameraLookAtEffect::StaticClass(), Priority, EffectCameraModesTag)))
	{
		FRotator InTargetRotDelta{PitchOff, YawOff, RollOff};
		FVector InLookAtLoc{LookAtX, LookAtY, LookAtZ};
		CA->Init(InLookAtLoc, LookAtActorID, InBlendInTime, InBlendOutTime, InDuration, bInRecover, InTargetRotDelta, bInUseManualControlPitch, bInCanInterrupt, InBlendInMode, InBlendOutMode, BlendInCurveID, BlendOutCurveID, BoneName, bContinue);
		StartCameraAction(CA);
		return CA->ActionID;
	}

	return KG_INVALID_ID;
}

int64 UCameraActionHandler::KAPI_Camera_ReStartCameraLookAtAction(int64 ActionID, int Priority,
	const TArray<int>& EffectCameraModesTag, float LookAtX, float LookAtY, float LookAtZ, int64 LookAtActorID, float InBlendInTime,
	float InBlendOutTime, float InDuration, bool bInRecover, float PitchOff, float YawOff, float RollOff,
	bool bInUseManualControlPitch, bool bInCanInterrupt, bool bContinue, ECameraEaseFunction::Type InBlendInMode,
	ECameraEaseFunction::Type InBlendOutMode, int64 BlendInCurveID, int64 BlendOutCurveID, const FString& BoneName)
{
	if(UCameraLookAtEffect* CA = Cast<UCameraLookAtEffect>(GetActionByID(ActionID)))
	{
		RefreshActionModeParams(CA, Priority, EffectCameraModesTag);
		FRotator InTargetRotDelta{PitchOff, YawOff, RollOff};
		FVector InLookAtLoc{LookAtX, LookAtY, LookAtZ};
		CA->Init(InLookAtLoc, LookAtActorID, InBlendInTime, InBlendOutTime, InDuration, bInRecover, InTargetRotDelta, bInUseManualControlPitch, bInCanInterrupt, InBlendInMode, InBlendOutMode, BlendInCurveID, BlendOutCurveID, BoneName, bContinue);
		StartCameraAction(CA);
		return CA->ActionID;
	}
	return KG_INVALID_ID;
}

int64 UCameraActionHandler::KAPI_Camera_StartCameraViewOffByRotAction(int Priority,
	const TArray<int>& EffectCameraModesTag, float CoordX, float CoordY, float InBlendInTime, float InBlendOutTime,
	ECameraEaseFunction::Type InBlendInType, ECameraEaseFunction::Type InBlendOutType, int64 BlendInCurve,
	int64 BlendOutCurve)
{
	if(UCameraViewOffsetEffect* CA = Cast<UCameraViewOffsetEffect>(CreateCameraAction(UCameraViewOffsetEffect::StaticClass(), Priority, EffectCameraModesTag)))
	{
		CA->Init(CoordX, CoordY, InBlendInTime, InBlendOutTime, InBlendInType, InBlendOutType, BlendInCurve, BlendOutCurve);
		StartCameraAction(CA);
		return CA->ActionID;
	}

	return KG_INVALID_ID;
}

void UCameraActionHandler::KAPI_Camera_ModifyCameraViewOffByRotAction(int64 ActionID, float CoordX, float CoordY,
	float InBlendInTime)
{
	if(UCameraViewOffsetEffect* CA = Cast<UCameraViewOffsetEffect>(GetActionByID(ActionID)))
	{
		CA->ModifyParams(CoordX, CoordY, InBlendInTime);
	}
}


int64 UCameraActionHandler::KAPI_Camera_StartCameraViewOffAction(int Priority, const TArray<int>& EffectCameraModesTag,
	float CoordX, float CoordY, float InBlendInTime, float InBlendOutTime, float InDuration,
	ECameraEaseFunction::Type InBlendInType, ECameraEaseFunction::Type InBlendOutType, int64 BlendInCurve,
	int64 BlendOutCurve)
{
	if(UCameraScreenViewOffsetAction* CA = Cast<UCameraScreenViewOffsetAction>(CreateCameraAction(UCameraScreenViewOffsetAction::StaticClass(), Priority, EffectCameraModesTag)))
	{
		CA->Init(CoordX, CoordY, InBlendInTime, InBlendOutTime, InDuration, InBlendInType, InBlendOutType, BlendInCurve, BlendOutCurve);
		StartCameraAction(CA);
		return CA->ActionID;
	}

	return KG_INVALID_ID;
}

int64 UCameraActionHandler::KAPI_Camera_RefreshCameraViewOffAction(int64 ActionID, float CoordX, float CoordY,
	float InBlendInTime, float InBlendOutTime, float InDuration, ECameraEaseFunction::Type InBlendInType,
	ECameraEaseFunction::Type InBlendOutType, int64 BlendInCurve, int64 BlendOutCurve)
{
	if(UCameraScreenViewOffsetAction* CA = Cast<UCameraScreenViewOffsetAction>(GetActionByID(ActionID)))
	{
		CA->Init(CoordX, CoordY, InBlendInTime, InBlendOutTime, InDuration, InBlendInType, InBlendOutType, BlendInCurve, BlendOutCurve);
		StartCameraAction(CA);
		return CA->ActionID;
	}

	return KG_INVALID_ID;
}

int64 UCameraActionHandler::KAPI_Camera_StartCameraRotZoomAdjustAction(int Priority,
                                                                       const TArray<int>& EffectCameraModesTag, float Pitch, float Yaw, float Zoom, float BlendInTime, float BlendOutTime,
                                                                       float InDuration, bool bInRecover, ECameraEaseFunction::Type BlendInType, ECameraEaseFunction::Type BlendOutType,
                                                                       int64 BlendInCurve, int64 BlendOutCurve)
{
	if(UCameraRotAndZoomAdjustAction* CA = Cast<UCameraRotAndZoomAdjustAction>(CreateCameraAction(UCameraRotAndZoomAdjustAction::StaticClass(), Priority, EffectCameraModesTag)))
	{
		CA->Init(Pitch, Yaw, Zoom, BlendInTime, BlendOutTime, InDuration, bInRecover, BlendInType, BlendOutType, BlendInCurve, BlendOutCurve);
		StartCameraAction(CA);
		return CA->ActionID;
	}

	return KG_INVALID_ID;
}

int64 UCameraActionHandler::KAPI_Camera_StartCameraRotateAction(int Priority,
                                                                const TArray<int>& EffectCameraModesTag, float Pitch, float Yaw, float Roll, float PitchOffset, float YawOffset,
                                                                float RollOffset, bool bInRecover, bool bInCanInterrupt, float InBlendInTime, float InBlendOutTime,
                                                                float InDuration, ECameraEaseFunction::Type InBlendInType, ECameraEaseFunction::Type InBlendOutType,
                                                                int64 BlendInCurve, int64 BlendOutCurve)
{
	if(UCameraRotateAction* CA = Cast<UCameraRotateAction>(CreateCameraAction(UCameraRotateAction::StaticClass(), Priority, EffectCameraModesTag)))
	{
		CA->Init(Pitch, Yaw, Roll, PitchOffset, YawOffset, RollOffset, bInRecover, bInCanInterrupt, InBlendInTime, InBlendOutTime, InDuration, InBlendInType, InBlendOutType, BlendInCurve, BlendOutCurve);
		StartCameraAction(CA);
		return CA->ActionID;
	}

	return KG_INVALID_ID;
}

int64 UCameraActionHandler::KAPI_Camera_StartCameraZoomAction(int Priority,
	const TArray<int>& EffectCameraModesTag, float Zoom, float ZoomOffset, bool bInRecover, bool bInCanInterrupt,
	float InBlendInTime, float InBlendOutTime, float InDuration, ECameraEaseFunction::Type InBlendInType,
	ECameraEaseFunction::Type InBlendOutType, int64 BlendInCurve, int64 BlendOutCurve)
{
	if(UCameraZoomAction* CA = Cast<UCameraZoomAction>(CreateCameraAction(UCameraZoomAction::StaticClass(), Priority, EffectCameraModesTag)))
	{
		CA->Init(Zoom, ZoomOffset, bInRecover, bInCanInterrupt, InBlendInTime, InBlendOutTime, InDuration, InBlendInType, InBlendOutType, BlendInCurve, BlendOutCurve);
		StartCameraAction(CA);
		return CA->ActionID;
	}

	return KG_INVALID_ID;
}

int64 UCameraActionHandler::KAPI_Camera_StartCameraFOVAction(int Priority,
	const TArray<int>& EffectCameraModesTag, float FOV, float FOVOffset, bool bInRecover,
	float InBlendInTime, float InBlendOutTime, float InDuration, ECameraEaseFunction::Type InBlendInType,
	ECameraEaseFunction::Type InBlendOutType, int64 BlendInCurve, int64 BlendOutCurve)
{
	if(UCameraFOVAction* CA = Cast<UCameraFOVAction>(CreateCameraAction(UCameraFOVAction::StaticClass(), Priority, EffectCameraModesTag)))
	{
		CA->Init(FOV, FOVOffset, bInRecover, InBlendInTime, InBlendOutTime, InDuration, InBlendInType, InBlendOutType, BlendInCurve, BlendOutCurve);
		StartCameraAction(CA);
		return CA->ActionID;
	}

	return KG_INVALID_ID;
}

int64 UCameraActionHandler::KAPI_Camera_StartCameraLagAction(int Priority,
	const TArray<int>& EffectCameraModesTag, float XYLag, float ZLag, float XYSoftRadius, float ZSoftRadius,
	float InBlendInTime, float InBlendOutTime, float InDuration, ECameraEaseFunction::Type InBlendInType,
	ECameraEaseFunction::Type InBlendOutType, int64 BlendInCurve, int64 BlendOutCurve)
{
	if(UCameraLagAction* CA = Cast<UCameraLagAction>(CreateCameraAction(UCameraLagAction::StaticClass(), Priority, EffectCameraModesTag)))
	{
		CA->Init(XYLag, ZLag, XYSoftRadius, ZSoftRadius, InBlendInTime, InBlendOutTime, InDuration, InBlendInType, InBlendOutType, BlendInCurve, BlendOutCurve);
		StartCameraAction(CA);
		return CA->ActionID;
	}

	return KG_INVALID_ID;
}

int64 UCameraActionHandler::KAPI_Camera_InitCameraFollowLookAtSplineMove(int Priority, const TArray<int>& EffectCameraModesTag, int64 SplineID, bool bInYawOffset, float InYawOffset, bool bInPitch, float InPitch, float InRotationLagParams)
{
	if(UCameraMoveFollowLookAtSplineMove* CA = Cast<UCameraMoveFollowLookAtSplineMove>(CreateCameraAction(UCameraMoveFollowLookAtSplineMove::StaticClass(), Priority, EffectCameraModesTag)))
	{
		CA->Init(Cast<USplineComponent>(KGUtils::GetObjectByID(SplineID)), bInYawOffset, InYawOffset, bInPitch, InPitch, InRotationLagParams);
		StartCameraAction(CA);
		return CA->ActionID;
	}

	return KG_INVALID_ID;
}

void UCameraActionHandler::KAPI_Camera_RefreshCameraFollowLookAtSplineMove(int64 ActionID, bool bInYawOffset,
	float InYawOffset, bool bInPitch, float InPitch, float InRotationLagParams)
{
	if(UCameraMoveFollowLookAtSplineMove* CA = Cast<UCameraMoveFollowLookAtSplineMove>(GetActionByID(ActionID)))
	{
		CA->Refresh(bInYawOffset, InYawOffset, bInPitch, InPitch, InRotationLagParams);
	}
}

void UCameraActionHandler::KAPI_Camera_SetCameraAIMovePriorityAndModesTag(int Priority,
	const TArray<int>& EffectCameraModesTag)
{
	CameraAIMovePriority = Priority;
	AIMoveEffectCameraModesTag = EffectCameraModesTag;
}

int64 UCameraActionHandler::KAPI_Camera_StartCameraAIMove(const TArray<FVector>& WorldLocations,
	const TArray<FRotator>& WorldRotations, int SampleRate, float BlendInTime, float BlendOutTime, float PlayRate)
{
	if(UCameraAIMove* CA = Cast<UCameraAIMove>(CreateCameraAction(UCameraAIMove::StaticClass(), CameraAIMovePriority, AIMoveEffectCameraModesTag)))
	{
		CA->Init(WorldLocations, WorldRotations, SampleRate, BlendInTime, BlendOutTime, PlayRate);
		StartCameraAction(CA);
		return CA->ActionID;
	}
	return KG_INVALID_ID;
}

int64 UCameraActionHandler::KAPI_Camera_StartCameraAIMoveWithPivot(const TArray<FVector>& WorldLocations,
	const TArray<FRotator>& WorldRotations, const TArray<FVector>& CameraPivotLocations, int SampleRate,
	float BlendInTime, float BlendOutTime, float PlayRate)
{
	if(UCameraAIMove* CA = Cast<UCameraAIMove>(CreateCameraAction(UCameraAIMove::StaticClass(), CameraAIMovePriority, AIMoveEffectCameraModesTag)))
	{
		CA->Init(WorldLocations, WorldRotations, CameraPivotLocations, SampleRate, BlendInTime, BlendOutTime, PlayRate);
		StartCameraAction(CA);
		return CA->ActionID;
	}
	return KG_INVALID_ID;
}

int64 UCameraActionHandler::KAPI_Camera_StartCameraLock(int Priority, const TArray<int>& EffectCameraModesTag,
                                                        int64 LockActorID, int InBlendType, float InScreenThresholdUp, float InScreenThresholdDown, float InYawBlendParam,
                                                        float InPitchBlendParam, float InSafeLockPitch, float InSafePitchMin, float InSafePitchMax, float InActionCD,
                                                        float InRaisePitchOffsetMax, float InDropPitchOffsetMax, bool bClearCD)
{
	if(UCameraActionBattleLockCorrection* CA = Cast<UCameraActionBattleLockCorrection>(CreateCameraAction(UCameraActionBattleLockCorrection::StaticClass(), Priority, EffectCameraModesTag, true)))
	{
		CA->Init(LockActorID, InBlendType, InScreenThresholdUp, InScreenThresholdDown, InYawBlendParam, InPitchBlendParam, InSafeLockPitch, InSafePitchMin, InSafePitchMax, InActionCD, InRaisePitchOffsetMax, InDropPitchOffsetMax, bClearCD);
		StartCameraAction(CA);
		return CA->ActionID;
	}
	return KG_INVALID_ID;
}

int64 UCameraActionHandler::KAPI_Camera_StartCameraNavigationMove(int Priority, const TArray<int>& EffectCameraModesTag,
	float InYawBlendParam, float InPitchBlendParam, float InLockPitch, float InActionCD)
{
	if(UCameraNavigationMoveAction* CA = Cast<UCameraNavigationMoveAction>(CreateCameraAction(UCameraNavigationMoveAction::StaticClass(), Priority, EffectCameraModesTag, true)))
	{
		CA->Init(InYawBlendParam, InPitchBlendParam, InLockPitch, InActionCD);
		StartCameraAction(CA);
		return CA->ActionID;
	}
	return KG_INVALID_ID;
}

int64 UCameraActionHandler::KAPI_Camera_StartCameraFollowMove(int Priority, const TArray<int>& EffectCameraModesTag,
	float InYawBlendParam, float InYawBlendSubParam, float InPitchBlendParam, float InVelocityThreshold,
	float InLookPitchOffset, float InContinuousInputDurationThreshold, float InPitchSampleDuration, float InActionCD,
	float InInputThreshold)
{
	if(UCameraFollowMove* CA = Cast<UCameraFollowMove>(CreateCameraAction(UCameraFollowMove::StaticClass(), Priority, EffectCameraModesTag, true)))
	{
		CA->Init(InYawBlendParam, InYawBlendSubParam, InPitchBlendParam, InVelocityThreshold, InLookPitchOffset, InContinuousInputDurationThreshold, InPitchSampleDuration, InActionCD, InInputThreshold);
		StartCameraAction(CA);
		return CA->ActionID;
	}
	return KG_INVALID_ID;
}

void UCameraActionHandler::KAPI_Camera_StartActionPlayRate(int64 ActionID, float NewPlayRate)
{
	if(UCameraActionBase* CA = Cast<UCameraActionBase>(GetActionByID(ActionID)))
	{
		CA->SetPlayRate(NewPlayRate);
	}
}

void UCameraActionHandler::KAPI_Camera_SetActionPlayAt(int64 ActionID, float NewPct)
{
	if(UCameraActionBase* CA = Cast<UCameraActionBase>(GetActionByID(ActionID)))
	{
		CA->SetPlayAt(NewPct);
	}
}

void UCameraActionHandler::KAPI_Camera_SetActionPause(int64 ActionID, bool bPause)
{
	if(UCameraActionBase* CA = Cast<UCameraActionBase>(GetActionByID(ActionID)))
	{
		CA->SetPause(bPause);
	}
}

void UCameraActionHandler::KAPI_Camera_SetActionRecover(int64 Action, bool bRecover)
{
	if(UCameraActionBase* CA = Cast<UCameraActionBase>(GetActionByID(Action)))
	{
		CA->bRecover = bRecover;
	}
}

void UCameraActionHandler::ProcessViewRotation(AActor* ViewTarget, float DeltaTime, FRotator& OutViewRotation,
                                               FRotator& OutDeltaRot)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("Camera Action ProcessViewRotation");

	RecoverRotation_Pitch.UpdateAllAbovePriority(OutViewRotation.Pitch, LastStrongSetPitchPriority);
	RecoverRotation_Yaw.UpdateAllAbovePriority(OutViewRotation.Yaw, LastStrongSetYawPriority);
	RecoverRotation_Roll.UpdateAllAbovePriority(OutViewRotation.Roll, LastStrongSetRollPriority);
	
	ControllerRotation_Pitch.RemoveValueWithoutBase();
	ControllerRotation_Yaw.RemoveValueWithoutBase();
	ControllerRotation_Roll.RemoveValueWithoutBase();
	
	ControllerRotation_Pitch.SetValueByPriority(OutViewRotation.Pitch, 0);
	ControllerRotation_Yaw.SetValueByPriority(OutViewRotation.Yaw, 0);
	ControllerRotation_Roll.SetValueByPriority(OutViewRotation.Roll, 0);
	
	LastStrongSetPitchPriority = -1; LastStrongSetYawPriority = -1; LastStrongSetRollPriority = -1;
	LastWeakSetPitchPriority = -1; LastWeakSetYawPriority = -1; LastWeakSetRollPriority = -1;

 	bHasModifyPitch = false; bHasModifyYaw = false; bHasModifyRoll = false;

	for(int Index = 0; Index < ActiveCameraActions.Num(); ++Index)
	{
		auto& Action = ActiveCameraActions[Index];
		Action->UpdateAlpha(DeltaTime);
	}

	if(bBlockActions)
	{
		return;
	}

	CachedRotation = OutViewRotation;
	if(bPlayingCameraAnimation)
	{
		OutDeltaRot = FRotator::ZeroRotator;
	}
	bool bModifyRotation_Pitch = false;
	bool bModifyRotation_Yaw = false;
	bool bModifyRotation_Roll = false;
	bool bHasModify = false;

	for(int Index = 0; Index < ActiveCameraActions.Num(); ++Index)
	{
		auto Action = ActiveCameraActions[Index];
		if(Action->bFinished && !Action->bRecover) // bRecover需要更新最后一帧
		{
			continue;
		}
		OutViewRotation = CachedRotation;
		bModifyRotation_Pitch = false;
		bModifyRotation_Yaw = false;
		bModifyRotation_Roll = false;
		bHasModify = Action->ProcessViewRotation(ViewTarget, DeltaTime, bModifyRotation_Pitch, OutViewRotation.Pitch, bModifyRotation_Yaw, OutViewRotation.Yaw, bModifyRotation_Roll, OutViewRotation.Roll, OutDeltaRot);
		OnChangeViewRotation(Action->Priority, bModifyRotation_Pitch, OutViewRotation.Pitch, bModifyRotation_Yaw, OutViewRotation.Yaw, bModifyRotation_Roll, OutViewRotation.Roll, Action->IsStronglySetRotation());			
	}

	if(CameraAnimModifier)
	{
		OutViewRotation = CachedRotation;
		bModifyRotation_Pitch = false;
		bModifyRotation_Yaw = false;
		bModifyRotation_Roll = false;
		bHasModify = CameraAnimModifier->ProcessViewRotation(ViewTarget, DeltaTime, bModifyRotation_Pitch, OutViewRotation.Pitch, bModifyRotation_Yaw, OutViewRotation.Yaw, bModifyRotation_Roll, OutViewRotation.Roll, OutDeltaRot);
		OnChangeViewRotation(INT_MAX, bModifyRotation_Pitch, OutViewRotation.Pitch, bModifyRotation_Yaw, OutViewRotation.Yaw, bModifyRotation_Roll, OutViewRotation.Roll, true);			
	}
	
	OutViewRotation.Pitch = ControllerRotation_Pitch.GetTopPriority() > 0 ? ControllerRotation_Pitch.GetValue() : CachedRotation.Pitch;
	OutViewRotation.Yaw = ControllerRotation_Yaw.GetTopPriority() > 0 ? ControllerRotation_Yaw.GetValue() : CachedRotation.Yaw;
	OutViewRotation.Roll = ControllerRotation_Roll.GetTopPriority() > 0 ? ControllerRotation_Roll.GetValue() : CachedRotation.Roll;
}

void UCameraActionHandler::OnChangeViewRotation(int Priority, bool bChangePitch, double Pitch, bool bChangeYaw,
	double Yaw, bool bChangeRoll, double Roll, bool bStrongSet)
{
	if(bChangePitch)
	{
		ControllerRotation_Pitch.SetValueByPriority(Pitch, Priority);
		bStrongSet ? LastStrongSetPitchPriority = Priority : LastWeakSetPitchPriority = Priority;
		if (!bStrongSet) RecoverRotation_Pitch.SetValueByPriority(RecoverRotation_Pitch.GetValueBelowPriority(Priority, Pitch), Priority);
		if (LastStrongSetPitchPriority == LastWeakSetPitchPriority)
		{
			UE_LOG(LogTemp, Error, TEXT("CameraAction ProcessRotation Get Same Pitch Priority Weak And Strong, Priority:%d"), LastStrongSetPitchPriority)
		}
	}
	if(bChangeYaw)
	{
		ControllerRotation_Yaw.SetValueByPriority(Yaw, Priority);
		bStrongSet ? LastStrongSetYawPriority = Priority : LastWeakSetYawPriority = Priority;
		if (!bStrongSet) RecoverRotation_Yaw.SetValueByPriority(RecoverRotation_Yaw.GetValueBelowPriority(Priority, Yaw), Priority);
		if (LastStrongSetYawPriority == LastWeakSetYawPriority)
		{
			UE_LOG(LogTemp, Error, TEXT("CameraAction ProcessRotation Get Same Yaw Priority Weak And Strong, Priority:%d"), LastStrongSetYawPriority)
		}
	}
	if(bChangeRoll)
	{
		ControllerRotation_Roll.SetValueByPriority(Roll, Priority);
		bStrongSet ? LastStrongSetRollPriority = Priority : LastWeakSetRollPriority = Priority;
		if (!bStrongSet) RecoverRotation_Roll.SetValueByPriority(RecoverRotation_Roll.GetValueBelowPriority(Priority, Roll), Priority);
		if (LastStrongSetRollPriority == LastWeakSetRollPriority)
		{
			UE_LOG(LogTemp, Error, TEXT("CameraAction ProcessRotation Get Same Roll Priority Weak And Strong, Priority:%d"), LastStrongSetRollPriority)
		}
	}

	bHasModifyPitch = bHasModifyPitch | bChangePitch;
	bHasModifyYaw = bHasModifyYaw | bChangeYaw;
	bHasModifyRoll = bHasModifyRoll | bChangeRoll;
}

void UCameraActionHandler::UpdateCameraActions(float DeltaTime)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("Camera Action ModifyCamera");

	for(int Index = 0; Index < ActiveCameraActions.Num(); ++Index)
	{
		auto& Action = ActiveCameraActions[Index];
		Action->UpdateAlpha(DeltaTime);
		if(!bBlockActions)
		{
			if(Action->bFinished && !Action->bRecover) // bRecover需要更新最后一帧
			{
				continue;
			}
			Action->ModifyCamera(DeltaTime);
		}
	}
}

void UCameraActionHandler::ModifyViewPOV(float DeltaTime, FMinimalViewInfo& InOutPOV)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("Camera Action ModifyViewPOV");

	for(int Index = 0; Index < ActiveCameraActions.Num(); ++Index)
	{
		auto& Action = ActiveCameraActions[Index];
		Action->UpdateAlpha(DeltaTime);
		if(!bBlockActions)
		{
			if(Action->bFinished && !Action->bRecover) // bRecover需要更新最后一帧
			{
				continue;
			}
			Action->ModifyViewPOV(DeltaTime, InOutPOV);
		}
	}

	if(CameraAnimModifier)
	{
		CameraAnimModifier->ModifyCamera(DeltaTime, InOutPOV);
	}
}

void UCameraActionHandler::UpdateAfterFrame()
{
	for(int Index = 0; Index < ActiveCameraActions.Num(); ++Index)
	{
		auto& Action = ActiveCameraActions[Index];
		Action->UpdateAfterFrame();
		if(Action->bFinished)
		{
			RecoverRotation_Pitch.RemoveValueByPriority(Action->Priority);
			RecoverRotation_Yaw.RemoveValueByPriority(Action->Priority);
			RecoverRotation_Roll.RemoveValueByPriority(Action->Priority);
			Action->Abort();
			DeActiveCameraActions.Emplace(Action);
			ActiveCameraActions.RemoveAt(Index, 1, EAllowShrinking::No);
			--Index;
		}
	}

	CameraManagerOwner->ClearModeModifyDataAfterFrame();
}

void UCameraActionHandler::KAPI_Camera_DisableCameraAction(int64 CameraActionID, bool bImmediate)
{
	if(UCameraActionBase* CameraAction = GetActionByID(CameraActionID))
	{
		CameraAction->DisableAction(bImmediate);
	}
}

void UCameraActionHandler::KAPI_Camera_DisableCameraActionWithBlend(int64 CameraActionID, float OverrideBlendOutTime)
{
	if(UCameraActionBase* CameraAction = GetActionByID(CameraActionID))
	{
		CameraAction->OverrideBlendOutTime(OverrideBlendOutTime);
		CameraAction->DisableAction(false);
	}
}

bool UCameraActionHandler::KAPI_Camera_CheckCameraActionActivate(int64 CameraActionID)
{
	if(UCameraActionBase* CameraAction = GetActionByID(CameraActionID))
	{
		return !CameraAction->bFinished;
	}

	return false;
}

void UCameraActionHandler::OnManalControl(ECameraManualControlType::Type ControlType)
{
	for(int Index = 0; Index < ActiveCameraActions.Num(); ++Index)
	{
		auto& CA = ActiveCameraActions[Index];
		if(CA->IsNeedDeActiveWhenManualControl(ControlType))
		{
			CA->DisableAction(true);
		}
	}
}

UCameraActionBase* UCameraActionHandler::CreateCameraAction(const TSubclassOf<UCameraActionBase>& NewActionClass, int64 Priority, const TArray<int>& EffectCameraModesTag, bool bUnique)
{
	UCameraActionBase* NewAction = nullptr;

	for(int Index = 0; Index < DeActiveCameraActions.Num(); ++Index)
	{
		if(DeActiveCameraActions[Index]->GetClass() == NewActionClass)
		{
			NewAction = DeActiveCameraActions[Index];
			DeActiveCameraActions.RemoveAt(Index);
			break;
		}
	}

	if(bUnique && NewAction == nullptr)
	{
		for(int Index = 0; Index < ActiveCameraActions.Num(); ++Index)
		{
			if(ActiveCameraActions[Index]->GetClass() == NewActionClass)
			{
				NewAction = ActiveCameraActions[Index];
				break;
			}
		}
	}
	
	if(NewAction == nullptr)
	{
		NewAction = NewObject<UCameraActionBase>(this, NewActionClass);
	}

	if(NewAction != nullptr)
	{
		RefreshActionModeParams(NewAction, Priority, EffectCameraModesTag);
	}
	
	return NewAction;
}

void UCameraActionHandler::KAPI_Camera_StartCameraAction(int64 ActionID)
{
	StartCameraAction(Cast<UCameraActionBase>(GetActionByID(ActionID)));
}

void UCameraActionHandler::StartCameraAction(UCameraActionBase* NewAction)
{
	if(NewAction == nullptr)
	{
		return;
	}

	ReImportCameraAction(NewAction);

	int64 OldActionID = NewAction->ActionID;
	if(IDToCameraActions.Contains(OldActionID))
	{
		IDToCameraActions.Remove(OldActionID);
	}
	NewAction->ActionID = ULowLevelFunctions::GetGlobalUniqueID();
	IDToCameraActions.Add(NewAction->ActionID, NewAction);
	
	if(NewAction->EffectCameraModesTag.Contains(CameraManagerOwner->KAPI_Camera_GetActiveCameraModeTag()))
	{
		NewAction->CameraMode = CameraManagerOwner->GetCurCameraMode();
	}
	else
	{
		NewAction->CameraMode.Reset();
	}

	NewAction->Play();
	UE_LOG(LogTemp, Log, TEXT("CameraManger:StartCameraAction Action:%s ActionID:%lld"), *NewAction->GetName(), NewAction->ActionID);
}

void UCameraActionHandler::OnModeActivate(UKgCameraMode* ActivateMode)
{
	if(ActivateMode == nullptr)
	{
		return;
	}

	int CameraModeTage = ActivateMode->CameraModeTag;
	for(auto& Action : ActiveCameraActions)
	{
		if(Action->EffectCameraModesTag.Contains(CameraModeTage))
		{
			Action->DoWhenEffectModeActivate(ActivateMode);
			Action->ModifyCamera(0.f);
		}
	}

	if(CameraAnimModifier != nullptr)
	{
		CameraAnimModifier->OnModeActivate(ActivateMode->CameraModeTag);
	}
}

void UCameraActionHandler::BlockAllAction(bool bBlock)
{
	bBlockActions = bBlock;
}

void UCameraActionHandler::ClearAllAction()
{
	ActiveCameraActions.Empty();
	DeActiveCameraActions.Empty();
	IDToCameraActions.Empty();

	if(CameraAnimModifier != nullptr)
	{
		CameraAnimModifier->StopAllCameraAnimations(true);
	}
}

void UCameraActionHandler::RefreshActionModeParams(UCameraActionBase* Action, int Priority,
	const TArray<int>& EffectCameraModesTag) const
{
	Action->Priority = Priority;
	Action->EffectCameraModesTag = EffectCameraModesTag;
	if(EffectCameraModesTag.Contains(CameraManagerOwner->KAPI_Camera_GetActiveCameraModeTag()))
	{
		Action->CameraMode = CameraManagerOwner->GetCurCameraMode();
	}
	else
	{
		Action->CameraMode.Reset();
	}
}

UCameraActionBase* UCameraActionHandler::GetActionByID(int64 ActionID)
{
	if(IDToCameraActions.Contains(ActionID))
	{
		return IDToCameraActions[ActionID].Get();
	}

	return nullptr;
}

bool UCameraActionHandler::HasHigherPriorityAction(int Priority)
{
	for(int Index = ActiveCameraActions.Num() - 1; Index > -1; --Index)
	{
		if (ActiveCameraActions[Index]->Priority > Priority)
		{
			return true;
		}
	}

	return false;
}

void UCameraActionHandler::ReImportCameraAction(UCameraActionBase* NewAction)
{
	for(int Index = 0; Index < DeActiveCameraActions.Num(); ++Index)
	{
		if(DeActiveCameraActions[Index] == NewAction)
		{
			DeActiveCameraActions.RemoveAt(Index);
			break;
		}
	}

	for(int Index = 0; Index < ActiveCameraActions.Num(); ++Index)
	{
		if(ActiveCameraActions[Index] == NewAction)
		{
			ActiveCameraActions.RemoveAt(Index);
			break;
		}
	}
	bool bEmplace = false;
	for(int Index = ActiveCameraActions.Num() - 1; Index > -1; --Index)
	{
		if(ActiveCameraActions[Index]->Priority <= NewAction->Priority)
		{
			ActiveCameraActions.Insert(NewAction, Index+1);
			bEmplace = true;
			break;
		}
	}
	if(!bEmplace)
	{
		ActiveCameraActions.Emplace(NewAction);
	}
}
