#include "3C/Camera/PostProcessNew/PostProcessInstance/PPMaterialSketch.h"

#include "3C/Camera/CameraManager.h"
#include "Runtime/FaceControlComponent.h"
#include "3C/Material/KGMaterialManager.h"
#include "3C/Core/KGUEActorManager.h"
#include "3C/Camera/PostProcessNew/PostProcessManager.h"
#include "3C/Interactor/WorldManager.h"

bool KGPPMaterialSketch::OnTaskStart()
{
	if (!KGPPMaterialBase::OnTaskStart())
	{
		return false;
	}

	// todo 这里没有ViewControlBaseComponent 上的command缓存, 目前只能在这里监听所有单位的创建消息, 后续如果使用较多的话
	// 还是需要在LuaScriptEntity上做一个通用的缓存结构
	if (UKGUEActorManager* UEActorManager = UKGUEActorManager::GetInstance(PostProcessManager.Get()))
	{
		UEActorManager->GetOnActorLoadedDelegate().AddRaw(this, &KGPPMaterialSketch::OnActorLoaded);
	}
	else
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialSketch::OnTaskStart: UEActorManager is null, %s"), *GetDebugInfo());
	}
	
	return true;
}

void KGPPMaterialSketch::OnTaskEnd(EKGPostProcessStopReason StopReason)
{
	if (UKGUEActorManager* UEActorManager = UKGUEActorManager::GetInstance(PostProcessManager.Get()))
	{
		UEActorManager->GetOnActorLoadedDelegate().RemoveAll(this);
	}
	else
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialSketch::OnTaskEnd: UEActorManager is null, %s"), *GetDebugInfo());
	}
	
	KGPPMaterialBase::OnTaskEnd(StopReason);
}

void KGPPMaterialSketch::OnTaskActivated()
{
	KGPPMaterialBase::OnTaskActivated();

	for (const auto& Kvp : TargetEffectInfo)
	{
		InternalChangeEntityMaterialEffect(Kvp.Key);
	}

	if (ACameraManager* CameraManager = Cast<ACameraManager>(UGameplayStatics::GetPlayerCameraManager(PostProcessManager.Get(), 0)))
	{
		CameraManager->KAPI_Camera_EnableCameraDitherFade(static_cast<int>(EKGCameraDitherModifyReason::SketchPP), false);
	}
	else
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialSketch::OnTaskActivated, invalid camera manager"));
	}

	if (UWorldManager* WorldManager = UWorldManager::GetInstance(PostProcessManager.Get()))
	{
		WorldManager->EnableFogs(false);
	}
}

void KGPPMaterialSketch::OnTaskDeactivated()
{
	for (const auto& Kvp : TargetEffectInfo)
	{
		InternalRevertEntityMaterialEffect(Kvp.Key);
	}

	if (UWorldManager* WorldManager = UWorldManager::GetInstance(PostProcessManager.Get()))
	{
		WorldManager->EnableFogs(true);
	}
	
	
	if (ACameraManager* CameraManager = Cast<ACameraManager>(UGameplayStatics::GetPlayerCameraManager(PostProcessManager.Get(), 0)))
	{
		CameraManager->KAPI_Camera_EnableCameraDitherFade(static_cast<int>(EKGCameraDitherModifyReason::SketchPP), true);
	}
	else
	{
		// 退出游戏时没有CameraManager是合理的
		UE_LOG(LogKGPP, Log, TEXT("KGPPMaterialSketch::OnTaskDeactivated, invalid camera manager"));
	}
	
	KGPPMaterialBase::OnTaskDeactivated();
}

void KGPPMaterialSketch::AddSketchTarget(KGEntityID EntityID, bool bChangeCustomDepth, int32 LogicType, int32 InPriority, int32 CustomStencilValue, EKGPPSketchEffectType EffectType)
{
	if (IsActivated() && TargetEffectInfo.Contains(EntityID))
	{
		InternalRevertEntityMaterialEffect(EntityID);
	}
	
	auto& EffectInfo = TargetEffectInfo.FindOrAdd(EntityID);
	EffectInfo.EffectType = EffectType;
	EffectInfo.bChangeCustomDepth = bChangeCustomDepth;
	EffectInfo.LogicType = LogicType;
	EffectInfo.Priority = InPriority;
	EffectInfo.CustomStencilValue = CustomStencilValue;

	if (IsActivated())
	{
		InternalChangeEntityMaterialEffect(EntityID);
	}
}

void KGPPMaterialSketch::RemoveSketchTarget(KGEntityID EntityID)
{
	RevertEntityCustomDepth(EntityID);
	
	if (TargetEffectInfo.Contains(EntityID))
	{
		if (IsActivated())
		{
			InternalRevertEntityMaterialEffect(EntityID);
		}
		
		TargetEffectInfo.Remove(EntityID);
	}
}

void KGPPMaterialSketch::InternalChangeEntityMaterialEffect(KGEntityID EntityID)
{
	UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(PostProcessManager.Get());
	if (!ActorManager)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialSketch::InternalChangeEntityMaterialEffect: ActorManager is invalid, %s"), *GetDebugInfo());
		return;
	}

	auto* Entity = ActorManager->GetLuaEntity(EntityID);
	if (!Entity)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialSketch::InternalChangeEntityMaterialEffect: Entity is null, %s, %lld"), *GetDebugInfo(), EntityID);
		return;
	}

	auto* Actor = Entity->GetLuaEntityBase()->GetActor();
	if (Actor == nullptr)
	{
		UE_LOG(LogKGPP, Log, TEXT("KGPPMaterialSketch::InternalChangeEntityMaterialEffect: Actor is null, waiting for actor loaded, %s, %lld"), *GetDebugInfo(), EntityID);
		return;
	}

	auto* EffectInfoPtr = TargetEffectInfo.Find(EntityID);
	if (!EffectInfoPtr)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialSketch::InternalChangeEntityMaterialEffect: EffectInfoPtr not found for EntityID %lld, %s"), EntityID, *GetDebugInfo());
		return;
	}

	if (EffectInfoPtr->bChangeCustomDepth)
	{
		SetEntityCustomDepth(EntityID, EffectInfoPtr->LogicType, EffectInfoPtr->Priority, true, EffectInfoPtr->CustomStencilValue, false);
	}

	if (EffectInfoPtr->EffectType == EKGPPSketchEffectType::ClearLine || EffectInfoPtr->EffectType == EKGPPSketchEffectType::PaintRed)
	{
		if (!MaterialManager.IsValid())
		{
			UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialSketch::InternalChangeEntityMaterialEffect: MaterialManager is null, %s"), *GetDebugInfo());
			return;
		}

		if (!PostProcessManager.IsValid())
		{
			UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialSketch::InternalChangeEntityMaterialEffect: PostProcessManager is null, %s"), *GetDebugInfo());
			return;
		}

		// 为什么一定要在后效里面设置角色材质, 这是因为仅后效生效时才能修改角色材质和材质参数, 且后效被屏蔽时需要清理对应材质和材质参数
		const auto& SketchMaterialRequests = PostProcessManager->GetSketchMaterialRequests();
		for (const auto& Request : SketchMaterialRequests)
		{
			FKGChangeMaterialRequest NewRequest = Request;
			NewRequest.OwnerActor = Actor;
			const auto ReqID = MaterialManager->ChangeMaterial(NewRequest);
			EffectInfoPtr->ChangeMaterialReqIDs.Add(ReqID);
		}
		
		const auto* SketchMaterialParamRequests = PostProcessManager->GetSketchMaterialParamRequestsPtr(EffectInfoPtr->EffectType);
		for (const auto& Request : *SketchMaterialParamRequests)
		{
			FKGChangeMaterialParamRequest NewRequest = Request;
			NewRequest.OwnerActor = Actor;
			const auto ReqID = MaterialManager->ChangeMaterialParam(NewRequest);
			EffectInfoPtr->ChangeMaterialParamReqIDs.Add(ReqID);
		}
	}

	if (UFaceControlComponent* FaceControlComponent = Actor->FindComponentByClass<UFaceControlComponent>())
	{
		FaceControlComponent->SetDisableGroom(EKGEnableGroomReason::PPSketch, true);
	}
}

void KGPPMaterialSketch::InternalRevertEntityMaterialEffect(KGEntityID EntityID)
{
	UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(PostProcessManager.Get());
	if (!ActorManager)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialSketch::InternalRevertEntityMaterialEffect: ActorManager is invalid, %s"), *GetDebugInfo());
		return;
	}

	auto* EffectInfoPtr = TargetEffectInfo.Find(EntityID);
	if (!EffectInfoPtr)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialSketch::InternalRevertEntityMaterialEffect: EffectInfoPtr not found for EntityID %lld, %s"), EntityID, *GetDebugInfo());
		return;
	}

	RevertEntityCustomDepth(EntityID);
	
	if (MaterialManager.IsValid())
	{
		for (const auto ReqID : EffectInfoPtr->ChangeMaterialReqIDs)
		{
			MaterialManager->RevertMaterial(ReqID);
		}
		EffectInfoPtr->ChangeMaterialReqIDs.Empty();

		for (const auto ReqID : EffectInfoPtr->ChangeMaterialParamReqIDs)
		{
			MaterialManager->RevertMaterialParam(ReqID);
		}
		EffectInfoPtr->ChangeMaterialParamReqIDs.Empty();
	}
	else
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialSketch::InternalRevertEntityMaterialEffect: MaterialManager is null, %s"), *GetDebugInfo());
	}

	if (auto* Entity = ActorManager->GetLuaEntity(EntityID))
	{
		if (auto* Actor = Entity->GetLuaEntityBase()->GetActor())
		{
			if (UFaceControlComponent* FaceControlComponent = Actor->FindComponentByClass<UFaceControlComponent>())
			{
				FaceControlComponent->SetDisableGroom(EKGEnableGroomReason::PPSketch, false);
			}
		}
	}
}

void KGPPMaterialSketch::OnActorLoaded(KGEntityID EntityID, AActor* Actor)
{
	if (TargetEffectInfo.Contains(EntityID))
	{
		auto& EffectInfo = TargetEffectInfo[EntityID];
		if (EffectInfo.HasTakenEffect())
		{
			UE_LOG(LogKGPP, Error, TEXT("KGPPMaterialSketch::OnActorLoaded: MaterialReqIDs already has taken effect, %s, %lld"), *GetDebugInfo(), EntityID);
			return;
		}
		
		if (IsActivated())
		{
			InternalChangeEntityMaterialEffect(EntityID);
		}
	}
}
