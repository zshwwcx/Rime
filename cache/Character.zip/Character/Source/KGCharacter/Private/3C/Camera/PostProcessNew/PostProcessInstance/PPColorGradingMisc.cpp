#include "3C/Camera/PostProcessNew/PostProcessInstance/PPColorGradingMisc.h"

#include "Manager/KGCppAssetManager.h"
#include "3C/Camera/PostProcessNew/PostProcessManager.h"
#include "Engine/Texture2D.h"

void KGPPColorGradingMisc::InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType,
	const FPostProcessSettings& InPostProcessSettings, const FString& InColorGradingLUTPath)
{
	KGPPNonMaterialBase::InitParams(CommonParams, InPPManager, InPPType, InPostProcessSettings);
	ColorGradingLUTPath = InColorGradingLUTPath;
}

bool KGPPColorGradingMisc::OnTaskStart()
{
	if (!KGPPNonMaterialBase::OnTaskStart())
	{
		return false;
	}

	if (PostProcessSettings.bOverride_ColorGradingLUT)
	{
		if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(PostProcessManager.Get()))
		{
			AssetLoadID = AssetManager->AsyncLoadAsset(
				ColorGradingLUTPath, FAsyncLoadCompleteDelegate::CreateRaw(this, &KGPPColorGradingMisc::OnColorGradingLUTTextureLoaded));
		}	
	}
	
	return true;
}

void KGPPColorGradingMisc::OnTaskEnd(EKGPostProcessStopReason StopReason)
{
	if (AssetLoadID != 0)
	{
		if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(PostProcessManager.Get()))
		{
			AssetManager->CancelAsyncLoadByLoadID(AssetLoadID);
		}
		else
		{
			UE_LOG(LogKGPP, Error, TEXT("KGPPColorGradingMisc::OnTaskEnd failed, AssetManager is nullptr, %s"), *GetDebugInfo());
		}
	}
	
	KGPPNonMaterialBase::OnTaskEnd(StopReason);
}

bool KGPPColorGradingMisc::CanOutputPostProcess() const
{
	if (PostProcessSettings.bOverride_ColorGradingLUT && !PostProcessSettings.ColorGradingLUT.Get())
	{
		return false;
	}
	
	return KGPPNonMaterialBase::CanOutputPostProcess();
}

void KGPPColorGradingMisc::OnColorGradingLUTTextureLoaded(int InLoadID, UObject* Asset)
{
	AssetLoadID = 0;
	UTexture* TextureAsset = Cast<UTexture>(Asset);
	if (TextureAsset == nullptr)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPColorGradingMisc::OnColorGradingLUTTextureLoaded failed, asset load failed, %s, %s"), *ColorGradingLUTPath, *GetDebugInfo());
		return;
	}

	UE_LOG(LogKGPP, Log, TEXT("KGPPColorGradingMisc::OnColorGradingLUTTextureLoaded, %s, %s"), *ColorGradingLUTPath, *GetDebugInfo());
	ColorGradingLUTTexture = TStrongObjectPtr(TextureAsset);
	PostProcessSettings.ColorGradingLUT = TextureAsset;
}


