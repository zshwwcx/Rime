#include "3C/Camera/CameraAction/KGCameraAnimationModifier.h"

#include "3C/Camera/CameraAction/CameraActionHandler.h"
#include "CameraAnimationSequence.h"
#include "CameraAnimationSequencePlayer.h"
#include "3C/Camera/CameraManager.h"
#include "DrawDebugHelpers.h"
#include "3C/Util/KGUtils.h"
#include "Misc/ObjCrashCollector.h"
#include "Camera/PlayerCameraManager.h"
#include "Kismet/KismetMathLibrary.h"
#include "Camera/CameraTypes.h"
#include "Components/SkeletalMeshComponent.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Platforms/AkPlatform_Android/AkAndroidPlatformInfo.h"
#include "Tracks/MovieSceneTransformTrack.h"


DECLARE_STATS_GROUP(TEXT("KGCamera Animation Evaluation"), STATGROUP_KGCameraAnimation, STATCAT_Advanced)
DECLARE_CYCLE_STAT(TEXT("KGCamera Animation Eval"), KGCameraAnimationEval_Total, STATGROUP_KGCameraAnimation);

const FName UKGCameraAnimationCameraModifier::RootName{TEXT("Root")};

bool UKGCameraAnimationCameraModifier::ModifyCamera(float DeltaTime, FMinimalViewInfo& InOutPOV)
{
	if(ActionHandlerOwner.IsValid())
	{
		ActionHandlerOwner->SetCameraAnimationPlaying(false);
	}

	if (LocationPlayCameraAnimation.IsValid())
	{
		if (IsCameraAnimationActive(LocationPlayCameraAnimation))
		{
			if (FActiveCameraAnimationInfo* Info = GetActiveCameraAnimation(LocationPlayCameraAnimation))
			{
				KGTickAnimation(*Info, bPause ? 0.f : DeltaTime, InOutPOV);
			}
		}
	}
	return false;
}

bool UKGCameraAnimationCameraModifier::ProcessViewRotation(AActor* ViewTarget, float DeltaTime, FRotator& OutViewRotation, FRotator& OutDeltaRot)
{
	bool bChangePitch = false;
	bool bChangeRoll = false;
	bool bChangeYaw = false;
	return ProcessViewRotation(ViewTarget, DeltaTime, bChangePitch, OutViewRotation.Pitch, bChangeYaw, OutViewRotation.Yaw, bChangeRoll, OutViewRotation.Roll, OutDeltaRot);
}

bool UKGCameraAnimationCameraModifier::ProcessViewRotation(AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch,
	double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot)
{
	if(bAdaptiveCameraRot || bCustomPitch)
	{
		if(ActionHandlerOwner.IsValid() && ActionHandlerOwner->IsBlockingCameraActions())
		{
			return false;
		}

		if(CameraMgr.IsValid() && CameraMgr->KAPI_Camera_IsCutSceneActivate())
		{
			return false;
		}

		if(bCanActivate)
		{
			if (LocationPlayCameraAnimation.IsValid())
			{
				if (IsCameraAnimationActive(LocationPlayCameraAnimation))
				{
					if (FActiveCameraAnimationInfo* Info = GetActiveCameraAnimation(LocationPlayCameraAnimation))
					{
						if(bAdaptiveCameraRot)
						{
							bOutChangeYaw = true;
							OutYaw = AdaptiveRot.Yaw;
							OutDeltaRot.Yaw = 0.f;
						}
						if(bCustomPitch)
						{
							bOutChangePitch = true;
							OutPitch = AdaptiveRot.Pitch;
							OutDeltaRot.Pitch = 0.f;
						}
					}
				}
			}
		}
	}

	return false;
}

void UKGCameraAnimationCameraModifier::KGTickAnimation(FActiveCameraAnimationInfo& CameraAnimation, float DeltaTime, FMinimalViewInfo& InOutPOV)
{
	SCOPE_CYCLE_COUNTER(KGCameraAnimationEval_Total);

	check(CameraAnimation.Player);
	check(CameraAnimation.CameraStandIn);

	const FCameraAnimationParams Params = CameraAnimation.Params;
	UCameraAnimationSequencePlayer* Player = CameraAnimation.Player;
	UCameraAnimationSequenceCameraStandIn* CameraStandIn = CameraAnimation.CameraStandIn;

	const FFrameRate DisplayRate = Player->GetInputRate();

	TotalPlayTime += DeltaTime;

	SampleTime += DeltaTime * Params.PlayRate;

	if(DesiredPlayTimePct > 0)
	{
		SampleTime = DesiredPlayTimePct * PlayDuration;
		TotalPlayTime = DesiredPlayTimePct * PlayDuration;
		DesiredPlayTimePct = -1;
	}

	float AssetDuration = DisplayRate.AsSeconds(Player->GetDuration());
	if(SampleTime > AssetDuration)
	{
		if(Params.bLoop)
		{
			SampleTime -= AssetDuration;
		}
		else
		{
			SampleTime = AssetDuration;
		}
	}

	if (TotalPlayTime > PlayDuration)
	{
		Player->Stop();
		return;
	}

	SampleTime += DisplayRate.AsSeconds(Player->GetStartFrame());
	// Update the sequence.
	Player->Update(DisplayRate.AsFrameTime(SampleTime));

	// Recalculate properties that might be invalidated by other properties having been animated.
	CameraStandIn->RecalcDerivedData();

	// Grab the final animated (animated) values, figure out the delta, apply scale, and feed that into the result.
	// Transform is always treated as a local, additive value. The data better be good.
	const FTransform AnimatedTransform = CameraStandIn->GetTransform();
	
	FVector AnimatedLocation = AnimatedTransform.GetLocation();
	FRotator AnimatedRotation = AnimatedTransform.GetRotation().Rotator();
	FVector Scale = FVector::OneVector;
	POVCache = InOutPOV;
	if(UserSpacePlayerActor.IsValid())
	{
		if(UserSpacePlayerActorMesh.IsValid())
		{
			POVCache.Location = bUseMeshSpace ? UserSpacePlayerActorMesh->GetComponentLocation() : UserSpacePlayerActorMesh->GetSocketLocation(UKGCameraAnimationCameraModifier::RootName);
			if(bUseTargetScale)
			{
				Scale = UserSpacePlayerActorMesh->GetComponentScale();
			}
		}
		else
		{
			POVCache.Location = UserSpacePlayerActor->GetActorLocation();
			if(bUseTargetScale)
			{
				Scale = UserSpacePlayerActor->GetActorScale();
			}
		}
	}
	else
	{
		POVCache.Location = AnimPlayLoc;
	}
	POVCache.DesiredFOV = CameraStandIn->FieldOfView;

	const bool bIsCameraLocal = (Params.PlaySpace == ECameraAnimationPlaySpace::CameraLocal);
	FTransform UserPlaySpaceMatrix = bIsCameraLocal ? FTransform(InOutPOV.Rotation, InOutPOV.Location) : FTransform((Params.PlaySpace == ECameraAnimationPlaySpace::UserDefined ? Params.UserPlaySpaceRot : FRotator::ZeroRotator), POVCache.Location, Scale);

	POVCache.Location = UserPlaySpaceMatrix.TransformPosition(AnimatedLocation);
	POVCache.Rotation = UserPlaySpaceMatrix.TransformRotation(AnimatedRotation.Quaternion()).Rotator();

	// UE_LOG(LogTemp, Log, TEXT("Camera Animation Duration:%f TotalTime:%f SampleTime:%f FOV:%f Location:%s Rotation:%s Root:%s"), PlayDuration, TotalPlayTime, SampleTime, POVCache.DesiredFOV, *AnimatedLocation.ToString(), *AnimatedRotation.ToString(), *UserPlaySpaceMatrix.GetLocation().ToString());

	AlphaCache = 1.f;
	if(!FMath::IsNearlyZero(BlendInTime) && TotalPlayTime < BlendInTime)
	{
		AlphaCache *= FCameraEaseCalculate::Evaluate(BlendInType, 0.f, 1.f, TotalPlayTime / BlendInTime);
	}

	if(!FMath::IsNearlyZero(BlendOutTime) && PlayDuration - TotalPlayTime < BlendOutTime)
	{
		AlphaCache *= FCameraEaseCalculate::Evaluate(BlendOutType, 0.f, 1.f, (PlayDuration - TotalPlayTime) / BlendOutTime);
		if(!bStartBlendOut)
		{
			bStartBlendOut = true;
			if(CameraMgr.IsValid())
			{
				if(AnimationHandleToGUID.Contains(GetTypeHash(CameraAnimation.Handle)))
				{
					CameraMgr->KCB_Camera_OnCameraAnimStartBlendOut(AnimationHandleToGUID[GetTypeHash(CameraAnimation.Handle)]);
				}
			}
			
			POVCacheLockOutgoing = POVCache;
		}
	}

	ApplyPOV(CameraStandIn, InOutPOV);
}

void UKGCameraAnimationCameraModifier::ApplyPOV(UCameraAnimationSequenceCameraStandIn* CameraStandIn, FMinimalViewInfo& InOutPOV) const
{
	if(ActionHandlerOwner.IsValid() && ActionHandlerOwner->IsBlockingCameraActions())
	{
		return;
	}

	if(CameraMgr.IsValid() && CameraMgr->KAPI_Camera_IsCutSceneActivate())
	{
		return;
	}

	if(bCanActivate)
	{
		const FMinimalViewInfo& BlendPOV = (bLockOutgoing && bStartBlendOut) ? POVCacheLockOutgoing : POVCache;
		InOutPOV.Location = FMath::Lerp(InOutPOV.Location, BlendPOV.Location, AlphaCache);
		const FRotator DeltaAng = (BlendPOV.Rotation - InOutPOV.Rotation).GetNormalized();
		InOutPOV.Rotation = InOutPOV.Rotation + AlphaCache * DeltaAng;

		float DesiredFOV = FMath::Lerp(InOutPOV.DesiredFOV, BlendPOV.DesiredFOV, AlphaCache);
		InOutPOV.DesiredFOV = DesiredFOV;
		// float AspectRatio = InOutPOV.AspectRatio;
		// if(CameraMgr.IsValid())
		// {
		// 	AspectRatio = CameraMgr->PCAspectRatio;
		// }
		// DesiredFOV = FMath::Atan(9.f / 16.f * AspectRatio * FMath::Tan(DesiredFOV * PI / 180.f / 2)) * 2 * 180.f / PI;
		InOutPOV.FOV = DesiredFOV;

		if (CameraOwner != nullptr && CameraStandIn->PostProcessBlendWeight > 0.f)
		{
			const float TotalPostProcessBlendWeight = CameraStandIn->PostProcessBlendWeight * AlphaCache;
			CameraOwner->AddCachedPPBlend(CameraStandIn->PostProcessSettings, TotalPostProcessBlendWeight, VTBlendOrder_Override);
		}

		if(ActionHandlerOwner.IsValid())
		{
			ActionHandlerOwner->SetCameraAnimationPlaying(true);
		}
	}
}

void UKGCameraAnimationCameraModifier::StopKGCameraAnimation(uint32 HandleHash, bool bImmediate)
{
	if(AnimationHandleToGUID.Contains(HandleHash))
	{
		AnimationHandleToGUID.Remove(HandleHash);
	}
	if(HandleHash == GetTypeHash(LocationPlayCameraAnimation))
	{
		if(bImmediate)
		{
			PlayDuration = TotalPlayTime;
		}
		else
		{
			if(!bStartBlendOut)
			{
				PlayDuration = TotalPlayTime + BlendOutTime;
			}
		}
	}
}

void UKGCameraAnimationCameraModifier::Pause(int CameraAnimHandleHash, bool bInPause)
{
	if(LocationPlayCameraAnimation.IsValid() && GetTypeHash(LocationPlayCameraAnimation) == CameraAnimHandleHash)
	{
		bPause = bInPause;
	}
}

void UKGCameraAnimationCameraModifier::SetAnimationPlayAt(int CameraAnimHandleHash, float Pct)
{
	if(LocationPlayCameraAnimation.IsValid() && GetTypeHash(LocationPlayCameraAnimation) == CameraAnimHandleHash)
	{
		Pct = FMath::Clamp(Pct, 0.f, 0.999f);
		DesiredPlayTimePct = Pct;
		TotalPlayTime = DesiredPlayTimePct * PlayDuration;
	}
}

int64 UKGCameraAnimationCameraModifier::PlayCameraAnimationAtLocation(int64 GUID, int64 SequenceID, float Duration,
	float EaseInDuration, ECameraEaseFunction::Type EaseInType, float EaseOutDuration, ECameraEaseFunction::Type EaseOutType,
	FCameraAnimationParams Params, int CollisionCheckCnt, const FVector& PlayLoc, int64 UserSpacePlayer, bool bInUseTargetScale,
	bool bInUseMeshSpace, bool bInLockOutgoing, bool bInAdaptiveCameraRot, bool bInCustomPitch, double InCustomPitch)
{
	UCameraAnimationSequence* Sequence = Cast<UCameraAnimationSequence>(KGUtils::GetObjectByID(SequenceID));
	if(!Sequence)
	{
		return KG_INVALID_ID;
	}
	
	bPause = false;
	UserSpacePlayerActor = KGUtils::GetActorByID(UserSpacePlayer);
	if(UserSpacePlayerActor.IsValid())
	{
		UserSpacePlayerActorMesh = UserSpacePlayerActor->GetComponentByClass<USkeletalMeshComponent>();
	}

	AnimPlayLoc = PlayLoc;
	bUseTargetScale = bInUseTargetScale;
	bUseMeshSpace = bInUseMeshSpace;
	PlayDuration = Duration;
	TotalPlayTime = 0.f;
	BlendInTime = EaseInDuration;
	BlendInType = EaseInType;
	BlendOutTime = EaseOutDuration;
	BlendOutType = EaseOutType;
	SampleTime = 0.f;
	bStartBlendOut = false;
	bLockOutgoing = bInLockOutgoing;
	bAdaptiveCameraRot = bInAdaptiveCameraRot;

	FTransform UserPlayTM = FTransform::Identity;
	if (Params.PlaySpace != ECameraAnimationPlaySpace::CameraLocal)
	{
		if(UserSpacePlayerActor.IsValid())
		{
			if(UserSpacePlayerActorMesh.IsValid())
			{
				UserPlayTM.SetLocation(bUseMeshSpace ? UserSpacePlayerActorMesh->GetComponentLocation() : UserSpacePlayerActorMesh->GetSocketLocation(UKGCameraAnimationCameraModifier::RootName));
				if(bUseTargetScale)
				{
					UserPlayTM.SetScale3D(UserSpacePlayerActorMesh->GetComponentScale());
				}
			}
			else
			{
				UserPlayTM.SetLocation(UserSpacePlayerActor->GetActorLocation());
				if(bUseTargetScale)
				{
					UserPlayTM.SetScale3D(UserSpacePlayerActor->GetActorScale());
				}
			}
		}
		else
		{
			UserPlayTM.SetLocation(AnimPlayLoc);
		}

		UserPlayTM.SetRotation(Params.UserPlaySpaceRot.Quaternion());
	}
	
	if (!CollisionCheck(GetWorld(), Sequence, UserPlayTM, CollisionCheckCnt)) return KG_INVALID_ID;
	
	LocationPlayCameraAnimation = PlayCameraAnimation(Sequence, Params);

	if(bInAdaptiveCameraRot)
	{
		if (LocationPlayCameraAnimation.IsValid())
		{
			if (IsCameraAnimationActive(LocationPlayCameraAnimation))
			{
				if (FActiveCameraAnimationInfo* Info = GetActiveCameraAnimation(LocationPlayCameraAnimation))
				{
					UCameraAnimationSequencePlayer* Player = Info->Player;
					UCameraAnimationSequenceCameraStandIn* CameraStandIn = Info->CameraStandIn;
					const FFrameRate DisplayRate = Player->GetInputRate();
					float SampleDuration = PlayDuration;
					if(bInLockOutgoing)
					{
						SampleDuration = PlayDuration - EaseOutDuration;
					}
					if(DisplayRate.AsSeconds(Player->GetDuration()) > SampleDuration)
					{
						SampleDuration = DisplayRate.AsSeconds(Player->GetDuration());
					}
					Player->Update(Player->GetStartFrame() + DisplayRate.AsFrameTime(SampleDuration));
					CameraStandIn->RecalcDerivedData();
					const FTransform AnimatedTransform = CameraStandIn->GetTransform();
					FQuat AnimatedRotation = AnimatedTransform.GetRotation();
					FQuat BaseRot = Params.PlaySpace == ECameraAnimationPlaySpace::UserDefined ? Params.UserPlaySpaceRot.Quaternion() : FQuat::Identity;
					AdaptiveRot = (BaseRot * AnimatedRotation).Rotator();
					Player->Stop();
					Player->Play(Params.bLoop, false);
				}
			}
		}
	}

	bCustomPitch = bInCustomPitch;
	AdaptiveRot.Pitch = InCustomPitch;

	AnimationHandleToGUID.Add(GetTypeHash(LocationPlayCameraAnimation), GUID);
	return GetTypeHash(LocationPlayCameraAnimation);
}

void UKGCameraAnimationCameraModifier::SetLoop(int CameraAnimHandleHash, bool bInLoop)
{
	if(LocationPlayCameraAnimation.IsValid() && GetTypeHash(LocationPlayCameraAnimation) == CameraAnimHandleHash)
	{
		if (FActiveCameraAnimationInfo* Info = GetActiveCameraAnimation(LocationPlayCameraAnimation))
		{
			Info->Params.bLoop = bInLoop;
		}
	}
}

void UKGCameraAnimationCameraModifier::SetPlayRate(int CameraAnimHandleHash, float NewPlayRate)
{
	if(LocationPlayCameraAnimation.IsValid() && GetTypeHash(LocationPlayCameraAnimation) == CameraAnimHandleHash)
	{
		if (FActiveCameraAnimationInfo* Info = GetActiveCameraAnimation(LocationPlayCameraAnimation))
		{
			Info->Params.PlayRate = NewPlayRate;
		}
	}
}

void UKGCameraAnimationCameraModifier::OnModeActivate(int ModeTag)
{
	if(EffectCameraTags.Contains(ModeTag))
	{
		bCanActivate = true;
		return;
	}

	bCanActivate = false;
}

void UKGCameraAnimationCameraModifier::SetEffectModeTags(const TArray<int>& InModeTags, int CurrentActivateModeTag)
{
	EffectCameraTags = InModeTags;
	OnModeActivate(CurrentActivateModeTag);
}

void UKGCameraAnimationCameraModifier::SetActionHandlerOwner(UCameraActionHandler* ActionOwner)
{
	ActionHandlerOwner = ActionOwner;
	CameraMgr = Cast<ACameraManager>(CameraOwner);
}

bool UKGCameraAnimationCameraModifier::CollisionCheck(UWorld* World, UCameraAnimationSequence* Sequence, const FTransform& PivotTM,
	int Count)
{
	if (Sequence == nullptr || World == nullptr)
	{
		return false;
	}

	UMovieScene* Scene = Sequence->GetMovieScene();
	if (!Scene)
	{
		return false;
	}



	if (Count < 1)
	{
		return true;
	}
	
	static FCollisionQueryParams QueryParams{SCENE_QUERY_STAT(CameraAnimation), false};
	
	for (const FMovieSceneBinding& Binding : Scene->GetBindings())
	{
		if (!Binding.GetName().Contains(TEXT("Camera")))
		{
			continue;
		}
		const TArray<UMovieSceneTrack*>& Tracks = Binding.GetTracks();
		for (auto& Track : Tracks)
		{
			const TArray<UMovieSceneSection*>& Sections = Track->GetAllSections();
			for (UMovieSceneSection* Section : Sections)
			{
				if (UMovieScene3DTransformSection* TMSection = Cast<UMovieScene3DTransformSection>(Section))
				{
					FMovieSceneDoubleChannel* Translation = TMSection->GetTranslation();
					const FMovieSceneDoubleChannel& XChannel = Translation[0];
					const FMovieSceneDoubleChannel& YChannel = Translation[1];
					const FMovieSceneDoubleChannel& ZChannel = Translation[2];

					TRange<FFrameNumber> PlayRange = Scene->GetPlaybackRange();
					FFrameNumber EndFrame = PlayRange.GetUpperBoundValue();
					int EndIndex = EndFrame.Value;
					FFrameNumber StartFrame = PlayRange.GetLowerBoundValue();
					int StartIndex = StartFrame.Value;

					int Range = EndFrame.Value - StartFrame.Value;
					float Interval = Range * 1.f / Count;
					FVector PivotLocation = PivotTM.GetLocation();
					FVector Location;
					FHitResult HitResult;
					for (int Cnt = 0; Cnt <= Count ; ++Cnt)
					{
						float Pct = Interval * Cnt;
						float FrameFloat = Pct + StartIndex;
						int FloorIndex = FMath::FloorToInt(FrameFloat);
						FloorIndex = FMath::Clamp(FloorIndex, StartIndex, EndIndex - 1);
						int CeilIndex = FloorIndex + 1;
						float T = FrameFloat - FloorIndex;

						FFrameNumber Left{FloorIndex};
						FFrameNumber Right{CeilIndex};
						float LeftValue, RightValue;
						XChannel.Evaluate(Left, LeftValue);
						XChannel.Evaluate(Right, RightValue);
						Location.X = FMath::Lerp(LeftValue, RightValue, T);
						YChannel.Evaluate(Left, LeftValue);
						YChannel.Evaluate(Right, RightValue);
						Location.Y = FMath::Lerp(LeftValue, RightValue, T);
						ZChannel.Evaluate(Left, LeftValue);
						ZChannel.Evaluate(Right, RightValue);
						Location.Z = FMath::Lerp(LeftValue, RightValue, T);
						
						Location = PivotTM.TransformPosition(Location);
						FVector DetectStartLocation = PivotLocation + FVector::UpVector * UCameraArmComponent::ProbeSize; // 上移避开地面
#if !(UE_BUILD_SHIPPING || UE_BUILD_TEST)
						if (ACameraManager::IsCameraDebug())
						{
							// UKismetSystemLibrary::SphereTraceSingle(World, DetectStartLocation, Location, UCameraArmComponent::ProbeSize, UEngineTypes::ConvertToTraceType(UCameraArmComponent::ProbeChannel), false, {}, EDrawDebugTrace::ForDuration, HitResult, false);
							UKismetSystemLibrary::LineTraceSingle(World, DetectStartLocation, Location, UEngineTypes::ConvertToTraceType(UCameraArmComponent::ProbeChannel), false, {}, EDrawDebugTrace::ForDuration, HitResult, false);
						}
#endif
						// if (World->SweepSingleByChannel(HitResult, DetectStartLocation, Location, FQuat::Identity, UCameraArmComponent::ProbeChannel, UCameraArmComponent::ProbeSphereShape, QueryParams))
						if (World->LineTraceSingleByChannel(HitResult, DetectStartLocation, Location, UCameraArmComponent::ProbeChannel, QueryParams))
						{
							return false;
						}
					}

					return true;
				}
			}
		}
	}

	return true;
}

