﻿#include "3C/Camera/PostProcessNew/PostProcessInstance/PPPhotoContrast.h"

#include "Util/ColorConstants.h"

void KGPPPhotoContrast::InitParams(
	const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType, const FString& InContrastCurvePath)
{
	KGPPNonMaterialBase::InitParams(CommonParams, InPPManager, InPPType);
	ColorContrastID = RegisterManualWeightCurve(InContrastCurvePath, EKGManualWeightCurveType::ColorCurve);
}

void KGPPPhotoContrast::SetManualWeightCurveValue(float Weight)
{
	KGPPNonMaterialBase::SetManualWeightCurveValue(Weight);
	KG_PP_SET_LINEAR_COLOR_CURVE_PARAM(ColorContrast);
}
