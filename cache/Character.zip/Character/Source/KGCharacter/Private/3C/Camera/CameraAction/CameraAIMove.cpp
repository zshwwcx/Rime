// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Camera/CameraAction/CameraAIMove.h"
#include "3C/Camera/CameraArmComponent.h"

void UCameraAIMove::Init(const TArray<FVector>& InWorldLocations, const TArray<FRotator>& InWorldRotations,
                         int InSampleRate, float InBlendInTime, float InBlendOutTime, float InPlayRate)
{
	PivotLocations.Reset();
	if(InWorldLocations.Num() != InWorldRotations.Num())
	{
		UE_LOG(LogTemp, Error, TEXT("[Camera] Camera AI Move Get Different Number of Location And Rotation, Please Check!"))
	}

	if(InWorldRotations.Num() == 0)
	{
		Duration = 0.f;
		UE_LOG(LogTemp, Error, TEXT("[Camera] Camera AI Move Get Empty Rotation Data, Please Check!"))
		return;
	}
	
	int Frame = InWorldLocations.Num();
	if(Frame == 0)
	{
		Duration = 0.f;
		UE_LOG(LogTemp, Error, TEXT("[Camera] Camera AI Move Get Empty Location Data, Please Check!"))
		return;
	}

	// 检查并保存关键帧数据
	WorldLocations.Empty();
	for(const auto& Location : InWorldLocations)
	{
		if(Location.ContainsNaN())
		{
			Duration = 0.f;
			UE_LOG(LogTemp, Error, TEXT("[Camera] Camera AI Move Get NAN Location Data, Please Check!"))
			return;
		}
		WorldLocations.Add(Location);
	}
	// CatmullRomMoveCurve.Init(InWorldLocations);
	WorldRotations = InWorldRotations;
	SampleRate = FMath::Max(InSampleRate, 1);
	PlayRate = InPlayRate;
	Duration = (Frame * 1.f) / SampleRate;
	SetEaseInType(ECameraEaseFunction::EaseInOutCubic, InBlendInTime, KG_INVALID_ID);
	SetEaseOutType(ECameraEaseFunction::EaseInOutCubic, InBlendOutTime, KG_INVALID_ID);
}

void UCameraAIMove::Init(const TArray<FVector>& InWorldLocations, const TArray<FRotator>& InWorldRotations,
	const TArray<FVector>& InPivotLocations, int InSampleRate, float InBlendInTime, float InBlendOutTime,
	float InPlayRate)
{
	Init(InWorldLocations, InWorldRotations, InSampleRate, InBlendInTime, InBlendOutTime, InPlayRate);
	if (FMath::IsNearlyZero(Duration))
	{
		return;
	}

	if (InPivotLocations.Num() > 0)
	{
		for(const auto& Location : InPivotLocations)
		{
			if(Location.ContainsNaN())
			{
				Duration = 0.f;
				UE_LOG(LogTemp, Error, TEXT("[Camera] Camera AI Move Get NAN Pivot Location Data, Please Check!"))
				return;
			}
			PivotLocations.Add(Location);
		}
	}
}

void UCameraAIMove::ModifyViewPOV(float DeltaTime, FMinimalViewInfo& InOutPOV)
{
	if(!CameraMode.IsValid() || !CameraMode->IsActivate() || FMath::IsNearlyZero(Duration))
	{
		return;
	}

	float Pct = FMath::Clamp(RunningTime / Duration, 0.f, 1.f);

	// CatmullRomMoveCurve.Evaluate(Pct, ResultLocation);

	// 手写线性插值位置
	if(WorldLocations.Num() > 0)
	{
		if(WorldLocations.Num() == 1)
		{
			ResultLocation = WorldLocations[0];
		}
		else
		{
			// 计算插值索引
			float FrameFloat = Pct * (WorldLocations.Num() - 1);
			int FloorIndex = FMath::FloorToInt(FrameFloat);
			FloorIndex = FMath::Clamp(FloorIndex, 0, WorldLocations.Num() - 2);
			int CeilIndex = FloorIndex + 1;
			float T = FrameFloat - FloorIndex;
			
			// 线性插值
			ResultLocation = FMath::Lerp(WorldLocations[FloorIndex], WorldLocations[CeilIndex], T);
		}
	}

	if (PivotLocations.Num() > 0)
	{
		FVector PivotLocation = FVector::ZeroVector;
		if(PivotLocations.Num() == 1)
		{
			PivotLocation = PivotLocations[0];
		}
		else
		{
			// 线性插值
			float FrameFloat = Pct * (PivotLocations.Num() - 1);
			int FloorIndex = FMath::FloorToInt(FrameFloat);
			FloorIndex = FMath::Clamp(FloorIndex, 0, PivotLocations.Num() - 2);
			int CeilIndex = FloorIndex + 1;
			float T = FrameFloat - FloorIndex;
			PivotLocation = FMath::Lerp(PivotLocations[FloorIndex], PivotLocations[CeilIndex], T);
		}

		{
			FHitResult HitResult;
			if (const bool bBlockingHit = GetWorld()->SweepSingleByChannel(HitResult, PivotLocation, ResultLocation, FQuat::Identity, UCameraArmComponent::ProbeChannel, UCameraArmComponent::ProbeSphereShape, QueryParams))
			{
				if (HitResult.IsValidBlockingHit())
				{
					float Len = (HitResult.Location - PivotLocation).Size();
					FVector Dir = (HitResult.Location - PivotLocation).GetSafeNormal();
					ResultLocation = PivotLocation + Dir * Len;
				}
			}
		}
	}

	InOutPOV.Location = FMath::Lerp(InOutPOV.Location, ResultLocation, Alpha);

	// 手写线性插值旋转
	if(WorldRotations.Num() > 0)
	{
		if(WorldRotations.Num() == 1)
		{
			ResultRotation = WorldRotations[0];
		}
		else
		{
			// 计算插值索引
			float FrameFloat = Pct * (WorldRotations.Num() - 1);
			int FloorIndex = FMath::FloorToInt(FrameFloat);
			FloorIndex = FMath::Clamp(FloorIndex, 0, WorldRotations.Num() - 2);
			int CeilIndex = FloorIndex + 1;
			float T = FrameFloat - FloorIndex;
			
			// 线性插值旋转
			ResultRotation = FMath::Lerp(WorldRotations[FloorIndex], WorldRotations[CeilIndex], T);
		}
	}
	DeltaAng = (ResultRotation - InOutPOV.Rotation).GetNormalized();
	InOutPOV.Rotation = InOutPOV.Rotation + Alpha * DeltaAng;

	// UE_LOG(LogTemp, Log, TEXT("CameraAIMove Location:%s Rotation:%s ResultRotation:%s DeltaAng:%s Pct:%f T:%f FloorIndex:%d CeilIndex:%d Alpha:%f"), *InOutPOV.Location.ToString(), *InOutPOV.Rotation.ToString(), *ResultRotation.ToString(), *DeltaAng.ToString(), Pct, T, FloorIndex, CeilIndex, Alpha);
}

bool UCameraAIMove::ProcessViewRotation(class AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch,
	double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot)
{
	if(!CameraMode.IsValid() || !CameraMode->IsActivate() || FMath::IsNearlyZero(Duration))
	{
		return false;
	}

	OutDeltaRot.Pitch = 0;
	OutDeltaRot.Yaw = 0;
	OutDeltaRot.Roll = 0;
	return true;
}

