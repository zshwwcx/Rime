// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Camera/CameraAction/CameraActionParamOverride.h"

#include "3C/Camera/CameraAction/CameraActionHandler.h"
#include "3C/Camera/CameraArmComponent.h"
#include "3C/Camera/KgCameraMode.h"
#include "3C/Util/KGUtils.h"
#include "Camera/CameraComponent.h"

void UCameraActionParamOverride::InitParamOverride(float InFadeInTime, float InDurationTime, float InFadeOutTime,
	const FRotator& PlayerRotator, bool bInUseYawAdjust, float TargetYaw, bool bInUsePitchAdjust, float TargetPitch,
	bool bInUseRollAdjust, float TargetRoll, float InArmLength, float InFOV, float XOYLag, float ZLag,
	float XOYSoftRadius, float ZSoftRadius, bool bInUseViewOffsetAdjust, float ViewOffsetX, float ViewOffsetY,
	ECameraEaseFunction::Type InBlendInMode, ECameraEaseFunction::Type InBlendOutMode,
	int64 InFadeInCurveID, int64 InFadeOutCurveID, bool InbDisableLimitView)
{
	SetEaseInType(InBlendInMode, InFadeInTime, InFadeInCurveID);
	SetEaseOutType(InBlendOutMode, InFadeOutTime, InFadeOutCurveID);
	Duration = InDurationTime;

	bUsePitchAdjust = bInUsePitchAdjust;
	bUseYawAdjust = bInUseYawAdjust;
	bUseRollAdjust = bInUseRollAdjust;
	bAdjustViewOffset = bInUseViewOffsetAdjust;
	RotationAdaptive = PlayerRotator;
	if (bInUsePitchAdjust)
	{
		TargetPitch = FMath::Clamp(TargetPitch, -90, 90);
		RotationAdaptive.Pitch = TargetPitch;
	}
	if (bInUseYawAdjust)
	{
		RotationAdaptive.Yaw += TargetYaw;
		RotationAdaptive.Yaw = FRotator::NormalizeAxis(RotationAdaptive.Yaw);
	}
	if(bInUseRollAdjust)
	{
		TargetRoll = FMath::Clamp(TargetRoll, -179.99, 180);
		RotationAdaptive.Roll = TargetRoll;
	}
	TargetViewOffset.X = ViewOffsetX;
	TargetViewOffset.Y = ViewOffsetY;
	TargetArmLength = InArmLength;
	TargetCameraFOV = InFOV;
	TargetCameraXOYLag = XOYLag;
	TargetCameraZLag = ZLag;
	TargetCameraXOYSoftRadius = XOYSoftRadius;
	TargetCameraZSoftRadius = ZSoftRadius;

	bDisableLimitView = InbDisableLimitView;
	bRowDisableLimitView = InbDisableLimitView;
}

void UCameraActionParamOverride::Play()
{
	Super::Play();

	InitBaseParam();
}

void UCameraActionParamOverride::ModifyCamera(float DeltaTime)
{
	Super::ModifyCamera(DeltaTime);

	if(CameraMode.IsValid())
	{
		if(TargetArmLength >= 0)
		{
			CameraMode->SetOverrideZoomSetting(FMath::Lerp(bStartBlendOut ? CameraMode->GetOverrideZoomBelowPriority(Priority, ArmBase) : ArmBase, TargetArmLength, Alpha), Priority);
		}

		if(TargetCameraFOV >= 0)
		{
			CameraMode->SetFOVSetting(FMath::Lerp(bStartBlendOut ? CameraMode->GetFOVBelowPriority(Priority, FOVBase) : FOVBase, TargetCameraFOV, Alpha), Priority);
		}

		if(TargetCameraXOYLag >= 0)
		{
			CameraMode->SetCameraXOYLagSetting(FMath::Lerp(bStartBlendOut ? CameraMode->GetXOYLagBelowPriority(Priority, XOYLagBase) : XOYLagBase, TargetCameraXOYLag, Alpha), Priority);
		}

		if(TargetCameraZLag >= 0)
		{
			CameraMode->SetCameraZLagSetting(FMath::Lerp(bStartBlendOut ? CameraMode->GetZLagBelowPriority(Priority, ZLagBase) : ZLagBase, TargetCameraZLag, Alpha), Priority);
		}

		if(TargetCameraXOYSoftRadius >= 0)
		{
			CameraMode->SetCameraXOYSoftRadiusSetting(FMath::Lerp(bStartBlendOut ? CameraMode->GetXOYSoftRadiusBelowPriority(Priority, XOYSoftRadiusBase) : XOYSoftRadiusBase, TargetCameraXOYSoftRadius, Alpha), Priority);
		}

		if(TargetCameraZSoftRadius >= 0)
		{
			CameraMode->SetCameraZSoftRadiusSetting(FMath::Lerp(bStartBlendOut ? CameraMode->GetZSoftRadiusBelowPriority(Priority, ZSoftRadiusBase) : ZSoftRadiusBase, TargetCameraZSoftRadius, Alpha), Priority);
		}

		if(bAdjustViewOffset)
		{
			FVector2D Result = FMath::Lerp(bStartBlendOut ? CameraMode->GetPivotOffsetBelowPriority(Priority, ViewOffsetBase) : ViewOffsetBase, TargetViewOffset, FMath::Clamp(Alpha, 0.f, 1.f));
			CameraMode->SetPivotOffsetFromScreenCoOffsetSetting(Result.X, Result.Y, Priority);
		}
	}
}

bool UCameraActionParamOverride::ProcessViewRotation(AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch,
	double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot)
{
	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return false;
	}

	if(bUsePitchAdjust || bUseYawAdjust || bUseRollAdjust)
	{
		FRotator TargetRot{OutPitch, OutYaw, OutRoll};
		if(bStartBlendOut && bRecover)
		{
			if(ActionHandlerOwner.IsValid())
			{
				ActionHandlerOwner->GetRotationRecoverTo(Priority, RotationBase);
			}

		}
		const FRotator DeltaAng = (RotationAdaptive - RotationBase).GetNormalized();
		TargetRot = RotationBase + FMath::Clamp(Alpha, 0.f, 1.f) * DeltaAng;
		if(bUsePitchAdjust)
		{
			OutPitch = TargetRot.Pitch;
			bOutChangePitch = true;
			OutDeltaRot.Pitch = 0.f;
		}
		if(bUseYawAdjust)
		{
			OutYaw = TargetRot.Yaw;
			bOutChangeYaw = true;
			OutDeltaRot.Yaw = 0.f;
		}
		if(bUseRollAdjust)
		{
			OutRoll = TargetRot.Roll;
			bOutChangeRoll = true;
			OutDeltaRot.Roll = 0.f;
		}
		// UE_LOG(LogTemp, Log, TEXT("Camera Override Param Roll:%f TargetRoll:%f"), OutRoll, RotationAdaptive.Roll);
		return true;
	}

	return false;
}

void UCameraActionParamOverride::Abort()
{
	if(bDisableLimitView)
	{
		CameraManager->DisableViewLimit(false);
	}
	
	if(CameraMode.IsValid())
	{
		if(TargetCameraFOV >= 0)
		{
			CameraMode->RemoveFOVSetting(Priority);
		}

		if(TargetCameraXOYLag >= 0)
		{
			CameraMode->RemoveCameraXOYLagSetting(Priority);
		}

		if(TargetCameraZLag >= 0)
		{
			CameraMode->RemoveCameraZLagSetting(Priority);
		}

		if(TargetCameraXOYSoftRadius >= 0)
		{
			CameraMode->RemoveCameraXOYSoftRadiusSetting(Priority);
		}

		if(TargetCameraZSoftRadius >= 0)
		{
			CameraMode->RemoveCameraZSoftRadiusSetting(Priority);
		}
	}

	Super::Abort();
}

void UCameraActionParamOverride::DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode)
{
	Super::DoWhenEffectModeActivate(ActivateCameraMode);
	InitBaseParam();
}

void UCameraActionParamOverride::InitBaseParam()
{
	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return;
	}
	
	UCameraArmComponent* Arm = CameraMode->GetCameraArmComponent();
	if (Arm == nullptr)
	{
		return;
	}
	UCameraComponent* Camera = CameraMode->GetCameraComponent();
	if (Camera == nullptr)
	{
		return;
	}

	if(bRowDisableLimitView && CameraMode.IsValid())
	{
		CameraManager->DisableViewLimit(false);
		bDisableLimitView = true;
	}
	else
	{
		bDisableLimitView = false;
	}

	if(TargetArmLength >= 0)
	{
		ArmBase = Arm->GetTargetCameraZoomLen();
	}

	if(TargetCameraFOV >= 0)
	{
		FOVBase = Camera->FieldOfView;
	}

	if(bUsePitchAdjust || bUseYawAdjust || bUseRollAdjust)
	{
		RotationBase = Camera->GetComponentRotation();
	}

	if(TargetCameraXOYLag >= 0)
	{
		XOYLagBase = CameraMode->GetDesiredCameraXOYLag();
	}

	if(TargetCameraZLag >= 0)
	{
		ZLagBase = CameraMode->GetDesiredCameraZLag();
	}

	if(TargetCameraXOYSoftRadius >= 0)
	{
		XOYSoftRadiusBase = CameraMode->GetDesiredCameraXOYSoftRadius();
	}

	if(TargetCameraZSoftRadius >= 0)
	{
		TargetCameraZSoftRadius = CameraMode->GetDesiredCameraZSoftRadius();
	}

	RotationBase = CameraMode->GetCameraRotation();

	if(bAdjustViewOffset)
	{
		ViewOffsetBase = CameraMode->GetPivotOffsetSetting();
	}
}
