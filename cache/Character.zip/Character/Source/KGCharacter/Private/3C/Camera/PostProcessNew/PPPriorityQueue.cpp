#include "3C/Camera/PostProcessNew/PPPriorityQueue.h"

#include "3C/Camera/PostProcessNew/PostProcessInstance/PPBase.h"

struct KGPPCompare
{
	bool operator()(const TWeakPtr<KGPPBase>& A, const TWeakPtr<KGPPBase>& B) const
	{
		check(A.IsValid() && B.IsValid());
		const KGPPBase& ARef = *(A.Pin().Get());
		const KGPPBase& BRef = *(B.Pin().Get());
		return ARef < BRef;
	}
};
static KGPPCompare GKGPPCompare;

void KGPostProcessPriorityQueue::AddNewPostProcess(TSharedPtr<KGPPBase> PPInst)
{
	if (!PPInst.IsValid())
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPostProcessPriorityQueue::AddNewPostProcess, invalid PPInst"));
		return;
	}
	
	KGPPBase* OldEffectivePPInst = GetActivePostProcessInstance();
	PPInstances.HeapPush(PPInst.ToWeakPtr(), GKGPPCompare);
	KGPPBase* NewEffectivePPInst = GetActivePostProcessInstance();
	if (OldEffectivePPInst != NewEffectivePPInst)
	{
		if (OldEffectivePPInst)
		{
			OldEffectivePPInst->DoTaskDeactivated();
		}

		check(NewEffectivePPInst);
		NewEffectivePPInst->DoTaskActivated();
	}
}

void KGPostProcessPriorityQueue::RemovePostProcess(int32 PostProcessID)
{
	if (PPInstances.Num() == 0)
	{
		return;
	}
	
	KGPPBase* OldEffectivePPInst = GetActivePostProcessInstance();
	TSharedPtr<KGPPBase> PPInstToRemove;
	for (int32 i = 0; i < PPInstances.Num(); ++i)
	{
		const auto PPInstance = PPInstances[i].Pin();
		if (!PPInstance.IsValid())
		{
			continue;
		}
		
		if (PPInstance->GetPostProcessID() == PostProcessID)
		{
			PPInstToRemove = PPInstance;
			PPInstances.HeapRemoveAt(i, GKGPPCompare);
			break;
		}
	}

	// 对于interrupt blend out的PP Instance, 会在blend out开始时就从优先队列移除, 后续真正结束时这里确实可能为空
	if (!PPInstToRemove.IsValid())
	{
		return;
	}
	
	KGPPBase* NewEffectivePPInst = GetActivePostProcessInstance();
	if (OldEffectivePPInst != NewEffectivePPInst)
	{
		if (OldEffectivePPInst)
		{
			OldEffectivePPInst->DoTaskDeactivated();
		}

		if (NewEffectivePPInst)
		{
			NewEffectivePPInst->DoTaskActivated();
		}
	}
}

KGPPBase* KGPostProcessPriorityQueue::GetActivePostProcessInstance()
{
	if (PPInstances.Num() > 0)
	{
		return PPInstances[0].Pin().Get();
	}

	return nullptr;
}

KGPPBase* KGPostProcessPriorityQueue::GetFirstNonDummyInstance()
{
	for (int32 i = 0; i < PPInstances.Num(); ++i)
	{
		const auto PPInstance = PPInstances[i].Pin();
		if (!PPInstance.IsValid())
		{
			continue;
		}
		
		const auto PPType = PPInstance->GetPPType();
		if (PPType != EKGPostProcessType::KG_PP_Dummy)
		{
			return PPInstance.Get();
		}
	}
	
	return nullptr;
}
