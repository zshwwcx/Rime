#include "3C/Camera/PostProcessNew/PostProcessInstance/PPFilmGrain.h"

#include "Manager/KGCppAssetManager.h"
#include "3C/Camera/PostProcessNew/PostProcessManager.h"

void KGPPFilmGrain::InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType,
	const FPostProcessSettings& InPostProcessSettings, const FString& InFilmGrainTexturePath)
{
	KGPPNonMaterialBase::InitParams(CommonParams, InPPManager, InPPType, InPostProcessSettings);
	FilmGrainTexturePath = InFilmGrainTexturePath;
}

bool KGPPFilmGrain::OnTaskStart()
{
	if (!KGPPNonMaterialBase::OnTaskStart())
	{
		return false;
	}

	if (PostProcessSettings.bOverride_FilmGrainTexture)
	{
		if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(PostProcessManager.Get()))
		{
			AssetLoadID = AssetManager->AsyncLoadAsset(
				FilmGrainTexturePath, FAsyncLoadCompleteDelegate::CreateRaw(this, &KGPPFilmGrain::OnFilmGrainTextureLoaded));
		}	
	}
	
	return true;
}

void KGPPFilmGrain::OnTaskEnd(EKGPostProcessStopReason StopReason)
{
	if (AssetLoadID != 0)
	{
		if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(PostProcessManager.Get()))
		{
			AssetManager->CancelAsyncLoadByLoadID(AssetLoadID);
		}
		else
		{
			UE_LOG(LogKGPP, Error, TEXT("KGPPFilmGrain::OnTaskEnd failed, AssetManager is nullptr, %s"), *GetDebugInfo());
		}
	}
	
	KGPPNonMaterialBase::OnTaskEnd(StopReason);
}

bool KGPPFilmGrain::CanOutputPostProcess() const
{
	if (PostProcessSettings.bOverride_FilmGrainTexture && !PostProcessSettings.FilmGrainTexture.Get())
	{
		return false;
	}
	
	return KGPPNonMaterialBase::CanOutputPostProcess();
}

void KGPPFilmGrain::OnFilmGrainTextureLoaded(int InLoadID, UObject* Asset)
{
	AssetLoadID = 0;
	UTexture2D* Texture2DAsset = Cast<UTexture2D>(Asset);
	if (Texture2DAsset == nullptr)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPFilmGrain::OnFilmGrainTextureLoaded failed, asset load failed, %s, %s"), *FilmGrainTexturePath, *GetDebugInfo());
		return;
	}

	UE_LOG(LogKGPP, Log, TEXT("KGPPFilmGrain::OnFilmGrainTextureLoaded, %s, %s"), *FilmGrainTexturePath, *GetDebugInfo());
	FilmGrainTexture = TStrongObjectPtr(Texture2DAsset);
	PostProcessSettings.FilmGrainTexture = Texture2DAsset;
}
