﻿#include "3C/Camera/PostProcessNew/PostProcessInstance/PPPhotoExposure.h"

void KGPPPhotoExposure::InitParams(
	const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType,
	const FString& InExposureCurvePath, float InBaseExposureBias)
{
	KGPPNonMaterialBase::InitParams(CommonParams, InPPManager, InPPType);
	AdditionalAutoExposureBiasID = RegisterManualWeightCurve(InExposureCurvePath, EKGManualWeightCurveType::FloatCurve);
	BaseExposureBias = InBaseExposureBias;
}

void KGPPPhotoExposure::SetManualWeightCurveValue(float Weight)
{
	KGPPNonMaterialBase::SetManualWeightCurveValue(Weight);
	KG_PP_SET_FLOAT_CURVE_PARAM(AdditionalAutoExposureBias);
}
