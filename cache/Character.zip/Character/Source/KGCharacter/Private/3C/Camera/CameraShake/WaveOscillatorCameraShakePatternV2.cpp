// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Camera/CameraShake/WaveOscillatorCameraShakePatternV2.h"
#include "3C/Camera/CameraManager.h"
#include "3C/Camera/BaseCamera.h"
#include "3C/Camera/CameraArmComponent.h"

void UWaveOscillatorCameraShakePatternV2::SetArmLen(float TargetCamera)
{
	ArmLen = TargetCamera;
}

void UWaveOscillatorCameraShakePatternV2::SetCameraMgr(ACameraManager* CameraMgrPtr)
{
	CameraMgrOwner = CameraMgrPtr;
}

void UWaveOscillatorCameraShakePatternV2::StartShakePatternImpl(const FCameraShakeStartParams& Params)
{
	USimpleCameraShakePattern::StartShakePatternImpl(Params);
	if (!Params.bIsRestarting)
	{
		X.Initialize(InitialLocationOffset.X);
		Y.Initialize(InitialLocationOffset.Y);
		Z.Initialize(InitialLocationOffset.Z);

		CurrentLocationOffset = InitialLocationOffset;

		Pitch.Initialize(InitialRotationOffset.X);
		Yaw.Initialize(  InitialRotationOffset.Y);
		Roll.Initialize( InitialRotationOffset.Z);

		CurrentRotationOffset = InitialRotationOffset;

		FOV.Initialize(InitialFOVOffset);

		CurrentFOVOffset = InitialFOVOffset;
	}
}

void UWaveOscillatorCameraShakePatternV2::UpdateShakePatternImpl(const FCameraShakeUpdateParams& Params,
                                                                 FCameraShakeUpdateResult& OutResult)
{
	UpdateOscillatorsV2(Params.DeltaTime, OutResult, Params.POV);

	float BlendWeight = State.Update(Params.DeltaTime);
	if(BlendWeight != 0 && (bUseBlendInCurve || bUseBlendOutCurve))
	{
		BlendWeight = 1.f;
		if(State.IsBlendingIn())
		{
			if(bUseBlendInCurve)
			{
				BlendWeight *= GetNormalBlendInCurveValue(State.GetCurrentBlendInTime() / State.GetShakeInfo().BlendIn);
			}
			else
			{
				BlendWeight *= State.GetCurrentBlendInTime() / State.GetShakeInfo().BlendIn;
			}
		}
		if(State.IsBlendingOut())
		{
			if(bUseBlendOutCurve)
			{
				BlendWeight *= GetNormalBlendOutCurveValue(State.GetCurrentBlendOutTime() / State.GetShakeInfo().BlendOut);
			}
			else
			{
				BlendWeight *= (1.f - State.GetCurrentBlendOutTime() / State.GetShakeInfo().BlendOut);
			}
		}
	}
	OutResult.ApplyScale(BlendWeight);
}

void UWaveOscillatorCameraShakePatternV2::ScrubShakePatternImpl(const FCameraShakeScrubParams& Params,
                                                                FCameraShakeUpdateResult& OutResult)
{
	// Scrubbing is like going back to our initial state and updating directly to the scrub time.
	CurrentLocationOffset = InitialLocationOffset;
	CurrentRotationOffset = InitialRotationOffset;
	CurrentFOVOffset = InitialFOVOffset;
	
	UpdateOscillatorsV2(Params.AbsoluteTime, OutResult, Params.POV);

	float BlendWeight = State.Update(Params.AbsoluteTime);
	if(BlendWeight != 0 && (bUseBlendInCurve || bUseBlendOutCurve))
	{
		BlendWeight = 1.f;
		if(State.IsBlendingIn())
		{
			if(bUseBlendInCurve)
			{
				BlendWeight *= GetNormalBlendInCurveValue(State.GetCurrentBlendInTime() / State.GetShakeInfo().BlendIn);
			}
			else
			{
				BlendWeight *= State.GetCurrentBlendInTime() / State.GetShakeInfo().BlendIn;
			}
		}
		if(State.IsBlendingOut())
		{
			if(bUseBlendOutCurve)
			{
				BlendWeight *= GetNormalBlendOutCurveValue(State.GetCurrentBlendOutTime() / State.GetShakeInfo().BlendOut);
			}
			else
			{
				BlendWeight *= (1.f - State.GetCurrentBlendOutTime() / State.GetShakeInfo().BlendOut);
			}
		}
	}
	OutResult.ApplyScale(BlendWeight);
}

void UWaveOscillatorCameraShakePatternV2::TeardownShakePatternImpl()
{
	if(CameraMgrOwner.IsValid())
	{
		CameraMgrOwner->OnCustomShakePatternTeardown(this);
	}
	USimpleCameraShakePattern::TeardownShakePatternImpl();
}

void UWaveOscillatorCameraShakePatternV2::UpdateOscillatorsV2(float DeltaTime, FCameraShakeUpdateResult& OutResult,
                                                              const FMinimalViewInfo& POV)
{
	const float PitchAngle = Pitch.Update(DeltaTime, RotationAmplitudeMultiplier, RotationFrequencyMultiplier, CurrentRotationOffset.X);
	const float YawAngle   = Yaw.Update(  DeltaTime, RotationAmplitudeMultiplier, RotationFrequencyMultiplier, CurrentRotationOffset.Y);
	const float RollAngle  = Roll.Update( DeltaTime, RotationAmplitudeMultiplier, RotationFrequencyMultiplier, CurrentRotationOffset.Z);
	
	if(!bUsePivotRotation)
	{
		OutResult.Rotation.Pitch = PitchAngle;
		OutResult.Rotation.Yaw   = YawAngle;
		OutResult.Rotation.Roll  = RollAngle;
	}
	else
	{
		const FTransform CamTM(POV.Rotation, POV.Location);
		const FVector SourceLocation = POV.Location + POV.Rotation.RotateVector(FVector::ForwardVector) * ArmLen;
		FVector SourceToCamDir = POV.Location - SourceLocation;
		FVector AxisX = SourceToCamDir;
		AxisX.Z = 0;
		AxisX = AxisX.GetSafeNormal();
		const FVector AxisZ = FVector::UpVector;
		const FVector AxisY = AxisZ ^ AxisX;

		SourceToCamDir = SourceToCamDir.RotateAngleAxis(PitchAngle, AxisY);
		SourceToCamDir = SourceToCamDir.RotateAngleAxis(YawAngle, AxisZ);
		
		OutResult.Location = CamTM.InverseTransformPosition(SourceLocation + SourceToCamDir.GetSafeNormal() * ArmLen);
		OutResult.Rotation.Roll = RollAngle;
		//OutResult.Rotation = CamTM.InverseTransformRotation(FRotationMatrix::MakeFromX(-SourceToCamDir.GetSafeNormal()).ToQuat() * FQuat::MakeFromRotator({0, 0, RollAngle})).Rotator();
	}

	OutResult.FOV = FOV.Update(DeltaTime, 1.f, 1.f, CurrentFOVOffset);

	OutResult.Location.X += X.Update(DeltaTime, LocationAmplitudeMultiplier, LocationFrequencyMultiplier, CurrentLocationOffset.X);
	OutResult.Location.Y += Y.Update(DeltaTime, LocationAmplitudeMultiplier, LocationFrequencyMultiplier, CurrentLocationOffset.Y);
	OutResult.Location.Z += Z.Update(DeltaTime, LocationAmplitudeMultiplier, LocationFrequencyMultiplier, CurrentLocationOffset.Z);
}

float UWaveOscillatorCameraShakePatternV2::GetNormalBlendInCurveValue(float Ratio) const
{
	const auto FirstKey = BlendInCurve.GetRichCurveConst()->GetFirstKey();
	const auto LastKey = BlendInCurve.GetRichCurveConst()->GetLastKey();
	const float MinTime = FirstKey.Time;
	const float MinValue = FirstKey.Value;
	const float MaxTime = LastKey.Time;
	const float MaxValue = LastKey.Value;
	if(MaxValue - MinValue == 0)
	{
		return 0;
	}
	return (BlendInCurve.GetRichCurveConst()->Eval(Ratio * (MaxTime - MinTime) + MinTime) - MinValue) / (MaxValue - MinValue);
}

float UWaveOscillatorCameraShakePatternV2::GetNormalBlendOutCurveValue(float Ratio) const
{
	const auto FirstKey = BlendOutCurve.GetRichCurveConst()->GetFirstKey();
	const auto LastKey = BlendOutCurve.GetRichCurveConst()->GetLastKey();
	const float MinTime = FirstKey.Time;
	const float MaxValue = FirstKey.Value;
	const float MaxTime = LastKey.Time;
	const float MinValue = LastKey.Value;
	if(MaxValue - MinValue == 0)
	{
		return 0;
	}
	return (BlendOutCurve.GetRichCurveConst()->Eval(Ratio * (MaxTime - MinTime) + MinTime) - MinValue) / (MaxValue - MinValue);
}
