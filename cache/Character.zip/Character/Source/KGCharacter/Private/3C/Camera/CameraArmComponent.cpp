#include "3C/Camera/CameraArmComponent.h"

#include "3C/Controller/BasePlayerController.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Camera/CameraManager.h"
#include "GameFramework/Pawn.h"
#include "CollisionQueryParams.h"
#include "Engine/World.h"
#include "3C/Camera/KgCameraMode.h"
#include "DrawDebugHelpers.h"
#include "Manager/KGBasicManager.h"
#include "KGWaterSubsystem.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "3C/Util/KGUtils.h"
#include "3C/Material/KGMaterialManager.h"
#include "Camera/CameraComponent.h"
#include "Components/PrimitiveComponent.h"
#include "Engine/OverlapResult.h"
#include "Kismet/GameplayStatics.h"


const FName UCameraArmComponent::SocketName(TEXT("SpringEndpoint"));
const TEnumAsByte<ECollisionChannel> UCameraArmComponent::ProbeChannel = ECC_Camera;
const FCollisionShape UCameraArmComponent::ProbeSphereShape = FCollisionShape::MakeSphere(12.f);
const float UCameraArmComponent::ProbeSize = 12.f;

UCameraArmComponent::UCameraArmComponent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryComponentTick.bCanEverTick = false;
	// PrimaryComponentTick.TickGroup = TG_PostPhysics;

	ResetConfig();
	if(ACameraActor* CameraActor = Cast<ACameraActor>(GetAttachmentRootActor()))
	{
		CameraOwner = CameraActor->GetCameraComponent();
	}
}

void UCameraArmComponent::MarkInstantBlend(bool bEnable)
{
	bMarkInstantBlend = bEnable;
}

FRotator UCameraArmComponent::GetControlRotation()
{
	FRotator DesiredRot = GetComponentRotation();

	if (bUsePawnControlRotation)
	{
		if(ControlActor.IsValid())
		{
			if (APawn* OwningPawn = Cast<APawn>(ControlActor.Get()))
			{
				const FRotator PawnViewRotation = OwningPawn->GetViewRotation();
				if (DesiredRot != PawnViewRotation)
				{
					DesiredRot = PawnViewRotation;
				}
			}
		}
		else if(!ControlActor.IsExplicitlyNull())
		{
			// 切图时Actor销毁 使用上一帧旋转
			if(CachedPivotRotation.ContainsNaN())
			{
				CachedPivotRotation = FRotator::ZeroRotator;
			}
			return CachedPivotRotation;
		}
	}

	// If inheriting rotation, check options for which components to inherit
	if (!IsUsingAbsoluteRotation())
	{
		const FRotator LocalRelativeRotation = GetRelativeRotation();
		if (!bInheritPitch)
		{
			DesiredRot.Pitch = LocalRelativeRotation.Pitch;
		}

		if (!bInheritYaw)
		{
			DesiredRot.Yaw = LocalRelativeRotation.Yaw;
		}

		if (!bInheritRoll)
		{
			DesiredRot.Roll = LocalRelativeRotation.Roll;
		}
	}

	return DesiredRot + TargetRotOffset;
}

void UCameraArmComponent::UpdateDesiredArmLocation(bool bDoTrace, bool bDoLocationLag, bool bDoRotationLag, float DeltaTime, bool bForceUpdate)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("Camera Update Arm");

	if(!bDoLocationLag)
	{
		TargetArmLength.MarkFinish();
	}

	CurArmLength = (OverrideZoom >= 0.f ? OverrideZoom : TargetArmLength.Evaluate(DeltaTime)) + ArmZoomOffset;
	if(CurActivateMode.IsValid())
	{
		CurActivateMode->UpdateControlData(DeltaTime);
	}
	CachedBaseArmLength = TargetArmLength.Evaluate(0.f);
	FRotator DesiredRot = GetControlRotation();

	TRACE_CPUPROFILER_EVENT_SCOPE_STR("Camera Update Arm Location");
	if(bDoRotationLag)
	{
		if (bUseCameraLagSubstepping && DeltaTime > CameraLagMaxTimeStep)
		{
			FRotator LerpTarget = CameraRotationEaseParam.Evaluate(0).Rotator();
			const FRotator ArmRotStep = (DesiredRot - LerpTarget).GetNormalized() * (1.f / DeltaTime);
			float RemainingTime = DeltaTime;
			while (RemainingTime > KINDA_SMALL_NUMBER)
			{
				const float LerpAmount = FMath::Min(CameraLagMaxTimeStep, RemainingTime);
				LerpTarget += ArmRotStep * LerpAmount;
				RemainingTime -= LerpAmount;

				CameraRotationEaseParam.RefreshEnd(FQuat(LerpTarget));
				DesiredRot = CameraRotationEaseParam.Evaluate(LerpAmount).Rotator();
			}
		}
		else
		{
			CameraRotationEaseParam.RefreshEnd(FQuat(DesiredRot));
			DesiredRot = CameraRotationEaseParam.Evaluate(DeltaTime).Rotator();
		}
	}
	else
	{
		CameraRotationEaseParam.Refresh(FQuat(DesiredRot), FQuat(DesiredRot));
		CameraRotationEaseParam.MarkFinish();
	}
	CachedPivotRotation = DesiredRot;
	
	// Get the spring arm 'origin', the target we want to look at
	FVector ArmOrigin = GetComponentLocation();
	ArmOrigin += OriginWorldOffset;
	FRotator NormalizeRot = DesiredRot;
	NormalizeRot.Pitch = 0.f; 
	ArmOrigin += FRotationMatrix(NormalizeRot).TransformVector(TargetOffset);

	TRACE_CPUPROFILER_EVENT_SCOPE_STR("Camera Update Arm Rotation");
	// We lag the target, not the actual camera position, so rotating the camera around does not have lag
	FVector DesiredLoc = ArmOrigin;
	if (bDoLocationLag)
	{
		FVector ResultLoc = ArmOrigin;
		CachedTargetSpeed = (ArmOrigin - CachedArmOrigin) / DeltaTime;
		FVector TempVector = CachedTargetSpeed;
		TempVector.Z = 0;
		CameraLocationEaseParamZ.SetSpringTargetSpeed(CachedTargetSpeed.Z);
		CameraLocationEaseParam.SetSpringTargetSpeed(TempVector);
		if (bUseCameraLagSubstepping && DeltaTime > CameraLagMaxTimeStep)
		{
			FVector LerpTarget = CachedArmOrigin;
			const FVector ArmMovementStep = (ArmOrigin - CachedArmOrigin) * (1.f / DeltaTime);
		
			float RemainingTime = DeltaTime;
			while (RemainingTime > KINDA_SMALL_NUMBER)
			{
				const float LerpAmount = FMath::Min(CameraLagMaxTimeStep, RemainingTime);
				LerpTarget += ArmMovementStep * LerpAmount;
				RemainingTime -= LerpAmount;
		
				TempVector = LerpTarget;
				TempVector.Z = 0;
		
				CameraLocationEaseParamZ.RefreshEnd(LerpTarget.Z);
				CameraLocationEaseParam.RefreshEnd(TempVector);
				ResultLoc = CameraLocationEaseParam.Evaluate(LerpAmount);
				ResultLoc.Z = CameraLocationEaseParamZ.Evaluate(LerpAmount);
				DesiredLoc = ResultLoc;
			}
		}
		else
		{
			TempVector = DesiredLoc;
			TempVector.Z = 0;
		
			CameraLocationEaseParamZ.RefreshEnd(DesiredLoc.Z);
			CameraLocationEaseParam.RefreshEnd(TempVector);
			ResultLoc = CameraLocationEaseParam.Evaluate(DeltaTime);
			ResultLoc.Z = CameraLocationEaseParamZ.Evaluate(DeltaTime);
			DesiredLoc = ResultLoc;
		}

		CachedArmOriginAfterLag = DesiredLoc;

		bool bClampedDist = false;
		if (SoftZoneRadiusXOY >= 0.f)
		{
			FVector FromOrigin = DesiredLoc - ArmOrigin;
			FromOrigin.Z = 0;
			if (FromOrigin.SizeSquared() > FMath::Square(SoftZoneRadiusXOY))
			{
				const FVector NewLoc = ArmOrigin + FromOrigin.GetClampedToMaxSize(SoftZoneRadiusXOY);
				DesiredLoc.X = NewLoc.X;
				DesiredLoc.Y = NewLoc.Y;
				if(CameraLocationEaseParam.EaseType != ECameraEaseFunction::Spring)
				{
					CameraLocationEaseParam.RefreshStart(NewLoc);
				}
				bClampedDist = true;
			}
		}
		if (SoftZoneRadiusZ >= 0.f)
		{
			FVector FromOrigin = DesiredLoc - ArmOrigin;
			FromOrigin.X = 0;
			FromOrigin.Y = 0;
			if (FromOrigin.SizeSquared() > FMath::Square(SoftZoneRadiusZ))
			{
				const FVector NewLoc = ArmOrigin + FromOrigin.GetClampedToMaxSize(SoftZoneRadiusZ);
				DesiredLoc.Z = NewLoc.Z;
				if(CameraLocationEaseParamZ.EaseType != ECameraEaseFunction::Spring)
				{
					CameraLocationEaseParamZ.RefreshStart(NewLoc.Z);
				}
				bClampedDist = true;
			}
		}	

		CachedArmOriginAfterRadius = DesiredLoc;

#if !(UE_BUILD_SHIPPING || UE_BUILD_TEST)
		if (ACameraManager::IsCameraDebug())
		{
			DrawDebugSphere(GetWorld(), GetComponentLocation(), 5.f, 8, FColor::Cyan);
			DrawDebugSphere(GetWorld(), ArmOrigin, 5.f, 8, FColor::Green);
			DrawDebugSphere(GetWorld(), DesiredLoc, 5.f, 8, FColor::Yellow);

			const FVector ToOrigin = ArmOrigin - DesiredLoc;
			DrawDebugDirectionalArrow(GetWorld(), DesiredLoc, DesiredLoc + ToOrigin * 0.5f, 7.5f, bClampedDist ? FColor::Red : FColor::Green);
			DrawDebugDirectionalArrow(GetWorld(), DesiredLoc + ToOrigin * 0.5f, ArmOrigin,  7.5f, bClampedDist ? FColor::Red : FColor::Green);
		}
#endif
	}
	else
	{
		CameraLocationEaseParam.Refresh(DesiredLoc, DesiredLoc);
		CameraLocationEaseParam.MarkFinish();
		CameraLocationEaseParamZ.Refresh(DesiredLoc.Z, DesiredLoc.Z);
		CameraLocationEaseParamZ.MarkFinish();
	}
#if !(UE_BUILD_SHIPPING || UE_BUILD_TEST)
	if(!FMath::IsNearlyZero(DeltaTime))
	{
		CachedSpeed = (DesiredLoc - PreviousDesiredLoc) / DeltaTime;
	}
#endif

	PreviousDesiredLoc = DesiredLoc;
	CachedArmOrigin = ArmOrigin;
	CachedPivotLocation = DesiredLoc;

	UpdatePivotOffsetFromScreenCoOffset(DesiredLoc, DesiredRot, CurArmLength, DeltaTime);

	CachedPivotLocationAfterOffset = DesiredLoc;

	DesiredLoc -= DesiredRot.Vector() * CurArmLength;
	DesiredLoc += FRotationMatrix(DesiredRot).TransformVector(SocketOffset);

	TRACE_CPUPROFILER_EVENT_SCOPE_STR("Camera Update Arm Collision");
	// Do a sweep to ensure we are not penetrating the world
	FVector ResultLoc = DesiredLoc;
	if (bDoTrace && (TargetArmLength.Evaluate(0) != 0.0f))
	{
		bIsCameraFixed = true;
		QueryParams.ClearIgnoredSourceObjects();
		QueryParams.AddIgnoredActor(LookAtTarget.Get());

		//把探测开始位置调整下, 避免碰撞凹面,相机拉近
		FVector SweepDir = DesiredLoc - CachedPivotLocation;
		SweepDir.Normalize();
		FVector SweepStart = CachedPivotLocation;

		FHitResult HitResult;

		bool bBlockingHit = false;
		FVector BlockLocation = DesiredLoc;

		if (bNewCollision)
		{
			HitResults.Reset();
			SelfHitResults.Reset();
			bBlockingHit = GetWorld()->SweepMultiByObjectType(SelfHitResults, bForceUpdate ? DesiredLoc : PreviousResultLoc, DesiredLoc, FQuat::Identity, NewCollisionDetectQueryParam, ProbeSphereShape, QueryParams);
			for(int Index = SelfHitResults.Num() - 1; Index > -1; --Index)
			{
				auto& SelfHitResult = SelfHitResults[Index];
				if(SelfHitResult.Component->GetCollisionResponseToChannels().GetResponse(ECC_Camera) != ECR_Block)
				{
					SelfHitResults.RemoveAt(Index);
				}
			}
			if(SelfHitResults.Num() == 0)
			{
				bBlockingHit = false;
			}
			else
			{
				bool bCheckPass = false;
				GetWorld()->SweepMultiByObjectType(HitResults, SweepStart, DesiredLoc, FQuat::Identity, NewCollisionDetectQueryParam, ProbeSphereShape, QueryParams);
				for(auto& HitResultToCheck : HitResults)
				{
					for(auto& TaggedHitResult : SelfHitResults)
					{
						if(HitResultToCheck.Component == TaggedHitResult.Component)
						{
							HitResult = HitResultToCheck;
							bCheckPass = true;
							break;
						}
					}
					if(bCheckPass) break;
				}
				if(!bCheckPass)
				{
					bBlockingHit = false;
					// bBlockingHit = GetWorld()->SweepSingleByChannel(HitResult, SweepStart, DesiredLoc, FQuat::Identity, ProbeChannel, ProbeSphereShape, QueryParams);
				}
			}
		}
		else
		{
			bBlockingHit = GetWorld()->SweepSingleByChannel(HitResult, SweepStart, DesiredLoc, FQuat::Identity, ProbeChannel, ProbeSphereShape, QueryParams);
		}
		if(bBlockingHit) BlockLocation = HitResult.Location;

		UnfixedCameraPosition = DesiredLoc;

 		ResultLoc = BlendCollisionLocations(CachedPivotLocation, DesiredLoc, BlockLocation, bBlockingHit, bDoLocationLag, DeltaTime);

		bIsPreviousBlockingHit = bBlockingHit;
	}

	// 水面
	if (bWaterCollision)
	{
		if (UKGWaterSubsystem* WaterSubsystem = UKGWaterSubsystem::GetWaterSubsystem(GetWorld()))
		{
			float WaterHeight = WaterSubsystem->GetWaterHeight(ResultLoc);
			if (ACameraManager::IsCameraDebug())
			{
				UE_LOG(LogTemp, Log, TEXT("Camera Water Height:%f ResultLoc.Z:%f CachedPivotLocation.Z:%f"), WaterHeight, ResultLoc.Z, CachedPivotLocationAfterOffset.Z);
			}
			if (ResultLoc.Z < WaterHeight + WaterHeightCorrect && CachedPivotLocation.Z > WaterHeight)
			{
				// 往前推
				FVector CollisionDir = ResultLoc - CachedPivotLocation;
				float CollisionPitch = -FRotator::NormalizeAxis(CollisionDir.ToOrientationRotator().Pitch);
				float CollisionLen = CollisionDir.Length();
				float Rad = FMath::DegreesToRadians(CollisionPitch);
				FVector BlockLocation = CachedPivotLocation + CollisionDir.GetSafeNormal() * FMath::Max(0, CollisionLen - (WaterHeight + WaterHeightCorrect - ResultLoc.Z) / FMath::Sin(Rad));

				ResultLoc = BlendCollisionLocations(CachedPivotLocation, DesiredLoc, BlockLocation, true, bDoLocationLag, DeltaTime);
			}
		}
	}
	
	if (ResultLoc == DesiredLoc) 
	{	
		bIsCameraFixed = false;
		UnfixedCameraPosition = ResultLoc;
	}

	FVector RotDir = DesiredRot.Vector();
	RealArmLen = RotDir | (CachedPivotLocation - ResultLoc);
	FTransform WorldCamTM(DesiredRot, ResultLoc);
	FTransform RelCamTM = WorldCamTM.GetRelativeTransform(GetComponentTransform());

	// Update socket location/rotation
	RelativeSocketLocation = RelCamTM.GetLocation();
	RelativeSocketRotation = (RelCamTM.Rotator() + SocketRotOffset).Quaternion();
	if(bEnableGlobalDitherFade && bEnableDitherFade)
	{
		bNeedDitherStatic = bNeedDitherStatic | ((PreviousResultLoc - ResultLoc).SizeSquared() > CameraPosDiffThreshold);
	}
	PreviousResultLoc = ResultLoc;

	UpdateChildTransforms();

	if (!bForceUpdate) // PostProcess一帧一次够了
	{
		PostProcess(DeltaTime, ResultLoc + RotDir * RealArmLen, ResultLoc, DesiredRot.Pitch);
	}
}

void UCameraArmComponent::ForceUpdate(bool bDoTrace)
{
	UpdateDesiredArmLocation(bDoTrace, false, false, 0, true);
}

void UCameraArmComponent::ForceUpdateWithBaseCollision()
{
	bool bRowNewCollision = bNewCollision;
	bNewCollision = false;
	UpdateDesiredArmLocation(true, false, false, 0, true);
	bNewCollision = bRowNewCollision;
}

void UCameraArmComponent::UpdateArms(float DeltaTime)
{
	UpdateDesiredArmLocation(bDoCollisionTest, bEnableCameraLag && !bMarkInstantBlend, bEnableCameraRotationLag && !bMarkInstantBlend, DeltaTime);
	bMarkInstantBlend = false;
}

FVector UCameraArmComponent::BlendCollisionLocations(const FVector& ArmOrigin, const FVector& DesiredArmLocation, const FVector& TraceHitLocation, bool bHitSomething, bool bDoLocationLag, float DeltaTime)
{
	const FVector DesiredRelativeLoc = bHitSomething ? (TraceHitLocation - ArmOrigin) : (DesiredArmLocation - ArmOrigin);
	const float DesiredLen = DesiredRelativeLoc.Length();

	if (!bHitSomething && bIsPreviousBlockingHit)
	{
		bIsHitReleaseComplete = false;
	}

	if (!bIsHitReleaseComplete)
	{
		bIsHitReleaseComplete = FMath::IsNearlyEqual(PreviousHitBlendLength, DesiredLen);
	}

	CollisionSpringReleaseParam.Refresh(PreviousHitBlendLength, DesiredLen);
	CollisionSpringCompressParam.Refresh(PreviousHitBlendLength, DesiredLen);
	if (bDoLocationLag)
	{
		if (!bHitSomething && bIsHitReleaseComplete)
		{
			// 前面位置插值，缩放插值都做了，这里不另作插值
			PreviousHitBlendLength = DesiredLen;
			return DesiredArmLocation;
		}

		if (PreviousHitBlendLength < DesiredLen)
		{
			PreviousHitBlendLength = CollisionSpringReleaseParam.Evaluate(DeltaTime);
			return ArmOrigin + DesiredRelativeLoc.GetSafeNormal() * PreviousHitBlendLength;
		}

		if(PreviousHitBlendLength > DesiredLen)
		{
			PreviousHitBlendLength = CollisionSpringCompressParam.Evaluate(DeltaTime);
			return ArmOrigin + DesiredRelativeLoc.GetSafeNormal() * PreviousHitBlendLength;
		}

		PreviousHitBlendLength = DesiredLen;
	}
	else
	{
		PreviousHitBlendLength = DesiredLen;
		CollisionSpringReleaseParam.MarkFinish();
		CollisionSpringCompressParam.MarkFinish();
	}

	return bHitSomething ? TraceHitLocation : DesiredArmLocation;
}

void UCameraArmComponent::OnRegister()
{
	Super::OnRegister();

	// enforce reasonable limits to avoid potential div-by-zero
	CameraLagMaxTimeStep = FMath::Max(CameraLagMaxTimeStep, 1.f / 200.f);

	UpdateDesiredArmLocation(false, false, false, 0.f);
}

void UCameraArmComponent::OnUnregister()
{
	Super::OnUnregister();
}

void UCameraArmComponent::PostLoad()
{
	Super::PostLoad();
}

void UCameraArmComponent::TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	// UpdateArms(DeltaTime);
}

FTransform UCameraArmComponent::GetSocketTransform(FName InSocketName, ERelativeTransformSpace TransformSpace) const
{
	FTransform RelativeTransform(RelativeSocketRotation, RelativeSocketLocation);

	switch(TransformSpace)
	{
		case RTS_World:
		{
			return RelativeTransform * GetComponentTransform();
			break;
		}
		case RTS_Actor:
		{
			if(const AActor* Actor = LookAtTarget.Get())
			{
				FTransform SocketTransform = RelativeTransform * GetComponentTransform();
				return SocketTransform.GetRelativeTransform(Actor->GetTransform());
			}
			break;
		}
		case RTS_Component:
		{
			return RelativeTransform;
		}
	}
	return RelativeTransform;
}

bool UCameraArmComponent::HasAnySockets() const
{
	return true;
}

void UCameraArmComponent::QuerySupportedSockets(TArray<FComponentSocketDescription>& OutSockets) const
{
	new (OutSockets) FComponentSocketDescription(SocketName, EComponentSocketType::Socket);
}

FVector UCameraArmComponent::GetUnfixedCameraPosition() const
{
	return UnfixedCameraPosition;
}

bool UCameraArmComponent::IsCollisionFixApplied() const
{
	return bIsCameraFixed;
}

void UCameraArmComponent::InitCollisionReleaseLagParam(ECameraEaseFunction::Type EaseType, float Param, int64 CurveID)
{
	float CurCollisionArmLength = CollisionSpringReleaseParam.Evaluate(0.f);
	switch (EaseType)
	{
	case ECameraEaseFunction::Spring:
		CollisionSpringReleaseParam.SetSpring(CurCollisionArmLength, CurCollisionArmLength, Param, 0, 0);
		break;
	case ECameraEaseFunction::Decay:
		CollisionSpringReleaseParam.SetDecay(CurCollisionArmLength, CurCollisionArmLength, Param);
		break;
	case ECameraEaseFunction::Curve:
		{
			UCurveFloat* NewCurve = Cast<UCurveFloat>(KGUtils::GetObjectByID(CurveID));
			CollisionSpringReleaseParam.SetCurve(CurCollisionArmLength, CurCollisionArmLength, Param, NewCurve);
		}
		break;
	default:
		CollisionSpringReleaseParam.SetEase(CurCollisionArmLength, CurCollisionArmLength, Param, EaseType);
		break;
	}
}

void UCameraArmComponent::InitCollisionCompressLagParam(ECameraEaseFunction::Type EaseType, float Param, int64 CurveID)
{
	float CurCollisionArmLength = CollisionSpringCompressParam.Evaluate(0.f);
	switch (EaseType)
	{
	case ECameraEaseFunction::Spring:
		CollisionSpringCompressParam.SetSpring(CurCollisionArmLength, CurCollisionArmLength, Param, 0, 0);
		break;
	case ECameraEaseFunction::Decay:
		CollisionSpringCompressParam.SetDecay(CurCollisionArmLength, CurCollisionArmLength, Param);
		break;
	case ECameraEaseFunction::Curve:
		{
			UCurveFloat* NewCurve = Cast<UCurveFloat>(KGUtils::GetObjectByID(CurveID));
			CollisionSpringCompressParam.SetCurve(CurCollisionArmLength, CurCollisionArmLength, Param, NewCurve);
		}
		break;
	default:
		CollisionSpringCompressParam.SetEase(CurCollisionArmLength, CurCollisionArmLength, Param, EaseType);
		break;
	}
}

void UCameraArmComponent::EnableNewCollision(bool bEnable, const TArray<int>& NewCollisionDetectTypes)
{
	if(bNewCollision != bEnable)
	{
		bNewCollision = bEnable;
		CollisionDetectTypes.Reset();
		if(bEnable)
		{
			for(auto& Type : NewCollisionDetectTypes)
			{
				CollisionDetectTypes.Emplace(static_cast<EObjectTypeQuery>(Type));
			}
		}
		NewCollisionDetectQueryParam = CollisionDetectTypes;
	}
}

void UCameraArmComponent::InitArmLagParam(ECameraEaseFunction::Type EaseType, float Param, int64 CurveID)
{
	float CurTargetArmLength = TargetArmLength.Evaluate(0.f);
	switch (EaseType)
	{
	case ECameraEaseFunction::Spring:
		TargetArmLength.SetSpring(CurTargetArmLength, CurTargetArmLength, Param, 0, 0);
		break;
	case ECameraEaseFunction::Decay:
		TargetArmLength.SetDecay(CurTargetArmLength, CurTargetArmLength, Param);
		break;
	case ECameraEaseFunction::Curve:
		{
			UCurveFloat* NewCurve = Cast<UCurveFloat>(KGUtils::GetObjectByID(CurveID));
			TargetArmLength.SetCurve(CurTargetArmLength, CurTargetArmLength, Param, NewCurve);
		}
		break;
	default:
		TargetArmLength.SetEase(CurTargetArmLength, CurTargetArmLength, Param, EaseType);
		break;
	}
}

void UCameraArmComponent::SetZoomSetting(float Min, float Max, bool bFix)
{
	float OldMin = MinZoom;
	float OldMax = MaxZoom;
	MinZoom = Min;
	MaxZoom = Max;
	if(OverrideZoom >= 0.f)
	{
		TargetArmLength.RefreshEnd(FMath::Clamp(TargetArmLength.Evaluate(0.f), MinZoom, MaxZoom));
	}
	else
	{
		if(bFix && (OldMin != MinZoom || OldMax != MaxZoom))
		{
			float CurLen = TargetArmLength.Evaluate(0.f);
			float Ratio = 0.5f;
			if(OldMin != OldMax)
			{
				Ratio = (CurLen - OldMin) / (OldMax - OldMin);
			}
			OnUpdateZoom(Ratio * (MaxZoom - MinZoom) + MinZoom);
		}
		else
		{
			OnUpdateZoom(FMath::Clamp(TargetArmLength.Evaluate(0.f), MinZoom, MaxZoom));
		}
	}
}

void UCameraArmComponent::SetControlConfig(class UKgCameraMode* TargetMode)
{
	CurActivateMode = TargetMode;
}

void UCameraArmComponent::MarkDeActiveByMode()
{
	EnableDitherFade(false, {}, {}, 0, 0.f, 0.f);
}

void UCameraArmComponent::BeginPlay()
{
	Super::BeginPlay();
	PC.Reset();
	CameraMgr = Cast<ACameraManager>(UGameplayStatics::GetPlayerCameraManager(GetWorld(), 0));
	CameraActorOwner = GetOwner();
	if(CameraMgr.IsValid())
	{
		PC = Cast<ABasePlayerController>(CameraMgr->PCOwner);
	}
}

void UCameraArmComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
}

void UCameraArmComponent::ResetConfig()
{
	bDoCollisionTest = true;

	CurActivateMode.Reset();

	bMarkInstantBlend = false;
	bUsePawnControlRotation = true;
	bInheritPitch = true;
	bInheritYaw = true;
	bInheritRoll = true;

	ControlActor = nullptr;
	LookAtTarget = nullptr;
	bLookAtMainPlayer = false;

	bEnableCameraRotationLag = true;
	bEnableCameraLag = true;
	bDoCollisionTest = true;
	bNewCollision = false;

	MinZoom = 0;
	MaxZoom = 0;
	SoftZoneRadiusXOY = 0.f;
	SoftZoneRadiusZ = 0.f;
	DitherFadeObjectTypes.Empty();
	CollisionDetectTypes.Empty();
	NewCollisionDetectQueryParam.ObjectTypesToQuery = 0;
	NewCollisionDetectQueryParam.IgnoreMask = 0;

	PivotOffsetForScreenCoOff = FVector::ZeroVector;
	RelativeCachedPivotOffset = FVector::ZeroVector;

	DitherFadeDetectType = 1;
	DitherFadeDetectRadius = 50;

	SocketOffset = FVector::ZeroVector;
	SocketRotOffset = FRotator::ZeroRotator;
	TargetOffset = FVector::ZeroVector;
	OriginWorldOffset = FVector::ZeroVector;
	TargetRotOffset = FRotator::ZeroRotator;

	ArmZoomOffset = 0;
	OverrideZoom = -1.f;

	bWaterCollision = false;
	WaterHeightCorrect = 0.f;
	
	CameraRotationEaseParam.SetDecay(FQuat::Identity, FQuat::Identity, 0.f);
	CameraLocationEaseParam.SetDecay(FVector::ZeroVector, FVector::ZeroVector, 0.f);
	CameraLocationEaseParamZ.SetDecay(0.f, 0.f, 0.f);
	TargetArmLength.SetDecay(0.f, 0.f, 0.f);
	CollisionSpringReleaseParam.SetDecay(0.f, 0.f, 0.f);
	CollisionSpringCompressParam.SetDecay(0.f, 0.f, 0.f);
	SetPivotOffsetFromScreenCoOffset(0, 0);
	
	bEnableGlobalDitherFade = CameraMgr.IsValid() ? CameraMgr->KAPI_Camera_CanCameraDitherFade() : false;
	EnableDitherFade(false, {}, {}, 0, 0.0f, 0.f);
}

#pragma region ArmLengthLerp
void UCameraArmComponent::OnUpdateZoom(float Target, bool bImmediate)
{
	if(OverrideZoom >= 0.f)
	{
		return;
	}

	Target = FMath::Clamp(Target, MinZoom, MaxZoom);

	if (!bIsHitReleaseComplete)
	{
		bIsHitReleaseComplete = true;
		TargetArmLength.RefreshStart(RealArmLen);
	}
	else
	{
		TargetArmLength.RefreshStart(TargetArmLength.Evaluate(0.f));
	}

	TargetArmLength.RefreshEnd(Target);
	if(bImmediate)
	{
		TargetArmLength.RefreshStart(Target);
	}
}

void UCameraArmComponent::ManualSetZoom(float InZoom)
{
	if(OverrideZoom < 0.f)
	{
		TargetArmLength.Refresh(InZoom, InZoom);
		if (!bIsHitReleaseComplete)
		{
			bIsHitReleaseComplete = true;
		}
	}
}

void UCameraArmComponent::SetOverrideZoom(float CurZoom)
{
	OverrideZoom = CurZoom;
	if(OverrideZoom >= 0.f)
	{
		TargetArmLength.Refresh(OverrideZoom, OverrideZoom);
		if (!bIsHitReleaseComplete)
		{
			bIsHitReleaseComplete = true;
		}
	}
}

void UCameraArmComponent::SetZoomOffset(float Target)
{
	ArmZoomOffset = Target;
}

float UCameraArmComponent::GetTargetCameraZoomLen()
{
	return TargetArmLength.GetEnd();
}

float UCameraArmComponent::GetCameraCurrentBaseZoomLen()
{
	return TargetArmLength.Evaluate(0);
}

float UCameraArmComponent::GetCameraCurrentZoomLen()
{
	return TargetArmLength.Evaluate(0) + ArmZoomOffset;
}

float UCameraArmComponent::GetCameraCachedBaseArmLen()
{
	return CachedBaseArmLength;
}

float UCameraArmComponent::GetRealCameraArmLen() const
{
	return RealArmLen;
}

FVector2D UCameraArmComponent::GetCameraXYZLagParam() const
{
	return {CameraLocationEaseParam.GetParam(), CameraLocationEaseParamZ.GetParam()};
}

void UCameraArmComponent::SetCameraXYZLagParam(const FVector2D& NewXYZLag)
{
	if(NewXYZLag.X >= 0)
	{
		CameraLocationEaseParam.SetParam(NewXYZLag.X);
	}

	if(NewXYZLag.Y >= 0)
	{
		CameraLocationEaseParamZ.SetParam(NewXYZLag.Y);
	}
}

#pragma endregion ArmLengthLerp

#pragma region ScreenViewOffset

void UCameraArmComponent::SetPivotOffsetFromScreenCoOffset(float OffX, float OffY)
{
	ScreenViewOffset.X = OffX;
	ScreenViewOffset.Y = OffY;
}

void UCameraArmComponent::UpdatePivotOffsetFromScreenCoOffset(FVector& DesiredLoc, const FRotator& CamRot, float ArmLen, float TimeDelta)
{
	if(!PC.IsValid())
	{
		return;
	}
	
	int ScreenX, ScreenY;
	PC->GetViewportSize(ScreenX, ScreenY);
	const float HalfHorizontalFOV = CameraOwner->FieldOfView / 2.0f;
	PivotOffsetForScreenCoOff.X = 0;
	float Ratio = FMath::Tan(HalfHorizontalFOV * PI / 180.f) * ArmLen * 9.f / 16.f;
	if(ScreenY == 0)
	{
		PivotOffsetForScreenCoOff.Y = 0;
	}
	else
	{
		PivotOffsetForScreenCoOff.Y = -(ScreenViewOffset.X * ScreenY) * 2 * Ratio / static_cast<float>(ScreenY) /* / static_cast<float>(ScreenX) * static_cast<float>(ScreenX) */;
	}
	PivotOffsetForScreenCoOff.Z = ScreenViewOffset.Y * 2 * Ratio;
	RelativeCachedPivotOffset = PivotOffsetForScreenCoOff;
	PivotOffsetForScreenCoOff = FRotationMatrix(CamRot).TransformVector(PivotOffsetForScreenCoOff);
	// 不修改轴点位置 用斜线检测碰撞
	DesiredLoc += PivotOffsetForScreenCoOff;
}

#pragma endregion ScreenViewOffset

void UCameraArmComponent::EnableDitherFade(bool bEnable, const TArray<int>& NewDitherFadeObjectTypesForStatic,
                                           const TArray<int>& NewDitherFadeObjectTypesForDynamic, int DetectType,
                                           float Radius, float InDetectPitch, float InStaticDetectInterval,
                                           float InDynamicDetectInterval, float InCameraDiffThreshold)
{
	if(bEnableDitherFade != bEnable)
	{
		bEnableDitherFade = bEnable;
		if(bEnable)
		{
			DitherFadeObjectTypes.Reset();
			DitherFadeObjectTypesForDynamic.Reset();
			DitherFadeObjectTypesForStatic.Reset();

			DetectDitherComponentsForStatic.Reset();
			DetectDitherComponentsForDynamic.Reset();

			for(auto& Type : NewDitherFadeObjectTypesForStatic)
			{
				DitherFadeObjectTypes.Emplace(static_cast<EObjectTypeQuery>(Type));
				DitherFadeObjectTypesForStatic.Emplace(static_cast<EObjectTypeQuery>(Type));
			}

			for(auto& Type : NewDitherFadeObjectTypesForDynamic)
			{
				DitherFadeObjectTypes.Emplace(static_cast<EObjectTypeQuery>(Type));
				DitherFadeObjectTypesForDynamic.Emplace(static_cast<EObjectTypeQuery>(Type));
			}

			DitherStaticDetectInterval = InStaticDetectInterval;
			TimeSinceLastStaticDitherDetect = InStaticDetectInterval + 0.01f; // 设置完后第一下是期望能进行虚化的

			DitherDynamicDetectInterval = InDynamicDetectInterval;
			TimeSinceLastDynamicDitherDetect = InDynamicDetectInterval + 0.01f; // 设置完后第一下是期望能进行虚化的

			CameraPosDiffThreshold = InCameraDiffThreshold;

			DitherFadeDetectType = DetectType;
			DitherFadeDetectRadius = Radius;
			DitherFadeDetectPitch = InDetectPitch;
			// QueryHandle.Invalidate();
			// DitherFadeQueryDelegate = FOverlapDelegate::CreateUObject(this, &UCameraArmComponent::OnDitherFadeQueryFinished);
		}
		else
		{
			DitherFadeObjectTypes.Reset();
			DitherFadeObjectTypesForDynamic.Reset();
			DitherFadeObjectTypesForStatic.Reset();
			if(UKGMaterialManager* MaterialMgr = Cast<UKGMaterialManager>(UKGBasicManager::GetManagerByType(GetWorld(), EManagerType::EMT_MaterialManager)))
			{
				if(bMainPlayerPitchDitherFade && LookAtTarget.IsValid())
				{
					MaterialMgr->DisableCameraDither(LookAtTarget.Get(), nullptr);
				}
				for(auto MeshComponentObjectID: DetectDitherComponentsForStatic)
				{
					if(DitherComponentToActorForStatic.Contains(MeshComponentObjectID))
					{
						if(AActor* DitherActor = DitherComponentToActorForStatic[MeshComponentObjectID].Get())
						{
							MaterialMgr->DisableCameraDither(DitherActor, KGUtils::GetObjectByID<UMeshComponent>(MeshComponentObjectID));
						}
						DitherComponentToActorForStatic.Remove(MeshComponentObjectID);
					}
				}
				for(auto MeshComponentObjectID: DetectDitherComponentsForDynamic)
				{
					if(DitherComponentToActorForDynamic.Contains(MeshComponentObjectID))
					{
						if(AActor* DitherActor = DitherComponentToActorForDynamic[MeshComponentObjectID].Get())
						{
							MaterialMgr->DisableCameraDither(DitherActor, KGUtils::GetObjectByID<UMeshComponent>(MeshComponentObjectID));
						}
						DitherComponentToActorForDynamic.Remove(MeshComponentObjectID);
					}
				}
			}
			DetectDitherComponentsForStatic.Reset();
			DetectDitherComponentsForDynamic.Reset();
			DitherComponentToActorForStatic.Reset();
			DitherComponentToActorForDynamic.Reset();
			bMainPlayerPitchDitherFade = false;
			bMainPlayerDistanceDitherFade = 0;
		}
	}
}

void UCameraArmComponent::EnableGlobalDitherFade(bool bEnable)
{
	if(bEnable != bEnableGlobalDitherFade)
	{
		bEnableGlobalDitherFade = bEnable;
		if(!bEnable)
		{
			if(UKGMaterialManager* MaterialMgr = Cast<UKGMaterialManager>(UKGBasicManager::GetManagerByType(GetWorld(), EManagerType::EMT_MaterialManager)))
			{
				if(bMainPlayerPitchDitherFade && LookAtTarget.IsValid())
				{
					MaterialMgr->DisableCameraDither(LookAtTarget.Get(), nullptr);
				}
				for(auto MeshComponentObjectID: DetectDitherComponentsForStatic)
				{
					if(DitherComponentToActorForStatic.Contains(MeshComponentObjectID))
					{
						if(AActor* DitherActor = DitherComponentToActorForStatic[MeshComponentObjectID].Get())
						{
							MaterialMgr->DisableCameraDither(DitherActor, KGUtils::GetObjectByID<UMeshComponent>(MeshComponentObjectID));
						}
						DitherComponentToActorForStatic.Remove(MeshComponentObjectID);
					}
				}
				for(auto MeshComponentObjectID: DetectDitherComponentsForDynamic)
				{
					if(DitherComponentToActorForDynamic.Contains(MeshComponentObjectID))
					{
						if(AActor* DitherActor = DitherComponentToActorForDynamic[MeshComponentObjectID].Get())
						{
							MaterialMgr->DisableCameraDither(DitherActor, KGUtils::GetObjectByID<UMeshComponent>(MeshComponentObjectID));
						}
						DitherComponentToActorForDynamic.Remove(MeshComponentObjectID);
					}
				}
			}
			DetectDitherComponentsForStatic.Reset();
			DetectDitherComponentsForDynamic.Reset();
			DitherComponentToActorForStatic.Reset();
			DitherComponentToActorForDynamic.Reset();
			bMainPlayerPitchDitherFade = false;
			bMainPlayerDistanceDitherFade = 0;
		}
		else
		{
			TimeSinceLastStaticDitherDetect = DitherStaticDetectInterval + 0.01f; // 设置完后第一下是期望能进行虚化的
			TimeSinceLastDynamicDitherDetect = DitherDynamicDetectInterval + 0.01f; // 设置完后第一下是期望能进行虚化的
		}
	}
}

void UCameraArmComponent::PostProcess(float DeltaTime, const FVector& CameraStartPos, const FVector& CameraEndPos, float CamPitch)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("Camera PostProcess");

	// 每间隔一段时间进行虚化检测
	// For Static 针对静态对象 有移动输入或相机位置差异大于阈值 允许检测 且间隔TimeSinceLastStaticStaticDetect
	// For Dynamic 针对移动对象 间隔TimeSinceLastStaticStaticDetect 与Static不会在一帧进行
	if(bEnableGlobalDitherFade && bEnableDitherFade && !DitherFadeObjectTypes.IsEmpty())
	{
		if(bLookAtMainPlayer && LookAtTarget.IsValid())
		{
			CamPitch = FRotator::NormalizeAxis(CamPitch);
			if(bMainPlayerPitchDitherFade && CamPitch < DitherFadeDetectPitch)
			{
				if(bMainPlayerDistanceDitherFade <= 0)
				{
					if(UKGMaterialManager* MaterialMgr = Cast<UKGMaterialManager>(UKGBasicManager::GetManagerByType(GetWorld(), EManagerType::EMT_MaterialManager)))
					{
						MaterialMgr->DisableCameraDither(LookAtTarget.Get(), nullptr);
					}
				}
				bMainPlayerPitchDitherFade = false;
			}
			else if(CamPitch >= DitherFadeDetectPitch && !bMainPlayerPitchDitherFade)
			{
				if(bMainPlayerDistanceDitherFade <= 0)
				{
					if(UKGMaterialManager* MaterialMgr = Cast<UKGMaterialManager>(UKGBasicManager::GetManagerByType(GetWorld(), EManagerType::EMT_MaterialManager)))
					{
						MaterialMgr->EnableCameraDither(LookAtTarget.Get(), nullptr);
					}
				}
				bMainPlayerPitchDitherFade = true;
			}
		}

		if (DitherFadeDetectRadius > 0)
		{
			TimeSinceLastDynamicDitherDetect = FMath::Min(TimeSinceLastDynamicDitherDetect + DeltaTime, DitherDynamicDetectInterval + 1.f); // 防止溢出
			TimeSinceLastStaticDitherDetect = FMath::Min(TimeSinceLastStaticDitherDetect + DeltaTime, DitherStaticDetectInterval + 1.f); // 防止溢出
			bool bCanStaticDetect = false;
			bool bCanDynamicDetect = false;

			if (CameraActorOwner.IsValid() && CameraMgr->PendingViewTarget.Target == CameraActorOwner.Get())
			{
				return;
			}

			if(PC.IsValid())
			{
				bHasPlayerInput = bHasPlayerInput | (PC->GetLocoInputDirectionAsVec().SizeSquared() > 0.f);
			}

			if((bHasPlayerInput || bNeedDitherStatic) && TimeSinceLastStaticDitherDetect > DitherStaticDetectInterval)
			{
				bCanStaticDetect = true;
			}
			else if(TimeSinceLastDynamicDitherDetect > DitherDynamicDetectInterval)
			{
				bCanDynamicDetect = true;
			}

			if(!bCanStaticDetect && !bCanDynamicDetect)
			{
				return;
			}
			
			TArray<FOverlapResult> OverlapResults;

			UWorld* World = GetWorld();
			if(World == nullptr)
			{
				return;
			}
			
			TRACE_CPUPROFILER_EVENT_SCOPE_STR("Camera PostProcess Query");
			FVector ShapeLocation = CameraEndPos;
			if(DitherFadeDetectType == EDitherFadeDetectType::SphereRayCastDetect)
			{
				CollisionShape.SetCapsule(DitherFadeDetectRadius, (CameraEndPos - CameraStartPos).Length() / 2.f);
				ShapeLocation = (CameraEndPos - CameraStartPos) / 2.f;
			}
			else if(DitherFadeDetectType == EDitherFadeDetectType::SphereDetect)
			{
				CollisionShape.SetSphere(DitherFadeDetectRadius);
			}

			if(bCanStaticDetect)
			{
				TRACE_CPUPROFILER_EVENT_SCOPE_STR("Camera PostProcess Query Static");
				World->OverlapMultiByObjectType(OverlapResults, ShapeLocation, FQuat::Identity, DitherFadeObjectTypesForStatic, CollisionShape, CollisionQueryParams);
				TimeSinceLastStaticDitherDetect = 0.f;
				bHasPlayerInput = false;
				bNeedDitherStatic = false;
			}
			else if(bCanDynamicDetect)
			{
				TRACE_CPUPROFILER_EVENT_SCOPE_STR("Camera PostProcess Query Dynamic");
				World->OverlapMultiByObjectType(OverlapResults, ShapeLocation, FQuat::Identity, DitherFadeObjectTypesForDynamic, CollisionShape, CollisionQueryParams);
				TimeSinceLastDynamicDitherDetect = 0.f;
			}

			// QueryHandle = World->AsyncOverlapByObjectType(CameraEndPos, FQuat::Identity, DitherFadeObjectTypes, CollisionShape, CollisionQueryParams, &DitherFadeQueryDelegate);

			TRACE_CPUPROFILER_EVENT_SCOPE_STR("Camera PostProcess Do Dither");

			UKGMaterialManager* MaterialMgr = Cast<UKGMaterialManager>(UKGBasicManager::GetManagerByType(GetWorld(), EManagerType::EMT_MaterialManager));
			if(MaterialMgr == nullptr)
			{
				return;
			}
			UKGUEActorManager* UEActorManager = UKGUEActorManager::GetInstance(GetWorld());
			if(UEActorManager == nullptr)
			{
				return;
			}

			TSet<int64> OutComponents;
			TArray<UPrimitiveComponent*> ComponentsNeedToEnableCameraDither;

			auto& DetectDitherComponents = bCanStaticDetect ? DetectDitherComponentsForStatic : DetectDitherComponentsForDynamic;
			auto& DitherComponentToActor = bCanStaticDetect ? DitherComponentToActorForStatic : DitherComponentToActorForDynamic;
			
			for (auto& HitResult : OverlapResults)
			{
				auto* HitActor = HitResult.GetActor();
				if (UEActorManager)
				{
					if (IC7ActorInterface* C7Actor = Cast<IC7ActorInterface>(HitActor))
					{
						if (auto* Entity = UEActorManager->GetLuaEntity(C7Actor->GetEntityUID()))
						{
							ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(HitActor);
							URoleMovementComponent* RoleMovement = BaseCharacter ? Cast<URoleMovementComponent>(BaseCharacter->GetMovementComponent()) : nullptr;
							const bool bIsMount = RoleMovement && RoleMovement->IsMount();
							const bool bIsRider = RoleMovement && RoleMovement->IsMountRider();
							// 对于处于挂接状态的物体, 目前跟随其attach parent一起进行虚化表现
							if (bIsMount || (Entity->IsAttached() && !bIsRider))
							{
								continue;
							}
						}
					}
				}
				
				if (HitResult.Component.IsValid())
				{
					KGObjectID ComponentID = KGUtils::GetIDByObject(HitResult.Component.Get());
					OutComponents.Add(ComponentID);
					if (!DetectDitherComponents.Contains(ComponentID) && HitResult.Component->GetCollisionResponseToChannels().GetResponse(ECC_Camera) == ECR_Ignore)
					{
						DetectDitherComponents.Emplace(ComponentID);
						DitherComponentToActor.Add(ComponentID, HitResult.GetActor());
						ComponentsNeedToEnableCameraDither.Add(HitResult.Component.Get());
					}
				}
			}
			
			for(KGObjectID MeshComponentObjectID: DetectDitherComponents.Difference(OutComponents))
			{
				DetectDitherComponents.Remove(MeshComponentObjectID);
				if(MaterialMgr)
				{
					if(DitherComponentToActor.Contains(MeshComponentObjectID))
					{
						if(AActor* DitherActor = DitherComponentToActor[MeshComponentObjectID].Get())
						{
							if(bMainPlayerPitchDitherFade == false || DitherActor != LookAtTarget)
							{
								MaterialMgr->DisableCameraDither(DitherActor, KGUtils::GetObjectByID<UMeshComponent>(MeshComponentObjectID));
							}
							if(DitherActor == LookAtTarget) bMainPlayerDistanceDitherFade = FMath::Max(0, bMainPlayerDistanceDitherFade - 1);
						}
						DitherComponentToActor.Remove(MeshComponentObjectID);
					}
				}
			}
			
			if (MaterialMgr)
			{
				for (auto* Component : ComponentsNeedToEnableCameraDither)
				{
					AActor* MeshOwner = Component->GetOwner();
					MaterialMgr->EnableCameraDither(MeshOwner, Cast<UMeshComponent>(Component));
					if(MeshOwner == LookAtTarget) ++bMainPlayerDistanceDitherFade;
				}
			}
		}
	}
}

// void UCameraArmComponent::OnDitherFadeQueryFinished(const FTraceHandle& Handle, FOverlapDatum& OverlapDatum)
// {
// }

#pragma region RotationLag

void UCameraArmComponent::InitRotationLagParam(bool bNewEnableCameraRotationLag, ECameraEaseFunction::Type EaseType,
                                               float Param, int64 CurveID)
{
	bEnableCameraRotationLag = bNewEnableCameraRotationLag;

	switch(EaseType)
	{
	case ECameraEaseFunction::Spring:
		CameraRotationEaseParam.SetSpring(FQuat::Identity, FQuat::Identity, Param, FQuat::Identity, FQuat::Identity);
		break;
	case ECameraEaseFunction::Decay:
		CameraRotationEaseParam.SetDecay(FQuat::Identity, FQuat::Identity, Param);
		break;
	case ECameraEaseFunction::Curve:
		{
			UCurveFloat* NewCurve = Cast<UCurveFloat>(KGUtils::GetObjectByID(CurveID));
			CameraRotationEaseParam.SetCurve(FQuat::Identity, FQuat::Identity, Param, NewCurve);
		}
		break;
	default:
		CameraRotationEaseParam.SetEase(FQuat::Identity, FQuat::Identity, Param, EaseType);
		break;
	}
}

#pragma endregion RotationLag 


#pragma region LocationLag

void UCameraArmComponent::InitLocationLagParamForXOY(ECameraEaseFunction::Type EaseType, float Param, int64 CurveID,
                                                     float NewSoftZoneRadiusXOY)
{
	switch (EaseType)
	{
	case ECameraEaseFunction::Spring:
		CameraLocationEaseParam.SetSpring(FVector::ZeroVector, FVector::ZeroVector, Param, FVector::ZeroVector,
		                                     FVector::ZeroVector);
		break;
	case ECameraEaseFunction::Decay:
		CameraLocationEaseParam.SetDecay(FVector::ZeroVector, FVector::ZeroVector, Param);
		break;
	case ECameraEaseFunction::Curve:
		{
			UCurveFloat* NewCurve = Cast<UCurveFloat>(KGUtils::GetObjectByID(CurveID));
			CameraLocationEaseParam.SetCurve(FVector::ZeroVector, FVector::ZeroVector, Param, NewCurve);
		}
		break;
	default:
		CameraLocationEaseParam.SetEase(FVector::ZeroVector, FVector::ZeroVector, Param, EaseType);
		break;
	}

	SoftZoneRadiusXOY = NewSoftZoneRadiusXOY;
}

void UCameraArmComponent::SetLocationLagParamForXOY(float Param)
{
	CameraLocationEaseParam.SetParam(Param);
}

void UCameraArmComponent::InitLocationLagParamForZ(ECameraEaseFunction::Type EaseType,
                                                   float Param, int64 CurveID, float NewSoftZoneRadiusZ)
{
	switch (EaseType)
	{
	case ECameraEaseFunction::Spring:
		CameraLocationEaseParamZ.SetSpring(0, 0, Param, 0, 0);
		break;
	case ECameraEaseFunction::Decay:
		CameraLocationEaseParamZ.SetDecay(0, 0, Param);
		break;
	case ECameraEaseFunction::Curve:
		{
			UCurveFloat* NewCurve = Cast<UCurveFloat>(KGUtils::GetObjectByID(CurveID));
			CameraLocationEaseParamZ.SetCurve(0, 0, Param, NewCurve);
		}
		break;
	default:
		CameraLocationEaseParamZ.SetEase(0, 0, Param, EaseType);
		break;
	}

	SoftZoneRadiusZ = NewSoftZoneRadiusZ;
}

void UCameraArmComponent::SetLocationLagParamForZ(float Param)
{
	CameraLocationEaseParamZ.SetParam(Param);
}

void UCameraArmComponent::SetLocationSoftRadiusParamForXOY(float Param)
{
	SoftZoneRadiusXOY = Param;
}

void UCameraArmComponent::SetLocationSoftRadiusParamForZ(float Param)
{
	SoftZoneRadiusZ = Param;
}

void UCameraArmComponent::SetRotationLagParam(float Param)
{
	CameraRotationEaseParam.SetParam(Param);
}

#pragma endregion LocationLag 
