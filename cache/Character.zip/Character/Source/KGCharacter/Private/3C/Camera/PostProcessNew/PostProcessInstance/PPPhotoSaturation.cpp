﻿#include "3C/Camera/PostProcessNew/PostProcessInstance/PPPhotoSaturation.h"

#include "Util/ColorConstants.h"

void KGPPPhotoSaturation::InitParams(
	const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType, const FString& InSaturationCurvePath)
{
	KGPPNonMaterialBase::InitParams(CommonParams, InPPManager, InPPType);
	ColorSaturationID = RegisterManualWeightCurve(InSaturationCurvePath, EKGManualWeightCurveType::ColorCurve);
}

void KGPPPhotoSaturation::SetManualWeightCurveValue(float Weight)
{
	KGPPNonMaterialBase::SetManualWeightCurveValue(Weight);
	KG_PP_SET_LINEAR_COLOR_CURVE_PARAM(ColorSaturation);
}
