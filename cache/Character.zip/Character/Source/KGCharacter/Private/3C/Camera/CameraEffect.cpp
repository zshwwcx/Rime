#include "3C/Camera/CameraEffect.h"

#include "3C/Camera/CameraManager.h"
#include "Camera/PlayerCameraManager.h"



#pragma region Override
void UCameraEffect::UpdateAlpha(float DeltaTime)
{
	float const TargetAlpha = GetTargetAlpha();
	float const BlendTime = FMath::IsNearlyEqual(TargetAlpha,LinerAlpha) ? 0 : ((TargetAlpha == 0.f) ? AlphaOutTime : AlphaInTime);

	// interpolate!
	if (BlendTime <= 0.f)
	{
		// no blendtime means no blending, just go directly to target alpha
		LinerAlpha = TargetAlpha;
		Alpha = LinerAlpha;
	}
	else if (LinerAlpha > TargetAlpha)
	{
		// interpolate downward to target, while protecting against overshooting
		LinerAlpha = FMath::Max<float>(LinerAlpha - DeltaTime / BlendTime, TargetAlpha);
		if (BlendOutCurve)
		{
			Alpha = BlendInCurve->GetFloatValue(LinerAlpha);
		}
		else
		{
			Alpha = LinerAlpha;
		}
	}
	else
	{
		// interpolate upward to target, while protecting against overshooting
		LinerAlpha = FMath::Min<float>(LinerAlpha + DeltaTime / BlendTime, TargetAlpha);
		if (BlendInCurve)
		{
			Alpha = BlendOutCurve->GetFloatValue(LinerAlpha);
		}
		else
		{
			Alpha = LinerAlpha;
		}
	}
	// Super::UpdateAlpha(DeltaTime);
}

void UCameraEffect::ToggleModifier()
{
	Super::ToggleModifier();
}

void UCameraEffect::DisableModifier(bool bImmediate)
{
	if (bImmediate)
	{
		bDisabled = true;
		bPendingDisable = false;

		// 如果需要自动从列表中移除
		if (bAutoRemoveFromList && CameraOwner)
		{
			//不能在这里直接Delete,这里可能CameraManager正在遍历ModiferList,这时直接删除List中元素存在风险，这边MarkDelete,再CameraManagerTick时删除。
			bMarkDelete = true;
			// CameraOwner->RemoveCameraModifier(this);
		}
	}
	else if (!bDisabled)
	{
		bPendingDisable = true;
	}
}

#pragma endregion Override



#pragma region Common

#pragma endregion Common



#pragma region Property
void UCameraEffect::SetAutoRemoveFromList(bool bNeedRemove)
{
	bAutoRemoveFromList = bNeedRemove;
}

void UCameraEffect::OnInterrupt()
{
	if(!(bDisabled ||bPendingDisable))
	{
		DisableModifier(true);
	}
}

#pragma endregion Property






#pragma region PostProcess
void UCEPPMaterial::ModifyPostProcess(float DeltaTime, float& PostProcessBlendWeight, FPostProcessSettings& PostProcessSettings)
{
	PostProcessBlendWeight = 1.f;
	PostProcessSettings.WeightedBlendables.Array.Add(Blendable);
}

void UCEPPDepthOfField_PC::ModifyPostProcess(float DeltaTime, float& PostProcessBlendWeight, FPostProcessSettings& PostProcessSettings)
{
	PostProcessBlendWeight = 1.f * Alpha;

	PostProcessSettings.bOverride_DepthOfFieldSensorWidth = true;
	PostProcessSettings.DepthOfFieldSensorWidth = SensorWidth;

	PostProcessSettings.bOverride_DepthOfFieldSqueezeFactor = true;
	PostProcessSettings.DepthOfFieldSqueezeFactor = SqueezeFactor;

	PostProcessSettings.bOverride_DepthOfFieldFocalDistance = true;
	PostProcessSettings.DepthOfFieldFocalDistance = FocalDistance;

	PostProcessSettings.bOverride_DepthOfFieldDepthBlurAmount = true;
	PostProcessSettings.DepthOfFieldDepthBlurAmount = DepthBlurAmount;

	PostProcessSettings.bOverride_DepthOfFieldDepthBlurRadius = true;
	PostProcessSettings.DepthOfFieldDepthBlurRadius = BlurRadius;
}


void UCEPPDepthOfField::ModifyPostProcess(float DeltaTime, float& PostProcessBlendWeight, FPostProcessSettings& PostProcessSettings)
{
	PostProcessBlendWeight = 1.f * Alpha;

	PostProcessSettings.bOverride_MobileHQGaussian = true;
	PostProcessSettings.bMobileHQGaussian = bMobileHQGaussian;

	PostProcessSettings.bOverride_DepthOfFieldFocalRegion = true;
	PostProcessSettings.DepthOfFieldFocalRegion = FocalRegion;

	PostProcessSettings.bOverride_DepthOfFieldNearTransitionRegion = true;
	PostProcessSettings.DepthOfFieldNearTransitionRegion = NearTransitionRegion;

	PostProcessSettings.bOverride_DepthOfFieldFarTransitionRegion = true;
	PostProcessSettings.DepthOfFieldFarTransitionRegion = FarTransitionRegion;

	PostProcessSettings.bOverride_DepthOfFieldScale = true;
	PostProcessSettings.DepthOfFieldScale = Scale;

	PostProcessSettings.bOverride_DepthOfFieldNearBlurSize = true;
	PostProcessSettings.DepthOfFieldNearBlurSize = NearBlurSize;

	PostProcessSettings.bOverride_DepthOfFieldFarBlurSize = true;
	PostProcessSettings.DepthOfFieldFarBlurSize = FarBlurSize;
}



void UCEPPBloom::ModifyPostProcess(float DeltaTime, float& PostProcessBlendWeight, FPostProcessSettings& PostProcessSettings)
{
	PostProcessBlendWeight = 1.f * Alpha;

	PostProcessSettings.bOverride_BloomMethod = bOverride_BloomMethod;
	PostProcessSettings.BloomMethod = BloomMethod;

	PostProcessSettings.bOverride_BloomIntensity = bOverride_BloomIntensity;
	PostProcessSettings.BloomIntensity = BloomIntensity;

	PostProcessSettings.bOverride_BloomThreshold = bOverride_BloomThreshold;
	PostProcessSettings.BloomThreshold = BloomThreshold;

	PostProcessSettings.bOverride_BloomSizeScale = bOverride_BloomSizeScale;
	PostProcessSettings.BloomSizeScale = BloomSizeScale;

	PostProcessSettings.bOverride_Bloom1Size = bOverride_Bloom1Size;
	PostProcessSettings.Bloom1Size = Bloom1Size;

	PostProcessSettings.bOverride_Bloom2Size = bOverride_Bloom2Size;
	PostProcessSettings.Bloom2Size = Bloom2Size;

	PostProcessSettings.bOverride_Bloom3Size = bOverride_Bloom3Size;
	PostProcessSettings.Bloom3Size = Bloom3Size;

	PostProcessSettings.bOverride_Bloom4Size = bOverride_Bloom4Size;
	PostProcessSettings.Bloom4Size = Bloom4Size;

	PostProcessSettings.bOverride_Bloom5Size = bOverride_Bloom5Size;
	PostProcessSettings.Bloom5Size = Bloom5Size;

	PostProcessSettings.bOverride_Bloom6Size = bOverride_Bloom6Size;
	PostProcessSettings.Bloom6Size = Bloom6Size;

	PostProcessSettings.bOverride_Bloom1Tint = bOverride_Bloom1Tint;
	PostProcessSettings.Bloom1Tint = Bloom1Tint;

	PostProcessSettings.bOverride_Bloom2Tint = bOverride_Bloom2Tint;
	PostProcessSettings.Bloom2Tint = Bloom2Tint;

	PostProcessSettings.bOverride_Bloom3Tint = bOverride_Bloom3Tint;
	PostProcessSettings.Bloom3Tint = Bloom3Tint;

	PostProcessSettings.bOverride_Bloom4Tint = bOverride_Bloom4Tint;
	PostProcessSettings.Bloom4Tint = Bloom4Tint;

	PostProcessSettings.bOverride_Bloom5Tint = bOverride_Bloom5Tint;
	PostProcessSettings.Bloom5Tint = Bloom5Tint;

	PostProcessSettings.bOverride_Bloom6Tint = bOverride_Bloom6Tint;
	PostProcessSettings.Bloom6Tint = Bloom6Tint;

	PostProcessSettings.bOverride_BloomConvolutionSize = bOverride_BloomConvolutionSize;
	PostProcessSettings.BloomConvolutionSize = BloomConvolutionSize;

	PostProcessSettings.bOverride_BloomConvolutionTexture = bOverride_BloomConvolutionTexture;
	PostProcessSettings.BloomConvolutionTexture = BloomConvolutionTexture;

	PostProcessSettings.bOverride_BloomConvolutionCenterUV = bOverride_BloomConvolutionCenterUV;
	PostProcessSettings.BloomConvolutionCenterUV = BloomConvolutionCenterUV;

	PostProcessSettings.bOverride_BloomConvolutionPreFilterMin = bOverride_BloomConvolutionPreFilterMin;
	PostProcessSettings.BloomConvolutionPreFilterMin = BloomConvolutionPreFilterMin;

	PostProcessSettings.bOverride_BloomConvolutionPreFilterMax = bOverride_BloomConvolutionPreFilterMax;
	PostProcessSettings.BloomConvolutionPreFilterMax = BloomConvolutionPreFilterMax;

	PostProcessSettings.bOverride_BloomConvolutionPreFilterMult = bOverride_BloomConvolutionPreFilterMult;
	PostProcessSettings.BloomConvolutionPreFilterMult = BloomConvolutionPreFilterMult;

	PostProcessSettings.bOverride_BloomConvolutionBufferScale = bOverride_BloomConvolutionBufferScale;
	PostProcessSettings.BloomConvolutionBufferScale = BloomConvolutionBufferScale;
}

#pragma endregion PostProcess

