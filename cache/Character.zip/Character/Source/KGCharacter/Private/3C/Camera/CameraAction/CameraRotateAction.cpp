// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Camera/CameraAction/CameraRotateAction.h"

#include "3C/Camera/CameraAction/CameraActionHandler.h"

void UCameraRotateAction::Init(float Pitch, float Yaw, float Roll, float PitchOffset, float YawOffset, float RollOffset,
                               bool bInRecover, bool bInCanInterrupt, float InBlendInTime, float InBlendOutTime, float InDuration,
                               ECameraEaseFunction::Type InBlendInType, ECameraEaseFunction::Type InBlendOutType, int64 InBlendInCurve,
                               int64 InBlendOutCurve)
{
	TargetRotate.Pitch = Pitch;
	TargetRotate.Yaw = Yaw;
	TargetRotate.Roll = Roll;

	TargetRotateOffset.Pitch = PitchOffset;
	TargetRotateOffset.Yaw = YawOffset;
	TargetRotateOffset.Roll = RollOffset;

	bRecover = bInRecover;
	bCanInterrupt = bInCanInterrupt;
	SetEaseInType(InBlendInType, InBlendInTime, InBlendInCurve);
	SetEaseOutType(InBlendOutType, InBlendOutTime, InBlendOutCurve);
	Duration = InDuration;
}

bool UCameraRotateAction::ProcessViewRotation(AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch,
	double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot)
{
	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return false;
	}

	bOutChangeYaw = true;
	bOutChangeRoll = true;
	bOutChangePitch = true;

	FRotator OutViewRotation = FRotator::ZeroRotator;
	if(bStartBlendOut and bRecover)
	{
		if(ActionHandlerOwner.IsValid())
		{
			ActionHandlerOwner->GetRotationRecoverTo(Priority, RotateBase);
		}
	}

	const FRotator DeltaAng = (TargetRotate - RotateBase).GetNormalized();
	OutViewRotation = RotateBase + FMath::Clamp(Alpha, 0.f, 1.f) * DeltaAng;

	OutPitch = OutViewRotation.Pitch;
	OutYaw = OutViewRotation.Yaw;
	OutRoll = OutViewRotation.Roll;
	OutDeltaRot = FRotator::ZeroRotator;
	return true;
}

void UCameraRotateAction::ModifyCamera(float DeltaTime)
{
	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return;
	}

	if(!TargetRotateOffset.IsZero())
	{
		const FRotator DeltaAng = (TargetRotateOffset - RotateOffsetBase).GetNormalized();
		FRotator Result = RotateOffsetBase + FMath::Clamp(Alpha, 0.f, 1.f) * DeltaAng;
		CameraMode->AddRotDelta(Result);
	}
}

void UCameraRotateAction::Play()
{
	Super::Play();
	InitParams();
}

bool UCameraRotateAction::IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType)
{
	if(ControlType == ECameraManualControlType::ManualRot)
	{
		return bCanInterrupt;
	}

	return false;
}

void UCameraRotateAction::DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode)
{
	Super::DoWhenEffectModeActivate(ActivateCameraMode);

	InitParams();
}

void UCameraRotateAction::InitParams()
{
	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return;
	}

	RotateBase = CameraMode->GetCameraRotation();
}
