// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Camera/CameraAction/CameraLagAction.h"

void UCameraLagAction::Init(float XYLag, float ZLag, float XYSoftRadius, float ZSoftRadius, float InBlendInTime,
	float InBlendOutTime, float InDuration, ECameraEaseFunction::Type InBlendInType,
	ECameraEaseFunction::Type InBlendOutType, int64 InBlendInCurve, int64 InBlendOutCurve)
{
	TargetXYLag = XYLag;
	TargetZLag = ZLag;
	TargetXYSoftRadius = XYSoftRadius;
	TargetZSoftRadius = ZSoftRadius;

	SetEaseInType(InBlendInType, InBlendInTime, InBlendInCurve);
	SetEaseOutType(InBlendOutType, InBlendOutTime, InBlendOutCurve);
	Duration = InDuration;
}

void UCameraLagAction::Play()
{
	Super::Play();
	InitParams();
}

void UCameraLagAction::ModifyCamera(float DeltaTime)
{
	Super::ModifyCamera(DeltaTime);
	
	if(CameraMode.IsValid())
	{
		if(TargetXYLag >= 0.f)
		{
			CameraMode->SetCameraXOYLagSetting(FMath::Lerp(bStartBlendOut ? CameraMode->GetXOYLagBelowPriority(Priority, XYLagBase) : XYLagBase, TargetXYLag, Alpha), Priority);
		}

		if(TargetZLag >= 0.f)
		{
			CameraMode->SetCameraZLagSetting(FMath::Lerp(bStartBlendOut ? CameraMode->GetZLagBelowPriority(Priority, ZLagBase) : ZLagBase, TargetZLag, Alpha), Priority);
		}

		if(TargetXYSoftRadius >= 0.f)
		{
			CameraMode->SetCameraXOYSoftRadiusSetting(FMath::Lerp(bStartBlendOut ? CameraMode->GetXOYSoftRadiusBelowPriority(Priority, XYSoftRadiusBase) : XYSoftRadiusBase, TargetXYSoftRadius, Alpha), Priority);
		}

		if(TargetZSoftRadius >= 0.f)
		{
			CameraMode->SetCameraZSoftRadiusSetting(FMath::Lerp(bStartBlendOut ? CameraMode->GetZSoftRadiusBelowPriority(Priority, ZSoftRadiusBase) : ZSoftRadiusBase, TargetZSoftRadius, Alpha), Priority);
		}
	}
}

void UCameraLagAction::Abort()
{
	Super::Abort();
	
	if(CameraMode.IsValid())
	{
		if(TargetXYLag >= 0.f)
		{
			CameraMode->RemoveCameraXOYLagSetting(Priority);
		}

		if(TargetZLag >= 0.f)
		{
			CameraMode->RemoveCameraZLagSetting(Priority);
		}

		if(TargetXYSoftRadius >= 0)
		{
			CameraMode->RemoveCameraXOYSoftRadiusSetting(Priority);
		}

		if(TargetZSoftRadius >= 0)
		{
			CameraMode->RemoveCameraZSoftRadiusSetting(Priority);
		}
	}
}

void UCameraLagAction::DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode)
{
	Super::DoWhenEffectModeActivate(ActivateCameraMode);
	InitParams();
}

void UCameraLagAction::InitParams()
{
	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return;
	}

	XYLagBase = CameraMode->GetDesiredCameraXOYLag();
	ZLagBase = CameraMode->GetDesiredCameraZLag();
	XYSoftRadiusBase = CameraMode->GetDesiredCameraXOYSoftRadius();
	ZSoftRadiusBase = CameraMode->GetDesiredCameraZSoftRadius();
}
