#include "3C/Camera/CameraAction/CameraSplineMoveModifier.h"


void UCameraSplineMoveModifier::ModifyViewPOV(float DeltaTime, struct FMinimalViewInfo& InOutPOV)
{
	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return;
	}
}

