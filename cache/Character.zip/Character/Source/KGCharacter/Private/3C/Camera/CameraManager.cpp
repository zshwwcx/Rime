#include "3C/Camera/CameraManager.h"
#include "GameFramework/PlayerController.h"
#include "3C/Camera/CameraAction/CameraActionHandler.h"
#include "Kismet/KismetSystemLibrary.h"
#include "3C/Camera/BaseCamera.h"
#include "TimerManager.h"
#include "3C/Camera/CameraShake/WaveOscillatorCameraShakePatternV2.h"
#include "3C/Camera/CameraShake/BaseCameraShake.h"
#include "3C/Camera/CameraArmComponent.h"
#include "Camera/CameraComponent.h"
#include "Curves/CurveFloat.h"
#include "Math/RotationMatrix.h"
#include "Camera/CameraModifier_CameraShake.h"
#include "Engine/World.h"
#include "Tracks/MovieScene3DTransformTrack.h"
#include "MovieScene.h"
#include "CameraAnimationSequence.h"
#include "3C/Util/KGUtils.h"

// BEGIN ADD BY liubo11@kuaishou.com: delay init phys
#include "3C/Camera/BaseCineCamera.h"
#include "3C/Controller/BasePlayerController.h"
#include "3C/Camera/CameraAction/CameraActionFocusOnTarget.h"
#include "3C/Camera/CameraEffect.h"
#include "CineCameraSettings.h"
#include "IXRTrackingSystem.h"
#include "Manager/KGAkAudioManager.h"
#include "3C/Camera/CameraAction/KGCameraAnimationModifier.h"
#include "Misc/ObjCrashCollector.h"
#include "3C/Camera/PostProcessNew/PostProcessManager.h"
#include "3C/Camera/CameraMode/ThirdCameraMode.h"
#include "Animations/CameraAnimationCameraModifier.h"
#include "Camera/CameraLensEffectInterface.h"
#include "Engine/Engine.h"
#if WITH_EDITOR
#include "Engine/GameViewportClient.h"
#include "Editor/EditorEngine.h"
#include "EditorViewportClient.h"
#endif
#include "3C/Camera/BaseCineCameraComponent.h"
#include "Manager/KGCppAssetManager.h"
#include "Components/SplineComponent.h"
#include "Engine/HitResult.h"
#include "3C/Material/KGMaterialManager.h"
// END ADD BY liubo11@kuaishou.com

DECLARE_CYCLE_STAT(TEXT("Camera ProcessViewRotation"), STAT_Camera_ProcessViewRotation, STATGROUP_Game);

int ACameraManager::CAMERA_BASE_SETTING_PRIORITY = 0;
bool ACameraManager::bEnableDebug = false;

ACameraManager::ACameraManager(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bEnableCameraModifier = true;
}
void ACameraManager::InitializeFor(APlayerController* PC)
{
	Super::InitializeFor(PC);

	CameraDitherFadeSwitcher = 0;

	if (CameraActionHandlerClass.Get()->IsValidLowLevelFast())
	{
		CameraActionHandler = NewObject<UCameraActionHandler>(this, CameraActionHandlerClass);
		UE_LOG(LogTemp, Log, TEXT("[ACameraManager]CameraActionHandler Init By CameraActionHandlerClass"));
	}
	else
	{
		CameraActionHandler = NewObject<UCameraActionHandler>(this);
		UE_LOG(LogTemp, Log, TEXT("[ACameraManager]CameraActionHandler Init By Default"));
	}

	if(CameraActionHandler != nullptr)
	{
		CameraActionHandler->Init();
	}
	
	if(OnBlendComplete().IsBound())
	{
		OnBlendComplete().Clear();
	}
	OnBlendComplete().AddUObject(this, &ACameraManager::OnBlendFinish);

	KAPI_Camera_SetViewPitchSetting(ViewPitchMin, ViewPitchMax, 0);
	KAPI_Camera_SetViewYawSetting(ViewYawMin, ViewYawMax, 0);
	KAPI_Camera_SetViewRollSetting(ViewRollMin, ViewRollMax, 0);

	OnInitializeFor(PC);
}


UKgCameraMode* ACameraManager::GetCurCameraMode()
{
	int CurModeTag = ActivateCameraModeTag;
	if(CameraModes.Contains(CurModeTag))
	{
		UKgCameraMode* CurCameraMode = Cast<UKgCameraMode>(CameraModes[CurModeTag]);
		return CurCameraMode;
	}
	return nullptr;
}

void ACameraManager::SetViewTarget(AActor* NewTarget, FViewTargetTransitionParams TransitionParams)
{
	bUseCustomBlend = false;

	if (NewTarget == nullptr)
	{
		NewTarget = PCOwner;
	}

	ViewTarget.CheckViewTarget(PCOwner);

	if (PendingViewTarget.Target != NULL)
	{
		PendingViewTarget.CheckViewTarget(PCOwner);

		if(NewTarget != PendingViewTarget.Target)
		{
			OnBlendComplete().Broadcast();
			TransitionParams.bLockOutgoing = true;
		}
	}

#if !(UE_BUILD_SHIPPING || UE_BUILD_TEST)
	UE_LOG(LogTemp, Log, TEXT("CameraManager:SetViewTarget NewTarget:%s CurTarget:%s Time:%f"), *NewTarget->GetName(), *ViewTarget.Target->GetName(), TransitionParams.BlendTime);
#endif
	
	if ((NewTarget == ViewTarget.Target) && (PendingViewTarget.Target != NULL))
	{
		TransitionParams.bLockOutgoing = true;
	}

	if (TransitionParams.BlendTime > 0)
	{
		if (PendingViewTarget.Target == NULL)
		{
			PendingViewTarget.Target = ViewTarget.Target;
		}

		ViewTarget.POV = GetCameraCacheView();
		ViewTargetSnapShot = ViewCachedSnapShot;
		BlendTimeToGo = TransitionParams.BlendTime;

		AssignViewTarget(NewTarget, PendingViewTarget, TransitionParams);
		PendingViewTarget.CheckViewTarget(PCOwner);
	}
	else
	{
		AssignViewTarget(NewTarget, ViewTarget);
		ViewTarget.CheckViewTarget(PCOwner);
		PendingViewTarget.Target = nullptr;
		BlendTimeToGo = 0.f;
		UpdateCamera(0.f);
		OnBlendComplete().Broadcast();
	}

	BlendParams = TransitionParams;
}

void ACameraManager::CustomSetViewTarget(AActor* NewViewTarget, ECameraEaseFunction::Type EaseType,
                                         ECameraViewBlendFunction::Type BlendType, float BlendTime, bool bLockOutgoing,
                                         UCurveFloat* BlendCurve, bool bDoDotBlendRot)
{
	this->bUseCustomBlend = true;
	this->bDoNotBlendRot = bDoDotBlendRot;

	BlendParams.BlendTime = BlendTime;
	BlendParams.bLockOutgoing = bLockOutgoing;

	CameraViewBlendProxy.SetViewBlendType(BlendType);

	if(BlendCurve)
	{
		CameraBlendParam.SetCurve(0.f, 1.f, BlendTime, BlendCurve);
	}
	else
	{
		CameraBlendParam.SetEase(0.f, 1.f, BlendTime, EaseType);
	}

	if (NewViewTarget == nullptr)
	{
		NewViewTarget = PCOwner;
	}

	ViewTarget.CheckViewTarget(PCOwner);

	if (PendingViewTarget.Target != NULL)
	{
		PendingViewTarget.CheckViewTarget(PCOwner);

		if(NewViewTarget != PendingViewTarget.Target)
		{
			OnBlendComplete().Broadcast();
			BlendParams.bLockOutgoing = true;
		}
	}

#if !(UE_BUILD_SHIPPING || UE_BUILD_TEST)
	UE_LOG(LogTemp, Log, TEXT("CameraManager:CustomSetViewTarget NewTarget:%s CurTarget:%s Time:%f"), *NewViewTarget->GetName(), *ViewTarget.Target->GetName(), BlendTime);
#endif
	
	if ((NewViewTarget == ViewTarget.Target) && (PendingViewTarget.Target != NULL))
	{
		BlendParams.bLockOutgoing = true;
	}

	if (BlendTime > 0)
	{
		if (PendingViewTarget.Target == NULL)
		{
			PendingViewTarget.Target = ViewTarget.Target;
		}

		ViewTarget.POV = GetCameraCacheView();
		ViewTargetSnapShot = ViewCachedSnapShot;
		BlendTimeToGo = BlendTime;

		AssignViewTarget(NewViewTarget, PendingViewTarget, BlendParams);
		PendingViewTarget.CheckViewTarget(PCOwner);
	}
	else
	{
		AssignViewTarget(NewViewTarget, ViewTarget);
		ViewTarget.CheckViewTarget(PCOwner);
		PendingViewTarget.Target = nullptr;
		BlendTimeToGo = 0.f;
		UpdateCamera(0.f);
		OnBlendComplete().Broadcast();
	}
}

void ACameraManager::ApplyCameraModifiers(float DeltaTime, FMinimalViewInfo& InOutPOV)
{
	TArray<TObjectPtr<UCameraModifier>> LocalModifierList = ModifierList;

	// Loop through each camera modifier
	for (int32 ModifierIdx = 0; ModifierIdx < LocalModifierList.Num(); ++ModifierIdx)
	{
		auto CameraModifier = LocalModifierList[ModifierIdx];
		if ((CameraModifier != NULL) && !CameraModifier->IsDisabled())
		{
			if(CameraModifier == CachedCameraShakeMod)
			{
				// 进入特定相机模式 保持更新震屏但不应用
				if(NotApplyPOVPostProcess.Num() > 0)
				{
					FMinimalViewInfo OldPOV = InOutPOV;
					bool bContinue = !CameraModifier->ModifyCamera(DeltaTime, InOutPOV);
					InOutPOV = OldPOV;
					if(bContinue)
					{
						return;
					}
				}
				else
				{
					if(CameraModifier->ModifyCamera(DeltaTime, InOutPOV))
					{
						return;
					}
				}
			}
			else
			{
				if(CameraModifier->ModifyCamera(DeltaTime, InOutPOV))
				{
					return;
				}
			}
		}
	}
}

void ACameraManager::RearrangeModifiers()
{
	ModifierList.Sort([](TObjectPtr<UCameraModifier> A, TObjectPtr<UCameraModifier> B) -> bool
	{
		return A->Priority < B->Priority;
	});
}

void ACameraManager::SetAudioCameraDistanceRtpcName(FString Name, float Tolerance)
{
	AudioCameraDistanceRtpcName = Name;
	AudioCameraDistanceTolerance = Tolerance;
}

void ACameraManager::ClearModeModifyDataAfterFrame()
{
	if(CameraModes.Contains(ActivateCameraModeTag))
	{
		auto& CameraMode = CameraModes[ActivateCameraModeTag];
		CameraMode->ClearModeModifyDataAfterFrame();
	}
}

void ACameraManager::DoUpdateCamera(float DeltaTime)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("ACameraManager:DoUpdateCamera");

	int X, Y;
	PCOwner->GetViewportSize(X, Y);
	if(Y == 0 || X == 0)
	{
		PCAspectRatio = DefaultAspectRatio;
#if WITH_EDITOR
		if(UEditorEngine* Engine = Cast<UEditorEngine>(GEngine))
		{
			for(auto& Port : Engine->GetAllViewportClients())
			{
				if(Port->Viewport && Port->IsPerspective())
				{
					auto Size = Port->Viewport->GetSizeXY();
					if(Size.X != 0 && Size.Y != 0)
					{
						PCAspectRatio = (Size.X * 1.f) / (Size.Y * 1.f);
						break;
					}
				}
			}
		}
#endif
	}
	else
	{
		PCAspectRatio = (X * 1.f) / (Y * 1.f);
	}

	FCameraSnapShot NewSnapShot = ViewTargetSnapShot;
	ViewTargetSnapShot.POV = ViewTarget.POV;

	// update color scale interpolation
	if (bEnableColorScaleInterp)
	{
		float BlendPct = FMath::Clamp((GetWorld()->TimeSeconds - ColorScaleInterpStartTime) / ColorScaleInterpDuration, 0.f, 1.0f);
		ColorScale = FMath::Lerp(OriginalColorScale, DesiredColorScale, BlendPct);
		// if we've maxed
		if (BlendPct == 1.0f)
		{
			// disable further interpolation
			bEnableColorScaleInterp = false;
		}
	}

	if (bEnableCameraModifier)
	{
		ClearCachedPPBlends();
	}

	// Don't update outgoing viewtarget during an interpolation when bLockOutgoing is set.
	if ((ViewTarget.Target != PendingViewTarget.Target) && ((PendingViewTarget.Target == NULL) || !BlendParams.bLockOutgoing))
	{
		// Update current view target
		if(!IsValid(ViewTarget.Target) && IsValid(CameraForGaming))
		{
			AssignViewTarget(CameraForGaming, ViewTarget);
		}
		ViewTarget.CheckViewTarget(PCOwner);
		UpdateView(ViewTarget, ViewTargetSnapShot, DeltaTime);
	}
	
	// our camera is now viewing there
	NewSnapShot = ViewTargetSnapShot;

	// if we have a pending view target, perform transition from one to another.
	if (PendingViewTarget.Target != NULL)
	{
		BlendTimeToGo -= DeltaTime;

		// Update pending view target
		PendingViewTarget.CheckViewTarget(PCOwner);
		UpdateView(PendingViewTarget, ViewPendingTargetSnapShot, DeltaTime);

		if (BlendTimeToGo > 0)
		{
			const float DurationPct = (BlendParams.BlendTime - BlendTimeToGo) / BlendParams.BlendTime;
			float BlendPct = 0.f;

			if(bUseCustomBlend)
			{
				BlendPct = CameraBlendParam.Evaluate(DeltaTime);
				CameraViewBlendProxy.CustomBlendPOV(NewSnapShot, ViewTargetSnapShot, ViewPendingTargetSnapShot, BlendPct, bHasRotationInput, IsValid(CameraActionHandler) ? CameraActionHandler->HsaModifyPitch() || CameraActionHandler->HsaModifyYaw() : false, bDoNotBlendRot, this);
				// UE_LOG(LogTemp, Log, TEXT("Camera Blend Pct:%f"), BlendPct);
			}
			else
			{
				switch (BlendParams.BlendFunction)
				{
				case VTBlend_Linear:
					BlendPct = FMath::Lerp(0.f, 1.f, DurationPct);
					break;
				case VTBlend_Cubic:
					BlendPct = FMath::CubicInterp(0.f, 0.f, 1.f, 0.f, DurationPct);
					break;
				case VTBlend_EaseIn:
					BlendPct = FMath::Lerp(0.f, 1.f, FMath::Pow(DurationPct, BlendParams.BlendExp));
					break;
				case VTBlend_EaseOut:
					BlendPct = FMath::Lerp(0.f, 1.f, FMath::Pow(DurationPct, 1.f / BlendParams.BlendExp));
					break;
				case VTBlend_EaseInOut:
					BlendPct = FMath::InterpEaseInOut(0.f, 1.f, DurationPct, BlendParams.BlendExp);
					break;
				case VTBlend_PreBlended:
					BlendPct = 1.0f;
					break;
				default:
					break;
				}

				NewSnapShot.POV.BlendViewInfo(ViewPendingTargetSnapShot.POV, BlendPct);
			}

			// Add this pending view target's post-process settings as an override of the main view target's one,
			// since it is blending on top of it.
			const float PendingViewTargetPPWeight = PendingViewTarget.POV.PostProcessBlendWeight * BlendPct;
			if (PendingViewTargetPPWeight > 0.f)
			{
				AddCachedPPBlend(PendingViewTarget.POV.PostProcessSettings, PendingViewTargetPPWeight, VTBlendOrder_Override);
			}
		}
		else
		{
			// we're done blending, set new view target
			ViewTarget = PendingViewTarget;

			// clear pending view target
			PendingViewTarget.Target = NULL;

			BlendTimeToGo = 0;

			// our camera is now viewing there
			NewSnapShot.POV = PendingViewTarget.POV;

			OnBlendComplete().Broadcast();
		}
	}

	// Viewing through a camera actor.
	// 通知当前UWaveOscillatorCameraShakePatternV2震屏配置的Camera对象
	for(auto CustomPattern : CustomShakePatternList)
	{
		if(CustomPattern.IsValid())
		{
			CustomPattern->SetArmLen(NewSnapShot.RealArmLen);
		}
	}

	/**
	* 后处理当前来源数据有两种, 一个是UE原生的CameraModifier提供的后处理效果(CutScene), 一个是PPManager管理的后处理效果
	* 后处理当前在用的开关有两个
	* 1) bDoNotApplyModifiers(自由相机或者调试相机模式, 为true时期望CameraModifier来源后处理不生效)
	* 2) bEnableCameraModifier(C7自己加的, 为false时期望所有后处理不生效)
	*
	 * 先支持CameraModifier和 PPManager混用的情况(是否有这种使用case?)
	* bDoNotApplyModifiers为false时, 原始camera manager并不会执行ClearCachedPPBlends, 目前直接清理掉(如果希望不清理, 还需要标记PostProcessBlendCache中哪些属于CameraModifier来源, 哪些属于PPManager来源)
	* 当前业务侧并没有找到类似的使用case, 后续如果有需要再扩展这里的功能
	*/

	if (bEnableCameraModifier)
	{
		if(CameraActionHandler != nullptr)
		{
			CameraActionHandler->ModifyViewPOV(DeltaTime, NewSnapShot.POV);
		}

		// Apply camera modifiers at the end (view shakes for example)
		ApplyCameraModifiers(DeltaTime, NewSnapShot.POV);

		if (UPostProcessManager* NewPostProcessManager = UPostProcessManager::GetInstance(GetWorld()))
		{
			NewPostProcessManager->AccumulateCachedPostProcessBlends(PostProcessBlendCache, PostProcessBlendCacheWeights, PostProcessBlendCacheOrders);
		}
	}

	// Synchronize the actor with the view target results
	SetActorLocationAndRotation(NewSnapShot.POV.Location, NewSnapShot.POV.Rotation, false);
	
	for (int32 Idx=0; Idx<CameraLensEffects.Num(); ++Idx)
	{
		if (CameraLensEffects[Idx] != NULL)
		{
			CameraLensEffects[Idx]->UpdateLocation(NewSnapShot.POV.Location, NewSnapShot.POV.Rotation, NewSnapShot.POV.FOV);
		}
	}

	if (bEnableFading)
	{
		if (bAutoAnimateFade)
		{
			FadeTimeRemaining = FMath::Max(FadeTimeRemaining - DeltaTime, 0.0f);


			if (FadeTime > 0.0f)
			{
				if(CurveForFade == nullptr)
				{
					FadeAmount = FadeAlpha.X + ((1.f - FadeTimeRemaining / FadeTime) * (FadeAlpha.Y - FadeAlpha.X));
				}
				else
				{
					float MinTime = 0;
					float MaxTime = 0;
					CurveForFade->GetTimeRange(MinTime, MaxTime);
					float CurveTime = (1.f - FadeTimeRemaining / FadeTime) * (MaxTime - MinTime) + MinTime;
					FadeAmount = FMath::Clamp(CurveForFade->GetFloatValue(CurveTime), 0.f, 1.f);
					UE_LOG(LogTemp, Log, TEXT("Camera Fade Amount:%f, RemainingTime:%f, FadeTime:%f"), FadeAmount, FadeTimeRemaining, FadeTime);
				}
			}

			if(FadeTimeRemaining <= 0.f)
			{
				CurveForFade = nullptr;
				if(bHoldFadeWhenFinished == false)
				{
					StopCameraFade();
				}
			}
		}
		else
		{
			CurveForFade = nullptr;
		}

		if (bFadeAudio)
		{
			ApplyAudioFade();
		}
	}

	if (AllowPhotographyMode())
	{
		const bool bPhotographyCausedCameraCut = UpdatePhotographyCamera(NewSnapShot.POV);
		bGameCameraCutThisFrame = bGameCameraCutThisFrame || bPhotographyCausedCameraCut;
	}

	// Cache results
	FillCameraCache(NewSnapShot.POV);
	ViewCachedSnapShot = NewSnapShot;

	if(CameraActionHandler != nullptr)
	{
		CameraActionHandler->UpdateAfterFrame();
	}
}

void ACameraManager::UpdateView(FTViewTarget& OutVT, FCameraSnapShot& OutSnapShot, float DeltaTime)
{
	// Reset the view target POV fully
	static const FMinimalViewInfo DefaultViewInfo;
	OutVT.POV = DefaultViewInfo;
	OutVT.POV.FOV = DefaultFOV;
	OutVT.POV.OrthoWidth = DefaultOrthoWidth;
	OutVT.POV.AspectRatio = PCAspectRatio;
	OutVT.POV.bConstrainAspectRatio = bDefaultConstrainAspectRatio;
	OutVT.POV.ProjectionMode = bIsOrthographic ? ECameraProjectionMode::Orthographic : ECameraProjectionMode::Perspective;
	OutVT.POV.PostProcessBlendWeight = 1.0f;
	OutVT.POV.AspectRatioAxisConstraint = EAspectRatioAxisConstraint::AspectRatio_MaintainYFOV;

	OutSnapShot.CameraTarget = OutVT.Target;
	OutSnapShot.PlayerController = PCOwner;

	if (ACameraActor* CamActor = Cast<ACameraActor>(OutVT.Target))
	{
		// Viewing through a camera actor.
		CamActor->GetCameraComponent()->GetCameraView(DeltaTime, OutVT.POV);
		if(ABaseCamera* Camera = Cast<ABaseCamera>(CamActor))
		{
			auto* Arm = Camera->GetCameraArmComponent();
			OutSnapShot.RealArmLen = Arm->GetRealCameraArmLen();
			OutSnapShot.PivotLocation = Arm->GetCachedPivotLocation();
			OutSnapShot.LookAtActor = Camera->GetLookAtTarget();
			OutSnapShot.LookAtActorLocation = Camera->GetLookAtTarget() != nullptr ? Camera->GetLookAtTarget()->GetActorLocation() : OutSnapShot.PivotLocation;
			OutSnapShot.PivotRotation = Arm->GetCachedPivotRotation();
			OutSnapShot.ScreenOffset = Arm->GetScreenOffset();
			OutSnapShot.SocketOffset = Arm->SocketOffset;
			OutSnapShot.SocketRotOffset = Arm->SocketRotOffset;
		}
	}
	else
	{
		UpdateViewTargetInternal(OutVT, DeltaTime);
		OutSnapShot.RealArmLen = 0.f;
		OutSnapShot.PivotLocation = OutVT.POV.Location;
		OutSnapShot.PivotRotation = OutVT.POV.Rotation;
		OutSnapShot.ScreenOffset = FVector2D::ZeroVector;
		OutSnapShot.SocketOffset = FVector::ZeroVector;
		OutSnapShot.SocketRotOffset = FRotator::ZeroRotator;
	}

	float DesiredFOV = OutVT.POV.FOV;
	OutVT.POV.DesiredFOV = DesiredFOV;

	OutSnapShot.POV = OutVT.POV;
}

void ACameraManager::StopCameraFade()
{
	Super::StopCameraFade();
	CurveForFade = nullptr;
}

UCameraShakeBase* ACameraManager::StartCameraShake(TSubclassOf<UCameraShakeBase> ShakeClass, float Scale,
                                                   ECameraShakePlaySpace PlaySpace, FRotator UserPlaySpaceRot)
{
	return StartCameraShakeWithDuration(ShakeClass, Scale, PlaySpace, UserPlaySpaceRot,0);
}

UCameraShakeBase* ACameraManager::StartCameraShakeWithDuration(TSubclassOf<UCameraShakeBase> ShakeClass, float Scale, ECameraShakePlaySpace PlaySpace, FRotator UserPlaySpaceRot, float Duration)
{
	c7_obj_check(ShakeClass)
	UCameraShakeBase* Result = nullptr;
	if (ShakeClass && CachedCameraShakeMod && (Scale > 0.0f))
	{
		if (ShakeClass->IsChildOf(UBaseCameraShake::StaticClass()))
		{
			if (const UBaseCameraShake* CDO = Cast<UBaseCameraShake>(ShakeClass->GetDefaultObject()))
			{
				FAddCameraShakeParams ShakeParams(Scale * CDO->Scale, CDO->PlaySpace, CDO->UserPlaySpaceRot);
				if(Duration > 0)
				{
					ShakeParams.DurationOverride = Duration;
				}
				Result = CachedCameraShakeMod->AddCameraShake(
					ShakeClass, ShakeParams);
			}
		}
		else
		{
			FAddCameraShakeParams ShakeParams(Scale, PlaySpace, UserPlaySpaceRot);
			if(Duration > 0)
			{
				ShakeParams.DurationOverride = Duration;
			}
			Result = CachedCameraShakeMod->AddCameraShake(
				ShakeClass, ShakeParams);
		}
	}
	if (Result != nullptr)
	{
		if (UWaveOscillatorCameraShakePatternV2* CustomPattern = Cast<UWaveOscillatorCameraShakePatternV2>(
			Result->GetRootShakePattern()))
		{
			CustomPattern->SetCameraMgr(this);
			CustomShakePatternList.Add(CustomPattern);
		}
	}
	return Result;
}

int64 ACameraManager::KAPI_Camera_StartCameraShakeWithDuration(int64 ShakeClassID, float Scale, ECameraShakePlaySpace PlaySpace, FRotator UserPlaySpaceRot, float Duration)
{
	if(UClass* ShakeClass = KGUtils::GetClassByID(ShakeClassID))
	{
		return KGUtils::GetIDByObject(StartCameraShakeWithDuration(ShakeClass, Scale, PlaySpace, UserPlaySpaceRot, Duration));
	}

	return KG_INVALID_ID;
}

void ACameraManager::KAPI_Camera_StopCameraShake(int64 ShakeInstID, bool bImmediately)
{
	if(UCameraShakeBase* CameraShakeInst = Cast<UCameraShakeBase>(KGUtils::GetObjectByID(ShakeInstID)))
	{
		StopCameraShake(CameraShakeInst, bImmediately);
	}
}

void ACameraManager::KAPI_Camera_SetViewTargetWithBlendCustom(AActor* NewViewTarget, float BlendTime,
                                                              ECameraEaseFunction::Type EaseFunc,
                                                              ECameraViewBlendFunction::Type BlendType,
                                                              bool bLockOutgoing, int64 CameraBlendCurveID,
                                                              bool bInDoNotBlendRot)
{
	UCurveFloat* CameraBlendCurve = Cast<UCurveFloat>(KGUtils::GetObjectByID(CameraBlendCurveID));
	CustomSetViewTarget(NewViewTarget, EaseFunc, BlendType, BlendTime, bLockOutgoing, CameraBlendCurve, bInDoNotBlendRot);
}

void ACameraManager::KAPI_Camera_SetViewTargetWithBlendCustomByID(int64 NewViewTargetID, float BlendTime,
                                                                  ECameraEaseFunction::Type EaseFunc,
                                                                  ECameraViewBlendFunction::Type BlendType,
                                                                  bool bLockOutgoing, int64 CameraBlendCurveID,
                                                                  bool bInDoNotBlendRot)
{
	if(AActor* NewViewTarget = KGUtils::GetActorByID(NewViewTargetID))
	{
		KAPI_Camera_SetViewTargetWithBlendCustom(NewViewTarget, BlendTime, EaseFunc, BlendType, bLockOutgoing, CameraBlendCurveID, bInDoNotBlendRot);
	}
}

void ACameraManager::KAPI_Camera_SetViewTargetWithBlendCustomByCameraComponentID(int64 NewViewTargetID, float BlendTime,
	ECameraEaseFunction::Type EaseFunc, ECameraViewBlendFunction::Type BlendType, bool bLockOutgoing,
	int64 CameraBlendCurveID)
{
	if(UCameraComponent* Cam = Cast<UCameraComponent>(KGUtils::GetObjectByID(NewViewTargetID)))
	{
		if(AActor* NewViewTarget = Cam->GetOwner())
		{
			KAPI_Camera_SetViewTargetWithBlendCustom(NewViewTarget, BlendTime, EaseFunc, BlendType, bLockOutgoing, CameraBlendCurveID);
		}
	}
}

void ACameraManager::KAPI_Camera_SetViewTargetWithBlendByID(int64 NewViewTargetID, float BlendTime,
                                                            EViewTargetBlendFunction BlendFunc, float BlendExp,
                                                            bool bLockOutgoing)
{
	if(AActor* NewViewTarget = KGUtils::GetActorByID(NewViewTargetID))
	{
		FViewTargetTransitionParams TransitionParams;
		TransitionParams.BlendTime = BlendTime;
		TransitionParams.BlendFunction = BlendFunc;
		TransitionParams.BlendExp = BlendExp;
		TransitionParams.bLockOutgoing = bLockOutgoing;

		SetViewTarget(NewViewTarget, TransitionParams);
	}
}

void ACameraManager::KAPI_Camera_SetViewTargetWithBlendByCameraComponentID(int64 NewViewTargetID, float BlendTime,
	EViewTargetBlendFunction BlendFunc, float BlendExp, bool bLockOutgoing)
{
	if(UCameraComponent* Cam = Cast<UCameraComponent>(KGUtils::GetObjectByID(NewViewTargetID)))
	{
		if(AActor* NewViewTarget = Cam->GetOwner())
		{
			FViewTargetTransitionParams TransitionParams;
			TransitionParams.BlendTime = BlendTime;
			TransitionParams.BlendFunction = BlendFunc;
			TransitionParams.BlendExp = BlendExp;
			TransitionParams.bLockOutgoing = bLockOutgoing;

			SetViewTarget(NewViewTarget, TransitionParams);
		}
	}
}

void ACameraManager::Update(float DeltaTime)
{
	QUICK_SCOPE_CYCLE_COUNTER(ACameraManager_Update);

	UKgCameraMode* Mode = nullptr;
	for(auto& [_, CameraMode] : CameraModes)
	{
		CameraMode->Update(DeltaTime);
	}

	bool Deleted = false;
	for(int i = ModifierList.Num()-1 ; i > -1; --i)
	{
		UCameraEffect* Effect = Cast<UCameraEffect>(ModifierList[i]);
		if (Effect!= nullptr && Effect->ShouldDelete())
		{
			if (ModifierList[i])
			{
				ModifierList.RemoveAt(i, 1,EAllowShrinking::No);
				Deleted = true;
			}
		}
	}
	
	if(Deleted)
	{
		ModifierList.Shrink();
	}
	
	if (CameraActionHandler)
	{
		CameraActionHandler->UpdateCameraActions(DeltaTime);
	}

	//BEGIN ADD BY hujianglong@kuaishou.com : UKGAkAudioManager在Core模块，这里来更新一下音频组件需要的相机距离参数
	if(!AudioCameraDistanceRtpcName.IsEmpty())
	{
		UKgCameraMode* CurCameraMode = GetCurCameraMode();
		if(CurCameraMode != nullptr)
		{
			ABaseCamera* CurCamera = Cast<ABaseCamera>(CurCameraMode->GetCurCamera());
			if(CurCamera != nullptr && CurCamera->CameraArmComponent != nullptr)
			{
				float ArmLen = CurCamera->CameraArmComponent->GetRealCameraArmLen();
				if (!FMath::IsNearlyEqual(CurrentCameraDistanceRtpcValue, ArmLen, AudioCameraDistanceTolerance))
				{
					CurrentCameraDistanceRtpcValue = ArmLen;
					UKGAkAudioManager::GetInstance(this)->InnerSetRtpcValue(AudioCameraDistanceRtpcName, FMath::FloorToInt(ArmLen));
				}
			}
		}
	}
	//END ADD BY hujianglong@kuaishou.com
}

void ACameraManager::OnCustomShakePatternTeardown(
	UWaveOscillatorCameraShakePatternV2* WaveOscillatorCameraShakePatternV2)
{
	CustomShakePatternList.Remove(WaveOscillatorCameraShakePatternV2);
}

void ACameraManager::PlayCameraShake(const FString& AssetPath, float Scale)
{
	FString ShakePath = AssetPath;
	if (!ShakePath.EndsWith("_C"))
	{
		ShakePath += "_C";
	}
	if(UClass* LoadedObject = StaticLoadClass(UDefaultCameraShakeBase::StaticClass(), nullptr, *ShakePath))
	{
		StartCameraShake(LoadedObject, Scale);
	}
}

void ACameraManager::ProcessViewRotation(float DeltaTime, FRotator& OutViewRotation, FRotator& OutDeltaRot)
{
	SCOPE_CYCLE_COUNTER(STAT_Camera_ProcessViewRotation);

	// UE_LOG(LogTemp, Log, TEXT("Camera ProcessViewRotation:%s OutDeltaRot:%s"), *OutViewRotation.ToString(), *OutDeltaRot.ToString())

	if(!IsValid(ViewTarget.Target) && IsValid(CameraForGaming))
	{
#if !(UE_BUILD_SHIPPING || UE_BUILD_TEST)
		UE_LOG(LogTemp, Log, TEXT("Camera Detect ViewTarget InValid SetViewTarget To BaseCamera:%s"), *GetNameSafe(CameraForGaming))
#endif
		AssignViewTarget(CameraForGaming, ViewTarget);
	}

	if (!bCanRotInputWhileBlend && bUseCustomBlend && !bDoNotBlendRot && IsValid(PendingViewTarget.Target))
	{
		OutDeltaRot = FRotator::ZeroRotator;
	}

	if(CameraActionHandler != nullptr)
	{
		CameraActionHandler->ProcessViewRotation(ViewTarget.Target, DeltaTime, OutViewRotation, OutDeltaRot);
	}

	for( int32 ModifierIdx = 0; ModifierIdx < ModifierList.Num(); ModifierIdx++ )
	{
		if( ModifierList[ModifierIdx] != NULL && 
			!ModifierList[ModifierIdx]->IsDisabled() )
		{
			if( ModifierList[ModifierIdx]->ProcessViewRotation(ViewTarget.Target, DeltaTime, OutViewRotation, OutDeltaRot) )
			{
				break;
			}
		}
	}

	bHasRotationInput = OutDeltaRot.IsNearlyZero();

	// Add Delta Rotation
	OutViewRotation += OutDeltaRot;
	OutDeltaRot = FRotator::ZeroRotator;

	if(const bool bIsHeadTrackingAllowed = GEngine->XRSystem.IsValid() && (GetWorld() != nullptr ? GEngine->XRSystem->IsHeadTrackingAllowedForWorld(*GetWorld()) : GEngine->XRSystem->IsHeadTrackingAllowed()))
	{
		// With the HMD devices, we can't limit the view pitch, because it's bound to the player's head.  A simple normalization will suffice
		OutViewRotation.Normalize();
	}
	else
	{
		// Limit Player View Axes
		if(DisableLimitView <= 0)
		{
			LimitViewPitch( OutViewRotation, ViewPitchMin, ViewPitchMax );
			LimitViewYaw( OutViewRotation, ViewYawMin, ViewYawMax );
			LimitViewRoll( OutViewRotation, ViewRollMin, ViewRollMax );
		}
	}
}

void ACameraManager::AssignViewTarget(AActor* NewTarget, FTViewTarget& VT, FViewTargetTransitionParams TransitionParams)
{
	Super::AssignViewTarget(NewTarget, VT, TransitionParams);
	// 加个日志
#if !(UE_BUILD_SHIPPING || UE_BUILD_TEST)
	UE_LOG(LogTemp, Log, TEXT("Camera AssignViewTarget SetViewTarget To %s"), *GetNameSafe(NewTarget))
#endif
}

float ACameraManager::GetCameraShakeDurationFromCDO(TSubclassOf<UCameraShakeBase> CameraShakeClass)
{
	FCameraShakeDuration ShakeDuration;
	if (CameraShakeClass != nullptr)
	{
		UCameraShakeBase::GetCameraShakeDuration(CameraShakeClass, ShakeDuration);
	}

	if (ShakeDuration.IsInfinite())
	{
		return 0;	
	}
	
	return ShakeDuration.Get();
}

void ACameraManager::SetEnableCameraModifier(bool bEnable)
{
	bEnableCameraModifier = bEnable;

	if (!bEnable)
	{
		ClearCachedPPBlends();
	}
}

void ACameraManager::K2_ClearCachedPPBlends()
{
	ClearCachedPPBlends();
}

bool ACameraManager::IsBlending()
{
	return BlendTimeToGo > 0 && PendingViewTarget.Target !=nullptr;
}

void ACameraManager::OnBlendFinish()
{
	UE_LOG(LogTemp, Log, TEXT("CameraManager Camera Blend Finish"));
	bDoNotBlendRot = false;
	if(bNeedNotifyScriptWhenBlendFinish)
	{
		OnBlendFinishForScript();
	}
}
#pragma region CameraBase

AActor* ACameraManager::KAPI_Camera_GetLookAtTarget()
{
	if(UKgCameraMode* Mode = GetCurCameraMode())
	{
		if(UCameraArmComponent* Arm = Mode->GetCameraArmComponent())
		{
			return Arm->LookAtTarget.Get();
		}
	}
	return nullptr;
}

int64 ACameraManager::KAPI_Camera_GetLookAtTargetActorID()
{
	if(UKgCameraMode* Mode = GetCurCameraMode())
	{
		if(UCameraArmComponent* Arm = Mode->GetCameraArmComponent())
		{
			return KGUtils::GetIDByObject(Arm->LookAtTarget.Get());
		}
	}
	return KG_INVALID_ID;
}

void ACameraManager::KAPI_LoadCurves(const TArray<FString>& Curves, const TArray<int64>& CurvesID)
{
	if(Curves.Num() != CurvesID.Num())
	{
		UE_LOG(LogTemp, Error, TEXT("Camera Load Curves Number Not Match!"));
		return;
	}
	if(UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this))
	{
		CurveIDs = CurvesID;
		CurveLoadID = AssetManager->AsyncLoadAsset(Curves, FAsyncLoadListCompleteDelegate::CreateUObject(this, &ACameraManager::OnLoadedCurves), static_cast<int32>(EAssetLoadPriority::MoveCurve));
	}
}

void ACameraManager::OnLoadedCurves(int InLoadID, const TArray<UObject*>& Curves)
{
	if(InLoadID != CurveLoadID)
	{
		return;
	}
	CurveLoadID = -1;

	if(Curves.Num() != CurveIDs.Num())
	{
		CurveIDs.Reset();
		UE_LOG(LogTemp, Error, TEXT("Camera Loaded Curves Number Not Match!"));
		return;
	}

	CameraCurves.Reset();
	TMap<int64, int64> CurveIDToObjectID;
	for(int Index = 0; Index < CurveIDs.Num(); ++Index)
	{
		if(UCurveBase* Curve = Cast<UCurveBase>(Curves[Index]))
		{
			CameraCurves.Add(CurveIDs[Index], Curve);
			CurveIDToObjectID.Add(CurveIDs[Index], KGUtils::GetIDByObject(Curve));
		}
	}
	KCB_Camera_OnLoadedCurves(CurveIDToObjectID);
}



void ACameraManager::KAPI_Camera_SetACTMode(bool bEnable)
{
	bACTMode = bEnable;
}

void ACameraManager::KAPI_Camera_SetViewAngleSetting(int64 CameraModeID, float InViewPitchMin, float InViewPitchMax, float InViewYawMin,
                                                     float InViewYawMax, float InViewRollMin, float InViewRollMax,
                                                     int Priority)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->SetViewAngleSetting(InViewPitchMin, InViewPitchMax, InViewYawMin, InViewYawMax, InViewRollMin, InViewRollMax, Priority);
	}
}

void ACameraManager::KAPI_Camera_RemoveViewAngleSetting(int64 CameraModeID, int Priority)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->RemoveViewAngleSetting(Priority);
	}
}

void ACameraManager::KAPI_Camera_SetViewPitchSetting(int64 CameraModeID, float Min, float Max, int Priority)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->SetViewPitchSetting(Min, Max, Priority);
	}
}

void ACameraManager::KAPI_Camera_SyncModeViewLimitSetting(int64 CameraModeID)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		const FCameraModeConfig& BasicConfig = CameraMode->BasicConfig;
		ViewPitchMin = BasicConfig.CustomViewPitchMin.GetValue();
		ViewPitchMax = BasicConfig.CustomViewPitchMax.GetValue();
		ViewYawMin = BasicConfig.CustomViewYawMin.GetValue();
		ViewYawMax = BasicConfig.CustomViewYawMax.GetValue();
		ViewRollMin = BasicConfig.CustomViewRollMin.GetValue();
		ViewRollMax = BasicConfig.CustomViewRollMax.GetValue();
	}
}

void ACameraManager::KAPI_Camera_SetViewYawSetting(int64 CameraModeID, float Min, float Max, int Priority)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->SetViewYawSetting(Min, Max, Priority);
	}
}

void ACameraManager::KAPI_Camera_SetViewRollSetting(int64 CameraModeID, float Min, float Max, int Priority)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->SetViewRollSetting(Min, Max, Priority);
	}
}

void ACameraManager::KAPI_Camera_ClearMode()
{
	CameraModes.Reset();
	if(CameraForGaming != nullptr)
	{
		CameraForGaming->Destroy();
		CameraForGaming = nullptr;
	}
	if(CineCameraForGaming != nullptr)
	{
		CineCameraForGaming->Destroy();
		CineCameraForGaming = nullptr;
	}
	ActivateCameraModeTag = -1;
	if(IsValid(CameraActionHandler))
	{
		CameraActionHandler->ClearAllAction();
	}
}

int64 ACameraManager::KAPI_Camera_GetOrCreateCamera(int CameraModeTag, bool bCinematic)
{
	if(bCinematic)
	{
		if(CineCameraForGaming != nullptr)
		{
			return KGUtils::GetIDByObject(CineCameraForGaming);
		}
	}
	else
	{
		if(CameraForGaming != nullptr)
		{
			return KGUtils::GetIDByObject(CameraForGaming);
		}	
	}

	UClass* CameraClass = bCinematic ? ABaseCineCamera::StaticClass() : ABaseCamera::StaticClass();
	if(ABaseCamera* Camera = Cast<ABaseCamera>(GetWorld()->SpawnActor(CameraClass)))
	{
		if(bCinematic)
		{
			CineCameraForGaming = Camera;
		}
		else
		{
			CameraForGaming = Camera;
		}
		return KGUtils::GetIDByObject(Camera);
	}
	return KG_INVALID_ID;
}

int64 ACameraManager::KAPI_Camera_GetOrCreateGameControlCamera(int64 GPEMCameraID, const FVector& Loc,
                                                               const FRotator& Rot)
{
	if(CameraForGaming != nullptr)
	{
		CameraForGaming->SetActorLocation(Loc);
		CameraForGaming->SetActorRotation(Rot);
		return KGUtils::GetIDByObject(CameraForGaming);
	}

	FActorSpawnParameters SpawnParameters;
	FTransform ActorTransform = FTransform(Rot, Loc);
	if(ABaseCamera* Camera = Cast<ABaseCamera>(GetWorld()->SpawnActor(ABaseCamera::StaticClass(), &ActorTransform, SpawnParameters)))
	{
		CameraForGaming = Camera;
		return KGUtils::GetIDByObject(Camera);
	}
	return KG_INVALID_ID;
}

int64 ACameraManager::KAPI_Camera_CreateCameraMode(int CameraModeTag)
{
	return KG_INVALID_ID;
}

int64 ACameraManager::KAPI_Camera_FindCameraByName(const FName& CameraMane)
{
	TArray<AActor*> Result;
	UGameplayStatics::GetAllActorsOfClass(GetWorld(), ACameraActor::StaticClass(), Result);
	for(auto& Actor : Result)
	{
		if(Actor->GetFName().IsEqual(CameraMane))
		{
			return KGUtils::GetIDByObject(Actor);
		}
	}

	return KG_INVALID_ID;
}

int64 ACameraManager::KAPI_Camera_GetViewTargetActorID()
{
	return KGUtils::GetIDByObject(ViewTarget.Target);
}

void ACameraManager::KAPI_Camera_EnableModeApplyPOVPostProcess(int64 CameraModeID, bool bEnable)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->EnableApplyPOVPostProcess(bEnable);
	}
}

void ACameraManager::KAPI_Camera_CopyAndRefreshControlData(int64 PreviousCameraModeID, int64 CurrentCameraModeID, int Priority)
{
	if(UKgCameraMode* PreviousCameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(PreviousCameraModeID)))
	{
		if (UKgCameraMode* CurrentCameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CurrentCameraModeID)))
		{
			CurrentCameraMode->CopyAndRefreshControlData(PreviousCameraMode, Priority);
		}
	}
}

void ACameraManager::KAPI_Camera_RefreshControlData(
	int64 CameraModeID, int Priority,
	float ZoomMin, float ZoomMax, float ZoomStep, float NewFOV,
	int EaseTypeZoomLag, float ParamZoomLag, int64 CurveIDZoomLag,
	int EaseTypeZLag, float ParamZLag, int64 CurveIDZLag, float NewSoftZoneRadiusZ,
	int EaseTypeXOYLag, float ParamXOYLag, int64 CurveIDXOYLag, float NewSoftZoneRadiusXOY,
	int EaseTypeRelease, float ParamRelease, int64 CurveIDRelease,
	int EaseTypeCompress, float ParamCompress, int64 CurveIDCompress,
	float ViewOffX, float ViewOffY,
	bool bEnableDitherFade, const TArray<int>& NewDitherFadeObjectTypesForStatic, const TArray<int>& NewDitherFadeObjectTypesForDynamic,
	int DetectType, float DetectRadius, float DetectPitch, float AngleMin, float AngleMax, float StaticDetectInterval, float DynamicDetectInterval, float CameraPosDiffThreshold,
	float InitArmLen, const FRotator& InitRot,
	float YawSensitivity, float PitchSensitivity, int64 TargetLocationOffsetCurveID, int64 FOVCurveID
)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->RefreshControlData(
			Priority,
			ZoomMin, ZoomMax, ZoomStep, NewFOV,
			EaseTypeZoomLag, ParamZoomLag, CurveIDZoomLag,
			EaseTypeZLag, ParamZLag, CurveIDZLag, NewSoftZoneRadiusZ,
			EaseTypeXOYLag, ParamXOYLag, CurveIDXOYLag, NewSoftZoneRadiusXOY,
			EaseTypeRelease, ParamRelease, CurveIDRelease,
			EaseTypeCompress, ParamCompress, CurveIDCompress,
			ViewOffX, ViewOffY,
			bEnableDitherFade, NewDitherFadeObjectTypesForStatic, NewDitherFadeObjectTypesForDynamic,
			DetectType, DetectRadius, DetectPitch, StaticDetectInterval, DynamicDetectInterval, CameraPosDiffThreshold,
			InitArmLen, InitRot,
			YawSensitivity, PitchSensitivity, TargetLocationOffsetCurveID, FOVCurveID
		);
	}
	
	if (auto* MaterialManager = UKGMaterialManager::GetInstance(GetWorld()))
	{
		MaterialManager->SetCameraDitherAngleThreshold(AngleMin, AngleMax);
	}
}

void ACameraManager::KAPI_Camera_InitRotationLagParam(int64 CameraModeID, bool bNewEnableCameraRotationLag,
                                                      ECameraEaseFunction::Type EaseType, float Param, int64 CurveID)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->InitRotationLagParam(bNewEnableCameraRotationLag, EaseType, Param, CurveID);
	}
}

void ACameraManager::KAPI_Camera_ResetCamera(int64 CameraModeID)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->ResetToDefault();
	}
}

void ACameraManager::KAPI_Camera_EnableModeTick(int64 CameraModeID, bool bEnable)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->bEnableTick = bEnable;
	}
}

void ACameraManager::KAPI_Camera_ForceUpdate(int64 CameraModeID, bool bDoTrace)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->ForceUpdate(bDoTrace);
	}
}

void ACameraManager::KAPI_Camera_MarkInstantBlend(int64 CameraActorID, bool bMarkInstantBlend)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->GetCameraArmComponent()->MarkInstantBlend(bMarkInstantBlend);
	}
}

void ACameraManager::KAPI_Camera_ForceUpdateWithBaseCollision(int64 CameraModeID)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->ForceUpdateWithBaseCollision();
	}
}

void ACameraManager::KAPI_Camera_MarkModeActivate(int64 CameraModeID, bool Value)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->MarkActivate(Value);
		ActivateCameraModeTag = CameraMode->CameraModeTag;
	}
}

void ACameraManager::KAPI_Camera_SetLookAtTargetByID(int64 CameraID, int64 TargetID)
{
	if(ABaseCamera* BaseCamera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraID)))
	{
		BaseCamera->SetLookAtTargetByID(TargetID);
	}
}

void ACameraManager::KAPI_Camera_AfterModeActivate(int64 CameraModeID)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		if(CameraActionHandler != nullptr)
		{
			CameraActionHandler->OnModeActivate(CameraMode);
		}
	}
}

void ACameraManager::KAPI_Camera_SetInitArmLenAndDir(int64 CameraModeID, float TargetArmLen, const FRotator& TargetRot,
                                                     const FRotator& BaseSpace, bool bSyncPlayerController)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->SetInitArmLenAndDir(TargetArmLen, TargetRot, BaseSpace, bSyncPlayerController);
	}
}

void ACameraManager::KAPI_Camera_SetZoomSetting(int64 CameraModeID, float ZoomMin, float ZoomMax, int Priority)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->SetZoomSetting(ZoomMin, ZoomMax, Priority);
	}
}

void ACameraManager::KAPI_Camera_GetZoomSetting(int64 CameraModeID, float& ZoomMin, float& ZoomMax)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->GetZoomSetting(ZoomMin, ZoomMax);
	}
}

void ACameraManager::KAPI_Camera_SetOverrideZoomSetting(int64 CameraModeID, float OverrideZoom, int Priority)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->SetOverrideZoomSetting(OverrideZoom, Priority);
	}
}

float ACameraManager::KAPI_Camera_GetZoomMin(int64 CameraModeID) const
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		return CameraMode->BasicConfig.ZoomMinLen.GetValue();
	}

	return 0;
}

float ACameraManager::KAPI_Camera_GetZoomMax(int64 CameraModeID) const
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		return CameraMode->BasicConfig.ZoomMaxLen.GetValue();
	}

	return 0;
}

void ACameraManager::KAPI_Camera_SetZoomMaxSetting(int64 CameraModeID, float ZoomMax, int Priority)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->SetZoomMaxSetting(ZoomMax, Priority);
	}
}

void ACameraManager::KAPI_Camera_RemoveZoomSetting(int64 CameraModeID, int Priority, bool bNeedZoomFix)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->RemoveZoomSetting(Priority, bNeedZoomFix);
	}
}

FVector ACameraManager::KAPI_Camera_GetCameraViewForwardDirection()
{
	FRotator ViewRot = GetCameraRotation();
	ViewRot.Pitch = 0.f;
	return ViewRot.Vector();
}

FVector ACameraManager::KAPI_Camera_GetCameraViewRightDirection()
{
	FRotator ViewRot = GetCameraRotation();
	ViewRot.Pitch = 0.f;
	return ViewRot.RotateVector(FVector::RightVector);
}

void ACameraManager::KAPI_Camera_SetFOVSetting(int64 CameraModeID, float NewFOV, int Priority)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->SetFOVSetting(NewFOV, Priority);
	}
}

void ACameraManager::KAPI_Camera_RemoveFOVSetting(int64 CameraModeID, int Priority)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
    {
    	CameraMode->RemoveFOVSetting(Priority);
    }
}

void ACameraManager::KAPI_Camera_SetCameraZLagSetting(int64 CameraModeID, float Param, int Priority)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->SetCameraZLagSetting(Param, Priority);
	}
}

void ACameraManager::KAPI_Camera_SetCameraZSoftRadiusSetting(int64 CameraModeID, float Param, int Priority)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->SetCameraZSoftRadiusSetting(Param, Priority);
	}
}

void ACameraManager::KAPI_Camera_SetCameraXOYLagSetting(int64 CameraModeID, float Param, int Priority)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->SetCameraXOYLagSetting(Param, Priority);
	}
}

void ACameraManager::KAPI_Camera_SetCameraXOYSoftRadiusSetting(int64 CameraModeID, float Param, int Priority)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->SetCameraXOYSoftRadiusSetting(Param, Priority);
	}
}

void ACameraManager::KAPI_Camera_RemoveCameraZLagSetting(int64 CameraModeID, int Priority)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->RemoveCameraZLagSetting(Priority);
	}
}

void ACameraManager::KAPI_Camera_RemoveCameraZSoftRadiusSetting(int64 CameraModeID, int Priority)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->RemoveCameraZSoftRadiusSetting(Priority);
	}
}

void ACameraManager::KAPI_Camera_RemoveCameraXOYLagSetting(int64 CameraModeID, int Priority)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->RemoveCameraXOYLagSetting(Priority);
	}
}

void ACameraManager::Kapi_Camera_RemoveCameraXoySoftRadiusSetting(int64 CameraModeID, int Priority)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->RemoveCameraXOYSoftRadiusSetting(Priority);
	}
}

void ACameraManager::KAPI_Camera_SetCameraLookAt(int64 CameraModeID, int64 TargetActorID, int64 ControlActorID,
                                                 const FName& NewBoneName, float NewBoneOffsetX, float NewBoneOffsetY,
                                                 float NewBoneOffsetZ,
                                                 ERelativeTransformSpace InTransformSpace)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->SetCameraLookAt(TargetActorID, ControlActorID, NewBoneName, NewBoneOffsetX, NewBoneOffsetY, NewBoneOffsetZ, InTransformSpace);
	}
}

void ACameraManager::KAPI_Camera_SetCameraLookAtWithStaticBoneOffsetZ(int64 CameraModeID, int64 TargetActorID,
	int64 ControlActorID, const FName& NewBoneName, float NewBoneOffsetX, float NewBoneOffsetY, float NewBoneOffsetZ,
	ERelativeTransformSpace InTransformSpace)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->SetCameraLookAtWithStaticBoneOffsetZ(TargetActorID, ControlActorID, NewBoneName, NewBoneOffsetX, NewBoneOffsetY, NewBoneOffsetZ, InTransformSpace);
	}
}

int64 ACameraManager::KAPI_Camera_GetCameraLookAt(int64 CameraModeID)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		return KGUtils::GetIDByObject(CameraMode->GetCameraLookAt());
	}

	return KG_INVALID_ID;
}

void ACameraManager::KAPI_Camera_SetCameraLookAtWithWorldLoc(int64 CameraModeID, int64 TargetID, int64 TargetActorID, const FVector& WorldLoc)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->SetCameraLookAtWithWorldLoc(TargetID, TargetActorID, WorldLoc);
	}
}

void ACameraManager::KAPI_Camera_SetCameraLookAtWithPivotLoc(int64 CameraModeID, int64 TargetID, int64 TargetActorID,
                                                             float PivotLocX, float PivotLocY, float PivotLocZ,
                                                             float CameraPitch, float CameraYaw, float CameraRoll,
                                                             float Zoom)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->SetCameraLookAtWithPivotLoc(TargetID, TargetActorID, {PivotLocX, PivotLocY, PivotLocZ}, {CameraPitch, CameraYaw, CameraRoll}, Zoom);
	}
}

void ACameraManager::KAPI_Camera_SetCameraScreenViewOffsetSetting(int64 CameraModeID, float X, float Y, int Priority)
{
	if (UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->SetPivotOffsetFromScreenCoOffsetSetting(X, Y, Priority);
	}
}

void ACameraManager::KAPI_Camera_RemoveCameraScreenViewOffsetSetting(int64 CameraModeID, int Priority)
{
	if (UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->RemovePivotOffsetFromScreenCoOffsetSetting(Priority);
	}
}

void ACameraManager::KAPI_Camera_GetCameraScreenViewOffsetSetting(int64 CameraModeID, float& OutX, float& OutY)
{
	if (UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		FVector2D Offset = CameraMode->GetPivotOffsetSetting();
		OutX = Offset.X;
		OutY = Offset.Y;
	}
}

void ACameraManager::KAPI_Camera_SetCameraAdaptiveScreenViewOffsetSettingWithZoom(int64 CameraModeID,
                                                                                  float ViewOffXWithZoomMax, float ViewOffXWithZoomMin, float ViewOffYWithZoomMax, float ViewOffYWithZoomMin,
                                                                                  float HalfLife)
{
	if (UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->SetAdaptiveViewOffsetWithZoom(ViewOffXWithZoomMax, ViewOffXWithZoomMin, ViewOffYWithZoomMax, ViewOffYWithZoomMin, HalfLife);
	}
}

void ACameraManager::KAPI_Camera_UpdateZoom(int64 CameraActorID, float TargetZoom, bool bAbsolute)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->GetCameraArmComponent()->OnUpdateZoom(TargetZoom, bAbsolute);
	}
}

int ACameraManager::KAPI_Camera_GetCameraTargetZoomLen(int64 CameraActorID)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		return Camera->GetCameraArmComponent()->GetTargetCameraZoomLen();
	}

	return 0;
}

void ACameraManager::KAPI_Camera_EnableCameraTick(int64 CameraActorID, bool bEnable)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->EnableCameraTick(bEnable);
	}
}

void ACameraManager::KAPI_Camera_EnableCameraModeTick(int64 CameraModeID, bool bEnable)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->bEnableTick = bEnable;
	}	
}

void ACameraManager::KAPI_Camera_EnableCameraNewCollision(int64 CameraActorID, bool bEnable, const TArray<int>& NewCollisionDetectTypes)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->GetCameraArmComponent()->EnableNewCollision(bEnable, NewCollisionDetectTypes);
	}
}

void ACameraManager::KAPI_Camera_EnableCameraCollision(int64 CameraActorID, bool bEnable)
{
	if(ABaseCamera* CameraMode = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		if (UCameraArmComponent* Arm = CameraMode->GetCameraArmComponent())
		{
			Arm->bDoCollisionTest = bEnable;
		}
	}	
}

void ACameraManager::KAPI_Camera_SetCameraRotSensitivity(int64 CameraModeID, float Yaw, float Pitch, int Priority)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->SetCameraRotSensitivity(Yaw, Pitch, Priority);
	}	
}

void ACameraManager::KAPI_Camera_RemoveCameraRotSensitivity(int64 CameraModeID, int Priority)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->RemoveCameraRotSensitivity(Priority);
	}	
}

float ACameraManager::KAPI_Camera_GetCameraRotYawSensitivity(int64 CameraModeID)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		return CameraMode->GetCameraRotYawSensitivity();
	}

	return 1;
}

float ACameraManager::KAPI_Camera_GetCameraRotPitchSensitivity(int64 CameraModeID)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		return CameraMode->GetCameraRotPitchSensitivity();
	}

	return 1;
}

FVector ACameraManager::KAPI_Camera_GetCameraRootLocation(int64 CameraActorID)
{
	if(ACameraActor* Camera = Cast<ACameraActor>(KGUtils::GetObjectByID(CameraActorID)))
	{
		return Camera->GetActorLocation();
	}

	return FVector::ZeroVector;
}

FRotator ACameraManager::KAPI_Camera_GetCameraRootRotation(int64 CameraActorID)
{
	if(ACameraActor* Camera = Cast<ACameraActor>(KGUtils::GetObjectByID(CameraActorID)))
	{
		return Camera->GetActorRotation();
	}

	return FRotator::ZeroRotator;
}

void ACameraManager::KAPI_Camera_SetCameraRootLocation(int64 CameraActorID, const FVector& NewLocation)
{
	if(ACameraActor* Camera = Cast<ACameraActor>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->SetActorLocation(NewLocation);
	}
}

void ACameraManager::KAPI_Camera_SetCameraRootRelativeLocation(int64 CameraActorID, float X, float Y, float Z)
{
	if(ACameraActor* Camera = Cast<ACameraActor>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->SetActorRelativeLocation({X, Y, Z});
	}
}

void ACameraManager::KAPI_Camera_SetCameraArmRelativeRotation(int64 CameraActorID, const FRotator& NewRelative)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->GetCameraArmComponent()->SetRelativeRotation(NewRelative);
	}
}

void ACameraManager::KAPI_Camera_SetCameraRootRotation(int64 CameraActorID, const FRotator& NewRotation)
{
	if(ACameraActor* Camera = Cast<ACameraActor>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->SetActorRotation(NewRotation);
	}
}

FVector ACameraManager::KAPI_Camera_GetCameraCachedArmOrigin(int64 CameraActorID)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		return Camera->GetCameraArmComponent()->GetCachedArmOrigin();
	}
	return FVector::ZeroVector;
}

void ACameraManager::KAPI_Camera_CopyTransformFromCamera(int64 CameraActorIDA, int64 CameraActorIDB)
{
	if(AActor* CameraA = Cast<AActor>(KGUtils::GetObjectByID(CameraActorIDA)))
	{
		if(ACameraActor* CameraB = Cast<ACameraActor>(KGUtils::GetObjectByID(CameraActorIDB)))
		{
			CameraA->SetActorTransform(CameraB->GetTransform());
		}
	}
}

void ACameraManager::KAPI_Camera_CopyTransformFromView(int64 CameraActorIDA)
{
	if(AActor* CameraA = Cast<AActor>(KGUtils::GetObjectByID(CameraActorIDA)))
	{
		const FMinimalViewInfo& POV = this->GetCameraCacheView();
		CameraA->SetActorTransform(FTransform(POV.Rotation, POV.Location));
	}
}

FVector ACameraManager::KAPI_Camera_GetCameraLocation(int64 CameraActorID)
{
	if(AActor* Actor = KGUtils::GetActorByID(CameraActorID))
	{
		if(UCameraComponent* CameraCom = Cast<UCameraComponent>(Actor->GetComponentByClass(UCameraComponent::StaticClass())))
		{
			return CameraCom->GetComponentLocation();
		}
	}

	return FVector::ZeroVector;
}

FRotator ACameraManager::KAPI_Camera_GetCameraRotation(int64 CameraActorID)
{
	if(AActor* Actor = KGUtils::GetActorByID(CameraActorID))
	{
		if(UCameraComponent* CameraCom = Cast<UCameraComponent>(Actor->GetComponentByClass(UCameraComponent::StaticClass())))
		{
			return CameraCom->GetComponentRotation();
		}
	}

	return FRotator::ZeroRotator;
}

void ACameraManager::KAPI_Camera_GetCameraActorRotationByAxis(int64 CameraActorID, float& Pitch, float& Yaw,
	float& Roll)
{
	if(AActor* Actor = KGUtils::GetActorByID(CameraActorID))
	{
		FRotator Rot = Actor->GetActorRotation();
		Pitch = Rot.Pitch;
		Yaw = Rot.Yaw;
		Roll = Rot.Roll;
	}
}

void ACameraManager::KAPI_Camera_SetCameraActorPitch(int64 CameraActorID, float Pitch)
{
	if(AActor* Actor = KGUtils::GetActorByID(CameraActorID))
	{
		FRotator Rot = Actor->GetActorRotation();
		Rot.Pitch = Pitch;
		Actor->SetActorRotation(Rot);
	}
}

void ACameraManager::KAPI_Camera_SetCameraActorRoll(int64 CameraActorID, float Roll)
{
	if(AActor* Actor = KGUtils::GetActorByID(CameraActorID))
	{
		FRotator Rot = Actor->GetActorRotation();
		Rot.Roll = Roll;
		Actor->SetActorRotation(Rot);
	}
}

void ACameraManager::KAPI_Camera_SetCameraActorYaw(int64 CameraActorID, float Yaw)
{
	if(AActor* Actor = KGUtils::GetActorByID(CameraActorID))
	{
		FRotator Rot = Actor->GetActorRotation();
		Rot.Yaw = Yaw;
		Actor->SetActorRotation(Rot);
	}
}

void ACameraManager::KAPI_Camera_AdjustTargetOffsetWhenLookAtMove(int64 CameraActorID, const FVector& LookAtNewPos)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		UCameraArmComponent* Arm = Camera->GetCameraArmComponent();
		FVector PreviousArmOrigin = Arm->GetCachedArmOrigin();
		FRotator CameraRot = Camera->GetCameraRotation();
		CameraRot.Pitch = 0.f;
		Camera->GetCameraArmComponent()->SetTargetOffset(FTransform(CameraRot).InverseTransformVector(PreviousArmOrigin - LookAtNewPos));
	}
}

void ACameraManager::KAPI_Camera_SetCameraTargetOffset(int64 CameraActorID, float X, float Y, float Z)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->GetCameraArmComponent()->SetTargetOffset({X, Y, Z});
	}
}
float ACameraManager::KAPI_Camera_GetCameraTargetOffsetZ(int64 CameraActorID)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		return Camera->GetCameraArmComponent()->GetTargetOffsetZ();
	}
	return 0;
}

float ACameraManager::KAPI_Camera_GetCameraTargetOffsetY(int64 CameraActorID)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		return Camera->GetCameraArmComponent()->GetTargetOffsetY();
	}
	return 0;
}

void ACameraManager::KAPI_Camera_AddCameraTargetOffsetZWithClamp(int64 CameraActorID, float ZDelta, float Min, float Max)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		UCameraArmComponent* Arm = Camera->GetCameraArmComponent();
		float OldZ = Arm->GetTargetOffsetZ();
		Arm->SetTargetOffsetZ(FMath::Clamp(OldZ + ZDelta, Min, Max));
	}
}

void ACameraManager::KAPI_Camera_AddCameraTargetOffsetYWithClamp(int64 CameraActorID, float YDelta, float Min,
                                                                 float Max)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		UCameraArmComponent* Arm = Camera->GetCameraArmComponent();
		float OldY = Arm->GetTargetOffsetY();
		Arm->SetTargetOffsetY(FMath::Clamp(OldY + YDelta, Min, Max));
	}
}


float ACameraManager::KAPI_Camera_GetCameraFOV(int64 CameraActorID)
{
	if (ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		return Camera->GetCameraFOV();
	}
	return 0.0f;
}

void ACameraManager::KAPI_Camera_SetOnlyUseBoneLocationZ(int64 CameraActorID, bool bEnable)
{
	if (ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		return Camera->SetOnlyUseBoneLocationZ(bEnable);
	}
}

void ACameraManager::KAPI_Camera_SetCameraSocketOffset(int64 CameraActorID, float X, float Y, float Z)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->GetCameraArmComponent()->SetSocketOffset(X, Y, Z);
	}
}

void ACameraManager::KAPI_Camera_SetCameraSocketRotOffset(int64 CameraActorID, float Pitch, float Yaw, float Roll)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->GetCameraArmComponent()->SetSocketRotOffset(Pitch, Yaw, Roll);
	}
}

void ACameraManager::KAPI_Camera_GetCameraSocketRotOffset(int64 CameraActorID, float& Pitch, float& Yaw, float& Roll)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		FRotator SocketRotOffset = Camera->GetCameraArmComponent()->GetSocketRotOffset();
		Pitch = SocketRotOffset.Pitch;
		Yaw = SocketRotOffset.Yaw;
		Roll = SocketRotOffset.Roll;
	}
}

void ACameraManager::KAPI_Camera_SetCameraSocketOffsetX(int64 CameraActorID, float X)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->GetCameraArmComponent()->SetSocketOffsetX(X);
	}
}

void ACameraManager::KAPI_Camera_SetCameraSocketOffsetY(int64 CameraActorID, float Y)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->GetCameraArmComponent()->SetSocketOffsetY(Y);
	}
}

void ACameraManager::KAPI_Camera_SetCameraSocketOffsetZ(int64 CameraActorID, float Z)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->GetCameraArmComponent()->SetSocketOffsetZ(Z);
	}
}

void ACameraManager::KAPI_Camera_GetCameraOriginWorldOffset(int64 CameraActorID, float& X, float& Y, float& Z)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		FVector OriginWorldOffset = Camera->GetCameraArmComponent()->OriginWorldOffset;
		X = OriginWorldOffset.X;
		Y = OriginWorldOffset.Y;
		Z = OriginWorldOffset.Z;
	}
}

void ACameraManager::KAPI_Camera_GetCameraSocketOffset(int64 CameraActorID, float& X, float& Y, float& Z)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		FVector SocketOffset = Camera->GetCameraArmComponent()->SocketOffset;
		X = SocketOffset.X;
		Y = SocketOffset.Y;
		Z = SocketOffset.Z;
	}
}

float ACameraManager::KAPI_Camera_GetCameraSocketOffsetZ(int64 CameraActorID)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		return Camera->GetCameraArmComponent()->GetSocketOffsetZ();
	}

	return 0;
}

void ACameraManager::KAPI_Camera_InitManualMove(int64 CameraActorID, bool bEnable, bool bLimitRot, float NewPitchMin,
                                                float NewPitchMax, float NewYawMin, float NewYawMax)
{
	if (ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->InitManualMove(bEnable, bLimitRot, NewPitchMin, NewPitchMax, NewYawMin, NewYawMax);
	}
}

void ACameraManager::KAPI_Camera_InitLimitRot(int64 CameraActorID, bool bLimitRot, float NewPitchMin, float NewPitchMax,
	float NewYawMin, float NewYawMax)
{
	if (ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->InitLimitRot(bLimitRot, NewPitchMin, NewPitchMax, NewYawMin, NewYawMax);
	}
}

void ACameraManager::KAPI_Camera_InitLimitPitchRot(int64 CameraActorID, bool bLimitRot, float NewPitchMin,
	float NewPitchMax)
{
	if (ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->InitLimitPitchRot(bLimitRot, NewPitchMin, NewPitchMax);
	}
}

void ACameraManager::KAPI_Camera_MoveX(int64 CameraActorID, float X, bool bLimitZone)
{
	if (ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->Move_X(X, bLimitZone);
	}
}

void ACameraManager::KAPI_Camera_MoveY(int64 CameraActorID, float Y, bool bLimitZone)
{
	if (ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->Move_Y(Y, bLimitZone);
	}
}

void ACameraManager::KAPI_Camera_MoveZ(int64 CameraActorID, float Z, bool bLimitZone)
{
	if (ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->Move_Z(Z, bLimitZone);
	}
}

void ACameraManager::KAPI_Camera_MoveZToXOY(int64 CameraActorID, float Z, bool bLimitZone)
{
	if (ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->Move_ZToXOY(Z, bLimitZone);
	}
}

void ACameraManager::KAPI_Camera_LookUp(int64 CameraActorID, float Value)
{
	if (ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->LookUp_Axis(Value);
	}
}

void ACameraManager::KAPI_Camera_Turn(int64 CameraActorID, float Value)
{
	if (ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->Turn_Axis(Value);
	}
}

void ACameraManager::KAPI_Camera_CopyFOVFromCamera(int64 CameraActorIDA, int64 CameraActorIDB)
{
	if (ACameraActor* CameraA = Cast<ACameraActor>(KGUtils::GetObjectByID(CameraActorIDA)))
	{
		if (ACameraActor* CameraB = Cast<ACameraActor>(KGUtils::GetObjectByID(CameraActorIDB)))
		{
			CameraA->GetCameraComponent()->SetFieldOfView(CameraB->GetCameraComponent()->FieldOfView);
		}
	}
}

void ACameraManager::KAPI_Camera_CopyPPFromCamera(int64 CameraActorIDA, int64 CameraActorIDB)
{
	if (ACameraActor* CameraA = Cast<ACameraActor>(KGUtils::GetObjectByID(CameraActorIDA)))
	{
		if (ACameraActor* CameraB = Cast<ACameraActor>(KGUtils::GetObjectByID(CameraActorIDB)))
		{
			CameraA->GetCameraComponent()->PostProcessSettings = CameraB->GetCameraComponent()->PostProcessSettings;
		}
	}
}

int ACameraManager::KAPI_Camera_GetFocusOnAdaptiveRotator(int64 CameraActorID, FRotator& Result,
                                                          const FVector& ActorLocation,
                                                          float InLeftX, float InRightX, float InUpY, float InDownY,
                                                          float InCheckInScreenError, float InMiddleLockHeight,
                                                          bool InbForceLockMiddle)
{
	if (ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		return UCameraActionFocusOnTarget::GetFocusOnAdaptiveRotator(Result, ActorLocation, PCOwner, Camera, InLeftX, InRightX, InUpY, InDownY, InCheckInScreenError, InMiddleLockHeight, InbForceLockMiddle);
	}

	return 0;
}

FPostProcessSettings ACameraManager::KAPI_Camera_GetPPSetting(int64 CameraActorID)
{
	if(ACameraActor* Camera = Cast<ACameraActor>(KGUtils::GetObjectByID(CameraActorID)))
	{
		return Camera->GetCameraComponent()->PostProcessSettings;
	}
	return FPostProcessSettings();
}

void ACameraManager::KAPI_Camera_AddCameraSocketOffset(int64 CameraActorID, float X, float Y, float Z)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->GetCameraArmComponent()->AddSocketOffset(X, Y, Z);
	}
}

void ACameraManager::KAPI_Camera_AddCameraOriginWorldOffset(int64 CameraActorID, float X, float Y, float Z)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		Camera->GetCameraArmComponent()->AddOriginWorldOffset(X, Y, Z);
	}
}

void ACameraManager::KAPI_Camera_AddCameraSocketOffsetXWithClamp(int64 CameraActorID, float X, float Min, float Max)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		auto* Arm = Camera->GetCameraArmComponent();
		FVector CurSocketOffset = Arm->GetSocketOffset();
		float RowX = CurSocketOffset.X;
		CurSocketOffset.X = FMath::Clamp(CurSocketOffset.X + X, Min, Max);
		Arm->AddSocketOffset(CurSocketOffset.X - RowX, 0, 0);
	}
}

void ACameraManager::KAPI_Camera_AddCameraSocketOffsetYWithClamp(int64 CameraActorID, float Y, float Min, float Max)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		auto* Arm = Camera->GetCameraArmComponent();
		FVector CurSocketOffset = Arm->GetSocketOffset();
		float RowY = CurSocketOffset.Y;
		CurSocketOffset.Y = FMath::Clamp(CurSocketOffset.Y + Y, Min, Max);
		Arm->AddSocketOffset(0, CurSocketOffset.Y - RowY, 0);
	}
}

void ACameraManager::KAPI_Camera_AddCameraSocketOffsetZWithClamp(int64 CameraActorID, float Z, float Min, float Max)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		auto* Arm = Camera->GetCameraArmComponent();
		FVector CurSocketOffset = Arm->GetSocketOffset();
		float RowZ = CurSocketOffset.Z;
		CurSocketOffset.Z = FMath::Clamp(CurSocketOffset.Z + Z, Min, Max);
		Arm->AddSocketOffset(0, 0, CurSocketOffset.Z - RowZ);
	}
}

void ACameraManager::KAPI_CineCamera_SetActorTrackFocusSetting(int64 CameraActorID, int64 TrackActorID,
                                                               const FVector& Offset)
{
	if(AActor* Camera = Cast<AActor>(KGUtils::GetObjectByID(CameraActorID)))
	{
		if (UCineCameraComponent* CineCamera = Camera->GetComponentByClass<UCineCameraComponent>())
		{
			FCameraFocusSettings RowSetting = CineCamera->FocusSettings;
			RowSetting.FocusMethod = ECameraFocusMethod::Tracking;
			RowSetting.TrackingFocusSettings.ActorToTrack = KGUtils::GetActorByID(TrackActorID);
			RowSetting.TrackingFocusSettings.RelativeOffset = Offset;
			CineCamera->SetFocusSettings(RowSetting);
		}
	}
}

void ACameraManager::KAPI_CineCamera_SetManualFocusSetting(int64 CameraActorID, float ManualFocusDistance)
{
	if(AActor* Camera = Cast<AActor>(KGUtils::GetObjectByID(CameraActorID)))
	{
		if (UCineCameraComponent* CineCamera = Camera->GetComponentByClass<UCineCameraComponent>())
		{
			FCameraFocusSettings RowSetting = CineCamera->FocusSettings;
			RowSetting.FocusMethod = ECameraFocusMethod::Manual;
			RowSetting.ManualFocusDistance = ManualFocusDistance;
			CineCamera->SetFocusSettings(RowSetting);
		}
	}
}

void ACameraManager::KAPI_CineCamera_SetFocusLengthSetting(int64 CameraActorID, float FocusLength)
{
	if(ABaseCineCamera* Camera = Cast<ABaseCineCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		UCineCameraComponent* CineCamera = Camera->GetCineCameraComponent();
		CineCamera->SetCurrentFocalLength(FocusLength);
	}
}

float ACameraManager::KAPI_CineCamera_GetCameraFocalLength(int64 CameraActorID)
{
	if (ABaseCineCamera* Camera = Cast<ABaseCineCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		return Camera->GetCineCameraComponent()->CurrentFocalLength;
	}
	return 0;
}

void ACameraManager::KAPI_CineCamera_SetApertureSetting(int64 CameraActorID, float Aperture)
{
	if(ABaseCineCamera* Camera = Cast<ABaseCineCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		UCineCameraComponent* CineCamera = Camera->GetCineCameraComponent();
		CineCamera->SetCurrentAperture(Aperture);
	}
}

FRotator ACameraManager::KAPI_Camera_GetAppropriateRotationForInteractive(int64 ActorAID, int64 ActorBID,
	int64 ActorCID)
{
	AActor* A = KGUtils::GetActorByID(ActorAID);
	if(A == nullptr)
	{
		return FRotator::ZeroRotator;
	}
	AActor* B = KGUtils::GetActorByID(ActorBID);
	if(B == nullptr)
	{
		return FRotator::ZeroRotator;
	}
	AActor* C = KGUtils::GetActorByID(ActorCID);
	if(C == nullptr)
	{
		return FRotator::ZeroRotator;
	}

	FVector AToB = B->GetActorLocation() - A->GetActorLocation();
	FVector AToC = C->GetActorLocation() - A->GetActorLocation();
	if(AToB.SquaredLength() < AToC.SquaredLength())
	{
		return AToB.GetSafeNormal().Rotation();
	}
	return AToC.GetSafeNormal().Rotation();
	
}

FTransform ACameraManager::KAPI_Camera_GetCorrectInteractiveCameraRotAndZoom(int64 OriginActorID,
                                                                             int64 DestinationActorID,
                                                                             const FRotator& CurrentDir,
                                                                             float DesiredPitch,
                                                                             float DesiredYawToOrigin,
                                                                             float DesiredYawToDestination,
                                                                             float DesiredZoom, float MinZoom,
                                                                             bool bCoaxial)
{
	AActor* A = KGUtils::GetActorByID(OriginActorID);
	AActor* B = KGUtils::GetActorByID(DestinationActorID);

	if(A == nullptr && B == nullptr)
	{
		return FTransform(CurrentDir, FVector::ZeroVector);
	}
	if(A == nullptr)
	{
		return FTransform(CurrentDir, B->GetActorLocation());
	}
	if(B == nullptr)
	{
		return FTransform(CurrentDir, A->GetActorLocation());
	}

	const FVector PosA = A->GetActorLocation();
    const FVector PosB = B->GetActorLocation();
	const FVector Dir = (PosB - PosA).GetSafeNormal();
	const FVector StartPos = (PosB + PosA) / 2;
	FRotator Result = CurrentDir;

	float InitYaw = FRotator::ClampAxis(CurrentDir.Yaw);
	float DirYaw = FRotator::ClampAxis(Dir.ToOrientationRotator().Yaw);
	float InitYawDiff = MathFormula::ClosetYawSignedDiff(InitYaw, DirYaw);
	float CandidateYawA, CandidateYawB, CandidateYawC, CandidateYawD;
	if(bCoaxial)
	{
		if(InitYawDiff < 0)
		{
			if(InitYawDiff < -90)
			{
				CandidateYawA = FRotator::ClampAxis(DirYaw - DesiredYawToDestination + 180);
				CandidateYawB = FRotator::ClampAxis(DirYaw + DesiredYawToOrigin);
				CandidateYawC = FRotator::ClampAxis(DirYaw + DesiredYawToDestination + 180);
				CandidateYawD = FRotator::ClampAxis(DirYaw - DesiredYawToOrigin);
			}
			else
			{
				CandidateYawA = FRotator::ClampAxis(DirYaw + DesiredYawToOrigin);
				CandidateYawB = FRotator::ClampAxis(DirYaw - DesiredYawToDestination + 180);
				CandidateYawC = FRotator::ClampAxis(DirYaw - DesiredYawToOrigin);
				CandidateYawD = FRotator::ClampAxis(DirYaw + DesiredYawToDestination + 180);
			}
		}
		else
		{
			if(InitYawDiff > 90)
			{
				CandidateYawA = FRotator::ClampAxis(DirYaw + DesiredYawToDestination + 180);
				CandidateYawB = FRotator::ClampAxis(DirYaw - DesiredYawToOrigin);
				CandidateYawC = FRotator::ClampAxis(DirYaw - DesiredYawToDestination + 180);
				CandidateYawD = FRotator::ClampAxis(DirYaw + DesiredYawToOrigin);
			}
			else
			{
				CandidateYawA = FRotator::ClampAxis(DirYaw - DesiredYawToOrigin);
				CandidateYawB = FRotator::ClampAxis(DirYaw + DesiredYawToDestination + 180);
				CandidateYawC = FRotator::ClampAxis(DirYaw + DesiredYawToOrigin);
				CandidateYawD = FRotator::ClampAxis(DirYaw - DesiredYawToDestination + 180);
			}
		}
	}
	else
	{
		if(InitYawDiff < 0)
		{
			if(InitYawDiff < -90)
			{
				CandidateYawA = FRotator::ClampAxis(DirYaw - DesiredYawToDestination + 180);
				CandidateYawB = FRotator::ClampAxis(DirYaw + DesiredYawToDestination + 180);
				CandidateYawC = FRotator::ClampAxis(DirYaw + DesiredYawToOrigin);
				CandidateYawD = FRotator::ClampAxis(DirYaw - DesiredYawToOrigin);
			}
			else
			{
				CandidateYawA = FRotator::ClampAxis(DirYaw + DesiredYawToOrigin);
				CandidateYawB = FRotator::ClampAxis(DirYaw - DesiredYawToOrigin);
				CandidateYawC = FRotator::ClampAxis(DirYaw - DesiredYawToDestination + 180);
				CandidateYawD = FRotator::ClampAxis(DirYaw + DesiredYawToDestination + 180);
			}
		}
		else
		{
			if(InitYawDiff > 90)
			{
				CandidateYawA = FRotator::ClampAxis(DirYaw + DesiredYawToDestination + 180);
				CandidateYawB = FRotator::ClampAxis(DirYaw - DesiredYawToDestination + 180);
				CandidateYawC = FRotator::ClampAxis(DirYaw - DesiredYawToOrigin);
				CandidateYawD = FRotator::ClampAxis(DirYaw + DesiredYawToOrigin);
			}
			else
			{
				CandidateYawA = FRotator::ClampAxis(DirYaw - DesiredYawToOrigin);
				CandidateYawB = FRotator::ClampAxis(DirYaw + DesiredYawToOrigin);
				CandidateYawC = FRotator::ClampAxis(DirYaw + DesiredYawToDestination + 180);
				CandidateYawD = FRotator::ClampAxis(DirYaw - DesiredYawToDestination + 180);
			}
		}
	}

	Result.Pitch = DesiredPitch;
	Result.Yaw = CandidateYawA;
	
	FCollisionQueryParams QueryParams(SCENE_QUERY_STAT(CameraArm), false);
	FHitResult HitResults;
	if(GetWorld()->SweepSingleByChannel(HitResults, StartPos, StartPos - DesiredZoom * Result.Vector(), FQuat::Identity, ECollisionChannel::ECC_Camera, FCollisionShape::MakeSphere(12), QueryParams))
	{
		if((HitResults.Location - StartPos).Size() > MinZoom)
		{
			return FTransform(Result, StartPos);
		}
	}
	else
	{
		return FTransform(Result, StartPos);
	}

	Result.Yaw = CandidateYawB;
	if(GetWorld()->SweepSingleByChannel(HitResults, StartPos, StartPos - DesiredZoom * Result.Vector(), FQuat::Identity, ECollisionChannel::ECC_Camera, FCollisionShape::MakeSphere(12), QueryParams))
	{
		if((HitResults.Location - StartPos).Size() > MinZoom)
		{
			return FTransform(Result, StartPos);
		}
	}
	else
	{
		return FTransform(Result, StartPos);
	}

	Result.Yaw = CandidateYawC;
	if(GetWorld()->SweepSingleByChannel(HitResults, StartPos, StartPos - DesiredZoom * Result.Vector(), FQuat::Identity, ECollisionChannel::ECC_Camera, FCollisionShape::MakeSphere(12), QueryParams))
	{
		if((HitResults.Location - StartPos).Size() > MinZoom)
		{
			return FTransform(Result, StartPos);
		}
	}
	else
	{
		return FTransform(Result, StartPos);
	}

	Result.Yaw = CandidateYawD;
	if(GetWorld()->SweepSingleByChannel(HitResults, StartPos, StartPos - DesiredZoom * Result.Vector(), FQuat::Identity, ECollisionChannel::ECC_Camera, FCollisionShape::MakeSphere(12), QueryParams))
	{
		if((HitResults.Location - StartPos).Size() > MinZoom)
		{
			return FTransform(Result, StartPos);
		}
	}
	else
	{
		return FTransform(Result, StartPos);
	}

	Result.Yaw = CandidateYawA;
	FVector ResultDir = Result.Vector();
	if(!GetWorld()->SweepSingleByChannel(HitResults, StartPos - DesiredZoom * ResultDir, StartPos - DesiredZoom * ResultDir, FQuat::Identity, ECollisionChannel::ECC_Camera, FCollisionShape::MakeSphere(12), QueryParams))
	{
		return FTransform(Result, StartPos);
	}

	Result.Yaw = CandidateYawB;
	ResultDir = Result.Vector();
	if(!GetWorld()->SweepSingleByChannel(HitResults, StartPos - DesiredZoom * ResultDir, StartPos - DesiredZoom * ResultDir, FQuat::Identity, ECollisionChannel::ECC_Camera, FCollisionShape::MakeSphere(12), QueryParams))
	{
		return FTransform(Result, StartPos);
	}

	Result.Yaw = CandidateYawC;
	ResultDir = Result.Vector();
	if(!GetWorld()->SweepSingleByChannel(HitResults, StartPos - DesiredZoom * ResultDir, StartPos - DesiredZoom * ResultDir, FQuat::Identity, ECollisionChannel::ECC_Camera, FCollisionShape::MakeSphere(12), QueryParams))
	{
		return FTransform(Result, StartPos);
	}

	Result.Yaw = CandidateYawD;
	ResultDir = Result.Vector();
	if(!GetWorld()->SweepSingleByChannel(HitResults, StartPos - DesiredZoom * ResultDir, StartPos - DesiredZoom * ResultDir, FQuat::Identity, ECollisionChannel::ECC_Camera, FCollisionShape::MakeSphere(12), QueryParams))
	{
		return FTransform(Result, StartPos);
	}

	Result.Yaw = CandidateYawA;
	return FTransform(Result, StartPos);
}

FTransform ACameraManager::KAPI_Camera_GetCorrectInteractiveCameraRotAndZoomForDualCamera(int64 OriginActorID,
	int64 DestinationActorID, const FRotator& CurrentDir, float DesiredPitch, float DesiredYawToOrigin,
	float DesiredZoom, float MinZoom)
{
	AActor* A = KGUtils::GetActorByID(OriginActorID);
	AActor* B = KGUtils::GetActorByID(DestinationActorID);

	if(A == nullptr && B == nullptr)
	{
		return FTransform(CurrentDir, FVector::ZeroVector);
	}
	if(A == nullptr)
	{
		return FTransform(CurrentDir, B->GetActorLocation());
	}
	if(B == nullptr)
	{
		return FTransform(CurrentDir, A->GetActorLocation());
	}

	const FVector PosA = A->GetActorLocation();
    const FVector PosB = B->GetActorLocation();
	const FVector Dir = (PosB - PosA).GetSafeNormal();
	const FVector StartPos = (PosB + PosA) / 2;
	FRotator Result = CurrentDir;

	float InitYaw = FRotator::ClampAxis(CurrentDir.Yaw);
	float DirYaw = FRotator::ClampAxis(Dir.ToOrientationRotator().Yaw);
	float InitYawDiff = MathFormula::ClosetYawSignedDiff(InitYaw, DirYaw);
	float CandidateYawA, CandidateYawB;
		
	if(InitYawDiff < 0)
	{
		CandidateYawA = FRotator::ClampAxis(DirYaw + DesiredYawToOrigin);
		CandidateYawB = FRotator::ClampAxis(DirYaw - DesiredYawToOrigin);
	}
	else
	{
		CandidateYawA = FRotator::ClampAxis(DirYaw - DesiredYawToOrigin);
		CandidateYawB = FRotator::ClampAxis(DirYaw + DesiredYawToOrigin);
	}

	Result.Pitch = DesiredPitch;
	Result.Yaw = CandidateYawA;
	
	FCollisionQueryParams QueryParams(SCENE_QUERY_STAT(CameraArm), false);
	FHitResult HitResults;
	if(GetWorld()->SweepSingleByChannel(HitResults, StartPos, StartPos - DesiredZoom * Result.Vector(), FQuat::Identity, ECollisionChannel::ECC_Camera, FCollisionShape::MakeSphere(12), QueryParams))
	{
		if((HitResults.Location - StartPos).Size() > MinZoom)
		{
			return FTransform(Result, StartPos);
		}
	}
	else
	{
		return FTransform(Result, StartPos);
	}

	Result.Yaw = CandidateYawB;
	if(GetWorld()->SweepSingleByChannel(HitResults, StartPos, StartPos - DesiredZoom * Result.Vector(), FQuat::Identity, ECollisionChannel::ECC_Camera, FCollisionShape::MakeSphere(12), QueryParams))
	{
		if((HitResults.Location - StartPos).Size() > MinZoom)
		{
			return FTransform(Result, StartPos);
		}
	}
	else
	{
		return FTransform(Result, StartPos);
	}

	Result.Yaw = CandidateYawA;
	FVector ResultDir = Result.Vector();
	if(!GetWorld()->SweepSingleByChannel(HitResults, StartPos - DesiredZoom * ResultDir, StartPos - DesiredZoom * ResultDir, FQuat::Identity, ECollisionChannel::ECC_Camera, FCollisionShape::MakeSphere(12), QueryParams))
	{
		return FTransform(Result, StartPos);
	}

	Result.Yaw = CandidateYawB;
	ResultDir = Result.Vector();
	if(!GetWorld()->SweepSingleByChannel(HitResults, StartPos - DesiredZoom * ResultDir, StartPos - DesiredZoom * ResultDir, FQuat::Identity, ECollisionChannel::ECC_Camera, FCollisionShape::MakeSphere(12), QueryParams))
	{
		return FTransform(Result, StartPos);
	}
	
	Result.Yaw = CandidateYawA;
	return FTransform(Result, StartPos);
}

void ACameraManager::KAPI_Camera_UpdateZoomWithPivotAdsorption(int64 CameraModeID, float TargetZoom)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->UpdateZoomWithPivotAdsorption(TargetZoom);
	}
}

void ACameraManager::KAPI_Camera_AddSocketOffZWithPivotAdsorption(int64 CameraModeID, float Value, float UpThreshold,
	float DownThreshold)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		if(UCameraComponent* Camera = CameraMode->GetCameraComponent())
		{
			if(UCameraArmComponent* Arm = CameraMode->GetCameraArmComponent())
			{
				if(PCOwner != nullptr)
				{
					float CurrentOffsetZ = Arm->GetSocketOffsetZ();
					if(CurrentOffsetZ <= DownThreshold && Value <= 0) return;
					if(CurrentOffsetZ >= UpThreshold && Value >= 0) return;

					float HFOV = Camera->FieldOfView;
					int ScreenX, ScreenY;
					PCOwner->GetViewportSize(ScreenX, ScreenY);
					Value *= 9.f / 8.f * FMath::Tan(FMath::DegreesToRadians(HFOV / 2.f)) * Arm->GetRealCameraArmLen() / (ScreenY * 1.f);

					if(CurrentOffsetZ <= UpThreshold && Value + CurrentOffsetZ >= UpThreshold)
					{
						Value = UpThreshold - CurrentOffsetZ;
					}
					else if(CurrentOffsetZ >= DownThreshold && Value + CurrentOffsetZ <= DownThreshold)
					{
						Value = DownThreshold - CurrentOffsetZ;
					}
					UE_LOG(LogTemp, Log, TEXT("Camera Socket CurrentOffsetZ:%f DownThreshold:%f Value:%f"), CurrentOffsetZ, DownThreshold, Value);
				
					CameraMode->AddSocketOffZWithPivotAdsorption(Value);
				}
			}
		}
	}
}

void ACameraManager::KAPI_Camera_SetZoomWithAdsorption(int64 CameraModeID, float InAdsorptionSpeedX, float InAdsorptionSpeedXY, float InMaxX, float InMaxY, float InMaxYNeg, int EaseType, float AdsorptionMinZoom, float AdsorptionMaxZoom)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->SetZoomWithAdsorption(InAdsorptionSpeedX, InAdsorptionSpeedXY, InMaxX, InMaxY, InMaxYNeg, EaseType, AdsorptionMinZoom, AdsorptionMaxZoom);
	}
}

void ACameraManager::KAPI_Camera_CancelZoomAdsorption(int64 CameraModeID)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->CancelZoomAdsorption();
	}
}

void ACameraManager::KAPI_Camera_GetAdsorptionUpAndDownThreshold(int64 CameraModeID, float Height, float& DownThreshold,
	float& UpThreshold)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->GetAdsorptionUpAndDownThreshold(Height, DownThreshold, UpThreshold);
	}
}

void ACameraManager::KAPI_Camera_SetCustomRotAndOffWithRecover(int64 CameraModeID, float DesiredPitch, float DesiredYaw,
                                                               float DesiredRoll, float X, float Y, float Z,
                                                               float BasePitch, float BaseYaw, float BaseRoll,
                                                               ECameraEaseFunction::Type InRecoverEaseType)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->SetCustomRotAndOffWithRecover(DesiredPitch, DesiredYaw, DesiredRoll, X, Y, Z, BasePitch, BaseYaw, BaseRoll, InRecoverEaseType);
	}
}

void ACameraManager::KAPI_Camera_CancelCustomRotAndOffWithRecover(int64 CameraModeID)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->CancelCustomRotAndOffWithRecover();
	}
}

FRotator ACameraManager::KAPI_Camera_CalcOrientFromPosToPos(float StartX, float StartY, float StartZ, float EndX,
                                                            float EndY, float EndZ)
{
	FVector Dir = {EndX - StartX, EndY - StartY, EndZ - StartZ};
	return FRotationMatrix::MakeFromX(Dir).Rotator();
}

void ACameraManager::KAPI_Camera_EnableCameraDitherFade(int Reason, bool bEnable)
{
	UE_LOG(LogTemp, Log, TEXT("[Camera:KAPI_Camera_EnableCameraDitherFade] Reason:%d bEnable:%d"), FMath::CountTrailingZeros(static_cast<uint32>(Reason)), bEnable);
	if(bEnable)
	{
		CameraDitherFadeSwitcher &= ~Reason;
		if(CameraDitherFadeSwitcher == 0)
		{
			if(CameraForGaming != nullptr)
			{
				CameraForGaming->GetCameraArmComponent()->EnableGlobalDitherFade(true);
			}
		}
	}
	else
	{
		CameraDitherFadeSwitcher |= Reason;
		if(CameraForGaming != nullptr)
		{
			CameraForGaming->GetCameraArmComponent()->EnableGlobalDitherFade(false);
		}
	}
}

void ACameraManager::KAPI_Camera_SetCineCameraDitherFade(int64 CameraActorID, bool bEnable)
{
	if (AActor* Actor = KGUtils::GetActorByID(CameraActorID))
	{
        if(UBaseCineCameraComponent* CameraCom = Cast<UBaseCineCameraComponent>(Actor->GetComponentByClass(UCameraComponent::StaticClass())))
        {
        	CameraCom->bDitherFadeDetect = bEnable;
        	if (!bEnable) CameraCom->ClearDitherFade();
        }
	}
}

void ACameraManager::KAPI_Camera_StartManualCameraFade(float Duration, int64 FadeCurveID, float R, float G, float B, float A)
{
	if(UCurveFloat* FadeCurve = Cast<UCurveFloat>(KGUtils::GetObjectByID(FadeCurveID)))
	{
		CurveForFade = FadeCurve;

		bEnableFading = true;

		bEnableFading = true;

		FadeColor = FLinearColor(R, G, B, A);
		FadeTime = Duration;
		FadeTimeRemaining = Duration;
		bFadeAudio = false;
		bAutoAnimateFade = true;
		bHoldFadeWhenFinished = false;
	}
}

void ACameraManager::KAPI_Camera_SetWaterHeightCorrectParams(int64 CameraActorID, bool bEnableWaterDetect,
	float InWaterHeightCorrect)
{
	if(ABaseCamera* Camera = Cast<ABaseCamera>(KGUtils::GetObjectByID(CameraActorID)))
	{
		if (auto* Arm = Camera->GetCameraArmComponent())
		{
			Arm->bWaterCollision = bEnableWaterDetect;
			Arm->WaterHeightCorrect = InWaterHeightCorrect;
		}
	}
}

void ACameraManager::KAPI_Camera_SetCameraCustomRoleInitParams(int64 CameraModeID, int64 LookAtTargetID,
	const FName& LookAtBone, float LookAtScreenX, float LookAtScreenY, const FName& CloseUpBone, float CloseUpScreenX,
	float CloseUpScreenY, float HalfLife, float MaxZoom, float MinZoom, float ThresholdZoom, float InitZoom,
	float LookAtYaw, float CloseUpYaw, float InitPitch, float InitRoll, float PitchMin, float PitchMaxCloseUp,
	float PitchMaxThreshold, float YawMin, float YawMax)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->SetCustomRoleLookAtBone(LookAtTargetID, LookAtBone, LookAtScreenX, LookAtScreenY, CloseUpBone, CloseUpScreenX, CloseUpScreenY, HalfLife, MaxZoom, MinZoom, ThresholdZoom, InitZoom, LookAtYaw, CloseUpYaw, InitPitch, InitRoll, PitchMin, PitchMaxCloseUp, PitchMaxThreshold, YawMin, YawMax);
	}
}

void ACameraManager::KAPI_Camera_RemoveLookAtBoneRemainOffset(int64 CameraModeID)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->RemoveLookAtBoneRemainOffset();
	}
}

void ACameraManager::KAPI_Camera_RecoverCameraLookAt(int64 CameraModeID)
{
	if(UKgCameraMode* CameraMode = Cast<UKgCameraMode>(KGUtils::GetObjectByID(CameraModeID)))
	{
		CameraMode->RecoverLookAt();
	}
}

#pragma endregion CameraBase

#pragma region Modifier

int64 ACameraManager::KAPI_Camera_AddNewCameraModifier(TSubclassOf<UCameraModifier> ModifierClass)
{
	UCameraModifier* Result = AddNewCameraModifier(ModifierClass);
	return KGUtils::GetIDByObject(Result);
}

void ACameraManager::KAPI_Camera_RemoveCameraModifier(int64 ModifierID)
{
	if(UCameraModifier* Modifier = Cast<UCameraModifier>(KGUtils::GetObjectByID(ModifierID)))
	{
		RemoveCameraModifier(Modifier);
	}
}

void ACameraManager::KAPI_Camera_EnableModifier(int64 ModifierID)
{
	if(UCameraModifier* Modifier = Cast<UCameraModifier>(KGUtils::GetObjectByID(ModifierID)))
	{
		Modifier->EnableModifier();
	}
}

void ACameraManager::KAPI_Camera_DisableModifier(int64 ModifierID, bool bImmediate)
{
	if(UCameraModifier* Modifier = Cast<UCameraModifier>(KGUtils::GetObjectByID(ModifierID)))
	{
		Modifier->DisableModifier(bImmediate);
	}
}

void ACameraManager::KAPI_Camera_CameraEffect_DisableModifier(int64 ModifierID, bool bImmediate)
{
	if(UCameraEffect* Modifier = Cast<UCameraEffect>(KGUtils::GetObjectByID(ModifierID)))
	{
		Modifier->DisableModifier(bImmediate);
	}
}

void ACameraManager::KAPI_Camera_CameraEffect_SetAlphaOutTime(int64 ModifierID, float OutTime)
{
	if(UCameraEffect* Modifier = Cast<UCameraEffect>(KGUtils::GetObjectByID(ModifierID)))
	{
		Modifier->SetAlphaOutTime(OutTime);
	}
}

void ACameraManager::KAPI_Camera_CameraEffect_SetAlphaInTime(int64 ModifierID, float InTime)
{
	if(UCameraEffect* Modifier = Cast<UCameraEffect>(KGUtils::GetObjectByID(ModifierID)))
	{
		Modifier->SetAlphaInTime(InTime);
	}
}

void ACameraManager::KAPI_Camera_CameraEffect_SetAutoRemoveFromList(int64 ModifierID, bool bNeedRemove)
{
	if(UCameraEffect* Modifier = Cast<UCameraEffect>(KGUtils::GetObjectByID(ModifierID)))
	{
		Modifier->SetAutoRemoveFromList(bNeedRemove);
	}
}

void ACameraManager::KAPI_Camera_PPMaterial_SetBlendableWeight(int64 ModifierID, float Weight)
{
	if(UCEPPMaterial* Modifier = Cast<UCEPPMaterial>(KGUtils::GetObjectByID(ModifierID)))
	{
		Modifier->Blendable.Weight = Weight;
	}
}

void ACameraManager::KAPI_Camera_PPMaterial_SetBlendableObject(int64 ModifierID, UObject* NewObject)
{
	if(UCEPPMaterial* Modifier = Cast<UCEPPMaterial>(KGUtils::GetObjectByID(ModifierID)))
	{
		Modifier->Blendable.Object = NewObject;
	}
}

int ACameraManager::KAPI_Camera_CameraAnimation_PlayCameraAnimationAtLocation(const TArray<int>& EffectCameraTags,
	int64 GUID, int64 SequenceID, float PlayRate, bool bLoop, float Duration, float EaseInDuration,
	ECameraEaseFunction::Type EaseInType, float EaseOutDuration, ECameraEaseFunction::Type EaseOutType,
	const FRotator& UserPlaySpaceRot, const FVector& UserPlaySpaceLoc, int64 UserSpacePlayer, int CollisionCheckCount,
	bool bUseTargetScale, bool bUseMeshSpace, bool bLockOutgoing, bool bInAdaptiveCameraRot, bool bCustomPitch,
	double CustomPitch)
{
	// UCameraAnimationSequenceSubsystem 不支持 Preview Editor World 
	if(GetWorld()->WorldType == EWorldType::EditorPreview)
	{
		return 0;
	}
	if(CameraActionHandler != nullptr)
	{
		if (UKGCameraAnimationCameraModifier* Modifier = CameraActionHandler->GetCameraAnimationModifier())
		{
			FCameraAnimationParams Param;
			{
				Param.PlayRate = PlayRate;
				Param.PlaySpace = ECameraAnimationPlaySpace::UserDefined;
				Param.UserPlaySpaceRot = UserPlaySpaceRot;
				Param.bLoop = bLoop;
			}
			Modifier->SetEffectModeTags(EffectCameraTags, ActivateCameraModeTag);
			return Modifier->PlayCameraAnimationAtLocation(GUID, SequenceID, Duration, EaseInDuration, EaseInType, EaseOutDuration, EaseOutType, Param, CollisionCheckCount, UserPlaySpaceLoc, UserSpacePlayer, bUseTargetScale, bUseMeshSpace, bLockOutgoing, bInAdaptiveCameraRot, bCustomPitch, CustomPitch);
		}
	}

	return 0;
}

void ACameraManager::KAPI_Camera_CameraAnimation_SetPause(int CameraAnimHandleHash, bool bPause)
{
	if(CameraActionHandler != nullptr)
	{
		if (UKGCameraAnimationCameraModifier* Modifier = CameraActionHandler->GetCameraAnimationModifier())
		{
			Modifier->Pause(CameraAnimHandleHash, bPause);
		}
	}
}

void ACameraManager::KAPI_Camera_CameraAnimation_SetPlayRate(int CameraAnimHandleHash, float NewPlayRate)
{
	if(CameraActionHandler != nullptr)
	{
		if (UKGCameraAnimationCameraModifier* Modifier = CameraActionHandler->GetCameraAnimationModifier())
		{
			Modifier->SetPlayRate(CameraAnimHandleHash, NewPlayRate);
		}
	}
}

void ACameraManager::KAPI_Camera_CameraAnimation_SetPlayAt(int CameraAnimHandleHash, float NewPct)
{
	if(CameraActionHandler != nullptr)
	{
		if (UKGCameraAnimationCameraModifier* Modifier = CameraActionHandler->GetCameraAnimationModifier())
		{
			Modifier->SetAnimationPlayAt(CameraAnimHandleHash, NewPct);
		}
	}
}

void ACameraManager::KAPI_Camera_CameraAnimation_SetLoop(int CameraAnimHandleHash, bool bLoop)
{
	if(CameraActionHandler != nullptr)
	{
		if (UKGCameraAnimationCameraModifier* Modifier = CameraActionHandler->GetCameraAnimationModifier())
		{
			Modifier->SetLoop(CameraAnimHandleHash, bLoop);
		}
	}
}

void ACameraManager::KAPI_Camera_CameraAnimation_StopCameraAnimation(int CameraAnimHandleHash, bool bImmediate)
{
	if(CameraActionHandler != nullptr)
	{
		if (UKGCameraAnimationCameraModifier* Modifier = CameraActionHandler->GetCameraAnimationModifier())
		{
			Modifier->StopKGCameraAnimation(CameraAnimHandleHash, bImmediate);
		}
	}
}

double ACameraManager::KAPI_Camera_GetCameraAnimationLength(int64 CameraAnimationID)
{
	if(UCameraAnimationSequence* CameraAnim = Cast<UCameraAnimationSequence>(KGUtils::GetObjectByID(CameraAnimationID)))
	{
		return CameraAnim->GetMovieScene()->GetTickResolution().AsSeconds(CameraAnim->GetMovieScene()->GetPlaybackRange().Size<FFrameNumber>());
	}
	return -1.f;
}

int64 ACameraManager::KCB_Camera_StartCameraAIMove(const TArray<FVector>& WorldLocations,
	const TArray<FRotator>& WorldRotations, int SampleRate, float BlendInTime, float BlendOutTime, float PlayRate)
{
	if(CameraActionHandler != nullptr)
	{
		return CameraActionHandler->KAPI_Camera_StartCameraAIMove(WorldLocations, WorldRotations, SampleRate, BlendInTime, BlendOutTime, PlayRate);
	}
	return KG_INVALID_ID;
}

int64 ACameraManager::KCB_Camera_StartCameraAIMoveWithPivot(const TArray<FVector>& WorldLocations,
	const TArray<FRotator>& WorldRotations, const TArray<FVector>& PivotLocations, int SampleRate, float BlendInTime,
	float BlendOutTime, float PlayRate)
{
	if(CameraActionHandler != nullptr)
	{
		return CameraActionHandler->KAPI_Camera_StartCameraAIMoveWithPivot(WorldLocations, WorldRotations, PivotLocations, SampleRate, BlendInTime, BlendOutTime, PlayRate);
	}
	return KG_INVALID_ID;
}

#pragma endregion Modifier

#pragma region Utils

int64 ACameraManager::KAPI_Camera_GetCameraManagerActorID()
{
	return KGUtils::GetIDByObject(this);
}

int64 ACameraManager::KAPI_Camera_GetCameraManagerRootComponentID()
{
	return KGUtils::GetIDByObject(this->GetRootComponent());
}

int64 ACameraManager::KAPI_Camera_GetCurrentSceneBaseCameraActor(const FString& CameraNamePattern)
{
	TArray<AActor*> Result;
	UGameplayStatics::GetAllActorsOfClass(this, ABaseCamera::StaticClass(), Result);
	for(auto& Camera : Result)
	{
		if(Camera->GetName().Contains(CameraNamePattern))
		{
			return KGUtils::GetIDByObject(Camera);
		}
	}

	return KG_INVALID_ID;
}

int64 ACameraManager::KAPI_Camera_GetCurrentSceneBaseCameraActorFromSceneActorID(int64 SceneActorID)
{
	if(AActor* SceneActor = KGUtils::GetActorByID(SceneActorID))
	{
		for(auto& Com : SceneActor->K2_GetComponentsByClass(UChildActorComponent::StaticClass()))
		{
			if(ACameraActor* Camera = Cast<ACameraActor>(Cast<UChildActorComponent>(Com)->GetChildActor()))
			{
				return KGUtils::GetIDByObject(Camera);
			}
		}
	}
	return KG_INVALID_ID;
}

int64 ACameraManager::KAPI_Camera_GetCurrentSceneBaseCameraActorFromSceneActorIDByTag(int64 SceneActorID, const FName& ComponentTag)
{
	if(AActor* SceneActor = KGUtils::GetActorByID(SceneActorID))
	{
		for(auto& Com : SceneActor->GetComponentsByTag(UChildActorComponent::StaticClass(), ComponentTag))
		{
			if(ACameraActor* Camera = Cast<ACameraActor>(Cast<UChildActorComponent>(Com)->GetChildActor()))
			{
				return KGUtils::GetIDByObject(Camera);
			}
		}
	}
	return KG_INVALID_ID;
}


void ACameraManager::KAPI_Camera_DialogueCamera_SetCameraPostProcessSetting(int64 CameraActorID,
	bool bOverride_DepthOfFieldFocalDistance, float DepthOfFieldFocalDistance, bool bOverride_DepthOfFieldFstop,
	float DepthOfFieldFstop, bool bOverride_DepthOfFieldSensorWidth, float DepthOfFieldSensorWidth,
	bool bOverride_DepthOfFieldFocalRegion, float DepthOfFieldFocalRegion,
	bool bOverride_DepthOfFieldNearTransitionRegion, float DepthOfFieldNearTransitionRegion,
	bool bOverride_DepthOfFieldFarTransitionRegion, float DepthOfFieldFarTransitionRegion, bool bMobileHQGaussian,
	bool bOverride_DepthOfFieldScale, bool bOverride_DepthOfFieldNearBlurSize, bool bOverride_DepthOfFieldFarBlurSize,
	float FieldOfView)
{
	if(AActor* Actor = KGUtils::GetActorByID(CameraActorID))
	{
		if(UCameraComponent* CameraCom = Cast<UCameraComponent>(Actor->GetComponentByClass(UCameraComponent::StaticClass())))
		{
			FPostProcessSettings& PostProcessSettings = CameraCom->PostProcessSettings;
			PostProcessSettings.bOverride_DepthOfFieldFocalDistance = bOverride_DepthOfFieldFocalDistance;
				
			PostProcessSettings.DepthOfFieldFocalDistance = DepthOfFieldFocalDistance;

			PostProcessSettings.bOverride_DepthOfFieldFstop = bOverride_DepthOfFieldFstop;
			PostProcessSettings.DepthOfFieldFstop = DepthOfFieldFstop;

			PostProcessSettings.bOverride_DepthOfFieldSensorWidth = bOverride_DepthOfFieldSensorWidth;
			PostProcessSettings.DepthOfFieldSensorWidth = DepthOfFieldSensorWidth;

			PostProcessSettings.bOverride_DepthOfFieldFocalRegion = bOverride_DepthOfFieldFocalRegion;
			PostProcessSettings.DepthOfFieldFocalRegion = DepthOfFieldFocalRegion;

			PostProcessSettings.bOverride_DepthOfFieldNearTransitionRegion = bOverride_DepthOfFieldNearTransitionRegion;
			PostProcessSettings.DepthOfFieldNearTransitionRegion = DepthOfFieldNearTransitionRegion;

			PostProcessSettings.bOverride_DepthOfFieldFarTransitionRegion = bOverride_DepthOfFieldFarTransitionRegion;
			PostProcessSettings.DepthOfFieldFarTransitionRegion = DepthOfFieldFarTransitionRegion;

			PostProcessSettings.bMobileHQGaussian = bMobileHQGaussian;
			PostProcessSettings.bOverride_DepthOfFieldScale = bOverride_DepthOfFieldScale;
			PostProcessSettings.bOverride_DepthOfFieldNearBlurSize = bOverride_DepthOfFieldNearBlurSize;
			PostProcessSettings.bOverride_DepthOfFieldFarBlurSize = bOverride_DepthOfFieldFarBlurSize;

			CameraCom->SetFieldOfView(FieldOfView);
		}
	}
}

void ACameraManager::KAPI_Camera_DialogueCamera_SetCameraDOFDistance(int64 CameraActorID, float DOFDistance)
{
	if(AActor* Actor = KGUtils::GetActorByID(CameraActorID))
	{
		if(UCameraComponent* CameraCom = Cast<UCameraComponent>(Actor->GetComponentByClass(UCameraComponent::StaticClass())))
		{
			FPostProcessSettings& PostProcessSettings = CameraCom->PostProcessSettings;
			PostProcessSettings.DepthOfFieldFocalDistance = DOFDistance;
		}
	}
}

float ACameraManager::KAPI_Camera_DialogueCamera_GetCameraDOFDistance(int64 CameraActorID)
{
	if(AActor* Actor = KGUtils::GetActorByID(CameraActorID))
	{
		if(UCameraComponent* CameraCom = Cast<UCameraComponent>(Actor->GetComponentByClass(UCameraComponent::StaticClass())))
		{
			return CameraCom->PostProcessSettings.DepthOfFieldFocalDistance;
		}
	}

	return 0.f;
}

float ACameraManager::KAPI_Camera_DialogueCamera_GetCameraDOFDistanceFromViewportCenter(int64 CameraActorID)
{
	if (APlayerController* PlayerController = GetWorld()->GetFirstPlayerController())
	{
		FVector2D ScreenCenter = FVector2D(0.5f, 0.5f);
		int32 ViewportSizeX, ViewportSizeY;
		FVector WorldLocation, WorldRotation;
		PlayerController->GetViewportSize(ViewportSizeX, ViewportSizeY);
		PlayerController->DeprojectScreenPositionToWorld(ScreenCenter.X * ViewportSizeX, ScreenCenter.Y * ViewportSizeY, WorldLocation, WorldRotation);

		if (AActor* Actor = KGUtils::GetActorByID(CameraActorID))
		{
			return UKismetMathLibrary::Vector_Distance(Actor->GetActorLocation(), WorldLocation);
		}
	}

	return 0.0f;
}

FVector ACameraManager::KAPI_Camera_DialogueCamera_GetViewportCenterWorldPosition()
{
	if (APlayerController* PlayerController = GetWorld()->GetFirstPlayerController())
	{
		FVector2D ScreenCenter = FVector2D(0.5f, 0.5f);
		int32 ViewportSizeX, ViewportSizeY;
		FVector WorldLocation, WorldRotation;
		PlayerController->GetViewportSize(ViewportSizeX, ViewportSizeY);
		PlayerController->DeprojectScreenPositionToWorld(ScreenCenter.X * ViewportSizeX, ScreenCenter.Y * ViewportSizeY, WorldLocation, WorldRotation);
		return WorldLocation;
	}
	return FVector::ZeroVector;
}

void ACameraManager::KAPI_Camera_DialogueCamera_SetCameraDOFOverride(int64 CameraActorID, bool bOverride_DOFFstop, bool bOverride_DOFSensorWidth, bool bOverride_DOFFocalDistance)
{
	if(ACameraActor* Camera = Cast<ACameraActor>(KGUtils::GetObjectByID(CameraActorID)))
	{
		auto& PPSet = Camera->GetCameraComponent()->PostProcessSettings;
		PPSet.bOverride_DepthOfFieldFstop = bOverride_DOFFstop;
		PPSet.bOverride_DepthOfFieldSensorWidth = bOverride_DOFSensorWidth;
		PPSet.bOverride_DepthOfFieldFocalDistance = bOverride_DOFFocalDistance;
	}
}

void ACameraManager::KAPI_Camera_DialogueCamera_SetCameraDOFParams(int64 CameraActorID, float DOFDistance, float DOFSensorWidth, float DOFFstop)
{
	if(ACameraActor* Camera = Cast<ACameraActor>(KGUtils::GetObjectByID(CameraActorID)))
	{
		auto& PPSet = Camera->GetCameraComponent()->PostProcessSettings;
		PPSet.bOverride_DepthOfFieldFocalDistance = DOFDistance;
		PPSet.bOverride_DepthOfFieldSensorWidth = DOFSensorWidth;
		PPSet.bOverride_DepthOfFieldFstop = DOFFstop;
	}
}

void ACameraManager::KAPI_Camera_DialogueCamera_SetCameraFOV(int64 CameraActorID, float FOVValue)
{
	if(AActor* Actor = KGUtils::GetActorByID(CameraActorID))
	{
		if(UCameraComponent* CameraCom = Cast<UCameraComponent>(Actor->GetComponentByClass(UCameraComponent::StaticClass())))
		{
			CameraCom->SetFieldOfView(FOVValue);
		}
	}
}

void ACameraManager::KAPI_Camera_DialogueCamera_SetCameraAspectRatioAxisConstraint(int64 CameraActorID,
	int NewEAspectRatioAxisConstraint)
{
	if(AActor* Actor = KGUtils::GetActorByID(CameraActorID))
	{
		if(UCameraComponent* CameraCom = Cast<UCameraComponent>(Actor->GetComponentByClass(UCameraComponent::StaticClass())))
		{
			CameraCom->SetAspectRatioAxisConstraint(static_cast<EAspectRatioAxisConstraint>(NewEAspectRatioAxisConstraint));
		}
	}
}

void ACameraManager::KAPI_Camera_DialogueCamera_SetCameraOverrideAspectRatioAxisConstraint(int64 CameraActorID,
	bool bNewOverrideAspectRatioAxisConstraint)
{
	if(AActor* Actor = KGUtils::GetActorByID(CameraActorID))
	{
		if(UCameraComponent* CameraCom = Cast<UCameraComponent>(Actor->GetComponentByClass(UCameraComponent::StaticClass())))
		{
			CameraCom->bOverrideAspectRatioAxisConstraint = bNewOverrideAspectRatioAxisConstraint;
		}
	}
}

void ACameraManager::KAPI_Camera_DialogueCamera_SetAspectRatio(int64 CameraActorID, float InAspectRatio)
{
    if(AActor* Actor = KGUtils::GetActorByID(CameraActorID))
    {
        if(UCameraComponent* CameraCom = Cast<UCameraComponent>(Actor->GetComponentByClass(UCameraComponent::StaticClass())))
        {
            CameraCom->SetAspectRatio(InAspectRatio);
        }
        else
        {
            UE_LOG(LogTemp, Warning, TEXT("[CameraManager]KAPI_Camera_DialogueCamera_SetAspectRatio failed: camera actor[%lld] has no camera component"), CameraActorID);
        }
    }
    else
    {
        UE_LOG(LogTemp, Warning, TEXT("[CameraManager]KAPI_Camera_DialogueCamera_SetAspectRatio failed: cannot find camera actor, camera actor id: %lld"), CameraActorID);
    }
}

void ACameraManager::KAPI_Camera_DialogueCamera_SetConstraintAspectRatio(int64 CameraActorID, bool bInConstrainAspectRatio)
{
    if(AActor* Actor = KGUtils::GetActorByID(CameraActorID))
    {
        if(UCameraComponent* CameraCom = Cast<UCameraComponent>(Actor->GetComponentByClass(UCameraComponent::StaticClass())))
        {
            CameraCom->SetConstraintAspectRatio(bInConstrainAspectRatio);
        }
        else
        {
            UE_LOG(LogTemp, Warning, TEXT("[CameraManager]KAPI_Camera_DialogueCamera_SetConstraintAspectRatio failed: camera actor[%lld] has no camera component"), CameraActorID);
        }
    }
    else
    {
        UE_LOG(LogTemp, Warning, TEXT("[CameraManager]KAPI_Camera_DialogueCamera_SetConstraintAspectRatio failed: cannot find camera actor, camera actor id: %lld"), CameraActorID);
    }
}

void ACameraManager::KAPI_Camera_EnablePOVPostProcess(bool bEnable, int Tag)
{
	if(bEnable)
	{
		NotApplyPOVPostProcess.Remove(Tag);
	}
	else
	{
		NotApplyPOVPostProcess.Add(Tag);
	}
}

void ACameraManager::KAPI_Camera_CutSceneActivate(bool bActivate)
{
	bCutSceneActivate = bActivate;
}

void ACameraManager::KAPI_Camera_BlockAllCameraActions(bool Value)
{
	if(CameraActionHandler != nullptr)
	{
		CameraActionHandler->BlockAllAction(Value);
	}
}

void ACameraManager::AssignScale(int Left, int Right, float Value)
{
	ScaleContainer.Assign(Left, Right, Value);
}

float ACameraManager::CalScaleForDamage(int64 TargetActorID)
{
	AActor* TargetActor = Cast<AActor>(KGUtils::GetObjectByID(TargetActorID));
	if(!TargetActor)
	{
		return ScaleContainer.GetDefault();
	}

	return ScaleContainer.Get(FVector::Dist(TargetActor->GetActorLocation(), GetCameraCacheView().Location));
}

float ACameraManager::GetCorrectInteractiveCameraRotAndZoom(const FVector& PosA, const FVector& PosB, const FVector& StartPos, const FRotator& InitRot, int DesiredPitch, int YawOff, int ZoomMinOff, int ZoomDesireOff, FRotator& ResultRot)
{
	ResultRot.Roll = 0;

	FVector Dir = (PosB - PosA).GetSafeNormal();
	float InitYaw = FRotator::ClampAxis(InitRot.Yaw);
	float DirYaw = FRotator::ClampAxis(Dir.ToOrientationRotator().Yaw);
	float TargetYaw = DirYaw;
	if(InitRot.Vector().Dot(Dir) >= 0)
	{
		if(MathFormula::ClosetYawAbsDiff(InitYaw, DirYaw + YawOff) < MathFormula::ClosetYawAbsDiff(InitYaw, DirYaw - YawOff))
		{
			TargetYaw = FRotator::ClampAxis(DirYaw + YawOff);
		}
		else
		{
			TargetYaw = FRotator::ClampAxis(DirYaw - YawOff);
		}
	}
	else
	{
		if(MathFormula::ClosetYawAbsDiff(InitYaw, DirYaw + 180 + YawOff) < MathFormula::ClosetYawAbsDiff(InitYaw, DirYaw + 180 - YawOff))
		{
			TargetYaw = FRotator::ClampAxis(DirYaw + 180 + YawOff);
		}
		else
		{
			TargetYaw = FRotator::ClampAxis(DirYaw + 180 - YawOff);
		}
	}

	const float MinZoom = (PosB - PosA).Size() / 2 + ZoomMinOff;
	float DesiredZoom = (PosB - PosA).Size() / 2 + ZoomDesireOff;
	float ResultZoom = FMath::Floor(DesiredZoom);

	ResultRot.Pitch = DesiredPitch;
	ResultRot.Yaw = TargetYaw;
	
	FCollisionQueryParams QueryParams(SCENE_QUERY_STAT(CameraArm), false);
	FHitResult HitResults;
	if(GetWorld()->SweepSingleByChannel(HitResults, StartPos, StartPos - DesiredZoom * ResultRot.Vector(), FQuat::Identity, ECollisionChannel::ECC_Camera, FCollisionShape::MakeSphere(24), QueryParams))
	{
		if((HitResults.Location - StartPos).Size() > MinZoom)
		{
			return ResultZoom;
		}
	}
	else
	{
		return ResultZoom;
	}

	ResultRot.Yaw = FRotator::ClampAxis(2 * DirYaw - TargetYaw);
	if(GetWorld()->SweepSingleByChannel(HitResults, StartPos, StartPos - DesiredZoom * ResultRot.Vector(), FQuat::Identity, ECollisionChannel::ECC_Camera, FCollisionShape::MakeSphere(24), QueryParams))
	{
		if((HitResults.Location - StartPos).Size() < MinZoom)
		{
			ResultRot = InitRot;
			ResultZoom = MinZoom;
			return ResultZoom;
		}
	}

	return ResultZoom;
}

void ACameraManager::ModifyIncreasingCurve(UCurveVector* Curve, float MinX, float MaxX, FVector MinY, FVector MaxY)
{
	if(Curve == nullptr)
	{
		return;
	}

	for(int Index = 0; Index < 3; ++Index)
	{
		Curve->FloatCurves[Index].Reset();
		Curve->FloatCurves[Index].UpdateOrAddKey(MinX, MinY[Index]);
		Curve->FloatCurves[Index].UpdateOrAddKey(MaxX, MaxY[Index]);
	}
}

#pragma endregion Utils
