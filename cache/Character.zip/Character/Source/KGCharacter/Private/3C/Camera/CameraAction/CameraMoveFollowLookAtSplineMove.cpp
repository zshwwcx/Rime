// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Camera/CameraAction/CameraMoveFollowLookAtSplineMove.h"

#include "3C/Movement/RoleMovementComponent.h"
#include "GameFramework/Character.h"

void UCameraMoveFollowLookAtSplineMove::Init(USplineComponent* SplineCom, bool bInYawOffset, float InYawOffset,
	bool bInPitch, float InPitch, float InRotationLagParams)
{
	FollowLookAtSplineCom = nullptr;
	LookAtRoleMovementCom.Reset();
	Duration = -1;

	FollowLookAtSplineCom = SplineCom;
	RotationLagParams = InRotationLagParams;

	bPitch = bInPitch;
	Pitch = InPitch;
	bYawOffset = bInYawOffset;
	YawOffset = InYawOffset;

	bRecover = false;

	InitParams();
}

void UCameraMoveFollowLookAtSplineMove::Refresh(bool bInYawOffset, float InYawOffset, bool bInPitch, float InPitch,
	float InRotationLagParams)
{
	bPitch = bInPitch;
	Pitch = InPitch;
	bYawOffset = bInYawOffset;
	YawOffset = InYawOffset;
	RotationLagParams = InRotationLagParams;

	if(CameraMode.IsValid() && CameraMode->IsActivate())
	{
		CameraMode->SetCameraRotationLagSetting(RotationLagParams, Priority);

		if(LookAtRoleMovementCom.IsValid() && FollowLookAtSplineCom != nullptr)
		{
			float MoveDistance = FMath::Max(LookAtRoleMovementCom->GetSplineMoveDistance(), 0);
			FRotator Orient = FollowLookAtSplineCom->GetWorldRotationAtDistanceAlongSpline(MoveDistance);
			if(bYawOffset)
			{
				Orient.Yaw += YawOffset;
			}
			if(bPitch)
			{
				Orient.Pitch = Pitch;
			}
			Orient.Roll = 0;
			if(ABaseCamera* Camera = CameraMode->GetCamera())
			{
				Camera->SetActorRotation(Orient);
			}
		}
	}
}

void UCameraMoveFollowLookAtSplineMove::Play()
{
	Super::Play();
	InitParams();
}

bool UCameraMoveFollowLookAtSplineMove::ProcessViewRotation(AActor* ViewTarget, float DeltaTime,
	bool& bOutChangePitch, double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll,
	FRotator& OutDeltaRot)
{
	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return false;
	}

	if(!LookAtRoleMovementCom.IsValid() || FollowLookAtSplineCom == nullptr)
	{
		return false;
	}

	float MoveDistance = FMath::Max(LookAtRoleMovementCom->GetSplineMoveDistance(), 0);
	FRotator Orient = FollowLookAtSplineCom->GetWorldRotationAtDistanceAlongSpline(MoveDistance);
	if(bYawOffset)
	{
		Orient.Yaw += YawOffset;
	}
	OutRoll = Orient.Roll;
	OutYaw = Orient.Yaw;
	bOutChangeRoll = true;
	bOutChangeYaw = true;
	OutDeltaRot.Roll = 0;
	OutDeltaRot.Yaw = 0;
	if(bPitch)
	{
		OutPitch = Pitch;
		OutDeltaRot.Pitch = 0;
		bOutChangePitch = true;
	}
	if(ABaseCamera* Camera = CameraMode->GetCamera())
	{
		Camera->SetActorRotation(Orient);
	}
	return true;
}

void UCameraMoveFollowLookAtSplineMove::ModifyCamera(float DeltaTime)
{
	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return;
	}

	if(ABaseCamera* Camera = CameraMode->GetCamera())
	{
		if(LookAtRoleMovementCom.IsValid() && FollowLookAtSplineCom != nullptr)
		{
			float MoveDistance = FMath::Max(LookAtRoleMovementCom->GetSplineMoveDistance(), 0);
			float TotalDistance = FollowLookAtSplineCom->GetSplineLength();
			FVector Loc = FollowLookAtSplineCom->GetWorldLocationAtDistanceAlongSpline(MoveDistance);
			Camera->SetCameraFollowLookAtSplineMoveLocation(Loc);
		}
	}
}

void UCameraMoveFollowLookAtSplineMove::Abort()
{
	if(CameraMode.IsValid() && CameraMode->IsActivate())
	{
		if(ABaseCamera* Cam = CameraMode->GetCamera())
		{
			Cam->CancelFollowLookAtSpineMove();
		}
		CameraMode->RemoveCameraRotationLagSetting(Priority);
	}
	Super::Abort();
}

void UCameraMoveFollowLookAtSplineMove::DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode)
{
	Super::DoWhenEffectModeActivate(ActivateCameraMode);
	InitParams();
}

void UCameraMoveFollowLookAtSplineMove::CancelFollowLookAtSpineMove()
{
	LookAtRoleMovementCom.Reset();
	FollowLookAtSplineCom = nullptr;
}

void UCameraMoveFollowLookAtSplineMove::InitParams()
{
	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return;
	}

	CameraMode->SetCameraRotationLagSetting(RotationLagParams, Priority);
	
	if(ABaseCamera* Cam = CameraMode->GetCamera())
	{
		if(ACharacter* LookAtCharacter = Cast<ACharacter>(Cam->GetControlledTarget()))
		{
			if(URoleMovementComponent* RoleMovementCom = LookAtCharacter->GetComponentByClass<URoleMovementComponent>())
			{
				LookAtRoleMovementCom = RoleMovementCom;
				Cam->InitFollowLookAtSpineMove();
			}
		}
	}
}
