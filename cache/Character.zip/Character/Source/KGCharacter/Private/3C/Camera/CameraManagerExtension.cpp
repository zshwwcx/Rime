// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Camera/CameraManagerExtension.h"


#if ALLOW_CONSOLE
#include "Engine/Blueprint.h"
#include "Camera/CameraShakeBase.h"
#include "Engine/ObjectLibrary.h"
#include "AssetRegistry/AssetData.h"
#include "ConsoleSettings.h"
#endif

void FCameraManagerExtension::PopulateAutoCompleteEntries(TArray<FAutoCompleteCommand>& AutoCompleteList)
{
#if (ALLOW_CONSOLE && UE_BUILD_DEVELOPMENT)
	auto objLibrary = UObjectLibrary::CreateLibrary(UBlueprint::StaticClass(), false, true);
	objLibrary->LoadAssetDataFromPath(TEXT("/Game/Arts/Effects/CameraShake/"));
	TArray<FAssetData> ItemAssets;
	objLibrary->GetAssetDataList(ItemAssets);

	const UConsoleSettings* ConsoleSettings = GetDefault<UConsoleSettings>();
	for (const FAssetData& ItemAsset : ItemAssets)
	{
		FAutoCompleteCommand AutoCompleteCommand;
		
		// The name of cheat must match the start of this
		// We are assuming there is a cheat "GiveItem" that is defined elsewhere
		AutoCompleteCommand.Command = *FString::Printf(TEXT("PlayCameraShake %s"), *ItemAsset.GetObjectPathString());
		
		AutoCompleteCommand.Desc = "Play the specified camera shake";
		
		// You can customize the color or just use the default one
		AutoCompleteCommand.Color = ConsoleSettings->AutoCompleteCommandColor;
 
		// MoveTemp for efficiency
		AutoCompleteList.Add(MoveTemp(AutoCompleteCommand));
	}
#endif
}
