// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Camera/CameraAction/CameraNavigationMoveAction.h"

#include "3C/Movement/RoleMovementComponent.h"

void UCameraNavigationMoveAction::Init(float InYawBlendParam, float InPitchBlendParam, float InLockPitch,
                                       float InActionCD)
{
	YawBlendParam = InYawBlendParam;
	PitchBlendParam = InPitchBlendParam;
	LockPitch = InLockPitch;
	ActionCD = InActionCD;
	Duration = -1;
	MoveComponent.Reset();
}

void UCameraNavigationMoveAction::Play()
{
	Super::Play();
	CurrentCDTime = ActionCD + CDCorrect;

	InitParams();
}

bool UCameraNavigationMoveAction::ProcessViewRotation(AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch,
	double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot)
{
	if(!MoveComponent.IsValid())
	{
		return false;
	}

	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return false;
	}

	CurrentCDTime = FMath::Min(CurrentCDTime + DeltaTime, ActionCD + CDCorrect);
	if(CurrentCDTime < ActionCD)
	{
		return false;
	}

	OutDeltaRot.Pitch = 0.f;
	OutDeltaRot.Yaw = 0.f;
	
	FVector MoveVelocity = MoveComponent->GetMovementVelocity();
	if(!MoveComponent->GetIsLocoStart() || MoveVelocity.IsNearlyZero())
	{
		return true;
	}

	// UE_LOG(LogTemp, Log, TEXT("Camera Navigation MoveVelocity:%s Value:%f"), *MoveVelocity.ToString(), MoveVelocity.Length())
	FRotator MoveVelocityDir = MoveVelocity.Rotation();
	float InnerYawAlpha = FMath::IsNearlyZero(YawBlendParam) ? 0.f : FMath::Pow(0.5f, DeltaTime / YawBlendParam); 
	float InnerPitchAlpha = FMath::IsNearlyZero(PitchBlendParam) ? 0.f : FMath::Pow(0.5f, DeltaTime / PitchBlendParam);

	float CurrentYaw = FRotator::NormalizeAxis(OutYaw);
	float CurrentPitch = FRotator::NormalizeAxis(OutPitch);
	float TargetYaw = MathFormula::SameSignAngle(CurrentYaw, MoveVelocityDir.Yaw);
	float TargetPitch = MathFormula::SameSignAngle(CurrentPitch, LockPitch);

	bOutChangePitch = true;
	bOutChangeYaw = true;
	OutYaw = TargetYaw + (CurrentYaw - TargetYaw) * InnerYawAlpha;
	OutPitch = TargetPitch + (CurrentPitch - TargetPitch) * InnerPitchAlpha;
	return true;
}

bool UCameraNavigationMoveAction::IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType)
{
	if(ControlType == ECameraManualControlType::ManualRot)
	{
		CurrentCDTime = 0.f;
	}

	return false;
}

void UCameraNavigationMoveAction::DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode)
{
	Super::DoWhenEffectModeActivate(ActivateCameraMode);
	InitParams();
}

void UCameraNavigationMoveAction::InitParams()
{
	MoveComponent.Reset();
	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return;
	}

	if(UCameraArmComponent* Arm = CameraMode->GetCameraArmComponent())
	{
		if(Arm->LookAtTarget.IsValid())
		{
			if(URoleMovementComponent* RoleMove = Arm->LookAtTarget->GetComponentByClass<URoleMovementComponent>())
			{
				MoveComponent = RoleMove;
			}
		}
	}
}
