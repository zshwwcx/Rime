// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Camera/CameraUtil/CameraUtils.h"

FCameraMultiLayerParam::FCameraMultiLayerParam()
{
	Param.Reset();
	Param.Emplace(0, 0.f);
}

FCameraMultiLayerParam::FCameraMultiLayerParam(float Value)
{
	Reset(Value);
}

FCameraMultiLayerParam::operator float() const
{
	return GetValue();
}

void FCameraMultiLayerParam::SetValueByPriority(float Value, int Priority)
{
	for (int Index = 0; Index < Param.Num(); ++Index)
	{
		if(Param[Index].Key > Priority)
		{
			Param.Insert({Priority, Value}, Index);
			return;
		}

		if(Param[Index].Key == Priority)
		{
			Param[Index].Value = Value;
			return;
		}
	}
	Param.Emplace(Priority, Value);
}

float FCameraMultiLayerParam::GetValueBelowPriority(int Priority, float DefaultValue) const
{
	float Result = DefaultValue;
	for (int Index = Param.Num() - 1; Index > -1; --Index)
	{
		if(Param[Index].Key < Priority)
		{
			Result = Param[Index].Value;
			break;
		}
	}

	return Result;
}

float FCameraMultiLayerParam::GetValueByPriority(int Priority, float DefaultValue) const
{
	float Result = DefaultValue;
	for (int Index = 0; Index < Param.Num(); ++Index)
	{
		if(Param[Index].Key == Priority)
		{
			Result = Param[Index].Value;
			break;
		}
	}

	return Result;
}

float FCameraMultiLayerParam::GetValueBelowOrEqualPriority(int Priority, float DefaultValue) const
{
	float Result = DefaultValue;
	for (int Index = Param.Num() - 1; Index > -1; --Index)
	{
		if(Param[Index].Key <= Priority)
		{
			Result = Param[Index].Value;
			break;
		}
	}

	return Result;
}

void FCameraMultiLayerParam::RemoveValueByPriority(int Priority)
{
	for (int Index = 0; Index < Param.Num(); ++Index)
	{
		if(Param[Index].Key > Priority)
		{
			return;
		}

		if(Param[Index].Key == Priority)
		{
			Param.RemoveAt(Index);
			return;
		}
	}
}

bool FCameraMultiLayerParam::IsTopPriority(int Priority) const
{
	if (Param.Num() == 0)
	{
		UE_LOG(LogTemp, Error, TEXT("Camera:CameraMultiLayerParam No Valid Value."))
		return false;
	}

	return Param.Last().Key == Priority;
}

bool FCameraMultiLayerParam::GetValueSecondaryPriority(float& OutValue) const
{
	if(Param.Num() < 2)
	{
		return false;
	}

	OutValue = Param[Param.Num() - 2].Value;
	return true;
}

void FCameraMultiLayerParam::SetValueSecondaryPriority(float Value)
{
	if(Param.Num() < 2)
	{
		return;
	}

	SetValueByPriority(Value, Param[Param.Num() - 2].Key);
}

void FCameraMultiLayerParam::Reset(float Value)
{
	Param.Reset();
	Param.Emplace(0, Value);
}

float FCameraMultiLayerParam::GetValue() const
{
	if(Param.Num() == 0)
	{
		UE_LOG(LogTemp, Error, TEXT("Camera:CameraMultiLayerParam No Valid Value."))
		return 0;
	}

	return Param.Last().Value;
}

int FCameraMultiLayerParam::GetTopPriority() const
{
	if (Param.Num() == 0)
	{
		UE_LOG(LogTemp, Error, TEXT("Camera:CameraMultiLayerParam No Valid Value."))
		return 0;
	}

	return Param.Last().Key;
}

int FCameraMultiLayerParam::GetTopPriorityBelowPriority(int Priority) const
{
	for (int Index = Param.Num() - 1; Index > 0; --Index)
	{
		if (Param[Index].Key < Priority)
		{
			return Param[Index].Key;
		}
	}
	return -1;
}

void FCameraMultiLayerParam::RemoveValueWithoutBase()
{
	for (int Index = Param.Num() - 1; Index > 0; --Index)
	{
		Param.RemoveAt(Index);
	}
}

void FCameraMultiLayerParam::UpdateAllAbovePriority(float Value, int Priority)
{
	for (int Index = Param.Num() - 1; Index > -1; --Index)
	{
		if (Param[Index].Key <= Priority)
		{
			break;
		}
		Param[Index].Value = Value;
	}
}

FCameraMultiLayerParam_FVector::FCameraMultiLayerParam_FVector()
{
	Param.Reset();
	Param.Emplace(0, FVector::ZeroVector);
}

FCameraMultiLayerParam_FVector::FCameraMultiLayerParam_FVector(const FVector& Value)
{
	Reset(Value);
}

FCameraMultiLayerParam_FVector::operator FVector() const
{
	return GetValue();
}

void FCameraMultiLayerParam_FVector::SetValueByPriority(const FVector& Value, int Priority)
{
	for (int Index = 0; Index < Param.Num(); ++Index)
	{
		if(Param[Index].Key > Priority)
		{
			Param.Insert({Priority, Value}, Index);
			return;
		}

		if(Param[Index].Key == Priority)
		{
			Param[Index].Value = Value;
			return;
		}
	}

	Param.Emplace(Priority, Value);
}

FVector FCameraMultiLayerParam_FVector::GetValueBelowPriority(int Priority, const FVector& DefaultValue) const
{
	FVector Result = DefaultValue;
	for (int Index = Param.Num() - 1; Index > -1; --Index)
	{
		if(Param[Index].Key < Priority)
		{
			Result = Param[Index].Value;
			break;
		}
	}

	return Result;
}

void FCameraMultiLayerParam_FVector::RemoveValueByPriority(int Priority)
{
	for (int Index = 0; Index < Param.Num(); ++Index)
	{
		if(Param[Index].Key > Priority)
		{
			return;
		}

		if(Param[Index].Key == Priority)
		{
			Param.RemoveAt(Index);
			return;
		}
	}
}

bool FCameraMultiLayerParam_FVector::IsTopPriority(int Priority) const
{
	if(Param.Num() == 0)
	{
		UE_LOG(LogTemp, Error, TEXT("Camera:FCameraMultiLayerParam_FVector No Valid Value."))
		return false;
	}

	return Param.Last().Key == Priority;
}

void FCameraMultiLayerParam_FVector::Reset(FVector Value)
{
	Param.Reset();
	Param.Emplace(0, Value);
}

bool FCameraMultiLayerParam_FVector::GetValueSecondaryPriority(FVector& OutValue) const
{
	if(Param.Num() < 2)
	{
		return false;
	}

	OutValue = Param[Param.Num() - 2].Value;
	return true;
}

void FCameraMultiLayerParam_FVector::SetValueSecondaryPriority(const FVector& Value)
{
	if(Param.Num() < 2)
	{
		return;
	}

	SetValueByPriority(Value, Param[Param.Num() - 2].Key);
}

FVector FCameraMultiLayerParam_FVector::GetValue() const
{
	if(Param.Num() == 0)
	{
		UE_LOG(LogTemp, Error, TEXT("Camera:FCameraMultiLayerParam_FVector No Valid Value."))
		return FVector::ZeroVector;
	}

	return Param.Last().Value;
}

int FCameraMultiLayerParam_FVector::GetTopPriority() const
{
	if (Param.Num() == 0)
	{
		UE_LOG(LogTemp, Error, TEXT("Camera:CameraMultiLayerParam No Valid Value."))
		return 0;
	}

	return Param.Last().Key;
}

void FCameraMultiLayerParam_FVector::RemoveValueWithoutBase()
{
	for (int Index = Param.Num() - 1; Index > 0; --Index)
	{
		Param.RemoveAt(Index);
	}
}

FCameraMultiLayerParam_FRotator::FCameraMultiLayerParam_FRotator()
{
	Param.Reset();
	Param.Emplace(0, FRotator::ZeroRotator);
}

FCameraMultiLayerParam_FRotator::FCameraMultiLayerParam_FRotator(const FRotator& Value)
{
	Reset(Value);
}

FCameraMultiLayerParam_FRotator::operator FRotator() const
{
	return GetValue();
}

void FCameraMultiLayerParam_FRotator::SetValueByPriority(const FRotator& Value, int Priority)
{
	for (int Index = 0; Index < Param.Num(); ++Index)
	{
		if(Param[Index].Key > Priority)
		{
			Param.Insert({Priority, Value}, Index);
			return;
		}

		if(Param[Index].Key == Priority)
		{
			Param[Index].Value = Value;
			return;
		}
	}

	Param.Emplace(Priority, Value);
}

FRotator FCameraMultiLayerParam_FRotator::GetValueBelowPriority(int Priority, const FRotator& DefaultValue) const
{
	FRotator Result = DefaultValue;
	for (int Index = Param.Num() - 1; Index > -1; --Index)
	{
		if(Param[Index].Key < Priority)
		{
			Result = Param[Index].Value;
			break;
		}
	}

	return Result;
}

void FCameraMultiLayerParam_FRotator::RemoveValueByPriority(int Priority)
{
	for (int Index = 0; Index < Param.Num(); ++Index)
	{
		if(Param[Index].Key > Priority)
		{
			return;
		}

		if(Param[Index].Key == Priority)
		{
			Param.RemoveAt(Index);
			return;
		}
	}
}

bool FCameraMultiLayerParam_FRotator::IsTopPriority(int Priority)
{
	if(Param.Num() == 0)
	{
		UE_LOG(LogTemp, Error, TEXT("Camera:FCameraMultiLayerParam_FRotator No Valid Value."))
		return false;
	}

	return Param.Last().Key == Priority;
}

void FCameraMultiLayerParam_FRotator::Reset(FRotator Value)
{
	Param.Reset();
	Param.Emplace(0, Value);
}

bool FCameraMultiLayerParam_FRotator::GetValueSecondaryPriority(FRotator& OutValue)
{
	if(Param.Num() < 2)
	{
		return false;
	}

	OutValue = Param[Param.Num() - 2].Value;
	return true;
}

void FCameraMultiLayerParam_FRotator::SetValueSecondaryPriority(const FRotator& Value)
{
	if(Param.Num() < 2)
	{
		return;
	}

	SetValueByPriority(Value, Param[Param.Num() - 2].Key);
}

FRotator FCameraMultiLayerParam_FRotator::GetValue() const
{
	if(Param.Num() == 0)
	{
		UE_LOG(LogTemp, Error, TEXT("Camera:FCameraMultiLayerParam_FVector No Valid Value."))
		return FRotator::ZeroRotator;
	}

	return Param.Last().Value;
}

int FCameraMultiLayerParam_FRotator::GetTopPriority() const
{
	if (Param.Num() == 0)
	{
		UE_LOG(LogTemp, Error, TEXT("Camera:CameraMultiLayerParam No Valid Value."))
		return 0;
	}

	return Param.Last().Key;
}

void FCameraMultiLayerParam_FRotator::RemoveValueWithoutBase()
{
	for (int Index = Param.Num() - 1; Index > 0; --Index)
	{
		Param.RemoveAt(Index);
	}
}
