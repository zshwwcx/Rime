#include "3C/Camera/PostProcessNew/PPCommon.h"

DEFINE_LOG_CATEGORY(LogKGPP);

#if WITH_EDITOR
TAutoConsoleVariable<float> CVarForcePPBlendWeight(
	TEXT("gp.ForcePPBlendWeight"),
	-1.0f,
	TEXT("ForcePPBlendWeight."),
	ECVF_Default
);
#endif

uint32 KGPPUtils::GeneratePPID()
{
	static uint32 InOutIncID = 1;
	InOutIncID++;
	if (InOutIncID >= 0x7fffffff)
	{
		InOutIncID = 1;
	}

	return InOutIncID;
}
