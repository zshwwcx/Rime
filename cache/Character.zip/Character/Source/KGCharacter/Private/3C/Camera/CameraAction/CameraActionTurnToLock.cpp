// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Camera/CameraAction/CameraActionTurnToLock.h"

#include "3C/Camera/CameraAction/CameraActionHandler.h"
#include "3C/Util/KGUtils.h"
#include "Camera/CameraComponent.h"
#include "Components/SkeletalMeshComponent.h"

const FName UCameraActionTurnToLock::CameraLookBoneName = TEXT("Camera_Look");

void UCameraActionTurnToLock::Init(int64 TargetActorID, float NewYawDemarcation, float NewWideAngleBlendTime, float NewNarrowAngleBlendTime)
{
	DesiredYaw = 0.f;

	LockSKMesh.Reset();
	LockActor.Reset();

	if(AActor* LockTarget = KGUtils::GetActorByID(TargetActorID))
	{
		LockActor = LockTarget;
		if(USkeletalMeshComponent* SKMesh = LockTarget->FindComponentByClass<USkeletalMeshComponent>())
		{
			LockSKMesh = SKMesh;
			if(!SKMesh->DoesSocketExist(CameraLookBoneName))
			{
				LockSKMesh = nullptr;
			}
		}
	}

	YawDemarcation = NewYawDemarcation;

	WideAngleBlendTime = NewWideAngleBlendTime;
	NarrowAngleBlendTime = NewNarrowAngleBlendTime;

	Duration = NewWideAngleBlendTime;

	SetEaseInType(ECameraEaseFunction::EaseInOutCubic, NewWideAngleBlendTime, KG_INVALID_ID);
	bRecover = false;
}

void UCameraActionTurnToLock::Play()
{
	if(bFinished)
	{
		CurSmoothSpeed = 0;
	}

	Super::Play();

	if(!LockSKMesh.IsValid() && !LockActor.IsValid())
	{
		DisableAction(true);
		return;
	}

	LastAlpha = 0.f;
	CalDesiredRot(true);
}

bool UCameraActionTurnToLock::ProcessViewRotation(AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch,
	double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot)
{
	if(!LockSKMesh.IsValid() && !LockActor.IsValid())
	{
		DisableAction(true);
		return false;
	}

	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return false;
	}

	// CalDesiredRot(false);

	bOutChangeYaw = true;
	OutDeltaRot.Yaw = 0.f;

	DesiredYaw = FRotator::NormalizeAxis(DesiredYaw);
	float YawBase = FRotator::NormalizeAxis(BaseYaw);

	const float DeltaAng = MathFormula::ClosetYawSignedDiff(YawBase, DesiredYaw);
	OutYaw = YawBase + FMath::Clamp(Alpha, 0.f, 1.f) * DeltaAng;
	return true;
}


bool UCameraActionTurnToLock::IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType)
{
	if(ControlType == ECameraManualControlType::ManualRot)
	{
		return true;
	}

	return false;
}

void UCameraActionTurnToLock::DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode)
{
	Super::DoWhenEffectModeActivate(ActivateCameraMode);

	CalDesiredRot(true);
}

void UCameraActionTurnToLock::CalDesiredRot(bool bInit)
{
	if(CameraMode.IsValid() && CameraMode->IsActivate() && (LockSKMesh.IsValid() || LockActor.IsValid()))
	{
		if (UCameraArmComponent* Arm = CameraMode->GetCameraArmComponent())
		{
			FVector LookAtLocation = Arm->GetCachedPivotLocation();
			CameraRotation = CameraMode->GetCameraRotation();
			if(bInit)
			{
				BaseYaw = CameraMode->GetCameraRotation().Yaw;
			}

			const FVector PivotToLockDir = ((LockSKMesh.IsValid() ? LockSKMesh->GetSocketLocation(CameraLookBoneName) : LockActor->GetActorLocation()) - LookAtLocation).GetSafeNormal();
			const FRotator PivotToLockDirRot = PivotToLockDir.ToOrientationRotator();
			DesiredYaw = PivotToLockDirRot.Yaw;

			// if(CameraMode->BasicConfig.ViewOffset.GetValue().X == 0 || FMath::IsNearlyZero(Radius))
			// {
			// 	const FVector PivotToLockDir = (LockTarget->GetComponentLocation() - LookAtLocation).GetSafeNormal();
			// 	const FRotator PivotToLockDirRot = PivotToLockDir.ToOrientationRotator();
			// 	DesiredYaw = PivotToLockDirRot.Yaw;
			// }
			// else
			// {
			// 	const FVector LockLocation = LockTarget->GetComponentLocation();
			// 	FVector LookAtToTargetProjection = LockLocation - LookAtLocation;
			// 	LookAtToTargetProjection.Z = 0.f;
			// 	float Distance = LookAtToTargetProjection.Length();
			// 	if(FMath::Abs(Radius) > Distance)
			// 	{
			// 		float YawOffset = Radius > 0 ? -90 : 90;
			// 		DesiredYaw = LookAtToTargetProjection.ToOrientationRotator().Yaw + YawOffset;
			// 	}
			// 	else
			// 	{
			// 		float YawOffset = FMath::RadiansToDegrees(FMath::Acos(Radius / Distance));
			// 		float RadiusYaw = LookAtToTargetProjection.ToOrientationRotator().Yaw + YawOffset;
			// 		LookAtLocation.X += Radius * FMath::Cos(FMath::DegreesToRadians(RadiusYaw));
			// 		LookAtLocation.Y += Radius * FMath::Sin(FMath::DegreesToRadians(RadiusYaw));
			// 		DesiredYaw = (LockLocation - LookAtLocation).ToOrientationRotator().Yaw;
			// 	}
			// }

			if(FMath::Abs(MathFormula::ClosetYawSignedDiff(CameraRotation.Yaw, DesiredYaw)) > YawDemarcation)
			{
				SetEaseInType(ECameraEaseFunction::EaseInOutCubic, WideAngleBlendTime, KG_INVALID_ID);
			}
			else
			{
				SetEaseInType(ECameraEaseFunction::EaseInOutCubic, NarrowAngleBlendTime, KG_INVALID_ID);
			}

			InnerUpdateAlpha(0.f);
		}
	}
}
