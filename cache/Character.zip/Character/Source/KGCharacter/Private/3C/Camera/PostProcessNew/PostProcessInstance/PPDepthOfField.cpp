#include "3C/Camera/PostProcessNew/PostProcessInstance/PPDepthOfField.h"

#include "Misc/KGPlatformUtils.h"
#include "3C/Core/KGUEActorManager.h"
#include "3C/Camera/PostProcessNew/PostProcessManager.h"
#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/Character.h"

void KGPPDepthOfField::InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType, 
	const FKGDepthOfFieldParams& InDepthOfFieldParams)
{
	KGPPBase::InitParams(CommonParams, InPPManager);
	PPType = InPPType;
	DepthOfFieldParams = InDepthOfFieldParams;
}

bool KGPPDepthOfField::OnTaskStart()
{
	if (!KGPPNonMaterialBase::OnTaskStart())
	{
		return false;
	}

	bIsMobile = KGPlatformUtils::Is_ES3_1_FeatureLevel(PostProcessManager.Get());
	UE_LOG(LogKGPP, Log, TEXT("KGPPDepthOfField::OnTaskStart, bIsMobile: %d, %s"), bIsMobile, *GetDebugInfo());

	if (!PostProcessManager.IsValid())
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPDepthOfField::OnTaskStart, invalid PostProcessManager %s"), *GetDebugInfo());
		return false;
	}
	
	CameraManager = UGameplayStatics::GetPlayerCameraManager(PostProcessManager->GetWorld(), 0);
	if (!CameraManager.IsValid())
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPDepthOfField::OnTaskStart, invalid PlayerCameraManager %s"), *GetDebugInfo());
		return false;
	}
	
	PostProcessSettings.bOverride_DepthOfFieldFocalDistance = true;
	PostProcessSettings.DepthOfFieldFocalDistance = DepthOfFieldParams.FocalDistance + DepthOfFieldParams.FocalDistanceOffset;
	
	if (bIsMobile)
	{
		PostProcessSettings.bOverride_MobileHQGaussian = true;
		PostProcessSettings.bMobileHQGaussian = DepthOfFieldParams.bMobileHQGaussian;

		PostProcessSettings.bOverride_DepthOfFieldFocalRegion = true;
		PostProcessSettings.DepthOfFieldFocalRegion = DepthOfFieldParams.FocalRegion;

		if (DepthOfFieldParams.bMobileCustomTransition)
		{
			PostProcessSettings.bOverride_MobileCustomTransition = true;
			PostProcessSettings.bMobileCustomTransition = true;	
		}
		
		PostProcessSettings.bOverride_DepthOfFieldNearTransitionRegion = true;
		PostProcessSettings.DepthOfFieldNearTransitionRegion = DepthOfFieldParams.NearTransitionRegion;

		PostProcessSettings.bOverride_DepthOfFieldFarTransitionRegion = true;
		PostProcessSettings.DepthOfFieldFarTransitionRegion = DepthOfFieldParams.FarTransitionRegion;

		PostProcessSettings.bOverride_DepthOfFieldScale = true;
		PostProcessSettings.DepthOfFieldScale = DepthOfFieldParams.Scale;

		PostProcessSettings.bOverride_DepthOfFieldNearBlurSize = true;
		PostProcessSettings.DepthOfFieldNearBlurSize = DepthOfFieldParams.NearBlurSize;

		PostProcessSettings.bOverride_DepthOfFieldFarBlurSize = true;
		PostProcessSettings.DepthOfFieldFarBlurSize = DepthOfFieldParams.FarBlurSize;
	}
	else
	{
		PostProcessSettings.bOverride_DepthOfFieldFstop = true;
		PostProcessSettings.DepthOfFieldFstop = DepthOfFieldParams.DepthOfFieldFstop;

		PostProcessSettings.bOverride_DepthOfFieldMinFstop = true;
		PostProcessSettings.DepthOfFieldMinFstop = DepthOfFieldParams.DepthOfFieldMinFstop;

		PostProcessSettings.bOverride_DepthOfFieldBladeCount = true;
		PostProcessSettings.DepthOfFieldBladeCount = DepthOfFieldParams.DepthOfFieldBladeCount;
		
		PostProcessSettings.bOverride_DepthOfFieldSensorWidth = true;
		PostProcessSettings.DepthOfFieldSensorWidth = DepthOfFieldParams.SensorWidth;

		PostProcessSettings.bOverride_DepthOfFieldSqueezeFactor = true;
		PostProcessSettings.DepthOfFieldSqueezeFactor = DepthOfFieldParams.SqueezeFactor;

		PostProcessSettings.bOverride_DepthOfFieldDepthBlurAmount = true;
		PostProcessSettings.DepthOfFieldDepthBlurAmount = DepthOfFieldParams.DepthBlurAmount;

		PostProcessSettings.bOverride_DepthOfFieldDepthBlurRadius = true;
		PostProcessSettings.DepthOfFieldDepthBlurRadius = DepthOfFieldParams.DepthBlurRadius;
	}
	
	return true;
}

void KGPPDepthOfField::OnTaskTick(float DeltaTime)
{
	KGPPNonMaterialBase::OnTaskTick(DeltaTime);

	float TargetFocalDistance = 0.0f;
	if (!bIsMobile)
	{
		TargetFocalDistance = DepthOfFieldParams.FocalDistance;
	}

	if (CameraManager.IsValid())
	{
		AActor* FocalActor = nullptr;
		if (DepthOfFieldParams.FocalEntityID != 0)
		{
			if (UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(PostProcessManager.Get()))
			{
				if (auto* Entity = ActorManager->GetLuaEntity(DepthOfFieldParams.FocalEntityID))
				{
					AActor* BindActor = Entity->GetLuaEntityBase()->GetActor();
					if (BindActor == nullptr)
					{
						TargetFocalDistance = (CameraManager->GetCameraCacheView().Location - Entity->GetLocation()).Size();
					}
					else
					{
						FocalActor = BindActor;
					}
				}
			}
		}
		else
		{
			FocalActor = DepthOfFieldParams.FocalTarget.Get();
		}

		if (FocalActor)
		{
			bool bTargetFocalDistanceSet = false;
			if (ACharacter* Character = Cast<ACharacter>(FocalActor))
			{
				if (USkeletalMeshComponent* Mesh = Character->GetMesh())
				{
					TargetFocalDistance = (CameraManager->GetCameraCacheView().Location - Mesh->GetSocketLocation(DepthOfFieldParams.SocketName)).Size();
					bTargetFocalDistanceSet = true;
				}
			}

			if (!bTargetFocalDistanceSet)
			{
				TargetFocalDistance = (CameraManager->GetCameraCacheView().Location - FocalActor->GetActorLocation()).Size();
			}
		}
	}

	PostProcessSettings.DepthOfFieldFocalDistance = TargetFocalDistance + DepthOfFieldParams.FocalDistanceOffset;
}

FString KGPPDepthOfField::GetDebugInfo() const
{
	return FString::Printf(TEXT("[PPDepthOfField] ID[%d], w[%f], FocalTarget[%s], %f/%f"),
		PostProcessID, GetCurrentBlendWeight(),
		DepthOfFieldParams.FocalEntityID != 0 ? *FString::Printf(TEXT("%lld"), DepthOfFieldParams.FocalEntityID) : *GetNameSafe(DepthOfFieldParams.FocalTarget.Get()),
		AccumulateLifeTimeSeconds, TotalLifeTimeSeconds);
}
