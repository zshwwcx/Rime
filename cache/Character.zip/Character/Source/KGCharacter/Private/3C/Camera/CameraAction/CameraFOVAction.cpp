// Fill out your copyright notice in the Description page of Project Settings.

#include "3C/Camera/CameraAction/CameraFOVAction.h"
#include "Camera/CameraComponent.h"

void UCameraFOVAction::Init(float FOV, float FOVOffset, bool bInRecover, float InBlendInTime,
                            float InBlendOutTime, float InDuration, ECameraEaseFunction::Type InBlendInType,
                            ECameraEaseFunction::Type InBlendOutType, int64 InBlendInCurve, int64 InBlendOutCurve)
{
	TargetFOV = FOV;
	TargetFOVOffset = FOVOffset;

	bRecover = bInRecover;

	SetEaseInType(InBlendInType, InBlendInTime, InBlendInCurve);
	SetEaseOutType(InBlendOutType, InBlendOutTime, InBlendOutCurve);
	Duration = InDuration;
}

void UCameraFOVAction::Play()
{
	Super::Play();
	InitParams();
}

void UCameraFOVAction::ModifyCamera(float DeltaTime)
{
	Super::ModifyCamera(DeltaTime);
	
	if(CameraMode.IsValid())
	{
		if(TargetFOV >= 0.f)
		{
			CameraMode->SetFOVSetting(FMath::Lerp(bStartBlendOut ? CameraMode->GetFOVBelowPriority(Priority, FOVBase) : FOVBase, TargetFOV, FMath::Clamp(Alpha, 0.f, 1.f)), Priority);
		}

		if(TargetFOVOffset != 0.f)
		{
			CameraMode->AddFOVDelta(FMath::Lerp(FOVOffsetBase, TargetFOVOffset, FMath::Clamp(Alpha, 0.f, 1.f)));
		}
	}
}

void UCameraFOVAction::Abort()
{
	Super::Abort();

	if(CameraMode.IsValid())
	{
		if(TargetFOV >= 0.f)
		{
			CameraMode->RemoveFOVSetting(Priority);
		}
	}
}

void UCameraFOVAction::DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode)
{
	Super::DoWhenEffectModeActivate(ActivateCameraMode);
	InitParams();
}

void UCameraFOVAction::InitParams()
{
	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return;
	}

	if (UCameraComponent* Camera = CameraMode->GetCameraComponent())
	{
		FOVBase = Camera->FieldOfView;
	}
}
