// Fill out your copyright notice in the Description page of Project Settings.

#include "3C/Camera/CameraAction/CameraActionBattleCorrection.h"
#include "3C/Util/KGUtils.h"
#include "Camera/CameraComponent.h"
#include "Components/SkeletalMeshComponent.h"

const FName UCameraActionBattleCorrection::CameraLookBoneName = TEXT("Camera_Look");

void UCameraActionBattleCorrection::Init(int64 TargetActorID, float BufferYawLeft, float SafeYawLeft,
	float SafeYawRight, float BufferYawRight, float BufferPitchHigh, float SafePitchHigh, float SafePitchLow,
	float BufferPitchLow, float NewBlendTime, int NewBlendInType, int64 NewCurveID, float NewAdaptiveRatio)
{
	LookSKMesh.Reset();
	LookActor.Reset();

	if(AActor* LockTarget = KGUtils::GetActorByID(TargetActorID))
	{
		LookActor = LockTarget;
		if(USkeletalMeshComponent* SKMesh = LockTarget->FindComponentByClass<USkeletalMeshComponent>())
		{
			LookSKMesh = SKMesh;
			if(!SKMesh->DoesSocketExist(CameraLookBoneName))
			{
				LookSKMesh = nullptr;
			}
		}
	}

	BufferZoneYawLeft = BufferYawLeft;
	BufferZoneYawRight = BufferYawRight;
	BufferZonePitchHigh = BufferPitchHigh;
	BufferZonePitchLow = BufferPitchLow;

	SafeZoneYawLeft = SafeYawLeft;
	SafeZoneYawRight = SafeYawRight;
	SafeZonePitchHigh = SafePitchHigh;
	SafeZonePitchLow = SafePitchLow;

	AdaptiveRatio = NewAdaptiveRatio;

	bRecover = false;

	SetEaseInType(static_cast<ECameraEaseFunction::Type>(NewBlendInType), NewBlendTime, NewCurveID);
	Duration = NewBlendTime;
	bYawValid = false;
	bPitchValid = false;
}

void UCameraActionBattleCorrection::Play()
{
	Super::Play();

	CheckCameraRotationValid();
}

bool UCameraActionBattleCorrection::ProcessViewRotation(class AActor* ViewTarget, float DeltaTime,
	bool& bOutChangePitch, double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll,
	FRotator& OutDeltaRot)
{
	if(!LookSKMesh.IsValid() && !LookActor.IsValid())
	{
		DisableAction(true);
		return false;
	}

	if(!CameraMode.IsValid() || !CameraMode->IsActivate())
	{
		return false;
	}

	if(bPitchValid && bYawValid)
	{
		DisableAction(true);
		return false;
	}

	OutDeltaRot.Pitch = 0.f;
	OutDeltaRot.Yaw = 0.f;
	bOutChangePitch = true;
	bOutChangeYaw = true;
	FRotator DeltaAng = (ResultRotator - BaseRotator).GetNormalized();
	FRotator OutViewRotation = BaseRotator + DeltaAng * Alpha;
	OutPitch = OutViewRotation.Pitch;
	OutYaw = OutViewRotation.Yaw;
	return true;
}

void UCameraActionBattleCorrection::Abort()
{
	Super::Abort();
}

void UCameraActionBattleCorrection::DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode)
{
	Super::DoWhenEffectModeActivate(ActivateCameraMode);
	CheckCameraRotationValid();
}

void UCameraActionBattleCorrection::CheckCameraRotationValid()
{
	bPitchValid = true;
	bYawValid = true;

	if (!LookActor.IsValid()) return;
	
	UCameraComponent* Camera = CameraMode->GetCameraComponent();
	if(Camera == nullptr)
	{
		return;
	}
	UCameraArmComponent* Arm = CameraMode->GetCameraArmComponent();
	if(Arm == nullptr)
	{
		return;
	}

	bPitchValid = false;
	bYawValid = false;

	FRotator CameraRotation = Camera->GetComponentRotation();
	BaseRotator = CameraRotation;
	const FVector PivotLocation = Arm->GetCachedPivotLocation();

	const FVector PivotToLockDir = ((LookSKMesh.IsValid() ? LookSKMesh->GetSocketLocation(CameraLookBoneName) : LookActor->GetActorLocation()) - PivotLocation).GetSafeNormal();
	const FRotator PivotToLockDirRot = PivotToLockDir.ToOrientationRotator();

	const float PivotToLockYaw = FRotator::NormalizeAxis(PivotToLockDirRot.Yaw);
	const float PivotToLockPitch = FRotator::NormalizeAxis(PivotToLockDirRot.Pitch) * AdaptiveRatio;
	
	const float DesiredYawRight_Buffer = PivotToLockYaw + BufferZoneYawLeft;
	const float DesiredYawLeft_Buffer = PivotToLockYaw - BufferZoneYawRight;
	const float DesiredPitchHigh_Buffer = FMath::Max(-90.f, PivotToLockPitch - BufferZonePitchHigh);
	const float DesiredPitchLow_Buffer = FMath::Max(-90.f, PivotToLockPitch - BufferZonePitchLow);

	float CameraYaw = FRotator::NormalizeAxis(CameraRotation.Yaw);
	while(CameraYaw <= DesiredYawLeft_Buffer)
	{
		CameraYaw += 360.f;
	}

	if(DesiredPitchLow_Buffer >= CameraRotation.Pitch && CameraRotation.Pitch >= DesiredPitchHigh_Buffer)
	{
		bPitchValid = true;
	}
	if(DesiredYawLeft_Buffer <= CameraYaw && CameraYaw <= DesiredYawRight_Buffer)
	{
		bYawValid = true;
	}

	if(!bPitchValid)
	{
		const float DesiredPitchHigh_Safe = FMath::Max(-90.f, PivotToLockPitch - SafeZonePitchHigh);
		const float DesiredPitchLow_Safe = FMath::Max(-90.f, PivotToLockPitch - SafeZonePitchLow);
		
		if(CameraRotation.Pitch < DesiredPitchHigh_Safe)
		{
			ResultRotator.Pitch = DesiredPitchHigh_Safe;
		}
		if(CameraRotation.Pitch > DesiredPitchLow_Safe)
		{
			ResultRotator.Pitch = DesiredPitchLow_Safe;
		}
	}

	if(!bYawValid)
	{
		const float DesiredYawRight_Safe = PivotToLockYaw + SafeZoneYawLeft;
		const float DesiredYawLeft_Safe = PivotToLockYaw - SafeZoneYawRight;

		const float DeltaToRight = MathFormula::ClosetYawAbsDiff(CameraYaw, DesiredYawRight_Safe);
		const float DeltaToLeft = MathFormula::ClosetYawAbsDiff(CameraYaw, DesiredYawLeft_Safe);
		//UE_LOG(LogTemp, Log, TEXT("UCameraActionBattleCorrection ResultRotator.Yaw:%f DesiredYawRight_Safe.Yaw:%f DesiredYawLeft_Safe.Yaw:%f"), ResultRotator.Yaw, DesiredYawRight_Safe, DesiredYawLeft_Safe);
		if(DeltaToRight < DeltaToLeft)
		{
			ResultRotator.Yaw = DesiredYawRight_Safe;
		}
		else
		{
			ResultRotator.Yaw = DesiredYawLeft_Safe;
		}
	}

	ResultRotator.Roll = CameraRotation.Roll;
	CameraManager->LimitViewPitch(ResultRotator, CameraManager->ViewPitchMin, CameraManager->ViewPitchMax);
	CameraManager->LimitViewYaw(ResultRotator, CameraManager->ViewYawMin, CameraManager->ViewYawMax);
	CameraManager->LimitViewRoll(ResultRotator, CameraManager->ViewRollMin, CameraManager->ViewRollMax);
	NormalizeAxisRotator(ResultRotator);
}

void UCameraActionBattleCorrection::NormalizeAxisRotator(FRotator& InRotator)
{
	InRotator.Pitch = FRotator::NormalizeAxis(InRotator.Pitch);
	InRotator.Yaw = FRotator::NormalizeAxis(InRotator.Yaw);
	InRotator.Roll = FRotator::NormalizeAxis(InRotator.Roll);
}
