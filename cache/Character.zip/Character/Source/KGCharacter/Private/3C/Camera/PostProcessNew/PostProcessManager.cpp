#include "3C/Camera/PostProcessNew/PostProcessManager.h"

#include "3C/Core/KGUEActorManager.h"
#include "3C/Material/KGMaterialCommon.h"
#include "3C/Util/KGUtils.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPColorGradingMisc.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPDarken.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPDepthOfField.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPDirtMask.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPDummy.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPFilmGrain.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPLensFlares.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPMaterialBase.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPMaterialClip.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPMaterialFog.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPMaterialPhantom.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPMaterialSketch.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPNonMaterialBase.h"
#include "3C/Camera/PostProcessNew/PPPriorityQueue.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/Engine.h"
#include "Engine/StaticMesh.h"
#include "GameFramework/Character.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPChromaticAberrationByCameraArmLength.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPMaterialBlackFog.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPMaterialMultiTargetFog.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPPhotoContrast.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPPhotoExposure.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPPhotoFilter.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPPhotoSaturation.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPPhotoWhiteTemp.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPPhotoWhiteTint.h"

bool GDrawDebugPPOutputInfo = false;
static FAutoConsoleVariableRef CVarDrawDebugPPOutputInfo(
	TEXT("gp.DrawDebugPPOutputInfo"),
	GDrawDebugPPOutputInfo,
	TEXT("DrawKGMaterialManagerDebugInfo."),
	ECVF_Default
);

static FKGPPMaterialParams EmptyParams;

#define KG_PP_OVERRIDE_PP_SETTINGS(Param) \
	if (bOverride_##Param) \
	{ \
		PostProcessSettings.bOverride_##Param = true; \
		PostProcessSettings.Param = Param; \
	}

void UPostProcessManager::NativeInit()
{
	Super::NativeInit();

	using namespace NS_SLUA;
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartCommonPostProcessWithMaterial", &UPostProcessManager::KAPI_PostProcessManager_StartCommonPostProcessWithMaterial);
	REG_MANAGER_FUNC(UPostProcessManager, "InnerSetScalarParam", &UPostProcessManager::InnerSetScalarParam);
	REG_MANAGER_FUNC(UPostProcessManager, "InnerSetVectorParam", &UPostProcessManager::InnerSetVectorParam);
	REG_MANAGER_FUNC(UPostProcessManager, "InnerSetTextureParam", &UPostProcessManager::InnerSetTextureParam);
	REG_MANAGER_FUNC(UPostProcessManager, "InnerSetLinearSampleScalarParam", &UPostProcessManager::InnerSetLinearSampleScalarParam);
	REG_MANAGER_FUNC(UPostProcessManager, "InnerSetLinearBlendScalarParam", &UPostProcessManager::InnerSetLinearBlendScalarParam);
	REG_MANAGER_FUNC(UPostProcessManager, "InnerSetLinearSampleVectorParam", &UPostProcessManager::InnerSetLinearSampleVectorParam);
	REG_MANAGER_FUNC(UPostProcessManager, "InnerSetCurveParam", &UPostProcessManager::InnerSetCurveParam);
	REG_MANAGER_FUNC(UPostProcessManager, "InnerSetActorLocationParam", &UPostProcessManager::InnerSetActorLocationParam);
	REG_MANAGER_FUNC(UPostProcessManager, "InnerSetEntityLocationParam", &UPostProcessManager::InnerSetEntityLocationParam);
	REG_MANAGER_FUNC(UPostProcessManager, "ActivateCommonPostProcessWithMaterial", &UPostProcessManager::ActivateCommonPostProcessWithMaterial);
	
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartPhantomPP", &UPostProcessManager::KAPI_PostProcessManager_StartPhantomPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartBloomPP", &UPostProcessManager::KAPI_PostProcessManager_StartBloomPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartGIIndirectLightPP", &UPostProcessManager::KAPI_PostProcessManager_StartGIIndirectLightPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartChromaticAberrationPP", &UPostProcessManager::KAPI_PostProcessManager_StartChromaticAberrationPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartDirtMaskPP", &UPostProcessManager::KAPI_PostProcessManager_StartDirtMaskPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartLensFlaresPP", &UPostProcessManager::KAPI_PostProcessManager_StartLensFlaresPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartImageEffectsPP", &UPostProcessManager::KAPI_PostProcessManager_StartImageEffectsPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartColorGradingTemperaturePP", &UPostProcessManager::KAPI_PostProcessManager_StartColorGradingTemperaturePP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartColorGradingGlobalPP", &UPostProcessManager::KAPI_PostProcessManager_StartColorGradingGlobalPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartColorGradingShadowsPP", &UPostProcessManager::KAPI_PostProcessManager_StartColorGradingShadowsPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartColorGradingMidtonesPP", &UPostProcessManager::KAPI_PostProcessManager_StartColorGradingMidtonesPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartColorGradingHighlightsPP", &UPostProcessManager::KAPI_PostProcessManager_StartColorGradingHighlightsPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartColorGradingMiscPP", &UPostProcessManager::KAPI_PostProcessManager_StartColorGradingMiscPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartAutoExposureSpeedUpPP", &UPostProcessManager::KAPI_PostProcessManager_StartAutoExposureSpeedUpPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartFilmGrainPP", &UPostProcessManager::KAPI_PostProcessManager_StartFilmGrainPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartDarkenPP", &UPostProcessManager::KAPI_PostProcessManager_StartDarkenPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartDepthOfFieldPP", &UPostProcessManager::KAPI_PostProcessManager_StartDepthOfFieldPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartPhotoFilterPP", &UPostProcessManager::KAPI_PostProcessManager_StartPhotoFilterPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartPhotoContrastPP", &UPostProcessManager::KAPI_PostProcessManager_StartPhotoContrastPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartPhotoSaturationPP", &UPostProcessManager::KAPI_PostProcessManager_StartPhotoSaturationPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartPhotoWhiteTempPP", &UPostProcessManager::KAPI_PostProcessManager_StartPhotoWhiteTempPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartPhotoWhiteTintPP", &UPostProcessManager::KAPI_PostProcessManager_StartPhotoWhiteTintPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartPhotoExposurePP", &UPostProcessManager::KAPI_PostProcessManager_StartPhotoExposurePP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartSketchPP", &UPostProcessManager::KAPI_PostProcessManager_StartSketchPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartFogPP", &UPostProcessManager::KAPI_PostProcessManager_StartFogPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartClipPP", &UPostProcessManager::KAPI_PostProcessManager_StartClipPP);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartBlackFog", &UPostProcessManager::KAPI_PostProcessManager_StartBlackFog);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartMultiTargetFog", &UPostProcessManager::KAPI_PostProcessManager_StartMultiTargetFog);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_StartChromaticAberrationByCameraArmLengthPP", &UPostProcessManager::KAPI_PostProcessManager_StartChromaticAberrationByCameraArmLengthPP);
	
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_InterruptPostProcess", &UPostProcessManager::KAPI_PostProcessManager_InterruptPostProcess);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_InterruptPostProcessByPPTag", &UPostProcessManager::KAPI_PostProcessManager_InterruptPostProcessByPPTag);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_InterruptPostProcessByType", &UPostProcessManager::KAPI_PostProcessManager_InterruptPostProcessByType);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_InterruptPostProcessByPPTypeAndSourceType", &UPostProcessManager::KAPI_PostProcessManager_InterruptPostProcessByPPTypeAndSourceType);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_RemovePPInstancesOnLeaveSpace", &UPostProcessManager::KAPI_PostProcessManager_RemovePPInstancesOnLeaveSpace);
	
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_AddPPConfig", &UPostProcessManager::KAPI_PostProcessManager_AddPPConfig);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_ClearPPConfigs", &UPostProcessManager::KAPI_PostProcessManager_ClearPPConfigs);
	REG_MANAGER_FUNC(UPostProcessManager, "SetPPBlendOutTimeOnInterrupt", &UPostProcessManager::SetPPBlendOutTimeOnInterrupt);
	REG_MANAGER_FUNC(UPostProcessManager, "UpdatePostProcessQuality", &UPostProcessManager::UpdatePostProcessQuality);
	REG_MANAGER_FUNC(UPostProcessManager, "KPAI_PostProcessManager_GeneratePPID", &UPostProcessManager::KPAI_PostProcessManager_GeneratePPID);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_SetPlaneMeshInfo", &UPostProcessManager::KAPI_PostProcessManager_SetPlaneMeshInfo);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_SetEnablePlaneMeshPostProcess", &UPostProcessManager::KAPI_PostProcessManager_SetEnablePlaneMeshPostProcess);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_SetUseViewportPlaneMeshHandler", &UPostProcessManager::KAPI_PostProcessManager_SetUseViewportPlaneMeshHandler);
	
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_DisablePostProcess", &UPostProcessManager::KAPI_PostProcessManager_DisablePostProcess);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_DisablePostProcessBySourceType", &UPostProcessManager::KAPI_PostProcessManager_DisablePostProcessBySourceType);
	
	REG_MANAGER_FUNC(UPostProcessManager, "GetPPInstanceIDByPPType", &UPostProcessManager::GetPPInstanceIDByPPType);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_SetEntityCustomDepth", &UPostProcessManager::KAPI_PostProcessManager_SetEntityCustomDepth);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_RevertEntityCustomDepth", &UPostProcessManager::KAPI_PostProcessManager_RevertEntityCustomDepth);
	REG_MANAGER_FUNC(UPostProcessManager, "UpdateActorLocationMaterialParam", &UPostProcessManager::UpdateActorLocationMaterialParam);
	REG_MANAGER_FUNC(UPostProcessManager, "UpdateEntityLocationMaterialParam", &UPostProcessManager::UpdateEntityLocationMaterialParam);
	REG_MANAGER_FUNC(UPostProcessManager, "RemoveActorLocationMaterialParam", &UPostProcessManager::RemoveActorLocationMaterialParam);
	REG_MANAGER_FUNC(UPostProcessManager, "RemoveEntityLocationMaterialParam", &UPostProcessManager::RemoveEntityLocationMaterialParam);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_SetManualBlendWeight", &UPostProcessManager::KAPI_PostProcessManager_SetManualBlendWeight);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_ClearManualBlendWeight", &UPostProcessManager::KAPI_PostProcessManager_ClearManualBlendWeight);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_SetPhotoPPBlendWeight", &UPostProcessManager::KAPI_PostProcessManager_SetPhotoPPBlendWeight);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_AdvancePPTime", &UPostProcessManager::KAPI_PostProcessManager_AdvancePPTime);
	
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_UpdateFogParams", &UPostProcessManager::KAPI_PostProcessManager_UpdateFogParams);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_UpdateFogOpacity", &UPostProcessManager::KAPI_PostProcessManager_UpdateFogOpacity);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_UpdateFogTargetActorBySourceType", &UPostProcessManager::KAPI_PostProcessManager_UpdateFogTargetActorBySourceType);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_GetFogPPIDBySourceType", &UPostProcessManager::KAPI_PostProcessManager_GetFogPPIDBySourceType);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_UpdateBlackFogParams", &UPostProcessManager::KAPI_PostProcessManager_UpdateBlackFogParams);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_AddOrUpdateFogTarget", &UPostProcessManager::KAPI_PostProcessManager_AddOrUpdateFogTarget);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_RemoveFogTarget", &UPostProcessManager::KAPI_PostProcessManager_RemoveFogTarget);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_SetFogParamName", &UPostProcessManager::KAPI_PostProcessManager_SetFogParamName);
	
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_AddSketchChangeMaterialInfo", &UPostProcessManager::KAPI_PostProcessManager_AddSketchChangeMaterialInfo);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_AddSketchChangeMaterialParamInfo", &UPostProcessManager::KAPI_PostProcessManager_AddSketchChangeMaterialParamInfo);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_AddSketchTarget", &UPostProcessManager::KAPI_PostProcessManager_AddSketchTarget);
	REG_MANAGER_FUNC(UPostProcessManager, "KAPI_PostProcessManager_RemoveSketchTarget", &UPostProcessManager::KAPI_PostProcessManager_RemoveSketchTarget);
}

void UPostProcessManager::NativeUninit()
{
	TArray<uint32> PPIDs = NonDummyPostProcessInstanceIDs.Array();
	for (const auto PPID : PPIDs)
	{
		StopPostProcess(PPID, EKGPostProcessStopReason::GameFinished);
	}
	
	Super::NativeUninit();
}

void UPostProcessManager::Tick(float DeltaTime)
{
	TArray<uint32, TInlineAllocator<2>> PostProcessIDsAboutToFinish;
	for (const auto PPID : NonDummyPostProcessInstanceIDs)
	{
		auto PPInstance = GetPPInstance(PPID);
		check(PPInstance);

		PPInstance->DoTaskTick(DeltaTime);

		if (PPInstance->IsLifeTimeExpired())
		{
			PostProcessIDsAboutToFinish.Add(PPID);
		}
	}

	UpdatePostProcessBlendCache();

	if (PostProcessIDsAboutToFinish.Num() > 0)
	{
		for (const auto PPID : PostProcessIDsAboutToFinish)
		{
			StopPostProcess(PPID, EKGPostProcessStopReason::LifeTimeEnd);
		}
	}
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartCommonPostProcessWithMaterial(
	KG_PP_COMMON_PARAMS, EKGPostProcessType EffectType)
{
	return StartCommonPostProcessWithMaterial(KG_PP_COMMON_PARAMS_NAMES, EffectType, EmptyParams, true);
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartPhantomPP(
	KG_PP_COMMON_PARAMS,
	const FName& GapParamName, float Gap,
	const FName& SpeedParamName, float Speed,
	const FName& DirParamName, float DirR, float DirG, float DirB, float DirA,
	const FString& NiagaraPath, const FName& AttachSocketName, KGEntityID EntityID, EKGPostProcessQuality PostProcessQuality,
	int32 InCustomDepthLogicType, int32 CustomDepthPriority, int32 InCustomDepthStencilValue, uint32 InCustomPPID)
{
	auto* PPConfigPtr = PPConfigs.Find(EKGPostProcessType::KG_PP_Phantom);
	if (!PPConfigPtr)
	{
		UE_LOG(LogKGPP, Error, TEXT("KAPI_PostProcessManager_StartPhantomPP: No PPConfig found"));
		return KG_PP_INVALID_PPID;
	}
	
	if (EntityID == KG_INVALID_ENTITY_ID)
	{
		UE_LOG(LogKGPP, Error, TEXT("KAPI_PostProcessManager_StartPhantomPP: invalid entity id"));
		return KG_PP_INVALID_PPID;
	}
	
	auto* Entity = UKGUEActorManager::GetLuaEntity(this, EntityID);
	if (!Entity)
	{
		UE_LOG(LogKGPP, Error, TEXT("KAPI_PostProcessManager_StartPhantomPP: invalid entity %lld"), EntityID);
		return KG_PP_INVALID_PPID;
	}
	
	AActor* SpawnerActor = Entity->GetBindedActor();
	if (!SpawnerActor)
	{
		UE_LOG(LogKGPP, Error, TEXT("KAPI_PostProcessManager_StartPhantomPP, invalid actor of entity %lld"), EntityID);
		return KG_PP_INVALID_PPID;
	}

	USceneComponent* AttachComponent = nullptr;
	if (ACharacter* SpawnerCharacter = Cast<ACharacter>(SpawnerActor))
	{
		AttachComponent = SpawnerCharacter->GetMesh();
	}
	else
	{
		AttachComponent = SpawnerActor->GetComponentByClass<USkeletalMeshComponent>();
	}
	
	if (!AttachComponent)
	{
		UE_LOG(LogKGPP, Error, TEXT("KAPI_PostProcessManager_StartPhantomPP, invalid AttachComponent %s"), *SpawnerActor->GetName());
		return KG_PP_INVALID_PPID;
	}
	
	TSharedPtr<KGPPMaterialPhantom> PPMaterial;
	if (InCustomPPID == 0)
	{
		PPMaterial = MakeShared<KGPPMaterialPhantom>();
	}
	else
	{
		if (PostProcessInstances.Contains(InCustomPPID))
		{
			UE_LOG(LogKGPP, Error, TEXT("KAPI_PostProcessManager_StartPhantomPP, CustomPPID already in use %d"), InCustomPPID);
			return KG_PP_INVALID_PPID;
		}
		
		PPMaterial = MakeShared<KGPPMaterialPhantom>(InCustomPPID);
	}
	
	FKGPPMaterialParams MaterialParams;
	MaterialParams.ScalarParams.Add(GapParamName, Gap);
	MaterialParams.ScalarParams.Add(SpeedParamName, Speed);
	MaterialParams.VectorParams.Add(DirParamName, FLinearColor(DirR, DirG, DirB, DirA));
	
	PPMaterial->InitParams(
		FKGPPCommonParams(KG_PP_COMMON_PARAMS_NAMES),
		NiagaraPath, PostProcessQuality, AttachSocketName, SpawnerActor, AttachComponent,
		EntityID, InCustomDepthLogicType, CustomDepthPriority, InCustomDepthStencilValue,
		EKGPostProcessType::KG_PP_Phantom, PPConfigPtr->MaterialPath, PPConfigPtr->PlaneMeshMaterialPath,
		PPConfigPtr->ViewPriority, PPConfigPtr->IntensityParamName, MaterialParams, this);
	
	StartPostProcess(PPMaterial);
	return PPMaterial->GetPostProcessID();
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartFogPP(
	KG_PP_COMMON_PARAMS,
	float HeadInfoHideDistInMeters, bool bOverrideClimate, int32 OverrideClimateID, float BlendTimeSeconds,
	const FName& LocationBindParamName, KGEntityID LocationBindEntityID, KGActorID LocationBindActorID,
	const FName& FogOpacityParamName, float FogOpacityStartVal, float FogOpacityEndVal,
	const FName& MaxDistParamName, float MaxDistInMetersStartVal, float MaxDistInMetersEndVal,
	bool bOverrideFogColor, const FName& FogColorParamName, float FogColorR, float FogColorG, float FogColorB, float FogColorA,
	const FName& SmoothDistParamName, float SmoothDistInMetersStartVal, float SmoothDistInMetersEndVal)
{
	auto* PPConfigPtr = PPConfigs.Find(EKGPostProcessType::KG_PP_Fog);
	if (!PPConfigPtr)
	{
		UE_LOG(LogKGPP, Error, TEXT("KAPI_PostProcessManager_StartFogPP: No PPConfig found"));
		return KG_PP_INVALID_PPID;
	}
	
	FKGPPMaterialParams MaterialParams;
	if (bOverrideFogColor)
	{
		FLinearColor Color(FogColorR, FogColorG, FogColorB, FogColorA);
		check(!FVector4(Color).ContainsNaN());
		MaterialParams.VectorParams.Add(FogColorParamName, Color);
	}

	if (LocationBindEntityID != 0)
	{
		MaterialParams.EntityLocationParams.Add(LocationBindParamName, LocationBindEntityID);
	}
	else if (LocationBindActorID != 0)
	{
		if (AActor* LocationBindActor = KGUtils::GetActorByID(LocationBindActorID))
		{
			MaterialParams.ActorLocationParams.Add(LocationBindParamName, LocationBindActor);
		}
		else
		{
			UE_LOG(LogKGPP, Error, TEXT("StartFogPP, invalid LocationBindActorID %lld"), LocationBindActorID);
			return KG_PP_INVALID_PPID;
		}
	}
	
	ProcessLinearSampleParams(FogOpacityParamName, FogOpacityStartVal, FogOpacityEndVal, BlendTimeSeconds, MaterialParams);
	ProcessLinearSampleParams(MaxDistParamName, MaxDistInMetersStartVal, MaxDistInMetersEndVal, BlendTimeSeconds, MaterialParams);
	ProcessLinearSampleParams(SmoothDistParamName, SmoothDistInMetersStartVal, SmoothDistInMetersEndVal, BlendTimeSeconds, MaterialParams);
	
	TSharedPtr<KGPPMaterialFog> PPMaterial = MakeShared<KGPPMaterialFog>();
	PPMaterial->InitParams(
		FKGPPCommonParams(KG_PP_COMMON_PARAMS_NAMES),
		EKGPostProcessType::KG_PP_Fog, PPConfigPtr->MaterialPath, PPConfigPtr->PlaneMeshMaterialPath,
		PPConfigPtr->ViewPriority, PPConfigPtr->IntensityParamName, MaterialParams, this,
		bOverrideClimate, OverrideClimateID, MaxDistInMetersEndVal, HeadInfoHideDistInMeters, BlendTimeSeconds);
	
	StartPostProcess(PPMaterial);
	return PPMaterial->GetPostProcessID();
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartSketchPP(KG_PP_COMMON_PARAMS)
{
	auto* PPConfigPtr = PPConfigs.Find(EKGPostProcessType::KG_PP_Sketch);
	if (!PPConfigPtr)
	{
		UE_LOG(LogKGPP, Error, TEXT("KAPI_PostProcessManager_StartSketchPP: No PPConfig found"));
		return KG_PP_INVALID_PPID;
	}
	
	FKGPPMaterialParams MaterialParams;
	TSharedPtr<KGPPMaterialSketch> PPMaterial = MakeShared<KGPPMaterialSketch>();
	PPMaterial->InitParams(
		FKGPPCommonParams(KG_PP_COMMON_PARAMS_NAMES),
		EKGPostProcessType::KG_PP_Sketch, PPConfigPtr->MaterialPath, PPConfigPtr->PlaneMeshMaterialPath, PPConfigPtr->ViewPriority,
		PPConfigPtr->IntensityParamName, MaterialParams, this);
	
	StartPostProcess(PPMaterial);
	return PPMaterial->GetPostProcessID();
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartClipPP(
	KG_PP_COMMON_PARAMS,
	const FName& ClipColorParamName, float ColorR, float ColorG, float ColorB, float ColorA,
	const FName& BackgroundColorParamName, float BGColorR, float BGColorG, float BGColorB, float BGColorA)
{
	auto* PPConfigPtr = PPConfigs.Find(EKGPostProcessType::KG_PP_Clip);
	if (!PPConfigPtr)
	{
		UE_LOG(LogKGPP, Error, TEXT("KAPI_PostProcessManager_StartClipPP: No PPConfig found"));
		return KG_PP_INVALID_PPID;
	}
	
	FKGPPMaterialParams MaterialParams;
	FLinearColor Color(ColorR, ColorG, ColorB, ColorA);
	check(!FVector4(Color).ContainsNaN());
	MaterialParams.VectorParams.Add(ClipColorParamName, Color);
	
	FLinearColor BackgroundColor(BGColorR, BGColorG, BGColorB, BGColorA);
	check(!FVector4(BackgroundColor).ContainsNaN());
	MaterialParams.VectorParams.Add(BackgroundColorParamName, BackgroundColor);
	
	TSharedPtr<KGPPMaterialClip> PPMaterial = MakeShared<KGPPMaterialClip>();
	PPMaterial->InitParams(
		FKGPPCommonParams(KG_PP_COMMON_PARAMS_NAMES),
		EKGPostProcessType::KG_PP_Clip, PPConfigPtr->MaterialPath, PPConfigPtr->PlaneMeshMaterialPath, PPConfigPtr->ViewPriority,
		PPConfigPtr->IntensityParamName, MaterialParams, this);
	
	StartPostProcess(PPMaterial);
	return PPMaterial->GetPostProcessID();
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartBlackFog(
	KG_PP_COMMON_PARAMS,
	float BlendTimeSeconds, KGEntityID PlayerEntityID, KGEntityID BossEntityID,
	bool bOverrideCenterPos, float CenterPosX, float CenterPosY, float CenterPosZ,
	bool bOverrideFogOpacity, float FogOpacity,
	bool bOverrideFogColor, float FogColorR, float FogColorG, float FogColorB, float FogColorA,
	bool bOverrideSmoothDist, float SmoothDistInMeters,
	EKGFogShapeType ShapeType, float CircleRadius, float RingPercent, float RingOuterRadius,
	float CrossLength, float CrossWidth, float HalfFieldWidth, bool bOverrideRangeSpawnRotation, float RangeSpawnRotation)
{
	auto* PPConfigPtr = PPConfigs.Find(EKGPostProcessType::KG_PP_BlackFog);
	if (!PPConfigPtr)
	{
		UE_LOG(LogKGPP, Error, TEXT("KAPI_PostProcessManager_StartBlackFog: No PPConfig found"));
		return KG_PP_INVALID_PPID;
	}

	if (FMath::IsNearlyZero(BlendTimeSeconds))
	{
		UE_LOG(LogKGPP, Error, TEXT("KAPI_PostProcessManager_StartBlackFog: invalid blend time"));
		return KG_PP_INVALID_PPID;
	}
	
	FVector CenterPos(CenterPosX, CenterPosY, CenterPosZ);
	if (CenterPos.ContainsNaN())
	{
		UE_LOG(LogKGPP, Error, TEXT("KAPI_PostProcessManager_StartBlackFog: CenterPos invalid"));
		return KG_PP_INVALID_PPID;
	}
	
	FLinearColor FogColor(FogColorR, FogColorG, FogColorB, FogColorA);
	if (FVector4(FogColor).ContainsNaN())
	{
		UE_LOG(LogKGPP, Error, TEXT("KAPI_PostProcessManager_StartBlackFog: FogColor invalid"));
		return KG_PP_INVALID_PPID;
	}
	
	FKGPPMaterialParams MaterialParams;
	if (PlayerEntityID != 0)
	{
		MaterialParams.EntityLocationParams.Add(FogParams.PlayerPosParamName, PlayerEntityID);
	}

	if (BossEntityID != 0)
	{
		MaterialParams.EntityLocationParams.Add(FogParams.BossPosParamName, BossEntityID);
	}

	TSharedPtr<KGPPMaterialBlackFog> PPMaterial = MakeShared<KGPPMaterialBlackFog>();
	PPMaterial->InitParams(
		FKGPPCommonParams(KG_PP_COMMON_PARAMS_NAMES),
		EKGPostProcessType::KG_PP_BlackFog, PPConfigPtr->MaterialPath, PPConfigPtr->PlaneMeshMaterialPath,
		PPConfigPtr->ViewPriority, PPConfigPtr->IntensityParamName, MaterialParams, this, FogParams);
	
	PPMaterial->UpdateBlackFogParams(
		BlendTimeSeconds, bOverrideCenterPos, CenterPos, bOverrideFogOpacity, FogOpacity, bOverrideFogColor, FogColor,
		bOverrideSmoothDist, SmoothDistInMeters,
		ShapeType, CircleRadius, RingPercent, RingOuterRadius,
		CrossLength, CrossWidth, HalfFieldWidth,
		bOverrideRangeSpawnRotation, RangeSpawnRotation);
	
	StartPostProcess(PPMaterial);
	return PPMaterial->GetPostProcessID();
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartMultiTargetFog(
	KG_PP_COMMON_PARAMS,
	float HeadInfoHideDistInMeters, float BlendTimeSeconds, int32 MaxTargetNum,
	const FName& LocationBindParamName, KGEntityID LocationBindEntityID, 
	const FName& FogOpacityParamName, float FogOpacityStartVal, float FogOpacityEndVal,
	const FName& MaxDistParamName, float MaxDistInMetersStartVal, float MaxDistInMetersEndVal,
	bool bOverrideFogColor, const FName& FogColorParamName, float FogColorR, float FogColorG, float FogColorB, float FogColorA,
	const FName& SmoothDistParamName, float SmoothDistInMetersStartVal, float SmoothDistInMetersEndVal)
{
	auto* PPConfigPtr = PPConfigs.Find(EKGPostProcessType::KG_PP_MultiTargetFog);
	if (!PPConfigPtr)
	{
		UE_LOG(LogKGPP, Error, TEXT("KAPI_PostProcessManager_StartFogPP: No PPConfig found"));
		return KG_PP_INVALID_PPID;
	}
	
	FKGPPMaterialParams MaterialParams;
	if (bOverrideFogColor)
	{
		FLinearColor Color(FogColorR, FogColorG, FogColorB, FogColorA);
		check(!FVector4(Color).ContainsNaN());
		MaterialParams.VectorParams.Add(FogColorParamName, Color);
	}

	if (LocationBindEntityID != 0)
	{
		MaterialParams.EntityLocationParams.Add(LocationBindParamName, LocationBindEntityID);
	}
	
	ProcessLinearSampleParams(FogOpacityParamName, FogOpacityStartVal, FogOpacityEndVal, BlendTimeSeconds, MaterialParams);
	ProcessLinearSampleParams(MaxDistParamName, MaxDistInMetersStartVal, MaxDistInMetersEndVal, BlendTimeSeconds, MaterialParams);
	ProcessLinearSampleParams(SmoothDistParamName, SmoothDistInMetersStartVal, SmoothDistInMetersEndVal, BlendTimeSeconds, MaterialParams);
	
	TSharedPtr<KGPPMaterialMultiTargetFog> PPMaterial = MakeShared<KGPPMaterialMultiTargetFog>();
	PPMaterial->InitParams(
		FKGPPCommonParams(KG_PP_COMMON_PARAMS_NAMES),
		EKGPostProcessType::KG_PP_MultiTargetFog, PPConfigPtr->MaterialPath, PPConfigPtr->PlaneMeshMaterialPath,
		PPConfigPtr->ViewPriority, PPConfigPtr->IntensityParamName, MaterialParams, this,
		BlendTimeSeconds, MaxDistInMetersEndVal, HeadInfoHideDistInMeters, MaxTargetNum);
	
	StartPostProcess(PPMaterial);
	return PPMaterial->GetPostProcessID();
}

void UPostProcessManager::InnerSetScalarParam(uint32 PPID, const FName& ParamName, float ParamVal)
{
	if (KGPPMaterialBase* MaterialPPInstance = GetMaterialPPInstance(PPID))
	{
		MaterialPPInstance->UpdateScalarParam(ParamName, ParamVal);
	}
}

void UPostProcessManager::InnerSetVectorParam(uint32 PPID, const FName& ParamName, float R, float G, float B, float A)
{
	if (KGPPMaterialBase* MaterialPPInstance = GetMaterialPPInstance(PPID))
	{
		MaterialPPInstance->UpdateVectorParam(ParamName, FLinearColor(R, G, B, A));
	}
}

void UPostProcessManager::InnerSetTextureParam(uint32 PPID, const FName& ParamName, const FString& TexturePath)
{
	if (KGPPMaterialBase* MaterialPPInstance = GetMaterialPPInstance(PPID))
	{
		MaterialPPInstance->GetTextureParams().Add(ParamName, TexturePath);
	}
}

void UPostProcessManager::InnerSetLinearSampleScalarParam(uint32 PPID, const FName& ParamName, float StartVal, float EndVal, float Duration)
{
	if (FMath::IsNearlyZero(Duration))
	{
		UE_LOG(LogKGPP, Error, TEXT("UPostProcessManager::InnerSetLinearSampleScalarParam, Duration is nearly zero for Param %s, PPID: %d"),
			*ParamName.ToString(), PPID);
		return;
	}
	
	if (KGPPMaterialBase* MaterialPPInstance = GetMaterialPPInstance(PPID))
	{
		FKGLinearSampleParams<float> LinearSampleParams;
		LinearSampleParams.StartVal = StartVal;
		LinearSampleParams.EndVal = EndVal;
		LinearSampleParams.Duration = Duration;
		MaterialPPInstance->GetScalarLinearSampleParams().Add(ParamName, LinearSampleParams);
	}
}

void UPostProcessManager::InnerSetLinearSampleVectorParam(
	uint32 PPID, const FName& ParamName, float StartR, float StartG, float StartB, float StartA, float EndR, float EndG, float EndB, float EndA, float Duration)
{
	if (FMath::IsNearlyZero(Duration))
	{
		UE_LOG(LogKGPP, Error, TEXT("UPostProcessManager::InnerSetLinearSampleVectorParam, Duration is nearly zero for Param %s, PPID: %d"),
			*ParamName.ToString(), PPID);
		return;
	}
	
	if (KGPPMaterialBase* MaterialPPInstance = GetMaterialPPInstance(PPID))
	{
		FKGLinearSampleParams<FLinearColor> LinearSampleParams;
		LinearSampleParams.StartVal = FLinearColor(StartR, StartG, StartB, StartA);
		LinearSampleParams.EndVal = FLinearColor(EndR, EndG, EndB, EndA);
		LinearSampleParams.Duration = Duration;
		MaterialPPInstance->GetVectorLinearSampleParams().Add(ParamName, LinearSampleParams);
	}
}

void UPostProcessManager::InnerSetLinearBlendScalarParam(uint32 PPID, const FName& ParamName, float StartVal, float EndVal, float BlendInTime, float BlendOutTime, float Duration)
{
	if (FMath::IsNearlyZero(Duration) || (BlendInTime + BlendOutTime - Duration > UE_KINDA_SMALL_NUMBER))
	{
		UE_LOG(LogKGPP, Error,
			TEXT("UPostProcessManager::InnerSetLinearBlendScalarParam, invalid blend time %s, PPID: %d, BlendInTime: %f, BlendOutTime: %f, Duration: %f"),
			*ParamName.ToString(), PPID, BlendInTime, BlendOutTime, Duration);
		return;
	}
	
	if (KGPPMaterialBase* MaterialPPInstance = GetMaterialPPInstance(PPID))
	{
		FKGLinearBlendInAndBlendOutParams<float> LinearBlendParams;
		LinearBlendParams.StartVal = StartVal;
		LinearBlendParams.EndVal = EndVal;
		LinearBlendParams.BlendInTime = BlendInTime;
		LinearBlendParams.BlendOutTime = BlendOutTime;
		LinearBlendParams.Duration = Duration;
		MaterialPPInstance->GetScalarLinearBlendParams().Add(ParamName, LinearBlendParams);
	}
}

void UPostProcessManager::InnerSetCurveParam(uint32 PPID, const FName& ParamName, const FString& CurvePath, bool bNeedRemap, float RemapTime, bool bLoop)
{
	if (KGPPMaterialBase* MaterialPPInstance = GetMaterialPPInstance(PPID))
	{
		FKGCurveParams CurveParam;
		CurveParam.CurvePath = CurvePath;
		CurveParam.bNeedRemap = bNeedRemap;
		CurveParam.RemapTime = RemapTime;
		CurveParam.bLoop = bLoop;
		MaterialPPInstance->GetCurveParams().Add(ParamName, CurveParam);
	}
}

void UPostProcessManager::InnerSetActorLocationParam(uint32 PPID, const FName& ParamName, KGObjectID ActorId)
{
	AActor* Actor = KGUtils::GetActorByID(ActorId);
	if (!Actor)
	{
		UE_LOG(LogKGPP, Error, TEXT("UPostProcessManager::InnerAddActorLocationParam, invalid actor %lld"), ActorId);
		return;
	}
	
	if (KGPPMaterialBase* MaterialPPInstance = GetMaterialPPInstance(PPID))
	{
		MaterialPPInstance->UpdateActorLocationParam(ParamName, Actor);
	}
}

void UPostProcessManager::InnerSetEntityLocationParam(uint32 PPID, const FName& ParamName, KGEntityID EntityID)
{
	if (KGPPMaterialBase* MaterialPPInstance = GetMaterialPPInstance(PPID))
	{
		MaterialPPInstance->UpdateEntityLocationParams(ParamName, EntityID);
	}
}

void UPostProcessManager::ActivateCommonPostProcessWithMaterial(uint32 PPID)
{
	if (PostProcessInstances.Contains(PPID))
	{
		StartPostProcess(PostProcessInstances[PPID]);
	}
}

uint32 UPostProcessManager::StartCommonPostProcessWithMaterial(
	KG_PP_COMMON_PARAMS, EKGPostProcessType EffectType, const FKGPPMaterialParams& Params, bool bManualActivated)
{
	auto* PPConfigPtr = PPConfigs.Find(EffectType);
	if (!PPConfigPtr)
	{
		UE_LOG(LogKGPP, Error, TEXT("ScriptStartCommonPostProcessWithMaterial failed, invalid PPType %d"), EffectType);
		return KG_PP_INVALID_PPID;
	}
	
	// 所有common material post process实现类都使用 PPMaterialBase
	int32 ViewPriority = GetPPViewPriority(EffectType);
	TSharedPtr<KGPPMaterialBase> PPInstance = MakeShared<KGPPMaterialBase>();
	PPInstance->InitParams(
		FKGPPCommonParams(KG_PP_COMMON_PARAMS_NAMES), EffectType, PPConfigPtr->MaterialPath, PPConfigPtr->PlaneMeshMaterialPath, ViewPriority,
		PPConfigPtr->IntensityParamName, Params, this);
	
	const auto PPID = PPInstance->GetPostProcessID();
	if (!bManualActivated)
	{
		StartPostProcess(PPInstance);
	}
	else
	{
		PostProcessInstances.Add(PPID, PPInstance);
		NonDummyPostProcessInstanceIDs.Add(PPID);
	}
	
	return PPInstance->GetPostProcessID();
}

void UPostProcessManager::InterruptPostProcess(uint32 PPID, bool bOverrideBlendOutTime, float NewBlendOutTime)
{
	StopPostProcess(PPID, EKGPostProcessStopReason::ExternalInterrupt, bOverrideBlendOutTime, NewBlendOutTime);
}

void UPostProcessManager::InterruptPostProcessByPPTag(uint32 PPTag, bool bOverrideBlendOutTime, float NewBlendOutTime)
{
	TArray<uint32> PPIDs = NonDummyPostProcessInstanceIDs.Array();
	for (const auto PPID : PPIDs)
	{
		auto PPInstance = GetPPInstance(PPID);
		check(PPInstance);

		if (PPInstance->GetPPTags().Contains(PPTag))
		{
			UE_LOG(LogKGPP, Log, TEXT("UPostProcessManager::InterruptPostProcessByPPTag, PPID %s"), *PPInstance->GetDebugInfo());
			InterruptPostProcess(PPID, bOverrideBlendOutTime, NewBlendOutTime);
		}
	}
}

void UPostProcessManager::InterruptPostProcessByType(EKGPostProcessType PPType, bool bOverrideBlendOutTime, float NewBlendOutTime)
{
	TArray<uint32> PPIDs = NonDummyPostProcessInstanceIDs.Array();
	for (const auto PPID : PPIDs)
	{
		auto PPInstance = GetPPInstance(PPID);
		check(PPInstance);

		if (PPInstance->GetPPType() == PPType)
		{
			UE_LOG(LogKGPP, Log, TEXT("UPostProcessManager::InterruptPostProcessByType, PPID %s"), *PPInstance->GetDebugInfo());
			InterruptPostProcess(PPID, bOverrideBlendOutTime, NewBlendOutTime);
		}
	}
}

void UPostProcessManager::InterruptPostProcessByPPTypeAndSourceType(EKGPostProcessType PPType, uint32 SourceType, bool bOverrideBlendOutTime, float NewBlendOutTime)
{
	TArray<uint32> PPIDs = NonDummyPostProcessInstanceIDs.Array();
	for (const auto PPID : PPIDs)
	{
		auto PPInstance = GetPPInstance(PPID);
		check(PPInstance);

		if (PPInstance->GetPPType() == PPType && PPInstance->GetSourceType() == SourceType)
		{
			UE_LOG(LogKGPP, Log, TEXT("UPostProcessManager::InterruptPostProcessByPPTypeAndSourceType, PPID %s"), *PPInstance->GetDebugInfo());
			InterruptPostProcess(PPID, bOverrideBlendOutTime, NewBlendOutTime);
		}
	}
}

void UPostProcessManager::RemovePPInstancesOnLeaveSpace()
{
	TArray<uint32> PPIDs = NonDummyPostProcessInstanceIDs.Array();
	for (const auto PPID : PPIDs)
	{
		auto PPInstance = GetPPInstance(PPID);
		check(PPInstance);

		if (PPInstance->ShouldDestroyWhenLeaveSpace())
		{
			UE_LOG(LogKGPP, Log, TEXT("UPostProcessManager::RemovePPInstancesOnLeaveSpace, PPID %s"), *PPInstance->GetDebugInfo());
			StopPostProcess(PPID, EKGPostProcessStopReason::LeaveSpace);
		}
	}
}

void UPostProcessManager::StopPostProcess(uint32 PPID, EKGPostProcessStopReason StopReason, bool bOverrideBlendOutTime, float NewBlendOutTime)
{
	TSharedPtr<KGPPBase> PPInstance = GetPPInstanceSharedPtr(PPID);
	if (!PPInstance.IsValid())
	{
		UE_LOG(LogKGPP, Log, TEXT("UPostProcessManager::StopPostProcess failed, invalid PPID %d"), PPID);
		return;
	}

	UE_LOG(LogKGPP, Log, TEXT("UPostProcessManager::StopPostProcess, PPID %d, StopReason %d"), PPID, (int32)StopReason);
	
	if (StopReason == EKGPostProcessStopReason::ExternalInterrupt && PPInstance->CanInterruptedBlendOut())
	{
		if (InternalBlendOutPostProcess(PPInstance, bOverrideBlendOutTime, NewBlendOutTime, EKGPostProcessBlendReason::TaskInterrupted))
		{
			if (PPInstance->GetPostProcessState() == EKGPostProcessState::InterruptedBlendingOut_PendingDeactivated)
			{
				RemovePostProcessPriorityInfo(PPInstance);	
			}
			return;
		}
	}
	
	InternalStopPostProcess(PPID, StopReason);
}

void UPostProcessManager::KAPI_PostProcessManager_AddPPConfig(
	EKGPostProcessType PPType, const FString& TypeName, const TArray<EKGPostProcessType>& ConflictTypes,
	int32 ViewPriority, const FString& MaterialPath, const FString& PlaneMeshMaterialPath, const FName& IntensityParamName)
{
	auto& PPConfig = PPConfigs.FindOrAdd(PPType);
	PPConfig.TypeName = TypeName;
	PPConfig.ConflictTypes = ConflictTypes;
	PPConfig.ViewPriority = ViewPriority;
	PPConfig.MaterialPath = MaterialPath;
	PPConfig.PlaneMeshMaterialPath = PlaneMeshMaterialPath;
	PPConfig.IntensityParamName = IntensityParamName;
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartBloomPP(
	KG_PP_COMMON_PARAMS,
	bool bOverride_BloomMethod, int32 InBloomMethod, bool bOverride_BloomIntensity,
	float BloomIntensity, bool bOverride_BloomThreshold, float BloomThreshold, bool bOverride_BloomSizeScale, float BloomSizeScale)
{
	FPostProcessSettings PostProcessSettings;
	EBloomMethod BloomMethod = static_cast<TEnumAsByte<enum EBloomMethod>>(InBloomMethod);
	KG_PP_OVERRIDE_PP_SETTINGS(BloomMethod)
	KG_PP_OVERRIDE_PP_SETTINGS(BloomIntensity)
	KG_PP_OVERRIDE_PP_SETTINGS(BloomThreshold)
	KG_PP_OVERRIDE_PP_SETTINGS(BloomSizeScale)
	return StartCommonPostProcess(
		KG_PP_COMMON_PARAMS_NAMES, EKGPostProcessType::KG_PP_Bloom, PostProcessSettings);
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartGIIndirectLightPP(
	KG_PP_COMMON_PARAMS,
	bool bOverride_IndirectLightingColor, float IndirectLightingColorR, float IndirectLightingColorG,
	float IndirectLightingColorB, float IndirectLightingColorA, bool bOverride_IndirectLightingIntensity, float IndirectLightingIntensity)
{
	FPostProcessSettings PostProcessSettings;
	FLinearColor IndirectLightingColor(IndirectLightingColorR, IndirectLightingColorG, IndirectLightingColorB, IndirectLightingColorA);
	KG_PP_OVERRIDE_PP_SETTINGS(IndirectLightingColor)
	KG_PP_OVERRIDE_PP_SETTINGS(IndirectLightingIntensity)
	
	return StartCommonPostProcess(
		KG_PP_COMMON_PARAMS_NAMES, EKGPostProcessType::KG_PP_GI_IndirectLight, PostProcessSettings);
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartChromaticAberrationPP(
	KG_PP_COMMON_PARAMS,
	bool bOverride_SceneFringeIntensity, float SceneFringeIntensity, bool bOverride_ChromaticAberrationStartOffset, float ChromaticAberrationStartOffset)
{
	FPostProcessSettings PostProcessSettings;
	KG_PP_OVERRIDE_PP_SETTINGS(SceneFringeIntensity)
	KG_PP_OVERRIDE_PP_SETTINGS(ChromaticAberrationStartOffset)
	return StartCommonPostProcess(
		KG_PP_COMMON_PARAMS_NAMES, EKGPostProcessType::KG_PP_ChromaticAberration, PostProcessSettings);
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartChromaticAberrationByCameraArmLengthPP(
	KG_PP_COMMON_PARAMS, float InMinCameraArmLength, float InMaxCameraArmLength, float InMinChromaticAberrationIntensity, float InMaxChromaticAberrationIntensity)
{
	if (InMinCameraArmLength > InMaxCameraArmLength || FMath::IsNearlyEqual(InMinCameraArmLength, InMaxCameraArmLength))
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::KAPI_PostProcessManager_StartChromaticAberrationByCameraArmLengthPP, invalid camera arm length %f, %f"),
			InMinCameraArmLength, InMaxCameraArmLength);
		return KG_PP_INVALID_PPID;
	}
	
	TSharedPtr<KGPPChromaticAberrationByCameraArmLength> PPInstance = MakeShared<KGPPChromaticAberrationByCameraArmLength>();
	PPInstance->InitParams(
		FKGPPCommonParams(KG_PP_COMMON_PARAMS_NAMES), this, EKGPostProcessType::KG_PP_ChromaticAberrationByCameraArmLength, 
		InMinCameraArmLength, InMaxCameraArmLength, InMinChromaticAberrationIntensity, InMaxChromaticAberrationIntensity);
	StartPostProcess(PPInstance);
	return PPInstance->GetPostProcessID();
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartDirtMaskPP(
	KG_PP_COMMON_PARAMS,
	bool bOverride_BloomDirtMask, const FString& BloomDirtMaskTexturePath,
	bool bOverride_BloomDirtMaskIntensity, float BloomDirtMaskIntensity,
	bool bOverride_BloomDirtMaskTint, float BloomDirtMaskTintR, float BloomDirtMaskTintG, float BloomDirtMaskTintB, float BloomDirtMaskTintA)
{
	FPostProcessSettings PostProcessSettings;
	PostProcessSettings.bOverride_BloomDirtMask = bOverride_BloomDirtMask;
	KG_PP_OVERRIDE_PP_SETTINGS(BloomDirtMaskIntensity)
	FLinearColor BloomDirtMaskTint(BloomDirtMaskTintR, BloomDirtMaskTintG, BloomDirtMaskTintB, BloomDirtMaskTintA);
	KG_PP_OVERRIDE_PP_SETTINGS(BloomDirtMaskTint)

	TSharedPtr<KGPPDirtMask> PPInstance = MakeShared<KGPPDirtMask>();
	PPInstance->InitParams(
		FKGPPCommonParams(KG_PP_COMMON_PARAMS_NAMES), this, EKGPostProcessType::KG_PP_DirtMask, PostProcessSettings, BloomDirtMaskTexturePath);
	StartPostProcess(PPInstance);
	return PPInstance->GetPostProcessID();
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartLensFlaresPP(
    KG_PP_COMMON_PARAMS,
    bool bOverride_LensFlareIntensity, float LensFlareIntensity,
    bool bOverride_LensFlareTint, float LensFlareTintR, float LensFlareTintG, float LensFlareTintB, float LensFlareTintA,
    bool bOverride_LensFlareBokehSize, float LensFlareBokehSize,
    bool bOverride_LensFlareThreshold, float LensFlareThreshold,
    bool bOverride_LensFlareBokehShape, const FString& LensFlareBokehShapePath,
    bool bOverride_LensFlareTints, const TArray<float>& LensFlareTints,
    bool bOverride_LensFlareScales, const TArray<float>& LensFlareScales)
{
    FPostProcessSettings PostProcessSettings;
    PostProcessSettings.bOverride_LensFlareTints = bOverride_LensFlareTints;
	if (bOverride_LensFlareTints)
	{
		if (LensFlareTints.Num() != KG_PP_LENS_FLARES_TINTS_NUM * 4)
		{
			UE_LOG(LogKGPP, Error, TEXT("UPostProcessManager::KAPI_PostProcessManager_StartLensFlaresPP, invalid LensFlareTints num, %d"), LensFlareTints.Num());
			return KG_PP_INVALID_PPID;
		}
		
		for (int32 i = 0; i < KG_PP_LENS_FLARES_TINTS_NUM; i++)
		{
			PostProcessSettings.LensFlareTints[i] = FLinearColor(LensFlareTints[4*i], LensFlareTints[4*i+1], LensFlareTints[4*i+2], LensFlareTints[4*i+3]);
			check(!FVector4(PostProcessSettings.LensFlareTints[i]).ContainsNaN());
		}
	}

    PostProcessSettings.bOverride_LensFlareScales = bOverride_LensFlareScales;
	if (bOverride_LensFlareScales)
	{
		if (LensFlareScales.Num() != KG_PP_LENS_FLARES_TINTS_NUM)
		{
			UE_LOG(LogKGPP, Error, TEXT("UPostProcessManager::KAPI_PostProcessManager_StartLensFlaresPP, invalid LensFlareScales num, %d"), LensFlareScales.Num());
			return KG_PP_INVALID_PPID;
		}
		
		for (int32 i = 0; i < KG_PP_LENS_FLARES_TINTS_NUM; i++)
		{
			PostProcessSettings.LensFlareScales[i] = LensFlareScales[i];
		}
	}
	
	KG_PP_OVERRIDE_PP_SETTINGS(LensFlareIntensity)
	FLinearColor LensFlareTint(LensFlareTintR, LensFlareTintG, LensFlareTintB, LensFlareTintA);
	KG_PP_OVERRIDE_PP_SETTINGS(LensFlareTint)
	KG_PP_OVERRIDE_PP_SETTINGS(LensFlareBokehSize)
	KG_PP_OVERRIDE_PP_SETTINGS(LensFlareThreshold)
	PostProcessSettings.bOverride_LensFlareBokehShape = bOverride_LensFlareBokehShape;
	
	TSharedPtr<KGPPLensFlares> PPInstance = MakeShared<KGPPLensFlares>();
	PPInstance->InitParams(
		FKGPPCommonParams(KG_PP_COMMON_PARAMS_NAMES), this, EKGPostProcessType::KG_PP_LensFlares, PostProcessSettings, LensFlareBokehShapePath);
	StartPostProcess(PPInstance);
	return PPInstance->GetPostProcessID();
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartImageEffectsPP(
	KG_PP_COMMON_PARAMS,
	bool bOverride_VignetteIntensity, float VignetteIntensity,
	bool bOverride_Sharpen, float Sharpen)
{
	FPostProcessSettings PostProcessSettings;
	KG_PP_OVERRIDE_PP_SETTINGS(VignetteIntensity)
	KG_PP_OVERRIDE_PP_SETTINGS(Sharpen)

	return StartCommonPostProcess(
		KG_PP_COMMON_PARAMS_NAMES, EKGPostProcessType::KG_PP_ImageEffects, PostProcessSettings);
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartColorGradingTemperaturePP(
	KG_PP_COMMON_PARAMS,
	bool bOverride_TemperatureType, int32 InTemperatureType,
	bool bOverride_WhiteTemp, float WhiteTemp,
	bool bOverride_WhiteTint, float WhiteTint)
{
	FPostProcessSettings PostProcessSettings;
	ETemperatureMethod TemperatureType = static_cast<ETemperatureMethod>(InTemperatureType);
	KG_PP_OVERRIDE_PP_SETTINGS(TemperatureType)
	KG_PP_OVERRIDE_PP_SETTINGS(WhiteTemp)
	KG_PP_OVERRIDE_PP_SETTINGS(WhiteTint)

	return StartCommonPostProcess(
		KG_PP_COMMON_PARAMS_NAMES, EKGPostProcessType::KG_PP_ColorGradingTemperature, PostProcessSettings);
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartColorGradingGlobalPP(
    KG_PP_COMMON_PARAMS,
    bool bOverride_ColorSaturation, float ColorSaturationR, float ColorSaturationG, float ColorSaturationB, float ColorSaturationA,
    bool bOverride_ColorContrast, float ColorContrastR, float ColorContrastG, float ColorContrastB, float ColorContrastA,
    bool bOverride_ColorGamma, float ColorGammaR, float ColorGammaG, float ColorGammaB, float ColorGammaA,
    bool bOverride_ColorGain, float ColorGainR, float ColorGainG, float ColorGainB, float ColorGainA,
    bool bOverride_ColorOffset, float ColorOffsetR, float ColorOffsetG, float ColorOffsetB, float ColorOffsetA)
{
    FPostProcessSettings PostProcessSettings;
	FVector4 ColorSaturation(ColorSaturationR, ColorSaturationG, ColorSaturationB, ColorSaturationA);
	KG_PP_OVERRIDE_PP_SETTINGS(ColorSaturation)
	FVector4 ColorContrast(ColorContrastR, ColorContrastG, ColorContrastB, ColorContrastA);
	KG_PP_OVERRIDE_PP_SETTINGS(ColorContrast)
	FVector4 ColorGamma(ColorGammaR, ColorGammaG, ColorGammaB, ColorGammaA);
	KG_PP_OVERRIDE_PP_SETTINGS(ColorGamma)
	FVector4 ColorGain(ColorGainR, ColorGainG, ColorGainB, ColorGainA);
	KG_PP_OVERRIDE_PP_SETTINGS(ColorGain)
	FVector4 ColorOffset(ColorOffsetR, ColorOffsetG, ColorOffsetB, ColorOffsetA);
	KG_PP_OVERRIDE_PP_SETTINGS(ColorOffset)
	
    return StartCommonPostProcess(
        KG_PP_COMMON_PARAMS_NAMES, EKGPostProcessType::KG_PP_ColorGradingGlobal, PostProcessSettings);
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartColorGradingShadowsPP(
	KG_PP_COMMON_PARAMS,
	bool bOverride_ColorSaturationShadows, float ColorSaturationShadowsR, float ColorSaturationShadowsG, float ColorSaturationShadowsB, float ColorSaturationShadowsA,
	bool bOverride_ColorContrastShadows, float ColorContrastShadowsR, float ColorContrastShadowsG, float ColorContrastShadowsB, float ColorContrastShadowsA,
	bool bOverride_ColorGammaShadows, float ColorGammaShadowsR, float ColorGammaShadowsG, float ColorGammaShadowsB, float ColorGammaShadowsA,
	bool bOverride_ColorGainShadows, float ColorGainShadowsR, float ColorGainShadowsG, float ColorGainShadowsB, float ColorGainShadowsA,
	bool bOverride_ColorOffsetShadows, float ColorOffsetShadowsR, float ColorOffsetShadowsG, float ColorOffsetShadowsB, float ColorOffsetShadowsA)
{
	FPostProcessSettings PostProcessSettings;
	FVector4 ColorSaturationShadows(ColorSaturationShadowsR, ColorSaturationShadowsG, ColorSaturationShadowsB, ColorSaturationShadowsA);
	KG_PP_OVERRIDE_PP_SETTINGS(ColorSaturationShadows)
	FVector4 ColorContrastShadows(ColorContrastShadowsR, ColorContrastShadowsG, ColorContrastShadowsB, ColorContrastShadowsA);
	KG_PP_OVERRIDE_PP_SETTINGS(ColorContrastShadows)
	FVector4 ColorGammaShadows(ColorGammaShadowsR, ColorGammaShadowsG, ColorGammaShadowsB, ColorGammaShadowsA);
	KG_PP_OVERRIDE_PP_SETTINGS(ColorGammaShadows)
	FVector4 ColorGainShadows(ColorGainShadowsR, ColorGainShadowsG, ColorGainShadowsB, ColorGainShadowsA);
	KG_PP_OVERRIDE_PP_SETTINGS(ColorGainShadows)
	FVector4 ColorOffsetShadows(ColorOffsetShadowsR, ColorOffsetShadowsG, ColorOffsetShadowsB, ColorOffsetShadowsA);
	KG_PP_OVERRIDE_PP_SETTINGS(ColorOffsetShadows)

	return StartCommonPostProcess(
		KG_PP_COMMON_PARAMS_NAMES,
		EKGPostProcessType::KG_PP_ColorGradingShadows, PostProcessSettings);
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartColorGradingMidtonesPP(
    KG_PP_COMMON_PARAMS,
    bool bOverride_ColorSaturationMidtones, float ColorSaturationMidtonesR, float ColorSaturationMidtonesG, float ColorSaturationMidtonesB, float ColorSaturationMidtonesA,
    bool bOverride_ColorContrastMidtones, float ColorContrastMidtonesR, float ColorContrastMidtonesG, float ColorContrastMidtonesB, float ColorContrastMidtonesA,
    bool bOverride_ColorGammaMidtones, float ColorGammaMidtonesR, float ColorGammaMidtonesG, float ColorGammaMidtonesB, float ColorGammaMidtonesA,
    bool bOverride_ColorGainMidtones, float ColorGainMidtonesR, float ColorGainMidtonesG, float ColorGainMidtonesB, float ColorGainMidtonesA,
    bool bOverride_ColorOffsetMidtones, float ColorOffsetMidtonesR, float ColorOffsetMidtonesG, float ColorOffsetMidtonesB, float ColorOffsetMidtonesA)
{
    FPostProcessSettings PostProcessSettings;
	FVector4 ColorSaturationMidtones(ColorSaturationMidtonesR, ColorSaturationMidtonesG, ColorSaturationMidtonesB, ColorSaturationMidtonesA);
	KG_PP_OVERRIDE_PP_SETTINGS(ColorSaturationMidtones)
	FVector4 ColorContrastMidtones(ColorContrastMidtonesR, ColorContrastMidtonesG, ColorContrastMidtonesB, ColorContrastMidtonesA);
	KG_PP_OVERRIDE_PP_SETTINGS(ColorContrastMidtones)
	FVector4 ColorGammaMidtones(ColorGammaMidtonesR, ColorGammaMidtonesG, ColorGammaMidtonesB, ColorGammaMidtonesA);
	KG_PP_OVERRIDE_PP_SETTINGS(ColorGammaMidtones)
	FVector4 ColorGainMidtones(ColorGainMidtonesR, ColorGainMidtonesG, ColorGainMidtonesB, ColorGainMidtonesA);
	KG_PP_OVERRIDE_PP_SETTINGS(ColorGainMidtones)
	FVector4 ColorOffsetMidtones(ColorOffsetMidtonesR, ColorOffsetMidtonesG, ColorOffsetMidtonesB, ColorOffsetMidtonesA);
	KG_PP_OVERRIDE_PP_SETTINGS(ColorOffsetMidtones)
	
    return StartCommonPostProcess(
        KG_PP_COMMON_PARAMS_NAMES,
        EKGPostProcessType::KG_PP_ColorGradingMidtones, PostProcessSettings);
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartColorGradingHighlightsPP(
    KG_PP_COMMON_PARAMS,
    bool bOverride_ColorSaturationHighlights, float ColorSaturationHighlightsR, float ColorSaturationHighlightsG, float ColorSaturationHighlightsB, float ColorSaturationHighlightsA,
    bool bOverride_ColorContrastHighlights, float ColorContrastHighlightsR, float ColorContrastHighlightsG, float ColorContrastHighlightsB, float ColorContrastHighlightsA,
    bool bOverride_ColorGammaHighlights, float ColorGammaHighlightsR, float ColorGammaHighlightsG, float ColorGammaHighlightsB, float ColorGammaHighlightsA,
    bool bOverride_ColorGainHighlights, float ColorGainHighlightsR, float ColorGainHighlightsG, float ColorGainHighlightsB, float ColorGainHighlightsA,
    bool bOverride_ColorOffsetHighlights, float ColorOffsetHighlightsR, float ColorOffsetHighlightsG, float ColorOffsetHighlightsB, float ColorOffsetHighlightsA,
    bool bOverride_ColorCorrectionHighlightsMin, float ColorCorrectionHighlightsMin,
    bool bOverride_ColorCorrectionHighlightsMax, float ColorCorrectionHighlightsMax)
{
    FPostProcessSettings PostProcessSettings;
	FVector4 ColorSaturationHighlights(ColorSaturationHighlightsR, ColorSaturationHighlightsG, ColorSaturationHighlightsB, ColorSaturationHighlightsA);
	KG_PP_OVERRIDE_PP_SETTINGS(ColorSaturationHighlights)
	FVector4 ColorContrastHighlights(ColorContrastHighlightsR, ColorContrastHighlightsG, ColorContrastHighlightsB, ColorContrastHighlightsA);
	KG_PP_OVERRIDE_PP_SETTINGS(ColorContrastHighlights)
	FVector4 ColorGammaHighlights(ColorGammaHighlightsR, ColorGammaHighlightsG, ColorGammaHighlightsB, ColorGammaHighlightsA);
	KG_PP_OVERRIDE_PP_SETTINGS(ColorGammaHighlights)
	FVector4 ColorGainHighlights(ColorGainHighlightsR, ColorGainHighlightsG, ColorGainHighlightsB, ColorGainHighlightsA);
	KG_PP_OVERRIDE_PP_SETTINGS(ColorGainHighlights)
	FVector4 ColorOffsetHighlights(ColorOffsetHighlightsR, ColorOffsetHighlightsG, ColorOffsetHighlightsB, ColorOffsetHighlightsA);
	KG_PP_OVERRIDE_PP_SETTINGS(ColorOffsetHighlights)
	KG_PP_OVERRIDE_PP_SETTINGS(ColorCorrectionHighlightsMin)
	KG_PP_OVERRIDE_PP_SETTINGS(ColorCorrectionHighlightsMax)
	
    return StartCommonPostProcess(
        KG_PP_COMMON_PARAMS_NAMES,
        EKGPostProcessType::KG_PP_ColorGradingHighlights, PostProcessSettings);
}


uint32 UPostProcessManager::KAPI_PostProcessManager_StartColorGradingMiscPP(
	KG_PP_COMMON_PARAMS,
	bool bOverride_ColorGradingIntensity, float ColorGradingIntensity,
	bool bOverride_ColorGradingLUT, const FString& ColorGradingLUTPath)
{
	FPostProcessSettings PostProcessSettings;
	KG_PP_OVERRIDE_PP_SETTINGS(ColorGradingIntensity)
	
	PostProcessSettings.bOverride_ColorGradingLUT = bOverride_ColorGradingLUT;
	
	TSharedPtr<KGPPColorGradingMisc> PPInstance = MakeShared<KGPPColorGradingMisc>();
	PPInstance->InitParams(
		FKGPPCommonParams(KG_PP_COMMON_PARAMS_NAMES), this, EKGPostProcessType::KG_PP_ColorGradingMisc, PostProcessSettings, ColorGradingLUTPath);
	StartPostProcess(PPInstance);
	return PPInstance->GetPostProcessID();
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartFilmGrainPP(
    KG_PP_COMMON_PARAMS,
    bool bOverride_FilmGrainIntensity, float FilmGrainIntensity,
    bool bOverride_FilmGrainIntensityShadows, float FilmGrainIntensityShadows,
    bool bOverride_FilmGrainIntensityMidtones, float FilmGrainIntensityMidtones,
    bool bOverride_FilmGrainIntensityHighlights, float FilmGrainIntensityHighlights,
    bool bOverride_FilmGrainShadowsMax, float FilmGrainShadowsMax,
    bool bOverride_FilmGrainHighlightsMin, float FilmGrainHighlightsMin,
    bool bOverride_FilmGrainHighlightsMax, float FilmGrainHighlightsMax,
    bool bOverride_FilmGrainTexelSize, float FilmGrainTexelSize,
    bool bOverride_FilmGrainTexture, const FString& FilmGrainTexturePath)
{
    FPostProcessSettings PostProcessSettings;
	KG_PP_OVERRIDE_PP_SETTINGS(FilmGrainIntensity)
	KG_PP_OVERRIDE_PP_SETTINGS(FilmGrainIntensityShadows)
	KG_PP_OVERRIDE_PP_SETTINGS(FilmGrainIntensityMidtones)
	KG_PP_OVERRIDE_PP_SETTINGS(FilmGrainIntensityHighlights)
	KG_PP_OVERRIDE_PP_SETTINGS(FilmGrainShadowsMax)
	KG_PP_OVERRIDE_PP_SETTINGS(FilmGrainHighlightsMin)
	KG_PP_OVERRIDE_PP_SETTINGS(FilmGrainHighlightsMax)
	KG_PP_OVERRIDE_PP_SETTINGS(FilmGrainTexelSize)
    PostProcessSettings.bOverride_FilmGrainTexture = bOverride_FilmGrainTexture;

	TSharedPtr<KGPPFilmGrain> PPInstance = MakeShared<KGPPFilmGrain>();
	PPInstance->InitParams(
		FKGPPCommonParams(KG_PP_COMMON_PARAMS_NAMES), this, EKGPostProcessType::KG_PP_FilmGrain, PostProcessSettings, FilmGrainTexturePath);
	StartPostProcess(PPInstance);
	return PPInstance->GetPostProcessID();
}


uint32 UPostProcessManager::KAPI_PostProcessManager_StartDarkenPP(
	KG_PP_COMMON_PARAMS,
	float BaseExposureBias,
	bool bOverride_AdditionalAutoExposureBias, float AdditionalAutoExposureBias, bool bOverride_AutoExposureBias, float AutoExposureBias)
{
	if (bOverride_AdditionalAutoExposureBias == bOverride_AutoExposureBias)
	{
		UE_LOG(LogKGPP, Error, TEXT("UPostProcessManager::StartDarkenPP failed, need to use either additional mode or normal mode"));
		return KG_PP_INVALID_PPID;
	}
	
	FPostProcessSettings PostProcessSettings;
	KG_PP_OVERRIDE_PP_SETTINGS(AdditionalAutoExposureBias)
	KG_PP_OVERRIDE_PP_SETTINGS(AutoExposureBias)

	TSharedPtr<KGPPDarken> PPInstance = MakeShared<KGPPDarken>();
	PPInstance->InitParams(
		FKGPPCommonParams(KG_PP_COMMON_PARAMS_NAMES),
		this, EKGPostProcessType::KG_PP_Darken, PostProcessSettings, BaseExposureBias);
	
	StartPostProcess(PPInstance);
	return PPInstance->GetPostProcessID();
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartDepthOfFieldPP(
	KG_PP_COMMON_PARAMS,
	bool bMobileHQGaussian, float FocalRegion, bool bMobileCustomTransition, float NearTransitionRegion, float FarTransitionRegion, float Scale, float NearBlurSize, float FarBlurSize,
	float DepthOfFieldFstop, float DepthOfFieldMinFstop, int32 DepthOfFieldBladeCount, float SensorWidth, float SqueezeFactor, float FocalDistance,
	float DepthBlurAmount, float DepthBlurRadius, float FocalDistanceOffset,
	bool bUseActorID, KGObjectID FocalActorID, KGEntityID FocalEntityID, const FName& SocketName)
{
	FKGDepthOfFieldParams DepthOfFieldParams;
	DepthOfFieldParams.bMobileHQGaussian = bMobileHQGaussian;
	DepthOfFieldParams.FocalRegion = FocalRegion;
	DepthOfFieldParams.bMobileCustomTransition = bMobileCustomTransition;
	DepthOfFieldParams.NearTransitionRegion = NearTransitionRegion;
	DepthOfFieldParams.FarTransitionRegion = FarTransitionRegion;
	DepthOfFieldParams.Scale = Scale;
	DepthOfFieldParams.NearBlurSize = NearBlurSize;
	DepthOfFieldParams.FarBlurSize = FarBlurSize;
	DepthOfFieldParams.DepthOfFieldFstop = DepthOfFieldFstop;
	DepthOfFieldParams.DepthOfFieldMinFstop = DepthOfFieldMinFstop;
	DepthOfFieldParams.DepthOfFieldBladeCount = DepthOfFieldBladeCount;
	DepthOfFieldParams.SensorWidth = SensorWidth;
	DepthOfFieldParams.SqueezeFactor = SqueezeFactor;
	DepthOfFieldParams.FocalDistance = FocalDistance;
	DepthOfFieldParams.DepthBlurAmount = DepthBlurAmount;
	DepthOfFieldParams.DepthBlurRadius = DepthBlurRadius;
	DepthOfFieldParams.FocalDistanceOffset = FocalDistanceOffset;
	DepthOfFieldParams.SocketName = SocketName;

	if (bUseActorID)
	{
		DepthOfFieldParams.FocalTarget = KGUtils::GetActorByID(FocalActorID);
	}
	else
	{
		DepthOfFieldParams.FocalEntityID = FocalEntityID;
	}
	
	TSharedPtr<KGPPDepthOfField> PPInstance = MakeShared<KGPPDepthOfField>();
	PPInstance->InitParams(
		FKGPPCommonParams(KG_PP_COMMON_PARAMS_NAMES), this, EKGPostProcessType::KG_PP_DepthOfField, DepthOfFieldParams);
	StartPostProcess(PPInstance);
	return PPInstance->GetPostProcessID();
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartPhotoFilterPP(
	KG_PP_COMMON_PARAMS,
	const FString& PhotoFilterAssetPath)
{
	TSharedPtr<KGPPPhotoFilter> PPInstance = MakeShared<KGPPPhotoFilter>();
	PPInstance->InitParams(
		FKGPPCommonParams(KG_PP_COMMON_PARAMS_NAMES), this, EKGPostProcessType::KG_PP_PhotoFilters, PhotoFilterAssetPath);
	StartPostProcess(PPInstance);
	return PPInstance->GetPostProcessID();
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartPhotoContrastPP(KG_PP_COMMON_PARAMS, const FString& ColorContrastCurvePath)
{
	TSharedPtr<KGPPPhotoContrast> PPInstance = MakeShared<KGPPPhotoContrast>();
	PPInstance->InitParams(
		FKGPPCommonParams(KG_PP_COMMON_PARAMS_NAMES), this, EKGPostProcessType::KG_PP_PhotoContrast, ColorContrastCurvePath);
	StartPostProcess(PPInstance);
	return PPInstance->GetPostProcessID();
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartPhotoSaturationPP(KG_PP_COMMON_PARAMS, const FString& ColorSaturationCurvePath)
{
	TSharedPtr<KGPPPhotoSaturation> PPInstance = MakeShared<KGPPPhotoSaturation>();
	PPInstance->InitParams(
		FKGPPCommonParams(KG_PP_COMMON_PARAMS_NAMES), this, EKGPostProcessType::KG_PP_PhotoSaturation, ColorSaturationCurvePath);
	StartPostProcess(PPInstance);
	return PPInstance->GetPostProcessID();
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartPhotoWhiteTempPP(KG_PP_COMMON_PARAMS, const FString& WhiteTempCurvePath)
{
	TSharedPtr<KGPPPhotoWhiteTemp> PPInstance = MakeShared<KGPPPhotoWhiteTemp>();
	PPInstance->InitParams(
		FKGPPCommonParams(KG_PP_COMMON_PARAMS_NAMES), this, EKGPostProcessType::KG_PP_PhotoWhiteTemp, WhiteTempCurvePath);
	StartPostProcess(PPInstance);
	return PPInstance->GetPostProcessID();
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartPhotoWhiteTintPP(KG_PP_COMMON_PARAMS, const FString& WhiteTintCurvePath)
{
	TSharedPtr<KGPPPhotoWhiteTint> PPInstance = MakeShared<KGPPPhotoWhiteTint>();
	PPInstance->InitParams(
		FKGPPCommonParams(KG_PP_COMMON_PARAMS_NAMES), this, EKGPostProcessType::KG_PP_PhotoWhiteTint, WhiteTintCurvePath);
	StartPostProcess(PPInstance);
	return PPInstance->GetPostProcessID();
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartPhotoExposurePP(KG_PP_COMMON_PARAMS, const FString& ExposureCurvePath, float InBaseExposureBias)
{
	TSharedPtr<KGPPPhotoExposure> PPInstance = MakeShared<KGPPPhotoExposure>();
	PPInstance->InitParams(
		FKGPPCommonParams(KG_PP_COMMON_PARAMS_NAMES), this, EKGPostProcessType::KG_PP_PhotoExposure, ExposureCurvePath, InBaseExposureBias);
	StartPostProcess(PPInstance);
	return PPInstance->GetPostProcessID();
}

uint32 UPostProcessManager::KAPI_PostProcessManager_StartAutoExposureSpeedUpPP(KG_PP_COMMON_PARAMS, float AutoExposureSpeedUp)
{
	FPostProcessSettings PostProcessSettings;
	PostProcessSettings.bOverride_AutoExposureSpeedUp = true;
	PostProcessSettings.AutoExposureSpeedUp = AutoExposureSpeedUp;
	
	return StartCommonPostProcess(
		KG_PP_COMMON_PARAMS_NAMES, EKGPostProcessType::KG_PP_AutoExposureSpeedUp, PostProcessSettings);
}

uint32 UPostProcessManager::StartCommonPostProcess(
	KG_PP_COMMON_PARAMS, EKGPostProcessType EffectType, const FPostProcessSettings& PostProcessSettings)
{
	// 所有common material post process实现类都使用 PPMaterialBase
	TSharedPtr<KGPPNonMaterialBase> PPNonMaterial = MakeShared<KGPPNonMaterialBase>();
	PPNonMaterial->InitParams(
		FKGPPCommonParams(KG_PP_COMMON_PARAMS_NAMES), this, EffectType, PostProcessSettings);
	
	const auto PPID = PPNonMaterial->GetPostProcessID();
	StartPostProcess(PPNonMaterial);
	
	return PPID;
}

void UPostProcessManager::StartPostProcess(TSharedPtr<KGPPBase> PPInstance)
{
	if (!PPInstance.IsValid())
	{
		UE_LOG(LogKGPP, Error, TEXT("UPostProcessManager::StartPostProcess failed, invalid PPInstance"));
		return;
	}

	UE_LOG(LogKGPP, Log, TEXT("UPostProcessManager::StartPostProcess, %s"), *PPInstance->GetDebugInfo());

	RemoveInterruptedBlendingOutPostProcess(PPInstance);
	
	PPInstance->DoTaskStart();
	const auto PPID = PPInstance->GetPostProcessID();
	const bool bIsPPDisabledBySourceType = DisabledPostProcessSourceTypes.Contains(PPInstance->GetSourceType());
	const bool bIsPPDisabled = bPostProcessDisabled || bIsPPDisabledBySourceType;
	if (bIsPPDisabled)
	{
		if (bPostProcessDisabled)
		{
			PPInstance->AddDisableReason(EKGPostProcessDisableReason::GlobalDisable);
		}
		if (bIsPPDisabledBySourceType)
		{
			PPInstance->AddDisableReason(EKGPostProcessDisableReason::SourceTypeDisable);
		}
	}
	else
	{
		AddPostProcessPriorityInfo(PPInstance);
	}
	
	if (!PostProcessInstances.Contains(PPID))
	{
		PostProcessInstances.Add(PPID, PPInstance);
	}
	if (!NonDummyPostProcessInstanceIDs.Contains(PPID))
	{
		NonDummyPostProcessInstanceIDs.Add(PPID);
	}
}

float UPostProcessManager::GetPlaneMeshDistance(KGPPMaterialBase* NewPPInstance)
{
	if (!NewPPInstance)
	{
		UE_LOG(LogKGPP, Error, TEXT("UPostProcessManager::GetPlaneMeshDistance, invalid pp instance found"));
		return 0.0f;
	}
	
	// 计算PPID对应的pp instance合适的plane mesh distance, 优先级越高, 同优先级下后加的后处理, plane mesh对应的位置越靠近相机(更靠前渲染)
	// 这里跟后处理中 PostProcessSettings 的排序规则是一致的
	TArray<KGPPMaterialBase*> ActiveMaterialInstances;
	GetPlaneMeshPPMaterialInstances(ActiveMaterialInstances);
	ActiveMaterialInstances.AddUnique(NewPPInstance);

	if (ActiveMaterialInstances.Num() == 1)
	{
		return (PlaneMeshMinDist + PlaneMeshMaxDist) * 0.5f; // 如果只有一个PP, 那么直接返回中间值
	}
	
	Algo::Sort(ActiveMaterialInstances, [](KGPPMaterialBase* PP1, KGPPMaterialBase* PP2) {
		if (PP1->GetViewPriority() == PP2->GetViewPriority())
		{
			return PP1->GetSequenceID() > PP2->GetSequenceID();
		}
		return PP1->GetViewPriority() > PP2->GetViewPriority();
	});

	for (int32 i = 0; i < ActiveMaterialInstances.Num(); ++i)
	{
		const auto& MaterialPP = ActiveMaterialInstances[i];
		check(MaterialPP);
		if (MaterialPP == NewPPInstance)
		{
			float MinDist = ActiveMaterialInstances.IsValidIndex(i - 1) ? ActiveMaterialInstances[i - 1]->GetPlaneMeshDistance() : PlaneMeshMinDist;
			float MaxDist = ActiveMaterialInstances.IsValidIndex(i + 1) ? ActiveMaterialInstances[i + 1]->GetPlaneMeshDistance() : PlaneMeshMaxDist;
			UE_CLOG(FMath::IsNearlyZero(MinDist) || FMath::IsNearlyZero(MaxDist), LogKGPP, Error,
				TEXT("UPostProcessManager::GetPlaneMeshDistance, invalid plane mesh distance, %f, %f, %s"), MinDist, MaxDist, *MaterialPP->GetDebugInfo());
			return (MinDist + MaxDist) * 0.5f;
		}
	}

	UE_LOG(LogKGPP, Error, TEXT("UPostProcessManager::GetPlaneMeshDistance, PPID %s not found in active material instances"), *NewPPInstance->GetDebugInfo());
	return 0.0f;
}

void UPostProcessManager::KAPI_PostProcessManager_SetPlaneMeshInfo(
	const FString& AssetPath, float MinDist, float MaxDist, float Pitch, float Yaw, float Roll, float ScaleX, float ScaleY, float ScaleZ)
{
	// init阶段同步加载, 加载后不卸载
	if (!AssetPath.IsEmpty())
	{
		PlaneMeshAsset = Cast<UStaticMesh>(StaticLoadObject(UStaticMesh::StaticClass(), nullptr, *AssetPath));
	}

	PlaneMeshMinDist = MinDist;
	PlaneMeshMaxDist = MaxDist;
	PlaneMeshRotation = FRotator(Pitch, Yaw, Roll);
	PlaneMeshScale = FVector(ScaleX, ScaleY, ScaleZ);
}

void UPostProcessManager::GetCachedPostProcessBlends(TArray<FPostProcessSettings> const*& OutPPSettings, TArray<float> const*& OutBlendWeights) const
{
	OutPPSettings = &PostProcessBlendCache;
	OutBlendWeights = &PostProcessBlendCacheWeights;
}

void UPostProcessManager::GetCachedPostProcessBlends(TArray<FPostProcessSettings>& OutPPSettings, TArray<float>& OutBlendWeights, TArray<EViewTargetBlendOrder>& OutBlendOrders) const
{
	OutPPSettings = PostProcessBlendCache;
	OutBlendWeights = PostProcessBlendCacheWeights;
	OutBlendOrders = PostProcessBlendCacheOrders;
}

void UPostProcessManager::AccumulateCachedPostProcessBlends(TArray<FPostProcessSettings>& OutPPSettings, TArray<float>& OutBlendWeights, TArray<EViewTargetBlendOrder>& OutBlendOrders) const
{
	OutPPSettings.Append(PostProcessBlendCache);
	OutBlendWeights.Append(PostProcessBlendCacheWeights);
	OutBlendOrders.Append(PostProcessBlendCacheOrders);
}

void UPostProcessManager::UpdatePostProcessQuality(EKGPostProcessQuality PostProcessQuality)
{
	UE_LOG(LogKGPP, Log, TEXT("UPostProcessManager::UpdatePostProcessQuality, %d"), PostProcessQuality);
	CurrentPostProcessQuality = PostProcessQuality;
	OnPostProcessQualityChanged.Broadcast(CurrentPostProcessQuality);
}

bool UPostProcessManager::InternalBlendOutPostProcess(TSharedPtr<KGPPBase> PPInstance, bool bOverrideBlendOutTime, float NewBlendOutTime, EKGPostProcessBlendReason InBlendReason)
{
	if (!PPInstance.IsValid())
	{
		UE_LOG(LogKGPP, Error, TEXT("UPostProcessManager::BlendOutPostProcess failed, invalid PPInstance"));
		return false;
	}

	UE_LOG(LogKGPP, Log, TEXT("UPostProcessManager::BlendOutPostProcess, %s, %d, %f, %d"), 
		*PPInstance->GetDebugInfo(), bOverrideBlendOutTime, NewBlendOutTime, InBlendReason);
	
	return PPInstance->StartBlendOutPP(bOverrideBlendOutTime, NewBlendOutTime, InBlendReason);
}

void UPostProcessManager::RemoveInterruptedBlendingOutPostProcess(TSharedPtr<KGPPBase> PPInstance)
{
	if (!PPInstance.IsValid())
	{
		UE_LOG(LogKGPP, Error, TEXT("UPostProcessManager::RemoveBlendingOutPostProcess failed, invalid PPInstance"));
		return;
	}

	if (PPInstance->CanActivateMultiPPInstance())
	{
		return;
	}

	if (NonDummyPostProcessInstanceIDs.Num() == 0)
	{
		return;
	}

	const auto NewPPType = PPInstance->GetPPType();
	const auto NewPPID = PPInstance->GetPostProcessID();
	TSet<EKGPostProcessType> ConflictedPPTypes;
	if (PPConfigs.Contains(NewPPType))
	{
		ConflictedPPTypes.Append(PPConfigs[NewPPType].ConflictTypes);
	}

	TArray<uint32> PPIDsNeedToRemove;
	for (const auto PPID : NonDummyPostProcessInstanceIDs)
	{
		if (PPID == NewPPID)
		{
			continue;
		}

		KGPPBase* OtherPPInstance = GetPPInstance(PPID);
		if (!OtherPPInstance)
		{
			continue;
		}

		const auto OtherPPType = OtherPPInstance->GetPPType();
		if (OtherPPInstance->IsInInterruptedBlendOut() && (OtherPPType == NewPPType || ConflictedPPTypes.Contains(OtherPPType)))
		{
			PPIDsNeedToRemove.Add(PPID);
		}
	}

	for (const auto PPID : PPIDsNeedToRemove)
	{
		UE_LOG(LogKGPP, Log, TEXT("UPostProcessManager::RemoveInterruptedBlendingOutPostProcess, remove interrupted blending out pp, %d"), PPID);
		StopPostProcess(PPID, EKGPostProcessStopReason::PriorityOccupy);
	}
}

void UPostProcessManager::DisablePostProcess(bool bDisable)
{
	UE_LOG(LogKGPP, Log, TEXT("UPostProcessManager::DisablePostProcess, bPostProcessDisabled: %d, bDisable: %d"), bPostProcessDisabled, bDisable);
	if (bPostProcessDisabled == bDisable)
	{
		// 如果当前状态跟目标状态一致, 则不需要做任何操作
		return;
	}
	
	bPostProcessDisabled = bDisable;
	for (const auto PPID : NonDummyPostProcessInstanceIDs)
	{
		TSharedPtr<KGPPBase> PPInstance = GetPPInstanceSharedPtr(PPID);
		if (!PPInstance.IsValid())
		{
			UE_LOG(LogKGPP, Error, TEXT("UPostProcessManager::DisablePostProcess, no active PP instance found for ID %d"), PPID);
			continue;
		}

		InternalUpdatePostProcessDisableState(PPInstance, bPostProcessDisabled, EKGPostProcessDisableReason::GlobalDisable);
	}
}

void UPostProcessManager::DisablePostProcessBySourceType(uint32 SourceType, bool bDisable)
{
	const bool bSourceTypeDisabled = DisabledPostProcessSourceTypes.Contains(SourceType);

	UE_LOG(LogKGPP, Log,
		TEXT("UPostProcessManager::DisablePostProcessBySourceType, SourceType: %d, bSourceTypeDisabled: %d, bDisable: %d"),
		SourceType, bSourceTypeDisabled, bDisable);
	
	if (bSourceTypeDisabled == bDisable)
	{
		// 如果当前状态跟目标状态一致, 则不需要做任何操作
		return;
	}

	if (bDisable)
	{
		DisabledPostProcessSourceTypes.Add(SourceType);
	}
	else
	{
		DisabledPostProcessSourceTypes.Remove(SourceType);
	}

	for (const auto PPID : NonDummyPostProcessInstanceIDs)
	{
		TSharedPtr<KGPPBase> PPInstance = GetPPInstanceSharedPtr(PPID);
		if (!PPInstance.IsValid())
		{
			UE_LOG(LogKGPP, Error, TEXT("UPostProcessManager::DisablePostProcessBySourceType, no active PP instance found for ID %d"), PPID);
			continue;
		}

		if (PPInstance->GetSourceType() != SourceType)
		{
			// 如果PPInstance的SourceType跟当前操作的SourceType不一致, 则不需要更新Disable状态
			continue;
		}

		InternalUpdatePostProcessDisableState(PPInstance, bDisable, EKGPostProcessDisableReason::SourceTypeDisable);
	}
}

void UPostProcessManager::KAPI_PostProcessManager_SetPhotoPPBlendWeight(uint32 PPID, float BlendWeight)
{
	auto PPInstance = GetPPInstance(PPID);
	if (!PPInstance)
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::KAPI_PostProcessManager_SetPhotoPPBlendWeight, no active PP instance found, %d"), PPID);
		return;
	}

	if (!PPInstance->IsNonMaterialPP())
	{
		UE_LOG(LogKGPP, Warning,
			TEXT("UPostProcessManager::KAPI_PostProcessManager_SetPhotoPPBlendWeight, only support non-material PP, %s"), *PPInstance->GetDebugInfo());
		return;
	}

	KGPPNonMaterialBase* NonMaterialPP = static_cast<KGPPNonMaterialBase*>(PPInstance);
	if (NonMaterialPP->HasManualWeightCurve())
	{
		NonMaterialPP->SetManualWeightCurveValue(BlendWeight);
	}
	else
	{
		NonMaterialPP->SetManualBlendWeight(BlendWeight);	
	}
}

void UPostProcessManager::KAPI_PostProcessManager_SetManualBlendWeight(uint32 PPID, float BlendWeight)
{
	auto PPInstance = GetPPInstance(PPID);
	if (!PPInstance)
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::KAPI_PostProcessManager_SetManualBlendWeight, no active PP instance found, %d"), PPID);
		return;
	}

	if (!PPInstance->IsNonMaterialPP())
	{
		UE_LOG(LogKGPP, Warning,
			TEXT("UPostProcessManager::KAPI_PostProcessManager_SetManualBlendWeight, only support non-material PP, %s"), *PPInstance->GetDebugInfo());
		return;
	}

	KGPPNonMaterialBase* NonMaterialPP = static_cast<KGPPNonMaterialBase*>(PPInstance);
	NonMaterialPP->SetManualBlendWeight(BlendWeight);
}

void UPostProcessManager::KAPI_PostProcessManager_ClearManualBlendWeight(uint32 PPID)
{
	auto PPInstance = GetPPInstance(PPID);
	if (!PPInstance)
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::KAPI_PostProcessManager_ClearManualBlendWeight, no active PP instance found, %d"), PPID);
		return;
	}

	if (!PPInstance->IsNonMaterialPP())
	{
		UE_LOG(LogKGPP, Warning,
			TEXT("UPostProcessManager::KAPI_PostProcessManager_ClearManualBlendWeight, only support non-material PP, %s"), *PPInstance->GetDebugInfo());
		return;
	}

	KGPPNonMaterialBase* NonMaterialPP = static_cast<KGPPNonMaterialBase*>(PPInstance);
	NonMaterialPP->ClearManualBlendWeight();
}

void UPostProcessManager::KAPI_PostProcessManager_SetEntityCustomDepth(
	uint32 PPID, KGEntityID EntityID, int32 LogicType, int32 Priority, bool bEnableClip, int32 CustomDepthStencilValue, bool bNiagaraRenderCustomDepth)
{
	auto PPInstance = GetPPInstance(PPID);
	if (!PPInstance)
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::SetEntityCustomDepth, no active PP instance found"));
		return;
	}

	UE_LOG(LogKGPP, Log,
		TEXT("UPostProcessManager::SetEntityCustomDepth, PPID: %d, EntityID: %lld, LogicType: %d, Priority: %d, bEnableClip: %d, CustomDepthStencilValue: %d, bNiagaraRenderCustomDepth: %d"),
		PPID, EntityID, LogicType, Priority, bEnableClip, CustomDepthStencilValue, bNiagaraRenderCustomDepth);
	
	PPInstance->SetEntityCustomDepth(EntityID, LogicType, Priority, bEnableClip, CustomDepthStencilValue, bNiagaraRenderCustomDepth);
}

void UPostProcessManager::KAPI_PostProcessManager_RevertEntityCustomDepth(uint32 PPID, KGEntityID EntityID)
{
	auto PPInstance = GetPPInstance(PPID);
	if (!PPInstance)
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::RevertEntityCustomDepth, no active PP instance found"));
		return;
	}

	UE_LOG(LogKGPP, Log, TEXT("UPostProcessManager::RevertEntityCustomDepth, PPID: %d, EntityID: %lld"), PPID, EntityID);
	PPInstance->RevertEntityCustomDepth(EntityID);
}

void UPostProcessManager::KAPI_PostProcessManager_UpdateFogParams(
	uint32 PPID, float HeadInfoHideDistInMeters, bool bInOverrideClimate, int32 OverrideClimateID, float InBlendTimeSeconds,
	const FName& FogOpacityParamName, float FogOpacityTargetVal,
	const FName& MaxDistParamName, float MaxDistInMetersTargetVal,
	const FName& FogColorParamName, float FogColorR, float FogColorG, float FogColorB, float FogColorA,
	const FName& SmoothDistParamName, float SmoothDistInMetersTargetVal)
{
	auto PPInstance = GetPPInstance(PPID);
	if (!PPInstance)
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::UpdateFogParams, no active PP instance found %d"), PPID);
		return;
	}

	if (!KGPPUtils::IsFogPP(PPInstance->GetPPType()))
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::UpdateFogParams, pp instance is not fog, %d"), PPID);
		return;
	}
	
	KGPPMaterialFog* FogPP = static_cast<KGPPMaterialFog*>(PPInstance);
	FogPP->UpdateFogParams(HeadInfoHideDistInMeters, bInOverrideClimate, OverrideClimateID, InBlendTimeSeconds,
		FogOpacityParamName, FogOpacityTargetVal,
		MaxDistParamName, MaxDistInMetersTargetVal,
		FogColorParamName, FogColorR, FogColorG, FogColorB, FogColorA,
		SmoothDistParamName, SmoothDistInMetersTargetVal);
}

void UPostProcessManager::KAPI_PostProcessManager_UpdateFogOpacity(uint32 PPID, const FName& FogOpacityParamName, float TargetFogOpacity, float NewDuration)
{
	auto PPInstance = GetPPInstance(PPID);
	if (!PPInstance)
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::UpdateFogOpacity, no active PP instance found %d"), PPID);
		return;
	}

	if (!KGPPUtils::IsFogPP(PPInstance->GetPPType()))
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::UpdateFogOpacity, pp instance is not fog, %d"), PPID);
		return;
	}
	
	KGPPMaterialFog* FogPP = static_cast<KGPPMaterialFog*>(PPInstance);
	FogPP->UpdateFogOpacity(FogOpacityParamName, TargetFogOpacity, NewDuration);
}

void UPostProcessManager::KAPI_PostProcessManager_UpdateFogTargetActorBySourceType(uint32 SourceType, const FName& PlayerPosParamName, KGActorID ActorID)
{
	AActor* PlayerActor = nullptr;
	if (ActorID != KG_INVALID_ACTOR_ID)
	{
		PlayerActor = KGUtils::GetActorByID(ActorID);
		if (!PlayerActor)
		{
			UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::KAPI_PostProcessManager_UpdateFogTargetActorBySourceType, no actor found for id %lld"), ActorID);
			return;
		}
	}
	
	for (const auto PPID : NonDummyPostProcessInstanceIDs)
	{
		auto* PPInstance = GetPPInstance(PPID);
		if (PPInstance && PPInstance->GetPPType() == EKGPostProcessType::KG_PP_Fog)
		{
			KGPPMaterialFog* FogPP = static_cast<KGPPMaterialFog*>(PPInstance);
			if (FogPP->GetSourceType() == SourceType)
			{
				if (ActorID == KG_INVALID_ACTOR_ID)
				{
					FogPP->RemoveActorLocationParam(PlayerPosParamName);
				}
				else
				{
					FogPP->UpdateActorLocationParam(PlayerPosParamName, PlayerActor);
				}
			}
		}
	}
}

int32 UPostProcessManager::GetFogPPIDBySourceType(int32 SourceType)
{
	for (const auto PPID : NonDummyPostProcessInstanceIDs)
	{
		auto* PPInstance = GetPPInstance(PPID);
		if (PPInstance && PPInstance->GetPPType() == EKGPostProcessType::KG_PP_Fog)
		{
			KGPPMaterialFog* FogPP = static_cast<KGPPMaterialFog*>(PPInstance);
			if (FogPP->GetSourceType() == SourceType)
			{
				return PPID;
			}
		}
	}

	return KG_PP_INVALID_PPID;
}

void UPostProcessManager::KCB_ChangeClimate(int32 OverrideClimateID)
{
	CallLuaFunction("KCB_ChangeClimate", OverrideClimateID);
}

void UPostProcessManager::KCB_ResetCurrentClimate()
{
	CallLuaFunction("KCB_ResetCurrentClimate");
}

void UPostProcessManager::KAPI_PostProcessManager_AddOrUpdateFogTarget(
	uint32 PPID, KGEntityID EntityID, const FName& AvoidDistanceParamNamePrefix, float AvoidDistanceInMeters,
	const FName& AvoidSmoothDistParamNamePrefix, float AvoidSmoothDist, const FName& FogOpacityParamPrefix, const FName& EntityPosParamNamePrefix, float InBlendTimeSeconds)
{
	auto PPInstance = GetPPInstance(PPID);
	if (!PPInstance)
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::KAPI_PostProcessManager_AddOrUpdateFogTarget, no active PP instance found %d"), PPID);
		return;
	}

	if (PPInstance->GetPPType() != EKGPostProcessType::KG_PP_MultiTargetFog)
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::KAPI_PostProcessManager_AddOrUpdateFogTarget, pp instance is not fog, %d"), PPID);
		return;
	}
	
	KGPPMaterialMultiTargetFog* FogPP = static_cast<KGPPMaterialMultiTargetFog*>(PPInstance);
	FogPP->AddOrUpdateFogTarget(EntityID, AvoidDistanceParamNamePrefix, AvoidDistanceInMeters,
		AvoidSmoothDistParamNamePrefix, AvoidSmoothDist, FogOpacityParamPrefix, EntityPosParamNamePrefix, InBlendTimeSeconds);
}

void UPostProcessManager::KAPI_PostProcessManager_RemoveFogTarget(uint32 PPID, KGEntityID EntityID, const FName& FogOpacityParamPrefix, float InBlendTimeSeconds)
{
	auto PPInstance = GetPPInstance(PPID);
	if (!PPInstance)
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::KAPI_PostProcessManager_RemoveFogTarget, no active PP instance found %d"), PPID);
		return;
	}

	if (PPInstance->GetPPType() != EKGPostProcessType::KG_PP_MultiTargetFog)
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::KAPI_PostProcessManager_RemoveFogTarget, pp instance is not fog, %d"), PPID);
		return;
	}
	
	KGPPMaterialMultiTargetFog* FogPP = static_cast<KGPPMaterialMultiTargetFog*>(PPInstance);
	FogPP->RemoveFogTarget(EntityID, FogOpacityParamPrefix, InBlendTimeSeconds);
}

void UPostProcessManager::KAPI_PostProcessManager_UpdateBlackFogParams(
	uint32 PPID, float BlendTimeSeconds, 
	bool bOverrideCenterPos, float CenterPosX, float CenterPosY, float CenterPosZ,
	bool bOverrideFogOpacity, float FogOpacity,
	bool bOverrideFogColor, float FogColorR, float FogColorG, float FogColorB, float FogColorA,
	bool bOverrideSmoothDist, float SmoothDistInMeters,
	EKGFogShapeType ShapeType, float CircleRadius, float RingPercent, float RingOuterRadius,
	float CrossLength, float CrossWidth, float HalfFieldWidth, bool bOverrideRangeSpawnRotation, float RangeSpawnRotation)
{
	auto PPInstance = GetPPInstance(PPID);
	if (!PPInstance)
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::KAPI_PostProcessManager_UpdateBlackFogParams, no active PP instance found %d"), PPID);
		return;
	}

	if (PPInstance->GetPPType() != EKGPostProcessType::KG_PP_BlackFog)
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::KAPI_PostProcessManager_UpdateBlackFogParams, pp instance is not fog, %d"), PPID);
		return;
	}
	
	FVector CenterPos(CenterPosX, CenterPosY, CenterPosZ);
	if (CenterPos.ContainsNaN())
	{
		UE_LOG(LogKGPP, Error, TEXT("KAPI_PostProcessManager_UpdateBlackFogParams: CenterPos invalid"));
		return;
	}
	
	FLinearColor FogColor(FogColorR, FogColorG, FogColorB, FogColorA);
	if (FVector4(FogColor).ContainsNaN())
	{
		UE_LOG(LogKGPP, Error, TEXT("KAPI_PostProcessManager_UpdateBlackFogParams: FogColor invalid"));
		return;
	}
	
	KGPPMaterialBlackFog* FogPP = static_cast<KGPPMaterialBlackFog*>(PPInstance);
	FogPP->UpdateBlackFogParams(
		BlendTimeSeconds, bOverrideCenterPos, CenterPos, bOverrideFogOpacity, FogOpacity, bOverrideFogColor, FogColor,
		bOverrideSmoothDist, SmoothDistInMeters,
		ShapeType, CircleRadius, RingPercent, RingOuterRadius, CrossLength, CrossWidth, HalfFieldWidth,
		bOverrideRangeSpawnRotation, RangeSpawnRotation);
}

void UPostProcessManager::KAPI_PostProcessManager_SetFogParamName(
	const FName& InFogCenterPosParamName, const FName& InFogOpacityParamName, const FName& InFogColorParamName, const FName& InSmoothDistParamName,
	const FName& InMaxDistParamName, const FName& InPlayerPosParamName, const FName& InBossPosParamName, const FName& InShapeTypeName, const FName& ShapeTypeBName, 
	const FName& InCircleRadiusName, const FName& InRingPercentName, const FName& InRingOuterRadiusName, const FName& InCrossLengthName, 
	const FName& InCrossWidthName, const FName& InHalfFieldWidthName, const FName& InRangeSpawnRotationName, const FName& ShapeLerpName)
{
	FogParams.FogCenterPosParamName = InFogCenterPosParamName;
	FogParams.FogOpacityParamName = InFogOpacityParamName;
	FogParams.FogColorParamName = InFogColorParamName;
	FogParams.SmoothDistParamName = InSmoothDistParamName;
	FogParams.MaxDistParamName = InMaxDistParamName;
	FogParams.PlayerPosParamName = InPlayerPosParamName;
	FogParams.BossPosParamName = InBossPosParamName;
	FogParams.ShapeTypeName = InShapeTypeName;
	FogParams.ShapeTypeBName = ShapeTypeBName;
	FogParams.CircleRadiusName = InCircleRadiusName;
	FogParams.RingPercentName = InRingPercentName;
	FogParams.RingOuterRadiusName = InRingOuterRadiusName;
	FogParams.CrossLengthName = InCrossLengthName;
	FogParams.CrossWidthName = InCrossWidthName;
	FogParams.HalfFieldWidthName = InHalfFieldWidthName;
	FogParams.RangeSpawnRotationName = InRangeSpawnRotationName;
	FogParams.ShapeLerpName = ShapeLerpName;
}

void UPostProcessManager::KAPI_PostProcessManager_AdvancePPTime(uint32 PPID, float DeltaTime)
{
	if (DeltaTime < UE_KINDA_SMALL_NUMBER)
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::AdvancePPTime, invalid DeltaTime %f"), DeltaTime);
		return;
	}
	
	auto PPInstance = GetPPInstance(PPID);
	if (!PPInstance)
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::AdvancePPTime, no active PP instance found %d"), PPID);
		return;
	}
	
	UE_LOG(LogKGPP, Log, TEXT("UPostProcessManager::AdvancePPTime, PPID %d, DeltaTime %f"), PPID, DeltaTime);
	PPInstance->AdvancePPTime(DeltaTime);
}

uint32 UPostProcessManager::GetPPInstanceIDByPPType(EKGPostProcessType PPType)
{
	auto PPInstance = GetPPInstanceByType(PPType);
	return PPInstance == nullptr ? KG_PP_INVALID_PPID : PPInstance->GetPostProcessID();
}

void UPostProcessManager::UpdateActorLocationMaterialParam(uint32 PPID, const FName& ParamName, KGActorID ActorID)
{
	auto PPInstance = GetPPInstance(PPID);
	if (!PPInstance)
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::UpdateActorLocationMaterialParam, no active PP instance found %d"), PPID);
		return;
	}

	if (!PPInstance->IsMaterialPP())
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::UpdateActorLocationMaterialParam, pp instance is not material pp, %d"), PPID);
		return;
	}

	AActor* Actor = KGUtils::GetActorByID(ActorID);
	if (!Actor)
	{
		UE_LOG(LogKGPP, Error, TEXT("UPostProcessManager::UpdateActorLocationMaterialParam, invalid actor %lld"), ActorID);
		return;
	}
	
	KGPPMaterialBase* MaterialPP = static_cast<KGPPMaterialBase*>(PPInstance);
	MaterialPP->UpdateActorLocationParam(ParamName, Actor);
}

void UPostProcessManager::UpdateEntityLocationMaterialParam(uint32 PPID, const FName& ParamName, KGEntityID EntityID)
{
	auto PPInstance = GetPPInstance(PPID);
	if (!PPInstance)
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::UpdateEntityLocationMaterialParam, no active PP instance found %d"), PPID);
		return;
	}

	if (!PPInstance->IsMaterialPP())
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::UpdateEntityLocationMaterialParam, pp instance is not material pp, %d"), PPID);
		return;
	}
	
	KGPPMaterialBase* MaterialPP = static_cast<KGPPMaterialBase*>(PPInstance);
	MaterialPP->UpdateEntityLocationParams(ParamName, EntityID);
}

void UPostProcessManager::RemoveActorLocationMaterialParam(uint32 PPID, const FName& ParamName)
{
	auto PPInstance = GetPPInstance(PPID);
	if (!PPInstance)
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::RemoveActorLocationMaterialParam, no active PP instance found %d"), PPID);
		return;
	}

	if (!PPInstance->IsMaterialPP())
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::RemoveActorLocationMaterialParam, pp instance is not material pp, %d"), PPID);
		return;
	}
	
	KGPPMaterialBase* MaterialPP = static_cast<KGPPMaterialBase*>(PPInstance);
	MaterialPP->RemoveActorLocationParam(ParamName);
}

void UPostProcessManager::RemoveEntityLocationMaterialParam(uint32 PPID, const FName& ParamName)
{
	auto PPInstance = GetPPInstance(PPID);
	if (!PPInstance)
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::RemoveEntityLocationMaterialParam, no active PP instance found %d"), PPID);
		return;
	}

	if (!PPInstance->IsMaterialPP())
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::RemoveEntityLocationMaterialParam, pp instance is not material pp, %d"), PPID);
		return;
	}
	
	KGPPMaterialBase* MaterialPP = static_cast<KGPPMaterialBase*>(PPInstance);
	MaterialPP->RemoveEntityLocationParam(ParamName);
}

void UPostProcessManager::KAPI_PostProcessManager_AddSketchChangeMaterialInfo(const FString& MaterialPath, const TArray<FName>& ExcludeMeshComponentTags, const TArray<FName>& SlotNames)
{
	if (MaterialPath.IsEmpty())
	{
		UE_LOG(LogKGPP, Error, TEXT("UPostProcessManager::AddSketchChangeMaterialInfo, invalid MaterialPath"));
		return;
	}

	FKGChangeMaterialRequest Request;
	Request.MaterialPath = MaterialPath;
	Request.ExcludeMeshTags = ExcludeMeshComponentTags;
	if (SlotNames.Num() > 0)
	{
		Request.SearchMaterialType = EKGSearchMaterialType::SearchMaterialBySlots;
		Request.MaterialSlotNames = SlotNames;
	}
		
	SketchMaterialRequests.Add(Request);
}

void UPostProcessManager::KAPI_PostProcessManager_AddSketchChangeMaterialParamInfo(
	EKGPPSketchEffectType EffectType, const TArray<FName>& SlotNames, const TArray<FName>& InheritTextureMaterialParamName, const TMap<FName, FLinearColor>& VectorParams)
{
	FKGChangeMaterialParamRequest Request;
	if (SlotNames.Num() > 0)
	{
		Request.SearchMaterialType = EKGSearchMaterialType::SearchMaterialBySlots;
		Request.MaterialSlotNames = SlotNames;	
	}
	Request.TextureMaterialParamsInheritDefaultMaterial.Append(InheritTextureMaterialParamName);
	Request.VectorParams.Append(VectorParams);

	SketchMaterialParamRequests.FindOrAdd(EffectType).Add(Request);
}

void UPostProcessManager::KAPI_PostProcessManager_AddSketchTarget(
	uint32 PPID, KGEntityID EntityID, bool bChangeCustomDepth, int32 LogicType, int32 Priority, int32 CustomStencilValue, EKGPPSketchEffectType EffectType)
{
	auto PPInstance = GetPPInstance(PPID);
	if (!PPInstance)
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::AddSketchTarget, no active PP instance found %d"), PPID);
		return;
	}

	if (PPInstance->GetPPType() != EKGPostProcessType::KG_PP_Sketch)
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::AddSketchTarget, pp instance is not sketch, %d"), PPID);
		return;
	}
	
	UE_LOG(LogKGPP, Log,
		TEXT("UPostProcessManager::KAPI_PostProcessManager_AddSketchTarget, PPID: %d, EntityID: %lld, bChangeCustomDepth: %d, LogicType: %d, Priority: %d, CustomStencilValue: %d, EffectType: %d"),
		PPID, EntityID, bChangeCustomDepth, LogicType, Priority, CustomStencilValue, static_cast<int32>(EffectType));

	KGPPMaterialSketch* SketchPP = static_cast<KGPPMaterialSketch*>(PPInstance);
	SketchPP->AddSketchTarget(EntityID, bChangeCustomDepth, LogicType, Priority, CustomStencilValue, EffectType);
}

void UPostProcessManager::KAPI_PostProcessManager_RemoveSketchTarget(uint32 PPID, KGEntityID EntityID)
{
	auto PPInstance = GetPPInstance(PPID);
	if (!PPInstance)
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::RemoveSketchTarget, no active PP instance found %d"), PPID);
		return;
	}

	if (PPInstance->GetPPType() != EKGPostProcessType::KG_PP_Sketch)
	{
		UE_LOG(LogKGPP, Warning, TEXT("UPostProcessManager::RemoveSketchTarget, pp instance is not sketch, %d"), PPID);
		return;
	}

	UE_LOG(LogKGPP, Log, TEXT("UPostProcessManager::KAPI_PostProcessManager_RemoveSketchTarget, PPID: %d, EntityID: %lld"), PPID, EntityID);
	
	KGPPMaterialSketch* SketchPP = static_cast<KGPPMaterialSketch*>(PPInstance);
	SketchPP->RemoveSketchTarget(EntityID);
}

void UPostProcessManager::UpdatePostProcessBlendCache()
{
	PostProcessBlendCache.Empty();
	PostProcessBlendCacheWeights.Empty();
	PostProcessBlendCacheOrders.Empty();

	// 非材质类型后处理无需排序, 材质类型后处理按照预定顺序排序
	// 进所有active以及blending out PP能够参与最终PP输出
	TArray<KGPPBase*> ActiveInstances;
	TArray<KGPPMaterialBase*> ActiveNonPlaneMeshMaterialInstances;
	for (const auto& PPID : NonDummyPostProcessInstanceIDs)
	{
		auto ActivePPInstance = GetPPInstance(PPID);
		check(ActivePPInstance);
		
		const auto PPType = ActivePPInstance->GetPPType();
		check(PPType != EKGPostProcessType::KG_PP_Dummy);
		if (ActivePPInstance->IsMaterialPP())
		{
			KGPPMaterialBase* MaterialPP = static_cast<KGPPMaterialBase*>(ActivePPInstance);
			if (!MaterialPP->UsePlaneMesh())
			{
				ActiveNonPlaneMeshMaterialInstances.Add(MaterialPP);
			}
		}
		else
		{
			ActiveInstances.Add(ActivePPInstance);
		}
	}

	if (ActiveInstances.Num() > 1)
	{
		Algo::Sort(ActiveInstances, [](KGPPBase* PP1, KGPPBase* PP2) {
			return PP1->GetSequenceID() > PP2->GetSequenceID();
		});
	}
	
	// 材质类型后处理需要按表现优先级顺序排序输出
	if (ActiveNonPlaneMeshMaterialInstances.Num() > 1)
	{
		Algo::Sort(ActiveNonPlaneMeshMaterialInstances, [](KGPPMaterialBase* PP1, KGPPMaterialBase* PP2) {
			if (PP1->GetViewPriority() == PP2->GetViewPriority())
			{
				return PP1->GetSequenceID() > PP2->GetSequenceID();
			}
			return PP1->GetViewPriority() > PP2->GetViewPriority();
		});
	}

	for (auto ActiveInstance : ActiveInstances)
	{
		AddPostProcessResult(ActiveInstance);
	}
	
	FPostProcessSettings PostProcessSettings;
	float BlendOutWeight = 1.0;
	EViewTargetBlendOrder BlendOrder;
	bool bPostProcessTakeEffect = false;
	for (auto ActiveMaterialInstance : ActiveNonPlaneMeshMaterialInstances)
	{
		if (ActiveMaterialInstance->GetPostProcessResult(PostProcessSettings, BlendOutWeight, BlendOrder))
		{
			bPostProcessTakeEffect = true;
		}
	}

	if (bPostProcessTakeEffect)
	{
		PostProcessBlendCache.Add(PostProcessSettings);
		PostProcessBlendCacheWeights.Add(BlendOutWeight);
		PostProcessBlendCacheOrders.Add(BlendOrder);
	}

#if KG_ENABLE_PP_MANAGER_DEBUG
	if (GDrawDebugPPOutputInfo)
	{
		for (auto ActiveInstance : ActiveInstances)
		{
			const bool bIsOutputPP = ActiveInstance->CanOutputPostProcess();
			GEngine->AddOnScreenDebugMessage(INDEX_NONE, .0f, FColor::Green,
				FString::Printf(TEXT("[%s] state[%d] %s"), bIsOutputPP ? TEXT("active") : TEXT("inactive"),
					ActiveInstance->GetPostProcessState(), *ActiveInstance->GetDebugInfo()));
		}
		
		TArray<KGPPMaterialBase*> AllMaterialInstances;
		GetPlaneMeshPPMaterialInstances(AllMaterialInstances);

		if (AllMaterialInstances.Num() > 1)
		{
			Algo::Sort(AllMaterialInstances, [](KGPPMaterialBase* PP1, KGPPMaterialBase* PP2) {
				return PP1->GetPlaneMeshDistance() < PP2->GetPlaneMeshDistance();
			});
		}

		AllMaterialInstances.Append(ActiveNonPlaneMeshMaterialInstances);
		for (int32 i = AllMaterialInstances.Num() - 1; i >= 0; i--)
		{
			// 这里绘制顺序和实际渲染顺序是相反的
			auto ActiveInstance = AllMaterialInstances[i];
			bool bIsOutputPP;
			if (ActiveInstance->UsePlaneMesh())
			{
				bIsOutputPP = ActiveInstance->IsPlaneMeshVisible();
			}
			else
			{
				bIsOutputPP = ActiveInstance->CanOutputPostProcess();
			}
			const FString MaterialParamDebugInfo = ActiveInstance->GetMaterialParamDebugInfo();
			if (!MaterialParamDebugInfo.IsEmpty())
			{
				GEngine->AddOnScreenDebugMessage(INDEX_NONE, .0f, FColor::Green,
					FString::Printf(TEXT("%s"), *MaterialParamDebugInfo));
			}
			GEngine->AddOnScreenDebugMessage(INDEX_NONE, .0f, FColor::Green,
				FString::Printf(TEXT("[%s] state[%d] %s"), bIsOutputPP ? TEXT("active") : TEXT("inactive"),
					ActiveInstance->GetPostProcessState(), *ActiveInstance->GetDebugInfo()));
		}
		
#if WITH_EDITOR
		const float ForcePPBlendWeight = CVarForcePPBlendWeight.GetValueOnGameThread();
		GEngine->AddOnScreenDebugMessage(INDEX_NONE, .0f, FColor::Green,
			FString::Printf(TEXT("ForcePPBlendWeight %f"), ForcePPBlendWeight));
#endif
	}
#endif
}

void UPostProcessManager::AddPostProcessResult(KGPPBase* PPInstance)
{
	if (!PPInstance)
	{
		UE_LOG(LogKGPP, Error, TEXT("UPostProcessManager::AddPostProcessResult failed, invalid PPInstance"));
		return;
	}

	FPostProcessSettings PostProcessSettings;
	float BlendOutWeight = 1.0;
	EViewTargetBlendOrder BlendOrder;
	if (PPInstance->GetPostProcessResult(PostProcessSettings, BlendOutWeight, BlendOrder))
	{
		PostProcessBlendCache.Add(PostProcessSettings);
		PostProcessBlendCacheWeights.Add(BlendOutWeight);
		PostProcessBlendCacheOrders.Add(BlendOrder);
	}
}

void UPostProcessManager::RemovePostProcessPriorityInfo(TSharedPtr<KGPPBase> PPInstance)
{
	if (!PPInstance)
	{
		UE_LOG(LogKGPP, Error, TEXT("UPostProcessManager::RemovePostProcessPriorityInfo failed, invalid PPInstance"));
		return;
	}

	const auto PPType = PPInstance->GetPPType();
	const auto PPID = PPInstance->GetPostProcessID();
	auto& PriorityQueue = GetOrCreatePostProcessPriorityQueue(PPType);
	PriorityQueue.RemovePostProcess(PPID);

	auto& LinkedDummyPPIDs = PPInstance->GetLinkedPostProcessIDs();
	for (const auto LinkedDummyPPID : LinkedDummyPPIDs)
	{
		check(LinkedDummyPPID != PPID);
		StopPostProcess(LinkedDummyPPID, EKGPostProcessStopReason::PostProcessDisabled);
	}
	LinkedDummyPPIDs.Empty();
}

void UPostProcessManager::AddPostProcessPriorityInfo(TSharedPtr<KGPPBase> PPInstance)
{
	if (!PPInstance)
	{
		UE_LOG(LogKGPP, Error, TEXT("UPostProcessManager::AddPostProcessPriorityInfo failed, invalid PPInstance"));
		return;
	}

	// 后处理处于interrupted blending out过程中, 不可以再重新被加入优先级队列
	const auto PPState = PPInstance->GetPostProcessState();
	if (PPState == EKGPostProcessState::InterruptedBlendingOut_PendingDeactivated ||
		PPState == EKGPostProcessState::InterruptedBlendingOut_Deactivated)
	{
		UE_LOG(LogKGPP, Log, TEXT("UPostProcessManager::AddPostProcessPriorityInfo, PPInstance is in interrupted blending out state, %d, %s"),
			PPState, *PPInstance->GetDebugInfo());
		return;
	}
	
	const auto PPID = PPInstance->GetPostProcessID();
	const auto PPType = PPInstance->GetPPType();
	
	if (PPConfigs.Contains(PPType))
	{
		for (const auto ConflictType : PPConfigs[PPType].ConflictTypes)
		{
			auto& ConflictPriorityQueue = GetOrCreatePostProcessPriorityQueue(ConflictType);
			
			TSharedPtr<KGPPDummy> PPDummy = MakeShared<KGPPDummy>();
			PPDummy->InitParams(PPInstance->GetPriority(), this, PPID, PPType, ConflictType);
			const uint32 DummyPPID = PPDummy->GetPostProcessID();
			// dummy总是跟着source PP生命周期走, 不需要设置TotalLifeTimeSeconds
			PPInstance->GetLinkedPostProcessIDs().Add(DummyPPID);
			PPDummy->DoTaskStart();
			ConflictPriorityQueue.AddNewPostProcess(PPDummy);
			PostProcessInstances.Add(DummyPPID, PPDummy);
		}
	}
	
	auto& PriorityQueue = GetOrCreatePostProcessPriorityQueue(PPType);
	PriorityQueue.AddNewPostProcess(PPInstance);	
}

void UPostProcessManager::InternalUpdatePostProcessDisableState(TSharedPtr<KGPPBase> PPInstance, bool bDisable, EKGPostProcessDisableReason Reason)
{
	if (!PPInstance.IsValid())
	{
		UE_LOG(LogKGPP, Error, TEXT("UPostProcessManager::InternalUpdatePostProcessDisableState failed, invalid PPInstance"));
		return;
	}

	const bool bOldIsPPDisabled = PPInstance->IsDisabled();
	if (bDisable)
	{
		PPInstance->AddDisableReason(Reason);
	}
	else
	{
		PPInstance->RemoveDisableReason(Reason);
	}
	const bool bNewIsPPDisabled = PPInstance->IsDisabled();

	if (bOldIsPPDisabled == bNewIsPPDisabled)
	{
		return;
	}

	if (bNewIsPPDisabled)
	{
		RemovePostProcessPriorityInfo(PPInstance);
	}
	else
	{
		AddPostProcessPriorityInfo(PPInstance);
	}
}

void UPostProcessManager::InternalStopPostProcess(uint32 PPID, EKGPostProcessStopReason StopReason)
{
	KGPPBase* PPInstance = GetPPInstance(PPID);
	if (!PPInstance)
	{
		UE_LOG(LogKGPP, Error, TEXT("UPostProcessManager::InternalStopPostProcess failed, invalid PPID %d"), PPID);
		return;
	}

	UE_LOG(LogKGPP, Log, TEXT("UPostProcessManager::InternalStopPostProcess, PPID %d, StopReason %d"), PPID, (int32)StopReason);

	const auto PPType = PPInstance->GetPPType();
	if (PPType != EKGPostProcessType::KG_PP_Dummy)
	{
		auto& PriorityQueue = GetOrCreatePostProcessPriorityQueue(PPType);
		PriorityQueue.RemovePostProcess(PPID);
		
		auto& LinkedDummyPPIDs = PPInstance->GetLinkedPostProcessIDs();
		for (const auto LinkedDummyPPID : LinkedDummyPPIDs)
		{
			check(LinkedDummyPPID != PPID);
			StopPostProcess(LinkedDummyPPID, StopReason);
		}
		LinkedDummyPPIDs.Empty();

		if (NonDummyPostProcessInstanceIDs.Contains(PPID))
		{
			NonDummyPostProcessInstanceIDs.Remove(PPID);
		}
	}
	else
	{
		KGPPDummy* PPDummy = static_cast<KGPPDummy*>(PPInstance);
		auto& PriorityQueue = GetOrCreatePostProcessPriorityQueue(PPDummy->GetTargetPPType());
		PriorityQueue.RemovePostProcess(PPID);
	}

	PPInstance->DoTaskEnd(StopReason);
	PostProcessInstances.Remove(PPID);
}

KGPPMaterialBase* UPostProcessManager::GetMaterialPPInstance(uint32 PPID)
{
	KGPPBase* PPInstance = GetPPInstance(PPID);
	if (!PPInstance)
	{
		return nullptr;
	}

	if (!PPInstance->IsMaterialPP())
	{
		UE_LOG(LogKGPP, Error, TEXT("UPostProcessManager::GetMaterialPPInstance failed, invalid PP type, %d"), PPInstance->GetPPType());
		return nullptr;
	}

	return StaticCast<KGPPMaterialBase*>(PPInstance);
}

KGPPBase* UPostProcessManager::GetActivePPInstanceByType(EKGPostProcessType PPType)
{
	if (!PPTypeToPriorityQueues.Contains(PPType))
	{
		UE_LOG(LogKGPP, Log, TEXT("UPostProcessManager::GetActivePPInstanceByType, no active clip PP instance found"));
		return nullptr;
	}

	return PPTypeToPriorityQueues[PPType].GetActivePostProcessInstance();
}

KGPPBase* UPostProcessManager::GetPPInstanceByType(EKGPostProcessType PPType)
{
	if (!PPTypeToPriorityQueues.Contains(PPType))
	{
		UE_LOG(LogKGPP, Log, TEXT("UPostProcessManager::GetPPInstanceByType, no PP instance found"));
		return nullptr;
	}
	
	return PPTypeToPriorityQueues[PPType].GetFirstNonDummyInstance();
}

void UPostProcessManager::GetPlaneMeshPPMaterialInstances(TArray<KGPPMaterialBase*>& OutMaterialInstances)
{
	for (const auto& NonDummyPPID : NonDummyPostProcessInstanceIDs)
	{
		auto ActivePPInstance = GetPPInstance(NonDummyPPID);
		check(ActivePPInstance);
		
		const auto PPType = ActivePPInstance->GetPPType();
		check(PPType != EKGPostProcessType::KG_PP_Dummy);
		if (ActivePPInstance->IsMaterialPP())
		{
			KGPPMaterialBase* MaterialPP = static_cast<KGPPMaterialBase*>(ActivePPInstance);
			if (MaterialPP->UsePlaneMesh())
			{
				OutMaterialInstances.Add(MaterialPP);	
			}
		}
	}
}

void UPostProcessManager::ProcessLinearSampleParams(const FName& ParamName, float StartVal, float EndVal, float Duration, FKGPPMaterialParams& OutParams)
{
	if (Duration > UE_KINDA_SMALL_NUMBER)
	{
		auto& SampleParams = OutParams.ScalarLinearSampleParams.Add(ParamName);
		SampleParams.StartVal = StartVal;
		SampleParams.EndVal = EndVal;
		SampleParams.Duration = Duration;
	}
	else
	{
		OutParams.ScalarParams.Add(ParamName, EndVal);
	}
}
