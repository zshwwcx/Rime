#include "3C/Camera/CameraAction/CameraActionFocusOnTarget.h"

#include "3C/Camera/CameraAction/CameraActionHandler.h"
#include "Camera/CameraComponent.h"
#include "Blueprint/WidgetLayoutLibrary.h"
#include "Engine/Engine.h"
#include "GameFramework/Pawn.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetMathLibrary.h"


bool UCameraActionFocusOnTarget::ScreenDeltaYawToCameraDeltaYaw(float CameraRootToCamera, float TargetToCameraRoot, float ScreenDeltaYaw, float& CameraDeltaYaw)
{
	// 复杂的三角函数推导......
	float a = TargetToCameraRoot;
	float b = CameraRootToCamera;
	CameraDeltaYaw = FMath::Sin(FMath::DegreesToRadians(ScreenDeltaYaw));
	CameraDeltaYaw = a * a - (b * b * CameraDeltaYaw * CameraDeltaYaw);
	if (CameraDeltaYaw < 0)
	{
		// 当目标与CameraRoot过近（a过小），无法将目标调整至对应的ScreenYaw
		return false;
	}
	CameraDeltaYaw = FMath::Cos(FMath::DegreesToRadians(ScreenDeltaYaw)) * FMath::Sqrt(CameraDeltaYaw) - (-CameraDeltaYaw + a * a) / b;
	CameraDeltaYaw = FMath::RadiansToDegrees(FMath::Acos(CameraDeltaYaw / a));
	return true;
}

bool UCameraActionFocusOnTarget::ScreenDeltaPitchToCameraDeltaPitch(float CameraRootToCamera, float TargetToCameraRoot, float ScreenDeltaPitch, float& CameraDeltaPitch)
{
	// 复杂的三角函数推导......
	float a = TargetToCameraRoot;
	float b = CameraRootToCamera;
	CameraDeltaPitch = FMath::Sin(FMath::DegreesToRadians(ScreenDeltaPitch));
	CameraDeltaPitch = a * a - (b * b * CameraDeltaPitch * CameraDeltaPitch);
	if (CameraDeltaPitch < 0)
	{
		// 当目标与CameraRoot过近（a过小），无法将目标调整至对应的ScreenYaw
		CameraDeltaPitch = 0.0f;
		return false;
	}
	CameraDeltaPitch = b * FMath::Cos(FMath::DegreesToRadians(ScreenDeltaPitch)) + FMath::Sqrt(CameraDeltaPitch);	// c
	CameraDeltaPitch = FMath::RadiansToDegrees(FMath::Acos(-(a * a + b * b - CameraDeltaPitch * CameraDeltaPitch) / 2 / a / b));// 0-90
	return true;
}

int UCameraActionFocusOnTarget::GetFocusOnAdaptiveRotator(FRotator& Result, const FVector& ActorLocation,
                                                           APlayerController* PC, ABaseCamera* InCamera, float InLeftX,
                                                           float InRightX, float InUpY, float InDownY,
                                                           float InCheckInScreenError, float InMiddleLockHeight,
                                                           bool InbForceLockMiddle)
{
	// 计算屏幕大小
	FVector2D OriginScreenSize = UWidgetLayoutLibrary::GetViewportSize(PC);
	float FOV = InCamera->GetCameraFOV();
	// 计算舒适区域偏转角度
	float LeftAngle = -(180.0) / UE_DOUBLE_PI * FMath::Atan2(2 * FMath::Tan(FMath::DegreesToRadians(0.5 * FOV)) * (0.5 - InLeftX), 1.0);
	float RightAngle = (180.0) / UE_DOUBLE_PI * FMath::Atan2(2 * FMath::Tan(FMath::DegreesToRadians(0.5 * FOV)) * (InRightX - 0.5), 1.0);
	float UpAngle = (180.0) / UE_DOUBLE_PI * FMath::Atan2(2 * FMath::Tan(FMath::DegreesToRadians(0.5 * FOV)) * (0.5 - InUpY) * OriginScreenSize.Y / OriginScreenSize.X, 1.0);
	float DownAngle = (180.0) / UE_DOUBLE_PI * FMath::Atan2(2 * FMath::Tan(FMath::DegreesToRadians(0.5 * FOV)) * (InDownY - 0.5) * OriginScreenSize.Y / OriginScreenSize.X, 1.0);

	
	FVector2D ScreenPosition = FVector2D(-1.0, -1.0);
	float DeltaYaw = 0.0;	// 角色不在屏幕内，直接将角色聚焦在屏幕中间
	float DeltaPitch = 0.0f;
	bool bAllowsjustPitch = true;
	// 判断是否在屏幕内
	if (UGameplayStatics::ProjectWorldToScreen(PC, ActorLocation, ScreenPosition) &&
		ScreenPosition.X > -InCheckInScreenError && ScreenPosition.X <= OriginScreenSize.X + InCheckInScreenError &&
		ScreenPosition.Y > -InCheckInScreenError && ScreenPosition.Y <= OriginScreenSize.Y + InCheckInScreenError)
	{
		if (ScreenPosition.X >= OriginScreenSize.X * InLeftX && ScreenPosition.X <= OriginScreenSize.X * InRightX &&
			ScreenPosition.Y >= OriginScreenSize.Y * InUpY && ScreenPosition.Y <= OriginScreenSize.Y * InDownY)
		{
			// 在舒适区域中不做调整
			return 0;
		}

		DeltaYaw = ScreenPosition.X <= OriginScreenSize.X / 2 ? LeftAngle : RightAngle;
		if (CheckCanReachComfortRegion(InbForceLockMiddle, ActorLocation, InCamera, DeltaYaw, UpAngle, DownAngle))
		{
			// 可以调整至舒适区边缘时，水平调整
			bAllowsjustPitch = false;
			//return;
		}
		else
		{
			// 虽然在屏幕内，但是无法调整至舒适区边缘时，仍然调整至屏幕中心
			DeltaYaw = 0.0f;
		}
	}

	// 移动至MiddleLockHeight的俯仰角调整值
	if(bAllowsjustPitch)
	{
		DeltaPitch = (180.0) / UE_DOUBLE_PI * FMath::Atan2(2 * FMath::Tan(FMath::DegreesToRadians(0.5 * FOV)) * (0.5 - InMiddleLockHeight) * OriginScreenSize.Y / OriginScreenSize.X, 1.0);
	}
	
	FVector CameraRootLocation = InCamera->GetRootComponent()->GetComponentLocation();
	FVector CameraLocation = InCamera->GetCameraComponent()->GetComponentLocation();

	float CameraDeltaYaw = 0.0f;
	if (!UCameraActionFocusOnTarget::ScreenDeltaYawToCameraDeltaYaw((CameraLocation - CameraRootLocation).Size(), (ActorLocation - CameraRootLocation).Size(), DeltaYaw, CameraDeltaYaw))
	{
		return -1;
	}
	float CameraDetaPitch = 0.0f;
	UCameraActionFocusOnTarget::ScreenDeltaPitchToCameraDeltaPitch((CameraLocation - CameraRootLocation).Size(), (ActorLocation - CameraRootLocation).Size(), DeltaPitch, CameraDetaPitch);

	Result = UKismetMathLibrary::FindLookAtRotation(CameraRootLocation /*+ CameraRootLocation - ActorLocation*/, ActorLocation);
	Result.Yaw += DeltaYaw >= 0 ? -CameraDeltaYaw : +CameraDeltaYaw;
	Result.Pitch -= CameraDetaPitch; //CameraDetaPitch
	Result.Roll = 0.0f;
	if (!bAllowsjustPitch)
	{
		Result.Pitch = InCamera->GetCameraComponent()->GetComponentRotation().Pitch;
	}
	return 1;
}


bool UCameraActionFocusOnTarget::CheckCanReachComfortRegion(bool bForceLockMiddle, const FVector& ActorLocation, ABaseCamera* Camera, float DeltaYaw, float UpAngle, float DownAngle)
{
	if (bForceLockMiddle == true)
	{
		return false;
	}

	FVector CameraRootLocation = Camera->GetRootComponent()->GetComponentLocation();
	FVector CameraLocation = Camera->GetCameraComponent()->GetComponentLocation();
	FRotator CameraRotation = Camera->GetCameraComponent()->GetComponentRotation();
	FRotator NewRotator = UKismetMathLibrary::FindLookAtRotation(CameraRootLocation, ActorLocation);
	float CameraRootToCamera = (CameraLocation - CameraRootLocation).Size();
	float TargetToCameraRoot = (ActorLocation - CameraRootLocation).Size();
	float CameraDeltaYaw = 0.0;
	float CameraDeltaPitch = 0.0;

	if (!UCameraActionFocusOnTarget::ScreenDeltaYawToCameraDeltaYaw(CameraRootToCamera, TargetToCameraRoot, DeltaYaw, CameraDeltaYaw))
	{
		// 无法调整到对应的ScreenYaw，则调整至中心
		return false;
	}

	// 镜头朝下时，检查目标是否在UpAngle下方
	if (CameraRotation.Pitch < 0.0f)
	{
		if (!UCameraActionFocusOnTarget::ScreenDeltaPitchToCameraDeltaPitch(CameraRootToCamera, TargetToCameraRoot * FMath::Cos(FMath::DegreesToRadians(CameraDeltaYaw)), UpAngle, CameraDeltaPitch))
		{
			// 无法调整到对应的UpAngle，说明一定可以转动到舒适区域内
			return true;
		}

		// 实际Pitch绝对值小于临界值，可以滑至舒适区
		return FMath::Abs(-NewRotator.Pitch + CameraDeltaPitch) >= -CameraRotation.Pitch;
	}
	// 镜头朝上时，检查目标是否在DownAngle上方
	else if (CameraRotation.Pitch > 0.0f)
	{
		if (!UCameraActionFocusOnTarget::ScreenDeltaPitchToCameraDeltaPitch(CameraRootToCamera, TargetToCameraRoot * FMath::Cos(FMath::DegreesToRadians(CameraDeltaYaw)), DownAngle, CameraDeltaPitch))
		{
			// 无法调整到对应的DownAngle，说明一定可以转动到舒适区域内
			return true;
		}

		// 实际Pitch值小于临界值，可以滑至舒适区
		return FMath::Abs(NewRotator.Pitch + CameraDeltaPitch) > CameraRotation.Pitch;
	}
	
	return true;
}

