#include "3C/Camera/PostProcessNew/PostProcessInstance/PPDirtMask.h"

#include "Manager/KGCppAssetManager.h"
#include "3C/Camera/PostProcessNew/PostProcessManager.h"
#include "Engine/Texture2D.h"

void KGPPDirtMask::InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType,
	const FPostProcessSettings& InPostProcessSettings, const FString& InBloomDirtMaskTexturePath)
{
	KGPPNonMaterialBase::InitParams(CommonParams, InPPManager, InPPType, InPostProcessSettings);
	BloomDirtMaskTexturePath = InBloomDirtMaskTexturePath;
}

bool KGPPDirtMask::OnTaskStart()
{
	if (!KGPPNonMaterialBase::OnTaskStart())
	{
		return false;
	}

	if (PostProcessSettings.bOverride_BloomDirtMask)
	{
		if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(PostProcessManager.Get()))
		{
			AssetLoadID = AssetManager->AsyncLoadAsset(
				BloomDirtMaskTexturePath, FAsyncLoadCompleteDelegate::CreateRaw(this, &KGPPDirtMask::OnBloomDirtMaskTextureLoaded));
		}	
	}
	
	return true;
}

void KGPPDirtMask::OnTaskEnd(EKGPostProcessStopReason StopReason)
{
	if (AssetLoadID != 0)
	{
		if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(PostProcessManager.Get()))
		{
			AssetManager->CancelAsyncLoadByLoadID(AssetLoadID);
		}
		else
		{
			UE_LOG(LogKGPP, Error, TEXT("KGPPDirtMask::OnTaskEnd failed, PostProcessManager is nullptr, %s"), *GetDebugInfo());
		}
	}
	
	KGPPNonMaterialBase::OnTaskEnd(StopReason);
}

bool KGPPDirtMask::CanOutputPostProcess() const
{
	if (PostProcessSettings.bOverride_BloomDirtMask && !PostProcessSettings.BloomDirtMask.Get())
	{
		return false;
	}
	
	return KGPPNonMaterialBase::CanOutputPostProcess();
}

void KGPPDirtMask::OnBloomDirtMaskTextureLoaded(int InLoadID, UObject* Asset)
{
	AssetLoadID = 0;
	UTexture* TextureAsset = Cast<UTexture>(Asset);
	if (TextureAsset == nullptr)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPDirtMask::OnBloomDirtMaskTextureLoaded failed, asset load failed, %s, %s"), *BloomDirtMaskTexturePath, *GetDebugInfo());
		return;
	}

	UE_LOG(LogKGPP, Log, TEXT("KGPPDirtMask::OnBloomDirtMaskTextureLoaded, %s, %s"), *BloomDirtMaskTexturePath, *GetDebugInfo());
	BloomDirtMaskTexture = TStrongObjectPtr(TextureAsset);
	PostProcessSettings.BloomDirtMask = TextureAsset;
}


