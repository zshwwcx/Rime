#include "3C/Camera/PostProcessNew/PostProcessInstance/PPLensFlares.h"

#include "Manager/KGCppAssetManager.h"
#include "3C/Camera/PostProcessNew/PostProcessManager.h"
#include "Engine/Texture2D.h"

void KGPPLensFlares::InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType,
	const FPostProcessSettings& InPostProcessSettings, const FString& InLensFlareBokehShapePath)
{
	KGPPNonMaterialBase::InitParams(CommonParams, InPPManager, InPPType, InPostProcessSettings);
	LensFlareBokehShapePath = InLensFlareBokehShapePath;
}

bool KGPPLensFlares::OnTaskStart()
{
	if (!KGPPNonMaterialBase::OnTaskStart())
	{
		return false;
	}

	if (PostProcessSettings.bOverride_LensFlareBokehShape)
	{
		if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(PostProcessManager.Get()))
		{
			AssetLoadID = AssetManager->AsyncLoadAsset(
				LensFlareBokehShapePath, FAsyncLoadCompleteDelegate::CreateRaw(this, &KGPPLensFlares::OnLensFlareBokehShapeTextureLoaded));
		}	
	}
	
	return true;
}

void KGPPLensFlares::OnTaskEnd(EKGPostProcessStopReason StopReason)
{
	if (AssetLoadID != 0)
	{
		if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(PostProcessManager.Get()))
		{
			AssetManager->CancelAsyncLoadByLoadID(AssetLoadID);
		}
		else
		{
			UE_LOG(LogKGPP, Error, TEXT("KGPPLensFlares::OnTaskEnd failed, AssetManager is nullptr, %s"), *GetDebugInfo());
		}
	}
	
	KGPPNonMaterialBase::OnTaskEnd(StopReason);
}

bool KGPPLensFlares::CanOutputPostProcess() const
{
	if (PostProcessSettings.bOverride_LensFlareBokehShape && !PostProcessSettings.LensFlareBokehShape.Get())
	{
		return false;
	}
	
	return KGPPNonMaterialBase::CanOutputPostProcess();
}

void KGPPLensFlares::OnLensFlareBokehShapeTextureLoaded(int InLoadID, UObject* Asset)
{
	AssetLoadID = 0;
	UTexture* TextureAsset = Cast<UTexture>(Asset);
	if (TextureAsset == nullptr)
	{
		UE_LOG(LogKGPP, Error, TEXT("KGPPLensFlares::OnLensFlareBokehShapeTextureLoaded failed, asset load failed, %s, %s"), *LensFlareBokehShapePath, *GetDebugInfo());
		return;
	}

	UE_LOG(LogKGPP, Log, TEXT("KGPPLensFlares::OnLensFlareBokehShapeTextureLoaded, %s, %s"), *LensFlareBokehShapePath, *GetDebugInfo());
	LensFlareBokehShapeTexture = TStrongObjectPtr(TextureAsset);
	PostProcessSettings.LensFlareBokehShape = TextureAsset;
}


