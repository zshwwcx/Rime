// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Camera/BaseCineCameraComponent.h"

#include "3C/Character/BaseCharacter.h"
#include "3C/Core/C7ActorInterface.h"
#include "3C/Core/KGUEActorManager.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "Engine/OverlapResult.h"
#include "Engine/World.h"
#include "3C/Material/KGMaterialManager.h"
#include "3C/Util/KGUtils.h"

UBaseCineCameraComponent::UBaseCineCameraComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UBaseCineCameraComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	PostProcess(DeltaTime);
}

void UBaseCineCameraComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	ClearDitherFade();
	Super::EndPlay(EndPlayReason);
}

void UBaseCineCameraComponent::PostProcess(float DeltaTime)
{
	if (bDitherFadeDetect)
	{
		if (UWorld* World = GetWorld())
		{
			if (DitherDetectRadius > 0 && DitherFadeObjectTypes.Num() > 0)
			{
				CollisionShape.SetSphere(DitherDetectRadius);
				TArray<FOverlapResult> OverlapResults;
				World->OverlapMultiByObjectType(OverlapResults, GetComponentLocation(), FQuat::Identity, DitherFadeObjectTypes, CollisionShape, CollisionQueryParams);

				UKGMaterialManager* MaterialMgr = Cast<UKGMaterialManager>(UKGBasicManager::GetManagerByType(GetWorld(), EManagerType::EMT_MaterialManager));
				if(MaterialMgr == nullptr)
				{
					return;
				}
				UKGUEActorManager* UEActorManager = UKGUEActorManager::GetInstance(GetWorld());
				if(UEActorManager == nullptr)
				{
					return;
				}

				TSet<int64> OutComponents;
				TArray<UPrimitiveComponent*> ComponentsNeedToEnableCameraDither;
				for (auto& HitResult : OverlapResults)
				{
					if (DitherFadeObjectMatchActor.Num() > 0)
					{
						bool bMatch = false;
						for (auto& ClassType : DitherFadeObjectMatchActor)
						{
							if (AActor* Owner = HitResult.GetActor())
							{
								if (Owner->IsA(ClassType))
								{
									bMatch = true;
									break;
								}
							}
						}
						if (!bMatch) break;
					}
					auto* HitActor = HitResult.GetActor();
					if (UEActorManager)
					{
						if (IC7ActorInterface* C7Actor = Cast<IC7ActorInterface>(HitActor))
						{
							if (auto* Entity = UEActorManager->GetLuaEntity(C7Actor->GetEntityUID()))
							{
								ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(HitActor);
								URoleMovementComponent* RoleMovement = BaseCharacter ? Cast<URoleMovementComponent>(BaseCharacter->GetMovementComponent()) : nullptr;
								const bool bIsMount = RoleMovement && RoleMovement->IsMount();
								const bool bIsRider = RoleMovement && RoleMovement->IsMountRider();
								// 对于处于挂接状态的物体, 目前跟随其attach parent一起进行虚化表现
								if (bIsMount || (Entity->IsAttached() && !bIsRider))
								{
									continue;
								}
							}
						}
					}
					
					if (HitResult.Component.IsValid())
					{
						KGObjectID ComponentID = KGUtils::GetIDByObject(HitResult.Component.Get());
						OutComponents.Add(ComponentID);
						if (!DetectDitherComponents.Contains(ComponentID) && HitResult.Component->GetCollisionResponseToChannels().GetResponse(ECC_Camera) == ECR_Ignore)
						{
							DetectDitherComponents.Emplace(ComponentID);
							DitherComponentToActor.Add(ComponentID, HitResult.GetActor());
							ComponentsNeedToEnableCameraDither.Add(HitResult.Component.Get());
						}
					}
				}
				
				for(KGObjectID MeshComponentObjectID: DetectDitherComponents.Difference(OutComponents))
				{
					DetectDitherComponents.Remove(MeshComponentObjectID);
					if(MaterialMgr)
					{
						if(DitherComponentToActor.Contains(MeshComponentObjectID))
						{
							if(AActor* DitherActor = DitherComponentToActor[MeshComponentObjectID].Get())
							{
								MaterialMgr->DisableCameraDither(DitherActor, KGUtils::GetObjectByID<UMeshComponent>(MeshComponentObjectID));
							}
							DitherComponentToActor.Remove(MeshComponentObjectID);
						}
					}
				}
				
				if (MaterialMgr)
				{
					for (auto* Component : ComponentsNeedToEnableCameraDither)
					{
						AActor* MeshOwner = Component->GetOwner();
						MaterialMgr->EnableCameraDither(MeshOwner, Cast<UMeshComponent>(Component));
					}
				}
			}
		}
	}
}

void UBaseCineCameraComponent::ClearDitherFade()
{
	if(UKGMaterialManager* MaterialMgr = Cast<UKGMaterialManager>(UKGBasicManager::GetManagerByType(GetWorld(), EManagerType::EMT_MaterialManager)))
	{
		for(auto MeshComponentObjectID: DetectDitherComponents)
		{
			if(DitherComponentToActor.Contains(MeshComponentObjectID))
			{
				if(AActor* DitherActor = DitherComponentToActor[MeshComponentObjectID].Get())
				{
					MaterialMgr->DisableCameraDither(DitherActor, KGUtils::GetObjectByID<UMeshComponent>(MeshComponentObjectID));
				}
				DitherComponentToActor.Remove(MeshComponentObjectID);
			}
		}
	}

	DetectDitherComponents.Reset();
	DitherComponentToActor.Reset();
}
