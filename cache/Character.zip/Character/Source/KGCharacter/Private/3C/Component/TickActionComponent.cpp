// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Component/TickActionComponent.h"
#include "Manager/KGObjectActorManager.h"
#include "Components/CapsuleComponent.h"

UTickActionComponent::UTickActionComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	SetTickGroup(TG_PostUpdateWork);
}

void UTickActionComponent::BeginPlay()
{
	Super::BeginPlay();
}

void UTickActionComponent::ResetToDefaultsForCache()
{
	ModelScaleUpdateContexts.Reset();
	if (bHasSourceScale3D) {
		if (AActor* Actor = GetOwner()) {
			Actor->SetActorScale3D(SourceScale3D);
			bHasSourceScale3D = false;
		}
	}
}

int32 UTickActionComponent::StartModelScale(float TargetHeightScaleRate, float TargetRadiusScaleRate, float InDuration, float InFadeIn, float InFadeOut)
{
	AActor* Actor = GetOwner();
	if (!Actor)
	{
		UE_LOG(LogTemp, Warning, TEXT("[UTickActionComponent::StartModelScaleChange] Cannot Get GetOwner()"));
		return 0;
	}
	float Duration = FMath::Max(0.0f, InDuration);
	float FadeIn = FMath::Max(0.0f, InFadeIn);
	float FadeOut = FMath::Max(0.0f, InFadeOut);

	FVector OriginScale = Actor->GetActorScale3D();
	//记录原始的尺寸，在Reset时重置
	if (!bHasSourceScale3D) {
		SourceScale3D = OriginScale;
		bHasSourceScale3D = true;
	}
	FModelScaleUpdateContext Ctx;
	Ctx.OriginScale = Actor->GetActorScale3D();
	Ctx.OverTime = 0.0f;
	Ctx.TargetScale = FVector(OriginScale.X * TargetRadiusScaleRate, OriginScale.Y * TargetRadiusScaleRate, OriginScale.Z * TargetHeightScaleRate);
	Ctx.Duration = Duration;
	Ctx.FadeIn = FadeIn;
	Ctx.FadeOut = FadeOut;
	const int32 ModelScaleId = GenerateModelScaleId();
	ModelScaleUpdateContexts.Add(ModelScaleId, Ctx);
	return ModelScaleId;
}

void UTickActionComponent::StopModelScale(int32 InModelScaleId, bool bNotRevert)
{
	if (bNotRevert)
	{
		ModelScaleUpdateContexts.Remove(InModelScaleId);
		return;
	}
	AActor* Actor = GetOwner();
	if (!Actor)
	{
		UE_LOG(LogTemp, Warning, TEXT("[UTickActionComponent::StopModelScaleChange] Cannot Get GetOwner()"));
		return;
	}
	FModelScaleUpdateContext* ContextPtr = ModelScaleUpdateContexts.Find(InModelScaleId);
	if (!ContextPtr)
	{
		UE_LOG(LogTemp, Warning, TEXT("[UTickActionComponent::StopModelScale] Invalid ModelScaleId=%d"), InModelScaleId);
		return;
	}
	FVector OriginScale = ContextPtr->OriginScale;
	if (UCapsuleComponent* Capsule = Actor->GetComponentByClass<UCapsuleComponent>()) {
		FVector CurLocation = Actor->GetActorLocation();
		FVector CurScale3D = Actor->GetActorScale3D();

		float DeltaZScale = OriginScale.Z - CurScale3D.Z;
		float HalfHeight = Capsule->GetUnscaledCapsuleHalfHeight();
		CurLocation.Z += HalfHeight * DeltaZScale;
		Actor->SetActorLocation(CurLocation);
	}
	Actor->SetActorScale3D(OriginScale);
	ModelScaleUpdateContexts.Remove(InModelScaleId);
}

void UTickActionComponent::ModelScaleTick(float DeltaTime, int32 ModelScaleId)
{
	AActor* Actor = GetOwner();
	if (!Actor)
	{
		UE_LOG(LogTemp, Warning, TEXT("[UTickActionComponent::ModelScaleTick] Owner is null"));
		return;
	}

	FModelScaleUpdateContext* Ctx = ModelScaleUpdateContexts.Find(ModelScaleId);
	if (!Ctx)
	{
		return;
	}

	float Duration = FMath::Max(0.f, Ctx->Duration);
	float FadeIn = FMath::Max(0.f, Ctx->FadeIn);
	float FadeOut = FMath::Max(0.f, Ctx->FadeOut);

	Ctx->OverTime = FMath::Min(Ctx->OverTime + DeltaTime, Duration);
	float OverTime = Ctx->OverTime;

	float SafeFadeIn = FMath::Min(FadeIn, Duration);
	float SafeFadeOut = FMath::Min(FadeOut, Duration);
	float FadeOutStart = FMath::Max(0.f, Duration - SafeFadeOut);

	float Alpha = 1.f;
	FVector TargetScale = Ctx->OriginScale;

	if (Duration <= 0.f)
	{
		TargetScale = Ctx->TargetScale;
	}
	else if (SafeFadeOut > 0.f && OverTime >= FadeOutStart)
	{
		Alpha = (OverTime - FadeOutStart) / SafeFadeOut;
		Alpha = 1.f - FMath::Clamp(Alpha, 0.f, 1.f);
		TargetScale = FMath::Lerp(Ctx->OriginScale, Ctx->TargetScale, Alpha);
	}
	else if (SafeFadeIn > 0.f && OverTime < SafeFadeIn)
	{
		Alpha = OverTime / SafeFadeIn;
		Alpha = FMath::Clamp(Alpha, 0.f, 1.f);
		TargetScale = FMath::Lerp(Ctx->OriginScale, Ctx->TargetScale, Alpha);
	}
	else
	{
		TargetScale = Ctx->TargetScale;
	}
	if (UCapsuleComponent* Capsule = Actor->GetComponentByClass<UCapsuleComponent>())
	{
		FVector CurLocation = Actor->GetActorLocation();
		FVector CurScale3D = Actor->GetActorScale3D();

		float DeltaZScale = TargetScale.Z - CurScale3D.Z;
		float HalfHeight = Capsule->GetUnscaledCapsuleHalfHeight();

		CurLocation.Z += HalfHeight * DeltaZScale;
		Actor->SetActorLocation(CurLocation);
	}

	Actor->SetActorScale3D(TargetScale);
}

void UTickActionComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	for(auto kvp: ModelScaleUpdateContexts){
		ModelScaleTick(DeltaTime, kvp.Key);
	}
}

int32 UTickActionComponent::GenerateModelScaleId()
{
	static int32 ModelScaleId = 0;
	ModelScaleId++;
	if (ModelScaleId >= 0x7fffffff)
	{
		ModelScaleId = 1;
	}

	return ModelScaleId;
}
