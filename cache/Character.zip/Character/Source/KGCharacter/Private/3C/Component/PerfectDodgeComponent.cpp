﻿#include "3C/Component/PerfectDodgeComponent.h"

#include "3C/Character/BSAGhostActor.h"
#include "3C/Character/BulletActor.h"
#include "3C/Core/C7ActorInterface.h"
#include "DrawDebugHelpers.h"
#include "KGCharacterModule.h"
#include "TimerManager.h"
#include "Components/CapsuleComponent.h"
#include "Curves/CurveFloat.h"
#include "3C/Effect/KGEffectManager.h"
#include "Engine/World.h"
#include "Managers/KGCombatSettingsManager.h"
#include "Managers/KGCombatUnitManager.h"
#include "3C/Material/KGMaterialCommon.h"
#include "3C/Material/KGMaterialManager.h"
#include "3C/Util/KGUtils.h"

/*
 * ---------------------------------------------------------------------------------
 * PrePhysics:
 *	怪物新增&移除PhysicsQueryCollision
 *	怪物以及武器动画更新(最早)
 *  玩家在当前帧位置创建受击collision(首帧, 最早)
 * ---------------------------------------------------------------------------------
 * StartPhysics: 
 * ---------------------------------------------------------------------------------
 * DuringPhysics:
 *  玩家在当前帧位置创建受击collision(除首帧外)
 *  怪物创建的shape query查询判定
 * ---------------------------------------------------------------------------------
 * EndPhysics: 
 * ---------------------------------------------------------------------------------
 * PostPhysics:
 *	怪物以及武器动画更新(最晚)
 *	玩家在当前帧位置创建受击collision(首帧, 最晚)
 *	玩家位置更新
 * ---------------------------------------------------------------------------------
 * TG_PostUpdateWork:
 *	怪物精确物理查询判定
 * ---------------------------------------------------------------------------------
 */

// 为了避免配置问题导致完美闪避碰撞组件无限制增长, 这里设置一个上限
static int32 PerfectDodgeCollisionComponentMaxNum = 20;
static FAutoConsoleVariableRef CVarPerfectDodgeCollisionComponentMaxNum(
	TEXT("gp.PerfectDodgeCollisionComponentMaxNum"),
	PerfectDodgeCollisionComponentMaxNum,
	TEXT("PerfectDodgeCollisionComponentMaxNum."),
	ECVF_Default
);

static bool bEnablePerfectDodgeDrawDebug = false;
static FAutoConsoleVariableRef CVarEnablePerfectDodgeDrawDebug(
	TEXT("gp.EnablePerfectDodgeDrawDebug"),
	bEnablePerfectDodgeDrawDebug,
	TEXT("EnablePerfectDodgeDrawDebug."),
	ECVF_Default
);

UPerfectDodgeComponent::UPerfectDodgeComponent(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = false;
	PrimaryComponentTick.TickGroup = TG_DuringPhysics;
}

void UPerfectDodgeComponent::TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (bPerfectDodgeEnabled)
	{
		CreatePerfectDodgeCollisionComponent();
	}

	if (PerfectDodgeTimeDilationCurve)
	{
		UpdateActorCustomTickDilation();
	}

#if !UE_BUILD_TEST && !UE_BUILD_SHIPPING
	if (bEnablePerfectDodgeDrawDebug)
	{
		DrawDebugPerfectDodgeCollisionInfos();
	}
#endif
}

void UPerfectDodgeComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	RemoveAllPerfectDodgeCollisions();
	DestroyGhosts();
	
	Super::EndPlay(EndPlayReason);
}

bool UPerfectDodgeComponent::EnablePerfectDodge(float ActiveTime)
{
	if (bPerfectDodgeEnabled)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("PerfectDodge is already enabled, %s"), *GetNameSafe(GetOwner()));
		return false;
	}

	if (ActiveTime < UE_KINDA_SMALL_NUMBER)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UPerfectDodgeComponent::EnablePerfectDodge, invalid CurrentPerfectDodgeActiveTime, %s"), *GetNameSafe(GetOwner()));
		return false;
	}
	
	bPerfectDodgeEnabled = true;
	CurrentPerfectDodgeActiveTime = ActiveTime;
	UpdateComponentTickState();
	RemoveAllPerfectDodgeCollisions();
	CreatePerfectDodgeCollisionComponent();
	return true;
}

bool UPerfectDodgeComponent::DisablePerfectDodge()
{
	if (!bPerfectDodgeEnabled)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("PerfectDodge is already disabled, %s"), *GetNameSafe(GetOwner()));
		return false;
	}
	
	bPerfectDodgeEnabled = false;
	UpdateComponentTickState();
	CreatePerfectDodgeCollisionComponent();
	return true;
}

void UPerfectDodgeComponent::TriggerPerfectDodge(bool bIsAttacker, bool bPropagateToChildUnits)
{
	UE_LOG(LogKGCombat, Log, TEXT("UPerfectDodgeComponent::TriggerPerfectDodge, %s"), *GetNameSafe(GetOwner()));

	if (!UpdateAndCacheManagers())
	{
		return;
	}
	check(CombatSettingsManager.IsValid());
	check(MaterialManager.IsValid());
	check(EffectManager.IsValid());

	if (!CombatSettingsManager->IsPerfectDodgeEnabled())
	{
		UE_LOG(LogKGCombat, Log, TEXT("UPerfectDodgeComponent::TriggerPerfectDodge, perfect dodge is disabled in combat settings, %s"),
			*GetNameSafe(GetOwner()));
		return;
	}

	PerfectDodgeTimeDilationCurve = bIsAttacker ?
		CombatSettingsManager->GetAttackerPerfectDodgeCurve() :
		CombatSettingsManager->GetDefenderPerfectDodgeCurve();
	if (!PerfectDodgeTimeDilationCurve)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UPerfectDodgeComponent::TriggerPerfectDodge, invalid PerfectDodgeTimeDilationCurve, %s"),
			*GetNameSafe(GetOwner()));
		return;
	}
	
	if (!bIsAttacker)
	{
		SpawnGhost();
	}

	bEnableSkillSlomo = bIsAttacker;
	CurrentSkillSlomoSegmentIndex = -1;
	PerfectDodgeStartTimeSeconds = FPlatformTime::Seconds();
	UpdateActorCustomTickDilation();
	UpdateComponentTickState();
	if (AActor* OwnerActor = GetOwner())
	{
		MaterialManager->SetActorEnableTimeDilation(KGUtils::GetIDByObject(OwnerActor), true);
		EffectManager->SetActorEnableTimeDilation(KGUtils::GetIDByObject(OwnerActor), true);	
	}

	if (bPropagateToChildUnits)
	{
		StartChildUnitsPerfectDodge();	
	}
}

void UPerfectDodgeComponent::AddChildUnitsEnableTimeDilation(AActor* InActor)
{
	if (InActor)
	{
		ChildUnitsEnableTimeDilation.Add(InActor);
	}
}

bool UPerfectDodgeComponent::ShouldComponentTick() const
{
	return bEnablePerfectDodgeDrawDebug || bPerfectDodgeEnabled || PerfectDodgeTimeDilationCurve != nullptr;
}

void UPerfectDodgeComponent::UpdateComponentTickState()
{
	const bool bIsComponentTickEnabled = PrimaryComponentTick.IsTickFunctionEnabled();
	const bool bShouldComponentTick = ShouldComponentTick();
	if (bIsComponentTickEnabled != bShouldComponentTick)
	{
		PrimaryComponentTick.SetTickFunctionEnable(bShouldComponentTick);
	}
}

bool UPerfectDodgeComponent::UpdateAndCacheManagers()
{
	if (!CombatSettingsManager.IsValid())
	{
		CombatSettingsManager = UKGCombatSettingsManager::GetInstance(this);
		if (!CombatSettingsManager.IsValid())
		{
			UE_LOG(LogKGCombat, Error, TEXT("UPerfectDodgeComponent::UpdateAndCacheManagers, invalid combat settings manager"));
			return false;
		}
	}
	
	if (!ActorManager.IsValid())
	{
		ActorManager = UKGUEActorManager::GetInstance(this);
		if (!ActorManager.IsValid())
		{
			UE_LOG(LogKGCombat, Error, TEXT("UPerfectDodgeComponent::UpdateAndCacheManagers, invalid ActorManager"));
			return false;
		}
	}
	
	if (!EffectManager.IsValid())
	{
		EffectManager = UKGEffectManager::GetInstance(this);
		if (!EffectManager.IsValid())
		{
			UE_LOG(LogKGCombat, Error, TEXT("UPerfectDodgeComponent::UpdateAndCacheManagers, invalid EffectManager"));
			return false;
		}
	}
	
	if (!MaterialManager.IsValid())
	{
		MaterialManager = UKGMaterialManager::GetInstance(this);
		if (!MaterialManager.IsValid())
		{
			UE_LOG(LogKGCombat, Error, TEXT("UPerfectDodgeComponent::UpdateAndCacheManagers, invalid MaterialManager"));
			return false;
		}
	}

	return true;
}

void UPerfectDodgeComponent::CreatePerfectDodgeCollisionComponent()
{
	if (PerfectDodgeCollisionInfos.Num() >= PerfectDodgeCollisionComponentMaxNum)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("PerfectDodgeCollisionComponents num exceed max num: %d"), PerfectDodgeCollisionComponentMaxNum);
		return;
	}

	const auto CurrentFrameID = GFrameCounter;
	if (PerfectDodgeCollisionInfos.Contains(CurrentFrameID))
	{
		// 当前帧已经创建过碰撞组件, 不重复创建
		return;
	}

	if (CurrentPerfectDodgeActiveTime < UE_KINDA_SMALL_NUMBER)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UPerfectDodgeComponent::CreatePerfectDodgeCollisionComponent, invalid CurrentPerfectDodgeActiveTime, %s"),
			*GetNameSafe(GetOwner()));
		return;
	}

	AActor* OwnerActor = GetOwner();
	if (!OwnerActor)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UPerfectDodgeComponent::CreatePerfectDodgeCollisionComponent, invalid owner"));
		return;
	}

	UWorld* World = OwnerActor->GetWorld();
	if (!World)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UPerfectDodgeComponent::CreatePerfectDodgeCollisionComponent, invalid world"));
		return;
	}

	UCapsuleComponent* CapsuleComponent = Cast<UCapsuleComponent>(OwnerActor->GetRootComponent());
	if (!CapsuleComponent)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("PerfectDodgeComponent owner has no CapsuleComponent as root, %s"), *OwnerActor->GetName());
		return;
	}

	UCapsuleComponent* NewCapsuleComponent = NewObject<UCapsuleComponent>(OwnerActor);
	NewCapsuleComponent->RegisterComponent();
	ULowLevelFunctions::EnableOverlapOptimization(NewCapsuleComponent, true);
	NewCapsuleComponent->SetWorldTransform(CapsuleComponent->GetComponentTransform());
	float Radius, HalfHeight;
	CapsuleComponent->GetUnscaledCapsuleSize(Radius, HalfHeight);
	NewCapsuleComponent->SetCapsuleSize(Radius, HalfHeight, false);
	NewCapsuleComponent->SetCollisionProfileName(CapsuleComponent->GetCollisionProfileName());
	NewCapsuleComponent->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
	
	FKGPerfectDodgeCapsuleCollisionInfo& CollisionInfo = PerfectDodgeCollisionInfos.Add(CurrentFrameID);
	CollisionInfo.CapsuleComponent = NewCapsuleComponent;
	World->GetTimerManager().SetTimer(CollisionInfo.TimeOutTimerHandle,
		FTimerDelegate::CreateUObject(this, &UPerfectDodgeComponent::OnPerfectDodgeCollisionTimeOut, CurrentFrameID),
		CurrentPerfectDodgeActiveTime, false);
}

void UPerfectDodgeComponent::RemovePerfectDodgeCollision(uint64 FrameKey)
{
	auto* CollisionInfoPtr = PerfectDodgeCollisionInfos.Find(FrameKey);
	if (CollisionInfoPtr == nullptr)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UPerfectDodgeComponent::RemovePerfectDodgeCollision, invalid frame key %lld"), FrameKey);
		return;
	}

	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(CollisionInfoPtr->TimeOutTimerHandle);
	}
	else
	{
		UE_LOG(LogKGCombat, Error, TEXT("UPerfectDodgeComponent::RemovePerfectDodgeCollision, invalid world, %s"), *GetNameSafe(GetOwner()));
	}

	if (CollisionInfoPtr->CapsuleComponent)
	{
		CollisionInfoPtr->CapsuleComponent->DestroyComponent();
	}
	else
	{
		UE_LOG(LogKGCombat, Error, TEXT("UPerfectDodgeComponent::RemovePerfectDodgeCollision, invalid CapsuleComponent, %s"),
			*GetNameSafe(GetOwner()));
	}

	PerfectDodgeCollisionInfos.Remove(FrameKey);
}

void UPerfectDodgeComponent::RemoveAllPerfectDodgeCollisions()
{
	if (PerfectDodgeCollisionInfos.Num() == 0)
	{
		return;
	}
	
	TArray<uint64> PerfectDodgeKeys;
	PerfectDodgeCollisionInfos.GenerateKeyArray(PerfectDodgeKeys);
	for (const auto PerfectDodgeKey : PerfectDodgeKeys)
	{
		RemovePerfectDodgeCollision(PerfectDodgeKey);
	}
}

void UPerfectDodgeComponent::OnPerfectDodgeCollisionTimeOut(uint64 FrameKey)
{
	RemovePerfectDodgeCollision(FrameKey);
}

void UPerfectDodgeComponent::DrawDebugPerfectDodgeCollisionInfos()
{
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	if (PerfectDodgeTimeDilationCurve != nullptr)
	{
		const auto CurrentTime = FPlatformTime::Seconds();
		TArray<TWeakObjectPtr<AActor>> TimeDilationActors = ChildUnitsEnableTimeDilation.Array();
		TimeDilationActors.Add(GetOwner());
		for (auto& TimeDilationActor : TimeDilationActors)
		{
			if (TimeDilationActor.IsValid())
			{
				const FString Msg = FString::Printf(TEXT("%.3f, Dilation: %f"),
					CurrentTime - PerfectDodgeStartTimeSeconds, TimeDilationActor->CustomTimeDilation);
				DrawDebugString(World, TimeDilationActor->GetActorLocation(), Msg, nullptr, FColor::Green, 0.0f);		
			}
		}	
	}
	
	for (const auto& Kvp : PerfectDodgeCollisionInfos)
	{
		const auto& CollisionInfo = Kvp.Value;
		if (!CollisionInfo.CapsuleComponent)
		{
			continue;
		}

		DrawDebugCapsule(World, CollisionInfo.CapsuleComponent->GetComponentLocation(),
			CollisionInfo.CapsuleComponent->GetScaledCapsuleHalfHeight(), CollisionInfo.CapsuleComponent->GetScaledCapsuleRadius(),
			CollisionInfo.CapsuleComponent->GetComponentQuat(), FColor::Black, false, 0.0f);
	}

	if (PerfectDodgeCollisionInfos.Num() > 0)
	{
		if (AActor* OwnerActor = GetOwner())
		{
			if (UCapsuleComponent* CapsuleComponent = Cast<UCapsuleComponent>(OwnerActor->GetRootComponent()))
			{
				DrawDebugCapsule(World, CapsuleComponent->GetComponentLocation(),
					CapsuleComponent->GetScaledCapsuleHalfHeight(), CapsuleComponent->GetScaledCapsuleRadius(),
					CapsuleComponent->GetComponentQuat(), FColor::Black, false, 0.0f);
			}
		}
	}
}

void UPerfectDodgeComponent::StartChildUnitsPerfectDodge()
{
	KGEntityID EntityID = KG_INVALID_ENTITY_ID;
	if (IC7ActorInterface* ActorInterface = Cast<IC7ActorInterface>(this))
	{
		EntityID = ActorInterface->GetEntityUID();
	}

	// 单位所有创生物都要跟着减速
	if (EntityID != KG_INVALID_ENTITY_ID)
	{
		if (UKGCombatUnitManager* CombatUnitManager = UKGCombatUnitManager::GetInstance(this))
		{
			TSet<TWeakObjectPtr<ABulletActor>> BulletActors;
			CombatUnitManager->GetAllBulletActorsByInstigatorID(EntityID, BulletActors);
			for (const auto& BulletActorPtr : BulletActors)
			{
				if (BulletActorPtr.IsValid())
				{
					ChildUnitsEnableTimeDilation.Add(BulletActorPtr);
					BulletActorPtr->StartTimeDilationEffect(true);
				}
			}
		}
	}
}

void UPerfectDodgeComponent::UpdateActorCustomTickDilation()
{
	if (!PerfectDodgeTimeDilationCurve)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UPerfectDodgeComponent::UpdateActorCustomTickDilation, invalid PerfectDodgeTimeDilationCurve, %s"),
			*GetNameSafe(GetOwner()));
		return;
	}

	if (!UpdateAndCacheManagers())
	{
		return;
	}
	check(ActorManager.IsValid());
	check(MaterialManager.IsValid());
	check(EffectManager.IsValid());

	AActor* OwnerActor = GetOwner();
	if (!OwnerActor)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UPerfectDodgeComponent::UpdateActorCustomTickDilation, invalid owner"));
		return;
	}
	
	float MinTime, MaxTime;
	PerfectDodgeTimeDilationCurve->GetTimeRange(MinTime, MaxTime);
	if (MaxTime - MinTime < UE_KINDA_SMALL_NUMBER)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UPerfectDodgeComponent::UpdateActorCustomTickDilation, invalid curve time range, %s"),
			*GetNameSafe(GetOwner()));
		return;
	}
	
	// 曲线的计时用绝对时间
	const double CurrentTimeSeconds = FPlatformTime::Seconds();
	const float ElapsedTime = static_cast<float>(CurrentTimeSeconds - PerfectDodgeStartTimeSeconds);
	const float ClampedElapsedTime = FMath::Clamp(ElapsedTime, MinTime, MaxTime);
	const float TimeDilation = PerfectDodgeTimeDilationCurve->GetFloatValue(ClampedElapsedTime);
	// UE内部分组件会check DeltaTime大于0, 因此这里不能设置为0
	float NewDilation = FMath::Max(TimeDilation, UE_KINDA_SMALL_NUMBER);

	const bool bAboutToFinish = ElapsedTime >= MaxTime;
	if (bAboutToFinish)
	{
		NewDilation = 1.0f;
	}

	DoSetCustomTimeDilation(OwnerActor, NewDilation);
	for (const auto& ChildUnit : ChildUnitsEnableTimeDilation)
	{
		DoSetCustomTimeDilation(ChildUnit.Get(), NewDilation);
	}

	// 技能单独处理time dilation
	if (bEnableSkillSlomo)
	{
		DoSkillSlomo(ClampedElapsedTime);
	}

	if (bAboutToFinish)
	{
		UE_LOG(LogKGCombat, Log, TEXT("UPerfectDodgeComponent::UpdateActorCustomTickDilation, PerfectDodge time dilation ended, %s, %f"),
			*GetNameSafe(OwnerActor), ElapsedTime);
		PerfectDodgeTimeDilationCurve = nullptr;
		CurrentSkillSlomoSegmentIndex = -1;
		UpdateComponentTickState();
		MaterialManager->SetActorEnableTimeDilation(KGUtils::GetIDByObject(OwnerActor), false);
		EffectManager->SetActorEnableTimeDilation(KGUtils::GetIDByObject(OwnerActor), false);

		for (const auto& ChildUnit : ChildUnitsEnableTimeDilation)
		{
			if (ABulletActor* BulletActor = Cast<ABulletActor>(ChildUnit.Get()))
			{
				BulletActor->StartTimeDilationEffect(false);	
			}
		}
		ChildUnitsEnableTimeDilation.Empty();

		if (bEnableSkillSlomo)
		{
			if (auto* Entity = ActorManager->GetLuaEntityByActor(OwnerActor))
			{
				Entity->GetLuaEntityBase()->CallLuaFunction(TEXT("KCB_OnClientSkillSlomoRateChanged"), 1.0f);
			}
		}
	}
}

void UPerfectDodgeComponent::DoSetCustomTimeDilation(AActor* InActor, float InTimeDilation)
{
	if (!IsValid(InActor))
	{
		return;
	}

	if (FMath::IsNearlyEqual(InActor->CustomTimeDilation, InTimeDilation))
	{
		return;
	}

	InActor->CustomTimeDilation = InTimeDilation;

	// if (bEnableSkillSlomo)
	// {
	// 	if (auto* Entity = ActorManager->GetLuaEntityByActor(InActor))
	// 	{
	// 		UE_LOG(LogKGCombat, Log, TEXT("UPerfectDodgeComponent::DoSetCustomTimeDilation, skill slomo rate changed: %f, %s"),
	// 			InTimeDilation, *GetNameSafe(InActor));
	// 		Entity->GetLuaEntityBase()->CallLuaFunction(TEXT("KCB_OnClientSkillSlomoRateChanged"), InTimeDilation);
	// 	}
	// }
	
	if (!UpdateAndCacheManagers())
	{
		return;
	}
	check(EffectManager.IsValid());
	
	EffectManager->UpdateNiagaraPlayRateBySpawnerID(KGUtils::GetIDByObject(InActor));
}

void UPerfectDodgeComponent::DoSkillSlomo(float ClampedElapsedTime)
{
	if (!PerfectDodgeTimeDilationCurve)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UPerfectDodgeComponent::DoSkillSlomo, invalid PerfectDodgeTimeDilationCurve, %s"),
			*GetNameSafe(GetOwner()));
		return;
	}
	
	if (!UpdateAndCacheManagers())
	{
		return;
	}
	check(ActorManager.IsValid());
	check(CombatSettingsManager.IsValid());

	AActor* OwnerActor = GetOwner();
	if (!OwnerActor)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UPerfectDodgeComponent::DoSkillSlomo, invalid owner"));
		return;
	}

	auto* Entity = ActorManager->GetLuaEntityByActor(OwnerActor);
	if (!Entity)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UPerfectDodgeComponent::DoSkillSlomo, cannot find entity for owner: %s"),
			*GetNameSafe(OwnerActor));
		return;
	}

	const auto& SkillSlomoSegments = CombatSettingsManager->GetAttackerCurveSlomoRateSegments();
	const int32 NextSkillSlomoSegmentIndex = CurrentSkillSlomoSegmentIndex + 1;
	if (!SkillSlomoSegments.IsValidIndex(NextSkillSlomoSegmentIndex))
	{
		return;
	}

	const auto NextTriggerTime = SkillSlomoSegments[NextSkillSlomoSegmentIndex].SegmentStartTime;
	if (ClampedElapsedTime < NextTriggerTime)
	{
		return;
	}

	CurrentSkillSlomoSegmentIndex = NextSkillSlomoSegmentIndex;
	const auto NewPlayRate = SkillSlomoSegments[NextSkillSlomoSegmentIndex].SegmentAvgSlomoRate;
	UE_LOG(LogKGCombat, Log, TEXT("UPerfectDodgeComponent::DoSkillSlomo, skill slomo rate changed: %f, %s"),
		NewPlayRate, *GetNameSafe(OwnerActor));
	Entity->GetLuaEntityBase()->CallLuaFunction(TEXT("KCB_OnClientSkillSlomoRateChanged"), NewPlayRate);
}

void UPerfectDodgeComponent::SpawnGhost()
{
	SCOPED_NAMED_EVENT(UPerfectDodgeComponent_SpawnGhost, FColor::Red);
	
	UWorld* World = GetWorld();
	if (!World)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UPerfectDodgeComponent::SpawnGhost, invalid world"));
		return;
	}
	
	AActor* OwnerActor = GetOwner();
	if (!OwnerActor)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UPerfectDodgeComponent::SpawnGhost, invalid owner"));
		return;
	}
	
	if (!UpdateAndCacheManagers())
	{
		return;
	}
	check(MaterialManager.IsValid());
	check(CombatSettingsManager.IsValid());
	
	const float DitherDuration = CombatSettingsManager->GetDitherDuration();
	if (DitherDuration <= UE_KINDA_SMALL_NUMBER)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UPerfectDodgeComponent::SpawnGhost, invalid dither duration %f"), DitherDuration);
		return;
	}
	
	const auto& SpawnTransform = OwnerActor->GetActorTransform();
	ABSAGhostActor* GhostActor = Cast<ABSAGhostActor>(World->SpawnActor(ABSAGhostActor::StaticClass(), &SpawnTransform));
	if (!GhostActor)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UPerfectDodgeComponent::SpawnGhost, spawn ghost actor failed"));
		return;
	}
	
	GhostActor->CopyPoseFromCreator(KGUtils::GetIDByObject(OwnerActor), false, false, true);
	KGObjectID GhostActorID = KGUtils::GetIDByObject(OwnerActor);
	auto& GhostInfo = GhostInfos.Add(GhostActorID);
	GhostInfo.GhostActor = GhostActor;
	
	FKGChangeMaterialParamRequest ChangeMaterialParamRequest;
	ChangeMaterialParamRequest.OwnerActor = GhostActor;
	ChangeMaterialParamRequest.EffectType = EKGMaterialEffectType::Dissolve;
	auto& Params = ChangeMaterialParamRequest.ScalarLinearSampleParams.Add(CombatSettingsManager->GetDitherAlphaParamName());
	Params.StartVal = 0.0f;
	Params.EndVal = 1.0f;
	Params.Duration = CombatSettingsManager->GetDitherDuration();
	MaterialManager->ChangeMaterialParam(ChangeMaterialParamRequest);
	
	World->GetTimerManager().SetTimer(GhostInfo.GhostActorLifeTimeHandle, 
		FTimerDelegate::CreateUObject(this, &UPerfectDodgeComponent::OnGhostTimeOut, GhostActorID), DitherDuration, false);
}

void UPerfectDodgeComponent::DestroyGhosts()
{
	for (auto& Kvp : GhostInfos)
	{
		DestroyGhost(Kvp.Value);
	}
	
	GhostInfos.Empty();
}

void UPerfectDodgeComponent::DestroyGhost(FKGPerfectDodgeGhostInfo& GhostInfo)
{
	UE_LOG(LogKGCombat, Log, TEXT("UPerfectDodgeComponent::DestroyGhost, %s"), *GetNameSafe(GhostInfo.GhostActor));
	
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}
	World->GetTimerManager().ClearTimer(GhostInfo.GhostActorLifeTimeHandle);

	if (!IsValid(GhostInfo.GhostActor))
	{
		return;
	}
	
	if (!UpdateAndCacheManagers())
	{
		return;
	}
	check(MaterialManager.IsValid());
	
	MaterialManager->RevertMaterialAndMaterialParamsOnActorDestroy(KGUtils::GetIDByObject(GhostInfo.GhostActor), false);
	GhostInfo.GhostActor->Destroy();
}

void UPerfectDodgeComponent::OnGhostTimeOut(KGObjectID GhostActorID)
{
	if (!GhostInfos.Contains(GhostActorID))
	{
		return;
	}
	auto& GhostInfo = GhostInfos[GhostActorID];
	UE_LOG(LogKGCombat, Log, TEXT("UPerfectDodgeComponent::OnGhostTimeOut, %s"), *GetNameSafe(GhostInfo.GhostActor));
	DestroyGhost(GhostInfo);
	
	GhostInfos.Remove(GhostActorID);
}
