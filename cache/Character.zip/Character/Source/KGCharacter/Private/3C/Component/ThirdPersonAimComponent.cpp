// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Component/ThirdPersonAimComponent.h"

#include "3C/Character/BaseCharacter.h"
#include "3C/Controller/BasePlayerController.h"
#include "3C/Core/C7ActorInterface.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/HitResult.h"


// Sets default values for this component's properties
UThirdPersonAimComponent::UThirdPersonAimComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;
}

// Called every frame
void UThirdPersonAimComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	
	if (bEnableAimSupport)
	{
		DetectAimTargetWithSupport();
	}
	else
	{
		DetectAimTarget();
	}
}

void UThirdPersonAimComponent::StartAim(const TArray<int32>& InObjectTypes)
{
	StopAim();
	
	ObjectTypes.Append(InObjectTypes);

	bEnableAimSupport = false;
	bFirstDetect = true;
	SetComponentTickEnabled(true);
}

void UThirdPersonAimComponent::StopAim()
{
	ObjectTypes.Empty();
	TargetActors.Empty();
	LastDetectedEntityID = 0;
	bFirstDetect = false;
	
	SetComponentTickEnabled(false);
}

void UThirdPersonAimComponent::DetectAimTarget()
{
	ABaseCharacter* Character = Cast<ABaseCharacter>(GetOwner());
	if (!Character)
	{
		return;
	}

	ABasePlayerController* PlayerController = Cast<ABasePlayerController>(Character->GetController());
	if (!PlayerController)
	{
		return;
	}
	
	// 获取屏幕中心点位
	int32 ViewportX = 0, ViewportY = 0;
	PlayerController->GetViewportSize(ViewportX, ViewportY);
	FVector2D ScreenCenter(ViewportX / 2, ViewportY / 2);
	
	int64 EntityID = 0;
	FHitResult HitResult;
	if (PlayerController->GetHitResultAtScreenPosition(ScreenCenter, ObjectTypes, false, HitResult))
	{
		EntityID = UKGUEActorManager::GetLuaEntityIDByActor(HitResult.GetActor());
	}

	// ID相同,不回调
	if (EntityID == LastDetectedEntityID)
	{
		return;
	}

	LastDetectedEntityID = EntityID;

	if (ICppEntityInterface* OwnerCppEntityInterface = UKGUEActorManager::GetLuaEntityByActor(GetOwner()))
	{
		if (LuaEntityBase* OwnerLuaEntity = OwnerCppEntityInterface->GetLuaEntityBase())
		{
			OwnerLuaEntity->CallLuaFunction(TEXT("KCB_OnAimTargetChange"), EntityID);		
		}
	}
}

void UThirdPersonAimComponent::StartAimWithSupport(const TArray<int32>& InObjectTypes, const TMap<TWeakObjectPtr<AActor>, FString>& InTargetActors, int32 InSupportAimRadius, int32 InFirstTimeSupportAimRadius, double InEscapeProtectTime)
{
	StopAim();
	
	ObjectTypes.Append(InObjectTypes);
	TargetActors.Append(InTargetActors);
	SupportAimRadius = InSupportAimRadius;
	FirstTimeSupportAimRadius = InFirstTimeSupportAimRadius;
	EscapeProtectTime = InEscapeProtectTime;

	bFirstDetect = true;
	bEnableAimSupport = true;
	SetComponentTickEnabled(true);
}

void UThirdPersonAimComponent::AddTargetActor(AActor* InActor, const FString& BoneName)
{
	TargetActors.Emplace(InActor, BoneName);
}

void UThirdPersonAimComponent::DetectAimTargetWithSupport()
{
	ABaseCharacter* Character = Cast<ABaseCharacter>(GetOwner());
	if (!Character)
	{
		return;
	}

	ABasePlayerController* PlayerController = Cast<ABasePlayerController>(Character->GetController());
	if (!PlayerController)
	{
		return;
	}

	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	// 获取屏幕中心点位
	int32 ViewportX = 0, ViewportY = 0;
	PlayerController->GetViewportSize(ViewportX, ViewportY);
	FVector2D ScreenCenter(ViewportX / 2, ViewportY / 2);

	// 先做瞄准检测,这里和辅助瞄准无关,只是检测屏幕中心的目标
	DetectAimTarget();
	
	double CurTimeSeconds = World->GetTimeSeconds();

	// 如果处于自瞄保护期内,不进行自瞄的计算
	if (NextSupportAimTime > 0)
	{
		if (CurTimeSeconds < NextSupportAimTime)
		{
			// 逃逸保护期内
			return;
		}
		else
		{
			// 逃逸保护期到了,下一帧进行检测
			NextSupportAimTime = -1;
			return;
		}
	}
	
	// 检测屏幕上离准心最近的单位
	FVector2D TargetScreenPos;
	double MinDistance = UE_BIG_NUMBER;
	AActor* NearestActor = nullptr;
	int32 AnimDetectRadius = bFirstDetect ? FirstTimeSupportAimRadius : SupportAimRadius;

	for (auto& It : TargetActors)
	{
		TWeakObjectPtr<AActor> Actor = It.Key;
		if (!Actor.IsValid())
		{
			continue;
		}

		const FName& BoneName = FName(It.Value);
		FVector AimLocation = Actor->GetActorLocation();
		if (BoneName.IsValid())
		{
			if (ABaseCharacter* TargetCharacter = Cast<ABaseCharacter>(Actor))
			{
				if (USkeletalMeshComponent* SkMeshComp = TargetCharacter->GetMainMesh())
				{
					int32 BoneIndex = SkMeshComp->GetBoneIndex(BoneName);
					if (BoneIndex != INDEX_NONE)
					{
						AimLocation = SkMeshComp->GetBoneLocation(BoneName);	
					}
				}
			}
		}
		
		if (PlayerController->ProjectWorldLocationToScreen(AimLocation, TargetScreenPos))
		{
			double Distance = FVector2D::Distance(TargetScreenPos, ScreenCenter);
			if (Distance <= AnimDetectRadius && Distance < MinDistance)
			{
				MinDistance = Distance;
				NearestActor = Actor.Get();
			}
		}
	}

	if (ICppEntityInterface* OwnerCppEntityInterface = UKGUEActorManager::GetLuaEntityByActor(GetOwner()))
	{
		if (LuaEntityBase* OwnerLuaEntity = OwnerCppEntityInterface->GetLuaEntityBase())
		{
			if (SupportAimTargetEntityID != 0 && !NearestActor)
			{
				// 如果当前有吸附目标,且新算出来的辅助瞄准目标为空,则认为进入逃逸保护期
				SupportAimTargetEntityID = 0;
				NextSupportAimTime = CurTimeSeconds + EscapeProtectTime;
				OwnerLuaEntity->CallLuaFunction(TEXT("KCB_OnSupportAimEscape"));
			}
			else if (SupportAimTargetEntityID == 0 && NearestActor)
			{
				// 没有吸附目标的情况下检测到了目标,通知业务层
				SupportAimTargetEntityID = UKGUEActorManager::GetLuaEntityIDByActor(NearestActor);
				OwnerLuaEntity->CallLuaFunction(TEXT("KCB_OnSupportAimHit"), SupportAimTargetEntityID);
				bFirstDetect = false;
			}
		}
	}
}
