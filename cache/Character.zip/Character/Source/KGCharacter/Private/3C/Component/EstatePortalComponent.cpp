// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Component/EstatePortalComponent.h"

#include "3C/Controller/BasePlayerController.h"
#include "3C/Camera/CameraManager.h"
#include "3C/Material/KGMaterialCommon.h"
#include "Kismet/GameplayStatics.h"

UEstatePortalComponent::UEstatePortalComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	SetTickGroup(TG_PostUpdateWork);
}

void UEstatePortalComponent::BeginPlay()
{
	Super::BeginPlay();
	SceneCaptureComponent = Cast<USceneCaptureComponent2D>(GetOwner()->GetComponentByClass(USceneCaptureComponent2D::StaticClass()));
}

void UEstatePortalComponent::TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (!TargetPortal.IsValid() || !TargetPortal->SceneCaptureComponent.IsValid())
		return;

	ACameraManager* CameraManager = Cast<ACameraManager>(UGameplayStatics::GetPlayerCameraManager(GetWorld(), 0));
	if (!CameraManager)
		return;
	
	FVector SourceLocation = CameraManager->GetCameraLocation();
	FRotator SourceRotation = CameraManager->GetCameraRotation();
	
	FVector TargetPosition = GetMirrorLocation(SourceLocation);
	FRotator TargetRotation = GetMirrorRotation(SourceRotation);
	
	TargetPortal->SceneCaptureComponent->SetWorldLocationAndRotation(TargetPosition, TargetRotation);
}

FVector UEstatePortalComponent::GetMirrorLocation(const FVector& SourceLocation)
{
	if (!TargetPortal.IsValid())
		return FVector::ZeroVector;
	
	FTransform SourcePortalTransform = this->GetComponentTransform();
	FTransform TargetPortalTransform = TargetPortal->GetComponentTransform();
	
	// 计算相对于当前传送门的局部位置
	FVector Location = SourcePortalTransform.InverseTransformPosition(SourceLocation);
	Location = FVector(-Location.X, -Location.Y, Location.Z);
	
	return TargetPortalTransform.TransformPosition(Location);
}

FRotator UEstatePortalComponent::GetMirrorRotation(const FRotator& SourceRotation)
{
	if (!TargetPortal.IsValid())
		return FRotator::ZeroRotator;
	
	FTransform SourcePortalTransform = this->GetComponentTransform();
	FTransform TargetPortalTransform = TargetPortal->GetComponentTransform();
	
	// 转换为四元数以进行旋转运算
	FQuat SourceQuat = SourceRotation.Quaternion();
	
	// 计算相对当前传送门的局部旋转
	FQuat PortalQuat = SourcePortalTransform.GetRotation();
	SourceQuat = PortalQuat.Inverse() * SourceQuat;
	
	// 应用镜像旋转
	SourceQuat = FQuat(0,0,1,0) * SourceQuat;  // 先镜像，后应用原旋转

	// 转换到目标传送门的旋转空间
	FQuat TargetRotation = TargetPortalTransform.GetRotation() * SourceQuat;

	return TargetRotation.Rotator();
}
