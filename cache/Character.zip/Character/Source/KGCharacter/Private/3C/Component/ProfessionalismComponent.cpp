// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Component/ProfessionalismComponent.h"

#include "3C/Core/AttachJointComponent_V2.h"
#include "3C/Animation/BaseAnimInstance.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Character/C7Actor.h"
#include "Manager/KGCppAssetManager.h"
#include "Manager/KGObjectActorManager.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "SkeletalMeshComponentBudgeted.h"
#include "3C/Character/SeerAttachActor.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/StaticMesh.h"
#include "Engine/World.h"
#include "UObject/ConstructorHelpers.h"
#include "3C/Util/KGUtils.h"

// Sets default values for this component's properties
UProfessionalismComponent::UProfessionalismComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// ...
}

UProfessionalismComponent::~UProfessionalismComponent()
{
}

void UProfessionalismComponent::ResetToDefaultsForCache()
{
	// 取消资源加载
	if (AssetLoadIDList.Num() > 0)
	{
		if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this))
		{
			for (int i=0; i<AssetLoadIDList.Num(); i++)
			{
				AssetManager->CancelAsyncLoadByLoadID(AssetLoadIDList[i]);
			}
		}
		AssetLoadIDList.Empty();
	}
	
	if (SeerForwardActor)
	{
		SeerForwardActor->RemoveAttachFromLogicParent();
		SeerForwardActor->SetActorHiddenInGame(true);
		SeerForwardActor->Destroy();
		SeerForwardActor = nullptr;
	}

	if (SeerBackActor)
	{
		SeerBackActor->RemoveAttachFromLogicParent();
		SeerBackActor->SetActorHiddenInGame(true);
		SeerBackActor->Destroy();
		SeerBackActor = nullptr;
	}

	bSeerFrontInit = false;
	bSeerBackInit = false;
	SeerHideBoneNameList.Empty();
	SeerCardBoneNameListMap.Empty();
	SeerFrontCardPathList.Empty();
	SeerMapOfMeshPath.Empty();
	SeerFrontCardListOne.Empty();
	SeerFrontCardListTwo.Empty();
	SeerFrontCardPathListCache.Empty();
	SeerFrontCardExpandAnim = nullptr;
	
	SeerCurBackHideIndex = -1;
	bLogicVisibility = true;
	DissolveEffectID = -1;
	FrontCardUniqueID = -1;
	FrontCardRelLocation = FVector::ZeroVector;
}

void UProfessionalismComponent::SetComponentSignificance(float Significance, bool bNeverSkip, bool bTickEvenIfNotRendered, bool bAllowReducedWork, bool bForceInterpolate)
{
	if (ProfessionalType == EProfessionalType::Seer)
	{
		if (SeerForwardActor)
		{
			if (USkeletalMeshComponentBudgeted* SKBudgetedCom = Cast< USkeletalMeshComponentBudgeted>(SeerForwardActor->GetMainMesh()))
			{
				if (!SKBudgetedCom->IsAnimationBudgetRegisted()) {
					SKBudgetedCom->RegisterToAllocatorBudget();
				}
				SKBudgetedCom->SetComponentSignificance(Significance, bNeverSkip, bTickEvenIfNotRendered, bAllowReducedWork, bForceInterpolate);
			}
		}
		if (SeerBackActor)
		{
			if (USkeletalMeshComponentBudgeted* SKBudgetedCom = Cast< USkeletalMeshComponentBudgeted>(SeerBackActor->GetMainMesh()))
			{
				if (!SKBudgetedCom->IsAnimationBudgetRegisted()) {
					SKBudgetedCom->RegisterToAllocatorBudget();
				}
				SKBudgetedCom->SetComponentSignificance(Significance, bNeverSkip, bTickEvenIfNotRendered, bAllowReducedWork, bForceInterpolate);
			}
		}
	}
}


// Called when the game starts
void UProfessionalismComponent::BeginPlay()
{
	Super::BeginPlay();

	// ...
	
}

void UProfessionalismComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
	
	ResetToDefaultsForCache();
}


// Called every frame
void UProfessionalismComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
}

void UProfessionalismComponent::InitSeerFrontActor(FString FActorClass, FName FAttachSocket, float RelLocX, float IdleRelLocY, float RunRelLocY, float SprintRelLocY, float IdleRelLocZ, float RunRelLocZ, float SprintRelLocZ,
		FRotator FSocketRelRot, bool bFDoCollision, float FProbeSize, const TArray<int>& CollisionChannels, float FBezierStep, float FBezierStepMaxDist, float FBezierSpeedAlpha, float FBezierLagSpeed,
		float FBezierDirectionMultiplier, float FAttachRotationLagSpeed, bool bFClampPitch, float FPitchAngleMin, float FPitchAngleMax, float FFaceToDirTolerance, float FRotateRoundTime)
{
	UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this);
	if (!AssetManager)
	{
		UE_LOG(LogTemp, Error, TEXT("invalid asset manager"));
		return ;
	}

	SeerForwardInitParam.ActorClass = FActorClass;
	SeerForwardInitParam.AttachSocket = FAttachSocket;
	SeerForwardInitParam.SocketIdleRelLoc = FVector(RelLocX, IdleRelLocY, IdleRelLocZ);
	SeerForwardInitParam.SocketRunRelLoc = FVector(RelLocX, RunRelLocY, RunRelLocZ);
	SeerForwardInitParam.SocketSprintRelLoc = FVector(RelLocX, SprintRelLocY, SprintRelLocZ);
	SeerForwardInitParam.SocketRelRot = FSocketRelRot;
	SeerForwardInitParam.bDoCollision = bFDoCollision;
	SeerForwardInitParam.ProbeSize = FProbeSize;
	SeerForwardInitParam.CollisionChannels = CollisionChannels;
	SeerForwardInitParam.BezierStep = FBezierStep;
	SeerForwardInitParam.BezierStepMaxDist = FBezierStepMaxDist;
	SeerForwardInitParam.BezierSpeedAlpha = FBezierSpeedAlpha;
	SeerForwardInitParam.BezierLagSpeed = FBezierLagSpeed;
	SeerForwardInitParam.BezierDirectionMultiplier = FBezierDirectionMultiplier;
	SeerForwardInitParam.AttachRotationLagSpeed = FAttachRotationLagSpeed;
	SeerForwardInitParam.bClampPitch = bFClampPitch;
	SeerForwardInitParam.PitchAngleMin = FPitchAngleMin;
	SeerForwardInitParam.PitchAngleMax = FPitchAngleMax;
	SeerForwardInitParam.FaceToDirTolerance = FFaceToDirTolerance;
	SeerForwardInitParam.RotateRoundTime = FRotateRoundTime;
	bSeerFrontInit = true;
	
	AssetManager->AsyncLoadAsset(FActorClass, FAsyncLoadCompleteDelegate::CreateUObject(this, &UProfessionalismComponent::OnSeerFrontActorClassLoaded), static_cast<int32>(EAssetLoadPriority::Default));
}

void UProfessionalismComponent::InitSeerBackActor(FString BActorClass, FName BAttachSocket, FVector BSocketRelLoc, FRotator BSocketRelRot, bool bBDoCollision, float BProbeSize, const TArray<int>& CollisionChannels, float BBezierStep,
	float BBezierStepMaxDist, float BBezierSpeedAlpha, float BBezierLagSpeed, float BBezierDirectionMultiplier, float BAttachRotationLagSpeed, bool bBClampPitch, float BPitchAngleMin, float BPitchAngleMax, float BFaceToDirTolerance,
	float BRotateRoundTime)
{
	UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this);
	if (!AssetManager)
	{
		UE_LOG(LogTemp, Error, TEXT("invalid asset manager"));
		return ;
	}

	SeerBackInitParam.ActorClass = BActorClass;
	SeerBackInitParam.AttachSocket = BAttachSocket;
	SeerBackInitParam.SocketIdleRelLoc = BSocketRelLoc;
	SeerBackInitParam.SocketRelRot = BSocketRelRot;
	SeerBackInitParam.bDoCollision = bBDoCollision;
	SeerBackInitParam.ProbeSize = BProbeSize;
	SeerBackInitParam.CollisionChannels = CollisionChannels;
	SeerBackInitParam.BezierStep = BBezierStep;
	SeerBackInitParam.BezierStepMaxDist = BBezierStepMaxDist;
	SeerBackInitParam.BezierSpeedAlpha = BBezierSpeedAlpha;
	SeerBackInitParam.BezierLagSpeed = BBezierLagSpeed;
	SeerBackInitParam.BezierDirectionMultiplier = BBezierDirectionMultiplier;
	SeerBackInitParam.AttachRotationLagSpeed = BAttachRotationLagSpeed;
	SeerBackInitParam.bClampPitch = bBClampPitch;
	SeerBackInitParam.PitchAngleMin = BPitchAngleMin;
	SeerBackInitParam.PitchAngleMax = BPitchAngleMax;
	SeerBackInitParam.FaceToDirTolerance = BFaceToDirTolerance;
	SeerBackInitParam.RotateRoundTime = BRotateRoundTime;
	bSeerBackInit = true;
	
	AssetManager->AsyncLoadAsset(BActorClass, FAsyncLoadCompleteDelegate::CreateUObject(this, &UProfessionalismComponent::OnSeerBackActorClassLoaded), static_cast<int32>(EAssetLoadPriority::Default));
}

void UProfessionalismComponent::InitSeerCardParam(const TArray<FName>& HideBoneNameList, const TArray<FName>& OneCardNameList, const TArray<FName>& TwoCardNameList, const TArray<FName>& ThreeCardNameList, const TArray<FName>& FourCardNameList,
		const TArray<FName>& FiveCardNameList, FString FrontCardAnimPath)
{
	SeerHideBoneNameList = HideBoneNameList;
	SeerCardBoneNameListMap.Add(1, OneCardNameList);
	SeerCardBoneNameListMap.Add(2, TwoCardNameList);
	SeerCardBoneNameListMap.Add(3, ThreeCardNameList);
	SeerCardBoneNameListMap.Add(4, FourCardNameList);
	SeerCardBoneNameListMap.Add(5, FiveCardNameList);

	UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this);
	if (!AssetManager)
	{
		UE_LOG(LogTemp, Error, TEXT("invalid asset manager"));
		return ;
	}
	AssetManager->AsyncLoadAsset(FrontCardAnimPath, FAsyncLoadCompleteDelegate::CreateUObject(this, &UProfessionalismComponent::OnSeerFrontCardExpandAnimLoaded), static_cast<int32>(EAssetLoadPriority::Default));
}

void UProfessionalismComponent::RegisterSeerMeshIDWithPath(int IDOne, FString PathOne, int IDTwo, FString PathTwo)
{
	FrontCardListOneID = IDOne;
	FrontCardListTwoID = IDTwo;
	
	SeerMapOfMeshPath.Add(IDOne, PathOne);
	SeerMapOfMeshPath.Add(IDTwo, PathTwo);

	for (auto& Component : SeerFrontCardListOne){
		Component.ResetMeshComponent();
	}
	for (auto& Component : SeerFrontCardListTwo){
		Component.ResetMeshComponent();
	}
}

void UProfessionalismComponent::RemoveBackCardAndAddFrontCard(int MeshID, int Index)
{
	if (!SeerMapOfMeshPath.Contains(MeshID))
	{
		if (bSeerFrontInit && bSeerBackInit)
		{
			UE_LOG(LogTemp, Error, TEXT("UProfessionalismComponent::RemoveBackCardAndAddFrontCard	SeerMapOfMeshPath no key MeshID:%i"), MeshID)
		}
		return;
	}
	
	if (!SeerBackActor)
	{
		if (bSeerBackInit)
		{
			// 异步加载中 只做数据缓存
			if (Index >=0 && Index < SeerFrontCardPathListCache.Num())
			{
				SeerFrontCardPathListCache.Insert(MeshID, Index);
			}
			else
			{
				SeerFrontCardPathListCache.Add(MeshID);
			}
		}
		return;
	}
	
	int MaxBoneAdjust = SeerHideBoneNameList.Num();
	if (SeerCurBackHideIndex + 1 >= MaxBoneAdjust)
	{
		UE_LOG(LogTemp, Error, TEXT("UProfessionalismComponent::RemoveBackCardAndAddFrontCard	SeerCurBackHideIndex:%i"), SeerCurBackHideIndex + 1)
		return;
	}
	
	USkeletalMeshComponent* MainMesh = SeerBackActor->GetMainMesh();
	UBaseAnimInstance* AnimInstance = MainMesh ? Cast<UBaseAnimInstance>(MainMesh->GetAnimInstance()) : nullptr;
	if (!MainMesh || !AnimInstance)
	{
		UE_LOG(LogTemp, Error, TEXT("UProfessionalismComponent::RemoveBackCardAndAddFrontCard	MainMesh or AnimInstance == nullptr"))
		return;
	}

	// 缩放背部骨骼
	SeerCurBackHideIndex += 1;
	if (SeerCurBackHideIndex < SeerHideBoneNameList.Num())
	{
		AnimInstance->AddModifyBoneParam(SeerHideBoneNameList[SeerCurBackHideIndex], EC7BoneModificationMode::BMM_Ignore, EC7BoneModificationMode::BMM_Ignore, EC7BoneModificationMode::BMM_Replace,
		EBoneControlSpace::BCS_BoneSpace, 0,0,0,0,0,0,0.01,0.01,0.01, NAME_None, 0.f);
	}

	// 添加前面骨骼预览模型 & 刷新排位顺序
	if (Index >=0 && Index < SeerFrontCardPathList.Num())
	{
		SeerFrontCardPathList.Insert(MeshID, Index);
	}
	else
	{
		SeerFrontCardPathList.Add(MeshID);
	}
		
	SeerUpdateFrontCardView();
}

void UProfessionalismComponent::RemoveBackCardAndAddFrontCardList(const TArray<int>& CardIDList)
{
	for (auto PathID : CardIDList)
	{
		RemoveBackCardAndAddFrontCard(PathID, -1);
	}
}

void UProfessionalismComponent::RecoverySeerFrontOneCard(int Index)
{
	if (!SeerForwardActor || !SeerBackActor)
	{
		// 移除缓存
		if (bSeerFrontInit && bSeerBackInit && SeerFrontCardPathListCache.Num() > 0)
		{
			if (Index < SeerFrontCardPathListCache.Num())
			{
				SeerFrontCardPathListCache.RemoveAt(Index);
			}
			else
			{
				UE_LOG(LogTemp, Error, TEXT("UProfessionalismComponent::RecoverySeerFrontOneCard	RemoveIndex:%d	MaxNum:%d"), Index, SeerFrontCardPathListCache.Num())
			}
		}
		return;
	}
	
	if (SeerFrontCardPathList.Num() == 0) return;

	// 移除骨骼缩放
	USkeletalMeshComponent* MainMesh = SeerBackActor ? SeerBackActor->GetMainMesh() : nullptr;
	UBaseAnimInstance* AnimInstance = MainMesh ? Cast<UBaseAnimInstance>(MainMesh->GetAnimInstance()) : nullptr;
	if (!MainMesh || !AnimInstance)
	{
		if (bSeerBackInit)
		{
			UE_LOG(LogTemp, Error, TEXT("UProfessionalismComponent::RecoverySeerFrontOneCard	MainMesh or AnimInstance == nullptr"))
		}
		return;
	}
	
	if (SeerCurBackHideIndex >= 0 && SeerCurBackHideIndex < SeerHideBoneNameList.Num())
	{
		AnimInstance->RemoveModifyBone(SeerHideBoneNameList[SeerCurBackHideIndex]);
		SeerCurBackHideIndex -= 1;
	}
	
	// 刷新卡牌显示
	if (Index < SeerFrontCardPathList.Num())
	{
		SeerFrontCardPathList.RemoveAt(Index);
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("UProfessionalismComponent::RecoverySeerFrontOneCard	RemoveIndex:%d	MaxNum:%d"), Index, SeerFrontCardPathList.Num())
		return;
	}
	
	SeerUpdateFrontCardView();
}

void UProfessionalismComponent::RecoverySeerCard()
{
	if (!SeerBackActor)
	{
		if (bSeerBackInit)
		{
			SeerFrontCardPathListCache.Empty();
		}
		return;
	}
	
	USkeletalMeshComponent* MainMesh = SeerBackActor->GetMainMesh();
	UBaseAnimInstance* AnimInstance = MainMesh ? Cast<UBaseAnimInstance>(MainMesh->GetAnimInstance()) : nullptr;
	if (!MainMesh || !AnimInstance)
	{
		UE_LOG(LogTemp, Error, TEXT("UProfessionalismComponent::RecoverySeerCard	MainMesh or AnimInstance == nullptr"))
		return;
	}

	SeerCurBackHideIndex = -1;
	SeerFrontCardPathList.Empty();
	// 移除后面卡牌的骨骼缩放
	for (auto BoneName : SeerHideBoneNameList)
	{
		AnimInstance->RemoveModifyBone(BoneName);
	}

	// 移除前面卡牌的挂接 Mesh
	for (auto Component : SeerFrontCardListOne)
	{
		Component.StaticMeshComponent->SetVisibility(false);
	}
	for (auto Component : SeerFrontCardListTwo)
	{
		Component.StaticMeshComponent->SetVisibility(false);
	}
}

void UProfessionalismComponent::UpdateSeerProfessionalActorVisibility(bool bVisible, int DissolveID, bool bWeaponDissolve)
{
	bLogicVisibility = bVisible;
	DissolveEffectID = DissolveID;
	
	FKGAttachExtraDissolveInfo ExtraDissolveInfo;
	if (bWeaponDissolve)
	{
		ExtraDissolveInfo.DissolveType = EKGAttachActorDissolveType::SeerCardDissolve;
	}
	
	if (SeerForwardActor)
	{
		ExtraDissolveInfo.bForwardCard = true;
		ExtraDissolveInfo.bBackCard = false;
		SeerForwardActor->SetVisibilityBySelf(DissolveID, bVisible, ExtraDissolveInfo);
	}

	if (SeerBackActor)
	{
		ExtraDissolveInfo.bForwardCard = false;
		ExtraDissolveInfo.bBackCard = true;
		SeerBackActor->SetVisibilityBySelf(DissolveID, bVisible, ExtraDissolveInfo);
	}
}

void UProfessionalismComponent::SyncSeerAnimParam(UBaseAnimInstance* ParentAnimIns, float DeltaSeconds)
{
	if (!ParentAnimIns || !SeerBackActor) return;

	USkeletalMeshComponent* BackActorMainMesh = Cast<USkeletalMeshComponent>(SeerBackActor->GetMainMesh());
	UBaseAnimInstance* BackActorAnimInstance = BackActorMainMesh ? Cast<UBaseAnimInstance>(BackActorMainMesh->GetAnimInstance()) :nullptr;
		
	if (BackActorAnimInstance)
	{
		BackActorAnimInstance->bUseIdleFightABPVar = ParentAnimIns->bUseIdleFightABPVar;
		BackActorAnimInstance->DelayedAnimMovePosture = ParentAnimIns->DelayedAnimMovePosture;
		BackActorAnimInstance->bIsWalkDelayedAnimMovePosture = ParentAnimIns->bIsWalkDelayedAnimMovePosture;
		BackActorAnimInstance->bIsRunDelayedAnimMovePosture = ParentAnimIns->bIsRunDelayedAnimMovePosture;
		BackActorAnimInstance->bIsSprintDelayedAnimMovePosture = ParentAnimIns->bIsSprintDelayedAnimMovePosture;
		BackActorAnimInstance->RelInputAxisToForward = ParentAnimIns->RelInputAxisToForward;
		BackActorAnimInstance->RelInputAxisToRight = ParentAnimIns->RelInputAxisToRight;
		
		BackActorAnimInstance->bIsALSMode = ParentAnimIns->bIsALSMode;
		if (ParentAnimIns->bIsALSMode)
		{
			BackActorAnimInstance->ALSLocoDirection = ParentAnimIns->ALSLocoDirection;
			BackActorAnimInstance->bRotateL = ParentAnimIns->bRotateL;
			BackActorAnimInstance->bRotateR = ParentAnimIns->bRotateR;

			// 181 InPlace 转向逻辑
			BackActorAnimInstance->AlsIdleIndex = 0;
			if (ParentAnimIns->bAlsTurnLeft90IP)
			{
				BackActorAnimInstance->AlsIdleIndex = 1;
			}
			else if (ParentAnimIns->bAlsTurnRight90IP)
			{
				BackActorAnimInstance->AlsIdleIndex = 2;
			}
			else if (ParentAnimIns->bAlsTurnLeft180IP)
			{
				BackActorAnimInstance->AlsIdleIndex = 3;
			}
			else if (ParentAnimIns->bAlsTurnRight180IP)
			{
				BackActorAnimInstance->AlsIdleIndex = 4;
			}

			ABaseCharacter* Owner = Cast<ABaseCharacter>(GetOwner());
			URoleMovementComponent* RoleMovement = Owner ? Cast<URoleMovementComponent>(Owner->GetMovementComponent()) : nullptr;
			if (RoleMovement)
			{
				BackActorAnimInstance->SetLocEnableInputAxis(true);
				BackActorAnimInstance->SetBodyLeanAxisDataSource(EBodyLeanAxisDataSource::AngleAccumulate);	
				BackActorAnimInstance->UpdateRelInputAxis(RoleMovement);
			}
		}

		FVector FrontTargetRelLoc = ParentAnimIns->IsLocoStart ? (ParentAnimIns->bIsRunAnimMovePosture ? SeerForwardInitParam.SocketRunRelLoc : SeerForwardInitParam.SocketSprintRelLoc) : SeerForwardInitParam.SocketIdleRelLoc;
		if (FrontTargetRelLoc != FrontCardRelLocation)
		{
			FrontCardRelLocation = FMath::VInterpTo(FrontCardRelLocation, FrontTargetRelLoc, DeltaSeconds, 10);
			if (UAttachJointComponent_V2* JointComponent = Cast<UAttachJointComponent_V2>(this->GetOwner()->FindComponentByClass(UAttachJointComponent_V2::StaticClass())))
			{
				JointComponent->UpdateAttachSocketRelLocation(FrontCardUniqueID, FrontCardRelLocation);
			}
		}
	}
}

void UProfessionalismComponent::SeerBackActorCrossfadeAnim(FName StateMachine, FName LocoStateName, float TranslationTime)
{
	if (!SeerBackActor) return;

	USkeletalMeshComponent* MainMesh = SeerBackActor->GetMainMesh();
	UBaseAnimInstance* AnimIns = MainMesh ? Cast<UBaseAnimInstance>(MainMesh->GetAnimInstance()) : nullptr;
	if (!AnimIns) return;

	AnimIns->CrossfadeInFixedTime(StateMachine, LocoStateName, TranslationTime);
}

void UProfessionalismComponent::SeerUpdateFrontCardView()
{
	if (!SeerForwardActor)
	{
		return;
	}
	USkeletalMeshComponent* MainMesh = SeerForwardActor->GetMainMesh();
	if (!MainMesh)
	{
		UE_LOG(LogTemp, Error, TEXT("UProfessionalismComponent::SeerUpdateFrontCardView	SeerForwardActor.MainMesh == nullptr"))
		return;
	}

	UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this);
	if (!AssetManager)
	{
		UE_LOG(LogTemp, Error, TEXT("invalid asset manager"));
		return ;
	}
	
	// 隐藏所有卡牌
	for (auto Component : SeerFrontCardListOne){
		Component.StaticMeshComponent->SetVisibility(false);
	}
	for (auto Component : SeerFrontCardListTwo){
		Component.StaticMeshComponent->SetVisibility(false);
	}

	int FrontCardNumber = SeerFrontCardPathList.Num();
	if (FrontCardNumber == 0) return;
	
	if (!SeerCardBoneNameListMap.Contains(FrontCardNumber))
	{
		UE_LOG(LogTemp, Error, TEXT("UProfessionalismComponent::SeerUpdateFrontCardView	!SeerCardBoneNameListMap.Contains(FrontCardNumber) FrontCardNumber:%d"), FrontCardNumber)
		return;
	}
	
	TArray<FName>& FrontCardSocketList = SeerCardBoneNameListMap[FrontCardNumber];
	
	int FrontCardListOneIndex = 0;
	int FrontCardListTwoIndex = 0;
	for (int i=0; i < FrontCardNumber && i < FrontCardSocketList.Num(); i++)
	{
		UStaticMeshComponent* StaticComponent = nullptr;
		int PathID = SeerFrontCardPathList[i];
		bool bOneCardList = PathID == FrontCardListOneID;
		TArray<FSeerStaticMeshComponent>& ComponentList = bOneCardList ? SeerFrontCardListOne : SeerFrontCardListTwo;
		int CardIndex = bOneCardList ? FrontCardListOneIndex : FrontCardListTwoIndex;
		if (CardIndex < ComponentList.Num())
		{
			StaticComponent = ComponentList[CardIndex].StaticMeshComponent;
		}
		else
		{
			StaticComponent = Cast<UStaticMeshComponent>(SeerForwardActor->AddComponentByClass(UStaticMeshComponent::StaticClass(), false, FTransform::Identity, false));
			if (StaticComponent){
				FSeerStaticMeshComponent SeerComponent;
				SeerComponent.StaticMeshComponent = StaticComponent;
				ComponentList.Add(SeerComponent);
				// 这里不能用parent的bounds, 用了之后, parent bounds extend为0, 显示不出来 (跟front card的bp和skmesh设置有关)
				ULowLevelFunctions::EnablePrimitiveComponentOptimization(StaticComponent, true, false);
			}
		}
		bOneCardList ? FrontCardListOneIndex++ : FrontCardListTwoIndex++;

		if (!StaticComponent)
		{
			UE_LOG(LogTemp, Error, TEXT("UProfessionalismComponent::SeerUpdateFrontCardView	StaticComponent == nullptr index:%i"), i)
			return;
		}

		if (!IsValid(StaticComponent->GetStaticMesh()) && SeerMapOfMeshPath.Contains(PathID) && !ComponentList[CardIndex].bInitMeshAsset)
		{
			int AssetLoadID = AssetManager->AsyncLoadAsset(*SeerMapOfMeshPath[PathID], FAsyncLoadCompleteDelegate::CreateUObject(this, &UProfessionalismComponent::OnSeerCardStaticMeshLoaded, TWeakObjectPtr<UStaticMeshComponent>(StaticComponent)), static_cast<int32>(EAssetLoadPriority::Default));
			AssetLoadIDList.Add(AssetLoadID);
			ComponentList[CardIndex].bInitMeshAsset = true;
		}
		
		StaticComponent->AttachToComponent(MainMesh, FAttachmentTransformRules(EAttachmentRule::SnapToTarget, false), FrontCardSocketList[i]);
		StaticComponent->SetVisibility(true);
#if WITH_EDITOR
		SeerForwardActor->AddInstanceComponent(StaticComponent);
#endif
	}

	// 播放前面卡牌展开动画
	if (SeerFrontCardExpandAnim)
	{
		if (USkeletalMeshComponent* MeshComponent = SeerForwardActor->GetMainMesh())
		{
			MeshComponent->PlayAnimation(SeerFrontCardExpandAnim, false);
		}
	}
}

void UProfessionalismComponent::OnSeerFrontActorClassLoaded(int InLoadID, UObject* LoadedAsset)
{
	if (!LoadedAsset)
	{
		UE_LOG(LogTemp, Warning, TEXT("UProfessionalismComponent::OnSeerFrontActorClassLoaded	LoadedAsset is nullptr ActorClass:%s"), *SeerForwardInitParam.ActorClass);
		return;
	}
	
	UClass* ActorClass = Cast<UClass>(LoadedAsset);
	if (!ActorClass || !ActorClass->IsChildOf(AC7Actor::StaticClass()))
	{
		UE_LOG(LogTemp, Warning, TEXT("UProfessionalismComponent::OnSeerFrontActorClassLoaded	ActorClass is not AC7Actor"));
		return;
	}

	UAttachJointComponent_V2* JointComponent = Cast<UAttachJointComponent_V2>(this->GetOwner()->FindComponentByClass(UAttachJointComponent_V2::StaticClass()));
	if (!JointComponent)
	{
		JointComponent = Cast<UAttachJointComponent_V2>(this->GetOwner()->AddComponentByClass(UAttachJointComponent_V2::StaticClass(), false, FTransform::Identity, false));
	}
	if (!JointComponent)
	{
		UE_LOG(LogTemp, Warning, TEXT("UProfessionalismComponent::OnSeerFrontActorClassLoaded	UAttachJointComponent_V2 is nullptr"));
		return;
	}
	
	ProfessionalType = EProfessionalType::Seer;

	if (SeerForwardActor == nullptr)
	{
		SeerForwardActor = GetWorld()->SpawnActor<ASeerAttachActor>(ActorClass);
		if (SeerForwardActor)
		{
			ULowLevelFunctions::EnableActorOptimizationForWithoutComposite(SeerForwardActor, true);
			FrontCardUniqueID = ULowLevelFunctions::GetGlobalUniqueID();
			FrontCardRelLocation = SeerForwardInitParam.SocketIdleRelLoc;
			JointComponent->AddAttachSocketByID(FrontCardUniqueID, SeerForwardInitParam.AttachSocket, "", FVector::ZeroVector, FRotator::ZeroRotator, SeerForwardInitParam.SocketIdleRelLoc, SeerForwardInitParam.SocketRelRot, false);
			JointComponent->AddAttachActor(SeerForwardActor, FrontCardUniqueID, FTransform());

			if (SeerForwardInitParam.bDoCollision)
			{
				JointComponent->EnableAttachSocketCollisionTest(FrontCardUniqueID, SeerForwardInitParam.ProbeSize, SeerForwardInitParam.CollisionChannels);
			}

			JointComponent->EnableAttachSocketLocationLagByBezier(FrontCardUniqueID, SeerForwardInitParam.BezierStep, SeerForwardInitParam.BezierStepMaxDist, SeerForwardInitParam.BezierSpeedAlpha, SeerForwardInitParam.BezierLagSpeed, SeerForwardInitParam.BezierDirectionMultiplier);
			JointComponent->EnableAttachSocketAttachRotationLag(FrontCardUniqueID, SeerForwardInitParam.AttachRotationLagSpeed, SeerForwardInitParam.bClampPitch, SeerForwardInitParam.PitchAngleMin, SeerForwardInitParam.PitchAngleMax, ERotationUpdateMode::FaceToMoveDir, SeerForwardInitParam.FaceToDirTolerance, SeerForwardInitParam.RotateRoundTime);

			// 添加逻辑父子关系
			if (IC7ActorInterface* Interface = Cast<IC7ActorInterface>(SeerForwardActor))
			{
				KGObjectID ParentActorID = KGUtils::GetIDByObject(this->GetOwner());
				Interface->AddAttachToLogicParent(ParentActorID);
			}
			
			if (ABaseCharacter* ParentCharacter = Cast<ABaseCharacter>(GetOwner()))
			{
				if (auto* ParentEntity = UKGUEActorManager::GetLuaEntityByActor(ParentCharacter))
				{
					ParentEntity->SyncEffectToChildActor(SeerForwardActor);
				}
			}

			// Actor 加载完毕异步处理
			if (SeerBackActor)
			{
				if (SeerFrontCardPathListCache.Num() > 0)
				{
					RemoveBackCardAndAddFrontCardList(SeerFrontCardPathListCache);
				}
				UpdateSeerProfessionalActorVisibility(bLogicVisibility, DissolveEffectID);
			}
		}
	}
}

void UProfessionalismComponent::OnSeerBackActorClassLoaded(int InLoadID, UObject* LoadedAsset)
{
	if (!LoadedAsset)
	{
		UE_LOG(LogTemp, Warning, TEXT("UProfessionalismComponent::OnSeerBackActorClassLoaded	LoadedAsset is nullptr ActorClass:%s"), *SeerBackInitParam.ActorClass);
		return;
	}
	
	UClass* ActorClass = Cast<UClass>(LoadedAsset);
	if (!ActorClass || !ActorClass->IsChildOf(AC7Actor::StaticClass()))
	{
		UE_LOG(LogTemp, Warning, TEXT("UProfessionalismComponent::OnSeerBackActorClassLoaded	ActorClass is not AC7Actor"));
		return;
	}

	UAttachJointComponent_V2* JointComponent = Cast<UAttachJointComponent_V2>(this->GetOwner()->FindComponentByClass(UAttachJointComponent_V2::StaticClass()));
	if (!JointComponent)
	{
		JointComponent = Cast<UAttachJointComponent_V2>(this->GetOwner()->AddComponentByClass(UAttachJointComponent_V2::StaticClass(), false, FTransform::Identity, false));
	}
	if (!JointComponent)
	{
		UE_LOG(LogTemp, Warning, TEXT("UProfessionalismComponent::OnSeerBackActorClassLoaded	UAttachJointComponent_V2 is nullptr"));
		return;
	}
	
	ProfessionalType = EProfessionalType::Seer;

	if (SeerBackActor == nullptr)
	{
		SeerBackActor = GetWorld()->SpawnActor<ASeerAttachActor>(ActorClass);
		if (SeerBackActor)
		{
			ULowLevelFunctions::EnableActorOptimizationForWithoutComposite(SeerForwardActor, true);
			int64 UniqueSocketID = ULowLevelFunctions::GetGlobalUniqueID();
			JointComponent->AddAttachSocketByID(UniqueSocketID, SeerBackInitParam.AttachSocket, "", FVector::ZeroVector, FRotator::ZeroRotator, SeerBackInitParam.SocketIdleRelLoc, SeerBackInitParam.SocketRelRot, false);
			JointComponent->AddAttachActor(SeerBackActor, UniqueSocketID, FTransform());

			if (SeerBackInitParam.bDoCollision)
			{
				JointComponent->EnableAttachSocketCollisionTest(UniqueSocketID, SeerBackInitParam.ProbeSize, SeerBackInitParam.CollisionChannels);
			}

			JointComponent->EnableAttachSocketLocationLagByBezier(UniqueSocketID, SeerBackInitParam.BezierStep, SeerBackInitParam.BezierStepMaxDist, SeerBackInitParam.BezierSpeedAlpha, SeerBackInitParam.BezierLagSpeed, SeerBackInitParam.BezierDirectionMultiplier);
			JointComponent->EnableAttachSocketAttachRotationLag(UniqueSocketID, SeerBackInitParam.AttachRotationLagSpeed, SeerBackInitParam.bClampPitch, SeerBackInitParam.PitchAngleMin, SeerBackInitParam.PitchAngleMax, ERotationUpdateMode::FaceToMoveDir, SeerBackInitParam.FaceToDirTolerance, SeerBackInitParam.RotateRoundTime);

			// 添加逻辑父子关系
			ABaseCharacter* ParentCharacter = Cast<ABaseCharacter>(this->GetOwner());
			AC7Actor* Interface = Cast<AC7Actor>(SeerBackActor);
			if (ParentCharacter && Interface)
			{
				KGObjectID ParentActorID = KGUtils::GetIDByObject(ParentCharacter);
				KGObjectID ChildCharacterID =  KGUtils::GetIDByObject(SeerBackActor);
				Interface->AddAttachToLogicParent(ParentActorID);

				// 动画同步开启
				if (USkeletalMeshComponent* MainMesh = Cast<USkeletalMeshComponent>(ParentCharacter->GetMainMesh()))
				{
					if (UBaseAnimInstance* AnimInstance = Cast<UBaseAnimInstance>(MainMesh->GetAnimInstance()))
					{
						AnimInstance->SetUsingLocoCrossfadeSynchronizeToLogicChilds(true);
					}
				}
				
				ParentCharacter->EnableLogicFeatureSynchronizeToChilds(ChildCharacterID, static_cast<int32>(ELogicParentFeatureSynchronizeMask::AnimationLocoState));
				if (auto* ParentEntity = UKGUEActorManager::GetLuaEntityByActor(ParentCharacter))
				{
					ParentEntity->SyncEffectToChildActor(SeerBackActor);
				}
			}

			// Actor 加载完毕异步处理
			if (SeerForwardActor)
			{
				if (SeerFrontCardPathListCache.Num() > 0)
				{
					RemoveBackCardAndAddFrontCardList(SeerFrontCardPathListCache);
				}
				UpdateSeerProfessionalActorVisibility(bLogicVisibility, DissolveEffectID);
			}
		}
	}
}

void UProfessionalismComponent::OnSeerFrontCardExpandAnimLoaded(int InLoadID, UObject* LoadedAsset)
{
	if (!LoadedAsset)
	{
		UE_LOG(LogTemp, Warning, TEXT("UProfessionalismComponent::OnSeerFrontCardExpandAnimLoaded	LoadedAsset is nullptr"));
		return;
	}
	SeerFrontCardExpandAnim = Cast<UAnimSequenceBase>(LoadedAsset);
}

void UProfessionalismComponent::OnSeerCardStaticMeshLoaded(int InLoadID, UObject* LoadedAsset, TWeakObjectPtr<UStaticMeshComponent> StaticMeshComponent)
{
	if (!LoadedAsset)
	{
		UE_LOG(LogTemp, Warning, TEXT("UProfessionalismComponent::OnSeerCardStaticMeshLoaded	LoadedAsset is nullptr"));
		return;
	}

	AssetLoadIDList.Remove(InLoadID);
	if (!StaticMeshComponent.IsValid())
	{
		UE_LOG(LogTemp, Warning, TEXT("UProfessionalismComponent::OnSeerCardStaticMeshLoaded	StaticMeshComponent is nullptr"));
		return;
	}
	
	if (UStaticMesh* StaticMesh = Cast<UStaticMesh>(LoadedAsset))
	{
		StaticMeshComponent->SetStaticMesh(StaticMesh);
	}

	if (SeerForwardActor) {
		SeerForwardActor->RefreshMaterialCacheOnAddMeshComponent(KGUtils::GetIDByObject(StaticMeshComponent.Get()), true);
	}
}

void UProfessionalismComponent::GetSeerAttachActors(TArray<AActor*>& OutAttachActors)
{
	if (SeerForwardActor)
	{
		OutAttachActors.Add(SeerForwardActor);
	}
	
	if (SeerBackActor)
	{
		OutAttachActors.Add(SeerBackActor);
	}
}
