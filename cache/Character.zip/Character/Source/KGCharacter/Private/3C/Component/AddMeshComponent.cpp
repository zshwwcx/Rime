// Fill out your copyright notice in the Description page of Project Settings.

#include "3C/Component/AddMeshComponent.h"

#include "3C/Util/AbilityCollisionUtil.h"
#include "Manager/KGObjectActorManager.h"
#include "Components/CapsuleComponent.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Core/C7ActorInterface.h"
#include "3C/Camera/CameraManager.h"
#include "3C/Util/KGComponentUtil.h"
#include "Manager/KGCppAssetManager.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/SphereComponent.h"
#include "3C/Effect/KGEffectManager.h"
#include "Engine/StaticMesh.h"
#include "3C/Material/KGMaterialManager.h"
#include "3C/Util/KGUtils.h"
#include "SkeletalMeshComponentBudgeted.h"

UAddMeshComponent::UAddMeshComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	SetTickGroup(TG_PostUpdateWork);
}

void UAddMeshComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	for (const TPair<int, FDynamicMeshContext>& It : DynamicMeshComponentMap)
	{
		InternalRemoveDynamicMesh(It.Key);
	}
	DynamicMeshComponentMap.Empty();
}


void UAddMeshComponent::HideMainMeshAndChildMesh(bool bHidden)
{
	AActor* actor = GetOwner();
	if (actor == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("ResetToDefaultsForCache : Cannot Get GetOwner()"));
		return;
	}
	if (IC7ActorInterface* IC7Actor = Cast<IC7ActorInterface>(actor))
	{
		USceneComponent* MainMeshComp = IC7Actor->GetMainMesh();
		if (MainMeshComp)
		{
			// 不能用引擎原生的propagate方法
			// MainMeshComp->SetHiddenInGame(bHidden, true);
			UKGComponentUtil::SetComponentHiddenInGame(MainMeshComp, bHidden, true);
		}
	}
}

void UAddMeshComponent::ResetToDefaultsForCache()
{
	for (const TPair<int, FDynamicMeshContext>& It : DynamicMeshComponentMap)
	{
		InternalRemoveDynamicMesh(It.Key);
	}
	DynamicMeshComponentMap.Empty();
	HideMainMeshAndChildMesh(false);
}

void UAddMeshComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	for (auto It = DynamicMeshComponentMap.CreateIterator(); It; ++It)
	{
		auto& FDynamicMeshContext = It.Value();
		
		if (FDynamicMeshContext.AttachTime > 0)
		{
			FDynamicMeshContext.AttachTime -= DeltaTime;
			if (FDynamicMeshContext.AttachTime <= 0)
			{
				if (FDynamicMeshContext.MeshComponent)
				{
					FDynamicMeshContext.MeshComponent->K2_DetachFromComponent(EDetachmentRule::KeepWorld, EDetachmentRule::KeepWorld, EDetachmentRule::KeepWorld, false);
				}
			}
		}
		
		if (FDynamicMeshContext.DestroyTime > 0)
		{
			FDynamicMeshContext.DestroyTime -= DeltaTime;
			if (FDynamicMeshContext.DestroyTime <= 0)
			{
				InternalRemoveDynamicMesh(FDynamicMeshContext.UniqueID);
				It.RemoveCurrent();
			}
		}
	}
}

int64 UAddMeshComponent::GetDynamicMeshByMeshName(const FName& MeshName)
{
	if (MeshName.IsNone())
	{
		return KG_CPP_INVALID_ASSET_LOAD_ID;
	}
	
	for (const TPair<int, FDynamicMeshContext>& It : DynamicMeshComponentMap)
	{
		if (It.Value.MeshName == MeshName)
		{
			return It.Key;
		}
	}
	return KG_CPP_INVALID_ASSET_LOAD_ID;
}

void UAddMeshComponent::RemoveDynamicMesh(int64 UniqueID)
{
	if (DynamicMeshComponentMap.Contains(UniqueID))
	{
		// cpp这边可能已经删掉了
		InternalRemoveDynamicMesh(UniqueID);
		DynamicMeshComponentMap.Remove(UniqueID);
	}
}

void UAddMeshComponent::InternalRemoveDynamicMesh(int64 UniqueID)
{
	AActor* actor = GetOwner();
	if (actor == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("RemoveDynamicMesh : Cannot Get GetOwner()"));
		return;
	}
	
	const FDynamicMeshContext* DynamicMeshContext = DynamicMeshComponentMap.Find(UniqueID);
	if (!DynamicMeshContext)
	{
		UE_LOG(LogTemp, Error, TEXT("RemoveDynamicMesh : invalid uniqueID [%lld]"), UniqueID);
		return;
	}
	
	if (DynamicMeshContext->InLoadID != KG_CPP_INVALID_ASSET_LOAD_ID)
	{
		// 还在资源加载中，取消加载
		if (UKGCppAssetManager* CppAssetManager = UKGCppAssetManager::GetInstance(actor))
		{
			CppAssetManager->CancelAsyncLoadByLoadID(DynamicMeshContext->InLoadID);
		}
	}
	else
	{
		// 卸载Mesh
		if (DynamicMeshContext->MeshComponent)
		{
			const KGEntityID MeshComponentID = KGUtils::GetIDByObject(DynamicMeshContext->MeshComponent.Get());
			const KGEntityID ActorID = KGUtils::GetIDByObject(actor);
			
			if (UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(actor))
			{
				EffectManager->NotifyRemoveComponent(KGUtils::GetIDByObject(actor), MeshComponentID);
			}
			
			if (ICppEntityInterface* OwnerCppEntityInterface = UKGUEActorManager::GetLuaEntityByActor(actor))
			{
				OwnerCppEntityInterface->KAPI_Actor_RefreshMaterialCacheOnRemoveMeshComponent(MeshComponentID);
			}
			
			UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(actor);
			if (!DynamicMeshContext->bInherit || !DynamicMeshContext->bEnableCameraDither)
			{
				if (MaterialManager)
				{
					MaterialManager->RemoveExcludedMeshComponentId(ActorID, MeshComponentID);
				}
			}
			if (MaterialManager)
			{
				MaterialManager->ChangeNoBatchOLM(ActorID, MeshComponentID, false);
			}
			DynamicMeshContext->MeshComponent->K2_DestroyComponent(DynamicMeshContext->MeshComponent);
		}
	}

	if (DynamicMeshContext->AddMeshCollisionComponent != nullptr)
	{
		DynamicMeshContext->AddMeshCollisionComponent->DestroyComponent();
	}
	
	// 回调Lua
	if (ICppEntityInterface* OwnerCppEntityInterface = UKGUEActorManager::GetLuaEntityByActor(actor))
	{
		if (LuaEntityBase* OwnerLuaEntity = OwnerCppEntityInterface->GetLuaEntityBase())
		{
			OwnerLuaEntity->CallLuaFunction(TEXT("RemoveDynamicMeshCallback"), UniqueID);		
		}
	}
}

bool UAddMeshComponent::CreateDynamicMesh(int64 UniqueID, bool bHidden, bool bPropagateToChildren, bool bUnit, bool bSMorSK,
	                                     const FName& MeshName, const FString& MeshPath, bool bNeedAttach,bool bAttachToCamera, const FName& AttachSocket,
										 float AttachTime, float DestroyTime, float TranslationX, float TranslationY, float TranslationZ,
										 float ScaleX, float ScaleY, float ScaleZ, float Pitch, float Yaw,
										 float Roll, bool bStickGround, bool bNeedLoop, const FString& AnimPath, const FString& BPAnimPath, 
										 bool UseLOD0, bool bCopyCurFrameAnim, KGEntityID InstigatorID, bool bLookAtInputPos, float InputPosX, 
										 float InputPosY, bool bInherit, bool bFollowActorScale, bool bEnableCameraDither, const FName& AddMeshCollisionProfileName, 
										 bool bUseSelfPosForCameraDither, bool bUseRootCompWhenSocketNone, bool bEnableLight, bool bCatchUpAnimProgress)
{
	TRACE_CPUPROFILER_EVENT_SCOPE(UAddMeshComponent.CreateDynamicMesh)
	
	AActor* actor = GetOwner();
	if (actor == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("CreateDynamicMesh : Cannot Get GetOwner()"));
		return false;
	}
	
	auto PreMeshUniqueID = GetDynamicMeshByMeshName(MeshName);
	if (PreMeshUniqueID != KG_CPP_INVALID_ASSET_LOAD_ID)
	{
		RemoveDynamicMesh(PreMeshUniqueID);
	}
	
	FDynamicMeshContext DynamicMeshContext;
	DynamicMeshContext.UniqueID = UniqueID;
	DynamicMeshContext.bHidden = bHidden;
	DynamicMeshContext.bPropagateToChildren = bPropagateToChildren;
	DynamicMeshContext.bUnit = bUnit;
	DynamicMeshContext.bAttachToCamera = bAttachToCamera;
	DynamicMeshContext.bNeedAttach = bNeedAttach;
	DynamicMeshContext.AttachSocket = AttachSocket;
	DynamicMeshContext.AttachTime = AttachTime;
	DynamicMeshContext.DestroyTime = DestroyTime;
	DynamicMeshContext.bStickGround = bStickGround;
	DynamicMeshContext.Transform.SetLocation(FVector(TranslationX, TranslationY, TranslationZ));
	DynamicMeshContext.Transform.SetScale3D(FVector(ScaleX, ScaleY, ScaleZ));
	DynamicMeshContext.Transform.SetRotation(FRotator(Pitch, Yaw, Roll).Quaternion());
	DynamicMeshContext.bSMorSK = bSMorSK;
	DynamicMeshContext.bCopyCurFrameAnim = bCopyCurFrameAnim;
	DynamicMeshContext.UseLOD0 = UseLOD0;
	DynamicMeshContext.InstigatorID = InstigatorID;
	DynamicMeshContext.bLookAtInputPos = bLookAtInputPos;
	DynamicMeshContext.InputPos.Set(InputPosX, InputPosY, 0.0f);
	DynamicMeshContext.MeshName = MeshName;
	DynamicMeshContext.bNeedLoop = bNeedLoop;
	DynamicMeshContext.bInherit = bInherit;
	DynamicMeshContext.bFollowActorScale = bFollowActorScale;
	DynamicMeshContext.bEnableCameraDither = bEnableCameraDither;
	DynamicMeshContext.AddMeshCollisionProfileName = AddMeshCollisionProfileName;
	DynamicMeshContext.bUseSelfPosForCameraDither = bUseSelfPosForCameraDither;
	DynamicMeshContext.EnableLight = bEnableLight;
	DynamicMeshContext.bCatchUpAnimProgress = !AnimPath.IsEmpty() && bCatchUpAnimProgress;
	DynamicMeshContext.CreateTimeStamp = DynamicMeshContext.bCatchUpAnimProgress ? GetWorld()->GetTimeSeconds(): 0.0f;
	
	TArray<FString> Paths;
	if (AnimPath.IsEmpty() && BPAnimPath.IsEmpty())
	{
		Paths.Add(MeshPath);
	}
	else if (!BPAnimPath.IsEmpty())
	{
		Paths.Add(MeshPath);
		Paths.Add(BPAnimPath);
		DynamicMeshContext.bBPAnim = true;
	}
	else
	{
		Paths.Add(MeshPath);
		Paths.Add(AnimPath);
	}

	TArray<int64> OutRemovedValue;
	if (WantToAddMeshCtxs.RemoveAndCopyValue(MeshName, OutRemovedValue))
	{
		DynamicMeshContext.NiagaraEffectIDs.Append(OutRemovedValue);
	}

	UKGCppAssetManager* CppAssetManager = UKGCppAssetManager::GetInstance(actor);
	if (!CppAssetManager)
	{
		UE_LOG(LogTemp, Error, TEXT("CreateDynamicMesh : Cannot Get CppAssetManager"));
		return false;
	}
	
	DynamicMeshContext.InLoadID = CppAssetManager->AsyncLoadAsset(Paths, FAsyncLoadListCompleteDelegate::CreateUObject(this, &UAddMeshComponent::CreateMeshAfterLoad, UniqueID, bUseRootCompWhenSocketNone));
	DynamicMeshComponentMap.Add(UniqueID, MoveTemp(DynamicMeshContext));

#if WITH_EDITOR
	if (DynamicMeshComponentMap.Num() > 2000)
	{
		UE_LOG(LogTemp, Error, TEXT("CreateDynamicMesh : dynamic mesh component map num is too large [%d]"), DynamicMeshComponentMap.Num());
	}
#endif
	return true;
}

void UAddMeshComponent::CreateMeshAfterLoad(int InLoadID, const TArray<UObject*>& Assets, int64 UniqueID, bool bUseRootCompWhenSocketNone)
{
	TRACE_CPUPROFILER_EVENT_SCOPE(UAddMeshComponent.CreateMeshAfterLoad)
	
	AActor* actor = GetOwner();
	if (actor == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("CreateMeshAfterLoad : Cannot Get GetOwner()"));
		return;
	}

	FDynamicMeshContext* DynamicMeshContext = DynamicMeshComponentMap.Find(UniqueID);
	if (!DynamicMeshContext)
	{
		UE_LOG(LogTemp, Error, TEXT("CreateMeshAfterLoad : invalid uniqueID [%lld]"), UniqueID);
		return;
	}
	DynamicMeshContext->InLoadID = KG_CPP_INVALID_ASSET_LOAD_ID;
	
	// 0.组装MESH
	if (Assets.Num() < 1)
	{
		UE_LOG(LogTemp, Error, TEXT("CreateMeshAfterLoad : Assets num is 0"));
		return;
	}

	// 0.0 获取ParentComponent
	USceneComponent* ParentComponent = nullptr;
	if (DynamicMeshContext->bAttachToCamera)
	{
		//  获取摄像机
		if (const ACameraManager* CameraManager = Cast<ACameraManager>(UGameplayStatics::GetPlayerCameraManager(GetWorld(), 0)))
		{
			ParentComponent = CameraManager->GetRootComponent();
		}
	}
	else
	{
		if (DynamicMeshContext->bUnit || (bUseRootCompWhenSocketNone && DynamicMeshContext->AttachSocket == "None"))
		{
			// 临时处理，如果是Unit, 则挂接到根组件；解决添加多个mesh情况下，第二次GetMainMesh会得到值的问题
			ParentComponent = actor->GetRootComponent();
		}
		else
		{
			if(IC7ActorInterface* IC7Actor = Cast<IC7ActorInterface>(actor))
			{
				ParentComponent = IC7Actor->GetMainMesh();
			}
			if (ParentComponent == nullptr)
			{
				ParentComponent = actor->GetRootComponent();
			}
		}
	}
	if (ParentComponent == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("CreateMeshAfterLoad : no parent comp to attach"));
		return;
	}

	// 0.1 贴地
	if (DynamicMeshContext->bStickGround)
	{
		// 这边在不影响现有配置的情况下加入贴地逻辑，后面迭代再处理
		FVector Pos = actor->GetActorLocation();
		double curZ = Pos.Z;
		
		TArray<TEnumAsByte<EObjectTypeQuery>> ObjectTypes;
		ObjectTypes.Add( UEngineTypes::ConvertToObjectType(ECC_WorldStatic));

		FVector Gravity = actor->GetActorUpVector() * -1.0f;
		
		FVector Ground;
		if (UAbilityCollisionUtil::FindGroundLocation(actor, Pos, ObjectTypes, Ground, FVector(-100.0, 1000.0, 0.4), Gravity, actor))
		{
			curZ = curZ - Ground.Z;
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("CreateMeshAfterLoad : FindGround failed"));
		}
		
		FVector Loc = DynamicMeshContext->Transform.GetLocation();
		Loc.Z = Loc.Z - curZ;
		DynamicMeshContext->Transform.SetLocation(Loc);
	}

	// 0.2 创建MeshComponent
	UMeshComponent* MeshComponent = nullptr;
	if (DynamicMeshContext->bSMorSK)
	{
		// StaticMesh
		if (auto StaticMeshComponent = Cast<UStaticMeshComponent>(actor->AddComponentByClass(UStaticMeshComponent::StaticClass(), true, DynamicMeshContext->Transform, false)))
		{
			if (auto StaticMesh = Cast<UStaticMesh>(Assets[0]))
			{
				UKGMaterialManager::SetActorStaticMesh(StaticMeshComponent, StaticMesh);
			}
			if (DynamicMeshContext->UseLOD0)
			{
				StaticMeshComponent->SetForcedLodModel(0);
			}
			MeshComponent = StaticMeshComponent;
		}
	}
	else if (DynamicMeshContext->bCopyCurFrameAnim)
	{
		// 手动骨骼模型
		if (auto PoseableMeshComponent = Cast<UPoseableMeshComponent>(actor->AddComponentByClass(UPoseableMeshComponent::StaticClass(), true, DynamicMeshContext->Transform, false)))
		{
			if (auto SkeletalMesh = Cast<USkeletalMesh>(Assets[0]))
			{
				UKGMaterialManager::SetActorPoseableSkeletalMesh(PoseableMeshComponent, SkeletalMesh, false);
			}
			if (DynamicMeshContext->UseLOD0)
			{
				PoseableMeshComponent->SetForcedLOD(0);
			}

			AActor* Target = nullptr;
			if (DynamicMeshContext->bUnit && DynamicMeshContext->InstigatorID > 0)
			{
				// 使用施法者当前的动画骨骼位置
				Target = KGUtils::GetObjectByID<AActor>(DynamicMeshContext->InstigatorID);
			}
			if (Target == nullptr)
			{
				Target = actor;
			}
			
			if (ABaseCharacter* BC = Cast<ABaseCharacter>(Target)) {
				// 复制姿势
				PoseableMeshComponent->CopyPoseFromSkeletalComponent(BC->GetMesh());
			}
			
			MeshComponent = PoseableMeshComponent;
		}
	}
	else
	{
		// 动画骨骼模型
		if (auto SkeletalMeshComponent = Cast<USkeletalMeshComponentBudgeted>(actor->AddComponentByClass(USkeletalMeshComponentBudgeted::StaticClass(), true, DynamicMeshContext->Transform, false)))
		{
			if (auto SkeletalMesh = Cast<USkeletalMesh>(Assets[0]))
			{
				UKGMaterialManager::SetActorSkeletalMesh(SkeletalMeshComponent, SkeletalMesh, false);
			}
			if (DynamicMeshContext->UseLOD0)
			{
				SkeletalMeshComponent->SetForcedLOD(0);
			}

			MeshComponent = SkeletalMeshComponent;
		}
	}

	if (MeshComponent == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("CreateMeshAfterLoad : create mesh component failed "));
		return;
	}

	ICppEntityInterface* CppEntity = UKGUEActorManager::GetLuaEntityByActor(actor);
	if(CppEntity && (!CppEntity->GetIsMainPlayer() || !CppEntity->GetIsBoos()))
	{
		ULowLevelFunctions::EnablePrimitiveComponentOptimization(MeshComponent, true, false);
	}
	
	// 0.3 挂接MeshComponent
	if (DynamicMeshContext->bNeedAttach || DynamicMeshContext->bAttachToCamera)
	{
		FName SocketName;
		if (DynamicMeshContext->bAttachToCamera)
		{
			SocketName = "";
		}
		else
		{
			SocketName = DynamicMeshContext->AttachSocket;
		}
		MeshComponent->AttachToComponent(ParentComponent, FAttachmentTransformRules::KeepRelativeTransform, SocketName);
	}
	else
	{
		// 没有父类，需要把追加上角色的位置
		if (DynamicMeshContext->bFollowActorScale)
		{
			auto WorldTransform = DynamicMeshContext->Transform * actor->GetActorTransform();
			MeshComponent->SetWorldTransform(WorldTransform);
		}
		else
		{
			// 不跟随角色缩放
			FTransform ActorTransform = FTransform(actor->GetActorRotation(), actor->GetActorLocation());
			auto WorldTransform = DynamicMeshContext->Transform * ActorTransform;
			MeshComponent->SetWorldTransform(WorldTransform);
		}
		
		// 模型释放位置计算完成后,给模型叠加一个看向inputPos的偏移
		if (DynamicMeshContext->bLookAtInputPos)
		{
			auto CurPos = MeshComponent->GetComponentLocation();
			auto InputPos = DynamicMeshContext->InputPos;

			FVector From = FVector(CurPos.X, CurPos.Y, 0.0f);
			FVector To   = FVector(InputPos.X != 0 ? InputPos.X : CurPos.X,
								   InputPos.Y != 0 ? InputPos.Y : CurPos.Y,
								   0.0f);
			FRotator LookAtRot = UKismetMathLibrary::FindLookAtRotation(From, To);
			FQuat FinalQuat = LookAtRot.Quaternion() * DynamicMeshContext->Transform.GetRotation();
			MeshComponent->SetWorldRotation(FinalQuat, false, nullptr, ETeleportType::ResetPhysics);
		}
	}

	// 命名标记
	if (!DynamicMeshContext->MeshName.IsNone())
	{
		MeshComponent->ComponentTags.AddUnique(DynamicMeshContext->MeshName);
	}
	
	// 1.组装Anim
	if (Assets.Num() > 1 && !DynamicMeshContext->bSMorSK)
	{
		if (USkeletalMeshComponent* SkeletalMeshComponent = Cast<USkeletalMeshComponent>(MeshComponent))
		{
			if (DynamicMeshContext->bBPAnim)
			{
				SkeletalMeshComponent->SetAnimationMode(EAnimationMode::AnimationBlueprint, false);
				SkeletalMeshComponent->SetAnimInstanceClass(Cast<UClass>(Assets[1]));
			}
			else
			{
				SkeletalMeshComponent->PlayAnimation(Cast<UAnimationAsset>(Assets[1]), DynamicMeshContext->bNeedLoop);
			}

			if (DynamicMeshContext->bCatchUpAnimProgress)
			{
				//设置动画播放开始进度时间
				float StartAnimationTime = GetWorld()->GetTimeSeconds() - DynamicMeshContext->CreateTimeStamp;
				SkeletalMeshComponent->SetPosition(StartAnimationTime, false);
			}
		
			if (!DynamicMeshContext->bCopyCurFrameAnim)
			{
				// bound设置, 改用直接新增的包围盒跟着蒙皮走的计算方式, 避免繁杂的physic asset的添加
				SkeletalMeshComponent->SetUpdateBoundWithFirstSkinnedBone(true);
			}
		}
	}
	DynamicMeshContext->MeshComponent = MeshComponent;

	auto ActorID = KGUtils::GetIDByObject(actor);
	auto MeshComponentID = KGUtils::GetIDByObject(MeshComponent);
	
	// 3.继承母体材质表现
	UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(actor);
	if (!DynamicMeshContext->bInherit || !DynamicMeshContext->bEnableCameraDither)
	{
		if (MaterialManager)
		{
			MaterialManager->AddExcludedMeshComponentId(
				ActorID, MeshComponentID, !DynamicMeshContext->bEnableCameraDither, !DynamicMeshContext->bInherit);
		}
	}
	
	if (MaterialManager)
	{
		if (ICppEntityInterface* OwnerCppEntityInterface = UKGUEActorManager::GetLuaEntityByActor(actor))
		{
			MaterialManager->ChangeNoBatchOLM(ActorID, MeshComponentID, true);
			OwnerCppEntityInterface->KAPI_Actor_RefreshMaterialCacheOnAddMeshComponent(MeshComponentID, DynamicMeshContext->bInherit);
		}
	}	

	// 4.特效逻辑处理
	if (!DynamicMeshContext->NiagaraEffectIDs.IsEmpty())
	{
		if (UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(actor))
		{
			for (int64 EffectID : DynamicMeshContext->NiagaraEffectIDs)
			{
				EffectManager->NotifyNiagaraAttachComponentCreated(EffectID);
			}
		}
		DynamicMeshContext->NiagaraEffectIDs.Empty();
	}
	
	// 5.其他
	MeshComponent->SetHiddenInGame(DynamicMeshContext->bHidden);					// 显隐
	MeshComponent->SetEnableCharacterLighting(DynamicMeshContext->EnableLight);		// 补光

	// 6, 设置相机虚化探测碰撞
	if (DynamicMeshContext->bEnableCameraDither)
	{
		// 根据mesh bounds创建sphere shape component
		const auto& Bounds = MeshComponent->GetLocalBounds();
		float SphereRadius = Bounds.SphereRadius;
		USphereComponent* SphereComp = NewObject<USphereComponent>(actor);
		SphereComp->RegisterComponent();
		SphereComp->SetSphereRadius(SphereRadius, false);
		SphereComp->AttachToComponent(MeshComponent, FAttachmentTransformRules::KeepRelativeTransform);
		SphereComp->SetRelativeLocation(Bounds.Origin);
		SphereComp->SetCollisionProfileName(DynamicMeshContext->AddMeshCollisionProfileName);
		ULowLevelFunctions::EnableOverlapOptimization(SphereComp, true);
		DynamicMeshContext->AddMeshCollisionComponent = SphereComp;

		if (DynamicMeshContext->bUseSelfPosForCameraDither)
		{
			//if (!MaterialManager)
			//{
			//	MaterialManager = UKGMaterialManager::GetInstance(actor);
			//}
			
			if (MaterialManager)
			{
				MeshComponent->ComponentTags.Add(MaterialManager->GetUseSelfLocationMeshTag());
			}
			else
			{
				UE_LOG(LogTemp, Error, TEXT("CreateMeshAfterLoad : Cannot Get MaterialManager for UseSelfPosForCameraDither"));
			}
		}
	}
#if WITH_EDITOR
	actor->AddInstanceComponent(MeshComponent);
#endif
}

void UAddMeshComponent::SetHiddenInGame(int64 UniqueID, bool bHidden, bool bPropagateToChildren)
{
	FDynamicMeshContext* DynamicMeshContext = DynamicMeshComponentMap.Find(UniqueID);
	if (!DynamicMeshContext)
	{
		// 目标Mesh可能已经删除
		return;
	}
	
	DynamicMeshContext->bHidden = bHidden;
	if (DynamicMeshContext->MeshComponent)
	{
		DynamicMeshContext->MeshComponent->SetHiddenInGame(DynamicMeshContext->bHidden, bPropagateToChildren);
	}
}

void UAddMeshComponent::PlayAnimationOnMesh(int64 UniqueID, const FString& AnimPath, bool bLoop, float BlendInTime, float BlendOutTime)
{
	AActor* actor = GetOwner();
	if (actor == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("PlayAnimationOnMesh : Cannot Get GetOwner()"));
		return;
	}
	
	FDynamicMeshContext* DynamicMeshContext = DynamicMeshComponentMap.Find(UniqueID);
	if (!DynamicMeshContext)
	{
		UE_LOG(LogTemp, Error, TEXT("PlayAnimationOnMesh : invalid uniqueID [%lld]"), UniqueID);
		return;
	}
	if (!DynamicMeshContext->MeshComponent)
	{
		return;
	}
	
	if (USkeletalMeshComponent* SkeletalMeshComponent = Cast<USkeletalMeshComponent>(DynamicMeshContext->MeshComponent))
	{
		SkeletalMeshComponent->SetAnimationMode(EAnimationMode::AnimationSingleNode, false);
		
		if (ICppEntityInterface* OwnerCppEntityInterface = UKGUEActorManager::GetLuaEntityByActor(actor))
		{
			const auto MeshComponentID = KGUtils::GetIDByObject(DynamicMeshContext->MeshComponent);
			const auto AnimPlayReqID = OwnerCppEntityInterface->KAPI_Animation_PlayAnimation(MeshComponentID, KG_INVALID_ID, AnimPath, "DefaultSlot", bLoop, false, BlendInTime, BlendOutTime);

			DynamicMeshContext->AnimPlayReqID = AnimPlayReqID;
		}
	}
}

void UAddMeshComponent::StopAnimation(int64 UniqueID, float BlendOutTime)
{
	AActor* actor = GetOwner();
	if (actor == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("StopAnimation : Cannot Get GetOwner()"));
		return;
	}
	
	FDynamicMeshContext* DynamicMeshContext = DynamicMeshComponentMap.Find(UniqueID);
	if (!DynamicMeshContext)
	{
		// 目标Mesh可能已经删除
		return;
	}

	if (!DynamicMeshContext->MeshComponent)
	{
		return;
	}
	
	if (DynamicMeshContext->AnimPlayReqID == 0)
	{
		return;
	}
	
	if (ICppEntityInterface* OwnerCppEntityInterface = UKGUEActorManager::GetLuaEntityByActor(actor))
	{
		OwnerCppEntityInterface->KAPI_Animation_StopAnimation(DynamicMeshContext->AnimPlayReqID, BlendOutTime);
		DynamicMeshContext->AnimPlayReqID = 0;
	}
}

void UAddMeshComponent::CacheNiagaraParamBefore(int64 EffectID, const FName& ComponentName, bool bWant2Add)
{
	if (ComponentName.IsNone())
	{
		return;
	}
	for (TPair<int, FDynamicMeshContext>& It : DynamicMeshComponentMap)
	{
		if (It.Value.MeshName == ComponentName)
		{
			It.Value.NiagaraEffectIDs.Add(EffectID);
			return;
		}
	}
	if (bWant2Add)
	{
		WantToAddMeshCtxs.FindOrAdd(ComponentName).Add(EffectID);
	}
}

void UAddMeshComponent::UnCacheNiagaraParamBefore(const FName& ComponentName)
{
	if (ComponentName.IsNone())
	{
		return;
	}
	
	auto uniqueID = GetDynamicMeshByMeshName(ComponentName);
	if (uniqueID > 0)
	{
		FDynamicMeshContext* DynamicMeshContext = DynamicMeshComponentMap.Find(uniqueID);
		if (!DynamicMeshContext)
		{
			// 目标Mesh可能已经删除
			return;
		}

		if (!DynamicMeshContext->MeshComponent)
		{
			return;
		}
		DynamicMeshContext->NiagaraEffectIDs.Empty();

		if (WantToAddMeshCtxs.Contains(ComponentName))
		{
			WantToAddMeshCtxs.Remove(ComponentName);
		}
	}
}

