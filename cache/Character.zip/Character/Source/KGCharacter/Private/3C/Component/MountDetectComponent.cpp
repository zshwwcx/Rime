// Fill out your copyright notice in the Description page of Project Settings.

#include "3C/Component/MountDetectComponent.h"

#include "Manager/KGObjectActorManager.h"
#include "3C/Core/KGUEActorManager.h"
#include "Components/PrimitiveComponent.h"
#include "DrawDebugHelpers.h"

#include "Components/InstancedStaticMeshComponent.h"
#include "PrimitiveSceneProxy.h"
#include "3C/Util/KGUtils.h"
#include "Components/MobileInstancedStaticMeshComponent.h"
#include "Engine/StaticMesh.h"
#include "Engine/StaticMeshActor.h"


UMountDetectComponent::UMountDetectComponent()
{
	PrimaryComponentTick.bCanEverTick = true;

	SetTickGroup(TG_PostUpdateWork);
}


void UMountDetectComponent::BeginPlay()
{
	Super::BeginPlay();

}


void UMountDetectComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (!bEnableDetect)
	{
		return;
	}

	UKGObjectActorManager* ObjectActorMgr = UKGObjectActorManager::GetInstance(this);
	if (!ObjectActorMgr)
	{
		UE_LOG(LogTemp, Warning, TEXT("[UMountDetectComponent::TickComponent] Cannot Get UKGObjectActorManager"));
		return;
	}

	AActor* OuterActor = GetOwner();
	if (!OuterActor)
	{
		UE_LOG(LogTemp, Warning, TEXT("[UMountDetectComponent::TickComponent] Cannot Get GetOwner()"));
		return;
	}


	TArray<AActor*> ActorsToIgnore;
	TArray<FHitResult> OutHits;

	FTransform MountTrans = OuterActor->GetActorTransform();
	FVector Start = MountTrans.TransformPositionNoScale(DetectStartPos);
	FVector End = MountTrans.TransformPositionNoScale(DetectEndPos);
	bool bHit = UKismetSystemLibrary::BoxTraceMulti(
		GetWorld(),
		Start,
		End,
		DetectBoxHalfSize,
		MountTrans.GetRotation().Rotator(),
		GTATraceChannel,
		false,
		ActorsToIgnore,
		DebugDrawType,
		OutHits,
		true
	);

	TSet<TWeakObjectPtr<ABaseCharacter>> ThisFrameActors;

	if (bHit)
	{
		TSet<UPrimitiveComponent*> ProcessedComponents;
		for (auto& HitResult : OutHits)
		{
			UPrimitiveComponent* Component = HitResult.GetComponent();
			if (Component && !ProcessedComponents.Contains(Component))
			{
				ProcessedComponents.Add(Component);
				if (ABaseCharacter* DetectedChar = Cast<ABaseCharacter>(HitResult.Component->GetOwner()))
				{
					if (bOnlyDetectCrowdNPC)
					{
						if (!DetectedChar->IsCrowdNpc())
						{
							continue;
						}
					}
					ThisFrameActors.Add(DetectedChar);

					if (!LastFrameActors.Contains(DetectedChar))
					{
						HandleActorEnter(DetectedChar, HitResult);
					}
				}
				else if (!bUseComponentGTATag || (bUseComponentGTATag && HitResult.Component->ComponentHasTag("GTA")))
				{
					ProcessGTAHitResult(HitResult);
				}
			}
		}
	}

	for (auto& WeakActor : LastFrameActors)
	{
		ABaseCharacter* Char = WeakActor.Get();
		if (Char && !ThisFrameActors.Contains(Char))
		{
			HandleActorLeave(Char);
		}
	}


	LastFrameActors = ThisFrameActors;
	
	// Sector Detect 扇形检测, 使NPC进入避让React
	if (FanDetectRadius > 0)
	{
		TickFanDetectReact();
	}
}

void UMountDetectComponent::ProcessGTAHitResult(const FHitResult& HitResult) const
{
	TObjectPtr<UStaticMesh> Mesh = nullptr;
	FTransform InstanceTM;
	if (UInstancedStaticMeshComponent* ISM = Cast<UInstancedStaticMeshComponent>(HitResult.Component))
	{
		const int32 InstanceIndex = HitResult.Item;
		if (InstanceIndex < 0)
		{
			return;
		}
		const bool bOk = ISM->GetInstanceTransform(InstanceIndex, InstanceTM, /*bWorldSpace*/ true);
		if (!bOk)
		{
			return;
		}
		Mesh = ISM->GetStaticMesh(); 
		FTransform HiddenTM = InstanceTM;
		HiddenTM.SetScale3D(FVector::ZeroVector);
		ISM->UpdateInstanceTransform(InstanceIndex,HiddenTM,true,true,true);
	}
	else if (UMobileInstancedStaticMeshComponent* MISM = Cast<UMobileInstancedStaticMeshComponent>(HitResult.Component))
	{
		const int32 InstanceIndex = HitResult.Item;
		if (InstanceIndex < 0)
		{
			return;
		}
		FMatrix44f Matrix44f = MISM->GetInstanceTransform(InstanceIndex);
		FMatrix44d Matrix44d;
		for (int32 R = 0; R < 4; ++R)
		{
			for (int32 C = 0; C < 4; ++C)
			{
				Matrix44d.M[R][C] = static_cast<double>(Matrix44f.M[R][C]);
			}
		}
		InstanceTM = FTransform(Matrix44d);
		MISM->SetInstanceVisible(InstanceIndex,false,true);
		Mesh = MISM->GetStaticMesh();
	}
	else if (UStaticMeshComponent* SMC = Cast<UStaticMeshComponent>(HitResult.Component))
	{
		Mesh = SMC->GetStaticMesh();
		InstanceTM = SMC->GetComponentTransform();
		SMC->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		auto Actor = SMC->GetOwner();
		Actor->SetActorHiddenInGame(true);
		Actor->SetActorEnableCollision(false);
	}

	AActor* Owner = GetOwner();
	if (Mesh && Owner)
	{
		const FVector ImpactPoint = HitResult.ImpactPoint;
	    const FVector ImpactNormal = HitResult.ImpactNormal;
	    const FVector ImpulseDir = (Owner->GetActorForwardVector() - ImpactNormal * 0.3f).GetSafeNormal();
	    FVector Impulse = ImpulseDir * StreetLampImpulseStrength;
		if (ImpulseConfig.Num() > 0)
		{
			volatile float VelocitySize = Owner->GetVelocity().Size() / 100;
			constexpr int PairNum = 3;
			float ImpulseHorizontal = 1;
			float ImpulseVertical = 1;
			for (int32 PairIndex = 0; PairIndex < ImpulseConfig.Num() / PairNum; ++PairIndex)
			{
				if (ImpulseConfig[PairIndex] > VelocitySize)
					break;
				ImpulseHorizontal = ImpulseConfig[PairIndex + 1];
				ImpulseVertical = ImpulseConfig[PairIndex + 2];
			}
			
			Impulse.Z = StreetLampImpulseStrength;
			Impulse = FVector(ImpulseHorizontal, ImpulseHorizontal, ImpulseVertical) * Impulse;
		}
		// 生成一个可模拟物理的 StaticMeshActor
		FActorSpawnParameters SP;
		SP.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		AStaticMeshActor* SMA = GetWorld()->SpawnActor<AStaticMeshActor>(AStaticMeshActor::StaticClass(), InstanceTM, SP);
		if (SMA)
		{
			UStaticMeshComponent* SMC = SMA->GetStaticMeshComponent();
			SMC->SetMobility(EComponentMobility::Movable);
			SMC->SetStaticMesh(Mesh);
			SMC->SetSimulatePhysics(true);
			SMC->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
			SMC->SetCollisionProfileName(CollisionProfileName);
			SMC->SetVisibility(true, true);
			SMC->SetHiddenInGame(false, true);								
			SMC->AddImpulseAtLocation(Impulse, ImpactPoint);
			SMA->SetLifeSpan(SpawnActorLifeSpan);
		}
		
		if (ICppEntityInterface* OwnerCppEntityInterface = UKGUEActorManager::GetLuaEntityByActor(Owner))
		{
			if (LuaEntityBase* OwnerLuaEntity = OwnerCppEntityInterface->GetLuaEntityBase())
			{
				KGObjectID ActorID = KGUtils::GetIDByObject(SMA);
				OwnerLuaEntity->CallLuaFunction(TEXT("KCB_OnMountHitSMA"), ActorID, ImpactPoint, ImpactNormal, Impulse);
			}
		}
	}
}

void UMountDetectComponent::TickFanDetectReact()
{
	TRACE_CPUPROFILER_EVENT_SCOPE(UMountDetectComponent::TickComponent::SectorDetect)

	const AActor* Owner = GetOwner();
	if (!Owner) return;

	const float Velocity = Owner->GetVelocity().Size2D();
	if (Velocity < MountVelocityThreshold)
	{
		return;
	}

	const FTransform& MountTrans = Owner->GetActorTransform();
	const FVector& Center = MountTrans.GetLocation();
	const FVector& Dir = MountTrans.GetUnitAxis(EAxis::X);

	TSet<TWeakObjectPtr<ABaseCharacter>>& ThisFrameActorsInFan = bLastFanFlag ? ActorsInFan1 : ActorsInFan2;
	const TSet<TWeakObjectPtr<ABaseCharacter>>& LastFrameActorsInFan = bLastFanFlag ? ActorsInFan2 : ActorsInFan1;
	ThisFrameActorsInFan.Reset();
	bLastFanFlag = !bLastFanFlag;
		
	// 1. 球形范围检测
	TArray<AActor*> AllActors;
	const TArray<AActor*> ActorsToIgnore;
	float SphereRadius = FanDetectRadius;
	if (MountVelocityFactor != 0) 
		SphereRadius = FanDetectRadius * Velocity * MountVelocityFactor;
	bool bOverlapped = UKismetSystemLibrary::SphereOverlapActors(
		GetWorld(),
		Center,
		SphereRadius,
		DetectObjectTypes,
		ABaseCharacter::StaticClass(),
		ActorsToIgnore,
		AllActors
	);
	
	// 2. 进行扇形角度过滤
	if (bOverlapped)
	{
		const float FacingCos = FMath::Cos(FMath::DegreesToRadians(CharacterFacingAngle / 2));
		for (AActor* Actor : AllActors)
		{
			ABaseCharacter* Character = Cast<ABaseCharacter>(Actor);
			if (!Character || !Character->IsCrowdNpc())
				continue;

			const FVector CharacterLocation = Character->GetActorLocation();

			// 1. 角色是否面向车
			FVector CharacterForward = Character->GetActorForwardVector();
			CharacterForward.Z = 0.f;
			if (!CharacterForward.Normalize())
				continue;

			FVector ToVehicle = Center - CharacterLocation;
			ToVehicle.Z = 0.f;
			if (!ToVehicle.Normalize())
				continue;

			if (FVector::DotProduct(CharacterForward, ToVehicle) < FacingCos)
				continue;

			// 2. 是否在车子的扇形范围
			if (!IsPointInSector(CharacterLocation, Center, Dir, FanDetectAngle))
				continue;

			// 3. 通知角色进入 React
			ThisFrameActorsInFan.Add(Character);
			if (!LastFrameActorsInFan.Contains(Character))
			{
				HandleActorEnterFan(Character, CharacterLocation - Center);
			}
		}
	}
	
	// Debug Draw
#if WITH_EDITOR
	if (DebugDrawType != EDrawDebugTrace::None)
	{
		// 计算扇形边界线
		const float HalfAngleDeg = FanDetectAngle * 0.5f;
		const FVector RightDir = Dir.RotateAngleAxis(HalfAngleDeg, FVector::UpVector);
		const FVector LeftDir = Dir.RotateAngleAxis(-HalfAngleDeg, FVector::UpVector);
		
		// 绘制扇形边界线
		DrawDebugLine(GetWorld(), Center, Center + RightDir * SphereRadius, FColor::Yellow, false, -1.f, 0, 2.f);
		DrawDebugLine(GetWorld(), Center, Center + LeftDir * SphereRadius, FColor::Yellow, false, -1.f, 0, 2.f);
		
		// 绘制扇形弧线
		const int32 NumArcSegments = 16;
		const float AngleStep = FanDetectAngle / (NumArcSegments - 1);
		FVector LastArcPoint = Center + RightDir * SphereRadius;
		for (int32 i = 1; i < NumArcSegments; ++i)
		{
			const float CurrentAngle = FanDetectAngle * 0.5f - AngleStep * i;
			const FVector CurrentDir = Dir.RotateAngleAxis(CurrentAngle, FVector::UpVector);
			const FVector CurrentArcPoint = Center + CurrentDir * SphereRadius;
			DrawDebugLine(GetWorld(), LastArcPoint, CurrentArcPoint, FColor::Cyan, false, -1.f, 0, 1.f);
			LastArcPoint = CurrentArcPoint;
		}
		
		// 绘制检测到的角色
		for (const TWeakObjectPtr<ABaseCharacter>& WeakChar : ThisFrameActorsInFan)
		{
			if (ABaseCharacter* Character = WeakChar.Get())
			{
				const FVector CharLocation = Character->GetActorLocation();
				DrawDebugSphere(GetWorld(), CharLocation, 50.f, 8, FColor::Red, false, -1.f, 0, 2.f);
				DrawDebugLine(GetWorld(), Center, CharLocation, FColor::Orange, false, -1.f, 0, 1.f);
			}
		}
		
		// 绘制速度信息
		if (GEngine)
		{
			const FString DebugText = FString::Printf(TEXT("Velocity: %.1f\nRadius: %.1f\nActors: %d"), 
				Velocity, SphereRadius, ThisFrameActorsInFan.Num());
			DrawDebugString(GetWorld(), Center + FVector(0, 0, 100.f), DebugText, nullptr, FColor::White, 0.f, true, 1.2f);
		}
	}
#endif
}

void UMountDetectComponent::StartDetectObjectsInBoxTrace(
	float StartX, float StartY, float StartZ,
	float EndX, float EndY, float EndZ,
	float BoxHalfSizeX, float BoxHalfSizeY, float BoxHalfSizeZ,
	TArray<int32> InDetectObjectTypes, bool OnlyDetectCrowdNPC)
{
	DetectObjectTypes.Empty();

	LastFrameActors.Empty();

	DetectStartPos.Set(StartX, StartY, StartZ);

	DetectEndPos.Set(EndX, EndY, EndZ);

	DetectBoxHalfSize.Set(BoxHalfSizeX, BoxHalfSizeY, BoxHalfSizeZ);

	for (int32 ObjectTypeInt : InDetectObjectTypes)
	{
		DetectObjectTypes.Add(TEnumAsByte<EObjectTypeQuery>(ObjectTypeInt));
	}

	bOnlyDetectCrowdNPC = OnlyDetectCrowdNPC;

	bEnableDetect = true;
}


void UMountDetectComponent::StopDetectObjects()
{
	for (auto& WeakActor : LastFrameActors)
	{
		ABaseCharacter* Char = WeakActor.Get();
		if (Char)
		{
			HandleActorLeave(Char);
		}
	}
	LastFrameActors.Empty();

	bEnableDetect = false;
}


void UMountDetectComponent::HandleActorEnter(ABaseCharacter* Char, const FHitResult& Hit)
{
	KGEntityID EntityID = UKGUEActorManager::GetLuaEntityIDByActor(Char);

	// 碰撞点
	const FVector ImpactPoint = Hit.ImpactPoint;

	// 碰撞点法线
	const FVector ImpactNormal = Hit.ImpactNormal;

	if (ICppEntityInterface* OwnerCppEntityInterface = UKGUEActorManager::GetLuaEntityByActor(GetOwner()))
	{
		if (LuaEntityBase* OwnerLuaEntity = OwnerCppEntityInterface->GetLuaEntityBase())
		{
			OwnerLuaEntity->CallLuaFunction(TEXT("KCB_OnMountDetectActorEnter"), EntityID, ImpactPoint, ImpactNormal);
		}
	}
}

void UMountDetectComponent::HandleActorLeave(ABaseCharacter* Char)
{
	KGEntityID EntityID = UKGUEActorManager::GetLuaEntityIDByActor(Char);

	if (ICppEntityInterface* OwnerCppEntityInterface = UKGUEActorManager::GetLuaEntityByActor(GetOwner()))
	{
		if (LuaEntityBase* OwnerLuaEntity = OwnerCppEntityInterface->GetLuaEntityBase())
		{
			OwnerLuaEntity->CallLuaFunction(TEXT("KCB_OnMountDetectActorLeave"), EntityID);
		}
	}
}

void UMountDetectComponent::SetDetectActorsInFanParams(const float Radius, const float Angle, const float VelocityFactor, const float VelocityThreshold, const float FacingAngle)
{
	FanDetectRadius = Radius;
	FanDetectAngle = Angle;
	MountVelocityFactor = VelocityFactor;
	MountVelocityThreshold = VelocityThreshold;
	CharacterFacingAngle = FacingAngle;
}

void UMountDetectComponent::SetGTAParams(const float ImpulseStrength,const int TraceChannel,bool UseComponentGTATag,const float LifeSpan,const FName ProfileName, const TArray<float>& InImpulseConfig)
{
	StreetLampImpulseStrength = ImpulseStrength;
	const ECollisionChannel Channel = static_cast<ECollisionChannel>(TraceChannel); 
	GTATraceChannel = UEngineTypes::ConvertToTraceType(Channel);
	bUseComponentGTATag = UseComponentGTATag;
	SpawnActorLifeSpan = LifeSpan;
	CollisionProfileName = ProfileName;
	ImpulseConfig = InImpulseConfig;
}

void UMountDetectComponent::HandleActorEnterFan(ABaseCharacter* Character, const FVector& Dir) const
{
	if (ICppEntityInterface* NpcCppEntityInterface = UKGUEActorManager::GetLuaEntityByActor(Character))
	{
		if (LuaEntityBase* NpcLuaEntity = NpcCppEntityInterface->GetLuaEntityBase())
		{
			NpcLuaEntity->CallLuaFunction(TEXT("KCB_OnEnterMountFan"), Dir);
		}
	}
}

bool UMountDetectComponent::IsPointInSector(const FVector& Point, const FVector& Center, const FVector& Dir, const float FanDetectAngle)
{    
	FVector ToPoint = Point - Center;
	ToPoint.Z = 0.f;

	const float ToPointLenSq = ToPoint.SizeSquared();
	if (ToPointLenSq < KINDA_SMALL_NUMBER)
	{
		return true;
	}

	FVector Forward = Dir;
	Forward.Z = 0.f;

	const float ForwardLenSq = Forward.SizeSquared();
	if (ForwardLenSq < KINDA_SMALL_NUMBER)
	{
		return false;
	}

	const float Dot = FVector::DotProduct(Forward, ToPoint);

	// 背面直接剔除（等价于 cos < 0）
	if (Dot <= 0.f)
	{
		return false;
	}

	// 计算 cos(halfAngle)
	const float CosThreshold = FMath::Cos(FMath::DegreesToRadians(FanDetectAngle / 2));

	// 等价于：
	// Dot / (|A||B|) >= cos(theta)
	return Dot >= FMath::Sqrt(ForwardLenSq * ToPointLenSq) * CosThreshold;
}
