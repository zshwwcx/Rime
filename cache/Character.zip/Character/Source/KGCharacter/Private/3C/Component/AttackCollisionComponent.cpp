#include "3C/Component/AttackCollisionComponent.h"

#include "3C/Character/BulletActor.h"
#include "3C/Core/C7ActorInterface.h"
#include "CollisionQueryParams.h"
#include "CollisionShape.h"
#include "DrawDebugHelpers.h"
#include "KGCharacterModule.h"
#include "3C/Character/SeerAttachActor.h"
#include "3C/Core/KGUEActorManager.h"
#include "3C/RoleComposite/RoleCompositeManager.h"
#include "3C/Combat/TargetSelectUtils.h"
#include "3C/Component/PerfectDodgeComponent.h"
#include "3C/Component/WeaponManagerComponent.h"
#include "Components/SceneComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/HitResult.h"
#include "Engine/World.h"
#include "GameFramework/Character.h"
#include "Managers/KGCombatSettingsManager.h"
#include "Managers/KGDataCacheManager.h"
#include "3C/Util/KGUtils.h"

#define KG_PHYSICS_QUERY_LINK_LINE_THICKNESS (10.0f)
#define KG_INVALID_ATTACK_INFO_ID (0)

static bool bEnableAttackCollisionDrawDebug = false;
static FAutoConsoleVariableRef CVarEnableAttackCollisionDrawDebug(
	TEXT("gp.EnableAttackCollisionDrawDebug"),
	bEnableAttackCollisionDrawDebug,
	TEXT("EnableAttackCollisionDrawDebug."),
	ECVF_Default
);

ICppEntityInterface* FKGClientRangeAttackContext::GetBaseEntity(UKGUEActorManager* ActorManager)
{
	if (BaseEntity.IsValid())
    {
    	return BaseEntity.Get();
    }
    
    if (ActorManager == nullptr)
    {
    	UE_LOG(LogKGCombat, Error, TEXT("FKGClientRangeAttackContext::GetBaseEntity, invalid ActorManager"));
    	return nullptr;
    }
    
    if (UnitEntityID == KG_INVALID_ENTITY_ID)
    {
    	return nullptr;
    }
    
    BaseEntity = ActorManager->GetLuaEntity(UnitEntityID);
    return BaseEntity.Get();
}

ICppEntityInterface* FKGClientRangeAttackContext::GetTargetEntity(UKGUEActorManager* ActorManager)
{
	if (TargetEntity.IsValid())
	{
		return TargetEntity.Get();
	}
	
	if (ActorManager == nullptr)
	{
		UE_LOG(LogKGCombat, Error, TEXT("FKGClientRangeAttackContext::GetTargetEntity, invalid ActorManager"));
		return nullptr;
	}
	
	if (TargetEntityID == KG_INVALID_ENTITY_ID)
	{
		return nullptr;
	}
	
	TargetEntity = ActorManager->GetLuaEntity(TargetEntityID);
	return TargetEntity.Get();
}

UAttackCollisionComponent::UAttackCollisionComponent(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	// 精确物理判定依赖当帧角色以及角色武器的动作更新结果, 也依赖各个单位当前帧位置更新结果, 这里先把这块逻辑放到TG_PostUpdateWork阶段执行, 不用tick依赖
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = false;
	PrimaryComponentTick.TickGroup = TG_PostUpdateWork;
}

void UAttackCollisionComponent::TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (PhysicsQueryCollisionContexts.Num() > 0)
	{
		PerformPhysicsQuery();	
	}
	
	if (ClientAttackParams.Num() > 0)
	{
		TArray<uint32> AttackIDs;
		ClientAttackParams.GenerateKeyArray(AttackIDs);
		
		for (auto AttackID : AttackIDs)
		{
			if (!ClientAttackParams.Contains(AttackID))
			{
				continue;
			}
			
			auto& Context = ClientAttackParams[AttackID];
			if (CanRangeAttack(Context, DeltaTime))
			{
				PerformRangeAttack(Context);
			}
		}
	}
}

void UAttackCollisionComponent::EnablePhysicsQueryCollision(
	KGActorID HitBoxOwnerActorID, const FName& ModelName, const FName& ShapeName, const TArray<int32>& ObjectTypesToQuery,
	uint32 SourceAbilityID, uint32 AttackSkillID, bool bTriggerPerfectDodge,float MinHitIntervalSeconds)
{
	if (CollisionShapeNameToID.Contains(ShapeName))
	{
		UE_LOG(LogKGCombat, Log, TEXT("UAttackCollisionComponent::EnablePhysicsQueryCollision, ShapeName already exists: %s, %s"),
			*ShapeName.ToString(), *GetNameSafe(GetOwner()));
		return;
	}
	
	AActor* OwnerActor = KGUtils::GetActorByID(HitBoxOwnerActorID);
	if (!IsValid(OwnerActor))
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::EnablePhysicsQueryCollision, invalid OwnerActor, %s"), *ShapeName.ToString());
		return;
	}

	URoleCompositeMgr* RoleCompositeMgr = URoleCompositeMgr::GetInstance(OwnerActor);
	if (!RoleCompositeMgr)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::EnablePhysicsQueryCollision, invalid RoleCompositeMgr, %s"), *ShapeName.ToString());
		return;
	}

	FModelHitBoxData ModelHitBoxData;
	if (!RoleCompositeMgr->GetModelHitbox(ModelName, ShapeName, ModelHitBoxData))
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::EnablePhysicsQueryCollision, cannot find hitbox data for ModelName: %s, ShapeName: %s"),
			*ModelName.ToString(), *ShapeName.ToString());
		return;
	}
	
	InternalEnablePhysicsQueryCollision(OwnerActor, ModelHitBoxData, ShapeName, ObjectTypesToQuery,
		SourceAbilityID, AttackSkillID, bTriggerPerfectDodge, MinHitIntervalSeconds);
}

void UAttackCollisionComponent::EnablePhysicsQueryCollisionNew(bool bCheckWeapon, const FName& CharacterModelName, const FName& ShapeName, 
	const TArray<int32>& ObjectTypesToQuery, uint32 SourceAbilityID, uint32 AttackSkillID, bool bTriggerPerfectDodge, float MinHitIntervalSeconds)
{
	if (CollisionShapeNameToID.Contains(ShapeName))
	{
		UE_LOG(LogKGCombat, Log, TEXT("UAttackCollisionComponent::EnablePhysicsQueryCollisionNew, ShapeName already exists: %s, %s"),
			*ShapeName.ToString(), *GetNameSafe(GetOwner()));
		return;
	}
	
	AActor* OwnerActor = GetOwner();
	if (!OwnerActor)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::EnablePhysicsQueryCollisionNew, invalid OwnerActor, %s"), *ShapeName.ToString());
		return;
	}
	
	URoleCompositeMgr* RoleCompositeMgr = URoleCompositeMgr::GetInstance(OwnerActor);
	if (!RoleCompositeMgr)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::EnablePhysicsQueryCollisionNew, invalid RoleCompositeMgr, %s"), *ShapeName.ToString());
		return;
	}

	FModelHitBoxData ModelHitBoxData;
	if (!RoleCompositeMgr->GetModelHitbox(CharacterModelName, ShapeName, ModelHitBoxData))
	{
		UE_LOG(LogKGCombat, Log, TEXT("UAttackCollisionComponent::EnablePhysicsQueryCollisionNew, cannot find hitbox data for ModelName: %s, ShapeName: %s"),
			*CharacterModelName.ToString(), *ShapeName.ToString());
		
		if (!bCheckWeapon)
		{
			return;
		}
		
		// 尝试从武器上获取hit box
		UWeaponManagerComponent* WeaponManagerComponent = OwnerActor->FindComponentByClass<UWeaponManagerComponent>();
		if (!WeaponManagerComponent)
		{
			UE_LOG(LogKGCombat, Log, TEXT("UAttackCollisionComponent::EnablePhysicsQueryCollisionNew, cannot find WeaponManagerComponent, %s"), *ShapeName.ToString());
			return;
		}
		
		const auto& WeaponIDs = WeaponManagerComponent->GetCurActiveWeaponList();
		AActor* WeaponActor = nullptr;
		for (auto WeaponID : WeaponIDs)
		{
			auto* WeaponInfoPtr = WeaponManagerComponent->GetWeaponInfoByID(WeaponID);
			if (!WeaponInfoPtr || !WeaponInfoPtr->WeaponActor)
			{
				continue;
			}
			
			if (RoleCompositeMgr->GetModelHitbox(*WeaponInfoPtr->InfoData.ModelID, ShapeName, ModelHitBoxData))
			{
				WeaponActor = WeaponInfoPtr->WeaponActor;
				UE_LOG(LogKGCombat, Log, TEXT("UAttackCollisionComponent::EnablePhysicsQueryCollisionNew, find hitbox data from weapon for ModelName: %s, ShapeName: %s"),
					*WeaponInfoPtr->InfoData.ModelID, *ShapeName.ToString());
				break;
			}
		}
		
		if (WeaponActor == nullptr)
		{
			UE_LOG(LogKGCombat, Warning, TEXT("UAttackCollisionComponent::EnablePhysicsQueryCollisionNew, cannot find hitbox data from weapon either, %s"), 
				*ShapeName.ToString());
			return;
		}
		
		OwnerActor = WeaponActor;
	}
	
	InternalEnablePhysicsQueryCollision(OwnerActor, ModelHitBoxData, ShapeName, ObjectTypesToQuery,
		SourceAbilityID, AttackSkillID, bTriggerPerfectDodge, MinHitIntervalSeconds);
}

void UAttackCollisionComponent::DisablePhysicsQueryCollision(const FName& ShapeName)
{
	auto* CollisionIDPtr = CollisionShapeNameToID.Find(ShapeName);
	if (CollisionIDPtr == nullptr)
	{
		return;
	}

	RemovePhysicsQueryCollision(*CollisionIDPtr);
	CollisionShapeNameToID.Remove(ShapeName);
}

uint32 UAttackCollisionComponent::AddPhysicsQueryCollision(const FKGPhysicsQueryCollisionInfo& CollisionInfo)
{
	UE_LOG(LogKGCombat, Log, TEXT("UAttackCollisionComponent::AddPhysicsQueryCollision, %s, %d, %s, %s"),
		*GetNameSafe(GetOwner()), CollisionInfo.ShapeType,
		CollisionInfo.AttachComponent.IsValid() ? *GetNameSafe(CollisionInfo.AttachComponent->GetOwner()) : TEXT("None"),
		*GetNameSafe(CollisionInfo.AttachComponent.Get()));
	const auto NewCollisionID = GenerateCollisionID();
	auto& Context = PhysicsQueryCollisionContexts.Add(NewCollisionID);
	Context.CollisionInfo = CollisionInfo;
	Context.LastFrameTrans = CollisionInfo.AttachComponent->GetSocketTransform(CollisionInfo.AttachSocketName);
	UpdatePhysicsQueryTickState();
	return NewCollisionID;
}

void UAttackCollisionComponent::RemovePhysicsQueryCollision(uint32 CollisionID)
{
	if (PhysicsQueryCollisionContexts.Contains(CollisionID))
	{
		UE_LOG(LogKGCombat, Log, TEXT("UAttackCollisionComponent::RemovePhysicsQueryCollision, disable ShapeName: %s"),
			*GetNameSafe(GetOwner()));
		PhysicsQueryCollisionContexts.Remove(CollisionID);
		UpdatePhysicsQueryTickState();
	}
	else
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::RemovePhysicsQueryCollision, cannot find collision context: %s"),
			*GetNameSafe(GetOwner()));
	}
}

uint32 UAttackCollisionComponent::EnableRangeAttack(
	// search params
	uint32 SkillOrSpellFieldID, KGEntityID TargetEntityID, bool bUseInputPos, float InputPosX, float InputPosY, float InputPosZ,
	bool bUseInputYaw, float InputYaw,
	// hit params
	bool bTriggerPerfectDodge, uint32 SourceSkillID, uint32 AttackSkillID, float MinHitIntervalSeconds, 
	EKGClientAttackSourceType SourceType, uint64 UnitInstID, KGEntityID UnitEntityID)
{
	if (SourceType != EKGClientAttackSourceType::Skill &&
		SourceType != EKGClientAttackSourceType::SpellField)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::EnableRangeAttack, invalid SourceType: %d"), (int32)SourceType);
		return KG_INVALID_ATTACK_INFO_ID;
	}
	
	if (SkillOrSpellFieldID == 0)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::EnableRangeAttack, invalid SkillOrSpellFieldID"));
		return KG_INVALID_ATTACK_INFO_ID;
	}
	
	if (!UpdateAndCacheManagers())
	{
		return KG_INVALID_ATTACK_INFO_ID;
	}
	check(DataCacheManager.IsValid());
	
	FKGClientRangeAttackContext AttackParams;
	if (SourceType == EKGClientAttackSourceType::Skill)
	{
		auto* SkillData = DataCacheManager->GetSkillData(SkillOrSpellFieldID);
		if (!SkillData)
		{
			UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::EnableRangeAttack, cannot find SkillData for SkillID: %d"), SkillOrSpellFieldID);
			return KG_INVALID_ATTACK_INFO_ID;
		}
	}
	else if (SourceType == EKGClientAttackSourceType::SpellField)
	{
		auto* SpellFieldData = DataCacheManager->GetSpellFieldData(SkillOrSpellFieldID);
		if (!SpellFieldData)
		{
			UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::EnableRangeAttack, cannot find SkillData for SkillID: %d"), SkillOrSpellFieldID);
			return KG_INVALID_ATTACK_INFO_ID;
		}
	}
	
	AttackParams.SkillOrSpellFieldID = SkillOrSpellFieldID;
	AttackParams.TargetEntityID = TargetEntityID;
	
	if (bUseInputPos)
	{
		FVector InputPos(InputPosX, InputPosY, InputPosZ);
		if (InputPos.ContainsNaN())
		{
			UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::EnableRangeAttack, invalid InputPos"));
			return KG_INVALID_ATTACK_INFO_ID;
		}
		AttackParams.InputPos = InputPos;
	}
	
	if (bUseInputYaw)
	{
		AttackParams.InputYaw = InputYaw;
	}
	
	AttackParams.bTriggerPerfectDodge = bTriggerPerfectDodge;
	AttackParams.SourceSkillID = SourceSkillID;
	AttackParams.AttackSkillID = AttackSkillID;
	AttackParams.MinHitIntervalSeconds = MinHitIntervalSeconds;
	AttackParams.SourceType = SourceType;
	AttackParams.UnitInstID = UnitInstID;
	AttackParams.UnitEntityID = UnitEntityID;
	
	const auto NewCollisionID = GenerateCollisionID();
	auto& Context = ClientAttackParams.Add(NewCollisionID, AttackParams);
	
	UE_LOG(LogKGCombat, Log, TEXT("UAttackCollisionComponent::EnableRangeAttack, enable RangeAttack: %s, SourceType: %d, ID: %d, AttackID: %d"),
		*GetNameSafe(GetOwner()), SourceType, SkillOrSpellFieldID, NewCollisionID);
	
	if (CanRangeAttack(Context, 0.0f))
	{
		PerformRangeAttack(Context);
	}
	UpdatePhysicsQueryTickState();
	return NewCollisionID;
}

void UAttackCollisionComponent::DisableRangeAttack(uint32 AttackID)
{
	if (ClientAttackParams.Contains(AttackID))
	{
		UE_LOG(LogKGCombat, Log, TEXT("UAttackCollisionComponent::DisableRangeAttack, disable RangeAttack: %s, AttackID: %d"),
			*GetNameSafe(GetOwner()), AttackID);
		ClientAttackParams.Remove(AttackID);
		UpdatePhysicsQueryTickState();
	}
}

void UAttackCollisionComponent::InternalEnablePhysicsQueryCollision(
	AActor* CollisionOwnerActor, const FModelHitBoxData& ModelHitBoxData, const FName& ShapeName, const TArray<int32>& ObjectTypesToQuery, 
	uint32 SourceAbilityID, uint32 AttackSkillID, bool bTriggerPerfectDodge, float MinHitIntervalSeconds)
{
	if (!CollisionOwnerActor)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::InternalEnablePhysicsQueryCollision, invalid CollisionOwnerActor, %s"), *ShapeName.ToString());
		return;
	}
	
	USceneComponent* AttachComponent = nullptr;
	if (ACharacter* OwnerCharacter = Cast<ACharacter>(CollisionOwnerActor))
	{
		AttachComponent = OwnerCharacter->GetMesh();
	}
	else
	{
		AttachComponent = CollisionOwnerActor->FindComponentByClass<USkeletalMeshComponent>();
		if (!AttachComponent)
		{
			AttachComponent = CollisionOwnerActor->FindComponentByClass<UStaticMeshComponent>();
		}
	}
	
	if (!IsValid(AttachComponent))
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::InternalEnablePhysicsQueryCollision, invalid AttachComponent, %s"), *ShapeName.ToString());
		return;
	}

	UE_LOG(LogKGCombat, Log, TEXT("UAttackCollisionComponent::InternalEnablePhysicsQueryCollision, enable ShapeName: %s, %s"),
		*ShapeName.ToString(), *GetNameSafe(GetOwner()));
	
	FKGPhysicsQueryCollisionInfo CollisionInfo;
	CollisionInfo.ObjectTypesToQuery.Reserve(ObjectTypesToQuery.Num());
	for (const auto& ObjectType : ObjectTypesToQuery)
	{
		CollisionInfo.ObjectTypesToQuery.Add(static_cast<TEnumAsByte<EObjectTypeQuery>>(ObjectType));
	}
	CollisionInfo.bTriggerPerfectDodge = bTriggerPerfectDodge;
	CollisionInfo.AttachComponent = AttachComponent;
	CollisionInfo.SourceAbilityID = SourceAbilityID;
	CollisionInfo.AttackSkillID = AttackSkillID;
	CollisionInfo.MinHitIntervalSeconds = MinHitIntervalSeconds;

	if (ModelHitBoxData.Type == EModelHitboxType::Box)
	{
		CollisionInfo.ShapeType = EKGPhysicsQueryShapeType::Box;
		FKGPhysicsQueryCollisionBoxShapeParams BoxParams;
		BoxParams.BoxExtent = ModelHitBoxData.Extent;
		CollisionInfo.ShapeParams.SetSubtype<FKGPhysicsQueryCollisionBoxShapeParams>(BoxParams);
	}
	else if (ModelHitBoxData.Type == EModelHitboxType::Sphere)
	{
		CollisionInfo.ShapeType = EKGPhysicsQueryShapeType::Sphere;
		FKGPhysicsQueryCollisionSphereShapeParams SphereParams;
		SphereParams.Radius = ModelHitBoxData.Radius;
		CollisionInfo.ShapeParams.SetSubtype<FKGPhysicsQueryCollisionSphereShapeParams>(SphereParams);
	}
	else if (ModelHitBoxData.Type == EModelHitboxType::Capsule)
	{
		CollisionInfo.ShapeType = EKGPhysicsQueryShapeType::Capsule;
		FKGPhysicsQueryCollisionCapsuleShapeParams CapsuleParams;
		CapsuleParams.Radius = ModelHitBoxData.Radius;
		CapsuleParams.HalfHeight = ModelHitBoxData.HalfHeight;
		CollisionInfo.ShapeParams.SetSubtype<FKGPhysicsQueryCollisionCapsuleShapeParams>(CapsuleParams);
	}
	else
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::InternalEnablePhysicsQueryCollision, invalid hit box type %d for ModelName: %s, ShapeName: %s"),
			ModelHitBoxData.Type, *ModelHitBoxData.Name.ToString(), *ShapeName.ToString());
		return;
	}
	CollisionInfo.RelativeTransform = ModelHitBoxData.RelativeTransform;
	CollisionInfo.AttachSocketName = ModelHitBoxData.SocketName;

	const auto CollisionID = AddPhysicsQueryCollision(CollisionInfo);
	CollisionShapeNameToID.Add(ShapeName, CollisionID);
}

void UAttackCollisionComponent::HitEntityByRangeCheck(
	KGEntityID HitEntityID, EKGClientAttackSourceType SourceType, uint32 SourceAbilityID, uint64 UnitInstID, uint32 AttackSkillID, bool bTriggerPerfectDodge)
{
	if (!UpdateAndCacheManagers())
	{
		return;
	}
	check(UEActorManager.IsValid());

	auto* Entity = UEActorManager->GetLuaEntity(HitEntityID);
	if (!Entity)
	{
		UE_LOG(LogKGCombat, Log, TEXT("UAttackCollisionComponent::HitEntityByRangeCheck, cannot find entity for HitEntityID: %lld"),
			HitEntityID);
		return;
	}

	// 目前客户端的命中判定是通过scene query查询得到的, 不可能出现actor未创建的情况下被命中的情况
	auto* Actor = Entity->GetLuaEntityBase()->GetActor();
	if (!Actor)
	{
		UE_LOG(LogKGCombat, Log, TEXT("UAttackCollisionComponent::HitEntityByRangeCheck, cannot find actor for HitEntityID: %lld"),
			HitEntityID);
		return;
	}

	HitActorCommon(Actor, SourceType, SourceAbilityID, UnitInstID, AttackSkillID, bTriggerPerfectDodge);
}

void UAttackCollisionComponent::UpdatePhysicsQueryTickState()
{
	const bool bIsTickEnabled = PrimaryComponentTick.IsTickFunctionEnabled();
	const bool bShouldTick = PhysicsQueryCollisionContexts.Num() > 0 || ClientAttackParams.Num() > 0;
	if (bIsTickEnabled == bShouldTick)
	{
		return;
	}
	
	PrimaryComponentTick.SetTickFunctionEnable(bShouldTick);
}

void UAttackCollisionComponent::HitActorCommon(
	AActor* HitActor, EKGClientAttackSourceType SourceType, uint32 SourceAbilityID,
	uint64 UnitInstID, uint32 AttackSkillID, bool bTriggerPerfectDodge)
{
	IC7ActorInterface* HitActorInterface = Cast<IC7ActorInterface>(HitActor);
	if (!HitActorInterface)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::HitActorCommon, invalid HitActor"));
		return;
	}

	AActor* OwnerActor = GetOwner();
	if (!IsValid(OwnerActor))
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::HitActorCommon, invalid OwnerActor"));
		return;
	}

	if (!UpdateAndCacheManagers())
	{
		return;
	}
	check(UEActorManager.IsValid());
	check(CombatSettingsManager.IsValid());

	KGEntityID AttackerInstigatorEntityID;
	if (ABulletActor* BulletActor = Cast<ABulletActor>(OwnerActor))
	{
		AttackerInstigatorEntityID = BulletActor->GetInstigatorID();
	}
	else if (IC7ActorInterface* OwnerActorInterface = Cast<IC7ActorInterface>(OwnerActor))
	{
		AttackerInstigatorEntityID = OwnerActorInterface->GetEntityUID();
	}
	else
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::HitActorCommon, invalid OwnerActor, %s"), *GetNameSafe(GetOwner()));
		return;
	}
	
	const auto HitEntityID = HitActorInterface->GetEntityUID();
	auto* AttackerEntity = UEActorManager->GetLuaEntity(AttackerInstigatorEntityID);
	if (!AttackerEntity)
	{
		UE_LOG(LogKGCombat, Log, TEXT("UAttackCollisionComponent::HitActorCommon, cannot find entity for HitActor: %s"),
			*GetNameSafe(HitActor));
		return;
	}

	AActor* AttackerActor = AttackerEntity->GetLuaEntityBase()->GetActor();
	if (!IsValid(AttackerActor))
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::HitActorCommon, invalid AttackerActor"));
		return;
	}

	bool bPerfectDodgeTriggered = false;
	float AttackerSkillAvgSlomoRate = 1.0f;
	float AttackerSkillTotalSlomoTime = 0.0f;
	if (bTriggerPerfectDodge)
	{
		UPerfectDodgeComponent* DefenderPerfectDodgeComponent = HitActor->FindComponentByClass<UPerfectDodgeComponent>();
		if (DefenderPerfectDodgeComponent && DefenderPerfectDodgeComponent->CanTriggerPerfectDodge() && !DefenderPerfectDodgeComponent->IsPerfectDodgeActive())
		{
			UE_LOG(LogKGCombat, Log, TEXT("UAttackCollisionComponent::HitActorCommon, trigger perfect dodge, attack actor: %s, HitActor: %s"),
				*GetNameSafe(OwnerActor), *GetNameSafe(HitActor));
			bPerfectDodgeTriggered = true;

			AttackerSkillAvgSlomoRate = CombatSettingsManager->GetAttackerCurveAvgSlomoRate();
			AttackerSkillTotalSlomoTime = CombatSettingsManager->GetAttackerCurveTotalTime();

			// 第一版先不支持传播到子Unit
			// 触发完美闪避效果
			DefenderPerfectDodgeComponent->TriggerPerfectDodge(false, false);
			
			UPerfectDodgeComponent* AttackerPerfectDodgeComp = AttackerActor->FindComponentByClass<UPerfectDodgeComponent>();
			if (!AttackerPerfectDodgeComp)
			{
				AttackerPerfectDodgeComp = NewObject<UPerfectDodgeComponent>(AttackerActor);
				if (!IsValid(AttackerPerfectDodgeComp))
				{
					UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::HitActorCommon: Create PerfectDodgeComponent failed, %s"),
						*AttackerActor->GetName());
				}
				else
				{
					AttackerPerfectDodgeComp->RegisterComponent();	
				}
			}

			if (AttackerPerfectDodgeComp)
			{
				AttackerPerfectDodgeComp->TriggerPerfectDodge(true, false);

				// 目前暂不支持完美闪避效果传播到子Unit
				if (OwnerActor != AttackerActor)
				{
					AttackerPerfectDodgeComp->AddChildUnitsEnableTimeDilation(OwnerActor);
					if (ABulletActor* BulletActor = Cast<ABulletActor>(OwnerActor))
					{
						BulletActor->StartTimeDilationEffect(true);	
					}
				}
			}
		}
	}

	FVector BulletPos = FVector::ZeroVector;
	FRotator BulletRot = FRotator::ZeroRotator;
	if (ABulletActor* BulletActor = Cast<ABulletActor>(OwnerActor))
	{
		BulletPos = BulletActor->GetActorLocation();
		BulletRot = BulletActor->GetActorRotation();
	}

	AttackerEntity->GetLuaEntityBase()->CallLuaFunction(TEXT("KCB_OnClientAttackHitEntity"),
		HitEntityID, SourceType, SourceAbilityID, UnitInstID, AttackSkillID, bPerfectDodgeTriggered,
		AttackerSkillAvgSlomoRate, AttackerSkillTotalSlomoTime,
		BulletPos.X, BulletPos.Y, BulletPos.Z, BulletRot.Pitch, BulletRot.Yaw, BulletRot.Roll);
}

bool UAttackCollisionComponent::CanRangeAttack(FKGClientRangeAttackContext& InOutContext, float DeltaTime)
{
	if (InOutContext.SourceType == EKGClientAttackSourceType::Skill)
	{
		return true;
	}
	
	auto* SpellFieldData = DataCacheManager->GetSpellFieldData(InOutContext.SkillOrSpellFieldID);
	if (SpellFieldData == nullptr)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::CanRangeAttack, cannot find SpellFieldData for SpellFieldID: %d"),
			InOutContext.SkillOrSpellFieldID);
		return false;
	}
	
	if (SpellFieldData->CheckTimeList.Num() == 0)
	{
		return true;
	}
	
	InOutContext.AccumulatedTimeSeconds += DeltaTime;
	if (!SpellFieldData->CheckTimeList.IsValidIndex(InOutContext.CurrentTimeWindowIndex))
	{
		return false;
	}
	
	FVector2D TimeWindow = SpellFieldData->CheckTimeList[InOutContext.CurrentTimeWindowIndex];
	
	while (InOutContext.AccumulatedTimeSeconds > TimeWindow.Y)
	{
		InOutContext.CurrentTimeWindowIndex++;
		if (!SpellFieldData->CheckTimeList.IsValidIndex(InOutContext.CurrentTimeWindowIndex))
		{
			return false;
		}
		TimeWindow = SpellFieldData->CheckTimeList[InOutContext.CurrentTimeWindowIndex];
	}
	
	if (InOutContext.AccumulatedTimeSeconds < TimeWindow.X)
	{
		return false;
	}
	
	return true;
}

void UAttackCollisionComponent::PerformRangeAttack(FKGClientRangeAttackContext& InOutContext)
{
	FKGTargetSelectParamsSimple TargetSelectParams;
	TargetSelectParams.BaseEntity = InOutContext.GetBaseEntity(UEActorManager.Get());
	TargetSelectParams.InputPos = InOutContext.InputPos;
	TargetSelectParams.InputYaw = InOutContext.InputYaw;
	TargetSelectParams.TargetEntity = InOutContext.GetTargetEntity(UEActorManager.Get());
	TargetSelectParams.SkillID = InOutContext.SourceSkillID;
	
	FKGTargetSelectResult SelectResult;
	if (InOutContext.SourceType == EKGClientAttackSourceType::Skill)
	{
		TargetSelectorUtils::QueryEntitiesBySkillID(TargetSelectParams, InOutContext.SkillOrSpellFieldID, SelectResult);
	}
	else if (InOutContext.SourceType == EKGClientAttackSourceType::SpellField)
	{
		TargetSelectorUtils::QueryEntitiesBySpellFieldID(TargetSelectParams, InOutContext.SkillOrSpellFieldID, SelectResult);
	}
	else
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::PerfectRangeAttack, invalid SourceType: %d"), (int32)InOutContext.SourceType);
		return;
	}
	
	if (SelectResult.EntityIDs.Num() == 0)
	{
		return;
	}
	
	const auto CurrentTimeSeconds = FPlatformTime::Seconds();
	for (const auto TargetID : SelectResult.EntityIDs)
	{
		if (InOutContext.MinHitIntervalSeconds > UE_KINDA_SMALL_NUMBER)
		{
			if (!InOutContext.TargetHitRecords.Contains(TargetID))
			{
				InOutContext.TargetHitRecords.Add(TargetID, CurrentTimeSeconds + InOutContext.MinHitIntervalSeconds);
			}
			else
			{
				const auto NextValidHitTime = InOutContext.TargetHitRecords[TargetID];
				if (CurrentTimeSeconds > NextValidHitTime)
				{
					InOutContext.TargetHitRecords[TargetID] = CurrentTimeSeconds + InOutContext.MinHitIntervalSeconds;
				}
				else
				{
					continue;
				}
			}
		}
		else
		{
			if (!InOutContext.TargetHitRecords.Contains(TargetID))
			{
				InOutContext.TargetHitRecords.Add(TargetID, 0);
			}
			else
			{
				continue;
			}
		}
		
		HitEntityByRangeCheck(TargetID, InOutContext.SourceType, InOutContext.SourceSkillID,
			InOutContext.UnitInstID, InOutContext.AttackSkillID, InOutContext.bTriggerPerfectDodge);
	}
}

uint32 UAttackCollisionComponent::GenerateCollisionID()
{
	CurCollisionID++;
	if (CurCollisionID == 0x7fffffff)
	{
		CurCollisionID = 1;
	}
	return CurCollisionID;
}

void UAttackCollisionComponent::PerformPhysicsQuery()
{
	UWorld* World = GetWorld();
	if (!World)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::PerformPhysicsQuery, invalid world, %s"), *GetNameSafe(GetOwner()));
		return;
	}

	// 可能会在迭代中调用到删除(技能变速)
	TArray<uint32> AttackIDs;
	PhysicsQueryCollisionContexts.GenerateKeyArray(AttackIDs);
	for (auto AttackID : AttackIDs)
	{
		if (!PhysicsQueryCollisionContexts.Contains(AttackID))
		{
			continue;
		}
		
		auto& CollisionContext = PhysicsQueryCollisionContexts[AttackID];
		const auto& CollisionInfo = CollisionContext.CollisionInfo;
		if (!CollisionInfo.AttachComponent.IsValid())
		{
			continue;
		}
		
		TArray<FHitResult> OutHitResults;
		FCollisionQueryParams QueryParams;
		QueryParams.AddIgnoredActor(GetOwner());
		QueryParams.AddIgnoredActors(CollisionContext.IgnoredActors);
		FCollisionObjectQueryParams ObjectQueryParams(CollisionInfo.ObjectTypesToQuery);
		FCollisionShape CollisionShape;
		const FTransform& CurFrameTransform = CollisionInfo.RelativeTransform * CollisionInfo.AttachComponent->GetSocketTransform(CollisionInfo.AttachSocketName);
		
		if (CollisionInfo.ShapeType == EKGPhysicsQueryShapeType::Sphere)
		{
			// todo 球形的sweep可以考虑替换为capsule的overlap
			const float SphereRadius = CollisionInfo.ShapeParams.GetSubtype<FKGPhysicsQueryCollisionSphereShapeParams>().Radius;
			CollisionShape.SetSphere(SphereRadius);
			World->SweepMultiByObjectType(OutHitResults, 
				CollisionContext.LastFrameTrans.GetLocation(), CurFrameTransform.GetLocation(),
				FQuat::Identity, ObjectQueryParams, CollisionShape, QueryParams);
#if !UE_BUILD_TEST && !UE_BUILD_SHIPPING
			if (bEnableAttackCollisionDrawDebug)
			{
				DrawDebugSphere(World, CollisionContext.LastFrameTrans.GetLocation(), SphereRadius,
					12, FColor::Red, false, 0.0f);
				DrawDebugSphere(World, CurFrameTransform.GetLocation(), SphereRadius,
					12, FColor::Red, false, 0.0f);
				DrawDebugLine(World, CollisionContext.LastFrameTrans.GetLocation(),
					CurFrameTransform.GetLocation(), FColor::Red, false, 0.0f,
					0, KG_PHYSICS_QUERY_LINK_LINE_THICKNESS);
			}
#endif
		}
		else if (CollisionInfo.ShapeType == EKGPhysicsQueryShapeType::Capsule || 
				CollisionInfo.ShapeType == EKGPhysicsQueryShapeType::Box)
		{
			if (CollisionInfo.ShapeType == EKGPhysicsQueryShapeType::Capsule)
			{
				const auto& CapsuleShapeInfo = CollisionInfo.ShapeParams.GetSubtype<FKGPhysicsQueryCollisionCapsuleShapeParams>();
				CollisionShape.SetCapsule(CapsuleShapeInfo.Radius, CapsuleShapeInfo.HalfHeight);
			}
			else
			{
				const auto& BoxShapeInfo = CollisionInfo.ShapeParams.GetSubtype<FKGPhysicsQueryCollisionBoxShapeParams>();
				CollisionShape.SetBox(FVector3f(BoxShapeInfo.BoxExtent));
			}
			World->SweepMultiByObjectType(OutHitResults, 
				CollisionContext.LastFrameTrans.GetLocation(),CurFrameTransform.GetLocation(),
				CollisionContext.LastFrameTrans.GetRotation(), ObjectQueryParams, CollisionShape, QueryParams);
#if !UE_BUILD_TEST && !UE_BUILD_SHIPPING
			if (bEnableAttackCollisionDrawDebug)
			{
				FColor DrawColor = FColor::Yellow;
				if (CollisionInfo.ShapeType == EKGPhysicsQueryShapeType::Capsule)
				{
					const auto& CapsuleShapeInfo = CollisionInfo.ShapeParams.GetSubtype<FKGPhysicsQueryCollisionCapsuleShapeParams>();
					DrawDebugCapsule(World, CollisionContext.LastFrameTrans.GetLocation(),
						CapsuleShapeInfo.HalfHeight, CapsuleShapeInfo.Radius,
						CollisionContext.LastFrameTrans.GetRotation(), DrawColor, false, 0.0f,
						0, KG_PHYSICS_QUERY_LINK_LINE_THICKNESS);
					DrawDebugCapsule(World, CurFrameTransform.GetLocation(),
						CapsuleShapeInfo.HalfHeight, CapsuleShapeInfo.Radius,
						CollisionContext.LastFrameTrans.GetRotation(), DrawColor, false, 0.0f,
						0, KG_PHYSICS_QUERY_LINK_LINE_THICKNESS);
				}
				else
				{
					DrawColor = FColor::Blue;
					const auto& BoxShapeInfo = CollisionInfo.ShapeParams.GetSubtype<FKGPhysicsQueryCollisionBoxShapeParams>();
					DrawDebugBox(World, CollisionContext.LastFrameTrans.GetLocation(), BoxShapeInfo.BoxExtent,
						CollisionContext.LastFrameTrans.GetRotation(), DrawColor, false, 0.0f,
						0, KG_PHYSICS_QUERY_LINK_LINE_THICKNESS);
					DrawDebugBox(World, CurFrameTransform.GetLocation(), BoxShapeInfo.BoxExtent,
						CollisionContext.LastFrameTrans.GetRotation(), DrawColor, false, 0.0f,
						0, KG_PHYSICS_QUERY_LINK_LINE_THICKNESS);
				}
				DrawDebugLine(World, CollisionContext.LastFrameTrans.GetLocation(),
					CurFrameTransform.GetLocation(), DrawColor, false, 0.0f,
					0, KG_PHYSICS_QUERY_LINK_LINE_THICKNESS);
			}
#endif
			
			// 第二次sweep检测
			TArray<FHitResult> SecondHitResults;
			World->SweepMultiByObjectType(SecondHitResults, 
				CollisionContext.LastFrameTrans.GetLocation(),CurFrameTransform.GetLocation(),
				CurFrameTransform.GetRotation(), ObjectQueryParams, CollisionShape, QueryParams);
			OutHitResults.Append(SecondHitResults);

#if !UE_BUILD_TEST && !UE_BUILD_SHIPPING
			if (bEnableAttackCollisionDrawDebug)
			{
				FColor DrawColor = FColor::Yellow;
				if (CollisionInfo.ShapeType == EKGPhysicsQueryShapeType::Capsule)
				{
					const auto& CapsuleShapeInfo = CollisionInfo.ShapeParams.GetSubtype<FKGPhysicsQueryCollisionCapsuleShapeParams>();
					DrawDebugCapsule(World, CollisionContext.LastFrameTrans.GetLocation(),
						CapsuleShapeInfo.HalfHeight, CapsuleShapeInfo.Radius,
						CurFrameTransform.GetRotation(), DrawColor, false, 0.0f,
						0, KG_PHYSICS_QUERY_LINK_LINE_THICKNESS);
					DrawDebugCapsule(World, CurFrameTransform.GetLocation(),
						CapsuleShapeInfo.HalfHeight, CapsuleShapeInfo.Radius,
						CurFrameTransform.GetRotation(), DrawColor, false, 0.0f,
						0, KG_PHYSICS_QUERY_LINK_LINE_THICKNESS);
				}
				else
				{
					DrawColor = FColor::Blue;
					const auto& BoxShapeInfo = CollisionInfo.ShapeParams.GetSubtype<FKGPhysicsQueryCollisionBoxShapeParams>();
					DrawDebugBox(World, CollisionContext.LastFrameTrans.GetLocation(), BoxShapeInfo.BoxExtent,
						CurFrameTransform.GetRotation(), DrawColor, false, 0.0f,
						0, KG_PHYSICS_QUERY_LINK_LINE_THICKNESS);
					DrawDebugBox(World, CurFrameTransform.GetLocation(), BoxShapeInfo.BoxExtent,
						CurFrameTransform.GetRotation(), DrawColor, false, 0.0f,
						0, KG_PHYSICS_QUERY_LINK_LINE_THICKNESS);
				}
				DrawDebugLine(World, CollisionContext.LastFrameTrans.GetLocation(),
					CurFrameTransform.GetLocation(), DrawColor, false, 0.0f,
					0, KG_PHYSICS_QUERY_LINK_LINE_THICKNESS);
			}
#endif
		}
		else
		{
			UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::PerformPhysicsQuery, unsupported ShapeType %d, %s"),
				static_cast<uint8>(CollisionInfo.ShapeType), *GetNameSafe(GetOwner()));
		}

		CollisionContext.LastFrameTrans = CurFrameTransform;
		
		if (OutHitResults.Num() == 0)
		{
			continue;
		}

		// 命中处理
		for (const auto& HitResult : OutHitResults)
		{
			AActor* HitActor = HitResult.GetActor();
			if (!HitActor)
			{
				continue;
			}

			if (CollisionInfo.MinHitIntervalSeconds > UE_KINDA_SMALL_NUMBER)
			{
				const auto CurrentTimeSeconds = FPlatformTime::Seconds();
				double* NextValidHitTimePtr = CollisionContext.TargetNextValidHitTimeInfo.Find(HitActor);
				if (NextValidHitTimePtr == nullptr ||
					*NextValidHitTimePtr < CurrentTimeSeconds)
				{
					CollisionContext.TargetNextValidHitTimeInfo.Add(HitActor, CurrentTimeSeconds + CollisionInfo.MinHitIntervalSeconds);
				}
				else
				{
					continue;
				}
			}
			else
			{
				if (CollisionContext.TargetNextValidHitTimeInfo.Contains(HitActor))
				{
					continue;
				}

				CollisionContext.TargetNextValidHitTimeInfo.Add(HitActor, 0.0f);
				CollisionContext.IgnoredActors.Add(HitActor);
			}

			HitActorCommon(HitActor, CollisionInfo.SourceType, CollisionInfo.SourceAbilityID, CollisionInfo.UnitInstID,
				CollisionInfo.AttackSkillID, CollisionInfo.bTriggerPerfectDodge);
		}
	}
}

bool UAttackCollisionComponent::UpdateAndCacheManagers()
{
	if (!UEActorManager.IsValid())
	{
		UEActorManager = UKGUEActorManager::GetInstance(this);
		if (!UEActorManager.IsValid())
		{
			UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::UpdateAndCacheManagers ActorManager is null, %s"), *GetNameSafe(GetOwner()));
			return false;
		}
	}

	if (!CombatSettingsManager.IsValid())
	{
		CombatSettingsManager = UKGCombatSettingsManager::GetInstance(this);
		if (!CombatSettingsManager.IsValid())
		{
			UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::UpdateAndCacheManagers CombatSettingsManager is null, %s"), *GetNameSafe(GetOwner()));
			return false;
		}
	}

	if (!DataCacheManager.IsValid())
	{
		DataCacheManager = UKGDataCacheManager::GetInstance(this);
		if (!DataCacheManager.IsValid())
		{
			UE_LOG(LogKGCombat, Error, TEXT("UAttackCollisionComponent::UpdateAndCacheManagers DataCacheManager is null, %s"), *GetNameSafe(GetOwner()));
			return false;
		}
	}
	
	return true;
}

