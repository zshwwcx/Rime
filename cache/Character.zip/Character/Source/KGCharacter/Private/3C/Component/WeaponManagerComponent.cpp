// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Component/WeaponManagerComponent.h"

#include "3C/Animation/BaseAnimInstance.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Character/C7Actor.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "3C/Character/SeerAttachActor.h"
#include "TimerManager.h"
#include "3C/Animation/WeaponAnimInstance.h"
#include "3C/Util/KGUtils.h"
#include "Components/SkeletalMeshComponent.h"
#include "Manager/KGCppAssetManager.h"
#include "Manager/KGObjectActorManager.h"
#include "Managers/KGDataCacheManager.h"

// PRAGMA_DISABLE_OPTIMIZATION

// Sets default values for this component's properties
UWeaponManagerComponent::UWeaponManagerComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = false;

	// ...
}

void UWeaponManagerComponent::InitWeaponManagerConfig(bool bEnableFightToIdle)
{
	UpdateIsEnablePlayUnHoldWeaponAnim(bEnableFightToIdle);
}

void UWeaponManagerComponent::UpdateIsEnablePlayUnHoldWeaponAnim(bool bEnableFightToIdle)
{
	bEnablePlayUnHoldWeaponAnim = bEnableFightToIdle;
}

void UWeaponManagerComponent::CreateWeapon(FString ActorClass, int WeaponID, int WeaponGroup, FString FightToIdleAnimPath, EWeaponVisibleRule WeaponVisibleRule, EWeaponAttachRule WeaponAttachRule, bool bMainWeapon)
{
	if (ActorClass == "")
	{
		UE_LOG(LogTemp, Warning, TEXT("UWeaponManagerComponent::CreateWeapon	ActorClass = \"\""));
		return;
	}

	UKGDataCacheManager* DataCacheMgr = UKGDataCacheManager::GetInstance(this);
	if (!DataCacheMgr)
	{
		UE_LOG(LogTemp, Warning, TEXT("UWeaponManagerComponent::CreateWeapon get UKGDataCacheManager failed"));
		return;
	}
	
	UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this);
	if (!AssetManager)
	{
		UE_LOG(LogTemp, Warning, TEXT("UWeaponManagerComponent::CreateWeapon	invalid asset manager"));
		return;
	}

	if (MapOfCreatedWeapon.Contains(WeaponID))
	{
		UE_LOG(LogTemp, Warning, TEXT("UWeaponManagerComponent::CreateWeapon	Already exists Weapon WeaponID:%d"), WeaponID);
		return;
	}

	FWeaponInfoData* InfoData = DataCacheMgr->GetWeaponInfoData(WeaponID);
	if (!InfoData)
	{
		UE_LOG(LogTemp, Warning, TEXT("UWeaponManagerComponent::CreateWeapon	InfoData = nullptr WeaponID:%d"), WeaponID);
		return;
	}

	FWeaponInfo WeaponInfo;
	WeaponInfo.InfoData = *InfoData;
	WeaponInfo.WeaponGroup = WeaponGroup;
	WeaponInfo.ActorClass = ActorClass;
	WeaponInfo.FightToIdleAnimPath = FightToIdleAnimPath;
	WeaponInfo.WeaponVisibleRule = WeaponVisibleRule;
	WeaponInfo.WeaponAttachRule = WeaponAttachRule;
	MapOfCreatedWeapon.Add(WeaponID, std::move(WeaponInfo));

	if (bMainWeapon)
	{
		// 这里值维护数据关系不维护 逻辑更新
		UpdateWeaponInfo(WeaponGroup, WeaponInfo.InfoData.WeaponType, WeaponID);
		ActiveWeaponGroupArray.AddUnique(WeaponGroup);
		MapOfGroupToType.Add(WeaponGroup,  WeaponInfo.InfoData.WeaponType);
	}
	
	// 这个接口必定不会当帧回来 所以挂点信息可以和创建接口分开
	int AssetLoadID = AssetManager->AsyncLoadAsset(ActorClass, FAsyncLoadCompleteDelegate::CreateUObject(this, &UWeaponManagerComponent::OnWeaponActorClassLoaded, WeaponID), static_cast<int32>(EAssetLoadPriority::Default));
	AssetLoadMap.Add(WeaponID, AssetLoadID);
}

void UWeaponManagerComponent::SetUnrealAttachParam(int WeaponID, bool IsHoldWeaponParam, FName SocketName, EAttachmentRule LocRule, EAttachmentRule RotRule, EAttachmentRule ScaleRule,
	float RelLocX, float RelLocY, float RelLocZ, float RelPitch, float RelYaw, float RelRoll)
{
	FWeaponInfo* WeaponInfo = MapOfCreatedWeapon.Find(WeaponID);
	if (!WeaponInfo) return;

	FWeaponAttachInfo& AttachInfo = IsHoldWeaponParam ? WeaponInfo->HoldWeaponInfo : WeaponInfo->UnHoldWeaponInfo;
	AttachInfo.bUnrealAttach = true;
	AttachInfo.UnrealAttachInfo.AttachSocket = SocketName;
	AttachInfo.UnrealAttachInfo.LocRule = LocRule;
	AttachInfo.UnrealAttachInfo.RotRule = RotRule;
	AttachInfo.UnrealAttachInfo.ScaleRule = ScaleRule;
	AttachInfo.UnrealAttachInfo.RelLocation = FVector(RelLocX, RelLocY, RelLocZ);
	AttachInfo.UnrealAttachInfo.RelRotation = FRotator(RelPitch, RelYaw, RelRoll);
}

void UWeaponManagerComponent::SetUseVirtualAttach(int WeaponID, bool IsHoldWeaponParam, int VirtualAttachID)
{
	FWeaponInfo* WeaponInfo = MapOfCreatedWeapon.Find(WeaponID);
	if (!WeaponInfo) return;
	
	UKGDataCacheManager* DataCacheMgr = UKGDataCacheManager::GetInstance(this);
	if (!DataCacheMgr)
	{
		UE_LOG(LogTemp, Warning, TEXT("UWeaponManagerComponent::SetUseVirtualAttach get UKGDataCacheManager failed"));
	}

	FVirtualAttachInfo* Info = DataCacheMgr->GetVirtualAttachInfo(VirtualAttachID);
	if (!Info)
	{
		UE_LOG(LogTemp, Warning, TEXT("UWeaponManagerComponent::SetUseVirtualAttach get FVirtualAttachInfo failed VirtualAttachID:%d"), VirtualAttachID);
		return;
	}
	
	FWeaponAttachInfo& AttachInfo = IsHoldWeaponParam ? WeaponInfo->HoldWeaponInfo : WeaponInfo->UnHoldWeaponInfo;
	AttachInfo.bUnrealAttach = false;
	AttachInfo.VirtualAttachInfo = *Info;
}

void UWeaponManagerComponent::SetWeaponVisibility(bool bVisibility)
{
	// 如果武器执行隐藏的时候有收刀动作则进行打断
	if (!bVisibility)
	{
		StopFightToIdleAnim();
		StopTimerOfDelayDissolveWeapon();
	}
	
	bShowWeapon = bVisibility;
	UpdateAllWeaponByRule();
}

void UWeaponManagerComponent::SetWeaponDissolveEffectWithDefaultID(bool bVisible)
{
	if (ActiveWeaponGroupArray.Num() == 0 || !GetIsWeaponEnableShow()) return;

	TArray<int> CurWeaponList = GetCurActiveWeaponList();
	if (CurWeaponList.Num() == 0) return;
	
	FWeaponInfo* WeaponInfo = MapOfCreatedWeapon.Find(CurWeaponList[0]);
	if (!WeaponInfo) return;

	// 溶出特效
	int DissolveID = bVisible ? WeaponInfo->InfoData.AppearEffect :WeaponInfo->InfoData.DisappearEffect;
	if (DissolveID != 0)
	{
		SetWeaponDissolveEffect(bVisible, DissolveID);
	}
}

void UWeaponManagerComponent::SetWeaponDissolveEffect(bool bVisible, int DissolveID)
{
	if (ActiveWeaponGroupArray.Num() == 0 || !GetIsWeaponEnableShow()) return;
	TArray<int> CurWeaponList = GetCurActiveWeaponList();
	
	bool bCurHoldWeapon = GetIsWeaponEnableHold();
	for (int i=0; i<CurWeaponList.Num(); i++)
	{
		FWeaponInfo* SubWeaponInfo = MapOfCreatedWeapon.Find(CurWeaponList[i]);
		if (SubWeaponInfo && SubWeaponInfo->WeaponActor)
		{
			// 如果是只有持武的时候才显示的武器,播放溶入特效时需要拦截
			if (SubWeaponInfo->WeaponVisibleRule == EWeaponVisibleRule::ActiveAndHoldShow)
			{
				if (!bCurHoldWeapon && bVisible)
				{
					continue;
				}
			}
			
			SubWeaponInfo->WeaponActor->SetVisibilityBySelf(DissolveID, bVisible, EKGAttachActorDissolveType::WeaponDissolve);
		}
	}	
}

bool UWeaponManagerComponent::GetIsWeaponEnableShow()
{
	return bForceSkillShowWeapon || bShowWeapon;
}

bool UWeaponManagerComponent::GetIsWeaponEnableHold()
{
	return bHoldWeapon || bForceHoldWeapon;
}

void UWeaponManagerComponent::ActiveWeaponGroupWithTypeAndID(int WeaponGroup, int WeaponType, int MainWeaponID)
{
	UpdateWeaponInfo(WeaponGroup, WeaponType, MainWeaponID);
	ActiveWeaponGroupWithType(WeaponGroup, WeaponType);
}

void UWeaponManagerComponent::UpdateWeaponInfo(int WeaponGroup, int WeaponType, int MainWeaponID)
{
	// 更新当前武器类型 & 清理与更新当前激活武器ID
	TMap<Type_WeaponType, ID_WeaponID>& TypeToID = MapOfWeaponGroupToTypeToID.FindOrAdd(WeaponGroup);
	TypeToID.Add(WeaponType, MainWeaponID);
}

void UWeaponManagerComponent::ActiveWeaponGroupWithType(int WeaponGroup, int WeaponType)
{
	if (ActiveWeaponGroupArray.Find(WeaponGroup) == INDEX_NONE)
	{
		ActiveWeaponGroupArray.Add(WeaponGroup);
	}
	MapOfGroupToType.Add(WeaponGroup, WeaponType);
	UpdateAllWeaponByRule();
}

int UWeaponManagerComponent::GetCurActiveWeaponGroup()
{
	Type_WeaponGroup ActiveWeaponGroup = -1;
	
	for (auto& GroupID : ActiveWeaponGroupArray)
	{
		if (GroupID > ActiveWeaponGroup)
		{
			ActiveWeaponGroup = GroupID;
		}
	}
	return ActiveWeaponGroup;
}

void UWeaponManagerComponent::ActiveWeaponTypeByGroup(int WeaponGroup, int WeaponType)
{
	MapOfGroupToType.Add(WeaponGroup, WeaponType);
}

void UWeaponManagerComponent::ActiveCurrentWeaponType(int WeaponType)
{
	int CurActiveWeaponGroup = GetCurActiveWeaponGroup();
	if (CurActiveWeaponGroup == -1) return;
	
	MapOfGroupToType.Add(CurActiveWeaponGroup, WeaponType);
	UpdateAllWeaponByRule();
}

int UWeaponManagerComponent::RemoveWeaponGroup(int WeaponGroup)
{
	// 移除整组武器
	TArray<int> CurWeaponList = GetWeaponGroupWeaponList(WeaponGroup);
	for (auto& WeaponID : CurWeaponList)
	{
		DeleteWeaponByID(WeaponID);
	}

	ActiveWeaponGroupArray.Remove(WeaponGroup);
	MapOfGroupToType.Remove(WeaponGroup);
	MapOfWeaponGroupToTypeToID.Remove(WeaponGroup);
	
	// 显示新武器
	UpdateAllWeaponByRule();

	int CurActiveWeaponGroup = GetCurActiveWeaponGroup();
	if (CurActiveWeaponGroup != -1)
	{
		TMap<Type_WeaponType, ID_WeaponID>* TypeToID = MapOfWeaponGroupToTypeToID.Find(CurActiveWeaponGroup);
		Type_WeaponType* WeaponType = MapOfGroupToType.Find(CurActiveWeaponGroup);
		if (TypeToID && WeaponType && TypeToID->Contains(*WeaponType))
		{
			return (*TypeToID)[*WeaponType];
		}
	}
	
	return -1;
}

void UWeaponManagerComponent::UpdateAllWeaponByRule(bool bSkipActiveWeaponVisible)
{
	// 当前激活的武器ID 列表
	TArray<int> CurWeaponList = GetCurActiveWeaponList();
	bool bVisibility = GetIsWeaponEnableShow();
	bool bCurHoldWeapon = GetIsWeaponEnableHold();

	for (auto& Iter : MapOfCreatedWeapon)
	{
		FWeaponInfo& WeaponInfo = Iter.Value;
		if (!WeaponInfo.WeaponActor) continue;

		bool bActiveWeapon = CurWeaponList.Find(WeaponInfo.InfoData.WeaponID) != INDEX_NONE;
		// 显隐控制 如果整体武器是可见的则根据自身规则控制显隐、反之默认隐藏
		bool bThisWeaponVisible = bVisibility;
		if (bVisibility)
		{
			switch (WeaponInfo.WeaponVisibleRule)
			{
			case EWeaponVisibleRule::AutoHide:
				bThisWeaponVisible = bActiveWeapon;
				break;
			case EWeaponVisibleRule::NeverHideWithWeaponVisible:
				bThisWeaponVisible = true;
				break;
			case EWeaponVisibleRule::ActiveAndHoldShow:
				bThisWeaponVisible = bActiveWeapon && bCurHoldWeapon;
				break;
			default:
				break;
			}
		}
		else
		{
			bThisWeaponVisible = false;
		}
		
		if (!bActiveWeapon || !bSkipActiveWeaponVisible)
		{
			WeaponInfo.WeaponActor->SetVisibilityBySelf(-1, bThisWeaponVisible, EKGAttachActorDissolveType::WeaponDissolve);
		}

		// 强制使用 持武挂点或者 非持武挂点表明不受持武变量控制挂点切换
		EWeaponAttachType AttachType = EWeaponAttachType::WaitAttach;
		if (WeaponInfo.WeaponAttachRule == EWeaponAttachRule::ForceHoldSocket)
		{
			AttachType = EWeaponAttachType::HoldAttach;
		}
		else if (WeaponInfo.WeaponAttachRule == EWeaponAttachRule::ForceUnholdSocket)
		{
			AttachType = EWeaponAttachType::UnHoldAttach;
		}
		else if (WeaponInfo.WeaponAttachRule == EWeaponAttachRule::AutoAttach)
		{
			AttachType = bCurHoldWeapon ? EWeaponAttachType::HoldAttach : EWeaponAttachType::UnHoldAttach;
		}
		
		if (AttachType != EWeaponAttachType::WaitAttach)
		{
			UpdateWeaponAttachState(WeaponInfo, AttachType);	
		}
	}
}

void UWeaponManagerComponent::UpdateHoldWeaponState(bool IsHoldWeapon, bool bSkipActiveWeaponVisible)
{
	if (bHoldWeapon == IsHoldWeapon) return;

	bHoldWeapon = IsHoldWeapon;

	// 如果强制显示武器的话挂点切换的时候刷新武器显示(时装隐藏 技能显示)
	if (bForceSkillShowWeapon)
	{
		if (!bHoldWeapon)
		{
			bForceSkillShowWeapon = false;
		}
	}

	// 更新武器挂接状态
	UpdateAllWeaponByRule(bSkipActiveWeaponVisible);

	// 更新玩家持武状态
	ABaseCharacter* Owner = GetOwner() ? Cast<ABaseCharacter>(GetOwner()) : nullptr;
	USkeletalMeshComponent* MainMesh = Owner ? Owner->GetMainMesh() : nullptr;
	if (MainMesh)
	{
		if (UBaseAnimInstance* AnimIns = Cast<UBaseAnimInstance>(MainMesh->GetAnimInstance()))
		{
			AnimIns->SetUseIdleFightABPVar(IsHoldWeapon);
		}
	}
}

void UWeaponManagerComponent::UpdateWeaponAttachState(FWeaponInfo& WeaponInfo, EWeaponAttachType AttachType)
{
	if (!WeaponInfo.WeaponActor || WeaponInfo.AttachType == AttachType) return;
	
	// 移除旧挂接关系
	bool bUseHoldWeaponSocket = AttachType == EWeaponAttachType::HoldAttach;
	if (WeaponInfo.AttachType != EWeaponAttachType::WaitAttach)
	{
		FWeaponAttachInfo& OldAttachInfo = bUseHoldWeaponSocket ? WeaponInfo.UnHoldWeaponInfo : WeaponInfo.HoldWeaponInfo;
		
		if (OldAttachInfo.bUnrealAttach)
		{
			WeaponInfo.WeaponActor->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
		}
		else if (UAttachJointComponent_V2* VirtualAttachComponent = GetAttachJointComponent())
		{
			VirtualAttachComponent->RemoveAttachment(OldAttachInfo.VirtualAttachInfo.AttachID);
			VirtualAttachComponent->RemoveAttachSocket(OldAttachInfo.VirtualAttachInfo.AttachVirtualSocketID);
		}
	}
	
	// 添加新挂接关系
	ExecuteWeaponAttach(WeaponInfo, bUseHoldWeaponSocket);
	// 更新挂接关系
	WeaponInfo.AttachType = AttachType;
}


void UWeaponManagerComponent::ExecuteWeaponAttach(FWeaponInfo& WeaponInfo, bool bUseHoldWeaponSocket)
{
	if (!WeaponInfo.WeaponActor) return;

	FWeaponAttachInfo& AttachInfo = bUseHoldWeaponSocket ? WeaponInfo.HoldWeaponInfo : WeaponInfo.UnHoldWeaponInfo;
	if (AttachInfo.bUnrealAttach)
	{
		ABaseCharacter* Owner = GetOwner() ? Cast<ABaseCharacter>(GetOwner()) : nullptr;
		USkeletalMeshComponent* MainMesh = Owner ? Owner->GetMainMesh() : nullptr;
		if (MainMesh)
		{
			FUnrealAttachInfo& UnrealAttachInfo = AttachInfo.UnrealAttachInfo;
			WeaponInfo.WeaponActor->K2_AttachToComponent(MainMesh, UnrealAttachInfo.AttachSocket, UnrealAttachInfo.LocRule, UnrealAttachInfo.RotRule,
				UnrealAttachInfo.ScaleRule, false);
			if (UnrealAttachInfo.LocRule != EAttachmentRule::KeepWorld)
			{
				WeaponInfo.WeaponActor->SetActorRelativeLocation(UnrealAttachInfo.RelLocation + UnrealAttachInfo.RelLocationAdd, false, nullptr, ETeleportType::None);
			}
			if (UnrealAttachInfo.RotRule != EAttachmentRule::KeepWorld)
			{
				WeaponInfo.WeaponActor->SetActorRelativeRotation(UnrealAttachInfo.RelRotation, false, nullptr, ETeleportType::None);	
			}
		} 
	}
	else if (UAttachJointComponent_V2* VirtualAttachComponent = GetAttachJointComponent())
	{
		FVirtualAttachInfo& VirtualAttachInfo = AttachInfo.VirtualAttachInfo;
		int64 AttachVirtualSocketID = ULowLevelFunctions::GetGlobalUniqueID();
		int64 AttachID = VirtualAttachComponent->AddAttachSocketByID(AttachVirtualSocketID, VirtualAttachInfo.AttachSocket, NAME_None,
			VirtualAttachInfo.RelLocation + VirtualAttachInfo.RelLocationAdd,VirtualAttachInfo.RelRotation,
			VirtualAttachInfo.SocketLocation, VirtualAttachInfo.SocketRotation, VirtualAttachInfo.bAbsoluteRotate);
		VirtualAttachComponent->AddAttachActor(WeaponInfo.WeaponActor, AttachVirtualSocketID, FTransform());

		// 位置模式
		if (ELocationUpdateMode(VirtualAttachInfo.LocationUpdateMode) == ELocationUpdateMode::Bezier)
		{
			VirtualAttachComponent->EnableAttachSocketLocationLagByBezier(AttachVirtualSocketID, VirtualAttachInfo.BezierStep, VirtualAttachInfo.BezierStepMaxDist, VirtualAttachInfo.BezierSpeedAlpha,
				VirtualAttachInfo.BezierLagSpeed, VirtualAttachInfo.BezierDirectionMultiplier);
		}
		else if (ELocationUpdateMode(VirtualAttachInfo.LocationUpdateMode) == ELocationUpdateMode::Bezier_WithInCircleLag)
		{
			VirtualAttachComponent->EnableAttachSocketLocationLagByBezierWithInCircleLag(AttachVirtualSocketID, VirtualAttachInfo.BezierStep, VirtualAttachInfo.BezierStepMaxDist, VirtualAttachInfo.BezierSpeedAlpha,
				VirtualAttachInfo.BezierLagSpeed, VirtualAttachInfo.BezierDirectionMultiplier, VirtualAttachInfo.InCircleLagSpeed, VirtualAttachInfo.InCircleLagTolerance);
		}

		// 旋转模式
		if (VirtualAttachInfo.bEnableAttachRotationLag)
		{
			VirtualAttachComponent->EnableAttachSocketAttachRotationLag(AttachVirtualSocketID, VirtualAttachInfo.AttachRotationLagSpeed, VirtualAttachInfo.bClampPitch, VirtualAttachInfo.PitchClampAngleMin,
				VirtualAttachInfo.PitchClampAngleMax, ERotationUpdateMode(VirtualAttachInfo.RotationUpdateMode), VirtualAttachInfo.FaceToMoveDirectionTolerance, VirtualAttachInfo.RotateRoundTime);
		}

		// 碰撞计算
		if (VirtualAttachInfo.bDoCollisionTest)
		{
			VirtualAttachComponent->EnableAttachSocketCollisionTest(AttachVirtualSocketID, VirtualAttachInfo.CollisionProbeSize, VirtualAttachInfo.CollisionChannels);
		}
		
		AttachInfo.VirtualAttachInfo.AttachVirtualSocketID = AttachVirtualSocketID;
		AttachInfo.VirtualAttachInfo.AttachID = AttachID;
	}

	// 更新武器状态
	if (USkeletalMeshComponent* MainMesh = WeaponInfo.WeaponActor->GetMainMesh())
	{
		if (UWeaponAnimInstance* AnimIns = Cast<UWeaponAnimInstance>(MainMesh->GetAnimInstance()))
		{
			AnimIns->SetUseIdleFightABPVar(bUseHoldWeaponSocket);
		}
	}
}

KGObjectID UWeaponManagerComponent::GetCurActiveMainWeaponCharacterID()
{
	TArray<int> CurWeaponList = GetCurActiveWeaponList();
	if (CurWeaponList.Num() > 0)
	{
		int WeaponID = CurWeaponList[0];
		FWeaponInfo* WeaponInfo = MapOfCreatedWeapon.Find(WeaponID);
		if (WeaponInfo && WeaponInfo->WeaponActor)
		{
			return KGUtils::GetIDByObject(WeaponInfo->WeaponActor);
		}
	}
	
	return KG_INVALID_ID;
}

KGObjectID UWeaponManagerComponent::GetActiveWeaponCharacterIDBySlot(int WeaponSlot)
{
	TArray<int> CurWeaponList = GetCurActiveWeaponList();
	for (const auto& WeaponID : CurWeaponList)
	{
		FWeaponInfo* WeaponInfo = MapOfCreatedWeapon.Find(WeaponID);
		if (WeaponInfo && WeaponInfo->InfoData.WeaponSlot == WeaponSlot && WeaponInfo->WeaponActor)
		{
			return KGUtils::GetIDByObject(WeaponInfo->WeaponActor);
		}
	}
	
	return KG_INVALID_ID;
}

KGObjectID UWeaponManagerComponent::GetCurActiveMainWeaponSkeletalMeshID()
{
	TArray<int> CurWeaponList = GetCurActiveWeaponList();
	if (CurWeaponList.Num() > 0)
	{
		int WeaponID = CurWeaponList[0];
		FWeaponInfo* WeaponInfo = MapOfCreatedWeapon.Find(WeaponID);
		if (WeaponInfo && WeaponInfo->WeaponActor)
		{
			return KGUtils::GetIDByObject(WeaponInfo->WeaponActor->GetMainMesh());
		}
	}
	return KG_INVALID_ID;
}

KGObjectID UWeaponManagerComponent::GetActiveWeaponSkeletalMeshIDBySlot(int WeaponSlot)
{
	TArray<int> CurWeaponList = GetCurActiveWeaponList();
	for (const auto& WeaponID : CurWeaponList)
	{
		FWeaponInfo* WeaponInfo = MapOfCreatedWeapon.Find(WeaponID);
		if (WeaponInfo && WeaponInfo->InfoData.WeaponSlot == WeaponSlot && WeaponInfo->WeaponActor)
		{
			return KGUtils::GetIDByObject(WeaponInfo->WeaponActor->GetMainMesh());
		}
	}
	
	return KG_INVALID_ID;
}


void UWeaponManagerComponent::GetWeaponActors(TArray<AActor*>& OutAttachActors)
{
	for (auto& WeaponInfo : MapOfCreatedWeapon)
	{
		FWeaponInfo& Value = WeaponInfo.Value;
		if (Value.WeaponActor)
		{
			OutAttachActors.Add(Value.WeaponActor);
		}
	}
}

void UWeaponManagerComponent::PlayWeaponAnimationByID(const FString& AnimID, const FName& AnimSlotName, float BlendInTime, float BlendOutTime)
{
	UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(this);
	if (!ActorManager) return;
	
	IC7ActorInterface* Actor = Cast<IC7ActorInterface>(GetOwner());
	if (!Actor) return;
	
	ICppEntityInterface* ActorInterface = ActorManager->GetLuaEntity(Actor->GetEntityUID());
	USkeletalMeshComponent* MainMesh = Actor->GetMainMesh();
	if (!ActorInterface || !MainMesh) return;

	TArray<int> CurWeaponList = GetCurActiveWeaponList();

	// 武器播放收刀动画
	for (auto& WeaponID : CurWeaponList)
	{
		FWeaponInfo* TempWeaponInfo = MapOfCreatedWeapon.Find(WeaponID);
		if (!TempWeaponInfo || !TempWeaponInfo->WeaponActor) continue;

		USkeletalMeshComponent* WeaponMainMesh = TempWeaponInfo->WeaponActor->GetMainMesh();
		if (!WeaponMainMesh) continue;
		
		FString AnimPath = "";
		if (AnimID != "")
		{
			if (UWeaponAnimInstance* WeaponAnimIns = Cast<UWeaponAnimInstance>(WeaponMainMesh->GetAnimInstance()))
			{
				AnimPath = WeaponAnimIns->GetWeaponAnimPathByID(AnimID);
			}
		}
		else
		{
			AnimPath = TempWeaponInfo->InfoData.WeaponFightToIdleAnimPath;
		}

		if (AnimPath != "")
		{
			KGObjectID WeaponMeshID = KGUtils::GetIDByObject(WeaponMainMesh);
			TempWeaponInfo->WeaponPlayAnimID = ActorInterface->KAPI_Animation_PlayAnimation(WeaponMeshID, 0, AnimPath, AnimSlotName, false, true, BlendInTime, BlendOutTime);
		}
	}
}

void UWeaponManagerComponent::StopWeaponAnimation(float BlendOutTime)
{
	UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(this);
	if (!ActorManager) return;
	
	IC7ActorInterface* Actor = Cast<IC7ActorInterface>(GetOwner());
	if (!Actor) return;
	
	ICppEntityInterface* ActorInterface = ActorManager->GetLuaEntity(Actor->GetEntityUID());
	if (!ActorInterface) return;
	
	TArray<int> CurWeaponList = GetCurActiveWeaponList();
	for (auto& WeaponID : CurWeaponList)
	{
		FWeaponInfo* TempWeaponInfo = MapOfCreatedWeapon.Find(WeaponID);
		if (!TempWeaponInfo || !TempWeaponInfo->WeaponActor) continue;

		if (TempWeaponInfo->WeaponPlayAnimID != 0)
		{
			ActorInterface->KAPI_Animation_StopAnimation(TempWeaponInfo->WeaponPlayAnimID, BlendOutTime);
			TempWeaponInfo->WeaponPlayAnimID = 0;
		}
	}
}

void UWeaponManagerComponent::ResetToDefaultsForCache()
{
	bHoldWeapon = false;
	bShowWeapon = true;
	MapOfWeaponGroupToTypeToID.Empty();
	MapOfGroupToType.Empty();
	ActiveWeaponGroupArray.Empty();

	if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this))
	{
		for (auto& Iter: AssetLoadMap)
		{
			AssetManager->CancelAsyncLoadByLoadID(Iter.Value);
		}
		AssetLoadMap.Empty();
	}

	for (auto& WeaponInfo : MapOfCreatedWeapon)
	{
		FWeaponInfo& Value = WeaponInfo.Value;
		if (Value.WeaponActor)
		{
			Value.WeaponActor->RemoveAttachFromLogicParent();
			Value.WeaponActor->SetActorHiddenInGame(true);
			Value.WeaponActor->Destroy();
			Value.WeaponActor = nullptr;
		}
	}
	MapOfCreatedWeapon.Empty();
	StopTimerOfDelayDissolveWeapon();
}

UAttachJointComponent_V2* UWeaponManagerComponent::GetAttachJointComponent()
{
	UAttachJointComponent_V2* AttachComponent = nullptr;
	if (AActor* Actor = GetOwner())
	{
		AttachComponent = Actor->GetComponentByClass<UAttachJointComponent_V2>();
		if (!AttachComponent)
		{
			AttachComponent = Cast<UAttachJointComponent_V2>(Actor->AddComponentByClass(UAttachJointComponent_V2::StaticClass(), false, FTransform::Identity, false));
		}
	}

	return AttachComponent;
}

void UWeaponManagerComponent::OnWeaponActorClassLoaded(int InLoadID, UObject* LoadedAsset, int WeaponID)
{
	AssetLoadMap.Remove(WeaponID);
	FWeaponInfo* WeaponInfo = MapOfCreatedWeapon.Find(WeaponID);
	if (!WeaponInfo) return;

	if (!LoadedAsset)
	{
		UE_LOG(LogTemp, Warning, TEXT("UWeaponManagerComponent::OnWeaponActorClassLoaded	LoadedAsset is nullptr ActorClass:%s"), *WeaponInfo->ActorClass);
		return;
	}
	
	UClass* ActorClass = Cast<UClass>(LoadedAsset);
	if (!ActorClass || !ActorClass->IsChildOf(ASeerAttachActor::StaticClass()))
	{
		UE_LOG(LogTemp, Warning, TEXT("UWeaponManagerComponent::OnWeaponActorClassLoaded	ActorClass is not ASeerAttachActor"));
		return;
	}
	WeaponInfo->WeaponActor = GetWorld()->SpawnActor<ASeerAttachActor>(ActorClass);
	if (!WeaponInfo->WeaponActor)
	{
		MapOfCreatedWeapon.Remove(WeaponID);
		UE_LOG(LogTemp, Warning, TEXT("UWeaponManagerComponent::OnWeaponActorClassLoaded	WeaponActor Created Failed"));
		return;
	}

	// 同步关系设置
	if (IC7ActorInterface* Interface = Cast<IC7ActorInterface>(WeaponInfo->WeaponActor))
	{
		KGObjectID ParentActorID = KGUtils::GetIDByObject(this->GetOwner());
		Interface->AddAttachToLogicParent(ParentActorID);
	}
			
	if (ABaseCharacter* ParentCharacter = Cast<ABaseCharacter>(GetOwner()))
	{
		if (auto* ParentEntity = UKGUEActorManager::GetLuaEntityByActor(ParentCharacter))
		{
			ParentEntity->SyncEffectToChildActor(WeaponInfo->WeaponActor);
		}
	}
	
	// 更新武器状态
	UpdateAllWeaponByRule();
}

void UWeaponManagerComponent::DeleteWeaponByID(int WeaponID)
{
	FWeaponInfo* SubWeaponInfo = MapOfCreatedWeapon.Find(WeaponID);
	if (SubWeaponInfo && SubWeaponInfo->WeaponActor)
	{
		SubWeaponInfo->WeaponActor->RemoveAttachFromLogicParent();
		SubWeaponInfo->WeaponActor->SetActorHiddenInGame(true);
		SubWeaponInfo->WeaponActor->Destroy();
		SubWeaponInfo->WeaponActor = nullptr;
	}
	MapOfCreatedWeapon.Remove(WeaponID);
	AssetLoadMap.Remove(WeaponID);
}

TArray<int> UWeaponManagerComponent::GetCurActiveWeaponList()
{
	TArray<int> WeaponList;

	int CurActiveWeaponGroup = GetCurActiveWeaponGroup();
	if (CurActiveWeaponGroup != -1)
	{
		WeaponList = GetSpecialWeaponList(CurActiveWeaponGroup);
	}
	
	return WeaponList;
}

TArray<int> UWeaponManagerComponent::GetSpecialWeaponList(int WeaponGroup)
{
	TArray<int> WeaponList;
	
	TMap<Type_WeaponType, ID_WeaponID>* TypeToID = MapOfWeaponGroupToTypeToID.Find(WeaponGroup);
	Type_WeaponType* WeaponType = MapOfGroupToType.Find(WeaponGroup);
	if (TypeToID && WeaponType && TypeToID->Contains(*WeaponType))
	{
		int MainWeaponID = (*TypeToID)[*WeaponType];
		WeaponList.Add(MainWeaponID);

		FWeaponInfo* WeaponInfo = MapOfCreatedWeapon.Find(MainWeaponID);
		if (WeaponInfo && WeaponInfo->InfoData.SubWeapons.Num() > 0)
		{
			for (auto& SubID : WeaponInfo->InfoData.SubWeapons)
			{
				WeaponList.Add(SubID);
			}
		}	
	}
	
	return WeaponList;
}

TArray<int> UWeaponManagerComponent::GetWeaponGroupWeaponList(int WeaponGroup)
{
	TArray<int> WeaponList;

	for (auto& Iter : MapOfCreatedWeapon)
	{
		FWeaponInfo& WeaponInfo = Iter.Value;
		if (WeaponInfo.WeaponGroup == WeaponGroup)
		{
			WeaponList.Add(WeaponInfo.InfoData.WeaponID);
		}
	}
	
	return WeaponList;
}


// Called when the game starts
void UWeaponManagerComponent::BeginPlay()
{
	Super::BeginPlay();

	ABaseCharacter* Owner = GetOwner() ? Cast<ABaseCharacter>(GetOwner()) : nullptr;
	if (URoleMovementComponent *Movement = Cast<URoleMovementComponent>(Owner->GetComponentByClass(URoleMovementComponent::StaticClass())))
	{
		Movement->OnLeaveDefaultLocoState.AddDynamic(this, &UWeaponManagerComponent::OnLocoMoveStart);
	}
}

void UWeaponManagerComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
	ResetToDefaultsForCache();

	ABaseCharacter* Owner = GetOwner() ? Cast<ABaseCharacter>(GetOwner()) : nullptr;
	if (URoleMovementComponent *Movement = Cast<URoleMovementComponent>(Owner->GetComponentByClass(URoleMovementComponent::StaticClass())))
	{
		Movement->OnLeaveDefaultLocoState.RemoveDynamic(this, &UWeaponManagerComponent::OnLocoMoveStart);
	}
}

void UWeaponManagerComponent::OnLocoMoveStart()
{
	StopTimerOfDelayDissolveWeapon();

	StopFightToIdleAnim();

	if (bHoldWeapon)
	{
		PlayDissolveEffect(false);
	
		UpdateHoldWeaponState(false, true);

		PlayDissolveEffect(true);	
	}
}

void UWeaponManagerComponent::PlayDissolveEffect(bool bVisible)
{
	SetWeaponDissolveEffectWithDefaultID(bVisible);
}

FWeaponTypeData* UWeaponManagerComponent::GetWeaponTypeData(int WeaponType)
{
	FWeaponTypeData* WeaponTypeData = nullptr;
	
	UKGDataCacheManager* DataCacheMgr = UKGDataCacheManager::GetInstance(this);
	if (!DataCacheMgr)
	{
		UE_LOG(LogTemp, Warning, TEXT("UWeaponManagerComponent::GetWeaponTypeData get UKGDataCacheManager failed"));
		return WeaponTypeData;
	}

	WeaponTypeData = DataCacheMgr->GetWeaponTypeData(WeaponType);
	return WeaponTypeData;
}

void UWeaponManagerComponent::OnSkillStartHoldWeapon(float DelayHideWeaponTime)
{
	if (bEnablePlayUnHoldWeaponAnim)
	{
		StopFightToIdleAnim();	// 停掉收刀动画
	}
	StopTimerOfDelayDissolveWeapon();
	UpdateHoldWeaponState(true);

	if (DelayHideWeaponTime > 0)
	{
		if (UWorld* World = GetWorld())
		{
			World->GetTimerManager().SetTimer(TimerHandleOfDelayDissolveWeapon, FTimerDelegate::CreateUObject(this, &UWeaponManagerComponent::DelayDissolveWeapon, false), DelayHideWeaponTime, false);	
		}
	}
}

void UWeaponManagerComponent::DelayDissolveWeapon(bool bVisible)
{
	PlayDissolveEffect(bVisible);
}

void UWeaponManagerComponent::OnFightToIdleDelayFadeOutWeapon(float DelayShowTime)
{
	// 溶解
	PlayDissolveEffect(false);
	// 切换挂点
	UpdateHoldWeaponState(false, true);
	// 延迟显示
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().SetTimer(TimerHandleOfDelayDissolveWeapon, FTimerDelegate::CreateUObject(this, &UWeaponManagerComponent::DelayDissolveWeapon, true), DelayShowTime/1000, false);	
	}
}

void UWeaponManagerComponent::ForceSkillShowWeapon()
{
	bForceSkillShowWeapon = true;
}

void UWeaponManagerComponent::SetForceHoldWeapon(bool bForce)
{
	bForceHoldWeapon = bForce;
}

void UWeaponManagerComponent::OnSkillEndUpdateWeapon(bool bMoveStop, bool bHold, bool bWeaponNeedFadeIn, bool bEndToCommonIdle, float DelayShowWeaponTime)
{
	UWorld* World = GetWorld();
	if (!World) return;
	
	ABaseCharacter* Owner = GetOwner() ? Cast<ABaseCharacter>(GetOwner()) : nullptr;
	USkeletalMeshComponent* MainMesh = Owner ? Owner->GetMainMesh() : nullptr;
	UBaseAnimInstance* AnimIns = MainMesh ? Cast<UBaseAnimInstance>(MainMesh->GetAnimInstance()) : nullptr;
	if (!AnimIns) return;
	
	if (bWeaponNeedFadeIn)
	{
		PlayDissolveEffect(true);
	}
	
	if (bHold || bMoveStop) return;
	
	const bool bIsALSMode = AnimIns->bIsALSMode;
	if (bIsALSMode)
	{
		OnLocoMoveStart();
	}
	else
	{
		if (bEndToCommonIdle || !bEnablePlayUnHoldWeaponAnim)
		{
			if (DelayShowWeaponTime > 0)
			{
				World->GetTimerManager().SetTimer(TimerHandleOfDelayDissolveWeapon, FTimerDelegate::CreateUObject(this, &UWeaponManagerComponent::DelayDissolveWeapon, true), DelayShowWeaponTime, false);
			}
			
			UpdateHoldWeaponState(false);
		}
		else
		{
			// 延迟收武器
			World->GetTimerManager().SetTimer(TimerHandleOfDelayDissolveWeapon, FTimerDelegate::CreateUObject(this, &UWeaponManagerComponent::DelayPlayUnHoldWeaponAnim), 3, false);
		}
	}
}

void UWeaponManagerComponent::DelayPlayUnHoldWeaponAnim()
{
	TArray<int> CurWeaponList = GetCurActiveWeaponList();
	if (CurWeaponList.Num() == 0) return;

	FWeaponInfo* WeaponInfo = MapOfCreatedWeapon.Find(CurWeaponList[0]);
	if (!WeaponInfo) return;
	
	UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(this);
	if (!ActorManager) return;
	
	IC7ActorInterface* Actor = Cast<IC7ActorInterface>(GetOwner());
	if (!Actor) return;
	
	ICppEntityInterface* ActorInterface = ActorManager->GetLuaEntity(Actor->GetEntityUID());
	USkeletalMeshComponent* MainMesh = Actor->GetMainMesh();
	if (!ActorInterface || !MainMesh) return;

	KGObjectID PlayerMeshID = KGUtils::GetIDByObject(MainMesh);

	FName AnimSlot = C7ThreeLayerAnimationConst::ACTION_LAYER_SLOT;
	// 玩家播放收刀动画
	PlayerFightToIdleAnimID = ActorInterface->KAPI_Animation_PlayAnimation(PlayerMeshID, 0, WeaponInfo->FightToIdleAnimPath, AnimSlot, false, true);
	// 定时溶解
	if (UWorld* World = GetWorld())
	{
		float DelayShowTime = WeaponInfo->InfoData.AppearStartTime - WeaponInfo->InfoData.DisappearStartTime;
		World->GetTimerManager().SetTimer(TimerHandleOfDelayDissolveWeapon, FTimerDelegate::CreateUObject(this, &UWeaponManagerComponent::OnFightToIdleDelayFadeOutWeapon, DelayShowTime), WeaponInfo->InfoData.DisappearStartTime/1000, false);	
	}
	
	// 武器播放收刀动画
	PlayWeaponAnimationByID("", AnimSlot, 0.2, 0.2);
}

void UWeaponManagerComponent::StopFightToIdleAnim()
{
	UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(this);
	if (!ActorManager) return;

	// 停掉玩家收刀动画
	if (PlayerFightToIdleAnimID != 0)
	{
		IC7ActorInterface* Actor = Cast<IC7ActorInterface>(GetOwner());
		if (!Actor) return;
	
		ICppEntityInterface* ActorInterface = ActorManager->GetLuaEntity(Actor->GetEntityUID());
		if (!ActorInterface) return;
		
		// 玩家播放收刀动画
		ActorInterface->KAPI_Animation_StopAnimation(PlayerFightToIdleAnimID);

		PlayerFightToIdleAnimID = 0;
	}

	// 停掉武器收刀动画
	StopWeaponAnimation(-1.f);
}

void UWeaponManagerComponent::StopTimerOfDelayDissolveWeapon()
{
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(TimerHandleOfDelayDissolveWeapon);
	}
}

void UWeaponManagerComponent::UpdateWeaponUnHoldOffset(int WeaponID, float RelX, float RelY, float RelZ)
{
	FWeaponInfo* WeaponInfo = MapOfCreatedWeapon.Find(WeaponID);
	if (!WeaponInfo) return;

	FWeaponAttachInfo& AttachInfo = WeaponInfo->UnHoldWeaponInfo;
	if (AttachInfo.bUnrealAttach)
	{
		FVector RelLocationAdd = FVector(RelX, RelY, RelZ);
		
		ABaseCharacter* Owner = GetOwner() ? Cast<ABaseCharacter>(GetOwner()) : nullptr;
		USkeletalMeshComponent* MainMesh = Owner ? Owner->GetMainMesh() : nullptr;
		if (MainMesh)
		{
			FTransform BoneTrans = MainMesh->GetBoneTransform(AttachInfo.UnrealAttachInfo.AttachSocket);

			// 位置偏移：先转角色坐标系，再转骨坐标系
			RelLocationAdd = Owner->GetActorRotation().RotateVector(RelLocationAdd);
			RelLocationAdd = BoneTrans.InverseTransformVector(RelLocationAdd);
		}
		
		AttachInfo.UnrealAttachInfo.RelLocationAdd = RelLocationAdd;

		if (WeaponInfo->AttachType == EWeaponAttachType::UnHoldAttach && WeaponInfo->WeaponActor)
		{
			if (AttachInfo.UnrealAttachInfo.LocRule != EAttachmentRule::KeepWorld)
			{
				WeaponInfo->WeaponActor->SetActorRelativeLocation(AttachInfo.UnrealAttachInfo.RelLocation + AttachInfo.UnrealAttachInfo.RelLocationAdd, false, nullptr, ETeleportType::None);
			}
			if (AttachInfo.UnrealAttachInfo.RotRule != EAttachmentRule::KeepWorld)
			{
				WeaponInfo->WeaponActor->SetActorRelativeRotation(AttachInfo.UnrealAttachInfo.RelRotation, false, nullptr, ETeleportType::None);	
			}
		}
	}
	else
	{
		AttachInfo.VirtualAttachInfo.RelLocationAdd = FVector(RelX, RelY, RelZ);

		if (WeaponInfo->AttachType == EWeaponAttachType::UnHoldAttach && WeaponInfo->WeaponActor)
		{
			if (UAttachJointComponent_V2* VirtualAttachComponent = GetAttachJointComponent())
			{
				VirtualAttachComponent->ModifyAttachSocket(AttachInfo.VirtualAttachInfo.AttachVirtualSocketID, AttachInfo.VirtualAttachInfo.AttachSocket, NAME_None,
					AttachInfo.VirtualAttachInfo.RelLocation + AttachInfo.VirtualAttachInfo.RelLocationAdd,AttachInfo.VirtualAttachInfo.RelRotation,
					AttachInfo.VirtualAttachInfo.SocketLocation, AttachInfo.VirtualAttachInfo.SocketRotation);
			}
		}
	}
}

void UWeaponManagerComponent::AppendDebugInfo(FString& infoOut)
{
	infoOut.Append(TEXT("===================<Title_Blue>UWeaponManagerComponent</>===================\n"));
	infoOut.Appendf(TEXT("bShowWeapon:%d	bHoldWeapon:%d	bForceHoldWeapon:%d  bForceSkillShowWeapon:%d  bEnablePlayUnHoldWeaponAnim:%d\n"),
		bShowWeapon, bHoldWeapon, bForceHoldWeapon, bForceSkillShowWeapon, bEnablePlayUnHoldWeaponAnim);

	// 当前激活武器组信息
	FString ActiveWeaponGroupArrayStr = "";
	for (auto WeaponGroup : ActiveWeaponGroupArray)
	{
		ActiveWeaponGroupArrayStr.Appendf(TEXT("WeaponGroup:%d  "), WeaponGroup);
	}
	infoOut.Appendf(TEXT("ActiveWeaponGroup:	Num:%d	Detail:	%s\n"), ActiveWeaponGroupArray.Num(), *ActiveWeaponGroupArrayStr);
	
	// 每个武器组对应激活的武器类型
	FString MapOfGroupToTypeStr = "";
	for (auto GroupToType : MapOfGroupToType)
	{
		MapOfGroupToTypeStr.Appendf(TEXT("Group:%d  WeaponType:%d	"), GroupToType.Key, GroupToType.Value);
	}
	infoOut.Appendf(TEXT("MapOfGroupToType:	Num:%d	Detail:	%s\n"), MapOfGroupToType.Num(), *MapOfGroupToTypeStr);

	// 每个武器对应的类型下激活的ID
	FString MapOfWeaponGroupToTypeToIDStr = "";
	for (auto& GroupToTypeID : MapOfWeaponGroupToTypeToID)
	{
		Type_WeaponGroup WeaponGroup = GroupToTypeID.Key;
		for (auto& TypeToID : GroupToTypeID.Value)
		{
			Type_WeaponType WeaponType = TypeToID.Key;
			ID_WeaponID WeaponID = TypeToID.Value;

			MapOfWeaponGroupToTypeToIDStr.Appendf(TEXT("WeaponGroup:%d WeaponType:%d WeaponID:%d、"), WeaponGroup, WeaponType, WeaponID);
		}
	}
	infoOut.Appendf(TEXT("MapOfWeaponGroupToTypeToID:	Detail:	%s\n"), *MapOfWeaponGroupToTypeToIDStr);

	// 武器详细信息
	for (auto& Iter : MapOfCreatedWeapon)
	{
		const FWeaponInfo& WeaponInfo = Iter.Value;
		FString SubWeapon = "";
		for (auto& SubID : WeaponInfo.InfoData.SubWeapons)
		{
			SubWeapon.Appendf(TEXT("SubID:%d  "), SubID);
		}

		// 挂点信息
		FName HoldWeaponSocket = WeaponInfo.HoldWeaponInfo.bUnrealAttach ? WeaponInfo.HoldWeaponInfo.UnrealAttachInfo.AttachSocket : WeaponInfo.HoldWeaponInfo.VirtualAttachInfo.AttachSocket;
		FName UnHoldWeaponSocket = WeaponInfo.UnHoldWeaponInfo.bUnrealAttach ? WeaponInfo.UnHoldWeaponInfo.UnrealAttachInfo.AttachSocket : WeaponInfo.UnHoldWeaponInfo.VirtualAttachInfo.AttachSocket;
		
		infoOut.Appendf(TEXT("WeaponInfo:WeaponGroup:%d  WeaponType:%d  WeaponID:%d  WeaponSlot:%d  WeaponModelID:%s  SubWeapon:%s  "
					   "HoldWeaponSocket:%s  UnHoldWeaponSocket:%s  WeaponVisibleRule:%d  WeaponAttachRule:%d  AttachType:%d\n"),
			WeaponInfo.WeaponGroup, WeaponInfo.InfoData.WeaponType, WeaponInfo.InfoData.WeaponID, WeaponInfo.InfoData.WeaponSlot, *WeaponInfo.InfoData.ModelID, *SubWeapon,
			*HoldWeaponSocket.ToString(), *UnHoldWeaponSocket.ToString(), WeaponInfo.WeaponVisibleRule, WeaponInfo.WeaponAttachRule, WeaponInfo.AttachType);
	}
}

