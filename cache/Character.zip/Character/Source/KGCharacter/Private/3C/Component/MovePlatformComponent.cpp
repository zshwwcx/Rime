// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Component/MovePlatformComponent.h"

#include "Manager/KGObjectActorManager.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "3C/Controller/BasePlayerController.h"
#include "Components/CapsuleComponent.h"


UMovePlatformComponent::UMovePlatformComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	SetTickGroup(TG_PostUpdateWork);
}

void UMovePlatformComponent::BeginPlay()
{
	Super::BeginPlay();
}

void UMovePlatformComponent::TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	UKGObjectActorManager * ObjectActorMgr = UKGObjectActorManager::GetInstance(this);
	if(!ObjectActorMgr)
	{
		UE_LOG(LogTemp, Warning, TEXT("[UMovePlatformComponent::TickComponent] Cannot Get UKGObjectActorManager"));
		return;
	}
	
	AActor * OuterActor = GetOwner();
	if(!OuterActor)
	{
		UE_LOG(LogTemp, Warning, TEXT("[UMovePlatformComponent::TickComponent] Cannot Get GetOwner()"));
		return;
	}

	// ============================1.进行非法位置的修正处理=======================================================
	if(IsUsingPositionCorrectionWithinInnerSafeArea)
	{
		DurationForCorrectToSafePosition +=DeltaTime;
		TSet<ABaseCharacter*> WaitCorrectedChar;
		if(DurationForCorrectToSafePosition > TimeForCorrectToSafePosition)
		{
			DurationForCorrectToSafePosition = 0.0f;
			
			TArray<AActor*> ActorsToIgnore;
			TArray<FHitResult> OutHits;
			FTransform MovePlatformTrans = OuterActor->GetActorTransform();
			FVector DetectedInteractablePos = MovePlatformTrans.TransformPositionNoScale(InnerSafeCenter);
			UKismetSystemLibrary::BoxTraceMultiForObjects(
				GetWorld(),
				DetectedInteractablePos,
				DetectedInteractablePos + FVector(0,0, -50),
				InnerSafeDetectBox,
				MovePlatformTrans.GetRotation().Rotator(),
				PositionCorrectionDetectObjectTypes,
				false,
				ActorsToIgnore,
				EDrawDebugTrace::None,
				OutHits,
				true
			);

			for (auto& HitResult : OutHits)
			{
				if (HitResult.Component.IsValid())
				{
					if(ABaseCharacter * DetectedChar = Cast<ABaseCharacter>(HitResult.Component->GetOwner()))
					{
						WaitCorrectedChar.Add(DetectedChar);
					}
				}
			}
		
		
			if(WaitCorrectedChar.Num() > 0)
			{
				for(auto CharPtr: WaitCorrectedChar)
				{
					if(!CharPtr)
					{
						continue;	
					}
					FVector CurrentCharTranslation = CharPtr->GetActorTransform().GetLocation();
					FVector CharPositionRelativeToPlatform = MovePlatformTrans.InverseTransformPositionNoScale(CurrentCharTranslation);
					float CharRadius = CharPtr->GetCapsule()->GetScaledCapsuleRadius();
					// 进行Y轴上的移动修正, 如果玩家之前是在Y轴的正方向, 就往Y轴正方向修正；反之同理,  保障使用最小距离往平台外部修正
					if(CharPositionRelativeToPlatform.Y  < 0)
					{
						CharPositionRelativeToPlatform.Y = -(MovePlatformExtendBox.Y + CharRadius);
					}
					else
					{
						CharPositionRelativeToPlatform.Y = (MovePlatformExtendBox.Y + CharRadius);
					}
					
					FVector SafeInnerWorldPosition = MovePlatformTrans.TransformPositionNoScale(CharPositionRelativeToPlatform);
			
					FVector FinalCharPosition = CharPtr->SimpleGetStickGroundLocationFromSpecificLocation(SafeInnerWorldPosition);
					CharPtr->SetActorLocation(FinalCharPosition);
				}
			}
		}
	}

	// ============================2.进行推挤修正处理=======================================================
	const float MINIMAL_MOVE_VELOCITY_TO_PUSH = 10;
	FVector MovePlatformVelocity = OuterActor->GetVelocity();
	// 速度太小, 可以不用探测
	if(IsUsingSafeAreaPush && !PushDetectObjectTypes.IsEmpty() && MovePlatformVelocity.Length() > MINIMAL_MOVE_VELOCITY_TO_PUSH)
	{
		bool IsReverseMove = OuterActor->GetActorForwardVector().Dot(MovePlatformVelocity) < 0.0f;
		DetectDuration += DeltaTime;

		if(DetectDuration >= DetectTickTime)
		{
			DetectDuration = 0.0f;
			TArray<AActor*> ActorsToIgnore;
			TArray<FHitResult> OutHits;
			FTransform MovePlatformTrans = OuterActor->GetActorTransform();
			FVector RealPlatformPushCenter = PlatformPushCenter;
			if(IsReverseMove)
			{
				RealPlatformPushCenter.X = -RealPlatformPushCenter.X;
			}
			
			FVector DetectedInteractablePos = MovePlatformTrans.TransformPositionNoScale(RealPlatformPushCenter);
			FVector CurrentVel = OuterActor->GetVelocity();
			UKismetSystemLibrary::BoxTraceMultiForObjects(
				GetWorld(),
				DetectedInteractablePos,
				DetectedInteractablePos + CurrentVel * DetectDuration,
				PlatformPushAreaBox,
				MovePlatformTrans.GetRotation().Rotator(),
				PushDetectObjectTypes,
				false,
				ActorsToIgnore,
				EDrawDebugTrace::None,
				OutHits,
				true
			);

			for (auto& HitResult : OutHits)
			{
				if (HitResult.Component.IsValid())
				{
					if(ABaseCharacter * DetectedChar = Cast<ABaseCharacter>(HitResult.Component->GetOwner()))
					{
						CharactersPushedToSafeArea.Emplace(DetectedChar, 0.0);
					}
				}
			}
		}
		
	
		if(CharactersPushedToSafeArea.Num() > 0 && MovePlatformVelocity.Length() > MINIMAL_MOVE_VELOCITY_TO_PUSH)
		{
			
			FTransform MovePlatformTrans = OuterActor->GetActorTransform();
			TArray<TWeakObjectPtr<ABaseCharacter>> NeedRemoveChars;
			for(auto & CharItem:CharactersPushedToSafeArea)
			{
				const auto& CharWeakPtr = CharItem.Key;
				if(!CharWeakPtr.IsValid())
				{
					NeedRemoveChars.Add(CharWeakPtr);
					continue;
				}

				CharItem.Value += DeltaTime;
				if(CharItem.Value >PushContinueTime)
				{
					NeedRemoveChars.Add(CharWeakPtr);
					continue;
				}

				
				
				if(URoleMovementComponent* RoleMC = Cast<URoleMovementComponent>(CharWeakPtr->GetCharacterMoveComp()))
				{

					FVector CharPosition = CharWeakPtr->GetActorLocation();
					FVector CharPositionRelativeToPlatform = MovePlatformTrans.InverseTransformPositionNoScale(CharPosition);

					float CharRadius = CharWeakPtr->GetCapsule()->GetScaledCapsuleRadius();
					// 严格修正到整体平台逻辑体积外部, 直接修正到侧面
					if(fabs(CharPositionRelativeToPlatform.X) < (MovePlatformExtendBox.X - CharRadius / 2.0f))
					{
						CharPositionRelativeToPlatform.Y = (MovePlatformExtendBox.Y + CharRadius) * FMath::Sign(CharPositionRelativeToPlatform.Y);
						FVector SafeOuterWorldPosition = MovePlatformTrans.TransformPositionNoScale(CharPositionRelativeToPlatform);
			
						FVector FinalCharPosition = CharWeakPtr->SimpleGetStickGroundLocationFromSpecificLocation(SafeOuterWorldPosition);
						CharWeakPtr->SetActorLocation(FinalCharPosition);
						continue;
					}

					FVector CharVelocity = RoleMC->GetMovementVelocity();
					FVector CharVelocityInPlatformSpace = MovePlatformTrans.InverseTransformVectorNoScale(CharVelocity);
					FVector MovePlatformVelocityInPlatformSpace = MovePlatformTrans.InverseTransformVectorNoScale(MovePlatformVelocity);
				
					
					// 速度同向, 且玩家速度可以逃逸车的速度, 不处理
					bool IsSameXDirection = MovePlatformVelocityInPlatformSpace.X * CharVelocityInPlatformSpace.X > 0;
					// 只要不能逃逸, 就要用车的X速度座位forward速度
					FVector LocalVelocity{0, CharVelocityInPlatformSpace.Y, 0};

					if(IsSameXDirection)
					{
						LocalVelocity.X = FMath::Max(FMath::Abs(MovePlatformVelocityInPlatformSpace.X),FMath::Abs(CharVelocityInPlatformSpace.X)) * FMath::Sign(MovePlatformVelocityInPlatformSpace.X);
					}
					else
					{
						LocalVelocity.X = MovePlatformVelocityInPlatformSpace.X;
					}
					
					// 直接进行侧向的滑动速度增加, 进行逃离
					if(LocalVelocity.Y >= 0)
					{
						LocalVelocity.Y = FMath::Max(PushSpeed,  LocalVelocity.Y);
					}
					else
					{
						LocalVelocity.Y = FMath::Min(-PushSpeed, LocalVelocity.Y) ;
					}

					// 移动要抵消掉之前的相对移动, 然后再加上Y上的横移偏移
					FVector FinalWorldPushVelocity = MovePlatformTrans.TransformVectorNoScale(LocalVelocity);
					RoleMC->ProduceReplacedFinalWorldPosDelta(FinalWorldPushVelocity*DeltaTime, true, true, false);
					
				
				}
			}

			if(NeedRemoveChars.Num() > 0){
				for(auto &CharKey:NeedRemoveChars)
				{
					CharactersPushedToSafeArea.Remove(CharKey);
				}
			}
		}
	}

	
}

void UMovePlatformComponent::StartPositionCorrectionWithinInnerSafeArea(
	float TimeToCorrection, float XPlatformExtent, float YPlatformExtent, float ZPlatformExtent,
	float XCenter, float YCenter, float ZCenter, float XExtent, float YExtent, float ZExtent, TArray<int32> InDetectObjectTypes)
{
	TimeForCorrectToSafePosition = TimeToCorrection;
	DurationForCorrectToSafePosition = TimeToCorrection;
	FVector Scale{1, 1, 1};
	AActor * Owner = GetOwner();
	if(Owner)
	{
		Scale = GetOwner()->GetActorScale3D();
	};
	MovePlatformExtendBox.Set(XPlatformExtent*Scale.X, YPlatformExtent*Scale.Y, ZPlatformExtent*Scale.Z);
	InnerSafeDetectBox.Set(XExtent*Scale.X, YExtent*Scale.Y, ZExtent*Scale.Z);
	InnerSafeCenter.Set(XCenter, YCenter, ZCenter);
	IsUsingPositionCorrectionWithinInnerSafeArea = true;
	for (int32 ObjectTypeInt: InDetectObjectTypes)
	{
		PositionCorrectionDetectObjectTypes.Add(TEnumAsByte<EObjectTypeQuery>(ObjectTypeInt));
	}
}

void UMovePlatformComponent::StopPositionCorrectionWithinInnerSafeArea()
{
	IsUsingPositionCorrectionWithinInnerSafeArea = false;
};




void UMovePlatformComponent::StartSafeAreaPush(float TickTime, float Speed, float CenterX, float CenterY, float CenterZ, float XExtent, float YExtent, float ZExtent, TArray<int32> InDetectObjectTypes)
{
	FVector Scale{1, 1, 1};
	if(GetOwner())
	{
		Scale = GetOwner()->GetActorScale3D();
	};
	PlatformPushCenter.Set(CenterX, CenterY, CenterZ);
	PlatformPushAreaBox.Set(XExtent*Scale.X, YExtent*Scale.Y, ZExtent*Scale.Z);
	PushDetectObjectTypes.Empty();
	for (int32 ObjectTypeInt: InDetectObjectTypes)
	{
		PushDetectObjectTypes.Add(TEnumAsByte<EObjectTypeQuery>(ObjectTypeInt));
	}

	DetectTickTime = TickTime;
	DetectDuration = TickTime;
	PushSpeed = Speed,

	IsUsingSafeAreaPush = true;
}

void UMovePlatformComponent::StopSafeAreaPush()
{
	IsUsingSafeAreaPush = false;
	CharactersPushedToSafeArea.Empty();
	
}