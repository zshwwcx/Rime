#include "3C/Component/AvatarFaceAnimComponent.h"

#include "3C/Animation/BaseAnimInstance.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Animation/AnimLayer/FaceAnimLayer.h"
#include "Components/SkeletalMeshComponent.h"
#include "Runtime/FaceControlComponent.h"

UAvatarFaceAnimComponent::UAvatarFaceAnimComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.TickInterval = 0.5F;
	PrimaryComponentTick.bStartWithTickEnabled = true;
	PrimaryComponentTick.SetTickFunctionEnable(true);
	PrimaryComponentTick.TickGroup = TG_PostPhysics;
}

void UAvatarFaceAnimComponent::BeginPlay()
{
	Super::BeginPlay();
	if (GetOwner())
	{
		Character = Cast<ABaseCharacter>(GetOwner());
	}
}

void UAvatarFaceAnimComponent::ResetToDefaultsForCache()
{
	NeedBlink = false;
	IsEnableBlink = false;
	if(Character.IsValid())
	{
		UFaceAnimLayer* FaceAnimLayer = GetFaceAnimLayer();
		if (FaceAnimLayer)
		{
			FaceAnimLayer->SetEyeBlinkWeight(0.0F);
			EnableFaceAnimLayer(false);
		}
	}
}

void UAvatarFaceAnimComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UAvatarFaceAnimComponent_TickComponent");
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if(Character.IsValid())
	{
		UFaceControlComponent* FaceControlComponent = Character->GetComponentByClass<UFaceControlComponent>();
		UFaceAnimLayer* FaceAnimLayer = GetFaceAnimLayer();
		if (FaceControlComponent && FaceAnimLayer)
		{
			bool IsFaceNearly = FaceControlComponent->CurrentCameraDistance <= AvatarFaceAnimDistance;
			if(NeedBlink && !IsEnableBlink && IsFaceNearly)
			{
				FaceAnimLayer->SetEyeBlinkWeight(1.0F);
				IsEnableBlink = true;
			}
			else if(IsEnableBlink && (!NeedBlink || !IsFaceNearly))
			{
				FaceAnimLayer->SetEyeBlinkWeight(0.0F);
				IsEnableBlink = false;
			}
			EnableFaceAnimLayer(IsFaceNearly);
		}
	}
}

UFaceAnimLayer* UAvatarFaceAnimComponent::GetFaceAnimLayer()
{
	if(Character.IsValid() && IsValid(Character->GetMainMesh()))
	{
		if (UBaseAnimInstance* AnimIns = Cast<UBaseAnimInstance>(Character->GetMainMesh()->GetAnimInstance()))
		{
			UFaceAnimLayer* FaceLayer = Cast<UFaceAnimLayer>(AnimIns->GetFeatureAnimLayer(FName(FaceAnimLayerTag)));
			if(IsValid(FaceLayer))
			{
				return FaceLayer;
			}
		}
	}
	return nullptr;
}

void UAvatarFaceAnimComponent::EnableFaceAnimLayer(bool Enable)
{
	if(Character.IsValid() && IsValid(Character->GetMainMesh()))
	{
		if (UBaseAnimInstance* AnimIns = Cast<UBaseAnimInstance>(Character->GetMainMesh()->GetAnimInstance()))
		{
			if(Enable)
			{
				AnimIns->EnableAnimFeatureLayer(FName(ABaseCharacter::FaceAnimTag));
			}
			else
			{
				AnimIns->DisableAnimFeatureLayer(FName(ABaseCharacter::FaceAnimTag));
			}
		}
	}
}