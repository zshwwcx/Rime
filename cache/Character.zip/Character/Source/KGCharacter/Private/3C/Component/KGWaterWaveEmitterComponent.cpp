#include "3C/Component/KGWaterWaveEmitterComponent.h"

#include "Scene/Components/C7ShapeCollisionComponent.h"
#include "3C/Interactor/WorldManager.h"

static FName CollisionProfileName(TEXT("InteractablePreset"));
static TAutoConsoleVariable<bool> CVarCharacterWaterWaveEmitter(TEXT("c7.Character.WaterWaveEmitter"), true, TEXT("c7.Character.WaterWaveEmitter"), ECVF_Default);


UKGWaterWaveEmitterComponent::UKGWaterWaveEmitterComponent()
{
}

void UKGWaterWaveEmitterComponent::BeginPlay()
{
	Super::BeginPlay();

	if (!CVarCharacterWaterWaveEmitter->GetBool())
	{
		return;
	}
	
	if (bEnableBound)
	{
		if (!ShapeCollision)
		{
			ShapeCollision = NewObject<UC7ShapeCollisionComponent>(GetOwner(), UC7ShapeCollisionComponent::StaticClass());
			ShapeCollision->AttachToComponent(this, FAttachmentTransformRules::SnapToTargetNotIncludingScale);
			ShapeCollision->RegisterComponent();
			ULowLevelFunctions::EnableOverlapOptimization(ShapeCollision, true);
			ShapeCollision->SetCollisionProfileName(CollisionProfileName);	
		}
		
		ShapeCollision->InitCollisionAsBox(BoxExtent);
		ShapeCollision->SetLineThickness(BoxLineThickness);
		
		ShapeCollision->OnEnterTrigger_MD.AddDynamic(this, &UKGWaterWaveEmitterComponent::OnPlayerEnter);
		ShapeCollision->OnLeaveTrigger_MD.AddDynamic(this, &UKGWaterWaveEmitterComponent::OnPlayerLeave);
		ShapeCollision->InitAsInteractable(0, true);
		
		bPlayerInside = false;
	}
	else
	{
		bPlayerInside = true;
		RefreshWaterWaveInManager();
	}
}

void UKGWaterWaveEmitterComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
	
	if (ShapeCollision)
	{
		ShapeCollision->OnEnterTrigger_MD.Clear();
		ShapeCollision->OnLeaveTrigger_MD.Clear();
	}

	if (UWorldManager* WorldManager = UWorldManager::GetInstance(this))
	{
		WorldManager->UnRegisterWaterWaveTick(WaterWaveRequestID);
	}
}

#if WITH_EDITOR
void UKGWaterWaveEmitterComponent::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
	RefreshWaterWaveInManager();

	if (bEnableBound)
	{
		if (!ShapeCollision)
		{
			ShapeCollision = NewObject<UC7ShapeCollisionComponent>(GetOwner(), UC7ShapeCollisionComponent::StaticClass());
			ShapeCollision->AttachToComponent(this, FAttachmentTransformRules::SnapToTargetNotIncludingScale);
			ShapeCollision->RegisterComponent();
			ShapeCollision->SetGenerateOverlapEvents(false);
			ShapeCollision->SetShouldUpdatePhysicsVolume(false);
			ShapeCollision->SetCollisionProfileName(CollisionProfileName);
		}
		
		ShapeCollision->InitCollisionAsBox(BoxExtent);
		ShapeCollision->SetLineThickness(BoxLineThickness);
	}
	else
	{
		if (ShapeCollision)
		{
			ShapeCollision->DestroyComponent();
			ShapeCollision = nullptr;
		}
	}
}

#endif

void UKGWaterWaveEmitterComponent::OnPlayerEnter(AActor* Player, const FVector& Loc)
{
	bPlayerInside = true;
	RefreshWaterWaveInManager();
}

void UKGWaterWaveEmitterComponent::OnPlayerLeave(AActor* Player, const FVector& Loc)
{
	bPlayerInside = false;
	if (UWorldManager* WorldManager = UWorldManager::GetInstance(this))
	{
		WorldManager->UnRegisterWaterWaveTick(WaterWaveRequestID);
	}
}

//WorldManger有TickCache，需要重新注册refresh参数
void UKGWaterWaveEmitterComponent::RefreshWaterWaveInManager()
{
	if (!bPlayerInside)
	{
		return;
	}
	
	if (!CVarCharacterWaterWaveEmitter->GetBool())
	{
		return;
	}
	
	if (UWorldManager* WorldManager = UWorldManager::GetInstance(this))
	{
		// 保底清理
		WorldManager->UnRegisterWaterWaveTick(WaterWaveRequestID);
		
		WaterWaveRequestID = WorldManager->GetGlobalWaterWaveRequestId();
		const FTransform ComponentTransform = GetComponentTransform();
		FVector Location = ComponentTransform.GetLocation();
		FRotator3f Rotation = FRotator3f(GetComponentRotation());
		//处理角度偏移
		float AngleRad = FMath::DegreesToRadians(MoveDirAngleOffset); // 角度转弧度
		float MoveDirX = FMath::Cos(AngleRad);
		float MoveDirY = FMath::Sin(AngleRad);
		const FVector3f MoveDirection(MoveDirX, MoveDirY, 0.f);
		const FVector3f RotatedMoveDirection = Rotation.RotateVector(MoveDirection);
		float MotorTextureYaw = FMath::Atan2(-RotatedMoveDirection.Y, RotatedMoveDirection.X);
		WorldManager->AddMotorForDynamicWaterWave(WaterWaveRequestID, MotorTextureId, Location.X, Location.Y, MotorTextureYaw, Scale.X, Scale.Y, MaxHeight, FoamScale, TimeGap, RotatedMoveDirection.X, RotatedMoveDirection.Y, 0);
	}
}

void UKGWaterWaveEmitterComponent::SetMotorTextureId(int32 Value)
{
	if (MotorTextureId != Value)
	{
		MotorTextureId = Value;
		RefreshWaterWaveInManager();
	}
}

void UKGWaterWaveEmitterComponent::SetScale(FVector2f Value)
{
	if (Scale != Value)
	{
		Scale = Value;
		RefreshWaterWaveInManager();
	}
}

void UKGWaterWaveEmitterComponent::SetMaxHeight(float Value)
{
	if (MaxHeight != Value)
	{
		MaxHeight = Value;
		RefreshWaterWaveInManager();
	}
}

void UKGWaterWaveEmitterComponent::SetFoamScale(float Value)
{
	if (FoamScale != Value)
	{
		FoamScale = Value;
		RefreshWaterWaveInManager();
	}
}

void UKGWaterWaveEmitterComponent::SetTimeGap(float Value)
{
	if (TimeGap != Value)
	{
		TimeGap = Value;
		RefreshWaterWaveInManager();
	}
}

void UKGWaterWaveEmitterComponent::SetMoveDirAngleOffset(int Value)
{
	if (MoveDirAngleOffset != Value)
	{
		MoveDirAngleOffset = Value;
		RefreshWaterWaveInManager();
	}
}
