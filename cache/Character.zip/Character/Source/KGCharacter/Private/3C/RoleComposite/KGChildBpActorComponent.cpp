// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com
#include "3C/RoleComposite/KGChildBpActorComponent.h"

#include "3C/Animation/BaseAnimInstance.h"
#include "3C/Character/BaseCharacter.h"
#include "JsonObjectConverter.h"
#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/Actor.h"
#include "Misc/FileHelper.h"
#include "Runtime/FaceControlComponent.h"

UKGChildBpActorComponent::UKGChildBpActorComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = true;
	bTickInEditor = true;
#if WITH_EDITOR
	SetEditorTreeViewVisualizationMode(EChildActorComponentTreeViewVisualizationMode::ComponentWithChildActor);
#endif
}

void UKGChildBpActorComponent::CreateChildActor(TFunction<void(AActor*)> CustomizerFunc)
{
	Super::CreateChildActor(CustomizerFunc);

	BpActor = Cast<ABaseCharacter>(GetChildActor());
	if (!BpActor) return;

	InitializeBakedBpCharacter(BpActor);

	if (AnimSequence)
	{
		PlayCustomAnim(AnimSequence, SlotName, LoopingCount, PlayRate, StartAtTime);
	}
}

void UKGChildBpActorComponent::PlayCustomAnim(UAnimSequenceBase* AnimToPlay, const FName InSlotName, int32 InLoopingCount, const float InPlayRate, const float InStartAtTime)
{
	if (!AnimToPlay || !BpActor) return;

	const USkeletalMeshComponent* SKCom = BpActor->GetMainMesh();
	if (!SKCom) return;

	UAnimInstance* AnimInst = SKCom->GetAnimInstance();
	if (!AnimInst) return;

	AnimInst->PlaySlotAnimationAsDynamicMontage(AnimToPlay, InSlotName, 0, 0, InPlayRate, InLoopingCount, -1, InStartAtTime);
}

ABaseCharacter* UKGChildBpActorComponent::GetBpActor()
{
	return BpActor;
}

void UKGChildBpActorComponent::InitializeBakedBpCharacter(ABaseCharacter* InCharacter)
{
	UFaceControlComponent* FaceControlComponent = InCharacter->GetComponentByClass<UFaceControlComponent>();
	if (!FaceControlComponent) return;

	FaceControlComponent->SetFaceDataRuntimeSelf();
	USkeletalMeshComponent* MainMesh = InCharacter->GetMesh();

	for (UActorComponent* Component : InCharacter->K2_GetComponentsByClass(USkeletalMeshComponent::StaticClass()))
	{
		Component->PrimaryComponentTick.bCanEverTick = true;
		Component->PrimaryComponentTick.bStartWithTickEnabled = true;
		Component->bTickInEditor = true;
		if (USkeletalMeshComponent* SkeletalMeshComponent = Cast<USkeletalMeshComponent>(Component))
		{
			if (SkeletalMeshComponent->AnimClass != nullptr)
			{
				SkeletalMeshComponent->InitAnim(true);
			}
			SkeletalMeshComponent->SetUpdateAnimationInEditor(true);
			if (SkeletalMeshComponent->ComponentTags.Contains("Follower"))
			{
				SkeletalMeshComponent->SetLeaderPoseComponent(MainMesh);
			}
		}
	}
}

// Called when the game starts
void UKGChildBpActorComponent::BeginPlay()
{
	Super::BeginPlay();
	InitializeBakedBpCharacter(BpActor);

	if (AnimSequence)
	{
		PlayCustomAnim(AnimSequence, SlotName, LoopingCount, PlayRate, StartAtTime);
	}
}

void UKGChildBpActorComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

#if WITH_EDITOR
	if (!BpActor) return;

	USkeletalMeshComponent* SKCom = BpActor->GetMainMesh();
	if (!SKCom) return;

	SKCom->SetUpdateAnimationInEditor(true);

	UAnimInstance* NewAnimInst = SKCom->GetAnimInstance();
	if (!NewAnimInst) return;

	if (AnimSequence && NewAnimInst->GetActiveMontageInstance() == nullptr)
	{
		PlayCustomAnim(AnimSequence, SlotName, LoopingCount, PlayRate, StartAtTime);
	}
#endif
}
