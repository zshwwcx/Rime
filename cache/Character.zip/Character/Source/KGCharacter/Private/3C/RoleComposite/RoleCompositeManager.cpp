#include "3C/RoleComposite/RoleCompositeManager.h"
#include "3C/Animation/BaseAnimInstance.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Core/C7ActorInterface.h"
#include "FurComponent.h"
#include "Manager/KGCppAssetManager.h"
#include "Runtime/FaceControlComponent.h"
#include "3C/Core/LuaHelper.h"
#include "Misc/KGGameInstanceBase.h"
#include "Manager/KGObjectActorManager.h"
#include "SkeletalMeshComponentBudgeted.h"
#include "3C/Util/KGUtils.h"
#include "Animation/AnimInstance.h"
#include "Animation/AnimSequenceBase.h"
#include "Chaos/Deformable/MuscleActivationConstraints.h"
#include "Components/CapsuleComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/StaticMesh.h"
#include "3C/Material/KGMaterialManager.h"
#include "PhysicsEngine/PhysicsAsset.h"
#include "Runtime/CustomRoleDataSerializer.h"
#include "Components/MeshComponent.h"
#include "3C/Effect/KGEffectManager.h"

//PRAGMA_DISABLE_OPTIMIZATION

void URoleCompositeMgr::NativeInit()
{
	Super::NativeInit();
	if(!MontageCaches.IsValid())
	{
		MontageCaches = MakeUnique<FCachedAnimMontage>();
	}

	ClearMontageSyncInfo();
	
	WorldCleanupHandle = FWorldDelegates::OnWorldCleanup.AddUObject(
		this,
		&URoleCompositeMgr::HandleWorldCleanup
	);

	InitializeEnumMaps();
	LoadAllDataAsset();
	using namespace NS_SLUA;
	REG_MANAGER_FUNC(URoleCompositeMgr, "LoadAllDataAsset", &URoleCompositeMgr::LoadAllDataAsset);
	REG_MANAGER_FUNC(URoleCompositeMgr, "EnableLog", &URoleCompositeMgr::EnableLog);
	REG_MANAGER_FUNC(URoleCompositeMgr, "CleanupAllResources", &URoleCompositeMgr::CleanupAllResources);
	REG_MANAGER_FUNC(URoleCompositeMgr, "AddPreLoadAnims", &URoleCompositeMgr::AddPreLoadAnims);
	REG_MANAGER_FUNC(URoleCompositeMgr, "CheckAnimsIsInCache", &URoleCompositeMgr::CheckAnimsIsInCache);
	REG_MANAGER_FUNC(URoleCompositeMgr, "GetMontageCacheByID", &URoleCompositeMgr::GetMontageCacheByID);
	REG_MANAGER_FUNC(URoleCompositeMgr, "CreateAndAddMontageCacheByID", &URoleCompositeMgr::CreateAndAddMontageCacheByID);
	REG_MANAGER_FUNC(URoleCompositeMgr, "EmptyMontageCache", &URoleCompositeMgr::EmptyMontageCache);
	REG_MANAGER_FUNC(URoleCompositeMgr, "EmptyMontageCacheAll", &URoleCompositeMgr::EmptyMontageCacheAll);
	REG_MANAGER_FUNC(URoleCompositeMgr, "ChangeMainPlayerMontageCacheCapacity", &URoleCompositeMgr::ChangeMainPlayerMontageCacheCapacity);
	REG_MANAGER_FUNC(URoleCompositeMgr, "ChangeDefaultMontageCacheCapacity", &URoleCompositeMgr::ChangeDefaultMontageCacheCapacity);
	REG_MANAGER_FUNC(URoleCompositeMgr, "ChangeMontageCachesCapacity", &URoleCompositeMgr::ChangeMontageCachesCapacity);
	REG_MANAGER_FUNC(URoleCompositeMgr, "ClearMontageSyncInfo", &URoleCompositeMgr::ClearMontageSyncInfo);
	REG_MANAGER_FUNC(URoleCompositeMgr, "RequestPreLoadAnims", &URoleCompositeMgr::RequestPreloadAnims);
	REG_MANAGER_FUNC(URoleCompositeMgr, "CancelPreloadAnims", &URoleCompositeMgr::CancelPreloadAnims);

	REG_MANAGER_FUNC(URoleCompositeMgr, "AddActorAppearanceAssetRef", &URoleCompositeMgr::AddActorAppearanceAssetRef);
	REG_MANAGER_FUNC(URoleCompositeMgr, "RemoveActorAppearanceAssetRefByPaths", &URoleCompositeMgr::RemoveActorAppearanceAssetRefByPaths);
	REG_MANAGER_FUNC(URoleCompositeMgr, "RemoveActorAppearanceAssetRef", &URoleCompositeMgr::RemoveActorAppearanceAssetRef);
	REG_MANAGER_FUNC(URoleCompositeMgr, "RemoveActorAppearanceAssetKeepRef", &URoleCompositeMgr::RemoveActorAppearanceAssetKeepRef);
	REG_MANAGER_FUNC(URoleCompositeMgr, "GetActorAppearanceAssetID", &URoleCompositeMgr::GetActorAppearanceAssetID);
	REG_MANAGER_FUNC(URoleCompositeMgr, "ClearActorAppearanceAssetRef", &URoleCompositeMgr::ClearActorAppearanceAssetRef);
	REG_MANAGER_FUNC(URoleCompositeMgr, "AsyncLoadAppearanceAsset", &URoleCompositeMgr::AsyncLoadAppearanceAsset);
	
	REG_MANAGER_FUNC(URoleCompositeMgr, "ClearFaceControlComponentCompositeData", &URoleCompositeMgr::ClearFaceControlComponentCompositeData);
	REG_MANAGER_FUNC(URoleCompositeMgr, "SetMaterialParameterFromMakeupSerializedData", &URoleCompositeMgr::SetMaterialParameterFromMakeupSerializedData);
	REG_MANAGER_FUNC(URoleCompositeMgr, "SetTextureIDPaths", &URoleCompositeMgr::SetTextureIDPaths);
	REG_MANAGER_FUNC(URoleCompositeMgr, "AddOtherPartAndSlots", &URoleCompositeMgr::AddOtherPartAndSlots);
	REG_MANAGER_FUNC(URoleCompositeMgr, "AddOtherPartAndSlotsByID", &URoleCompositeMgr::AddOtherPartAndSlotsByID);
	REG_MANAGER_FUNC(URoleCompositeMgr, "AddGFurOtherPartAndSlotsByID", &URoleCompositeMgr::AddGFurOtherPartAndSlotsByID);
	REG_MANAGER_FUNC(URoleCompositeMgr, "ApplyOtherPartAndSlots", &URoleCompositeMgr::ApplyOtherPartAndSlots);
	REG_MANAGER_FUNC(URoleCompositeMgr, "ResetAllMIDMaterialByCPD", &URoleCompositeMgr::ResetAllMIDMaterialByCPD);//ADD BY hechengang03@kuaishou.com
	REG_MANAGER_FUNC(URoleCompositeMgr, "SetHeadHighlightMaterial", &URoleCompositeMgr::SetHeadHighlightMaterial);//ADD BY hechengang03@kuaishou.com
	REG_MANAGER_FUNC(URoleCompositeMgr, "ResetAllMIDMaterialByCPDByPath", &URoleCompositeMgr::ResetAllMIDMaterialByCPDByPath);
	REG_MANAGER_FUNC(URoleCompositeMgr, "SetMeshMaterialParameter", &URoleCompositeMgr::SetMeshMaterialParameter);
	REG_MANAGER_FUNC(URoleCompositeMgr, "SetNPCMeshMaterialParameter", &URoleCompositeMgr::SetNPCMeshMaterialParameter);
	REG_MANAGER_FUNC(URoleCompositeMgr, "SetMakeupMeshMaterialParameter", &URoleCompositeMgr::SetMakeupMeshMaterialParameter);
	REG_MANAGER_FUNC(URoleCompositeMgr, "SetGFurMeshMaterialParameter", &URoleCompositeMgr::SetGFurMeshMaterialParameter);
	REG_MANAGER_FUNC(URoleCompositeMgr, "GetMaterialIndicesBySlotName", &URoleCompositeMgr::GetMaterialIndicesBySlotName);
	REG_MANAGER_FUNC(URoleCompositeMgr, "FaceSetMeshMaterialParameter", &URoleCompositeMgr::FaceSetMeshMaterialParameter);
	REG_MANAGER_FUNC(URoleCompositeMgr, "FaceSetMeshMaterialParameterByID", &URoleCompositeMgr::FaceSetMeshMaterialParameterByID);
	REG_MANAGER_FUNC(URoleCompositeMgr, "ChangeModelDefaultMaterial", &URoleCompositeMgr::ChangeModelDefaultMaterial);
	REG_MANAGER_FUNC(URoleCompositeMgr, "ChangeModelDefaultMaterialBatch", &URoleCompositeMgr::ChangeModelDefaultMaterialBatch);
	REG_MANAGER_FUNC(URoleCompositeMgr, "SetOverlayMaterial", &URoleCompositeMgr::SetOverlayMaterial);

	REG_MANAGER_FUNC(URoleCompositeMgr, "SetMainMeshNameValue", &URoleCompositeMgr::SetMainMeshNameValue);
	REG_MANAGER_FUNC(URoleCompositeMgr, "SetSkeletalMeshComParamFast", &URoleCompositeMgr::SetSkeletalMeshComParamFast);
	REG_MANAGER_FUNC(URoleCompositeMgr, "PostExecuteBakedBPSkeletalMesh", &URoleCompositeMgr::PostExecuteBakedBPSkeletalMesh);
	REG_MANAGER_FUNC(URoleCompositeMgr, "SetSkeletalMeshParam", &URoleCompositeMgr::SetSkeletalMeshParam);
	REG_MANAGER_FUNC(URoleCompositeMgr, "SetStaticMeshParam", &URoleCompositeMgr::SetStaticMeshParam);
	REG_MANAGER_FUNC(URoleCompositeMgr, "ClearDecorationComponents", &URoleCompositeMgr::ClearDecorationComponents);
	REG_MANAGER_FUNC(URoleCompositeMgr, "SetMeshUseParentCapsuleComponentBound", &URoleCompositeMgr::SetMeshUseParentCapsuleComponentBound);
	REG_MANAGER_FUNC(URoleCompositeMgr, "SetBoundsPhysicsAsset", &URoleCompositeMgr::SetBoundsPhysicsAsset);
	REG_MANAGER_FUNC(URoleCompositeMgr, "ClearBoundsPhysicsAsset", &URoleCompositeMgr::ClearBoundsPhysicsAsset);
	REG_MANAGER_FUNC(URoleCompositeMgr, "EnableKawaiiAllInOne", &URoleCompositeMgr::EnableKawaiiAllInOne);
	REG_MANAGER_FUNC(URoleCompositeMgr, "UseAShirtControlRig", &URoleCompositeMgr::UseAShirtControlRig);
	REG_MANAGER_FUNC(URoleCompositeMgr, "EnableMainMeshKawaiiOptimize", &URoleCompositeMgr::EnableMainMeshKawaiiOptimize);
	REG_MANAGER_FUNC(URoleCompositeMgr, "EnableAttachMeshKawaiiOptimize", &URoleCompositeMgr::EnableAttachMeshKawaiiOptimize);
	REG_MANAGER_FUNC(URoleCompositeMgr, "SetAvatarFaceAnimDistance", &URoleCompositeMgr::SetAvatarFaceAnimDistance);
	REG_MANAGER_FUNC(URoleCompositeMgr, "GetAvatarFaceAnimDistance", &URoleCompositeMgr::GetAvatarFaceAnimDistance);
	REG_MANAGER_FUNC(URoleCompositeMgr, "GetBoneMaskData", &URoleCompositeMgr::GetBoneMaskData);
	REG_MANAGER_FUNC(URoleCompositeMgr, "EnableBoneMask", &URoleCompositeMgr::EnableBoneMask);
	
	REG_MANAGER_FUNC(URoleCompositeMgr, "CreateAppearanceEffect", &URoleCompositeMgr::CreateAppearanceEffect);
	REG_MANAGER_FUNC(URoleCompositeMgr, "CreateAppearanceEffectOffset", &URoleCompositeMgr::CreateAppearanceEffectOffset);
	
	REG_MANAGER_FUNC(URoleCompositeMgr, "InitializeModelHitBoxData", &URoleCompositeMgr::InitializeModelHitBoxData);

#pragma region Hotfix
	REG_MANAGER_FUNC(URoleCompositeMgr,"RemoveAvatarModelLibMakeupMesh",&URoleCompositeMgr::RemoveAvatarModelLibMakeupMesh);
	REG_MANAGER_FUNC(URoleCompositeMgr,"RemoveAvatarModelLibGFurMesh",&URoleCompositeMgr::RemoveAvatarModelLibGFurMesh);
	REG_MANAGER_FUNC(URoleCompositeMgr,"RemoveAvatarModelLibCaptureData",&URoleCompositeMgr::RemoveAvatarModelLibCaptureData);
	REG_MANAGER_FUNC(URoleCompositeMgr,"RemoveAvatarModelLibOtherPartAndSlotsData",&URoleCompositeMgr::RemoveAvatarModelLibOtherPartAndSlotsData);
	REG_MANAGER_FUNC(URoleCompositeMgr,"RemoveAvatarModelLibGFurOtherPartAndSlots",&URoleCompositeMgr::RemoveAvatarModelLibGFurOtherPartAndSlots);
	REG_MANAGER_FUNC(URoleCompositeMgr,"RemoveNPCSuit",&URoleCompositeMgr::RemoveNPCSuit);
	REG_MANAGER_FUNC(URoleCompositeMgr,"RemoveNPCAsset",&URoleCompositeMgr::RemoveNPCAsset);
	
	REG_MANAGER_FUNC(URoleCompositeMgr,"AddAvatarModelLibMakeupMesh",&URoleCompositeMgr::AddAvatarModelLibMakeupMesh);
	REG_MANAGER_FUNC(URoleCompositeMgr,"AddAvatarModelLibGFurMesh",&URoleCompositeMgr::AddAvatarModelLibGFurMesh);
	REG_MANAGER_FUNC(URoleCompositeMgr,"AddAvatarModelLibCaptureData",&URoleCompositeMgr::AddAvatarModelLibCaptureData);
	REG_MANAGER_FUNC(URoleCompositeMgr,"AddAvatarModelLibOtherPartAndSlotsData",&URoleCompositeMgr::AddAvatarModelLibOtherPartAndSlotsData);
	REG_MANAGER_FUNC(URoleCompositeMgr,"AddAvatarModelLibGFurOtherPartAndSlots",&URoleCompositeMgr::AddAvatarModelLibGFurOtherPartAndSlots);
	REG_MANAGER_FUNC(URoleCompositeMgr,"AddNPCSuit",&URoleCompositeMgr::AddNPCSuit);
	REG_MANAGER_FUNC(URoleCompositeMgr,"AddNPCAsset",&URoleCompositeMgr::AddNPCAsset);
#pragma endregion
		

}

void URoleCompositeMgr::NativeUninit()
{
	FWorldDelegates::OnWorldCleanup.Remove(WorldCleanupHandle);
	EmptyMontageCacheAll();
	ClearActorAppearanceAssetRef();
	UnloadAllDataAsset();
	Super::NativeUninit();
}

void URoleCompositeMgr::HandleWorldCleanup(UWorld* World, bool bSessionEnded, bool bCleanupResources)
{
	if (World && World->IsGameWorld())
	{
		EmptyMontageCacheAll();
		ClearActorAppearanceAssetRef();
		ROLE_COMPOSITE_MANAGER_LOG(TEXT("Cleaned up role composite resources for world: %s"), *World->GetName());
	}
}

void URoleCompositeMgr::CleanupAllResources()
{
	EmptyMontageCacheAll();
	ClearActorAppearanceAssetRef();
}

URoleCompositeMgr::URoleCompositeMgr(const FObjectInitializer& ObjectInitializer)
	: Super()
{
}

void URoleCompositeMgr::SetDynamicMaterialScalarParameterValue(UMaterialInstanceDynamic* DyMaterial, FString Name, float Value)
{
	if (DyMaterial)
	{
		DyMaterial->SetScalarParameterValue(FName(Name), Value);
	}
}

void URoleCompositeMgr::SetDynamicMaterialVectorParameterValue(UMaterialInstanceDynamic* DyMaterial, FString Name, FColor Color)
{
	if (DyMaterial)
	{
		DyMaterial->SetVectorParameterValue(FName(Name), FLinearColor(Color));
	}
}

#pragma region Animation
void URoleCompositeMgr::AddPreLoadAnims(int CachePoolType, const TArray<FName>& PreloadAnimPaths, const TArray<KGObjectID>& PreloadAnimObjectIDs)
{
	if(PreloadAnimPaths.Num() != PreloadAnimObjectIDs.Num())
	{
		UE_LOG(RoleCompositeMgrLog, Warning, TEXT("[AnimationManager] AddPreLoadAnims Num Do Not Math."))
		return;
	}

	if(UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this))
	{
		EAnimSequenceCacheType CacheType = CachePoolType == 0 ? EAnimSequenceCacheType::Game : EAnimSequenceCacheType::Level;
		TArray<UAnimSequenceBase*> Anims;
		for (int Index = 0; Index < PreloadAnimObjectIDs.Num(); ++Index)
		{
			if (!PreloadAnimPaths[Index].IsNone())
			{
				if (UAnimSequenceBase* Seq = Cast<UAnimSequenceBase>(KGUtils::GetObjectByID(PreloadAnimObjectIDs[Index])))
				{
					AssetManager->AddAnimsToCache(CacheType, PreloadAnimPaths[Index], Seq);
				}
			}
		}
	}
}

bool URoleCompositeMgr::CheckAnimsIsInCache(int CachePoolType, const TArray<FName>& PreloadAnimPaths)
{
	if(UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this))
	{
		EAnimSequenceCacheType CacheType = CachePoolType == 0 ? EAnimSequenceCacheType::Game : EAnimSequenceCacheType::Level;
		bool bResult = true;
		for (auto& AnimPath : PreloadAnimPaths)
		{
			if (!AssetManager->HasAnimCache(CacheType, AnimPath))
			{
				bResult = false;
			}
		}
		return bResult;
	}

	return false;
}

int64 URoleCompositeMgr::RequestPreloadAnims(const TArray<FName>& AnimPaths, bool bHasCallBack, bool bGameCache)
{
	if(AnimPaths.Num() == 0)
	{
		return KG_INVALID_ID;
	}

	if(UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this))
	{
		int64 UUID = ULowLevelFunctions::GetGlobalUniqueID();
		TArray<FString> AnimPathStrs;
		for (auto& AnimPath : AnimPaths)
		{
			if (!AnimPath.IsNone())
			{
				AnimPathStrs.Emplace(AnimPath.ToString());
			}
			else
			{
				UE_LOG(LogTemp, Warning, TEXT("[URoleCompositeMgr]Animation PreLoad Get None AnimPath!"));
			}
		}
		int LoadID = AssetManager->AsyncLoadAsset(AnimPathStrs, FAsyncLoadListCompleteDelegate::CreateUObject(this, &URoleCompositeMgr::OnPreloadAnimsLoaded, UUID, bGameCache, bHasCallBack), static_cast<int32>(EAssetLoadPriority::AnimLib));
		AssetLoadIDs.Add(UUID, LoadID);
		IDToAssetPaths.Add(UUID, AnimPathStrs);
		return UUID;
	}

	return KG_INVALID_ID;
}

void URoleCompositeMgr::CancelPreloadAnims(int64 UUID)
{
	if (AssetLoadIDs.Contains(UUID))
	{
		if(UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this))
		{
			AssetManager->CancelAsyncLoadByLoadID(AssetLoadIDs[UUID]);
		}
		AssetLoadIDs.Remove(UUID);
		IDToAssetPaths.Remove(UUID);
	}
}

void URoleCompositeMgr::AddMontageCache(int CachePoolType, const FString& Key, UAnimMontage* Value)
{
	if(!MontageCaches.IsValid())
	{
		return;
	}
	MontageCaches->AddMontageCache(CachePoolType, Key, Value);
}

UAnimMontage* URoleCompositeMgr::CreateAndAddMontageCache(int CachePoolType, const FString& Key, UAnimSequenceBase* Value, const FName& AnimSlotName, float BlendInTime, float BlendOutTime, int LoopCount, bool bAddCache) const
{
	if(!MontageCaches.IsValid())
	{
		return nullptr;
	}
	return MontageCaches->CreateAndAddMontageCache(CachePoolType, Key, Value, AnimSlotName, BlendInTime, BlendOutTime, LoopCount, bAddCache);
}

KGObjectID URoleCompositeMgr::CreateAndAddMontageCacheByID(int CachePoolType, const FString& Key, int64 AnimAssetID, const FName& AnimSlotName, float BlendInTime, float BlendOutTime, int LoopCount, bool bAddCache) const
{
	if(UAnimSequenceBase* AnimAsset = Cast<UAnimSequenceBase>(KGUtils::GetObjectByID(AnimAssetID)))
	{
		UAnimMontage* Result = CreateAndAddMontageCache(CachePoolType, Key, AnimAsset, AnimSlotName, BlendInTime, BlendOutTime, LoopCount, bAddCache);
		return KGUtils::GetIDByObject(Result);
	}
	return KG_INVALID_ID;
}


UAnimMontage* URoleCompositeMgr::GetMontageCache(int CachePoolType, const FString& Key, const FName& AnimSlotName,
                                                 float BlendInTime, float BlendOutTime, int LoopCount)
{
	UAnimMontage* Result = nullptr;
	if(MontageCaches.IsValid())
	{
		Result = MontageCaches->GetMontageCache(CachePoolType, Key, AnimSlotName);
	}

	if(Result == nullptr)
	{
		if(UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this))
		{
			if(UAnimSequenceBase* CacheSeq = AssetManager->GetAnimSequenceAssetCache(FName(Key)))
			{
				Result = CreateAndAddMontageCache(CachePoolType, Key, CacheSeq, AnimSlotName, BlendInTime, BlendOutTime, LoopCount, true);
			}
		}
	}

	return Result;
}

KGObjectID URoleCompositeMgr::GetMontageCacheByID(int CachePoolType, const FString& Key, const FName& AnimSlotName,
                                                  float BlendInTime, float BlendOutTime, int LoopCount)
{
	return KGUtils::GetIDByObject(GetMontageCache(CachePoolType, Key, AnimSlotName, BlendInTime, BlendOutTime, LoopCount));
}

void URoleCompositeMgr::EmptyMontageCache(int CachePoolType)
{
	if(!MontageCaches.IsValid())
	{
		return;
	}
	MontageCaches->EmptyMontageCache(CachePoolType);
}

void URoleCompositeMgr::EmptyMontageCacheAll()
{
	if(!MontageCaches.IsValid())
	{
		return;
	}
	MontageCaches->EmptyMontageCacheAll();
}

void URoleCompositeMgr::ChangeMainPlayerMontageCacheCapacity(int NewCapacity)
{
	if(!MontageCaches.IsValid())
	{
		return;
	}
	MontageCaches->ChangeMontageCachesCapacity(NewCapacity);
}

void URoleCompositeMgr::ChangeDefaultMontageCacheCapacity(int NewCapacity)
{
	if(!MontageCaches.IsValid())
	{
		return;
	}
	MontageCaches->ChangeDefaultMontageCacheCapacity(NewCapacity);
}

void URoleCompositeMgr::ChangeMontageCachesCapacity(int NewCapacity)
{
	if(!MontageCaches.IsValid())
	{
		return;
	}
	MontageCaches->ChangeMontageCachesCapacity(NewCapacity);
}

void URoleCompositeMgr::RegisterLeadingAnimationSyncPlay(KGAnimPlayReqID LeadingAnimPlayReqID,
                                                         TSharedPtr<KGAnimPlayViewConfig> LeadingAnimPlayViewConfig)
{
	LeadingAnimations.Add(LeadingAnimPlayReqID, LeadingAnimPlayViewConfig);

	if(!LeadingFollowAnimationPairs.Contains(LeadingAnimPlayReqID))
	{
		LeadingFollowAnimationPairs.Add(LeadingAnimPlayReqID, {});
	}

	if(LeadingFollowAnimationPairs[LeadingAnimPlayReqID].Num() > 0)
	{
		auto& SyncPairs = LeadingFollowAnimationPairs[LeadingAnimPlayReqID];
		for(auto& [FollowAnimPlayReqID, _] : SyncPairs)
		{
			if(FollowAnimations.Contains(FollowAnimPlayReqID) && FollowAnimations[FollowAnimPlayReqID].IsValid())
			{
				onAnimationSyncPairReady(*FollowAnimations[FollowAnimPlayReqID].Pin(), *LeadingAnimPlayViewConfig);
			}
		}
	}
}

void URoleCompositeMgr::RegisterFollowAnimationSyncPlay(KGAnimPlayReqID FollowAnimPlayReqID,
                                                        TSharedPtr<KGAnimPlayViewConfig> FollowAnimPlayViewConfig,
                                                        KGAnimPlayReqID LeadingAnimPlayReqID)
{
	FollowAnimations.Add(FollowAnimPlayReqID, FollowAnimPlayViewConfig);

	if(!LeadingFollowAnimationPairs.Contains(LeadingAnimPlayReqID))
	{
		LeadingFollowAnimationPairs.Add(LeadingAnimPlayReqID, {});
	}
	LeadingFollowAnimationPairs[LeadingAnimPlayReqID].Add(FollowAnimPlayReqID, true);

	if(TWeakPtr<KGAnimPlayViewConfig>* LeadingAnimPlayViewConfigPtr = LeadingAnimations.Find(LeadingAnimPlayReqID))
	{
		if(LeadingAnimPlayViewConfigPtr->IsValid())
		{
			onAnimationSyncPairReady(*FollowAnimPlayViewConfig, *LeadingAnimPlayViewConfigPtr->Pin());
		}
	}
}

void URoleCompositeMgr::UnRegisterLeadingAnimationSyncPlay(KGAnimPlayReqID LeadingAnimPlayReqID)
{
	if(!LeadingAnimations.Contains(LeadingAnimPlayReqID))
	{
		return;
	}

	LeadingAnimations.Remove(LeadingAnimPlayReqID);

	if(!LeadingFollowAnimationPairs.Contains(LeadingAnimPlayReqID))
	{
		return;
	}

	for(auto& [FollowAnimPlayReqID, _] : LeadingFollowAnimationPairs[LeadingAnimPlayReqID])
	{
		if(FollowAnimations.Contains(FollowAnimPlayReqID) && FollowAnimations[FollowAnimPlayReqID].IsValid())
		{
			KGAnimPlayViewConfig& FollowAnimPlayViewConfig = *FollowAnimations[FollowAnimPlayReqID].Pin();
			if(USkeletalMeshComponent* FollowMesh = Cast<USkeletalMeshComponent>(KGUtils::GetObjectByID(FollowAnimPlayViewConfig.SKMeshID)))
			{
				if(FollowMesh->GetAnimInstance() != nullptr && FollowAnimPlayViewConfig.PlayingMontage.IsValid())
				{
					FollowMesh->GetAnimInstance()->MontageSync_StopFollowing(FollowAnimPlayViewConfig.PlayingMontage.Get());
				}
			}
		}
	}
	
	LeadingFollowAnimationPairs.Remove(LeadingAnimPlayReqID);
}

void URoleCompositeMgr::UnRegisterFollowAnimationSyncPlay(KGAnimPlayReqID FollowAnimPlayReqID,
                                                          KGAnimPlayReqID LeadingAnimPlayReqID)
{
	if(!FollowAnimations.Contains(FollowAnimPlayReqID))
	{
		return;
	}

	if(LeadingFollowAnimationPairs.Contains(LeadingAnimPlayReqID) && LeadingFollowAnimationPairs[LeadingAnimPlayReqID].Contains(FollowAnimPlayReqID))
	{
		if(FollowAnimations[FollowAnimPlayReqID].IsValid())
		{
			KGAnimPlayViewConfig& FollowAnimPlayViewConfig = *FollowAnimations[FollowAnimPlayReqID].Pin();
			if(USkeletalMeshComponent* FollowMesh = Cast<USkeletalMeshComponent>(KGUtils::GetObjectByID(FollowAnimPlayViewConfig.SKMeshID)))
			{
				if(FollowMesh->GetAnimInstance() != nullptr && FollowAnimPlayViewConfig.PlayingMontage.IsValid())
				{
					FollowMesh->GetAnimInstance()->MontageSync_StopFollowing(FollowAnimPlayViewConfig.PlayingMontage.Get());
				}
			}
		}
		LeadingFollowAnimationPairs[LeadingAnimPlayReqID].Remove(FollowAnimPlayReqID);
	}

	FollowAnimations.Remove(FollowAnimPlayReqID);
}

void URoleCompositeMgr::ClearMontageSyncInfo()
{
	LeadingAnimations.Empty();
	FollowAnimations.Empty();
	LeadingFollowAnimationPairs.Empty();
}

void URoleCompositeMgr::OnPreloadAnimsLoaded(int InLoadID, const TArray<UObject*>& AnimAssets, int64 UUID, bool bGameCache, bool bHasCallBack)
{
	if(AssetLoadIDs.Contains(UUID))
	{
		AssetLoadIDs.Remove(UUID);

		auto& AnimPaths = IDToAssetPaths[UUID];
		if(UKGCppAssetManager* CppAssetManager = UKGCppAssetManager::GetInstance(this))
		{
			for(int Index = AnimPaths.Num() - 1; Index > -1; --Index)
			{
				if(UAnimSequenceBase* Anim = Cast<UAnimSequenceBase>(AnimAssets[Index]))
				{
					const EAnimSequenceCacheType AnimSequenceCacheType = bGameCache ? EAnimSequenceCacheType::Game : EAnimSequenceCacheType::Level;
					CppAssetManager->AddAnimsToCache(AnimSequenceCacheType, FName(AnimPaths[Index]), Anim);
				}
			}
		}

		IDToAssetPaths.Remove(UUID);
  
		if (bHasCallBack)
		{
			CallLuaFunction("KCB_Animation_ReqPreloadAnimsLoaded", UUID);
		}
	}
}

FString URoleCompositeMgr::GetRoleCompositeManagerDebugInfo() const
{
	FString Output;
	Output.Append(TEXT("----Player Montage Cache Info-----\n"));
	if(MontageCaches.IsValid())
	{
		Output.Appendf(TEXT("CacheHitRate:%.2f%% QueryCnt:%d HitCnt:%d MissCnt:%d\n"), MontageCaches->GetMainCacheHitRate() * 100, MontageCaches->MainCacheQueryCnt(), MontageCaches->MainCacheHitCnt(), MontageCaches->MainCacheMissCnt());
	}

	Output.Append(TEXT("----Default Montage Cache Info-----\n"));
	if(MontageCaches.IsValid())
	{
		Output.Appendf(TEXT("CacheHitRate:%.2f%% QueryCnt:%d HitCnt:%d MissCnt:%d\n"), MontageCaches->GetDefaultCacheHitRate() * 100, MontageCaches->DefaultCacheQueryCnt(), MontageCaches->DefaultCacheHitCnt(), MontageCaches->DefaultCacheMissCnt());
	}

	return Output;
}

void URoleCompositeMgr::onAnimationSyncPairReady(const KGAnimPlayViewConfig& FollowAnimPlayViewConfig,
                                                 const KGAnimPlayViewConfig& LeadingAnimPlayViewConfig)
{
	const USkeletalMeshComponent* LeadingMesh = Cast<USkeletalMeshComponent>(KGUtils::GetObjectByID(LeadingAnimPlayViewConfig.SKMeshID));
	if(LeadingMesh == nullptr || LeadingMesh->GetAnimInstance() == nullptr)
	{
		UE_LOG(RoleCompositeMgrLog, Error, TEXT("[URoleCompositeMgr::Animation]onAnimationSyncPairReady Error, Can Not Find LeadingMesh or LeadingAnimIns, ReqID:%lld"), FollowAnimPlayViewConfig.LeadingAnimPlayReqID);
		return;
	}

	const USkeletalMeshComponent* FollowMesh = Cast<USkeletalMeshComponent>(KGUtils::GetObjectByID(FollowAnimPlayViewConfig.SKMeshID));
	if(FollowMesh == nullptr || FollowMesh->GetAnimInstance() == nullptr)
	{
		UE_LOG(RoleCompositeMgrLog, Error, TEXT("[URoleCompositeMgr::Animation]onAnimationSyncPairReady Error, Can Not Find FollowMesh or FollowAnimIns, ReqID:%lld"), FollowAnimPlayViewConfig.LeadingAnimPlayReqID);
		return;
	}

	if(FollowAnimPlayViewConfig.PlayingMontage.IsValid() && LeadingAnimPlayViewConfig.PlayingMontage.IsValid())
	{
		 FollowMesh->GetAnimInstance()->MontageSync_Follow(FollowAnimPlayViewConfig.PlayingMontage.Get(), LeadingMesh->GetAnimInstance(), LeadingAnimPlayViewConfig.PlayingMontage.Get());
	}
}
#pragma endregion Animation

#pragma region ActorAppearance Asset

int32 URoleCompositeMgr::AsyncLoadAppearanceAsset(int64 UID, const TArray<FString>& Paths, const TArray<FString>& AnimConfigIDArray, const TArray<bool>& IsLocalDisplayArray, bool IsNeedResetRegisterAsset)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::AsyncLoadAppearanceAsset");
	UKGCppAssetManager* CppAssetManager = UKGCppAssetManager::GetInstance(this);
	if (!CppAssetManager)
	{
		UE_LOG(LogTemp, Error, TEXT("AsyncLoadAppearanceAsset: CppAssetManager is null"));
		return 0;
	}
	
	// 验证参数数组长度一致
	checkf(IsLocalDisplayArray.Num() == AnimConfigIDArray.Num(), TEXT("IsLocalDisplayArray.Num() != AnimConfigIDArray.Num()"));

	// 创建最终的资产路径列表
	TArray<FString> FinalPaths = Paths;
	
	// 处理动画配置
	for (int32 i = 0; i < IsLocalDisplayArray.Num(); i++)
	{
		FName ConfigID = FName(AnimConfigIDArray[i]);
		bool IsLocalDisplay = IsLocalDisplayArray[i];
		
		if (PreloadAnimDataAsset)
		{
			// 从PreloadAnimDataAsset中查找配置数据
			if (auto DataPtr = PreloadAnimDataAsset->Data.Find(ConfigID))
			{
				if (IsLocalDisplay)
				{
					// 本地显示角色：只加载默认的Locomotion动画（Idle, Blink, Arm_Additive_Max等）
					// 这些动画用于角色的基础移动和待机表现
					for (int32 j = 0; j < DataPtr->AnimTypes.Num() && j < DataPtr->AnimAssets.Num(); j++)
					{
						FName AnimType = DataPtr->AnimTypes[j];
						FName AnimAssetPath = DataPtr->AnimAssets[j];
						
						// 检查是否是本地显示角色需要的默认动画
						if (LocalDisplayCharLocomotionABPNamesDefault.Contains(AnimType))
						{
							FString AnimAssetPathStr = AnimAssetPath.ToString();
							if (!AnimAssetPathStr.IsEmpty() && !FinalPaths.Contains(AnimAssetPathStr))
							{
								FinalPaths.Add(AnimAssetPathStr);
								ROLE_COMPOSITE_MANAGER_LOG(TEXT("AsyncLoadAppearanceAsset: Added local display anim path: %s for ConfigID: %s"), 
									*AnimAssetPathStr, *ConfigID.ToString());
							}
						}
					}
				}
				else
				{
					// 非本地显示角色（远程玩家/NPC）：加载所有动画资产
					// 这些角色可能需要播放各种动画，所以需要预加载完整的动画集
					if (bool hasCache = CppAssetManager->HasAnimCacheForLocomotionABP(ConfigID))
					{
						// 有缓存的情况要锁一下资源，异步过程可能被挤出LRU
						CppAssetManager->LockLocomotionABPCache(ConfigID);
						ROLE_COMPOSITE_MANAGER_LOG(TEXT("AsyncLoadAppearanceAsset: Locked anim cache for ConfigID: %s"),
							*ConfigID.ToString());
					}
					else
					{
						// 无缓存时，加载所有动画资产
						for (int32 j = 0; j < DataPtr->AnimAssets.Num(); j++)
						{
							FName AnimAssetPath = DataPtr->AnimAssets[j];
							FString AnimAssetPathStr = AnimAssetPath.ToString();
						
							if (!AnimAssetPathStr.IsEmpty() && !FinalPaths.Contains(AnimAssetPathStr))
							{
								FinalPaths.Add(AnimAssetPathStr);
								ROLE_COMPOSITE_MANAGER_LOG(TEXT("AsyncLoadAppearanceAsset: Added non-local display anim path: %s for ConfigID: %s"), 
									*AnimAssetPathStr, *ConfigID.ToString());
							}
						}
					}
				}
			}
			else
			{
				UE_LOG(LogTemp, Error, TEXT("AsyncLoadAppearanceAsset: ConfigID %s not found in PreloadAnimDataAsset"), *ConfigID.ToString());
			}
		}
	}
	
	// 记录加载信息
	ROLE_COMPOSITE_MANAGER_LOG(TEXT("AsyncLoadAppearanceAsset: UID=%lld, Total paths to load=%d"), UID, FinalPaths.Num());

	if (FinalPaths.Num() == 0)
	{
		return 0;
	}
	// 调用异步加载
	int32 LoadId = CppAssetManager->AsyncLoadAsset(FinalPaths, FAsyncLoadListCompleteDelegate::CreateUObject(this, &URoleCompositeMgr::OnAsyncLoadAppearanceAsset, UID, IsNeedResetRegisterAsset));
	return LoadId;
}

void URoleCompositeMgr::OnAsyncLoadAppearanceAsset(int InLoadID, const TArray<UObject*>& Assets, int64 UID, bool IsNeedResetRegisterAsset)
{
	AddActorAppearanceAssetRefWithAssets(UID,Assets,IsNeedResetRegisterAsset);
	OnActorAppearanceAssetListLoadedDelegate.Broadcast(InLoadID);
}

void URoleCompositeMgr::AddActorAppearanceAssetRefWithAssets(int64 UID, const TArray<UObject*>& Assets, bool NeedReset)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::AddActorAppearanceAssetRefWithAssets");
	FPathsAssetRefMap& AssetRefMap = ActorAppearanceAssetRefMap.FindOrAdd(UID);
	if (NeedReset) {
		AssetRefMap.PathsAssetMap.Reset();
	}

	for (int32 i(0); i < Assets.Num(); ++i)
	{
		UObject* Asset = Assets[i];
		if (Asset != nullptr)
		{
			AssetRefMap.PathsAssetMap.Add(FName(Asset->GetPathName()), Asset);
		}
	}
}

void URoleCompositeMgr::AddActorAppearanceAssetRef(int64 UID, const TArray<FString>& Paths, const TArray<KGObjectID>& AssetIDs, bool NeedReset)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::AddActorAppearanceAssetRef");
	FPathsAssetRefMap& AssetRefMap = ActorAppearanceAssetRefMap.FindOrAdd(UID);

	if (NeedReset) {
		AssetRefMap.PathsAssetMap.Reset();
	}

	int32 AssetNum = Paths.Num();
	ensureAlways(AssetNum == AssetIDs.Num());
	if (AssetNum == AssetIDs.Num())
	{
		for (int32 i(0); i < AssetNum; ++i)
		{
			UObject* Asset = KGUtils::GetObjectByID(AssetIDs[i]);
			if (Asset != nullptr)
			{
				AssetRefMap.PathsAssetMap.Add(FName(Paths[i]), Asset);
			}
			else
			{
				UE_LOG(RoleCompositeMgrLog, Warning, TEXT("[URoleCompositeMgr] AddActorAppearanceAssetRef GetObjectByID Failed, Path %s"), *Paths[i]);
			}
		}
	}
}

void URoleCompositeMgr::AddActorAppearanceAssetKeepRef(int64 UID, const TArray<FName>& Paths)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::AddActorAppearanceAssetKeepRef");
	FPathsAssetRefMap& AssetRefMap = ActorAppearanceAssetKeepRefMap.FindOrAdd(UID);

	int32 AssetNum = Paths.Num();
	for (int32 i(0); i < AssetNum; ++i)
	{
		UObject* Asset = GetActorAppearanceAsset(UID, Paths[i]);
		if (Asset != nullptr)
		{
			AssetRefMap.PathsAssetMap.Add(Paths[i], Asset);
		}
		else
		{
			UE_LOG(RoleCompositeMgrLog, Error, TEXT("[URoleCompositeMgr] AddActorAppearanceAssetKeepRef Failed, Path %s"), *Paths[i].ToString());
		}
	}
}

void URoleCompositeMgr::AddActorAppearanceAssetKeepRefByPath(int64 UID, const FName& Path)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::AddActorAppearanceAssetKeepRefByPath");
	FPathsAssetRefMap& AssetRefMap = ActorAppearanceAssetKeepRefMap.FindOrAdd(UID);
	UObject* Asset = GetActorAppearanceAsset(UID, Path);
	if (Asset != nullptr)
	{
		AssetRefMap.PathsAssetMap.Add(Path, Asset);
	}
	else
	{
		UE_LOG(RoleCompositeMgrLog, Error, TEXT("[URoleCompositeMgr] AddActorAppearanceAssetKeepRefByPath Failed, Path %s"), *Path.ToString());
	}
}

void URoleCompositeMgr::RemoveActorAppearanceAssetRefByPaths(int64 UID, const TArray<FString>& Paths) {
	FPathsAssetRefMap* AssetRefMap = ActorAppearanceAssetRefMap.Find(UID);
	if (!AssetRefMap) {
		return ;
	}

	for (auto& path : Paths) {
		AssetRefMap->PathsAssetMap.Remove(FName(path));
	}
}

void URoleCompositeMgr::RemoveActorAppearanceAssetRef(int64 UID)
{
	ActorAppearanceAssetRefMap.Remove(UID);
}

void URoleCompositeMgr::RemoveActorAppearanceAssetKeepRef(int64 UID)
{
	ActorAppearanceAssetKeepRefMap.Remove(UID);
}

UObject* URoleCompositeMgr::GetActorAppearanceAsset(const int64& UID, const FName& Path, bool IsNeedError)
{
	if (Path.IsNone())
	{
		return nullptr;
	}
	
	if (FPathsAssetRefMap* AssetRefMap = ActorAppearanceAssetRefMap.Find(UID))
	{
		if (UObject** Asset = AssetRefMap->PathsAssetMap.Find(Path))
		{
			return *Asset;
		}
	}

	if (FPathsAssetRefMap* AssetRefMap = ActorAppearanceAssetKeepRefMap.Find(UID))
	{
		if (UObject** Asset = AssetRefMap->PathsAssetMap.Find(Path))
		{
			return *Asset;
		}
	}
	
	if(IsNeedError)
	{
		UE_LOG(RoleCompositeMgrLog, Error, TEXT("[URoleCompositeMgr::GetActorAppearanceAsset]: UID:%lld Cannot Find Asset Path:%s"), UID, *Path.ToString());
	}
	
	return nullptr;
}

int64 URoleCompositeMgr::GetActorAppearanceAssetID(const int64& UID, const FString& Path)
{
	UObject* Asset = GetActorAppearanceAsset(UID, FName(Path));
	return KGUtils::GetIDByObject(Asset);
}

void URoleCompositeMgr::ClearActorAppearanceAssetRef()
{
	for (auto AssetRef : ActorAppearanceAssetRefMap)
	{
		AssetRef.Value.PathsAssetMap.Reset();
	}
	ActorAppearanceAssetRefMap.Reset();

	for (auto AssetRef : ActorAppearanceAssetKeepRefMap)
	{
		AssetRef.Value.PathsAssetMap.Reset();
	}
	ActorAppearanceAssetKeepRefMap.Reset();
}
#pragma endregion ActorAppearance Asset

#pragma region ActorAppearance Lib

#pragma region ActorAppearance Lib Material

void URoleCompositeMgr::SetMaterialParameter(
	const int64& UID, UKGMaterialManager* MaterialManager, UMeshComponent* MeshComponent,
	int32 MaterialIndex, bool bOverlayMaterial, bool bSeparateOverlayMaterial, const FUECompositeMaterialData& InMeshMaterialData)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetMaterialParameter");

	if (!IsValid(MeshComponent) || !IsValid(MaterialManager))
		return;

	TMap<FName, float> ScalarParams;
	for (auto& Elem : InMeshMaterialData.Scalars)
	{
		ScalarParams.Add(Elem.Key, Elem.Value);
	}
	MaterialManager->SetRoleCompositeScalarMaterialParams(MeshComponent, MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, ScalarParams);

	TMap<FName, FLinearColor> VectorParams;
	for (auto& Elem : InMeshMaterialData.Vectors)
	{
		VectorParams.Add(Elem.Key, Elem.Value);
	}
	MaterialManager->SetRoleCompositeVectorMaterialParams(MeshComponent, MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, VectorParams);

	int32 TextureNum = InMeshMaterialData.TextureNames.Num();
	if (TextureNum == InMeshMaterialData.TexturePaths.Num())
	{
		TMap<FName, UTexture*> TextureParams;
		for (int32 i(0); i < TextureNum; ++i)
		{
			const FName& Path = InMeshMaterialData.TexturePaths[i];
			if (Path.IsNone())
				continue;

			if (UObject* ObjectPtr = GetActorAppearanceAsset(UID, Path))
			{
				if (UTexture* Tex = Cast<UTexture>(ObjectPtr))
				{
					TextureParams.Add(InMeshMaterialData.TextureNames[i], Tex);
				}
			}
		}
		MaterialManager->SetRoleCompositeTextureMaterialParams(MeshComponent, MaterialIndex, bOverlayMaterial, bSeparateOverlayMaterial, TextureParams);
	}
}

const TMap<FString, FIntVector4>& URoleCompositeMgr::GetALevelMaterialParameterCPDMap()
{
	// FIntVector4: X:Index of CPD, Y:StartBit, Z:BitLength, W: IsInt(max to W when W != 0) or Float(0)
	static const TMap<FString, FIntVector4> ALevelMaterialParameterCPDMap =
	{
		//Pattern 1
		{ "PatternColor1",  {4, 0, 24, 0} },
		{ "DetailNormalTexIndex1", {4, 24, 8, 255} },
		{ "PatternRangeColorOri1", {5, 0, 24, 0} },
		{ "DetailPatternTexIndex1", {5, 24, 8, 255} },
		{ "DetailPatternTilling1", {6, 0, 7, 64} },
		{ "DetailPatternOffsetX1", {6, 7, 5, 0} },
		{ "ClothType1", {6, 12, 2, 3} },
		{ "DetailPatternTillingRatio1", {6, 14, 2, 2} },
		{ "DetailPatternRotate1", {6, 16, 6, 0} },
		{ "DetailPatternAlpha1", {6, 22, 4, 0} },
		{ "Aniso1", {6, 26, 2, 0} },
		{ "DetailPatternRoughness1", {6, 28, 4, 0} },
		{ "DetailPatternOffsetY1", {7, 0, 5, 0} },
		{ "DetailNormalTilling1", {7, 5, 7, 54} },
		{ "DetailPatternMetallic1", {7, 12, 4, 0} },
		{ "DetailNormalTillingRatio1", {7, 16, 2, 2} },
		{ "DetailNormalRotate1", {7, 18, 5, 0} },
		{ "DetailNormalStrength1", {7, 23, 4, 0} },
		//Pattern 2
		{ "PatternColor2",  {8, 0, 24, 0} },
		{ "DetailNormalTexIndex2", {8, 24, 8, 255} },
		{ "PatternRangeColorOri2", {9, 0, 24, 0} },
		{ "DetailPatternTexIndex2", {9, 24, 8, 255} },
		{ "DetailPatternTilling2", {10, 0, 7, 64} },
		{ "DetailPatternOffsetX2", {10, 7, 5, 0} },
		{ "ClothType2", {10, 12, 2, 3} },
		{ "DetailPatternTillingRatio2", {10, 14, 2, 2} },
		{ "DetailPatternRotate2", {10, 16, 6, 0} },
		{ "DetailPatternAlpha2", {10, 22, 4, 0} },
		{ "Aniso2", {10, 26, 2, 0} },
		{ "DetailPatternRoughness2", {10, 28, 4, 0} },
		{ "DetailPatternOffsetY2", {11, 0, 5, 0} },
		{ "DetailNormalTilling2", {11, 5, 7, 54} },
		{ "DetailPatternMetallic2", {11, 12, 4, 0} },
		{ "DetailNormalTillingRatio2", {11, 16, 2, 2} },
		{ "DetailNormalRotate2", {11, 18, 5, 0} },
		{ "DetailNormalStrength2", {11, 23, 4, 0} },
		//Pattern 3
		{ "PatternColor3",  {12, 0, 24, 0} },
		{ "DetailNormalTexIndex3", {12, 24, 8, 255} },
		{ "PatternRangeColorOri3", {13, 0, 24, 0} },
		{ "DetailPatternTexIndex3", {13, 24, 8, 255} },
		{ "DetailPatternTilling3", {14, 0, 7, 64} },
		{ "DetailPatternOffsetX3", {14, 7, 5, 0} },
		{ "ClothType3", {14, 12, 2, 3} },
		{ "DetailPatternTillingRatio3", {14, 14, 2, 2} },
		{ "DetailPatternRotate3", {14, 16, 6, 0} },
		{ "DetailPatternAlpha3", {14, 22, 4, 0} },
		{ "Aniso3", {14, 26, 2, 0} },
		{ "DetailPatternRoughness3", {14, 28, 4, 0} },
		{ "DetailPatternOffsetY3", {15, 0, 5, 0} },
		{ "DetailNormalTilling3", {15, 5, 7, 54} },
		{ "DetailPatternMetallic3", {15, 12, 4, 0} },
		{ "DetailNormalTillingRatio3", {15, 16, 2, 2} },
		{ "DetailNormalRotate3", {15, 18, 5, 0} },
		{ "DetailNormalStrength3", {15, 23, 4, 0} },
		//Pattern 4
		{ "PatternColor4",  {16, 0, 24, 0} },
		{ "DetailNormalTexIndex4", {16, 24, 8, 255} },
		{ "PatternRangeColorOri4", {17, 0, 24, 0} },
		{ "DetailPatternTexIndex4", {17, 24, 8, 255} },
		{ "DetailPatternTilling4", {18, 0, 7, 64} },
		{ "DetailPatternOffsetX4", {18, 7, 5, 0} },
		{ "ClothType4", {18, 12, 2, 3} },
		{ "DetailPatternTillingRatio4", {18, 14, 2, 2} },
		{ "DetailPatternRotate4", {18, 16, 6, 0} },
		{ "DetailPatternAlpha4", {18, 22, 4, 0} },
		{ "Aniso4", {18, 26, 2, 0} },
		{ "DetailPatternRoughness4", {18, 28, 4, 0} },
		{ "DetailPatternOffsetY4", {19, 0, 5, 0} },
		{ "DetailNormalTilling4", {19, 5, 7, 54} },
		{ "DetailPatternMetallic4", {19, 12, 4, 0} },
		{ "DetailNormalTillingRatio4", {19, 16, 2, 2} },
		{ "DetailNormalRotate4", {19, 18, 5, 0} },
		{ "DetailNormalStrength4", {19, 23, 4, 0} }
	};
	return ALevelMaterialParameterCPDMap;
}

const TArray<uint32>& URoleCompositeMgr::GetALevelMaterialParameterCPDArray()
{
	static const TArray<uint32> ALevelMaterialParameterCPDArray =
	{
		// Index: 0-3 reserved
		0, 0, 0, 0
		// Pattern 1
		, 0x00307589 // 4
		, 0x00ffffff // 5
		, 0x6fc09002 // 6
		, 0x00020fe0 // 7
		// Pattern 2
		, 0x00307589 // 8
		, 0x00ffffff // 9
		, 0x6fc09002 // 10
		, 0x00020fe0 // 11
		// Pattern 3
		, 0x00307589 // 12
		, 0x00ffffff // 13
		, 0x6fc09002 // 14
		, 0x00020fe0 // 15
		// Pattern 4
		, 0x00307589 // 16
		, 0x00ffffff // 17
		, 0x6fc09002 // 18
		, 0x00020fe0 // 19
	};
	return ALevelMaterialParameterCPDArray;
}

void URoleCompositeMgr::SetALevelClothMaterialParameterByCPD(const int64& UID, UMeshComponent* MeshComponent, int32 MaterialIndex, const FUECompositeMaterialData& InMeshMaterialData)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetALevelClothMaterialParameterByCPD");
	if (!IsValid(MeshComponent))
		return;

	UE_LOG(LogTemp, Warning, TEXT("\n-----[CPD]Every CPD Data of %s in uint-----"), *MeshComponent->GetFName().ToString());
	const TMap<FString, FIntVector4>& MaterialParameterCPDMap = GetALevelMaterialParameterCPDMap();
	for (auto& Elem : InMeshMaterialData.Scalars)
	{
		FString Key = Elem.Key.ToString();
		if (!MaterialParameterCPDMap.Contains(Key))
			continue;
		const FIntVector4& CPDInfo = MaterialParameterCPDMap[Key];
		float SetValue = Elem.Value/(CPDInfo.W == 0? 1.0f : CPDInfo.W);
		MeshComponent->SetCustomPrimitiveDataBitsFloat(CPDInfo.X, CPDInfo.Y, CPDInfo.Z, SetValue);
	}

	for (auto& Elem : InMeshMaterialData.Vectors)
	{
		FString Key = Elem.Key.ToString();
		if (!GetALevelMaterialParameterCPDMap().Contains(Key))
			continue;
		const FIntVector4& CPDInfo = GetALevelMaterialParameterCPDMap()[Key];
		int32 halfLength = CPDInfo.Z / 3;
		int32 ScalarFactor = (1 << halfLength) - 1;
		FVector ColorAsVector = FVector(Elem.Value.R, Elem.Value.G, Elem.Value.B);
		MeshComponent->SetCustomPrimitiveDataBitsColorToR8G8B8(CPDInfo.X, CPDInfo.Y, CPDInfo.Z, ColorAsVector);
	}
}

void URoleCompositeMgr::SetALevelDefaultMaterialParameterByCPD(const int64& UID, UMeshComponent* MeshComponent)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetALevelDefaultMaterialParameterByCPD");
	USkeletalMeshComponent* SkeletalMeshComp = Cast<USkeletalMeshComponent>(MeshComponent);
	if (!IsValid(SkeletalMeshComp))
		return;
	
	const TArray<uint32>& DefaultCPDArray = GetALevelMaterialParameterCPDArray();
	int32 CPDArrayNum = DefaultCPDArray.Num();
	for (int32 i = 4; i < CPDArrayNum; ++i) // Index 0-3 reserved
	{
		float CPDValue;
		FMemory::Memcpy(&CPDValue, &DefaultCPDArray[i], sizeof(uint32));
		SkeletalMeshComp->SetCustomPrimitiveDataFloat(i, CPDValue);
	}

	//Make MI parameter sync with CPD
	const TMap<FString, FIntVector4>& MaterialParameterCPDMap = GetALevelMaterialParameterCPDMap();
	//SkeletalMeshComp->ResetAssetsMaterialParameters(MaterialParameterCPDMap);
}

bool URoleCompositeMgr::SetMaterialParameterFromMakeupSerializedData(const int64& UID, const KGObjectID InMeshComID, FName Tag, FName ProfileName, const TArray<uint32>& SerializedData)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetMaterialParameterFromMakeupSerializedData");
	UMeshComponent* InMeshCom = KGUtils::GetObjectByID<UMeshComponent>(InMeshComID);
	if (!ensure(IsValid(InMeshCom)))
		return false;
	
	UKGMaterialManager* MaterialMgr = UKGMaterialManager::GetInstance(this);
	if (!MaterialMgr)
		return false;
	
	AActor* Actor = InMeshCom->GetOwner();
	if (!ensure(Actor))
		return false;

	UFaceControlComponent* FaceComponent = Actor->GetComponentByClass<UFaceControlComponent>();
	if (!FaceComponent)
		return false;
	
	const UFaceProfileRuntimeSetting* Setting = UFaceControlComponent::GetFaceBoneRuntimeSettingAssetChecked();
	const TMap<FName, FMakeupRuntimeSetting>& MakeupRuntimeSetting = Setting->GetMakeupRuntimeSetting();
	if (!ensure(MakeupRuntimeSetting.Contains(ProfileName)))
		return false;
	const auto& MakeupSetting = MakeupRuntimeSetting[ProfileName].PropertyConfigs;
	
	TMap<FName, float> Scalars;
	TMap<FName, FLinearColor> Vectors;
	TMap<FName, FName> Textures;
	if (!UCustomRoleDataSerializer::DeserializeData(SerializedData, Scalars, Vectors, Textures))
		return false;

	struct KGMaterialParamCache
	{
		TMap<FName, float> ScalarParams;
		TMap<FName, FLinearColor> VectorParams;
		TMap<FName, UTexture*> TextureParams;
	};
	
	TMap<FName, KGMaterialParamCache> MaterialParams;
	for (const auto& Pair : Scalars)
	{
		const FName& PropertyName = Pair.Key;
		float PropertyValue = Pair.Value;
		if (!ensure(MakeupSetting.Contains(PropertyName)))
			continue;

		const FMakeupRuntimePropertyConfig& PropertyConfig = MakeupSetting[PropertyName];
		ensure(InMeshCom->ComponentHasTag(PropertyConfig.PartTag));
		
		PropertyValue = (PropertyConfig.MaxValue - PropertyConfig.MinValue) * PropertyValue + PropertyConfig.MinValue;
		auto& ParamsBySlotName = MaterialParams.FindOrAdd(PropertyConfig.SlotName);
		FName MaterialParameterName = PropertyConfig.MaterialPropertyName;
		
		if (PropertyConfig.CaptureMaterialIndex == 0 || PropertyConfig.bBothApplyToFace)
			ParamsBySlotName.ScalarParams.Add(MaterialParameterName, PropertyValue);

		// Capture Material Parameters
		if (PropertyConfig.CaptureMaterialIndex > 0)
			FaceComponent->SetScalarParameterValueByCompositeIndex(PropertyConfig.CaptureMaterialIndex, MaterialParameterName, PropertyValue);		

		// Record OtherPartsAndSlot Data
		if (PropertyConfig.OtherParts.Num() > 0 && ensure(PropertyConfig.OtherParts.Num() == PropertyConfig.OtherSlots.Num()))
		{
			for (int i = 0; i < PropertyConfig.OtherParts.Num(); ++i)
			{
				FaceComponent->AddScalarOtherPartAndSlots(PropertyConfig.OtherParts[i], PropertyConfig.OtherSlots[i], MaterialParameterName, PropertyValue);
			}
		}
	}

	for (const auto& Pair : Vectors)
	{
		const FName& PropertyName = Pair.Key;
		const FLinearColor& PropertyValue = Pair.Value;
		if (!ensure(MakeupSetting.Contains(PropertyName)))
			continue;

		const FMakeupRuntimePropertyConfig& PropertyConfig = MakeupSetting[PropertyName];
		ensure(InMeshCom->ComponentHasTag(PropertyConfig.PartTag));
		
		auto& ParamsBySlotName = MaterialParams.FindOrAdd(PropertyConfig.SlotName);
		FName MaterialParameterName = PropertyConfig.MaterialPropertyName;
		
		if (PropertyConfig.CaptureMaterialIndex == 0 || PropertyConfig.bBothApplyToFace)
			ParamsBySlotName.VectorParams.Add(MaterialParameterName, PropertyValue);

		// Capture Material Parameters
		if (PropertyConfig.CaptureMaterialIndex > 0)
			FaceComponent->SetVectorParameterValueByCompositeIndex(PropertyConfig.CaptureMaterialIndex, MaterialParameterName, PropertyValue);		

		// Record OtherPartsAndSlot Data
		if (PropertyConfig.OtherParts.Num() > 0 && ensure(PropertyConfig.OtherParts.Num() == PropertyConfig.OtherSlots.Num()))
		{
			for (int i = 0; i < PropertyConfig.OtherParts.Num(); ++i)
			{
				FaceComponent->AddVectorOtherPartAndSlots(PropertyConfig.OtherParts[i], PropertyConfig.OtherSlots[i], MaterialParameterName, PropertyValue);
			}
		}
	}

	for (const auto& Pair : Textures)
	{
		const FName& PropertyName = Pair.Key;
		const FName& PropertyValue = Pair.Value;
		if (!ensure(MakeupSetting.Contains(PropertyName)))
			continue;

		const FMakeupRuntimePropertyConfig& PropertyConfig = MakeupSetting[PropertyName];
		ensure(InMeshCom->ComponentHasTag(PropertyConfig.PartTag));

		FName MaterialPropertyName = PropertyConfig.MaterialPropertyName;
		
		// Capture Material Parameters
		if (PropertyConfig.CaptureMaterialIndex > 0)
		{
			FaceComponent->SetTextureParameterValueByCompositeIndex(PropertyConfig.CaptureMaterialIndex, MaterialPropertyName, PropertyValue.ToString());
		}		

		// Record OtherPartsAndSlot Data
		if (PropertyConfig.OtherParts.Num() > 0 && ensure(PropertyConfig.OtherParts.Num() == PropertyConfig.OtherSlots.Num()))
		{
			for (int i = 0; i < PropertyConfig.OtherParts.Num(); ++i)
			{
				FaceComponent->AddTextureOtherPartAndSlots(PropertyConfig.OtherParts[i], PropertyConfig.OtherSlots[i], MaterialPropertyName, PropertyValue);
			}
		}
		
		if (UTexture* Tex = Cast<UTexture>(GetActorAppearanceAsset(UID, PropertyValue)))
		{
			auto& ParamsBySlotName = MaterialParams.FindOrAdd(PropertyConfig.SlotName);
			if (PropertyConfig.CaptureMaterialIndex == 0 || PropertyConfig.bBothApplyToFace)
				ParamsBySlotName.TextureParams.Add(MaterialPropertyName, Tex);
		}
	}

	for (const auto& Kvp : MaterialParams)
	{
		const auto& SlotName = Kvp.Key;
		TArray<int32> MaterialIndices = GetMaterialIndicesBySlotName(InMeshComID, SlotName);
		for (const int32 Index : MaterialIndices)
		{
			MaterialMgr->SetRoleCompositeScalarMaterialParams(InMeshCom, Index, false, false, Kvp.Value.ScalarParams);
			MaterialMgr->SetRoleCompositeVectorMaterialParams(InMeshCom, Index, false, false, Kvp.Value.VectorParams);
			MaterialMgr->SetRoleCompositeTextureMaterialParams(InMeshCom, Index, false, false, Kvp.Value.TextureParams);
		}
	}

	// GFur 单独处理, 大部分角色不会跑到.
	const TArray<TObjectPtr<USceneComponent>>& AttachChildren = InMeshCom->GetAttachChildren();
	if (AttachChildren.Num() > 0)
	{
		const FName GFurTag = FName(TEXT("Decoration_") + Tag.ToString());
		if (const TObjectPtr<USceneComponent>* ChildComponent = AttachChildren.FindByPredicate([GFurTag](const USceneComponent* Child)
		{
			return Child->IsA<UGFurComponent>() &&
				Child->ComponentHasTag(GFurTag);
		}))
		{
			UGFurComponent* GFurComponent = Cast<UGFurComponent>(*ChildComponent);
			SetMaterialParameterForGFur(UID, GFurComponent, GFurTag, MakeupSetting, Scalars, Vectors, Textures);
		}
	}
	
	return true;
}

void URoleCompositeMgr::SetMaterialParameterForGFur(const int64& UID, UGFurComponent* GFurComponent, const FName& Tag, const TMap<FName, FMakeupRuntimePropertyConfig>& PropertyConfigs,
	const TMap<FName, float>& Scalars, const TMap<FName, FLinearColor>& Vectors, const TMap<FName, FName>& Textures)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetMaterialParameterForGFur");	
	if (!ensure(GFurComponent))
		return;

	AActor* Actor = GFurComponent->GetOwner();
	if (!Actor)
		return;

	UKGMaterialManager* MaterialMgr = UKGMaterialManager::GetInstance(this);
	if (!MaterialMgr)
		return;

	// 拿材质索引
	TMap<FName, TMap<FName, int32>> MaterialIndex;
	auto GetMaterialSlotIndex = [&MaterialIndex, GFurComponent](const FName& InTag, const FName& SlotName) -> int32
	{
		if (const TMap<FName, int32>* Map = MaterialIndex.Find(InTag))
		{
			if (const int32* Index = Map->Find(SlotName))
				return *Index;
			return MaterialIndex[InTag].Add(SlotName, GFurComponent->GetMaterialIndex(SlotName));
		}
		int32 Index = GFurComponent->GetMaterialIndex(SlotName);
		MaterialIndex.Add(InTag, TMap<FName, int32>{{SlotName, Index}});
		return Index;
	};

	// 拿其他GFur组件
	UGFurComponent* OtherGFur = nullptr;
	FName OtherTag;
	TMap<FName, UGFurComponent*> GFurComponents;
	auto GetGFurComponent = [&Actor, &OtherGFur, &OtherTag, &GFurComponents](const FName& InTag) -> bool
	{
		OtherTag = FName(TEXT("Decoration_") + InTag.ToString());
		if (UGFurComponent** GFur = GFurComponents.Find(InTag))
		{
			OtherGFur = *GFur;
			return true;
		}
		
		TArray<UActorComponent*> Components = Actor->GetComponentsByTag(UGFurComponent::StaticClass(), OtherTag);
		if (Components.Num() > 0)
		{
			OtherGFur = GFurComponents.Add(InTag, Cast<UGFurComponent>(Components[0]));
			return true;
		}
		return false;
	};
	
	for (const auto& Pair : Scalars)
	{
		const FName& PropertyName = Pair.Key;
		float PropertyValue = Pair.Value;
		if (!ensure(PropertyConfigs.Contains(PropertyName)))
			continue;

		const FMakeupRuntimePropertyConfig& PropertyConfig = PropertyConfigs[PropertyName];
		PropertyValue = (PropertyConfig.MaxValue - PropertyConfig.MinValue) * PropertyValue + PropertyConfig.MinValue;
		
		MaterialMgr->SetRoleCompositeScalarMaterialParam(GFurComponent, GetMaterialSlotIndex(Tag, PropertyConfig.MaterialPropertyName),
			false, false, PropertyName, PropertyValue);
		
		if (PropertyConfig.OtherParts.Num() > 0 && ensure(PropertyConfig.OtherParts.Num() == PropertyConfig.OtherSlots.Num()))
		{
			for (int i = 0; i < PropertyConfig.OtherParts.Num(); ++i)
			{
				if (GetGFurComponent(PropertyConfig.OtherParts[i]))
				{
					MaterialMgr->SetRoleCompositeScalarMaterialParam(OtherGFur, GetMaterialSlotIndex(OtherTag, PropertyConfig.OtherSlots[i]),
						false, false, PropertyName, PropertyValue);
				}
			}
		}
	}

	for (const auto& Pair : Vectors)
	{
		const FName& PropertyName = Pair.Key;
		const FLinearColor& PropertyValue = Pair.Value;
		if (!ensure(PropertyConfigs.Contains(PropertyName)))
			continue;

		const FMakeupRuntimePropertyConfig& PropertyConfig = PropertyConfigs[PropertyName];
		MaterialMgr->SetRoleCompositeVectorMaterialParam(GFurComponent, GetMaterialSlotIndex(Tag, PropertyConfig.MaterialPropertyName),
			false, false, PropertyName, PropertyValue);

		if (PropertyConfig.OtherParts.Num() > 0 && ensure(PropertyConfig.OtherParts.Num() == PropertyConfig.OtherSlots.Num()))
		{
			for (int i = 0; i < PropertyConfig.OtherParts.Num(); ++i)
			{
				if (GetGFurComponent(PropertyConfig.OtherParts[i]))
				{
					MaterialMgr->SetRoleCompositeVectorMaterialParam(OtherGFur, GetMaterialSlotIndex(OtherTag, PropertyConfig.OtherSlots[i]),
						false, false, PropertyName, PropertyValue);
				}
			}
		}
	}

	for (const auto& Pair : Textures)
	{
		const FName& PropertyName = Pair.Key;
		const FName& PropertyValue = Pair.Value;
		if (!ensure(PropertyConfigs.Contains(PropertyName)))
			continue;

		const FMakeupRuntimePropertyConfig& PropertyConfig = PropertyConfigs[PropertyName];
		if (UTexture* Tex = Cast<UTexture>(GetActorAppearanceAsset(UID, PropertyValue)))
		{
			MaterialMgr->SetRoleCompositeTextureMaterialParam(GFurComponent, GetMaterialSlotIndex(Tag, PropertyConfig.MaterialPropertyName),
				false, false, PropertyName, Tex);
			if (PropertyConfig.OtherParts.Num() > 0 && ensure(PropertyConfig.OtherParts.Num() == PropertyConfig.OtherSlots.Num()))
			{
				for (int i = 0; i < PropertyConfig.OtherParts.Num(); ++i)
				{
					if (GetGFurComponent(PropertyConfig.OtherParts[i]))
					{
						MaterialMgr->SetRoleCompositeTextureMaterialParam(OtherGFur, GetMaterialSlotIndex(OtherTag, PropertyConfig.OtherSlots[i]),
							false, false, PropertyName, Tex);
					}
				}
			}
		}
	}	
}

void URoleCompositeMgr::SetTextureIDPaths(const TMap<int32, FName>& TextureIDPaths)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetTextureIDPaths");
	UFaceProfileRuntimeSetting* RuntimeSetting = UFaceControlComponent::GetFaceBoneRuntimeSettingAssetChecked();
	RuntimeSetting->IndexToTexturePath = TextureIDPaths;
	RuntimeSetting->TexturePathToIndex.Reset();
	for (const TPair<int32, FName>& Pair : TextureIDPaths)
	{
		RuntimeSetting->TexturePathToIndex.Add(Pair.Value, Pair.Key);
	}
}

void URoleCompositeMgr::ClearFaceControlComponentCompositeData(const KGObjectID ActorID)
{
	AActor* Actor = KGUtils::GetObjectByID<AActor>(ActorID);
	if (!Actor)
		return;

	UFaceControlComponent* FaceControlComponent = Actor->FindComponentByClass<UFaceControlComponent>();
	if (!FaceControlComponent)
		return;

	FaceControlComponent->ClearCompositeData();
}

bool URoleCompositeMgr::AddGFurOtherPartAndSlotsByID(const KGObjectID FaceControlComponentID, int id)
{
	if (!IsValid(AvatarModelPartLibPtr)) return false;
	const auto* PartSlotPtr = AvatarModelPartLibPtr->GFurOtherPartAndSlots.Find(id);
	if (!PartSlotPtr) return false;
	return AddOtherPartAndSlots(FaceControlComponentID,*PartSlotPtr);
}

bool URoleCompositeMgr::AddOtherPartAndSlotsByID(const KGObjectID FaceControlComponentID, int id)
{
	if (!IsValid(AvatarModelPartLibPtr)) return false;
	const auto* PartSlotPtr = AvatarModelPartLibPtr->OtherPartAndSlots.Find(id);
	if (!PartSlotPtr) return false;
	return AddOtherPartAndSlots(FaceControlComponentID,*PartSlotPtr);
}

bool URoleCompositeMgr::AddOtherPartAndSlots(const KGObjectID FaceControlComponentID, const FUECompositeOtherPartAndSlotsData& Data)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::AddOtherPartAndSlots");

	UFaceControlComponent* FaceControlComponent = KGUtils::GetObjectByID<UFaceControlComponent>(FaceControlComponentID);
	if (!ensure(FaceControlComponent))
		return false;

	if (Data.CompositeOtherPartAndSlotsDataMap.Num() > 0)
	{
		FaceControlComponent->bIsPartAndSlotsDataDirty = true;	
	}
	
	TMap<FName, FUECompositeMeshMaterialData>& CacheData = FaceControlComponent->CachedPartAndSlotsData;
	for (const auto& Pair : Data.CompositeOtherPartAndSlotsDataMap)
	{
		if (!CacheData.Contains(Pair.Key))
		{
			CacheData.Add(Pair.Key, Pair.Value);
			continue;
		}

		auto& InnerData = CacheData[Pair.Key].CompositeMeshMaterialDataMap;
		for (const auto& Pair2 : Pair.Value.CompositeMeshMaterialDataMap)
		{
			FUECompositeMaterialData InValue = Pair2.Value;
			if (!InnerData.Contains(Pair2.Key))
			{
				InnerData.Add(Pair2.Key, InValue);
				continue;
			}
			
			FUECompositeMaterialData& FinalData = InnerData[Pair2.Key];
			
			FinalData.Scalars.Append(InValue.Scalars);
			FinalData.Vectors.Append(InValue.Vectors);
			if (!ensure(InValue.TextureNames.Num() == InValue.TexturePaths.Num()))
				continue;

			// 不要慌, 数据量很小!
			for (int i = 0; i < InValue.TextureNames.Num(); i++)
			{
				const int32 Index = FinalData.TextureNames.IndexOfByKey(InValue.TextureNames[i]);
				if (Index != INDEX_NONE)
				{
					FinalData.TextureNames[Index] = InValue.TextureNames[i];
				}
				else
				{
					FinalData.TextureNames.Add(InValue.TextureNames[i]);
					FinalData.TexturePaths.Add(InValue.TexturePaths[i]);
				}
			}
		}
	}
	
	return true;
}

bool URoleCompositeMgr::ApplyOtherPartAndSlots(const int64& UID, const KGObjectID ActorID, const FName& OnlyPartTag, bool bForce)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::ApplyOtherPartAndSlots");
	AActor* Actor = KGUtils::GetObjectByID<AActor>(ActorID);
	if (!Actor)
		return false;

	UFaceControlComponent* FaceControlComponent = Actor->FindComponentByClass<UFaceControlComponent>();
	if (!FaceControlComponent)
		return false;
	
	//Mark everyone render state dirty
	TInlineComponentArray<USkinnedMeshComponent*> SkinnedMeshComps;
	Actor->GetComponents(SkinnedMeshComps);
	for (auto SkinnedMeshComp : SkinnedMeshComps)
	{
		SkinnedMeshComp->MarkRenderStateDirty();
	}

	if (!FaceControlComponent->bIsPartAndSlotsDataDirty && !bForce)
		return true;
	
	FaceControlComponent->bIsPartAndSlotsDataDirty = false;

	UKGMaterialManager* MaterialMgr = UKGMaterialManager::GetInstance(this);
	if (!MaterialMgr)
		return false;

	const FName GFurPartTag = FName(TEXT("Decoration_") + OnlyPartTag.ToString());

	// 复杂度有点高, 但是实际数据量很小.
	for (auto Pair : FaceControlComponent->CachedPartAndSlotsData)
	{
		const FName& PartTag = Pair.Key;

		if (!OnlyPartTag.IsNone() && OnlyPartTag != PartTag && GFurPartTag != PartTag)
			continue;
		
		UMeshComponent* MeshComponent = Actor->FindComponentByTag<UMeshComponent>(PartTag);
		if (!MeshComponent) // 没有找到对应的 Part Mesh Component 也是正常的
			continue;

		for (auto Pair2 : Pair.Value.CompositeMeshMaterialDataMap)
		{
			const FName& SlotName = Pair2.Key;
			const int32 MaterialIndex = MeshComponent->GetMaterialIndex(SlotName);
			SetMaterialParameter(UID, MaterialMgr, MeshComponent, MaterialIndex, false, false, Pair2.Value);

			if (Pair2.Value.TexturePaths.Num() > 0)
			{
				AddActorAppearanceAssetKeepRef(UID , Pair2.Value.TexturePaths);
			}
		}
	}
	
	return true;
}

void URoleCompositeMgr::LoadNPCSuitLib()
{
	if (NPCSuitLibPtr == nullptr)
	{
		FSoftObjectPath AssetRef(ModelPartLibRootPath + TEXT("/NPCSuitLibMakeupData.NPCSuitLibMakeupData"));
		UObject* Loaded = AssetRef.TryLoad();
		NPCSuitLibPtr = Cast<UNpcMeshMaterialDataAsset>(Loaded);
	}
}

void URoleCompositeMgr::RemoveAvatarModelLibMakeupMesh(int Key) const
{
	if (IsValid(AvatarModelPartLibPtr))
	{
		AvatarModelPartLibPtr->MakeupDataV2.Remove(Key);
	}
}

void URoleCompositeMgr::RemoveAvatarModelLibGFurMesh(int Key) const
{
	if (IsValid(AvatarModelPartLibPtr))
	{
		AvatarModelPartLibPtr->GFurData.Remove(Key);
	}
}

void URoleCompositeMgr::RemoveAvatarModelLibCaptureData(int Key) const
{
	if (IsValid(AvatarModelPartLibPtr))
	{
		AvatarModelPartLibPtr->CaptureData.Remove(Key);
	}
}

void URoleCompositeMgr::RemoveAvatarModelLibOtherPartAndSlotsData(int Key) const
{
	if (IsValid(AvatarModelPartLibPtr))
	{
		AvatarModelPartLibPtr->OtherPartAndSlots.Remove(Key);
	}
}

void URoleCompositeMgr::RemoveAvatarModelLibGFurOtherPartAndSlots(int Key) const
{
	if (IsValid(AvatarModelPartLibPtr))
	{
		AvatarModelPartLibPtr->GFurOtherPartAndSlots.Remove(Key);
	}
}

void URoleCompositeMgr::RemoveNPCSuit(const FString& Key) const
{
	if (IsValid(NPCSuitLibPtr))
	{
		NPCSuitLibPtr->OtherPartAndSlots.Remove(*Key);
	}
}

void URoleCompositeMgr::RemoveNPCAsset(const FString& Key) const
{
	if (IsValid(NPCAssetLibPtr))
	{
		NPCAssetLibPtr->OtherPartAndSlots.Remove(*Key);
	}
}

void URoleCompositeMgr::AddAvatarModelLibMakeupMesh(int Key, const FUECompositeMeshMaterialData& Data) const
{
	if (IsValid(AvatarModelPartLibPtr))
	{
		AvatarModelPartLibPtr->MakeupDataV2.Add(Key, Data);
	}
}

void URoleCompositeMgr::AddAvatarModelLibGFurMesh(int Key, const FUECompositeMeshMaterialData& Data) const
{
	if (IsValid(AvatarModelPartLibPtr))
	{
		AvatarModelPartLibPtr->GFurData.Add(Key, Data);
	}
}

void URoleCompositeMgr::AddAvatarModelLibCaptureData(int Key, const FUECompositeCaptureMaterialData& Data) const
{
	if (IsValid(AvatarModelPartLibPtr))
	{
		AvatarModelPartLibPtr->CaptureData.Add(Key, Data);
	}
}

void URoleCompositeMgr::AddAvatarModelLibOtherPartAndSlotsData(int Key, const FUECompositeOtherPartAndSlotsData& Data) const
{
	if (IsValid(AvatarModelPartLibPtr))
	{
		AvatarModelPartLibPtr->OtherPartAndSlots.Add(Key, Data);
	}
}

void URoleCompositeMgr::AddAvatarModelLibGFurOtherPartAndSlots(int Key, const FUECompositeOtherPartAndSlotsData& Data) const
{
	if (IsValid(AvatarModelPartLibPtr))
	{
		AvatarModelPartLibPtr->GFurOtherPartAndSlots.Add(Key, Data);
	}
}

void URoleCompositeMgr::AddNPCSuit(const FString& Key, const FUECompositeMeshMaterialData& Data) const
{
	if (IsValid(NPCSuitLibPtr))
	{
		NPCSuitLibPtr->OtherPartAndSlots.Add(*Key,Data);
	}
}

void URoleCompositeMgr::AddNPCAsset(const FString& Key, const FUECompositeMeshMaterialData& Data) const
{
	if (IsValid(NPCAssetLibPtr))
	{
		NPCAssetLibPtr->OtherPartAndSlots.Add(*Key,Data);
	}
}

void URoleCompositeMgr::LoadNPCAssetLib()
{
	if (NPCAssetLibPtr == nullptr)
	{
		FSoftObjectPath AssetRef(ModelPartLibRootPath + TEXT("/NPCAssetLibMakeup.NPCAssetLibMakeup"));
		UObject* Loaded = AssetRef.TryLoad();
		NPCAssetLibPtr = Cast<UNpcMeshMaterialDataAsset>(Loaded);
	}
}

void URoleCompositeMgr::LoadAllDataAsset()
{
	if (AvatarModelPartLibPtr == nullptr)
	{
		FSoftObjectPath AssetRef(ModelPartLibRootPath + TEXT("/AvatarModelPartLib.AvatarModelPartLib"));
		UObject* Loaded = AssetRef.TryLoad();
		AvatarModelPartLibPtr = Cast<UCompositeMaterialDataAsset>(Loaded);
	}
    if (PreloadAnimDataAsset == nullptr)
    {
        FSoftObjectPath AssetRef(ModelPartLibRootPath + TEXT("/AnimLibPreloadData.AnimLibPreloadData"));
        UObject* Loaded = AssetRef.TryLoad();
        PreloadAnimDataAsset = Cast<UPreloadAnimDataAsset>(Loaded);
    }
	LoadNPCAssetLib();
	LoadNPCSuitLib();
}

void URoleCompositeMgr::UnloadAllDataAsset()
{
	AvatarModelPartLibPtr = nullptr;
	NPCAssetLibPtr = nullptr;
	NPCSuitLibPtr = nullptr;
}

void URoleCompositeMgr::SetMakeupMeshMaterialParameter(const int64& UID, const KGObjectID InMeshComID, int MakeupID, const bool bCPDSet)
{
	if (!IsValid(AvatarModelPartLibPtr)) return;

	if (bCPDSet)
	{
		UMeshComponent* InMeshCom = KGUtils::GetObjectByID<UMeshComponent>(InMeshComID);
		if (!IsValid(InMeshCom))
			return;
		SetALevelDefaultMaterialParameterByCPD(UID, InMeshCom);
	}

	const auto* PartSlotPtr = AvatarModelPartLibPtr->MakeupDataV2.Find(MakeupID);
	if (!PartSlotPtr) return ;
	SetMeshMaterialParameter(UID,InMeshComID,*PartSlotPtr, bCPDSet);
}

void URoleCompositeMgr::SetNPCMeshMaterialParameter(const int64& UID, const KGObjectID InMeshComID, FString Key, const bool bCPDSet)
{
	FUECompositeMeshMaterialData* MeshMaterialData;
	if (Key.StartsWith(TEXT("ASSET")))
	{
		if (!IsValid(NPCAssetLibPtr)) return ;
		MeshMaterialData = NPCAssetLibPtr->OtherPartAndSlots.Find(*Key);
	}
	else
	{
		if (!IsValid(NPCSuitLibPtr)) return ;
		MeshMaterialData = NPCSuitLibPtr->OtherPartAndSlots.Find(*Key);
	}
	if (!MeshMaterialData) return ;
	
	if (bCPDSet)
	{
		UMeshComponent* InMeshCom = KGUtils::GetObjectByID<UMeshComponent>(InMeshComID);
		if (!IsValid(InMeshCom))
			return;
		SetALevelDefaultMaterialParameterByCPD(UID, InMeshCom);
	}

	SetMeshMaterialParameter(UID,InMeshComID,*MeshMaterialData, bCPDSet);
}

void URoleCompositeMgr::SetGFurMeshMaterialParameter(const int64& UID, const KGObjectID InMeshComID, int MakeupID, const bool bCPDSet)
{
	if (!IsValid(AvatarModelPartLibPtr)) return;
	const auto* PartSlotPtr = AvatarModelPartLibPtr->GFurData.Find(MakeupID);
	if (!PartSlotPtr) return ;

	if (bCPDSet)
	{
		UMeshComponent* InMeshCom = KGUtils::GetObjectByID<UMeshComponent>(InMeshComID);
		if (!IsValid(InMeshCom))
			return;
		SetALevelDefaultMaterialParameterByCPD(UID, InMeshCom);
	}

	SetMeshMaterialParameter(UID,InMeshComID,*PartSlotPtr, bCPDSet);
}

void URoleCompositeMgr::SetMeshMaterialParameter(const int64& UID, const KGObjectID InMeshComID, const FUECompositeMeshMaterialData& InMeshMaterialData,const bool bCPDSet)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetMeshMaterialParameter");
	UMeshComponent* InMeshCom = KGUtils::GetObjectByID<UMeshComponent>(InMeshComID);
	if (!IsValid(InMeshCom))
		return;

	UKGMaterialManager* MaterialMgr = UKGMaterialManager::GetInstance(this);
	if (!MaterialMgr)
		return;

	for (auto& MaterialsData : InMeshMaterialData.CompositeMeshMaterialDataMap)
	{
		TArray<int32> MaterialIndicesBySlotName = GetMaterialIndicesBySlotName(InMeshComID, MaterialsData.Key);
		if (bCPDSet && MaterialsData.Key == FName("ClothA"))
		{
			for (int32 MaterialIndex : MaterialIndicesBySlotName)
			{
				SetALevelClothMaterialParameterByCPD(UID, InMeshCom, MaterialIndex, MaterialsData.Value);
			}
		}
		else
		{
			for (int32 MaterialIndex : MaterialIndicesBySlotName)
			{
				SetMaterialParameter(UID, MaterialMgr, InMeshCom, MaterialIndex, false, false, MaterialsData.Value);
			}
		}
	}
}

bool URoleCompositeMgr::GetNPCUpperAndLowerBodyColor(const FName Suit,FLinearColor& UpperColor,FLinearColor& LowerColor) const
{
	FUECompositeMeshMaterialData* Keys = nullptr;
    if (IsValid(NPCSuitLibPtr))
    {
        Keys = NPCSuitLibPtr->OtherPartAndSlots.Find(Suit);
    }
    if (!Keys)
    {
        if (IsValid(NPCSuitLibPtr))
        {
            Keys = NPCSuitLibPtr->OtherPartAndSlots.Find(Suit);
        }
    }
	if (Keys)
	{
		if (const auto Value = Keys->CompositeMeshMaterialDataMap.Find("Cloth"))
		{
			if (const auto UPPtr = Value->Vectors.Find("ColorA"))
			{
				UpperColor = *UPPtr;
			}

			if (const auto LowPtr = Value->Vectors.Find("ColorC"))
			{
				LowerColor = *LowPtr;
			}
			return true;
		}
	}
	return false;
}


void URoleCompositeMgr::ResetAllMIDMaterialByCPDByPath(const int64& UID, const int64& OwnerActorID, FName key,bool isSuit)
{
    // 等旧资源清理后合并为一项
	FNameArrayWrapper* keys;
	if (isSuit)
	{
		if (!IsValid(NPCSuitLibPtr)) return;
		keys = NPCSuitLibPtr->OtherPartAndSlotsUEStructMap.Find(key);
	}
	else
	{
		if (!IsValid(NPCAssetLibPtr)) return;
		keys = NPCAssetLibPtr->OtherPartAndSlotsUEStructMap.Find(key);
	}
    
	if (keys)
	{
		FUECompositeOtherPartAndSlotsData data;
		for (auto name : keys->Names)
		{
		    FUECompositeMeshMaterialData* ans;
		    FString newkey = key.ToString();
		    newkey.Append(name.ToString());
		    if (isSuit)
		    {
		        newkey = "SUIT" + newkey;
		        ans = NPCSuitLibPtr->OtherPartAndSlots.Find(*newkey);
		    }
		    else
		    {
		        newkey = "Asset" + newkey;
		        ans = NPCAssetLibPtr->OtherPartAndSlots.Find(*newkey);
		    }
		    if (ans)
		    {
			    data.CompositeOtherPartAndSlotsDataMap.Add(name,*ans);
		    }
		}
		ResetAllMIDMaterialByCPD(UID, OwnerActorID, data);
	}
}

//BEGIN ADD BY hechengang03@kuaishou.com
void URoleCompositeMgr::ResetAllMIDMaterialByCPD(const int64& UID, const int64& OwnerActorID, const FUECompositeOtherPartAndSlotsData& Data)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::ResetAllMIDMaterialByCPD");
	AActor* OwnerActor = Cast<AActor>(KGUtils::GetObjectByID(OwnerActorID));
	if (!ensure(OwnerActor))
	{
		return;
	}

	//染色
	for (const TPair<FName, FUECompositeMeshMaterialData>& Item : Data.CompositeOtherPartAndSlotsDataMap)
	{
		const FName& MeshTag = Item.Key;
		if (MeshTag == TEXT("Head") || MeshTag == TEXT("Hair"))
		{
			continue;
		}

		const TMap<FName, FUECompositeMaterialData>& MeshMaterialDataMap = Item.Value.CompositeMeshMaterialDataMap;

		TArray<UActorComponent*> Components = OwnerActor->GetComponentsByTag(USkeletalMeshComponent::StaticClass(), MeshTag);
		if (Components.Num())
		{
			USkeletalMeshComponent* SkeletalMeshComp = Cast<USkeletalMeshComponent>(Components[0]);

			//Revert all MID Material
			for (int32 MaterialIndex = 0; MaterialIndex < SkeletalMeshComp->OverrideMaterials.Num(); MaterialIndex++)
			{
				SkeletalMeshComp->SetMaterial(MaterialIndex, nullptr);
			}
			//SkeletalMeshComp->SetAllowAnimCurveEvaluation(false);

			//set CPD parameter
			for (const TPair<FName, FUECompositeMaterialData>& MeshMaterialDataIt : MeshMaterialDataMap)
			{
				const FUECompositeMaterialData& MeshMaterialData = MeshMaterialDataIt.Value;
				for (const TPair<FName, float>& ScalarParam : MeshMaterialData.Scalars)
				{
					SkeletalMeshComp->SetScalarParameterForCustomPrimitiveData(ScalarParam.Key, ScalarParam.Value);
				}
				for (const TPair<FName, FLinearColor>& VectorParam : MeshMaterialData.Vectors)
				{
					FString NewVectorParaString = VectorParam.Key.ToString();
					NewVectorParaString += "_CPD";
					FName NewParaName(*NewVectorParaString);
					SkeletalMeshComp->SetVectorParameterForCustomPrimitiveData(NewParaName, VectorParam.Value);
				}
			}
		}
	}

	//肤色同步
	UFaceControlComponent* FaceControlComponent = OwnerActor->FindComponentByClass<UFaceControlComponent>();
	if (!ensure(FaceControlComponent))
	{
		return;
	}

	UKGMaterialManager* MaterialMgr = UKGMaterialManager::GetInstance(this);
	if (!MaterialMgr)
	{
		return;
	}

	const FName GFurPartTag = TEXT("Decoration_");

	// 复杂度有点高, 但是实际数据量很小.
	for (auto Pair : FaceControlComponent->CachedPartAndSlotsData)
	{
		const FName& PartTag = Pair.Key;

		UMeshComponent* MeshComponent = OwnerActor->FindComponentByTag<UMeshComponent>(PartTag);
		if (!MeshComponent) // 没有找到对应的 Part Mesh Component 也是正常的
			continue;

		for (auto MaterialsData : Pair.Value.CompositeMeshMaterialDataMap)
		{
			const FName& SlotName = MaterialsData.Key;
			const FUECompositeMaterialData& InMeshMatData = MaterialsData.Value;

			const TMap<FName, float>& ScalarParams = InMeshMatData.Scalars;
			const TMap<FName, FLinearColor>& VectorParams = InMeshMatData.Vectors;

			for (const auto ScalarParam : ScalarParams)
			{
				MeshComponent->SetScalarParameterForCustomPrimitiveData(ScalarParam.Key, ScalarParam.Value);
			}
			for (const auto VectorParam : VectorParams)
			{
				FString CPDVecParamString = VectorParam.Key.ToString() + "_CPD";
				FName CPDVecParamName(*CPDVecParamString);
				MeshComponent->SetVectorParameterForCustomPrimitiveData(CPDVecParamName, VectorParam.Value);
			}
		}
	}
}

void URoleCompositeMgr::SetHeadHighlightMaterial(const int64& UID, const int64& OwnerActorID, const FString& ResourceName)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetHeadHighlightMaterial");
	AActor* OwnerActor = Cast<AActor>(KGUtils::GetObjectByID(OwnerActorID));
	if (!ensure(OwnerActor))
	{
		return;
	}
	//Load Specific Highlight Material
	UMaterialInterface* Mat = LoadObject<UMaterialInterface>(nullptr, *ResourceName);
	if (Mat == nullptr)
	{
		return;
	}
	const FName MeshTag = TEXT("Head");
	TArray<UActorComponent*> Components = OwnerActor->GetComponentsByTag(USkeletalMeshComponent::StaticClass(), MeshTag);
	if (Components.Num())
	{
		USkeletalMeshComponent* SkeletalMeshComp = Cast<USkeletalMeshComponent>(Components[0]);
		USkeletalMesh* Mesh = SkeletalMeshComp->GetSkeletalMeshAsset();
		if (IsValid(Mesh))
		{
			for (int32 MaterialIndex = 0; MaterialIndex < Mesh->GetMaterials().Num(); MaterialIndex++)
			{
				SkeletalMeshComp->SetMaterial(MaterialIndex, Mat ? Mat : nullptr);
			}
		}
	}
}
//END ADD BY hechengang03@kuaishou.com

TArray<int32> URoleCompositeMgr::GetMaterialIndicesBySlotName(const KGObjectID MeshComponentID, const FName SlotName, bool bSeparateOverlay)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::GetMaterialIndicesBySlotName");
	UMeshComponent* MeshComponent = KGUtils::GetObjectByID<UMeshComponent>(MeshComponentID);
	TArray<int32> Results;
	if (ensure(MeshComponent != nullptr))
	{
		if (MeshComponent->IsA<USkinnedMeshComponent>())
		{
			const USkinnedMeshComponent* SkinnedMeshComponent = Cast<USkinnedMeshComponent>(MeshComponent);
			if (SkinnedMeshComponent->GetSkinnedAsset())
			{
				const TArray<FSkeletalMaterial>& SkeletalMaterials = !bSeparateOverlay
					? SkinnedMeshComponent->GetSkinnedAsset()->GetMaterials()
					: SkinnedMeshComponent->GetSkinnedAsset()->GetSeperateOverlayMaterials();
				for (int i = 0; i < SkeletalMaterials.Num(); i++)
				{
					if (SkeletalMaterials[i].MaterialSlotName == SlotName)
					{
						Results.Add(i);
					}
				}
			}
		}
		else if (MeshComponent->IsA<UStaticMeshComponent>())
		{
			const UStaticMeshComponent* StaticMeshComponent = Cast<UStaticMeshComponent>(MeshComponent);
			if (StaticMeshComponent->GetStaticMesh())
			{
				const TArray<FStaticMaterial>& StaticMaterials = !bSeparateOverlay
					? StaticMeshComponent->GetStaticMesh()->GetStaticMaterials()
					: StaticMeshComponent->GetStaticMesh()->GetStaticSeperateOverlayMaterials();
				for (int i = 0; i < StaticMaterials.Num(); i++)
				{
					if (StaticMaterials[i].MaterialSlotName == SlotName)
					{
						Results.Add(i);
					}
				}
			}
		}
		else if (MeshComponent->IsA<UGFurComponent>())
		{
			UGFurComponent* GFurComponent = Cast<UGFurComponent>(MeshComponent);
			return {GFurComponent->GetMaterialIndex(SlotName)};
		}
	}

	return Results;
}

void URoleCompositeMgr::ClearHeadMakeupRuntimeMaterialPath()
{
    HeadMakeupRuntimeMaterials.Empty();
}

bool URoleCompositeMgr::HasHeadMakeupRuntimeMaterialPath(const FName& ProfileName)
{
    return HeadMakeupRuntimeMaterials.Contains(ProfileName);
}

void URoleCompositeMgr::AddHeadMakeupRuntimeMaterialPath(const FName& ProfileName,const TArray<FName>& MaterialPaths)
{
    if (!HeadMakeupRuntimeMaterials.Contains(ProfileName))
    {
        HeadMakeupRuntimeMaterials.Add(ProfileName,MaterialPaths);
    }
}

void URoleCompositeMgr::InitHeadMakeupRuntimeMaterial(const int64& UID, const KGObjectID InFaceComID,const FName& ProfileName,bool hasMakeup,const KGObjectID HeadSkeletalMeshID)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::InitHeadMakeupRuntimeMaterial");
	UFaceControlComponent* InFaceCom = KGUtils::GetObjectByID<UFaceControlComponent>(InFaceComID);
	USkeletalMeshComponent* HeadSkeletalMesh = KGUtils::GetObjectByID<USkeletalMeshComponent>(HeadSkeletalMeshID);
	if (!ensure(IsValid(InFaceCom) && IsValid(HeadSkeletalMesh)))
	{
		return;
	}
    TArray<UObject*> _MaterialObjs;
    if (hasMakeup)
    {
        if (TArray<FName>* MaterialPaths = HeadMakeupRuntimeMaterials.Find(ProfileName))
        {
            for (const FName& _Path : *MaterialPaths)
            {
                if (UObject* ObjectPtr = GetActorAppearanceAsset(UID, _Path))
                {
                    _MaterialObjs.Add(ObjectPtr);
                }
            }

        }
    }
    InFaceCom->InitHeadMakeupRuntimeMaterial(ProfileName, _MaterialObjs, HeadSkeletalMesh);
}

void URoleCompositeMgr::FaceSetMeshMaterialParameterByID(const int64& UID, const KGObjectID InFaceComID, int id)
{
	if (!IsValid(AvatarModelPartLibPtr)) return;
	const auto* PartSlotPtr = AvatarModelPartLibPtr->CaptureData.Find(id);
	if (!PartSlotPtr) return ;
	FaceSetMeshMaterialParameter(UID,InFaceComID,*PartSlotPtr);
}

void URoleCompositeMgr::FaceSetMeshMaterialParameter(const int64& UID, const KGObjectID InFaceComID, const FUECompositeCaptureMaterialData& InCaptureMaterialData)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::FaceSetMeshMaterialParameter");
	UFaceControlComponent* InFaceCom = KGUtils::GetObjectByID<UFaceControlComponent>(InFaceComID);
	if (!IsValid(InFaceCom))
		return;
	
	for (auto& Elem : InCaptureMaterialData.CompositeCaptureMaterialDataMap)
	{
		for (auto& ScalarElem : Elem.Value.Scalars)
		{
			InFaceCom->SetScalarParameterValue((EAvatarCaptureMaterialSlotTypeIndex)Elem.Key, ScalarElem.Key, ScalarElem.Value);
		}

		for (auto& VectorElem : Elem.Value.Vectors)
		{
			InFaceCom->SetVectorParameterValue((EAvatarCaptureMaterialSlotTypeIndex)Elem.Key, VectorElem.Key, VectorElem.Value);
		}

		int32 TextureNum = Elem.Value.TextureNames.Num();
		if (TextureNum == Elem.Value.TexturePaths.Num())
		{
			for (int32 j(0); j < TextureNum; ++j)
			{
				const FName& Path = Elem.Value.TexturePaths[j];
				if (Path.IsNone())
					continue;

				InFaceCom->SetTextureParameterValue((EAvatarCaptureMaterialSlotTypeIndex)Elem.Key, Elem.Value.TextureNames[j], Path.ToString());
			}
		}
	}
}

void URoleCompositeMgr::ChangeModelDefaultMaterial(const int64& UID,  const KGObjectID InMeshComID, const FString& MainMaterialPath, const FString& EyeLashSlotName, const FString& EyeLashMaterialPath)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::ChangeModelDefaultMaterial");
	UMeshComponent* InMeshCom = KGUtils::GetObjectByID<UMeshComponent>(InMeshComID);
	if (!IsValid(InMeshCom))
		return;
	
	UKGMaterialManager* MaterialMgr = UKGMaterialManager::GetInstance(this);
	if (!MaterialMgr)
		return;

	if (UObject* ObjectPtr = GetActorAppearanceAsset(UID, FName(MainMaterialPath)))
	{
		if (UMaterialInstance* MaterialIns = Cast<UMaterialInstance>(ObjectPtr))
		{
			int32 SMaterialNum = InMeshCom->GetNumSeperateOverlayMaterials();
			int32 MaterialNum = InMeshCom->GetNumMaterials();
			int32 _MMaxNum = FMath::Max(SMaterialNum, MaterialNum);
			for (int32 i(0); i < _MMaxNum; ++i)
			{
				if (i < SMaterialNum)
				{
					MaterialMgr->ChangeDefaultMaterialInstance(InMeshCom, MaterialIns, i, false, true);
				}
				
				if (i < MaterialNum)
				{
					MaterialMgr->ChangeDefaultMaterialInstance(InMeshCom, MaterialIns, i, false, false);
				}
			}
		}
	}

	const int32 EyeLashSlotNameIndex = InMeshCom->GetMaterialIndex(FName(EyeLashSlotName));
	if (EyeLashSlotNameIndex >= 0)
	{
		if (UObject* ObjectPtr = GetActorAppearanceAsset(UID, FName(EyeLashMaterialPath)))
		{
			if (UMaterialInstance* MaterialIns = Cast<UMaterialInstance>(ObjectPtr))
			{
				MaterialMgr->ChangeDefaultMaterialInstance(InMeshCom, MaterialIns, EyeLashSlotNameIndex, false, false);
			}
		}
	}
}

void URoleCompositeMgr::ChangeModelDefaultMaterialBatch(const int64& UID, const int64 InActorID, const FString& MainMaterialPath, const FString& EyeLashSlotName, const FString& EyeLashMaterialPath)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::ChangeActorDefaultMaterial");

	AActor* InActor = KGUtils::GetActorByID(InActorID);
	if (!IsValid(InActor))
		return;

	UKGMaterialManager* MaterialMgr = UKGMaterialManager::GetInstance(this);
	if (!MaterialMgr)
		return;
	
	UMaterialInstance* MaterialIns = Cast<UMaterialInstance>(GetActorAppearanceAsset(UID, FName(MainMaterialPath)));
	if (!IsValid(MaterialIns))
		return;
	
	for (UActorComponent* Component : InActor->K2_GetComponentsByClass(UMeshComponent::StaticClass()))
	{
		UMeshComponent* MeshCom = Cast<UMeshComponent>(Component);
		const int32 SMaterialNum = MeshCom->GetNumSeperateOverlayMaterials();
		const int32 MaterialNum = MeshCom->GetNumMaterials();
		const int32 MMaxNum = FMath::Max(SMaterialNum, MaterialNum);
		for (int32 i(0); i < MMaxNum; ++i)
		{
			if (i < SMaterialNum)
			{
				MaterialMgr->ChangeDefaultMaterialInstance(MeshCom, MaterialIns, i, false, true);
			}
				
			if (i < MaterialNum)
			{
				MaterialMgr->ChangeDefaultMaterialInstance(MeshCom, MaterialIns, i, false, false);
			}
		}

		const int32 EyeLashSlotNameIndex = MeshCom->GetMaterialIndex(FName(EyeLashSlotName));
		if (EyeLashSlotNameIndex >= 0)
		{
			if (UMaterialInstance* EyeMaterialInstance = Cast<UMaterialInstance>(GetActorAppearanceAsset(UID, FName(EyeLashMaterialPath))))
			{
				MaterialMgr->ChangeDefaultMaterialInstance(MeshCom, EyeMaterialInstance, EyeLashSlotNameIndex, false, false);
			}
		}
	}
}

const TMap<int32, FName>& URoleCompositeMgr::GetModelColorMaterialData(const FString& ModelName, const FString& ColorName)
{
	if (!ColorMaterialMap.Contains(ModelName) || !ColorMaterialMap[ModelName].Contains(ColorName))
	{
		static TMap<int32, FName> EmptyMap;
		return EmptyMap;
	}
	return ColorMaterialMap[ModelName][ColorName];
}

void URoleCompositeMgr::SetModelColorMaterialData(const FString& ModelName, const FString& ColorName, const TMap<int32, FName>& MaterialPaths)
{
	ColorMaterialMap.FindOrAdd(ModelName).FindOrAdd(ColorName) = MaterialPaths;
}

bool URoleCompositeMgr::SetModelColorMaterials(const int64& UID, const KGObjectID InMeshComID, const FString& ModelName, const FString& ColorName)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetModelColorMaterials");
	UMeshComponent* InMeshCom = KGUtils::GetObjectByID<UMeshComponent>(InMeshComID);
	if (!ensure(IsValid(InMeshCom)))
		return false;
	
	UKGMaterialManager* MaterialMgr = UKGMaterialManager::GetInstance(this);
	if (!MaterialMgr)
		return false;

    const TMap<int32, FName>& MaterialPaths = GetModelColorMaterialData(ModelName,ColorName);

	for (const TPair<int32, FName>& Elem : MaterialPaths)
	{
		if (UMaterialInstance* MaterialIns = Cast<UMaterialInstance>(GetActorAppearanceAsset(UID, Elem.Value)))
		{
			MaterialMgr->ChangeDefaultMaterialInstance(InMeshCom, MaterialIns, Elem.Key, false, false);
		}
	}
	
	return true;
}

void  URoleCompositeMgr::SetMaterialFollowConfig(const FName& MaterialFollowLeaderMeshTag)
{
	if (!IsValid(AvatarModelPartLibPtr)) return;
    if (auto materialFollow = AvatarModelPartLibPtr->MaterialFollowers.Find(MaterialFollowLeaderMeshTag))
    {
        FMaterialFollowData& Data = MaterialFollowDataMap.FindOrAdd(MaterialFollowLeaderMeshTag);
        Data.FollowerParts = materialFollow->FollowerParts;
        Data.SlotNames = materialFollow->SlotNames;
        Data.LeaderPart = materialFollow->LeaderPart;
    }
}

/*
 * MaterialFollow功能, 对于丝袜黑丝白丝之类的材质, 脚和鞋子需要跟随下半身的材质.
*/
void URoleCompositeMgr::RefreshMaterialFollow(const int64 InActorID, const int64 InMeshComID, const FName& InMeshTag, const FName& MaterialFollowTag, bool IsMaterialFollowLeaderMesh)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::MaterialFollow");
	AActor* InActor = KGUtils::GetActorByID(InActorID);
	if (!IsValid(InActor))
		return;

	UMeshComponent* InMeshCom = KGUtils::GetObjectByID<UMeshComponent>(InMeshComID);
	if (!ensure(IsValid(InMeshCom)))
		return;

	UKGMaterialManager* MaterialMgr = UKGMaterialManager::GetInstance(this);
	if (!MaterialMgr)
		return;

	FMaterialFollowData* Data = MaterialFollowDataMap.Find(MaterialFollowTag);
	if(!Data)
	{
		return;
	}
	
	auto FollowerParts = Data->FollowerParts;
	auto SlotNames = Data->SlotNames;
	const auto MaterialFollowLeaderMeshTag = Data->LeaderPart;
	check(FollowerParts.Num() == SlotNames.Num());

	if(IsMaterialFollowLeaderMesh)
	{
		//更新的是MaterialFollow主Mesh，则先清理下FollowerMesh的材质，等会后面会刷回来
		if(InActor->Tags.Contains(MaterialFollowTag))
		{
			if(InMeshCom->ComponentTags.Contains(MaterialFollowTag))
			{
				InMeshCom->ComponentTags.Remove(MaterialFollowTag);
				InActor->Tags.Remove(MaterialFollowTag);
				for (int32 i = 0; i < FollowerParts.Num(); ++i)
				{
					TArray<UActorComponent*> Components = InActor->GetComponentsByTag(UMeshComponent::StaticClass(), FollowerParts[i]);
					for (int32 j = 0; j < Components.Num(); ++j)
					{
						if(UMeshComponent* MeshComponent = Cast<UMeshComponent>(Components[j]))
						{
							const int32 SlotIndex = MeshComponent->GetMaterialIndex(SlotNames[i]);
							if(SlotIndex >= 0)
							{
								MaterialMgr->ChangeDefaultMaterialInstance(MeshComponent,nullptr,SlotIndex,false,false);
							}
						}
					}
				}
			}
		}

		InMeshCom->ComponentTags.AddUnique(MaterialFollowTag);
		InActor->Tags.AddUnique(MaterialFollowTag);
		for (int32 i = 0; i < FollowerParts.Num(); ++i)
		{
			TArray<UActorComponent*> Components = InActor->GetComponentsByTag(UMeshComponent::StaticClass(), FollowerParts[i]);
			for (int32 j = 0; j < Components.Num(); ++j)
			{
				if(UMeshComponent* FollowMeshComponent = Cast<UMeshComponent>(Components[j]))
				{
					const int32 SlotIndex = InMeshCom->GetMaterialIndex(SlotNames[i]);
					const int32 FollowSlotIndex = FollowMeshComponent->GetMaterialIndex(SlotNames[i]);
					if(SlotIndex >= 0 && FollowSlotIndex >= 0)
					{
						UMaterialInstanceDynamic* MaterialInstance = MaterialMgr->GetDynamicMaterialInstance(InMeshCom, SlotIndex, false, false);
						MaterialMgr->ChangeDefaultMaterialInstance(FollowMeshComponent,MaterialInstance,SlotIndex,false,false);
					}
				}
			}
		}
	}
	else  //更新的是FollowerMesh的材质，则和MaterialFollow主Mesh同步一次
	{
		TArray<UActorComponent*> Components = InActor->GetComponentsByTag(UMeshComponent::StaticClass(), MaterialFollowLeaderMeshTag);
		if(Components.Num()>0)
		{
			if(UMeshComponent* LeaderSkeletalMeshComponent = Cast<UMeshComponent>(Components[0]))
			{
				for (int32 i = 0; i < FollowerParts.Num(); ++i)
				{
					if(FollowerParts[i] == InMeshTag)
					{
						const int32 LeaderSlotIndex = LeaderSkeletalMeshComponent->GetMaterialIndex(SlotNames[i]);
						if(LeaderSlotIndex >= 0)
						{
							UMaterialInstanceDynamic* MaterialInstance = MaterialMgr->GetDynamicMaterialInstance(LeaderSkeletalMeshComponent, LeaderSlotIndex, false, false);
							MaterialMgr->ChangeDefaultMaterialInstance(InMeshCom,MaterialInstance,LeaderSlotIndex,false,false);
						}
					}
				}
			}
		}
	}
}

void URoleCompositeMgr::RefreshOverrideMaterials(const int64&UID, const int64 InActorID, const TArray<int32>& InMeshComIDTagIDs, const FName& SlotName, const FName& MaterialPath)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::RefreshOverrideMaterials");
	const AActor* InActor = KGUtils::GetActorByID(InActorID);
	if (!IsValid(InActor))
	{
		return;
	}
	
	UKGMaterialManager* MaterialMgr = UKGMaterialManager::GetInstance(this);
	if (!MaterialMgr)
	{
		return;
	}
	
	if(UMaterialInstance* MaterialAsset = Cast<UMaterialInstance>(GetActorAppearanceAsset(UID, MaterialPath)))
	{
		for(const auto ComponentTag : InMeshComIDTagIDs)
		{
			const auto& ComponentTagName = AvatarBodyPartEnumToName(ComponentTag);
			for (auto* SKMesh : InActor->GetComponentsByTag(UMeshComponent::StaticClass(), ComponentTagName))
			{
				if(UMeshComponent* MeshCom = Cast<UMeshComponent>(SKMesh))
				{
					const int32 MaterialIndex = MeshCom->GetMaterialIndex(SlotName);
					if (MaterialIndex != INDEX_NONE)
					{
						MaterialMgr->ChangeDefaultMaterialInstance(MeshCom, MaterialAsset, MaterialIndex, false, false);
					}
				}
			}
		}
	}
}

void URoleCompositeMgr::SetOverrideMaterial(const int64&UID, const int64& OwnerActorID, const FName& MeshTag, const FName& profileName,const FName& modelPartId)
{    
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetOverrideMaterial");
	UKGMaterialManager* MaterialMgr = UKGMaterialManager::GetInstance(this);
	if (!MaterialMgr)
	{
		return;
	}
	
	AActor* OwnerActor = Cast<AActor>(KGUtils::GetObjectByID(OwnerActorID));
	if (!IsValid(OwnerActor))
	{
		return;
	}
	
	UMeshComponent* MeshCom = GetMeshComByTagOrMainMesh(OwnerActor, MeshTag);
	if(!MeshCom)
	{
		return;
	}

    if (!IsValid(AvatarModelPartLibPtr)) return;
    auto AvatarModelPartLibData = AvatarModelPartLibPtr->AvatarModelPartLibData.Find(profileName);
    if (!AvatarModelPartLibData) return;
    auto data = AvatarModelPartLibData->AvatarModelPartLibSubData.Find(modelPartId);
    if (!data) return;
    const TMap<FName, FName>& MaterialMap = data->OverrideMaterials;

	for(auto Item : MaterialMap)
	{
		if (UObject* ObjectPtr = GetActorAppearanceAsset(UID, Item.Value))
		{
			if (UMaterialInstance* Asset = Cast<UMaterialInstance>(ObjectPtr))
			{
				int32 SlotIndex = 0;
				for (auto SlotName : MeshCom->GetMaterialSlotNames())
				{
					if (SlotName == Item.Key)
					{
						TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetOverrideMaterial-ChangeDefaultMaterialInstance");
						MaterialMgr->ChangeDefaultMaterialInstance(MeshCom, Asset, SlotIndex, false, false);
					}
					SlotIndex++;
				}
			}
		}
	}
}

void URoleCompositeMgr::SetFNameFStringTest(FName& InFName, FString& InFString)
{
	bool bSame = InFName == FName(InFString);
	AllFName.Add(InFName);
	AllFString.Add(InFString);
	UE_LOG(LogTemp, Log, TEXT("SetFNameFStringTest %s %s %s %d %d"), *InFName.ToString(), *InFString, bSame ? TEXT("True") : TEXT("False"), AllFName.Num(), AllFString.Num());
}

FName URoleCompositeMgr::GetFNameTest(FName& InFName)
{
	UE_LOG(LogTemp, Log, TEXT("SetFNameFStringTest %s"), *InFName.ToString());
	return InFName;
}

FString URoleCompositeMgr::GetFStringTest(FString& InFString)
{
	UE_LOG(LogTemp, Log, TEXT("SetFNameFStringTest %s %s"), *InFString, *FName(*InFString).ToString());
	return InFString;
}

void URoleCompositeMgr::SetOverlayMaterial(const int64&UID, const int64& OwnerActorID,const FName& MeshTag,const FName& MaterialOverlayPath)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetOverlayMaterial");
	UKGMaterialManager* MaterialMgr = UKGMaterialManager::GetInstance(this);
	if (!MaterialMgr)
	{
		return;
	}
	AActor* OwnerActor = Cast<AActor>(KGUtils::GetObjectByID(OwnerActorID));
	if (!IsValid(OwnerActor))
	{
		return;
	}
	
	UMeshComponent* MeshCom = GetMeshComByTagOrMainMesh(OwnerActor, MeshTag);
	if(!MeshCom)
	{
		return;
	}

	if (UObject* ObjectPtr = GetActorAppearanceAsset(UID, FName(MaterialOverlayPath)))
	{
		if (UMaterialInstance* Asset = Cast<UMaterialInstance>(ObjectPtr))
		{
			TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetOverlayMaterial-ChangeDefaultMaterialInstance");
			MaterialMgr->ChangeDefaultMaterialInstance(MeshCom, Asset, 0, true, false);
		}
	}
}

#pragma endregion ActorAppearance Lib Material

#pragma region ActorAppearance Lib SkeletalMesh

USkeletalMeshComponent* URoleCompositeMgr::GetOrCreateSkeletalMesh(const int64& OwnerActorID, const FName& MeshTag)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::GetOrCreateSkeletalMesh");
	AActor* OwnerActor = Cast<AActor>(KGUtils::GetObjectByID(OwnerActorID));
	if (!IsValid(OwnerActor))
	{
		return nullptr;
	}
	
	const bool IsMainMeshTag = MeshTag == MainMeshName;
	UMeshComponent* MeshCom = GetMeshComByTagOrMainMesh(OwnerActor, MeshTag);
	USkeletalMeshComponent* SKMeshCom;
	if (!IsValid(MeshCom) || !MeshCom->IsA<USkeletalMeshComponent>())
	{
		// 如果需要设置leader component, 就不再参与到动画预算中, 使用直接禁用的tick方式进行优化
		if (IsMainMeshTag) {
			SKMeshCom = NewObject<USkeletalMeshComponentBudgeted>(OwnerActor, USkeletalMeshComponentBudgeted::StaticClass(),
				FName(TEXT("SkeletalMeshComponentBudgeted_") + MeshTag.ToString()), RF_Transient);
		}
		else {
			SKMeshCom = NewObject<USkeletalMeshComponent>(OwnerActor, USkeletalMeshComponent::StaticClass(),
				FName(TEXT("SkeletalMeshComponent_") + MeshTag.ToString()), RF_Transient);
		}

		if (!SKMeshCom)
		{
			return nullptr;
		}
		
		// 初始化组件并附加到根组件
		MeshCom = SKMeshCom;
		MeshCom->SetupAttachment(OwnerActor->GetRootComponent());
		MeshCom->RegisterComponent();
	}
	
	SKMeshCom = Cast< USkeletalMeshComponent>(MeshCom);
	if (!SKMeshCom)
	{
		return nullptr;
	}

#if WITH_EDITOR
	if (!GIsPlayInEditorWorld && MeshTag != MainMeshName)
	{
		const FString Name = FString::Printf(TEXT("%s_%s"), *SKMeshCom->GetClass()->GetName(), *MeshTag.ToString());
		if (SKMeshCom->GetName() != Name)
		{
			if (SKMeshCom->Rename(*Name, SKMeshCom->GetOuter(), REN_Test))
			{
				SKMeshCom->Rename(*Name, SKMeshCom->GetOuter());
			}
		}
	}
#endif
	
	return SKMeshCom;
}

void URoleCompositeMgr::SetSkeletalMeshParam(const int64& UID, const int64& OwnerActorID, const FName& MeshTag, const FString& SkeletalMeshPath, bool AttachToRoot, const FString& AttachSocketName, const FString& LeaderPoseComTag, bool bAddInstanceComponent)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetSkeletalMeshParam");
	AActor* OwnerActor = Cast<AActor>(KGUtils::GetObjectByID(OwnerActorID));
	if (!IsValid(OwnerActor))
	{
		return;
	}

	UStaticMeshComponent* STCom = OwnerActor->FindComponentByTag<UStaticMeshComponent>(MeshTag);
	if (STCom)
	{
		STCom->K2_DestroyComponent(STCom);
	}
	
	USkeletalMeshComponent* SKMeshCom = GetOrCreateSkeletalMesh(OwnerActorID, MeshTag);
	if(!SKMeshCom)
	{
		return;
	}

#if WITH_EDITOR
	if(bAddInstanceComponent)
	{
		if (!GIsPlayInEditorWorld)
		{
			SKMeshCom->SetFlags(SKMeshCom->GetFlags() | RF_Transient);
		}
		OwnerActor->AddInstanceComponent(SKMeshCom);
	}
#endif
	
	// 布料, 再单位入场后的预算机制中, 按需进行开启
	SKMeshCom->SetAllowClothActors(false);
	// 注意: 这里MainMesh不一定是SkeletalMeshComponentBudgeted, 走ABaseCharacter的基本都是、走拼装流程自己产生的是, 其他的没有强制限制
	SKMeshCom->ComponentTags.AddUnique(MeshTag);
	if (UObject* ObjectPtr = GetActorAppearanceAsset(UID, FName(SkeletalMeshPath)))
	{
		if (USkeletalMesh* MeshAsset = Cast<USkeletalMesh>(ObjectPtr))
		{
			TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetSkeletalMeshParam-SetSkeletalMeshAsset");
			UKGMaterialManager::SetActorSkeletalMesh(SKMeshCom, MeshAsset, false, true);
		}
	}

	//4中Attach方式: AttachToRoot(Model lib中的单部件非拼装角色，挂接到胶囊体下), AttachToParent(SetLeaderPose),AttachToParent(挂接到MainMesh)，主Mesh挂接
	if(AttachToRoot)
	{
		if (USceneComponent* RootCom = OwnerActor->GetRootComponent())
		{
			TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetSkeletalMeshParam-AttachToRootComponent");
			SKMeshCom->AttachToComponent(RootCom, URoleCompositeMgr::AttachmentTransformRules_KeepRelative);
		}
	}
	else if(!LeaderPoseComTag.IsEmpty())
	{
		USkinnedMeshComponent* LeaderSkCom = Cast<USkinnedMeshComponent>(GetMeshComByTagOrMainMesh(OwnerActor, FName(LeaderPoseComTag)));
		UMeshComponent* ParentSkCom = GetMeshComByTagOrMainMesh(OwnerActor, MainMeshName);
		if (LeaderSkCom && ParentSkCom)
		{
			TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetSkeletalMeshParam-SetLeaderPoseComponent");
			SKMeshCom->SetLeaderPoseComponent(LeaderSkCom);
			SKMeshCom->AttachToComponent(ParentSkCom, URoleCompositeMgr::AttachmentTransformRules_KeepRelative);
		}
	}
	else if(!AttachSocketName.IsEmpty())
	{
		UMeshComponent* ParentSkCom = GetMeshComByTagOrMainMesh(OwnerActor, MainMeshName);
		TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetSkeletalMeshParam-AttachToComponent");
		SKMeshCom->SetLeaderPoseComponent(nullptr);
		SKMeshCom->AttachToComponent(ParentSkCom, URoleCompositeMgr::AttachmentTransformRules_KeepRelative, FName(AttachSocketName));
	}
	else
	{
		SKMeshCom->SetLeaderPoseComponent(nullptr);
	}
}

void URoleCompositeMgr::SetStaticMeshParam(const int64&UID, const int64& OwnerActorID, const FName& MeshTag, const FString& StaticMeshPath, const FName& SocketName)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetStaticMeshParam");
	AActor* OwnerActor = Cast<AActor>(KGUtils::GetObjectByID(OwnerActorID));
	if (!IsValid(OwnerActor))
	{
		return;
	}

	//除了主Mesh的都可以删除，主Mesh清理一下就行
	USkeletalMeshComponent* SKCom = OwnerActor->FindComponentByTag<USkeletalMeshComponent>(MeshTag);
	if (SKCom)
	{
		if(MeshTag!=MainMeshName)
		{
			SKCom->K2_DestroyComponent(SKCom);
		}
		else
		{
			SKCom->SetSkeletalMeshAsset(nullptr);
			SKCom->SetAnimInstanceClass(nullptr);
		}
	}
	
	UMeshComponent* MeshCom = GetMeshComByTagOrMainMesh(OwnerActor, MeshTag);
	if (!IsValid(MeshCom) || !MeshCom->IsA<UStaticMeshComponent>())
	{
		MeshCom = NewObject<UStaticMeshComponent>(OwnerActor, UStaticMeshComponent::StaticClass(),
				FName(TEXT("StaticMeshComponent_") + MeshTag.ToString()), RF_Transient);
		if (!MeshCom)
		{
			return;
		}

		// 初始化组件并附加到根组件
		MeshCom->SetupAttachment(OwnerActor->GetRootComponent());
		MeshCom->RegisterComponent();
		MeshCom->ComponentTags.AddUnique(MeshTag); 	
	}
	
	// 注意: 这里MainMesh不一定是SkeletalMeshComponentBudgeted, 走ABaseCharacter的基本都是、走拼装流程自己产生的是, 其他的没有强制限制
	MeshCom->ComponentTags.AddUnique(MeshTag);

	UStaticMeshComponent* StaticMeshComponent = Cast<UStaticMeshComponent>(MeshCom);
	if(!StaticMeshComponent)
	{
		return;
	}

	if (UObject* ObjectPtr = GetActorAppearanceAsset(UID, FName(StaticMeshPath)))
	{
		if (UStaticMesh* MeshAsset = Cast<UStaticMesh>(ObjectPtr))
		{
			TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetStaticMeshParam-SetActorStaticMesh");
			UKGMaterialManager::SetActorStaticMesh(StaticMeshComponent, MeshAsset, true);
		}
	}

	if (UMeshComponent* ParentSkCom = GetMeshComByTagOrMainMesh(OwnerActor, MainMeshName))
	{
		TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetStaticMeshParam-AttachToRootComponent");
		StaticMeshComponent->AttachToComponent(ParentSkCom, URoleCompositeMgr::AttachmentTransformRules_SnapToTarget, SocketName);
	}
	
#if WITH_EDITOR
		if (!GIsPlayInEditorWorld)
		{
			StaticMeshComponent->SetFlags(StaticMeshComponent->GetFlags() | RF_Transient);
		}
		OwnerActor->AddInstanceComponent(StaticMeshComponent);
#endif
}

void URoleCompositeMgr::ClearDecorationComponents(const int64& OwnerActorID, const FName& MeshTag, const FString& DecorationTagPrefix)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetDecorationComponents");
	AActor* OwnerActor = Cast<AActor>(KGUtils::GetObjectByID(OwnerActorID));
	if (!IsValid(OwnerActor))
	{
		return;
	}

	const UMeshComponent* MeshCom = GetMeshComByTagOrMainMesh(OwnerActor, MeshTag);
	if(!MeshCom)
	{
		return;
	}

	const FString DecorationTag = DecorationTagPrefix + MeshTag.ToString();
	auto Components = OwnerActor->GetComponentsByTag(UActorComponent::StaticClass(), FName(DecorationTag));
	for (int32 i = 0; i < Components.Num(); ++i)
	{
		if(UActorComponent* ActorComponent = Components[i])
		{
			ActorComponent->K2_DestroyComponent(ActorComponent);
		}
	}
}

void URoleCompositeMgr::SetDecorationComponents(const int64&UID, const int64& OwnerActorID, const FName& MeshTag, const FString& DecorationTagPrefix, const FName& profileName,const FName& modelPartId)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetDecorationComponents");
	AActor* OwnerActor = Cast<AActor>(KGUtils::GetObjectByID(OwnerActorID));
	if (!IsValid(OwnerActor))
	{
		return;
	}
	
	UMeshComponent* MeshCom = GetMeshComByTagOrMainMesh(OwnerActor, MeshTag);
	if(!MeshCom)
	{
		return;
	}

    if (!IsValid(AvatarModelPartLibPtr)) return;
    auto AvatarModelPartLibData = AvatarModelPartLibPtr->AvatarModelPartLibData.Find(profileName);
    if (!AvatarModelPartLibData) return;
    auto data = AvatarModelPartLibData->AvatarModelPartLibSubData.Find(modelPartId);
    if (!data) return;
    const TArray<FName>& DecorationComponents = data->DecorationComponents;

	const FString DecorationTag = DecorationTagPrefix + MeshTag.ToString();
	for(auto& DecorationComponentPath : DecorationComponents)
	{
		if (UObject* ObjectPtr = GetActorAppearanceAsset(UID, DecorationComponentPath))
		{
			if (UClass* DecorationComponentClass = Cast<UClass>(ObjectPtr))
			{
				if(USceneComponent* DecorationComponent = Cast<USceneComponent>(OwnerActor->AddComponentByClass(DecorationComponentClass, false, FTransform::Identity, false)))
				{
					DecorationComponent->K2_AttachToComponent(MeshCom, "", EAttachmentRule::SnapToTarget,  EAttachmentRule::SnapToTarget,  EAttachmentRule::SnapToTarget, true);
					DecorationComponent->ComponentTags.AddUnique(FName(DecorationTag));
#if UE_EDITOR
					DecorationComponent->GetOwner()->AddInstanceComponent(DecorationComponent);
#endif
				}
			}
		}
	}
}

int64 URoleCompositeMgr::SetSkeletalMeshComParamFast(const int64& OwnerActorID,const FName& MeshTag, 
bool Active, bool ComponentTickEnabled, bool ReceivesDecals, bool RenderCustomDepth, int32 CustomDepthStencilValue,
bool HiddenInGame, bool CastInsetShadow, bool bCastShadow, bool SingleSampleShadowFromStationaryLights, bool UseAttachParentBound, bool EnableCharacterLighting,
bool UpdateOverlapsOnAnimationFinalize, bool AnimTickOptimization, bool SKMeshOptimization, bool bUseParentCapsuleComponentBound, float TranslucencySortDistanceOffset,
int32 ActorLODBias, bool UsePerObjectVLMOnMobile, uint8 MaxTextureLOD, bool bSyncAttachParentLOD, bool bUpdatePhysicsTransformParallelly)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetSkeletalMeshComParamFast");
	AActor* OwnerActor = Cast<AActor>(KGUtils::GetObjectByID(OwnerActorID));
	if (!IsValid(OwnerActor))
	{
		return KG_INVALID_ID;
	}
	
	UMeshComponent* MeshCom = GetMeshComByTagOrMainMesh(OwnerActor, MeshTag);
	if (!IsValid(MeshCom))
	{
		return KG_INVALID_ID;
	}

	MeshCom->SetActive(Active);
	MeshCom->SetComponentTickEnabled(ComponentTickEnabled);
	if(!ComponentTickEnabled)
	{
		MeshCom->ComponentTags.AddUnique(IgnoreTagForComTickSetByVisible);
	}
	MeshCom->SetReceivesDecals(ReceivesDecals);
	MeshCom->SetRenderCustomDepth(RenderCustomDepth);
	if (CustomDepthStencilValue >= 0)
	{
		MeshCom->SetCustomDepthStencilValue(CustomDepthStencilValue);
	}
	MeshCom->SetHiddenInGame(HiddenInGame);
	MeshCom->SetCastInsetShadow(CastInsetShadow);
	MeshCom->SetCastShadow(bCastShadow);
	MeshCom->SetSingleSampleShadowFromStationaryLights(SingleSampleShadowFromStationaryLights);
	MeshCom->bUseAttachParentBound = UseAttachParentBound;
	MeshCom->SetEnableCharacterLighting(EnableCharacterLighting);
	MeshCom->SetTranslucencySortDistanceOffset(TranslucencySortDistanceOffset);
	MeshCom->SetUpdatePhysicsTransformParallelly(bUpdatePhysicsTransformParallelly);
	if (USkeletalMeshComponent* CastedSKCom = Cast<USkeletalMeshComponent>(MeshCom))
	{
		CastedSKCom->SetActorLODBias(ActorLODBias);
		CastedSKCom->bSyncAttachParentLOD = bSyncAttachParentLOD;
		CastedSKCom->SetUsePerObjectVLMOnMobile(UsePerObjectVLMOnMobile);
		CastedSKCom->bUpdateOverlapsOnAnimationFinalize = UpdateOverlapsOnAnimationFinalize;
		CastedSKCom->SetMaxTextureLOD(MaxTextureLOD);
		ULowLevelFunctions::EnableAnimTickOptimization(CastedSKCom, AnimTickOptimization);
		ULowLevelFunctions::EnableSKMeshOptimization(CastedSKCom, SKMeshOptimization);
		UseParentCapsuleComponentBound(CastedSKCom, bUseParentCapsuleComponentBound);
	}

	return KGUtils::GetIDByObject(MeshCom);
}

void URoleCompositeMgr::PostExecuteBakedBPSkeletalMesh(const int64& OwnerActorID,
	bool bUseParentCapsuleComponentBound,
	bool bFollowerComponentTickEnabled,
	bool bCastShadow,
	bool bUsePerObjectVLMOnMobile,
	bool bSKMeshOptimization,
	bool bAnimTickOptimization,
	int32 ActorLODBias,
	bool bUpdateOverlapsOnAnimationFinalize,
	uint8 MaxTextureLOD)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::PostExecuteBakedBPSkeletalMesh");
	AActor* OwnerActor = Cast<AActor>(KGUtils::GetObjectByID(OwnerActorID));
	if (!IsValid(OwnerActor))
	{
		return;
	}
	
	UMeshComponent* MainMesh = GetMeshComByTagOrMainMesh(OwnerActor, MainMeshName);
	if (USkeletalMeshComponent* LeaderSkeletalMeshComponent = Cast<USkeletalMeshComponent>(MainMesh))
	{
		UseParentCapsuleComponentBound(LeaderSkeletalMeshComponent, bUseParentCapsuleComponentBound);
	}

	/*if (UFaceControlComponent* FaceControlComponent = OwnerActor->FindComponentByClass<UFaceControlComponent>())
	{
		FaceControlComponent->SetFaceDataRuntimeSelf();
	}*/

	TArray<UActorComponent*> ActorComponents = OwnerActor->K2_GetComponentsByClass(UMeshComponent::StaticClass());
	for (UActorComponent* ActorComponent : ActorComponents)
	{
		if(UMeshComponent* Comp = Cast<UMeshComponent>(ActorComponent))
		{
			//渲染设置
			Comp->SetCastShadow(bCastShadow);
			Comp->SetUsePerObjectVLMOnMobile(bUsePerObjectVLMOnMobile);

			//SK优化设置
			if (USkeletalMeshComponent* SKComp = Cast<USkeletalMeshComponent>(Comp))
			{
				SKComp->bUpdateOverlapsOnAnimationFinalize = bUpdateOverlapsOnAnimationFinalize;
				SKComp->SetMaxTextureLOD(MaxTextureLOD);
				ULowLevelFunctions::EnableSKMeshOptimization(SKComp, bSKMeshOptimization);
				ULowLevelFunctions::EnableAnimTickOptimization(SKComp, bAnimTickOptimization);
			}

			//Follower SK
			if (Comp->ComponentHasTag(FollowerTagName))
			{
				//设置LeaderPoseComponent
				if (USkinnedMeshComponent* LeaderSkinnedMeshComponent = Cast<USkinnedMeshComponent>(MainMesh))
				{
					LeaderSkinnedMeshComponent->SetActorLODBias(ActorLODBias);
					if(USkinnedMeshComponent* SkComp = Cast<USkinnedMeshComponent>(ActorComponent))
					{
						SkComp->SetLeaderPoseComponent(LeaderSkinnedMeshComponent);
					}
				}

				//设置Tick
				Comp->SetComponentTickEnabled(bFollowerComponentTickEnabled);
				if(!bFollowerComponentTickEnabled)
				{
					Comp->ComponentTags.AddUnique(IgnoreTagForComTickSetByVisible);
				}
				else
				{
					Comp->ComponentTags.Remove(IgnoreTagForComTickSetByVisible);
				}
			}
		}
	}
}

UMeshComponent* URoleCompositeMgr::GetMeshComByTagOrMainMesh(AActor* OwnerActor, const FName& MeshTag)
{
	if (IsValid(OwnerActor))
	{
		UMeshComponent* SKCom = OwnerActor->FindComponentByTag<UMeshComponent>(MeshTag);

		// 下面这个逻辑是一个业务逻辑, BodyUpper一定是一个SkeletalMeshComponent
		if (SKCom == nullptr && MeshTag == URoleCompositeMgr::MainMeshName)
		{
			IC7ActorInterface* C7ActorInterface = Cast<IC7ActorInterface>(OwnerActor);
			if (C7ActorInterface)
			{
				SKCom = C7ActorInterface->GetMainMesh();
			}
			else
			{
				SKCom = OwnerActor->FindComponentByClass<USkeletalMeshComponent>();
			}
			
		}

		return SKCom;
	}

	return nullptr;
}


void URoleCompositeMgr::InitBoneMaskData(const FString& SkeletonAssetPath, const TArray<FName>& MaskRootBoneNames)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::InitBoneMaskData");
	if (const USkeleton* Skeleton = LoadObject<USkeleton>(NULL,*SkeletonAssetPath))
	{
		const FName SkeletonName = Skeleton->GetFName();
		TMap<FName, TArray<int32>>& BoneMaskDataMap = SkeletalMeshBoneMaskMap.FindOrAdd(SkeletonName);
		BoneMaskDataMap.Empty();
		const FReferenceSkeleton& RefSkeleton = Skeleton->GetReferenceSkeleton();
		for(auto MaskRootBoneName:MaskRootBoneNames)
		{
			int32 RootBoneIdx = RefSkeleton.FindBoneIndex(MaskRootBoneName);
			TArray<int32> BoneIdxStack;
			TArray<int32> BoneChildIdxStack;
			if (RootBoneIdx > 0)
			{
				BoneIdxStack.Push(RootBoneIdx);
				while (BoneIdxStack.Num() > 0)
				{
					TArray<int32> DirectChildIndices;
					const int32 CurBoneIdx = BoneIdxStack.Pop();
					RefSkeleton.GetDirectChildBones(CurBoneIdx, DirectChildIndices);
					for (const int32 ChildBoneIndex : DirectChildIndices)
					{
						BoneIdxStack.Push(ChildBoneIndex);
						BoneChildIdxStack.Push(ChildBoneIndex);
					}
				}

				if (BoneChildIdxStack.Num() == 0)
				{
					continue;
				}
				
				BoneChildIdxStack.Sort();

				TArray<int32>& BoneMaskData = BoneMaskDataMap.Add(MaskRootBoneName);
				BoneMaskData = BoneChildIdxStack;
#if UE_EDITOR
				for(auto i : BoneChildIdxStack)
				{
					UE_LOG(LogTemp, Log, TEXT("URoleCompositeMgr::InitBoneMaskData  %d %s"),i, *RefSkeleton.GetBoneName(i).ToString());
				}
#endif
			}
		}
	}
}

TMap<FName, TArray<int32>>* URoleCompositeMgr::GetBoneMaskData(const FName& SkeletonName)
{
	if(!SkeletalMeshBoneMaskMap.Contains(SkeletonName))
	{
		return nullptr;
	}

	return &SkeletalMeshBoneMaskMap[SkeletonName];
}

TArray<int32>* URoleCompositeMgr::GetBoneMaskDataByRootName(const FName& SkeletonName, const FName& MaskRootName)
{
	if(!SkeletalMeshBoneMaskMap.Contains(SkeletonName))
	{
		return nullptr;
	}

	auto& BoneMaskDataMap = SkeletalMeshBoneMaskMap[SkeletonName];
	if(!BoneMaskDataMap.Contains(MaskRootName))
	{
		return nullptr;
	}
	
	return &BoneMaskDataMap[MaskRootName];
}

void URoleCompositeMgr::EnableBoneMask(const int64 InActorID, bool Enable)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::RefreshBoneMask")
	AActor* OwnerActor = Cast<AActor>(KGUtils::GetObjectByID(InActorID));
	if (!IsValid(OwnerActor))
		return;

	if(ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(OwnerActor))
	{
		BaseCharacter->EnableBoneMask(Enable);
	}
}

void URoleCompositeMgr::SetMeshUseParentCapsuleComponentBound(const int64& OwnerActorID, const bool& bEnable)
{
	AActor* OwnerActor = Cast<AActor>(KGUtils::GetObjectByID(OwnerActorID));
	if (!IsValid(OwnerActor))
	{
		return;
	}

	USkeletalMeshComponent* SKCom;
	IC7ActorInterface* C7ActorInterface = Cast<IC7ActorInterface>(OwnerActor);
	if (C7ActorInterface)
	{
		SKCom = C7ActorInterface->GetMainMesh();
	}
	else
	{
		SKCom = OwnerActor->FindComponentByClass<USkeletalMeshComponent>();
	}

	if(SKCom)
	{
		UseParentCapsuleComponentBound(SKCom, bEnable);
	}
}

void URoleCompositeMgr::ClearBoundsPhysicsAsset(const int64 InActorID, const int64 InMeshComID)
{
	AActor* OwnerActor = Cast<AActor>(KGUtils::GetObjectByID(InActorID));
	if (!IsValid(OwnerActor))
	{
		return;
	}

	USkeletalMeshComponent* InMeshCom = KGUtils::GetObjectByID<USkeletalMeshComponent>(InMeshComID);
	if (!IsValid(InMeshCom))
	{
		return;  
	}
	
	InMeshCom->PhysicsAssetUsedForBounds = nullptr;
}

void URoleCompositeMgr::SetBoundsPhysicsAsset(const int64& UID, const int64 InActorID, const int64 InMeshComID, const FName& AvatarBoundsPhysicsAssetPath)
{
	AActor* OwnerActor = Cast<AActor>(KGUtils::GetObjectByID(InActorID));
	if (!IsValid(OwnerActor))
	{
		return;
	}

	USkeletalMeshComponent* InMeshCom = KGUtils::GetObjectByID<USkeletalMeshComponent>(InMeshComID);
    if (!ensure(IsValid(InMeshCom)))
    {
    	return;  
    }
	
	if (UObject* ObjectPtr = GetActorAppearanceAsset(UID, AvatarBoundsPhysicsAssetPath))
	{
		if (UPhysicsAsset* BoundsPhysicsAsset = Cast<UPhysicsAsset>(ObjectPtr))
		{
			InMeshCom->PhysicsAssetUsedForBounds = BoundsPhysicsAsset;
		}
	}
}

void URoleCompositeMgr::UseParentCapsuleComponentBound(class USkeletalMeshComponent* InSkCom, const bool& bEnable)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::UseParentCapsuleComponentBound");
	if(!IsValid(InSkCom) || !IsValid(InSkCom->GetSkeletalMeshAsset()))
	{
		return;
	}
		
	USkeletalMesh* MeshAsset = InSkCom->GetSkeletalMeshAsset();
	if(!bEnable)
	{
		MeshAsset->SetNegativeBoundsExtension(FVector::Zero());
		MeshAsset->SetPositiveBoundsExtension(FVector::Zero());
		return;
	}

	if (auto Comp = InSkCom->GetAttachParent())
	{
		if (Comp->IsA(UCapsuleComponent::StaticClass()))
		{
			auto CapsuleComponent = Cast<UCapsuleComponent>(Comp);
			if(IsValid(CapsuleComponent))
			{
				auto CapsuleComponentBounds = CapsuleComponent->GetLocalBounds();
				auto SourceBounds = MeshAsset->GetImportedBounds();
				FVector HalfHeight = -InSkCom->GetRelativeLocation();

				const FReferenceSkeleton& ReferenceSkeleton = MeshAsset->GetRefSkeleton();
				int32 PelvisIndex = ReferenceSkeleton.FindBoneIndex(TopLogoBoneName); // TOP_LOGO直接在root底下, 可以直接拿Z
				if (PelvisIndex != INDEX_NONE)
					HalfHeight.Z = ReferenceSkeleton.GetRefBonePose()[PelvisIndex].GetLocation().Z / 2;
				
				FBoxSphereBounds TargetBounds = FBoxSphereBounds(HalfHeight, CapsuleComponentBounds.BoxExtent*1.5F, CapsuleComponentBounds.SphereRadius);
					
				// 计算原始包围盒的最小和最大点
				FVector SourceMin = SourceBounds.Origin - SourceBounds.BoxExtent;
				FVector SourceMax = SourceBounds.Origin + SourceBounds.BoxExtent;

				// 计算目标包围盒的最小和最大点
				FVector TargetMin = TargetBounds.Origin - TargetBounds.BoxExtent;
				FVector TargetMax = TargetBounds.Origin + TargetBounds.BoxExtent;

				// 逆向推导扩展量
				FVector NegativeBoundsExtension = SourceMin - TargetMin; // 负向扩展 = 原最小点 - 目标最小点
				FVector PositiveBoundsExtension = TargetMax - SourceMax; // 正向扩展 = 目标最大点 - 原最大点

				// 设置扩展量
				// 此处会修改资产的值
				MeshAsset->SetNegativeBoundsExtension(NegativeBoundsExtension);
				MeshAsset->SetPositiveBoundsExtension(PositiveBoundsExtension);
			}
		}
	}
}

#pragma endregion ActorAppearance Lib SkeletalMesh

#pragma region ActorAppearance Lib Anim

void URoleCompositeMgr::SetAnimParamsByConfigID(const int64& UID, const int64& OwnerActorID,
											 const FName& MeshTag, const FString& AnimClassPath,
											 const FName& AnimLibName, uint8 ContainerSize,
											 uint8 AnimAssetPriorityIndex, uint8 AnimAssetPrioritySemanticTag,
											 const TMap<FString,FString>& AnimLayerMap,
											 bool bGameCache, bool bUseCache, bool IsLocalDisplayChar)
{
	if (!IsValid(PreloadAnimDataAsset)) return;
    
	static const TArray<FName> EmptyArray;
	const TArray<FName>* AnimTypes = &EmptyArray;
	const TArray<FName>* AnimAssets = &EmptyArray;
	const TArray<FName>* AnimsForABP = &EmptyArray;
    
	if (auto dataPtr = PreloadAnimDataAsset->Data.Find(AnimLibName))
	{
		AnimTypes = &dataPtr->AnimTypes;
		AnimAssets = &dataPtr->AnimAssets;
		AnimsForABP = &dataPtr->AnimsForABP_AnimTypes;
	}
    
	SetAnimParams(UID, OwnerActorID, MeshTag, AnimClassPath, AnimLibName, ContainerSize, 
				 AnimAssetPriorityIndex, AnimAssetPrioritySemanticTag,
				 *AnimTypes, *AnimAssets, *AnimsForABP, 
				 AnimLayerMap, bGameCache, bUseCache, IsLocalDisplayChar);
}

void URoleCompositeMgr::SetAnimParams(const int64& UID, const int64& OwnerActorID,
                                             const FName& MeshTag, const FString& AnimClassPath,
                                             const FName& AnimLibName, uint8 ContainerSize,
                                             uint8 AnimAssetPriorityIndex, uint8 AnimAssetPrioritySemanticTag,
                                             const TArray<FName>& AnimAssetPathNames,
                                             const TArray<FName>& AnimAssetPathValues,
                                             const TArray<FName>& AnimAssetPathLocoNames,
                                             const TMap<FString,FString>& AnimLayerMap,
                                             bool bGameCache, bool bUseCache, bool IsLocalDisplayChar)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetAnimParams")
	AActor* OwnerActor = Cast<AActor>(KGUtils::GetObjectByID(OwnerActorID));
	if (!IsValid(OwnerActor))
		return;

	USkeletalMeshComponent* SkCom = Cast<USkeletalMeshComponent>(GetMeshComByTagOrMainMesh(OwnerActor, MeshTag));
	if (!SkCom)
		return ;

	UKGCppAssetManager* CppAssetManager = UKGCppAssetManager::GetInstance(this);
	if (!CppAssetManager)
		return;

	ROLE_COMPOSITE_MANAGER_LOG(TEXT("[URoleCompositeMgr::SetAnimParams]: UID:%lld SetAnimParams AnimClassPath:%s  AnimLibName:%s AnimAssetPathNames/AnimAssetPathValues size: %d/%d  AnimLayerMap Count:%d"),
		UID, *AnimClassPath, *AnimLibName.ToString(), AnimAssetPathNames.Num(), AnimAssetPathValues.Num(),  AnimLayerMap.Num());
	
	for (auto AnimLayer : AnimLayerMap) {
		if(AnimLayer.Value.IsEmpty())
		{
			continue;
		}
		FName AnimLinkLayerPathName = FName(AnimLayer.Value);

		UClass* ABPClassGenerated = Cast<UClass>(GetActorAppearanceAsset(UID, AnimLinkLayerPathName));
		if (!ABPClassGenerated) {
			
			UE_LOG(RoleCompositeMgrLog, Error, TEXT("[URoleCompositeMgr::SetAnimParams]: UID:%lld Cannot Find ABP Class:%s"), UID, *AnimLinkLayerPathName.ToString());
			continue;
		}

		// Link的layer是动态进行处理的, 单位资源加载提前准备好, 运行时按需根据path直接使用
		ROLE_COMPOSITE_MANAGER_LOG(TEXT("[URoleCompositeMgr::SetAnimParams]:UID:%lld Set AnimLayerClass AnimLinkLayerPath:%s "), UID, *AnimLinkLayerPathName.ToString());
		CppAssetManager->SetAnimABPClassCache(AnimLinkLayerPathName, ABPClassGenerated);
	}

	ABaseCharacter* TargetCharacter = Cast<ABaseCharacter>(OwnerActor);
	if (MeshTag == MainMeshName && TargetCharacter) //只有主mesh有权限设置，挂接物动画也用这个接口！
	{
		TargetCharacter->SetAnimLayerMap(AnimLayerMap);
	}

	if (UObject* ObjectPtr = GetActorAppearanceAsset(UID, FName(AnimClassPath)))
	{
		if (UClass* NewAnimClass = Cast<UClass>(ObjectPtr))
		{
			SkCom->SetAnimationMode(EAnimationMode::AnimationBlueprint, false);
			//if (AnimAssetPathNames.Num() == AnimAssetPathValues.Num() && AnimAssetPathNames.Num() > 0)
			//{
				//SkCom->bUseRefPoseOnInitAnim = true; //有动画资源设置的时候，后面会TickAnimation和RefreshBoneTransforms一次，这里就不执行了 hujianglong@kuaishou.com
			//}
			//else
			//{
				//SkCom->bUseRefPoseOnInitAnim = false;//SetAnimClass会执行TickAnimation和RefreshBoneTransforms hujianglong@kuaishou.com
			//}

			//拼装逻辑的时序在动画更新之前，不需要去执行TickAnimation和RefreshBoneTransforms
			SkCom->bUseRefPoseOnInitAnim = true;
			TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetAnimParams-SetAnimClass");
			SkCom->SetAnimInstanceClass(NewAnimClass);
			
#if WITH_EDITOR
			// 在Dialogue/Cutscene等编辑器下(非PIE), 需要更新动画. 对PIE没有影响.
			SkCom->SetUpdateAnimationInEditor(true);	
#endif
		}
	}

 	UBaseAnimInstance* AnimIns = Cast<UBaseAnimInstance>(SkCom->GetAnimInstance());
	if(AnimIns)
	{
		TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetAnimParams-InitLoco");
		if (AnimAssetPathNames.Num() > 0)
		{
			AnimIns->InitLocoSequenceContainerSize(ContainerSize, AnimLibName);
			if (bUseCache)
			{
				const TMap<FName, UAnimSequenceBase*>* CachedDataMap = CppAssetManager->GetAnimCacheForLocomotionABP(AnimLibName);
				if(CachedDataMap && CachedDataMap->Num() >= 0)
				{
					if(CachedDataMap->Num() != AnimAssetPathLocoNames.Num())
					{
						UE_LOG(RoleCompositeMgrLog, Error, TEXT("[URoleCompositeMgr::SetAnimParams] Get Anim Loco Anim Cache Number Not Match Desired:%d Matched:%d"), AnimAssetPathLocoNames.Num(), CachedDataMap->Num());
					}
					AnimIns->ObtainLocoSequenceMappingWithPriorityIndex(AnimAssetPriorityIndex, AnimAssetPrioritySemanticTag, *CachedDataMap);
					CppAssetManager->UnLockLocomotionABPCache(AnimLibName);
				}
				else if (AnimAssetPathNames.Num() == AnimAssetPathValues.Num())
				{
					if(bool Cached = TryAddToCached(UID, CppAssetManager, AnimLibName, bGameCache, AnimAssetPathNames, AnimAssetPathValues, AnimAssetPathLocoNames))
					{
						CachedDataMap = CppAssetManager->GetAnimCacheForLocomotionABP(AnimLibName);
						if(CachedDataMap)
						{
							AnimIns->ObtainLocoSequenceMappingWithPriorityIndex(AnimAssetPriorityIndex, AnimAssetPrioritySemanticTag, *CachedDataMap);
						}
						else
						{
							UE_LOG(RoleCompositeMgrLog, Error, TEXT("[URoleCompositeMgr::SetAnimParams] GetAnimCacheForLocomotionABP Failed AnimLibName:%s"), *AnimLibName.ToString());
						}
					}
					else
					{
						SetAnimObtainLocoSequenceMapping(UID, AnimLibName, AnimIns, AnimAssetPriorityIndex, AnimAssetPrioritySemanticTag, AnimAssetPathNames, AnimAssetPathValues, AnimAssetPathLocoNames, IsLocalDisplayChar);
					}
				}
			}
			else
			{
				if (AnimAssetPathNames.Num() == AnimAssetPathValues.Num())
				{
					SetAnimObtainLocoSequenceMapping(UID, AnimLibName, AnimIns, AnimAssetPriorityIndex, AnimAssetPrioritySemanticTag, AnimAssetPathNames , AnimAssetPathValues, AnimAssetPathLocoNames, IsLocalDisplayChar);
				}
			}
			
			//拼装逻辑的时序在动画更新之前，不需要去执行TickAnimation和RefreshBoneTransforms
			//SkCom->TickAnimation(0.f, false);
			//SkCom->RefreshBoneTransforms();
		}
	}
}

bool URoleCompositeMgr::TryAddToCached(const int64& UID, UKGCppAssetManager* CppAssetManager,const FName& AnimLibName, bool bGameCache,
	const TArray<FName>& AnimAssetPathNames, const TArray<FName>& AnimAssetPathValues,const TArray<FName>& AnimAssetPathLocoNames)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetAnimParams-TryAddToCached");

	if (!CppAssetManager)
	{
		return false;
	}
	
	TArray<UAnimSequenceBase*> NewAnimAssets;
	NewAnimAssets.Reserve(AnimAssetPathNames.Num());
	bool HasNullAsset = false;
	for (int32 i(0); i < AnimAssetPathNames.Num(); ++i)
	{
		if (UObject* ObjectPtr = GetActorAppearanceAsset(UID, FName(AnimAssetPathValues[i])))
		{
			if (UAnimSequenceBase* SeqAsset = Cast<UAnimSequenceBase>(ObjectPtr))
			{
				NewAnimAssets.Emplace(SeqAsset);
				continue;
			}
		}
						
		UE_LOG(RoleCompositeMgrLog, Warning, TEXT("[URoleCompositeMgr::SetAnimParams] Get Anim Failed AnimLibName:%s AssetPath:%s"), *AnimLibName.ToString(), * AnimAssetPathValues[i].ToString());
		NewAnimAssets.Emplace(nullptr);
		HasNullAsset = true;
	}

	//有错误的资产就不进缓存
	const EAnimSequenceCacheType AnimSequenceCacheType = bGameCache ? EAnimSequenceCacheType::Game : EAnimSequenceCacheType::Level;
	if(!HasNullAsset && CppAssetManager->AddAnimsToCache(AnimSequenceCacheType, AnimLibName, AnimAssetPathValues, NewAnimAssets, AnimAssetPathNames, AnimAssetPathLocoNames))
	{
		return true;
	}

	return false;
}

void URoleCompositeMgr::SetAnimObtainLocoSequenceMapping(const int64& UID, const FName& AnimLibName, UBaseAnimInstance* AnimIns,
	uint8 AnimAssetPriorityIndex, uint8 AnimAssetPrioritySemanticTag,
	const TArray<FName>& AnimAssetPathNames, const TArray<FName>& AnimAssetPathValues,const TArray<FName>& AnimAssetPathLocoNames,
	bool IsLocalDisplayChar)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetAnimParams-SetAnimObtainLocoSequenceMapping");
	if (!AnimIns)
	{
		return ;
	}
	
	TMap<FName, UAnimSequenceBase*> LocoAnimAssetMap;
	LocoAnimAssetMap.Reserve(AnimAssetPathLocoNames.Num());
	for (int32 i(0); i < AnimAssetPathNames.Num(); ++i)
	{
		if(!AnimAssetPathLocoNames.Contains(AnimAssetPathNames[i]))
		{
			continue;
		}
		if (UObject* ObjectPtr = GetActorAppearanceAsset(UID, FName(AnimAssetPathValues[i]), !IsLocalDisplayChar))
		{
			if (UAnimSequenceBase* SeqAsset = Cast<UAnimSequenceBase>(ObjectPtr))
			{
				LocoAnimAssetMap.Add(FName(AnimAssetPathNames[i]), SeqAsset);
				continue;
			}
		}
		LocoAnimAssetMap.Add(FName(AnimAssetPathNames[i]), nullptr);
	}
	AnimIns->ObtainLocoSequenceMappingWithPriorityIndex(AnimAssetPriorityIndex, AnimAssetPrioritySemanticTag, LocoAnimAssetMap);
}

void URoleCompositeMgr::UseAShirtControlRig(const int64& OwnerActorID, bool Enable)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::UseAShirtControlRig")
	AActor* OwnerActor = Cast<AActor>(KGUtils::GetObjectByID(OwnerActorID));
	if (!IsValid(OwnerActor))
		return;
	
	USkeletalMeshComponent* SkCom = Cast<USkeletalMeshComponent>( GetMeshComByTagOrMainMesh(OwnerActor, MainMeshName));
	if (!SkCom)
		return;

	if(UBaseAnimInstance* AnimIns = Cast<UBaseAnimInstance>(SkCom->GetAnimInstance()))
	{
		AnimIns->SetEnableASkirtControlRig(Enable);
	}
}

void URoleCompositeMgr::EnableKawaiiAllInOne(bool Enable)
{
	UBaseAnimInstance::SetEnableKawaiiAllInOne(Enable);
}

void URoleCompositeMgr::EnableMainMeshKawaiiOptimize(bool Enable)
{
	UBaseAnimInstance::SetEnableMainMeshKawaiiOptimize(Enable);
}

void URoleCompositeMgr::EnableAttachMeshKawaiiOptimize(bool Enable)
{
	UBaseAnimInstance::SetEnableAttachMeshKawaiiOptimize(Enable);
}

void URoleCompositeMgr::SetMainMeshKawaiiAlphaKeysHelper(const int64& OwnerActorID, const int64& MeshComID, const FName& profileName,const FName& modelPartId, bool Enable, float WindScale /*= 1.0f*/)
{
    if (!IsValid(AvatarModelPartLibPtr)) return;
    if (auto AvatarModelPartLibData = AvatarModelPartLibPtr->AvatarModelPartLibData.Find(profileName))
    {
        if (auto data = AvatarModelPartLibData->AvatarModelPartLibSubData.Find(modelPartId))
        {
            SetMainMeshKawaiiAlphaKeys(OwnerActorID,MeshComID,data->KawaiiAlphaEnableTags,Enable,WindScale);
        }
    }
}

void URoleCompositeMgr::SetMainMeshKawaiiAlphaKeys(const int64& OwnerActorID, const int64& MeshComID, const TArray<FName>& KawaiiAlphaEnableArray, bool Enable, float WindScale /*= 1.0f*/)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetKawaiiAlphaEnable")
	AActor* OwnerActor = Cast<AActor>(KGUtils::GetObjectByID(OwnerActorID));
	if (!IsValid(OwnerActor))
		return;

	if(ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(OwnerActor))
	{
        BaseCharacter->SetMainMeshKawaiiAlphaKeys(MeshComID, KawaiiAlphaEnableArray, Enable, WindScale);
	}
}

void URoleCompositeMgr::SetAttachMeshKawaiiAlphaKeysHelper(const int64& OwnerActorID, const int64& MeshComID, const FName& profileName,const FName& modelPartId, bool Enable, float WindScale /*= 1.0f*/)
{
    if (!IsValid(AvatarModelPartLibPtr)) return;
    if (auto AvatarModelPartLibData = AvatarModelPartLibPtr->AvatarModelPartLibData.Find(profileName))
    {
        if (auto data = AvatarModelPartLibData->AvatarModelPartLibSubData.Find(modelPartId))
        {
            SetAttachMeshKawaiiAlphaKeys(OwnerActorID,MeshComID,data->KawaiiAlphaEnableTags,Enable,WindScale);
        }
    }
}

void URoleCompositeMgr::SetAttachMeshKawaiiAlphaKeys(const int64& OwnerActorID, const int64& MeshComID, const TArray<FName>& KawaiiAlphaEnableArray, bool Enable, float WindScale /*= 1.0f*/)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleCompositeMgr::SetKawaiiAlphaEnable")
	AActor* OwnerActor = Cast<AActor>(KGUtils::GetObjectByID(OwnerActorID));
	if (!IsValid(OwnerActor))
		return;
	
	USkeletalMeshComponent* SkCom = Cast<USkeletalMeshComponent>( GetMeshComByTagOrMainMesh(OwnerActor, MainMeshName));
	if (!SkCom)
		return;

	if(UBaseAnimInstance* AnimIns = Cast<UBaseAnimInstance>(SkCom->GetAnimInstance()))
	{
        AnimIns->SetAttachMeshKawaiiAlphaKeys(MeshComID, KawaiiAlphaEnableArray, Enable, WindScale);
	}
}

#pragma endregion ActorAppearance Lib Anim

#pragma region ActorAppearance Lib Effect
int32 URoleCompositeMgr::CreateAppearanceEffectOffset(const int64& UID, const int64& SpawnerID, const int64& MeshCompId, const FString& NiagaraEffectPath, const FName& SocketName,
	const float& SpawnTrans_LX, const float& SpawnTrans_LY, const float& SpawnTrans_LZ,
	const float& Pitch, const float& Yaw, const float& Roll,
	const float& SpawnTrans_SX, const float& SpawnTrans_SY, const float& SpawnTrans_SZ, bool bActivateImmediately)
{
	UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(this);
	if (!EffectManager)
	{
		return 0;
	}

	FKGPlayNiagaraParams PlayNiagaraParams;
	PlayNiagaraParams.NiagaraEffectPath = NiagaraEffectPath;
	PlayNiagaraParams.bActivateImmediately = bActivateImmediately;
	
	FKGAttachedNiagaraSpawnInfo SpawnInfo;
	SpawnInfo.AttachPointName = SocketName;
	SpawnInfo.SearchAttachComponentType = EKGNiagaraSearchAttachComponentType::UseCustomAttachComponent;
	SpawnInfo.CustomAttachComponent = Cast<USceneComponent>(KGUtils::GetObjectByID(MeshCompId));
	if (!SpawnInfo.CustomAttachComponent.IsValid())
	{
		UE_LOG(RoleCompositeMgrLog, Error, TEXT("URoleCompositeMgr::CreateEffect, invalid custom attach component %lld"), MeshCompId);
		return 0;	
	}

	const FVector SpawnPos = FVector(SpawnTrans_LX, SpawnTrans_LY, SpawnTrans_LZ);
	checkf(!SpawnPos.ContainsNaN(), TEXT("URoleCompositeMgr::AssembleSpawnTrans, spawn pos contains NAN"));
	SpawnInfo.RelativeTrans.SetLocation(SpawnPos);

	const FRotator SpawnRot(Pitch, Yaw, Roll);
	checkf(!SpawnRot.ContainsNaN(), TEXT("URoleCompositeMgr::AssembleSpawnTrans, spawn rot contains NAN"));
	SpawnInfo.RelativeTrans.SetRotation(SpawnRot.Quaternion());

	const FVector SpawnScale = FVector(SpawnTrans_SX, SpawnTrans_SY, SpawnTrans_SZ);
	checkf(!SpawnScale.ContainsNaN(), TEXT("URoleCompositeMgr::AssembleSpawnTrans, spawn scale contains NAN"));
	SpawnInfo.RelativeTrans.SetScale3D(SpawnScale);
	PlayNiagaraParams.SetAttachedSpawnInfo(SpawnInfo);
	PlayNiagaraParams.SpawnerEntityID = UID;
	PlayNiagaraParams.SpawnerID = SpawnerID; 
	PlayNiagaraParams.EffectTags.Add(EKGNiagaraEffectTag::APPEARANCE);
	
	int32 EffectID = EffectManager->CreateNiagaraSystem(PlayNiagaraParams);
	return EffectID;
}

int32 URoleCompositeMgr::CreateAppearanceEffect(const int64& UID, const int64& SpawnerID, const int64& MeshCompId, const FString& NiagaraEffectPath, const FName& SocketName, bool bActivateImmediately)
{
	UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(this);
	if (!EffectManager)
	{
		return 0;
	}

	FKGPlayNiagaraParams PlayNiagaraParams;
	PlayNiagaraParams.NiagaraEffectPath = NiagaraEffectPath;
	PlayNiagaraParams.bActivateImmediately = bActivateImmediately;
	
	FKGAttachedNiagaraSpawnInfo SpawnInfo;
	SpawnInfo.AttachPointName = SocketName;
	SpawnInfo.SearchAttachComponentType = EKGNiagaraSearchAttachComponentType::UseCustomAttachComponent;
	SpawnInfo.CustomAttachComponent = Cast<USceneComponent>(KGUtils::GetObjectByID(MeshCompId));
	if (!SpawnInfo.CustomAttachComponent.IsValid())
	{
		UE_LOG(RoleCompositeMgrLog, Error, TEXT("URoleCompositeMgr::CreateEffect, invalid custom attach component %lld"), MeshCompId);
		return 0;	
	}
	PlayNiagaraParams.SetAttachedSpawnInfo(SpawnInfo);
	PlayNiagaraParams.SpawnerEntityID = UID;
	PlayNiagaraParams.SpawnerID = SpawnerID; 
	PlayNiagaraParams.EffectTags.Add(EKGNiagaraEffectTag::APPEARANCE);
	
	int32 EffectID = EffectManager->CreateNiagaraSystem(PlayNiagaraParams);
	return EffectID;
}
#pragma endregion ActorAppearance Lib Effect

#pragma endregion ActorAppearance Lib

#pragma region BodyPartType Enum/String

TMap<int32, FName> URoleCompositeMgr::AvatarBodyPartTypeStrings;
TMap<FName, int32> URoleCompositeMgr::AvatarBodyPartTypeMap;

FName URoleCompositeMgr::AvatarBodyPartEnumToName(const int32 AvatarBodyPartType)
{
	return AvatarBodyPartTypeStrings.Contains(AvatarBodyPartType) ? AvatarBodyPartTypeStrings[AvatarBodyPartType] : NAME_None;
}

int32 URoleCompositeMgr::AvatarBodyPartNameToEnum(const FName& AvatarBodyPartType)
{
	return AvatarBodyPartTypeMap.Contains(AvatarBodyPartType) ? AvatarBodyPartTypeMap[AvatarBodyPartType] : -1;
}

void URoleCompositeMgr::InitializeEnumMaps()
{
	if (AvatarBodyPartTypeStrings.Num() != 0)
		return;

	AvatarBodyPartTypeStrings.Reserve(30);
	AvatarBodyPartTypeMap.Reserve(30);

	if (const UEnum* Enum = StaticEnum<EAvatarBodyPartType>())
	{
		for (int32 i(0); i < Enum->NumEnums() - 1; ++i)
		{
			const int64 Value = Enum->GetValueByIndex(i);
			const FName Key(Enum->GetDisplayNameTextByIndex(i).ToString().Replace(TEXT(" "), TEXT("")));
			AvatarBodyPartTypeStrings.Add(Value, Key);
			AvatarBodyPartTypeMap.Add(Key, Value);
		}
	}
}

bool URoleCompositeMgr::GetModelHitbox(FName ModelName, FName HitBoxName, FModelHitBoxData& OutData)
{
	if (const auto& ModelHitBoxMap = ModelHitBoxData.Find(ModelName))
	{
		if (const FModelHitBoxData* FoundData = ModelHitBoxMap->Find(HitBoxName))
		{
			OutData = *FoundData;
			return true;
		}
	}

	return false;
}

void URoleCompositeMgr::InitializeModelHitBoxData(TArray<FName> ModelNames, TArray<FModelHitBoxData> DataList)
{
	if (ModelNames.Num() != DataList.Num())
	{
		UE_LOG(RoleCompositeMgrLog, Error, TEXT("URoleCompositeMgr::InitializeModelHitBoxData, ModelNames.Num() != DataList.Num()"));
		return;
	}

	for (int i = 0; i < ModelNames.Num(); i++)
	{
		ModelHitBoxData.FindOrAdd(ModelNames[i]).Emplace(DataList[i].Name, DataList[i]);
	}
}

#pragma endregion BodyPartType Enum/String
