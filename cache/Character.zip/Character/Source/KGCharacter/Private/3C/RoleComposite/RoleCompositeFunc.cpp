#include "3C/RoleComposite/RoleCompositeFunc.h"

#include "3C/Material/KGMaterialManager.h"
#include "Components/StaticMeshComponent.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Engine/StaticMesh.h"

UObject* URoleCompositeFunc::CreateMeshObj(FString MeshPath)
{
	FSoftObjectPath MeshObjPath = FSoftObjectPath(MeshPath);
	FSoftObjectPtr SoftObj(MeshObjPath);
	UObject* MeshAssetObj = SoftObj.LoadSynchronous();
	if (!MeshAssetObj)
	{
		UE_LOG(LogTemp, Warning, TEXT("CreateMeshObj Failed MeshPath %s !"), *MeshPath);
		return nullptr;
	}

	return MeshAssetObj;
}

UStaticMeshComponent* URoleCompositeFunc::LoadAndLinkStaticMeshCom(USceneComponent* Root, UObject* StaticMesh, FName ComponentName)
{
	if (!UKismetSystemLibrary::IsValid(Root) || !UKismetSystemLibrary::IsValid(StaticMesh)
	|| !UKismetSystemLibrary::IsValid(Root->GetOuter()))
		return nullptr;
		 
	UStaticMesh* Mesh = Cast<UStaticMesh>(StaticMesh);
	if (!Mesh)
	{
		return nullptr;
	}

	UStaticMeshComponent* NewComponent = NewObject<UStaticMeshComponent>(Root->GetOuter(), UStaticMeshComponent::StaticClass(), ComponentName);
	if (!NewComponent)
		return nullptr;

	NewComponent->RegisterComponent();

	// NewComponent->SetStaticMesh(Mesh);
	UKGMaterialManager::SetActorStaticMesh(NewComponent, Mesh, true);

	return NewComponent;
}

UActorComponent* URoleCompositeFunc::RegisterActorComponent(AActor* InActor, const TSubclassOf<UActorComponent> ComponentClass)
{
	if (!UKismetSystemLibrary::IsValid(InActor) || !UKismetSystemLibrary::IsValidClass(ComponentClass))
		return nullptr;

	UActorComponent* NewComponent = NewObject<UActorComponent>(InActor, ComponentClass, NAME_None);
	if (!NewComponent)
		return nullptr;

	NewComponent->RegisterComponent();

	return NewComponent;
}


UAnimSequenceBase* URoleCompositeFunc::LoadAnimSequence(FString Path)
{
	FSoftObjectPath MeshObjPath = FSoftObjectPath(Path);
	FSoftObjectPtr SoftObj(MeshObjPath);
	UObject* AssetObj = SoftObj.LoadSynchronous();
	if (!AssetObj || !AssetObj->IsA(UAnimSequenceBase::StaticClass()))
	{
		UE_LOG(LogTemp, Warning, TEXT("LoadAnimSequence Failed Path %s !"), *Path);
		return nullptr;
	}

	return Cast<UAnimSequenceBase>(AssetObj);
}