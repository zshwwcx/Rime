#include "3C/Character/BSUnit.h"
#include "Manager/KGObjectActorManager.h"



#pragma region Important
ABSUnit::ABSUnit(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	if (!HasAnyFlags(RF_ClassDefaultObject))
	{

	}

	PrimaryActorTick.bCanEverTick = true;

	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	SimpleMovementComponent = CreateDefaultSubobject<USimpleMovementComponent>(TEXT("SimpleMovement"));
}

ABSUnit::~ABSUnit()
{
	if (!HasAnyFlags(RF_ClassDefaultObject))
	{

	}
}

void ABSUnit::TickActor(float DeltaTime, ELevelTick TickType, FActorTickFunction& ThisTickFunction)
{
	Super::TickActor(DeltaTime, TickType, ThisTickFunction);

	if (!bIsActive)
	{
		return;
	}

	RunningTime += DeltaTime;
}

#pragma endregion Important



#pragma region Core
void ABSUnit::StartPerformance(float InTotalLife)
{

	bIsActive = true;

	RunningTime = 0.0f;


	TotalLife = InTotalLife;

	bEndOfLife = false;

	bScriptTick = false;

	bServerControlLife = false;


	// 开启Tick
	SetActorTickEnabled(true);
}

void ABSUnit::FinishPerformance()
{
	// 关闭Tick
	SetActorTickEnabled(false);

	// 解绑
	DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);

	// 清理标签
	Tags.Empty();

	bIsActive = false;
}

bool ABSUnit::LifeIsOver()
{
	// 如果服务器控制生命，则直接返回false
	if (bServerControlLife)
	{
		return false;
	}

	return bEndOfLife || (TotalLife >= 0.0f && RunningTime >= TotalLife);
}


#pragma endregion Core



#pragma region StaticProp
void ABSUnit::SetTotalLife(float InTotalLife)
{
	TotalLife = InTotalLife;
}

void ABSUnit::SetScriptTick(bool InTick)
{
	bScriptTick = InTick;
}

void ABSUnit::SetEndOfLife(bool InEnd)
{
	bEndOfLife = InEnd;
}

void ABSUnit::SetServerControlLife(bool InServerControl)
{
	bServerControlLife = InServerControl;
}

#pragma endregion StaticProp



#pragma region DynamicProp
int64 ABSUnit::GetGID()
{
	return GID;
}

bool ABSUnit::GetIsActive()
{
	return bIsActive;
}

void ABSUnit::SetTickRate(float InRate)
{
	CustomTimeDilation = FMath::Max(0.001f, InRate);
}

float ABSUnit::GetTickRate()
{
	return CustomTimeDilation;
}

void ABSUnit::SetRunningTime(float InRunningTime)
{
	RunningTime = InRunningTime;
}

float ABSUnit::GetRunningTime()
{
	return RunningTime;
}

#pragma endregion DynamicProp
