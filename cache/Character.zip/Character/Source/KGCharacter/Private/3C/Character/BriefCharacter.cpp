#include "3C/Character/BriefCharacter.h"

ABriefCharacter::ABriefCharacter(const FObjectInitializer& ObjectInitializer)
{
    PrimaryActorTick.bCanEverTick = true;
    PrimaryActorTick.TickGroup = TG_DuringPhysics;
    SetActorTickInterval(0.0333f);
}

void ABriefCharacter::BeginPlay()
{
	Super::BeginPlay();
	GetRootComponent()->SetMobility(EComponentMobility::Static);
	SetBriefActorLocation(GetActorLocation());

    MovementSimulator.InitBriefOwner(this);
}

void ABriefCharacter::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
    Super::EndPlay(EndPlayReason);
}

bool ABriefCharacter::IsBriefActor()
{
	return true;
}

void ABriefCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
    
    MovementSimulator.Tick(DeltaTime);
    FVector Position;
    FRotator Rotation;
    if (MovementSimulator.SimulatedTick(DeltaTime, Position, Rotation))
	{
		SetBriefActorLocation(Position);
	}
}

void ABriefCharacter::SetTickInterval(float TickInterval)
{
	SetActorTickInterval(TickInterval);
}

void ABriefCharacter::OnReceiveMovementData(MovementData &&MovementData)
{
	MovementSimulator.OnReceiveMovementData(std::move(MovementData));
}

void ABriefCharacter::ReceiveSetLocation(float X, float Y, float Z)
{
    MovementSimulator.Clear(EMoveSimulateClearReason::SetLocationAndRotation);
    SetActorLocation(FVector(X, Y, Z));
}