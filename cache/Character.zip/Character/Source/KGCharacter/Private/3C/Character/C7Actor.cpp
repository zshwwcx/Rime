#include "3C/Character/C7Actor.h"

#include "3C/Core/KGUEActorManager.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/CapsuleComponent.h"
#include "Animation/AnimMontage.h"


void AC7Actor::BeginPlay() {
	Super::BeginPlay();
	EntityUID = 0;
	LogicParentActorId = 0;
	LogicChildObjectIdMapping.Reset();
	

}

void AC7Actor::SetEntityUID(int64 InEntityUID)
{
	EntityUID = InEntityUID;	
}

bool AC7Actor::SetCollisionPresetForRootAndMeshComponents(bool updatedateOverlaps, const FName& SceneRoorPresetName, const FName& ChildPresetName)
{
	return IC7ActorInterface::DoSetCollisionPresetForRootAndMeshComponents(this, updatedateOverlaps, SceneRoorPresetName, ChildPresetName);
}

void AC7Actor::SetTagFromRootAndMeshComps(const FString& InTag)
{
	return IC7ActorInterface::DoSetTagFromRootAndMeshComps(this, InTag);
}

void AC7Actor::SetMinLOD(int32 InNewMinLOD) {
  return IC7ActorInterface::DoSetMinLOD(this, InNewMinLOD);
}


USkeletalMeshComponent* AC7Actor::GetMainMesh()
{
	return GetComponentByClass<USkeletalMeshComponent>();
}

UCapsuleComponent* AC7Actor::GetCapsule()
{
	return GetComponentByClass<UCapsuleComponent>();
}
