#include "3C/Character/SeerAttachActor.h"

#include "3C/Character/BaseCharacter.h"
#include "TimerManager.h"
#include "3C/Effect/KGEffectManager.h"
#include "Managers/KGDataCacheManager.h"
#include "3C/Material/KGMaterialCommon.h"
#include "3C/Material/KGMaterialManager.h"
#include "3C/Util/KGUtils.h"

ASeerAttachActor::ASeerAttachActor(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = false;
}

void ASeerAttachActor::PostInitializeComponents()
{
	Super::PostInitializeComponents();
	
	MeshPropController.BindActor(this, nullptr);
}

void ASeerAttachActor::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	ClearDelayInvisibleTimer();

	// 这里不能依赖entity的保底材质效果清理, 占卜家悬浮武器没有entity
	if (DissolveReqID != 0)
	{
		if (UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(this))
		{
			MaterialManager->RevertMaterialParam(DissolveReqID, EKGMaterialParamRevertType::ClearStateOnly);
		}
		else
		{
			UE_LOG(LogKGMaterial, Warning, TEXT("ASeerAttachActor::EndPlay: MaterialManager is null! Actor:%s"), *GetName());
		}
	}
	
	MeshPropController.UnBindActor();
	
	Super::EndPlay(EndPlayReason);
}

void ASeerAttachActor::SyncVisibilityFromParent(bool bVisible)
{
	const bool bOldVisible = bVisibleByParent && bVisibleBySelf;
	bVisibleByParent = bVisible;
	const bool bNewVisible = bVisibleByParent && bVisibleBySelf;
	if (bOldVisible == bNewVisible)
	{
		return;
	}
	
	DoSetVisibilityByDissolveEffect(bNewVisible);
}

void ASeerAttachActor::SetVisibilityBySelf(int32 EffectID, bool bVisible, const FKGAttachExtraDissolveInfo& ExtraDissolveInfo)
{
	const bool bOldVisible = bVisibleByParent && bVisibleBySelf;
	bVisibleBySelf = bVisible;
	DissolveEffectID = EffectID;
	const bool bNewVisible = bVisibleByParent && bVisibleBySelf;
	if (bOldVisible == bNewVisible)
	{
		return;
	}
	
	auto* MaterialManager = GetOrUpdateMaterialManager();
	if (!MaterialManager)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("ASeerAttachActor::SetVisibilityBySelf: MaterialManager is null! Actor:%s"), *GetName());
		return;
	}

	if (DissolveReqID != 0)
	{
		MaterialManager->RevertMaterialParam(DissolveReqID);
		DissolveReqID = 0;
	}

	ClearDelayInvisibleTimer();
	
	if (EffectID == -1)
	{
		DoSetVisibilityByDissolveEffect(bNewVisible);
	}
	else
	{
		SetVisibilityWithDissolveEffect(EffectID, bNewVisible, ExtraDissolveInfo);	
	}
}

void ASeerAttachActor::SetVisibilityWithDissolveEffect(int32 EffectID, bool bVisible, const FKGAttachExtraDissolveInfo& ExtraDissolveInfo)
{
	if (ExtraDissolveInfo.DissolveType == EKGAttachActorDissolveType::NormalDissolve)
	{
		StartNormalDissolveEffect(EffectID, bVisible, ExtraDissolveInfo);
	}
	else if (ExtraDissolveInfo.DissolveType == EKGAttachActorDissolveType::WeaponDissolve)
	{
		StartWeaponDissolveEffect(EffectID, bVisible, ExtraDissolveInfo);
	}
	else if (ExtraDissolveInfo.DissolveType == EKGAttachActorDissolveType::SeerCardDissolve)
	{
		StartSeerCardDissolveEffect(EffectID, bVisible, ExtraDissolveInfo);
	}
	else
	{
		UE_LOG(LogKGMaterial, Error, TEXT("ASeerAttachActor::SetVisibilityWithDissolveEffect: invalid DissolveType:%d Actor:%s"), 
			static_cast<uint8>(ExtraDissolveInfo.DissolveType), *GetName());
	}
}

void ASeerAttachActor::OnDelayInvisibleTimerTimeout()
{
	UE_LOG(LogKGMaterial, Log, TEXT("ASeerAttachActor::OnDelayInvisibleTimerTimeout: Actor:%s"), *GetName());
	DoSetVisibilityByDissolveEffect(false);

	if (auto* MaterialManager = GetOrUpdateMaterialManager())
	{
		MaterialManager->RevertMaterialParam(DissolveReqID);
		DissolveReqID = 0;
	}
	else
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("ASeerAttachActor::ClearDelayInvisibleTimer: MaterialManager is null! Actor:%s"), *GetName());
	}
}

void ASeerAttachActor::ClearDelayInvisibleTimer()
{
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(DelayInvisibleHandle);
	}
	else
	{
		UE_LOG(LogKGMaterial, Error, TEXT("ASeerAttachActor::ClearDelayInvisibleTimer: World is null! Actor:%s"), *GetName());
	}
}

void ASeerAttachActor::DoSetVisibilityByDissolveEffect(bool bVisible)
{
	const bool bNeedHidden = !bVisible;
	SetActorHiddenInGame(bNeedHidden);
#if WITH_EDITOR
	SetIsTemporarilyHiddenInEditor(bNeedHidden);
#endif

	if (auto* EffectManager = GetOrUpdateEffectManager())
	{
		EffectManager->UpdateEffectVisibilityBySpawnerID(
			KGUtils::GetIDByObject(this), bVisible, static_cast<uint8>(EKGNiagaraHiddenReason::OWNER_SET_HIDDEN));
	}
	else
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("ASeerAttachActor::SetVisibilityForDissolveEffect: EffectManager is null! Actor:%s"), *GetName());
	}
}

void ASeerAttachActor::RefreshMaterialCacheOnAddMeshComponent(KGObjectID MeshComponentID, bool bInheritMaterialEffect)
{
	MeshPropController.OnMeshComponentChanged();
	if (auto* MaterialManager = GetOrUpdateMaterialManager()) 
	{
		MaterialManager->RefreshMaterialCacheOnAddMeshComponent(KGUtils::GetIDByObject(this), MeshComponentID, bInheritMaterialEffect);
	}
}

void ASeerAttachActor::RefreshMaterialCacheOnRemoveMeshComponent(KGObjectID MeshComponentID)
{
	MeshPropController.OnMeshComponentChanged();
	if (auto* MaterialManager = GetOrUpdateMaterialManager())
	{
		MaterialManager->RefreshMaterialCacheOnRemoveMeshComponent(KGUtils::GetIDByObject(this), MeshComponentID);
	}
}

void ASeerAttachActor::StartSeerCardDissolveEffect(int32 EffectID, bool bVisible, const FKGAttachExtraDissolveInfo& ExtraDissolveInfo)
{
	auto* MaterialManager = GetOrUpdateMaterialManager();
	if (!MaterialManager)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("ASeerAttachActor::StartSeerCardDissolveEffect: MaterialManager is null! Actor:%s"), *GetName());
		return;
	}
	
	// 跟策划定了下, 目前这里只有剧情模式用, 一定是前0后8的状态
	DoSetVisibilityByDissolveEffect(bVisible);
	if (ExtraDissolveInfo.bForwardCard)
	{
		return;
	}
	
	if (bVisible)
	{
		DissolveReqID = MaterialManager->StartDissolveMaterialEffectByDissolveEffectID(GetEntityUID(), this, EffectID, true);
		return;
	}
	
	auto* DataCacheManager = GetOrUpdateDataCacheManager();
	if (!DataCacheManager)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("ASeerAttachActor::StartSeerCardDissolveEffect: DataCacheManager is null! Actor:%s"), *GetName());
		return;
	}
	
	auto* DissolveEffectData = DataCacheManager->GetDissolveEffectData(EffectID);
	if (!DissolveEffectData)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("ASeerAttachActor::StartSeerCardDissolveEffect: cannot find DissolveEffectData, Actor:%s, EffectID: %d"),
			*GetName(), EffectID);
		return;
	}
	
	auto* EffectManager = GetOrUpdateEffectManager();
	if (!EffectManager)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("ASeerAttachActor::StartSeerCardDissolveEffect: EffectManager is null! Actor:%s"), *GetName());
		return;
	}
	
	KGActorID ParentActorID = GetLoigcParent();
	if (ParentActorID == KG_INVALID_ACTOR_ID)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("ASeerAttachActor::StartSeerCardDissolveEffect, invalid owner actor id, %s"), *GetName());
		return;
	}

	auto* WeaponOwnerActor = KGUtils::GetActorByID(ParentActorID);
	if (!WeaponOwnerActor)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("ASeerAttachActor::StartSeerCardDissolveEffect, cannot find weapon owner actor"));
		return;
	}
	
	IC7ActorInterface* WeaponOwnerC7ActorInterface = Cast<IC7ActorInterface>(WeaponOwnerActor);
	if (!WeaponOwnerC7ActorInterface)
	{
		UE_LOG(LogKGMaterial, Error, TEXT("ASeerAttachActor::StartSeerCardDissolveEffect, invalid weapon owner, not IC7ActorInterface"));
		return;
	}
	
	USkeletalMeshComponent* SkeletalMeshComponent = FindComponentByClass<USkeletalMeshComponent>();
	if (!SkeletalMeshComponent)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("ASeerAttachActor::StartSeerCardDissolveEffect: SkeletalMeshComponent is null! Actor:%s"), *GetName());
		return;
	}
		
	// 背后卡牌对应的SM是在资源里做好的, 只需要在原地播放即可
	FKGPlayNiagaraParams PlayNiagaraParams;
	PlayNiagaraParams.NiagaraEffectPath = DissolveEffectData->WeaponDissolveSMEffectPath;
	PlayNiagaraParams.SpawnerID = ParentActorID;
	PlayNiagaraParams.SpawnerEntityID = WeaponOwnerC7ActorInterface->GetEntityUID();
	PlayNiagaraParams.EffectPlayRate = DissolveEffectData->WeaponDissolveEffectPlayRate;
	PlayNiagaraParams.TotalLifeMs = DissolveEffectData->Duration * 1000.0f;
	PlayNiagaraParams.bActivateImmediately = true;
	FKGUnattachedNiagaraSpawnInfo SpawnInfo;
	SpawnInfo.SearchSpawnLocationType = EKGNiagaraSearchSpawnLocationType::UseCustomSpawnTrans;
	SpawnInfo.WorldOrRelativeTrans = SkeletalMeshComponent->GetComponentTransform();
	PlayNiagaraParams.SetUnattachedSpawnInfo(SpawnInfo);
	EffectManager->CreateNiagaraSystem(PlayNiagaraParams);
}

void ASeerAttachActor::StartWeaponDissolveEffect(int32 EffectID, bool bVisible, const FKGAttachExtraDissolveInfo& ExtraDissolveInfo)
{
	auto* MaterialManager = GetOrUpdateMaterialManager();
	if (!MaterialManager)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("ASeerAttachActor::StartWeaponDissolveEffect: MaterialManager is null! Actor:%s"), *GetName());
		return;
	}
	
	DoSetVisibilityByDissolveEffect(bVisible);
	
	if (bVisible)
	{
		DissolveReqID = MaterialManager->StartDissolveMaterialEffectByDissolveEffectID(GetEntityUID(), this, EffectID, true);
	}
	else
	{
		auto* EffectManager = GetOrUpdateEffectManager();
		if (!EffectManager)
		{
			UE_LOG(LogKGMaterial, Warning, TEXT("ASeerAttachActor::StartWeaponDissolveEffect: EffectManager is null! Actor:%s"), *GetName());
			return;
		}
		
		auto* DataCacheManager = GetOrUpdateDataCacheManager();
		if (!DataCacheManager)
		{
			UE_LOG(LogKGMaterial, Warning, TEXT("ASeerAttachActor::StartWeaponDissolveEffect: DataCacheManager is null! Actor:%s"), *GetName());
			return;
		}
		
		auto* DissolveEffectData = DataCacheManager->GetDissolveEffectData(EffectID);
		if (!DissolveEffectData)
		{
			UE_LOG(LogKGMaterial, Warning, TEXT("ASeerAttachActor::StartWeaponDissolveEffect: cannot find DissolveEffectData, Actor:%s, EffectID: %d"),
				*GetName(), EffectID);
			return;
		}
		
		KGActorID ParentActorID = GetLoigcParent();
		if (ParentActorID == KG_INVALID_ACTOR_ID)
		{
			UE_LOG(LogKGMaterial, Error, TEXT("ASeerAttachActor::StartWeaponDissolveEffect, invalid owner actor id, %s"), *GetName());
			return;
		}

		auto* WeaponOwnerActor = KGUtils::GetActorByID(ParentActorID);
		if (!WeaponOwnerActor)
		{
			UE_LOG(LogKGMaterial, Warning, TEXT("ASeerAttachActor::StartWeaponDissolveEffect, cannot find weapon owner actor"));
			return;
		}
	
		IC7ActorInterface* WeaponOwnerC7ActorInterface = Cast<IC7ActorInterface>(WeaponOwnerActor);
		if (!WeaponOwnerC7ActorInterface)
		{
			UE_LOG(LogKGMaterial, Error, TEXT("ASeerAttachActor::StartWeaponDissolveEffect, invalid weapon owner, not IC7ActorInterface"));
			return;
		}
		
		EffectManager->CreateWeaponDissolveNiagaraEffect(
			this, 
			ParentActorID, 
			WeaponOwnerC7ActorInterface->GetEntityUID(), 
			DissolveEffectData->WeaponDissolveSKEffectPath,
			DissolveEffectData->WeaponDissolveSMEffectPath, 
			DissolveEffectData->Duration, 
			false, 
			DissolveEffectData->WeaponDissolveEffectPlayRate);
	}
}

void ASeerAttachActor::StartNormalDissolveEffect(int32 EffectID, bool bVisible, const FKGAttachExtraDissolveInfo& ExtraDissolveInfo)
{
	auto* MaterialManager = GetOrUpdateMaterialManager();
	if (!MaterialManager)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("ASeerAttachActor::StartNormalDissolveEffect: MaterialManager is null! Actor:%s"), *GetName());
		return;
	}
	
	if (bVisible)
	{
		DoSetVisibilityByDissolveEffect(true);

		DissolveReqID = MaterialManager->StartDissolveMaterialEffectByDissolveEffectID(GetEntityUID(), this, EffectID, true);
	}
	else
	{
		float DissolveOutTime = 0.0f;
		if (auto* DataCacheManager = GetOrUpdateDataCacheManager())
		{
			if (auto* DissolveEffectData = DataCacheManager->GetDissolveEffectData(EffectID))
			{
				DissolveOutTime = DissolveEffectData->Duration;
			}
			else
			{
				UE_LOG(LogKGMaterial, Warning, TEXT("ASeerAttachActor::StartNormalDissolveEffect: DissolveEffectData is null! EffectID:%d Actor:%s"), EffectID, *GetName());
			}
		}
		else
		{
			UE_LOG(LogKGMaterial, Warning, TEXT("ASeerAttachActor::StartNormalDissolveEffect: DataCacheManager is null! Actor:%s"), *GetName());
		}

		if (FMath::IsNearlyZero(DissolveOutTime))
		{
			DoSetVisibilityByDissolveEffect(false);
		}
		else
		{
			DissolveReqID = MaterialManager->StartDissolveMaterialEffectByDissolveEffectID(GetEntityUID(), this, EffectID, false);

			if (UWorld* World = GetWorld())
			{
				World->GetTimerManager().SetTimer(DelayInvisibleHandle,
					FTimerDelegate::CreateUObject(this, &ASeerAttachActor::OnDelayInvisibleTimerTimeout), DissolveOutTime, false);
			}
			else
			{
				UE_LOG(LogKGMaterial, Error, TEXT("ASeerAttachActor::StartNormalDissolveEffect: World is null! Actor:%s"), *GetName());
			}
		}
	}
}

UKGMaterialManager* ASeerAttachActor::GetOrUpdateMaterialManager()
{
	if (CachedMaterialManager.IsValid())
	{
		return CachedMaterialManager.Get();
	}
	
	UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(this);
	if (!MaterialManager)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("ASeerAttachActor::GetOrUpdateMaterialManager: MaterialManager is null! Actor:%s"), *GetName());
	}
	else
	{
		CachedMaterialManager = MaterialManager;
	}
	return MaterialManager;
}

UKGEffectManager* ASeerAttachActor::GetOrUpdateEffectManager()
{
	if (CachedEffectManager.IsValid())
	{
		return CachedEffectManager.Get();
	}
	
	UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(this);
	if (!EffectManager)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("ASeerAttachActor::GetOrUpdateEffectManager: EffectManager is null! Actor:%s"), *GetName());
	}
	else
	{
		CachedEffectManager = EffectManager;
	}
	return EffectManager;
}

UKGDataCacheManager* ASeerAttachActor::GetOrUpdateDataCacheManager()
{
	if (CachedDataCacheManager.IsValid())
	{
		return CachedDataCacheManager.Get();
	}
	
	UKGDataCacheManager* DataCacheManager = UKGDataCacheManager::GetInstance(this);
	if (!DataCacheManager)
	{
		UE_LOG(LogKGMaterial, Warning, TEXT("ASeerAttachActor::GetOrUpdateDataCacheManager: DataCacheManager is null! Actor:%s"), *GetName());
	}
	else
	{
		CachedDataCacheManager = DataCacheManager;
	}
	return DataCacheManager;
}
