#include "3C/Character/C7DecalActor.h"

#include "3C/Util/AbilityCollisionUtil.h"
#include "KGCharacterModule.h"
#include "Manager/KGCppAssetManager.h"
#include "3C/Core/KGUEActorManager.h"
#include "TimerManager.h"
#include "Components/CapsuleComponent.h"
#include "Components/DecalComponent.h"
#include "3C/Effect/KGEffectManager.h"
#include "Managers/KGCombatUnitManager.h"
#include "3C/Material/KGMaterialManager.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Materials/MaterialInterface.h"
#include "3C/Util/KGActorUtil.h"
#include "3C/Util/KGUtils.h"

AC7DecalActor::AC7DecalActor(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = false;
}

void AC7DecalActor::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (RotMode == EDecalRotationMode::PointAtInstigator)
	{
		
		if (ActorManager.IsValid() && CombatUnitManager.IsValid())
		{
			if (auto* InstigatorEntity = ActorManager->GetLuaEntity(InstigatorEntityID))
			{
				// 根据PosMode不同设置不同trans
				if (PosMode == EDecalPositionMode::Follow)
				{
					AActor* SpawnerActor = GetSpawnerActor();
					if (!SpawnerActor)
					{
						UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::Tick SpawnerActor is null %s"), *GetDebugInfo());
						return ;
					}

					USceneComponent* AttachComponent = UKGActorUtil::GetComponentBySocket(SpawnerActor, AttachBoneName, false);
					if (AttachComponent == nullptr)
					{
						UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::Tick AttachComponent is null for Actor %s, socket %s"),
							*SpawnerActor->GetName(), *AttachBoneName.ToString());
						return ;
					}

					FTransform SocketTransform = AttachComponent->GetSocketTransform(AttachBoneName);

					const FVector SpawnerActorLoc = SocketTransform.GetLocation();
					const FVector TargetLocation = InstigatorEntity->GetLocation();
					const FVector Dir2D = (TargetLocation - SpawnerActorLoc).GetSafeNormal2D();
					SocketTransform.SetRotation(Dir2D.ToOrientationQuat());
					SocketTransform.SetScale3D(FVector::OneVector);

					FTransform ResTransform;
					ResTransform = DeltaTransform * SocketTransform;
					ResTransform.SetRotation(ResTransform.GetRotation() * CombatUnitManager->GetDefaultDecalQuat());

					SetActorTransform(ResTransform);
				}
				else
				{
					// 位置不变，旋转会变
					const FVector DecalLocation = GetActorLocation();
					const FVector TargetLocation = InstigatorEntity->GetLocation();
					const FVector Dir2D = (TargetLocation - DecalLocation).GetSafeNormal2D();

					SetActorRotation(DeltaTransform.GetRotation() * Dir2D.ToOrientationQuat() * CombatUnitManager->GetDefaultDecalQuat());
				}

			}
			// 没找到是合理的情况, 比如角色出AOI了, 再进AOI时还需要恢复朝向
		}
	}
}

void AC7DecalActor::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (!bHasExitWorld)
	{
		ExitWorld();
	}
	
	Super::EndPlay(EndPlayReason);
}

bool AC7DecalActor::CalculateDecalSpawnTransform(
	EDecalPositionMode InPosMode, EDecalRotationMode InRotMode, const FTransform& InTransform, const FName& InAttachBoneName, FTransform& OutTransform)
{
	SCOPED_NAMED_EVENT(AC7DecalActor_CalculateDecalSpawnTransform, FColor::Red);
	if (!UpdateAndCacheManagers())
	{
		return false;
	}
	check(CombatUnitManager.IsValid());

	
	if (InPosMode == EDecalPositionMode::World && InRotMode == EDecalRotationMode::World)
	{
		// 直接作为relative transform
		OutTransform = InTransform;
		OutTransform.SetRotation(OutTransform.GetRotation() * CombatUnitManager->GetDefaultDecalQuat());
		return true;
	}


	AActor* SpawnerActor = GetSpawnerActor();
	if (!SpawnerActor)
	{
		UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::CalculateSpawnTransform SpawnerActor is null %s"), *GetDebugInfo());
		return false;
	}

	USceneComponent* AttachComponent = UKGActorUtil::GetComponentBySocket(SpawnerActor, InAttachBoneName, false);
	if (AttachComponent == nullptr)
	{
		UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::RefreshDecalTransform AttachComponent is null for Actor %s, socket %s"),
			*SpawnerActor->GetName(), *InAttachBoneName.ToString());
		return false;
	}

	FTransform SocketTransform = AttachComponent->GetSocketTransform(InAttachBoneName);

	if (InRotMode == EDecalRotationMode::PointAtInstigator)
	{
		if (ActorManager.IsValid())
		{
			if (auto* InstigatorEntity = ActorManager->GetLuaEntity(InstigatorEntityID))
			{
				const FVector SpawnerActorLoc = SocketTransform.GetLocation();
				const FVector TargetLocation = InstigatorEntity->GetLocation();
				const FVector Dir2D = (TargetLocation - SpawnerActorLoc).GetSafeNormal2D();
				SocketTransform.SetRotation(Dir2D.ToOrientationQuat());
			}
		}
	}
	
	/*UE_LOG(LogTemp, Warning, TEXT("ZZPZZP decal SocketTransform %s"), *SocketTransform.GetLocation().ToString());*/
	SocketTransform.SetScale3D(FVector::OneVector);
	OutTransform = InTransform * SocketTransform;
	OutTransform.SetRotation(OutTransform.GetRotation() * CombatUnitManager->GetDefaultDecalQuat());
	if (InPosMode == EDecalPositionMode::World)
	{
		OutTransform.SetLocation(InTransform.GetLocation());
	}

	if (InRotMode == EDecalRotationMode::World)
	{
		OutTransform.SetRotation(InTransform.GetRotation() * CombatUnitManager->GetDefaultDecalQuat());
	}

	return true;
}

void AC7DecalActor::TryFitGround(FTransform& OutTransform)
{
	AActor* SpawnerActor = GetSpawnerActor();
	if (!SpawnerActor)
	{
		UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::TryFitGround SpawnerActor is null"));
		return;
	}

	UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(this);
	if (!EffectManager)
	{
		UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::TryFitGround EffectManager is null"));
		return;
	}

	FVector GroundLoc = OutTransform.GetLocation();
	EffectManager->CheckGroundLocation(this, false, GroundLoc);
	OutTransform.SetLocation(GroundLoc);
}

bool AC7DecalActor::InitParamsByTemplate(
	const FKGDecalConfigData& InDecalConfigData, TWeakObjectPtr<UKGUEActorManager> InActorManager, TWeakObjectPtr<UKGCombatUnitManager> InCombatUnitManager,
	KGEntityID InSpawnerEntityID, KGEntityID InInstigatorEntityID, 
	const FTransform& InTransform, EDecalPositionMode InPosMode, EDecalRotationMode InRotMode, const FName& InAttachBoneName, bool bInAbsoluteScale, float DecalSizeX,
	bool bInUseColor, float ColorR, float ColorG, float ColorB, float ColorA,
	bool bInUseGlowColor, float GlowColorR, float GlowColorG, float GlowColorB, float GlowColorA,
	bool bInNeedCheckGround, float InFadeInTimeSeconds, float InFadeOutTimeSeconds, float InLifeTimeSeconds, float InDissolveTimeSeconds,
	EDecalShapeType InShapeType, float InLength, float InWidth, float InAngle, float InRadius,
	float InInnerRadius, float InOuterRadius, float InFillingDuration, const FString& FillCurvePath, bool bInLoopControl,
	EDecalPointAtTargetType InPointAtTargetType, EDecalRecFillMode InRecFillMode, EDecalCircleLikeFillMode InCircleLikeFillMode,
	EDecalRecDissolveMode RecDissolveMode, EDecalCircleLikeDissolveMode CircleLikeDissolveMode)
{
	SCOPED_NAMED_EVENT(AC7DecalActor_InitParamsByTemplate, FColor::Red);
	check(InCombatUnitManager.IsValid());
	check(InActorManager.IsValid());
	
	UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::InitParams %s"), *GetDebugInfo());
	MaterialPath = InDecalConfigData.MatPath;
	SpawnerEntityID = InSpawnerEntityID;
	InstigatorEntityID = InInstigatorEntityID;
	ActorManager = InActorManager;
	CombatUnitManager = InCombatUnitManager;

	DissolveTimeSeconds = InDissolveTimeSeconds;
	FadeInTimeSeconds = FMath::Max(0.0f, InFadeInTimeSeconds);;
	FadeOutTimeSeconds = FMath::Max(0.0f, InFadeOutTimeSeconds);;
	FillingDuration = InFillingDuration;
	ControlCurvePath = FillCurvePath;
	bLoopControl = bInLoopControl;
	LifeTimeSeconds = InLifeTimeSeconds;

	PosMode = InPosMode;
	RotMode = InRotMode;
	DeltaTransform = InTransform;
	AttachBoneName = InAttachBoneName;


	PointAtTargetType = InPointAtTargetType;
	
	if (FMath::IsNearlyZero(FillingDuration))
	{
		DynamicMaterialFloatParams.Add(CombatUnitManager->GetControlMaterialParamName(), 1.0f);
	}
	
	if (bInUseColor)
	{
		FLinearColor ColorParam(ColorR, ColorG, ColorB, ColorA);
		if (FVector4(ColorParam).ContainsNaN())
		{
			UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::InitParams: ColorParam contains NaN"));	
		}
		else
		{
			DynamicMaterialColorParams.Add(CombatUnitManager->GetColorMaterialParamName(), ColorParam);
		}
	}

	if (bInUseGlowColor)
	{
		FLinearColor GlowColorParam(GlowColorR, GlowColorG, GlowColorB, GlowColorA);
		if (FVector4(GlowColorParam).ContainsNaN())
		{
			UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::InitParams: GlowColorParam contains NaN"));	
		}
		else
		{
			DynamicMaterialColorParams.Add(CombatUnitManager->GetGlowColorMaterialParamName(), GlowColorParam);
		}
	}	

	const auto& ControlModeParamName = CombatUnitManager->GetControlModeMaterialParamName();
	const auto& DissolveModeParamName = CombatUnitManager->GetDissolveModeMaterialParamName();
	DecalSize.X = DecalSizeX;
	if (InShapeType == EDecalShapeType::Rectangle)
	{
		DecalSize.Y = InWidth;
		DecalSize.Z = InLength;
		FLinearColor ControlMode;
		if (CombatUnitManager->GetRecFillModeParam(InRecFillMode, ControlMode))
		{
			DynamicMaterialColorParams.Add(ControlModeParamName, ControlMode);
		}
		FLinearColor DissolveMode;
		if (CombatUnitManager->GetRecDissolveModeParam(RecDissolveMode, DissolveMode))
		{
			DynamicMaterialColorParams.Add(DissolveModeParamName, DissolveMode);
		}
	}
	else if (InShapeType == EDecalShapeType::Sector)
	{
		DecalSize.Y = InRadius;
		DecalSize.Z = InRadius;
		FLinearColor ControlMode;
		if (CombatUnitManager->GetCircleLikeFillModeParam(InCircleLikeFillMode, ControlMode))
		{
			DynamicMaterialColorParams.Add(ControlModeParamName, ControlMode);
		}
		DynamicMaterialFloatParams.Add(CombatUnitManager->GetSectorAngleMaterialParamName(), InAngle);
		FLinearColor DissolveMode;
		if (CombatUnitManager->GetCircleLikeDissolveModeParam(CircleLikeDissolveMode, DissolveMode))
		{
			DynamicMaterialColorParams.Add(DissolveModeParamName, DissolveMode);
		}
	}
	else if (InShapeType == EDecalShapeType::Circle)
	{
		DecalSize.Y = InRadius;
		DecalSize.Z = InRadius;
		FLinearColor ControlMode;
		if (CombatUnitManager->GetCircleLikeFillModeParam(InCircleLikeFillMode, ControlMode))
		{
			DynamicMaterialColorParams.Add(ControlModeParamName, ControlMode);
		}
		FLinearColor DissolveMode;
		if (CombatUnitManager->GetCircleLikeDissolveModeParam(CircleLikeDissolveMode, DissolveMode))
		{
			DynamicMaterialColorParams.Add(DissolveModeParamName, DissolveMode);
		}
	}
	else if (InShapeType == EDecalShapeType::Ring)
	{
		DecalSize.Y = InOuterRadius;
		DecalSize.Z = InOuterRadius;
		FLinearColor ControlMode;
		if (CombatUnitManager->GetCircleLikeFillModeParam(InCircleLikeFillMode, ControlMode))
		{
			DynamicMaterialColorParams.Add(ControlModeParamName, ControlMode);
		}
		DynamicMaterialFloatParams.Add(CombatUnitManager->GetInnerCircleSizeMaterialParamName(), InInnerRadius);
		FLinearColor DissolveMode;
		if (CombatUnitManager->GetCircleLikeDissolveModeParam(CircleLikeDissolveMode, DissolveMode))
		{
			DynamicMaterialColorParams.Add(DissolveModeParamName, DissolveMode);
		}
	}
	else
	{
		UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::InitParams invalid ShapeType %d"), static_cast<int32>(InShapeType));
		return false;
	}

	DynamicMaterialColorParams.Add(CombatUnitManager->GetDecalWorldSizeMaterialParamName(), FLinearColor(DecalSize));

	UpdateDecalTransform(
		InPosMode, InRotMode, InAttachBoneName, bInAbsoluteScale, bInNeedCheckGround, InTransform);
	
	return true;
}

bool AC7DecalActor::InitParamsCustomized(
	KGEntityID InSpawnerEntityID, TWeakObjectPtr<UKGUEActorManager> InActorManager, TWeakObjectPtr<UKGCombatUnitManager> InCombatUnitManager, KGEntityID InInstigatorEntityID,
	const FString& InMaterialPath, float DecalSizeX, float DecalSizeY, float DecalSizeZ,
	EDecalPositionMode InPosMode, EDecalRotationMode InRotMode, const FName& InAttachBoneName, bool bAbsoluteScale, bool bNeedCheckGround, const FTransform& InTransform,
	float InFadeInTimeSeconds, float InFadeOutTimeSeconds, float InLifeTimeSeconds, float InDissolveTimeSeconds,
	bool bOverrideAngle, float Angle, bool bOverrideInnerRadius, float InnerRadius, bool bOverrideOuterRadius, float OuterRadius,
	bool bOverrideControl, EDecalParamModifyType ControlModifyType, float ConstControlValue, float ControlDuration, const FString& InControlCurvePath,
	bool bInLoopControl, EDecalPointAtTargetType InPointAtTargetType)
{
	SCOPED_NAMED_EVENT(AC7DecalActor_InitParamsCustomized, FColor::Red);
	check(InCombatUnitManager.IsValid());
	check(InActorManager.IsValid());
	
	UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::InitParams %s"), *GetDebugInfo());
	MaterialPath = InMaterialPath;
	SpawnerEntityID = InSpawnerEntityID;
	ActorManager = InActorManager;
	CombatUnitManager = InCombatUnitManager;

	FadeInTimeSeconds = FMath::Max(0.0f, InFadeInTimeSeconds);
	FadeOutTimeSeconds = FMath::Max(0.0f, InFadeOutTimeSeconds);;
	LifeTimeSeconds = InLifeTimeSeconds;
	DissolveTimeSeconds = InDissolveTimeSeconds;
	PointAtTargetType = InPointAtTargetType;
	InstigatorEntityID = InInstigatorEntityID;

	PosMode = InPosMode;
	RotMode = InRotMode;
	DeltaTransform = InTransform;
	AttachBoneName = InAttachBoneName;

	DecalSize = FVector(DecalSizeX, DecalSizeY, DecalSizeZ);

	if (bOverrideAngle)
	{
		DynamicMaterialFloatParams.Add(CombatUnitManager->GetSectorAngleMaterialParamName(), Angle);
	}

	if (bOverrideInnerRadius)
	{
		DynamicMaterialFloatParams.Add(CombatUnitManager->GetInnerCircleSizeMaterialParamName(), InnerRadius);
	}

	if (bOverrideOuterRadius)
	{
		DynamicMaterialFloatParams.Add(CombatUnitManager->GetOuterRadiusMaterialParamName(), OuterRadius);
	}
	
	DynamicMaterialColorParams.Add(CombatUnitManager->GetDecalWorldSizeMaterialParamName(), FLinearColor(DecalSize));

	if (bOverrideControl)
	{
		if (ControlModifyType == EDecalParamModifyType::ConstantValue)
		{
			DynamicMaterialFloatParams.Add(CombatUnitManager->GetControlMaterialParamName(), ConstControlValue);
		}
		else if (ControlModifyType == EDecalParamModifyType::LinearSample)
		{
			FillingDuration = ControlDuration;
		}
		else if (ControlModifyType == EDecalParamModifyType::Curve)
		{
			FillingDuration = ControlDuration;
			ControlCurvePath = InControlCurvePath;
			bLoopControl = bInLoopControl;
		}	
	}
	
	UpdateDecalTransform(
		InPosMode,InRotMode, AttachBoneName, bAbsoluteScale, bNeedCheckGround, InTransform);
	
	return true;
}

bool AC7DecalActor::InitParamsByDecalSpawnParams(const FKGSimpleDecalSpawnParams& Params,
	TWeakObjectPtr<UKGUEActorManager> InActorManager, TWeakObjectPtr<UKGCombatUnitManager> InCombatUnitManager)
{
	SCOPED_NAMED_EVENT(AC7DecalActor_InitParamsCustomized, FColor::Red);
	check(InCombatUnitManager.IsValid());
	check(InActorManager.IsValid());
	
	UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::InitParams %s"), *GetDebugInfo());
	MaterialPath = Params.MaterialPath;
	SpawnerEntityID = KG_INVALID_ENTITY_ID;
	SpawnerActorPtr = Params.SpawnerActor;
	ActorManager = InActorManager;
	CombatUnitManager = InCombatUnitManager;
	
	FadeInTimeSeconds = FMath::Max(0.0f, Params.FadeInTimeSeconds);
	FadeOutTimeSeconds = FMath::Max(0.0f, Params.FadeOutTimeSeconds);
	OpacityStartVal = Params.OpacityStartVal;
	OpacityEndVal = Params.OpacityEndVal;
	LifeTimeSeconds = Params.LifeTimeSeconds;
	
	DecalSize = Params.DecalSize;
	DynamicMaterialColorParams.Add(CombatUnitManager->GetDecalWorldSizeMaterialParamName(), FLinearColor(DecalSize));
	
	// 如果没有FadeInTime,直接设置到End
	if (FadeInTimeSeconds <= UE_KINDA_SMALL_NUMBER)
	{
		DynamicMaterialFloatParams.Add(CombatUnitManager->GetOpacityMaterialParamName(), OpacityEndVal);	
	}
	
	UpdateDecalTransform(
		Params.PosMode, Params.RotMode, Params.AttachBoneName,  Params.bAbsoluteScale,
		Params.bNeedCheckGround, Params.Transform);
	return true;
}

void AC7DecalActor::EnterWorld()
{
	SCOPED_NAMED_EVENT(AC7DecalActor_EnterWorld, FColor::Red);
	
	// 加载材质
	UpdateAndCacheManagers();

	// 设置life timer
	if (LifeTimeSeconds > UE_KINDA_SMALL_NUMBER)
	{
		if (UWorld* World = GetWorld())
		{
			UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::EnterWorld set life timer %f seconds, %s"), LifeTimeSeconds, *GetDebugInfo());
			World->GetTimerManager().SetTimer(
				LifeTimerHandle, FTimerDelegate::CreateUObject(this, &AC7DecalActor::OnLifeTimeExpired), LifeTimeSeconds, false);

			// 按照策划需求, 从 LifeTimeSeconds - DissolveTimeSeconds 开始溶解（反向填充）
			if (DissolveTimeSeconds > UE_KINDA_SMALL_NUMBER)
			{
				const auto DelayTimeToDissolveStart = LifeTimeSeconds - DissolveTimeSeconds;
				if (DelayTimeToDissolveStart > UE_KINDA_SMALL_NUMBER)
				{
					UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::EnterWorld set dissolve timer %f seconds after enter world, %s"),
						DelayTimeToDissolveStart, *GetDebugInfo());
					World->GetTimerManager().SetTimer(
						DissolveTimerHandle, FTimerDelegate::CreateUObject(this, &AC7DecalActor::StartDissolve),
						DelayTimeToDissolveStart, false);	
				}
				else
				{
					StartDissolve();
				}
			}
		}
		else
		{
			UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::EnterWorld World is null"));
		}	
	}
	
	if (AssetManager.IsValid())
	{
		UObject* LoadedMaterial = nullptr;
		AssetLoadID = AssetManager->AsyncLoadAsset(
			MaterialPath, LoadedMaterial, FAsyncLoadCompleteDelegate::CreateUObject(this, &AC7DecalActor::OnMaterialLoaded, true));
		if (LoadedMaterial)
		{
			OnMaterialLoaded(AssetLoadID, LoadedMaterial, false);
		}
		else
		{
			SetDecalHiddenInGame(true, EKGDecalHiddenReason::LoadingMaterial);
		}
	}
}

void AC7DecalActor::ExitWorld()
{
	SCOPED_NAMED_EVENT(AC7DecalActor_ExitWorld, FColor::Red);
	UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::ExitWorld %s"), *GetDebugInfo());

	if (bHasExitWorld)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("AC7DecalActor::ExitWorld has already exited world %s"), *GetDebugInfo());
		return;
	}
	bHasExitWorld = true;

	UpdateAndCacheManagers();
	if (AssetLoadID != 0)
	{
		if (AssetManager.IsValid())
		{
			AssetManager->CancelAsyncLoadByLoadID(AssetLoadID);
		}
	}

	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(LifeTimerHandle);
		World->GetTimerManager().ClearTimer(FadeOutTimerHandle);
		World->GetTimerManager().ClearTimer(DissolveTimerHandle);
	}
	else
	{
		UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::ExitWorld World is null"));
	}

	if (TickTaskIDs.Num() > 0)
	{
		if (MaterialManager.IsValid())
		{
			for (const auto TaskID : TickTaskIDs)
			{
				MaterialManager->RemoveMaterialParamUpdateTask(TaskID);
			}	
		}	
	}

	if (AssetManager.IsValid())
	{
		for (const auto& Kvp : DynamicMaterialTextureParams)
		{
			if (Kvp.Value.LoadID != 0)
			{
				AssetManager->CancelAsyncLoadByLoadID(Kvp.Value.LoadID);
			}
		}
	}
}

bool AC7DecalActor::FadeOut()
{
	if (!UpdateAndCacheManagers())
	{
		return false;
	}
	check(MaterialManager.IsValid());
	check(CombatUnitManager.IsValid());
	
	if (FadeOutTimeSeconds <= UE_KINDA_SMALL_NUMBER)
	{
		UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::FadeOut both FadeOutTimeSeconds and DissolveTimeSeconds are zero, %s"), *GetDebugInfo());
		return false;
	}
	
	UWorld* World = GetWorld();
	if (!World)
	{
		UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::FadeOut World is null, %s"), *GetDebugInfo());
		return false;
	}
	
	UDecalComponent* DecalComp = GetDecal();
	if (!DecalComp)
	{
		UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::FadeOut DecalComponent is null"));
		return false;
	}

	UMaterialInstanceDynamic* MaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(DecalComp->GetDecalMaterial());
	if (!MaterialInstanceDynamic)
	{
		UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::FadeOut MaterialInstanceDynamic is null"));
		return false;
	}
	
	UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::FadeOut start fade out, %s, FadeOutTimeSeconds=%f"), *GetDebugInfo(), FadeOutTimeSeconds);
	const auto TaskID = MaterialManager->UpdateOrAddLinearSampleParamTargetValueWithNewDuration(
		OpacityChangeTaskID, CombatUnitManager->GetOpacityMaterialParamName(), MaterialInstanceDynamic,
		OpacityEndVal, 0.0f, FadeOutTimeSeconds);
	TickTaskIDs.Add(TaskID);

	World->GetTimerManager().ClearTimer(FadeOutTimerHandle);
	World->GetTimerManager().SetTimer(
		FadeOutTimerHandle, FTimerDelegate::CreateUObject(this, &AC7DecalActor::OnFadeOutTimeExpired), FadeOutTimeSeconds, false);
	return true;
}

void AC7DecalActor::StartDissolve()
{
	if (!UpdateAndCacheManagers())
	{
		return;
	}
	check(MaterialManager.IsValid());
	check(CombatUnitManager.IsValid());
	
	if (DissolveTimeSeconds <= UE_KINDA_SMALL_NUMBER)
	{
		UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::StartDissolve invalid DissolveTimeSeconds, %s"), *GetDebugInfo());
		return;
	}
	
	UDecalComponent* DecalComp = GetDecal();
	if (!DecalComp)
	{
		UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::StartDissolve DecalComponent is null"));
		return;
	}

	UMaterialInstanceDynamic* MaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(DecalComp->GetDecalMaterial());
	if (!MaterialInstanceDynamic)
	{
		UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::StartDissolve MaterialInstanceDynamic is null, delay dissolve"));
		bShouldStartDissolve = true;
	}
	else
	{
		UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::StartDissolve start dissolve, %s, DissolveTimeSeconds=%f"), *GetDebugInfo(), DissolveTimeSeconds);
		const auto TaskID = MaterialManager->AddScalarLinearSampleParamByDynamicMaterialInstance(
			CombatUnitManager->GetDissolveProgressMaterialParamName(), MaterialInstanceDynamic,
			0.0f, 1.0f, DissolveTimeSeconds, false);
		TickTaskIDs.Add(TaskID);	
	}
}

void AC7DecalActor::SetTextureMaterialParam(const FName& ParamName, const FString& TexturePath)
{
	UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::SetTextureMaterialParam %s, ParamName=%s, TexturePath=%s"),
		*GetDebugInfo(), *ParamName.ToString(), *TexturePath);
	UpdateAndCacheManagers();
	if (AssetManager.IsValid())
	{
		FKGDecalTextureParamLoadInfo LoadInfo;
		LoadInfo.TexturePath = TexturePath;
		LoadInfo.LoadID = AssetManager->AsyncLoadAsset(
			TexturePath, FAsyncLoadCompleteDelegate::CreateUObject(this, &AC7DecalActor::OnTextureLoaded, ParamName));
		DynamicMaterialTextureParams.Add(ParamName, LoadInfo);
	}
}

void AC7DecalActor::SetVectorMaterialParam(const FName& ParamName, const FLinearColor& Value)
{
	UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::SetVectorMaterialParam %s, ParamName=%s, Value=%s"),
		*GetDebugInfo(), *ParamName.ToString(), *Value.ToString());
	DynamicMaterialColorParams.Add(ParamName, Value);
	if (UMaterialInstanceDynamic* DynamicMaterialInstance = Cast<UMaterialInstanceDynamic>(GetDecalMaterial()))
	{
		DynamicMaterialInstance->SetVectorParameterValue(ParamName, Value);
	}
}

void AC7DecalActor::SetFloatMaterialParam(const FName& ParamName, float Value)
{
	UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::SetFloatMaterialParam %s, ParamName=%s, Value=%f"),
		*GetDebugInfo(), *ParamName.ToString(), Value);
	DynamicMaterialFloatParams.Add(ParamName, Value);
	if (UMaterialInstanceDynamic* DynamicMaterialInstance = Cast<UMaterialInstanceDynamic>(GetDecalMaterial()))
	{
		DynamicMaterialInstance->SetScalarParameterValue(ParamName, Value);
	}
}

void AC7DecalActor::SetDecalSize(float SizeX, float SizeY, float SizeZ)
{
	UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::SetDecalSize %s, SizeX=%f, SizeY=%f, SizeZ=%f"),
		*GetDebugInfo(), SizeX, SizeY, SizeZ);
	if (UDecalComponent* DecalComp = GetDecal())
	{
		DecalComp->DecalSize.X = SizeX;
		DecalComp->DecalSize.Y = SizeY;
		DecalComp->DecalSize.Z = SizeZ;
	}
	
	if (CombatUnitManager.IsValid())
	{
		FLinearColor DecalWorldSize(FVector(SizeX, SizeY, SizeZ));
		UE_CLOG(FVector4(DecalWorldSize).ContainsNaN(), LogKGCombat, Error, TEXT("AC7DecalActor::SetDecalSize DecalWorldSize contains NaN"));
		const auto& ParamName = CombatUnitManager->GetDecalWorldSizeMaterialParamName();
		DynamicMaterialColorParams.Add(ParamName, DecalWorldSize);
		if (UMaterialInstanceDynamic* DynamicMaterialInstance = Cast<UMaterialInstanceDynamic>(GetDecalMaterial()))
		{
			DynamicMaterialInstance->SetVectorParameterValue(ParamName, DecalWorldSize);
		}
	}
}

void AC7DecalActor::SetAbsolute(bool bNewAbsoluteLocation, bool bNewAbsoluteRotation, bool bNewAbsoluteScale)
{
	UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::SetAbsolute %s, bNewAbsoluteLocation=%d, bNewAbsoluteRotation=%d, bNewAbsoluteScale=%d"),
		*GetDebugInfo(), bNewAbsoluteLocation, bNewAbsoluteRotation, bNewAbsoluteScale);
	if (RootComponent)
	{
		RootComponent->SetAbsolute(bNewAbsoluteLocation, bNewAbsoluteRotation, bNewAbsoluteScale);
	}
	else
	{
		UE_LOG(LogKGCombat, Warning, TEXT("AC7DecalActor::SetAbsolute RootComponent is null"));
	}
}

KGActorID AC7DecalActor::GetActorID()
{
	return KGUtils::GetIDByObject(this);
}

void AC7DecalActor::SetDecalHiddenInGame(bool bHiddenDecal, EKGDecalHiddenReason Reason)
{
	UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::SetDecalHiddenInGame %s, bHiddenDecal=%d, Reason=%d"),
		*GetDebugInfo(), bHiddenDecal, static_cast<int32>(Reason));
	const bool bOldIsHidden = HiddenReason.Num() > 0;
	if (bHiddenDecal)
	{
		HiddenReason.Add(Reason);
	}
	else
	{
		HiddenReason.Remove(Reason);
	}
	const bool bNewIsHidden = HiddenReason.Num() > 0;
	if (bOldIsHidden != bNewIsHidden)
	{
		SetActorHiddenInGame(bNewIsHidden);
	}
}


void AC7DecalActor::UpdateDecalTransform(
	EDecalPositionMode InPosMode, EDecalRotationMode InRotMode, const FName& InAttachBoneName, bool bInAbsoluteScale, bool bInNeedCheckGround, const FTransform& InTransform)
{
	// 对于RotMode == EDecalRotationMode::PointAtInstigator，会在tick中更新transform，这里不做attach
	bool bNeedAttach = ((InPosMode == EDecalPositionMode::Follow || InRotMode == EDecalRotationMode::Follow || bInAbsoluteScale) && InRotMode != EDecalRotationMode::PointAtInstigator);
	if (bNeedAttach)
	{
		AActor* SpawnerActor = GetSpawnerActor();
		if (!SpawnerActor)
		{
			UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::UpdateDecalTransform SpawnerActor is null"));
		}
		else
		{
			AttachToActor(SpawnerActor, FAttachmentTransformRules::KeepRelativeTransform, InAttachBoneName);
		
			if (RootComponent)
			{
				bool bAbsoluteRotation = (InRotMode == EDecalRotationMode::Init || InRotMode == EDecalRotationMode::World);
				bool bAbsoluteTranslation = (InPosMode == EDecalPositionMode::Init || InPosMode == EDecalPositionMode::World);
				if (bAbsoluteTranslation || bAbsoluteRotation || bInAbsoluteScale)
				{
					RootComponent->SetAbsolute(bAbsoluteTranslation, bAbsoluteRotation, bInAbsoluteScale);
				}
			}
			else
			{
				UE_LOG(LogKGCombat, Warning, TEXT("AC7DecalActor::RefreshDecalTransform RootComponent is null"));
			}	
		}
	}

	FTransform OutTransform;
	if (!CalculateDecalSpawnTransform(InPosMode, InRotMode, InTransform, InAttachBoneName, OutTransform))
	{
		UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::UpdateDecalTransform CalculateDecalSpawnTransform failed, %s"), *GetDebugInfo());
		return;
	}

	if (bInNeedCheckGround)
	{
		TryFitGround(OutTransform);
	}
	
	//UE_LOG(LogTemp, Warning, TEXT("ZZPZZP decal OutTransform %s"), *OutTransform.GetLocation().ToString());

	SetActorTransform(OutTransform);
}

AActor* AC7DecalActor::GetSpawnerActor()
{
	if (SpawnerActorPtr.IsValid())
	{
		return SpawnerActorPtr.Get();
	}

	if (!ActorManager.IsValid())
	{
		UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::RefreshDecalTransform ActorManager is null"));
		return nullptr;
	}

	auto* SpawnerEntity = ActorManager->GetLuaEntity(SpawnerEntityID);
	if (!SpawnerEntity)
	{
		UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::RefreshDecalTransform SpawnerEntity is null for ID %lld"), SpawnerEntityID);
		return nullptr;
	}

	SpawnerActorPtr = SpawnerEntity->GetLuaEntityBase()->GetActor();
	return SpawnerActorPtr.Get();
}

void AC7DecalActor::OnMaterialLoaded(int InLoadID, UObject* LoadedAsset, bool bAsyncAssetLoadCallback)
{
	if (bAsyncAssetLoadCallback)
	{
		AssetLoadID = 0;	
	}
	
	if (bAssetLoaded)
	{
		return;
	}
	bAssetLoaded = true;
	
	SCOPED_NAMED_EVENT(AC7DecalActor_OnMaterialLoaded, FColor::Red);
	UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::OnMaterialLoaded %s, %s"), *GetDebugInfo(), *MaterialPath);
	
	UMaterialInterface* MaterialInterface = Cast<UMaterialInterface>(LoadedAsset);
	if (MaterialInterface == nullptr)
	{
		UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::OnMaterialLoaded failed to load material for %s"), *MaterialPath);
		return;
	}
	
	SetDecalHiddenInGame(false, EKGDecalHiddenReason::LoadingMaterial);

	if (UDecalComponent* DecalComp = GetDecal())
	{
		DecalComp->SetDecalMaterial(MaterialInterface);
		DecalComp->CreateDynamicMaterialInstance();
		DecalComp->DecalSize = DecalSize;
	}
	else
	{
		UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::OnMaterialLoaded DecalComponent is null"));
	}

	// 设置材质参数
	ChangeMaterialParams();
	
	if (RotMode == EDecalRotationMode::PointAtInstigator)
	{
		if (InstigatorEntityID == KG_INVALID_ENTITY_ID)
		{
			UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::OnMaterialLoaded InstigatorEntityID is invalid"));
		}
		else
		{
			SetDecalPointAtInstigator();
		}
	}
}

void AC7DecalActor::SetDecalPointAtInstigator()
{
	SetActorTickEnabled(true);
	bPointAtInstigator = true;
}

void AC7DecalActor::OnLifeTimeExpired()
{
	SCOPED_NAMED_EVENT(AC7DecalActor_OnLifeTimeExpired, FColor::Red);
	UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::OnLifeTimeExpired %s"), *GetDebugInfo());

	if (CombatUnitManager.IsValid())
	{
		CombatUnitManager->DestroyDecal(this, true);
	}
	else
	{
		UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::OnLifeTimeExpired CombatUnitManager is null"));
	}
}

void AC7DecalActor::OnFadeOutTimeExpired()
{
	SCOPED_NAMED_EVENT(AC7DecalActor_OnFadeOutTimeExpired, FColor::Red);
	UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::OnFadeOutTimeExpired %s"), *GetDebugInfo());

	if (CombatUnitManager.IsValid())
	{
		CombatUnitManager->DestroyDecal(this, false);
	}
	else
	{
		UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::OnLifeTimeExpired CombatUnitManager is null"));
	}
}

void AC7DecalActor::ChangeMaterialParams()
{
	UDecalComponent* DecalComp = GetDecal();
	if (!DecalComp)
	{
		UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::ChangeMaterialParams DecalComponent is null"));
		return;
	}

	UMaterialInstanceDynamic* MaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(DecalComp->GetDecalMaterial());
	if (!MaterialInstanceDynamic)
	{
		UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::ChangeMaterialParams MaterialInstanceDynamic is null"));
		return;
	}

	if (!UpdateAndCacheManagers())
	{
		return;
	}
	check(CombatUnitManager.IsValid());
	check(MaterialManager.IsValid());

	BATCH_DMIPARAM_SCOPE(MaterialInstanceDynamic);
	for (const auto& FloatParam : DynamicMaterialFloatParams)
	{
		UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::ChangeMaterialParams Set Float Param %s = %f"), *FloatParam.Key.ToString(), FloatParam.Value);
		MaterialInstanceDynamic->SetGameScalarParameterValue(FloatParam.Key, FloatParam.Value);
	}

	for (const auto& ColorParam : DynamicMaterialColorParams)
	{
		UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::ChangeMaterialParams Set Color Param %s = %s"), *ColorParam.Key.ToString(), *ColorParam.Value.ToString());
		MaterialInstanceDynamic->SetGameVectorParameterValue(ColorParam.Key, ColorParam.Value);
	}

	for (const auto& TextureParam : DynamicMaterialTextureParams)
	{
		if (TextureParam.Value.Texture != nullptr)
		{
			UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::ChangeMaterialParams Set Texture Param %s = %s"),
				*TextureParam.Key.ToString(), *TextureParam.Value.Texture->GetPathName());
			MaterialInstanceDynamic->SetGameTextureParameterValue(TextureParam.Key, TextureParam.Value.Texture);
		}
	}
	
	if (FillingDuration > UE_KINDA_SMALL_NUMBER)
	{
		uint32 TaskID;
		if (ControlCurvePath.IsEmpty())
		{
			TaskID = MaterialManager->AddScalarLinearSampleParamByDynamicMaterialInstance(
				CombatUnitManager->GetControlMaterialParamName(), MaterialInstanceDynamic,
				0.0f, 1.0f, FillingDuration, false);
		}
		else
		{
			TaskID = MaterialManager->AddCurveParamByDynamicMaterialInstance(
				CombatUnitManager->GetControlMaterialParamName(), MaterialInstanceDynamic,
				ControlCurvePath, true, FillingDuration, bLoopControl, false);
		}
		TickTaskIDs.Add(TaskID);
	}

	if (FadeInTimeSeconds > UE_KINDA_SMALL_NUMBER)
	{
		OpacityChangeTaskID = MaterialManager->AddScalarLinearSampleParamByDynamicMaterialInstance(
			CombatUnitManager->GetOpacityMaterialParamName(), MaterialInstanceDynamic,
			OpacityStartVal, OpacityEndVal, FadeInTimeSeconds, false, true);
		TickTaskIDs.Add(OpacityChangeTaskID);
	}

	if (bShouldStartDissolve)
	{
		if (DissolveTimeSeconds > UE_KINDA_SMALL_NUMBER)
		{
			UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::ChangeMaterialParams, delay start dissolve, %s, DissolveTimeSeconds=%f"), *GetDebugInfo(), DissolveTimeSeconds);
			const auto TaskID = MaterialManager->AddScalarLinearSampleParamByDynamicMaterialInstance(
				CombatUnitManager->GetDissolveProgressMaterialParamName(), MaterialInstanceDynamic,
				0.0f, 1.0f, DissolveTimeSeconds, false);
			TickTaskIDs.Add(TaskID);	
		}
		else
		{
			UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::ChangeMaterialParams, delay start dissolve but invalid DissolveTimeSeconds, %s"), *GetDebugInfo());
		}
	}
}

void AC7DecalActor::OnTextureLoaded(int InLoadID, UObject* LoadedAsset, FName ParamName)
{
	if (!DynamicMaterialTextureParams.Contains(ParamName))
	{
		UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::OnTextureLoaded no load info for ParamName %s, %s"), *ParamName.ToString(), *GetDebugInfo());
		return;
	}

	auto& LoadInfo = DynamicMaterialTextureParams[ParamName];
	LoadInfo.LoadID = 0;

	UTexture* Texture = Cast<UTexture>(LoadedAsset);
	if (Texture == nullptr)
	{
		UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::OnTextureLoaded failed to load texture for ParamName %s, %s"), *ParamName.ToString(), *GetDebugInfo());
		return;
	}

	UE_LOG(LogKGCombat, Log, TEXT("AC7DecalActor::OnTextureLoaded loaded texture for ParamName %s, %s"), *ParamName.ToString(), *GetDebugInfo());
	LoadInfo.Texture = Texture;

	if (UMaterialInstanceDynamic* DynamicMaterialInstance = Cast<UMaterialInstanceDynamic>(GetDecalMaterial()))
	{
		DynamicMaterialInstance->SetTextureParameterValue(ParamName, Texture);
		DynamicMaterialTextureParams.Remove(ParamName);
	}
}

bool AC7DecalActor::UpdateAndCacheManagers()
{
	if (!MaterialManager.IsValid())
	{
		MaterialManager = UKGMaterialManager::GetInstance(this);
		if (!MaterialManager.IsValid())
		{
			UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::UpdateAndCacheManagers ActorManager is null, %s"), *GetDebugInfo());
			return false;
		}
	}
	
	if (!AssetManager.IsValid())
	{
		AssetManager = UKGCppAssetManager::GetInstance(this);
		if (!AssetManager.IsValid())
		{
			UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::UpdateAndCacheManagers AssetManager is null, %s"), *GetDebugInfo());
			return false;
		}
	}
	
	// ActorManager和CombatUnitManager从外部传入, 不需要在这里获取
	if (!ActorManager.IsValid())
	{
		UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::UpdateAndCacheManagers ActorManager is null, %s"), *GetDebugInfo());
		return false;
	}

	if (!CombatUnitManager.IsValid())
	{
		UE_LOG(LogKGCombat, Error, TEXT("AC7DecalActor::UpdateAndCacheManagers CombatUnitManager is null, %s"), *GetDebugInfo());
		return false;
	}

	return true;
}

FString AC7DecalActor::GetDebugInfo() const
{
	return FString::Printf(TEXT("%s, Material: %s, InstID: %d"), *GetName(), *MaterialPath, DecalInstID);
}

