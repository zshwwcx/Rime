#include "3C/Character/BulletActor.h"

#include "AkComponent.h"
#include "Manager/KGAkAudioManager.h"
#include "3C/Audio/KGAudioNotifyHelper.h"
#include "KGCharacterModule.h"
#include "3C/Movement/SimpleMovementComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "3C/Effect/KGEffectManager.h"
#include "GameFramework/Character.h"
#include "Managers/KGCombatUnitManager.h"
#include "3C/Util/KGUtils.h"
#include "TimerManager.h"
#include "3C/Component/AttackCollisionComponent.h"
#include "3C/Component/PerfectDodgeComponent.h"

bool GEnableBulletDebug = false;
static FAutoConsoleVariableRef CVarEnableBulletDebug(
	TEXT("gp.EnableBulletDebug"),
	GEnableBulletDebug,
	TEXT("EnableBulletDebug."),
	ECVF_Default
);


ABulletActor::ABulletActor(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	SimpleMovementComponent = CreateDefaultSubobject<USimpleMovementComponent>(TEXT("SimpleMovement"));

	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = false;	
}

bool ABulletActor::CalculateSpawnTransform(
	UKGUEActorManager* ActorManager, const FBulletData& InBulletData, KGEntityID LauncherID, KGEntityID TargetID,
	const FVector& StartPos, const FRotator& StartRot, const FVector& ServerPosOffset,
	const FRotator& ServerRotOffset, EKGBulletOffsetMode OffsetMode, FTransform& OutTransform, bool bInALSAiming)
{
	if (!ActorManager)
	{
		UE_LOG(LogKGCombat, Error, TEXT("ABulletActor::CalculateSpawnTransform ActorManager is null"));
		return false;
	}

	OutTransform.SetLocation(StartPos);
	OutTransform.SetRotation(StartRot.Quaternion());
	
	if (InBulletData.TrailType == EKGBulletTrailType::MissileNoMiss)
	{
		ICppEntityInterface* LauncherEntity = nullptr;
		if (LauncherID != KG_INVALID_ENTITY_ID)
		{
			LauncherEntity = ActorManager->GetLuaEntity(LauncherID);
		}

		if (!LauncherEntity)
		{
			return true;
		}

		if (OffsetMode == EKGBulletOffsetMode::Target)
		{
			if (TargetID != KG_INVALID_ENTITY_ID)
			{
				if (auto* TargetEntity = ActorManager->GetLuaEntity(TargetID))
				{
					LauncherEntity = TargetEntity;
				}
			}
		}
		
		AActor* LauncherActor = LauncherEntity->GetLuaEntityBase()->GetActor();
		if (!IsValid(LauncherActor))
		{
			OutTransform.SetLocation(LauncherEntity->GetLocation());
			OutTransform.SetRotation(LauncherEntity->GetRotation().Quaternion());
			return true;
		}

		if (!InBulletData.StartPosAnchorBone.IsEmpty())
		{
			if (ACharacter* Character = Cast<ACharacter>(LauncherActor))
			{
				if (auto* MainMesh = Character->GetMesh())
				{
					OutTransform = MainMesh->GetSocketTransform(FName(*InBulletData.StartPosAnchorBone), RTS_World);
				}
			}
		}
		else
		{
			OutTransform = LauncherActor->GetTransform();
		}

		const FVector& NewLocation = OutTransform.TransformPosition(InBulletData.StartPosAnchorOffset + ServerPosOffset);
		OutTransform.SetLocation(NewLocation);

		if (!bInALSAiming)
		{
			FRotator NewRotation = ServerRotOffset + LauncherEntity->GetRotation();
			NewRotation.Roll = 0.0f;
			OutTransform.SetRotation(NewRotation.Quaternion());	
		}
		else
		{
			FRotator AimingRotation = LauncherEntity->GetALSAimingRotation();
			AimingRotation.Roll = 0.f;
			OutTransform.SetRotation(AimingRotation.Quaternion());	
		}

		OutTransform.SetScale3D(FVector::OneVector);
		return true;
	}

	return true;
}

void ABulletActor::PostInitializeComponents()
{
	Super::PostInitializeComponents();

	// 在world未加载好的情况下创建BulletActor, 此时可能调用顺序是先EnterWorld, 后BeginPlay, 对应Timer中的OwnerActor未准备好
	// 所以将这里提前到Initialize阶段
	DelayPerformTimer.SetOwnerActor(this);
	LifeTimer.SetOwnerActor(this);
}

void ABulletActor::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	DelayPerformTimer.UpdateTickTimer(DeltaSeconds);
	LifeTimer.UpdateTickTimer(DeltaSeconds);
	
#if KG_ENABLE_BULLET_DRAW_DEBUG
	if (GEnableBulletDebug)
	{
		UWorld* World = GetWorld();
		if (!World)
		{
			return;
		}
		
		const FVector CurrentPos = GetActorLocation();
		DrawDebugPoint(World, CurrentPos, 10.0f, FColor::Red, false, 0.2f, 0);
		DrawDebugDirectionalArrow(World, CurrentPos, CurrentPos + GetActorForwardVector() * 20.0f, 2.0f, FColor::Blue, false, 0.2f, 0, 2.0f);
	}
#endif
}

void ABulletActor::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	// 避免以外销毁时，定时器还在回调
	if (!bHasExitWorld)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("ABulletActor::EndPlay Bullet not exit world before EndPlay, %s"), *GetDebugInfo());
		ExitWorld(EKGBulletDestroyReason::UNDEFINED);
	}
	
	Super::EndPlay(EndPlayReason);
}

void ABulletActor::InitParams(
	const FBulletData& InBulletData, KGEntityID InLauncherID, KGEntityID InInstigatorID, KGEntityID InTargetID, float InLifeTimeSeconds,
	const FVector& InTargetPosFromServer, const FVector& InStartPos, const FRotator& InStartRot, float InDestroyNiagaraLifeTimeSeconds,
	uint64 InInstID, int32 InBulletAudioFadeTimeMS)
{
	BulletData = InBulletData;
	LauncherID = InLauncherID;
	InstigatorID = InInstigatorID;
	TargetID = InTargetID;
	TargetPosFromServer = InTargetPosFromServer;
	check(!TargetPosFromServer.ContainsNaN());
	StartPos = InStartPos;
	check(!StartPos.ContainsNaN());
	StartRot = InStartRot;
	check(!StartRot.ContainsNaN());
	DestroyNiagaraLifeTimeSeconds = InDestroyNiagaraLifeTimeSeconds;
	BulletAudioFadeTimeMS = InBulletAudioFadeTimeMS;
	InstID = InInstID;
	
	if (InLifeTimeSeconds <= 0.0f || FMath::IsNearlyZero(InLifeTimeSeconds))
	{
		LifeTimeSeconds = BulletData.MaxLifeTime;
	}
	else
	{
		LifeTimeSeconds = InLifeTimeSeconds;
	}
	
	if (BulletData.TrailType == EKGBulletTrailType::Parabola && FMath::IsNearlyZero(BulletData.MaxLifeTime))
	{
		if (FMath::IsNearlyZero(BulletData.Velocity))
		{
			UE_LOG(LogKGCombat, Error, TEXT("ABulletActor::InitParams Parabola bullet with zero velocity and zero MaxLifeTime, %d"), BulletData.ID);
		}
		else
		{
			LifeTimeSeconds = (InTargetPosFromServer - StartPos).Size2D() / BulletData.Velocity;
		}
	}
}

void ABulletActor::EnterWorld()
{
	SCOPED_NAMED_EVENT(ABulletActor_EnterWorld, FColor::Red);
	
	UE_LOG(LogKGCombat, Log, TEXT("ABulletActor::EnterWorld %s"), *GetDebugInfo());
	
	PlayNiagaraEffect(BulletData.BulletSpawnEffectData, LifeTimeSeconds + BulletData.DelayLaunchTime, BulletData.SpawnEffectFollowType, true);
	TrailEffectID = PlayNiagaraEffect(BulletData.BulletTrailEffectData, LifeTimeSeconds + BulletData.DelayLaunchTime + BulletData.TrailEffectDelayDestroyTime, BulletData.TrailEffectFollowType, false);

	FireAudioPlayingID = PlayAudio(BulletData.FireAudioName, true);

	if (BulletData.bEnableWaterWave && BulletData.WaterWaveRadius > 0.0f)
	{
		if (SimpleMovementComponent)
		{
			SimpleMovementComponent->AddWaterWavDetectParam(true, BulletData.DepthThreshold, BulletData.DistanceThreshold, BulletData.WaterWaveRadius);
			SimpleMovementComponent->AddWaterWaveMoveParam(BulletData.WaveMotorTextureID, BulletData.ScaleX, BulletData.ScaleY, BulletData.MaxHeight, BulletData.FoamScale);
		}
		else
		{
			UE_LOG(LogKGCombat, Error, TEXT("ABulletActor::EnterWorld SimpleMovementComponent is null, %s"), *GetDebugInfo());
		}
	}

	if (BulletData.DelayLaunchTime > UE_KINDA_SMALL_NUMBER)
	{
		DelayPerformTimer.InitOnceTimer(
			BulletData.DelayLaunchTime, FTimerDelegate::CreateUObject(this, &ABulletActor::StartBulletPerformance), !bUseTimeDilation);
	}
	else
	{
		StartBulletPerformance();
	}
	
	// 暂不支持时停效果扩散到其他子弹
	// TryInheritTimeDilationEffect();
	
#if KG_ENABLE_BULLET_DRAW_DEBUG
	if (GEnableBulletDebug)
	{
		UpdateActorTickState();
	}
#endif
}

void ABulletActor::ExitWorld(EKGBulletDestroyReason DestroyReason)
{
	if (bHasExitWorld)
	{
		return;
	}
	bHasExitWorld = true;

	SCOPED_NAMED_EVENT(ABulletActor_ExitWorld, FColor::Red);
	UE_LOG(LogKGCombat, Log, TEXT("ABulletActor::ExitWorld %s"), *GetDebugInfo());
	
	if (FireAudioPlayingID != AK_INVALID_PLAYING_ID && AkAudioManagerPtr.IsValid())
	{
		AkAudioManagerPtr->InnerStopEventForSkill(FireAudioPlayingID, BulletAudioFadeTimeMS, EAkCurveInterpolation::Linear);
		FireAudioPlayingID = AK_INVALID_PLAYING_ID;
	}

	PlayAudio(BulletData.FadeAudioName, false);

	if (!((DestroyReason == EKGBulletDestroyReason::HIT_TARGET && !BulletData.VFXData.HitEffectPath.IsEmpty()) ||
		(BulletData.TrailType == EKGBulletTrailType::MissileNoMiss && bHasTarget)) &&
		!IsHidden())
	{
		// hidden的情况下销毁特效没必要创建
		PlayNiagaraEffect(BulletData.BulletDestroyEffectData, DestroyNiagaraLifeTimeSeconds, EKGBulletNiagaraFollowType::NotFollow, false);
	}

	DelayPerformTimer.ClearTimer();
	LifeTimer.ClearTimer();

	if (EffectManagerPtr.IsValid())
	{
		if (TrailEffectID != 0)
		{
			if (BulletData.TrailEffectDelayDestroyTime > UE_KINDA_SMALL_NUMBER)
			{
				EffectManagerPtr->SetNiagaraDelayDestroy(TrailEffectID, BulletData.TrailEffectDelayDestroyTime * 1000);
			}
			else
			{
				EffectManagerPtr->DestroyNiagaraSystem(TrailEffectID);
			}
		}

		const auto ActorID = KGUtils::GetIDByObject(this);
		EffectManagerPtr->DestroyNiagarasBySpawnerId(ActorID, true);
	}
}

void ABulletActor::LoseTarget()
{
	if (BulletData.TrailType == EKGBulletTrailType::Missile ||
		BulletData.TrailType == EKGBulletTrailType::ParabolaWithTrack)
	{
		if (SimpleMovementComponent)
		{
			SimpleMovementComponent->MustMoveInLine();
		}
	}
}

void ABulletActor::StartTimeDilationEffect(bool bInUseTimeDilation)
{
	UE_LOG(LogKGCombat, Log, TEXT("ABulletActor::StartTimeDilationEffect %s, bInUseTimeDilation: %d"), *GetDebugInfo(), bInUseTimeDilation);
	bUseTimeDilation = bInUseTimeDilation;
	DelayPerformTimer.ChangeTimerMode(bUseTimeDilation);
	LifeTimer.ChangeTimerMode(bUseTimeDilation);
	UpdateActorTickState();
}

void ABulletActor::TryInheritTimeDilationEffect()
{
	if (InstigatorID == KG_INVALID_ENTITY_ID)
	{
		return;
	}

	if (!ActorManagerPtr.IsValid())
	{
		ActorManagerPtr = UKGUEActorManager::GetInstance(this);
		if (!ActorManagerPtr.IsValid())
		{
			UE_LOG(LogKGCombat, Error, TEXT("ABulletActor::TryInheritTimeDilationEffect ActorManager is null"));
			return;
		}	
	}
	
	auto* Entity = ActorManagerPtr->GetLuaEntity(InstigatorID);
	if (!Entity)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("ABulletActor::TryInheritTimeDilationEffect InstigatorEntity is null, %s"), *GetDebugInfo());
		return;
	}

	AActor* InstigatorActor = Entity->GetLuaEntityBase()->GetActor();
	if (!IsValid(InstigatorActor))
	{
		UE_LOG(LogKGCombat, Log, TEXT("ABulletActor::TryInheritTimeDilationEffect InstigatorActor is null, %s"), *GetDebugInfo());
		return;
	}

	UPerfectDodgeComponent* PerfectDodgeComp = InstigatorActor->FindComponentByClass<UPerfectDodgeComponent>();
	if (PerfectDodgeComp && PerfectDodgeComp->IsPerfectDodgeActive())
	{
		PerfectDodgeComp->AddChildUnitsEnableTimeDilation(this);
		StartTimeDilationEffect(true);
	}
}

void ABulletActor::UpdateHiddenState(bool bNewHidden)
{
	SetActorHiddenInGame(bNewHidden);
	
	if (EffectManagerPtr.IsValid())
	{
		const auto ActorID = KGUtils::GetIDByObject(this);
		EffectManagerPtr->UpdateEffectVisibilityBySpawnerID(ActorID, !bNewHidden, static_cast<uint8>(EKGNiagaraHiddenReason::OWNER_SET_HIDDEN));
	}
}

int32 ABulletActor::PlayNiagaraEffect(const FBulletEffectData& EffectData, float InLifeTimeSeconds, EKGBulletNiagaraFollowType FollowType, bool bDestroyWhenSpawnerExitWorld)
{
	if (EffectData.EffectPath.IsEmpty())
	{
		return 0;
	}
	
	if (!EffectManagerPtr.IsValid())
	{
		EffectManagerPtr = UKGEffectManager::GetInstance(this);
		if (!EffectManagerPtr.IsValid())
		{
			UE_LOG(LogKGCombat, Error, TEXT("ABulletActor::PlayNiagaraEffect EffectManager is null, %s"), *GetDebugInfo());
			return 0;
		}	
	}

	const auto ActorID = KGUtils::GetIDByObject(this);

	FKGPlayNiagaraParams PlayNiagaraParams;
	PlayNiagaraParams.NiagaraEffectPath = EffectData.EffectPath;
	PlayNiagaraParams.EffectTags.Add(EKGNiagaraEffectTag::BATTLE);
	PlayNiagaraParams.SpawnerID = ActorID;
	PlayNiagaraParams.SpawnerEntityID = LauncherID;
	PlayNiagaraParams.InstigatorEntityID = InstigatorID;
	PlayNiagaraParams.TotalLifeMs = InLifeTimeSeconds * 1000.0f;
	PlayNiagaraParams.bDestroyWhenSpawnerExitWorld = bDestroyWhenSpawnerExitWorld;
	PlayNiagaraParams.bFollowHidden = true;
	PlayNiagaraParams.NiagaraBusinessPriority = BulletData.EffectPriority;
	
	if (FollowType == EKGBulletNiagaraFollowType::NotFollow)
	{
		FKGUnattachedNiagaraSpawnInfo SpawnInfo;
		SpawnInfo.SearchSpawnLocationType = EKGNiagaraSearchSpawnLocationType::UseActorTransform;
		SpawnInfo.WorldOrRelativeTrans.SetLocation(EffectData.EffectOffset);
		SpawnInfo.WorldOrRelativeTrans.SetRotation(EffectData.EffectRotation.Quaternion());
		SpawnInfo.WorldOrRelativeTrans.SetScale3D(EffectData.EffectScale);
		PlayNiagaraParams.SetUnattachedSpawnInfo(SpawnInfo);
	}
	else
	{
		FKGAttachedNiagaraSpawnInfo SpawnInfo;
		SpawnInfo.SearchAttachComponentType = EKGNiagaraSearchAttachComponentType::UseRootComponent;
		SpawnInfo.RelativeTrans.SetLocation(EffectData.EffectOffset);
		SpawnInfo.RelativeTrans.SetRotation(EffectData.EffectRotation.Quaternion());
		SpawnInfo.RelativeTrans.SetScale3D(EffectData.EffectScale);
		SpawnInfo.bAbsoluteScale = !EffectData.bFollowScale;
		if (FollowType == EKGBulletNiagaraFollowType::OnlyFollowPos)
		{
			SpawnInfo.bAbsoluteRotation = true;
		}
		PlayNiagaraParams.SetAttachedSpawnInfo(SpawnInfo);
	}

	return EffectManagerPtr->CreateNiagaraSystem(PlayNiagaraParams);
}

int32 ABulletActor::PlayAudio(const FString& AudioName, bool bPostOnActor)
{
	if (AudioName.IsEmpty())
	{
		return 0;
	}

	if (InstigatorID == KG_INVALID_ENTITY_ID)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("ABulletActor::PlayAudio InstigatorID is invalid, %s"), *GetDebugInfo());
		return 0;
	}

	if (!ActorManagerPtr.IsValid())
	{
		ActorManagerPtr = UKGUEActorManager::GetInstance(this);
		if (!ActorManagerPtr.IsValid())
		{
			UE_LOG(LogKGCombat, Error, TEXT("ABulletActor::PlayAudio ActorManager is null"));
			return 0;
		}	
	}

	auto* InstigatorEntity = ActorManagerPtr->GetLuaEntity(InstigatorID);
	if (!InstigatorEntity)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("ABulletActor::PlayAudio InstigatorEntity is null, %s"), *GetDebugInfo());
		return 0;
	}

	if (!AkAudioManagerPtr.IsValid())
	{
		AkAudioManagerPtr = UKGAkAudioManager::GetInstance(this);
		if (!AkAudioManagerPtr.IsValid())
		{
			UE_LOG(LogKGCombat, Error, TEXT("ABulletActor::PlayAudio UKGAkAudioManager is null"));
			return 0;
		}	
	}
	
	if (bPostOnActor && !AkComponent)
	{
		AkComponent = NewObject<UAkComponent>(this);
		AkComponent->SetupAttachment(RootComponent);
		AkComponent->RegisterComponent();
		AkComponent->StopWhenOwnerDestroyed = false;
	}

	bool bFromLocal = InstigatorEntity->GetIsMainPlayer();
	const auto& ActorLocation = GetActorLocation();
	return AkAudioManagerPtr->InnerPostEventForSkill(AudioName, KGUtils::GetIDByObject(this), bFromLocal, false, false, bPostOnActor, ActorLocation.X, ActorLocation.Y, ActorLocation.Z, true, false, false, false);
}

void ABulletActor::StartBulletPerformance()
{
	UE_LOG(LogKGCombat, Log, TEXT("ABulletActor::StartBulletPerformance %s"), *GetDebugInfo());

	switch (BulletData.TrailType)
	{
	case EKGBulletTrailType::Direction:
		LaunchBullet_Direction();
		break;
	case EKGBulletTrailType::Line:
		LaunchBullet_Line();
		break;
	case EKGBulletTrailType::Missile:
		LaunchBullet_Missile();
		break;
	case EKGBulletTrailType::MissileNoMiss:
		LaunchBullet_MissileNoMiss();
		break;
	case EKGBulletTrailType::Parabola:
		LaunchBullet_Parabola();
		break;
	case EKGBulletTrailType::ParabolaWithTrack:
		LaunchBullet_ParabolaWithTrack();
		break;
	case EKGBulletTrailType::Round:
		LaunchBullet_Round();
		break;
	case EKGBulletTrailType::Curve:
	default:
		UE_LOG(LogKGCombat, Warning, TEXT("ABulletActor::StartBulletPerformance unsupported TrailType %d, %s"), (int)BulletData.TrailType, *GetDebugInfo());
		break;
	}

	float LifeTime = LifeTimeSeconds + BulletData.DelayDestroyTime;
	if (LifeTime > UE_KINDA_SMALL_NUMBER)
	{
		UE_LOG(LogKGCombat, Log, TEXT("ABulletActor::StartBulletPerformance set life timer %f seconds, %s"), LifeTime, *GetDebugInfo());
		LifeTimer.InitOnceTimer(LifeTime, FTimerDelegate::CreateUObject(this, &ABulletActor::OnLifeTimerExpired), !bUseTimeDilation);
	}
	
	StartPerfectDodgeCheck();
}

void ABulletActor::UpdateActorTickState()
{
	const bool bShouldTick = ShouldTickActor();
	const bool bIsTickEnabled = IsActorTickEnabled();
	if (bShouldTick != bIsTickEnabled)
	{
		SetActorTickEnabled(bShouldTick);
	}
}

bool ABulletActor::ShouldTickActor() const
{
	return bUseTimeDilation || GEnableBulletDebug;
}

void ABulletActor::OnLifeTimerExpired()
{
	UE_LOG(LogKGCombat, Log, TEXT("ABulletActor::OnLifeTimerExpired %s"), *GetDebugInfo());

	if (UKGCombatUnitManager* CombatUnitManager = UKGCombatUnitManager::GetInstance(this))
	{
		CombatUnitManager->DestroyBullet(this, EKGBulletDestroyReason::END_OF_LIFE);
	}
	else
	{
		UE_LOG(LogKGCombat, Error, TEXT("ABulletActor::OnLifeTimerExpired CombatUnitManager is null, %s"), *GetDebugInfo());
	}
}

void ABulletActor::LaunchBullet_Direction()
{
	float Duration = BulletData.MaxLifeTime;
	float CalcDis = BulletData.Velocity * Duration;
	if (BulletData.MoveDist >= 0.0f && BulletData.MoveDist < CalcDis)
	{
		if (BulletData.Velocity < UE_KINDA_SMALL_NUMBER)
		{
			UE_LOG(LogKGCombat, Error, TEXT("ABulletActor::LaunchBullet_Direction bullet with zero velocity %s"), *GetDebugInfo());
		}
		else
		{
			Duration = BulletData.MoveDist / BulletData.Velocity;	
		}
	}

	LifeTimeSeconds = Duration;
	if (SimpleMovementComponent)
	{
		SimpleMovementComponent->AddMoveVariableSpeed(
			StartPos.X, StartPos.Y, StartPos.Z,
			TargetPosFromServer.X, TargetPosFromServer.Y, TargetPosFromServer.Z,
			BulletData.Velocity, BulletData.Acceleration, Duration);
	}
	else
	{
		UE_LOG(LogKGCombat, Error, TEXT("ABulletActor::LaunchBullet_Direction SimpleMovementComponent is null, %s"), *GetDebugInfo());
	}
}

void ABulletActor::LaunchBullet_Line()
{
	if (SimpleMovementComponent)
	{
		SimpleMovementComponent->AddMoveVariableSpeed(
			StartPos.X, StartPos.Y, StartPos.Z,
			TargetPosFromServer.X, TargetPosFromServer.Y, TargetPosFromServer.Z,
			BulletData.Velocity, BulletData.Acceleration, LifeTimeSeconds);
	}
	else
	{
		UE_LOG(LogKGCombat, Error, TEXT("ABulletActor::LaunchBullet_Line SimpleMovementComponent is null, %s"), *GetDebugInfo());
	}
}

void ABulletActor::LaunchBullet_Missile()
{
	if (SimpleMovementComponent)
	{
		const auto MoveTaskID = SimpleMovementComponent->AddMoveTrackTarget(
			TargetID, BulletData.Velocity, BulletData.Acceleration, BulletData.AngularVelocity, BulletData.MaxHomingAngle, LifeTimeSeconds);
		if (MoveTaskID == KG_SIMPLE_MOVEMENT_INVALID_GID)
		{
			UE_LOG(LogKGCombat, Log, TEXT("ABulletActor::LaunchBullet_Missile invalid move target, change to line move, %s"), *GetDebugInfo());
			LaunchBullet_Line();
		}
	}
	else
	{
		UE_LOG(LogKGCombat, Error, TEXT("ABulletActor::LaunchBullet_Missile SimpleMovementComponent is null, %s"), *GetDebugInfo());
	}
}

void ABulletActor::LaunchBullet_MissileNoMiss()
{
	if (SimpleMovementComponent)
	{
		const auto MoveTaskID = SimpleMovementComponent->AddMoveMustHitTarget(TargetID, LifeTimeSeconds, *BulletData.TargetPosAnchorBone);
		if (MoveTaskID == KG_SIMPLE_MOVEMENT_INVALID_GID)
		{
			UE_LOG(LogKGCombat, Log, TEXT("ABulletActor::LaunchBullet_MissileNoMiss invalid move target, change to line move, %s"), *GetDebugInfo());
			LaunchBullet_Line();
		}
		else
		{
			bHasTarget = true;
		}
	}
	else
	{
		UE_LOG(LogKGCombat, Error, TEXT("ABulletActor::LaunchBullet_MissileNoMiss SimpleMovementComponent is null, %s"), *GetDebugInfo());
	}
}

void ABulletActor::LaunchBullet_Parabola()
{
	if (FMath::IsNearlyZero(BulletData.Velocity) && FMath::IsNearlyZero(BulletData.MaxLifeTime))
	{
		UE_LOG(LogKGCombat, Error, TEXT("ABulletActor::LaunchBullet_Parabola bullet with zero velocity and zero MaxLifeTime, %s"), *GetDebugInfo());
		return;
	}

	if (!SimpleMovementComponent)
	{
		UE_LOG(LogKGCombat, Error, TEXT("ABulletActor::LaunchBullet_Parabola SimpleMovementComponent is null, %s"), *GetDebugInfo());
		return;
	}
	
	if (FMath::IsNearlyZero(BulletData.Velocity))
	{
		SimpleMovementComponent->AddMoveParabolaWithDuration(
			StartPos.X, StartPos.Y, StartPos.Z,
			TargetPosFromServer.X, TargetPosFromServer.Y, TargetPosFromServer.Z,
			BulletData.MaxLifeTime, BulletData.Acceleration);
	}

	if (FMath::IsNearlyZero(BulletData.MaxLifeTime))
	{
		SimpleMovementComponent->AddMoveParabolaWithHorizontalVelocity(
			StartPos.X, StartPos.Y, StartPos.Z,
			TargetPosFromServer.X, TargetPosFromServer.Y, TargetPosFromServer.Z,
			BulletData.Velocity, BulletData.Acceleration);
	}
}

void ABulletActor::LaunchBullet_ParabolaWithTrack()
{
	if (SimpleMovementComponent)
	{
		float MaxLifeTime = BulletData.MaxLifeTime;
		if (BulletData.Velocity > 0 && BulletData.Acceleration > 0)
		{
			UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(this);
			if (ActorManager)
			{
				float Dist = 0;
				if (auto* TargetEntity = ActorManager->GetLuaEntity(TargetID))
				{
					FVector TargetEntPos = TargetEntity->GetLocation();
					FVector SelfPos = GetActorLocation();
					MaxLifeTime =  (TargetEntPos - SelfPos).Size2D() / BulletData.Velocity;
				}
			}
		}
		if (MaxLifeTime <= 0)
		{
			UE_LOG(LogKGCombat, Log, TEXT("ABulletActor::LaunchBullet_ParabolaWithTrack invalid MaxLifeTime, %s"), *GetDebugInfo());
			return;
		}
		const auto MoveTaskID = SimpleMovementComponent->AddMoveParabolaWithTrack(
			TargetID, BulletData.TargetPointMoveSpeed, BulletData.TrackDuration, MaxLifeTime, BulletData.Acceleration);
		if (MoveTaskID == KG_SIMPLE_MOVEMENT_INVALID_GID)
		{
			UE_LOG(LogKGCombat, Log, TEXT("ABulletActor::LaunchBullet_ParabolaWithTrack invalid move target, change to line move, %s"), *GetDebugInfo());
			LaunchBullet_Line();
		}
	}
	else
	{
		UE_LOG(LogKGCombat, Error, TEXT("ABulletActor::LaunchBullet_ParabolaWithTrack SimpleMovementComponent is null, %s"), *GetDebugInfo());
	}
}

void ABulletActor::LaunchBullet_Round()
{
	if (SimpleMovementComponent)
	{
		SimpleMovementComponent->AddMoveRound(
			BulletData.RoundStartCoordinates.X, BulletData.RoundStartCoordinates.Y, BulletData.RoundStartCoordinates.Z,
			BulletData.RoundCenterCoordinates.X, BulletData.RoundCenterCoordinates.Y, BulletData.RoundCenterCoordinates.Z,
			BulletData.MaxLifeTime, BulletData.AngularVelocity);
	}
	else
	{
		UE_LOG(LogKGCombat, Error, TEXT("ABulletActor::LaunchBullet_ParabolaWithTrack SimpleMovementComponent is null, %s"), *GetDebugInfo());
	}
}

void ABulletActor::StartPerfectDodgeCheck()
{
	if (!BulletData.bCheckPrefectDodge)
	{
		return;
	}

	if (BulletData.PerfectDodgeSkillID == 0)
	{
		UE_LOG(LogKGCombat, Error, TEXT("ABulletActor::StartPerfectDodgeCheck PerfectDodgeSkillID is zero, %s"), *GetDebugInfo());
		return;
	}

	UKGCombatUnitManager* CombatUnitManager = UKGCombatUnitManager::GetInstance(this);
	if (!CombatUnitManager)
	{
		UE_LOG(LogKGCombat, Error, TEXT("ABulletActor::StartPerfectDodgeCheck CombatUnitManager is null, %s"), *GetDebugInfo());
		return;
	}
	
	AttackCollisionComponent = NewObject<UAttackCollisionComponent>(this);
	if (!AttackCollisionComponent)
	{
		UE_LOG(LogKGCombat, Error, TEXT("ABulletActor::StartPerfectDodgeCheck Create AttackCollisionComponent failed, %s"), *GetDebugInfo());
		return;
	}
	
	AttackCollisionComponent->RegisterComponent();

	FKGPhysicsQueryCollisionInfo CollisionInfo;
	CollisionInfo.ShapeType = EKGPhysicsQueryShapeType::Sphere;
	FKGPhysicsQueryCollisionSphereShapeParams SphereParams;
	SphereParams.Radius = BulletData.CollisionRadius;
	CollisionInfo.ShapeParams.SetSubtype<FKGPhysicsQueryCollisionSphereShapeParams>(SphereParams);
	CollisionInfo.AttachComponent = RootComponent;
	CollisionInfo.ObjectTypesToQuery = CombatUnitManager->GetBulletPerfectDodgeObjectTypesToQuery();
	CollisionInfo.bTriggerPerfectDodge = true;
	CollisionInfo.SourceAbilityID = BulletData.ID;
	CollisionInfo.AttackSkillID = BulletData.PerfectDodgeSkillID;
	CollisionInfo.SourceType = EKGClientAttackSourceType::Bullet;
	CollisionInfo.UnitInstID = InstID;
			
	AttackCollisionComponent->AddPhysicsQueryCollision(CollisionInfo);
}

FString ABulletActor::GetDebugInfo() const
{
	return FString::Printf(TEXT("BulletID: %d, LauncherID: %lld, InstigatorID: %lld"), BulletData.ID, LauncherID, InstigatorID);
}	
