#include "3C/Character/BSAGhostActor.h"
#include "Engine/SkeletalMesh.h"
#include "3C/Material/KGMaterialManager.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "3C/Util/KGUtils.h"


#pragma region Important
ABSAGhostActor::ABSAGhostActor(const FObjectInitializer& ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = false;
	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
}

ABSAGhostActor::~ABSAGhostActor()
{
}

void ABSAGhostActor::BeginPlay()
{
	Super::BeginPlay();
}

#pragma endregion Important


void ABSAGhostActor::ClearRecord()
{
	GhostCompToSpawnerComp.Empty();
	SceneCompList.Empty();
	SkeletalMeshList.Empty();
	PoseableMeshList.Empty();
	StaticMeshList.Empty();
}

USceneComponent* ABSAGhostActor::GetSceneComponent()
{
	USceneComponent* Result = NewObject<USceneComponent>(this);
	if (IsValid(Result))
	{
		Result->RegisterComponent();
		Result->SetVisibility(true);
		Result->SetHiddenInGame(false);
		AddInstanceComponent(Result);
		SceneCompList.Add(Result);
	}

	return Result;
}

USkeletalMeshComponent* ABSAGhostActor::GetSkeletalMeshComp()
{
	USkeletalMeshComponent* Result = NewObject<USkeletalMeshComponent>(this);
	if (IsValid(Result))
	{
		Result->RegisterComponent();
		Result->SetVisibility(true);
		Result->SetHiddenInGame(false);
		AddInstanceComponent(Result);
		SkeletalMeshList.Add(Result);
	}
	return Result;
}

USkeletalMeshComponent* ABSAGhostActor::GetMainMesh()
{
	return GetComponentByClass<USkeletalMeshComponent>();	
}

UPoseableMeshComponent* ABSAGhostActor::GetPoseableMeshComp()
{
	UPoseableMeshComponent* Result = NewObject<UPoseableMeshComponent>(this);
	if (IsValid(Result))
	{
		Result->RegisterComponent();
		Result->SetVisibility(true);
		Result->SetHiddenInGame(false);
		AddInstanceComponent(Result);
		PoseableMeshList.Add(Result);
	}
	return Result;
}

UStaticMeshComponent* ABSAGhostActor::GetStaticMeshComp()
{
	UStaticMeshComponent* Result = NewObject<UStaticMeshComponent>(this);
	if (IsValid(Result))
	{
		Result->RegisterComponent();
		Result->SetVisibility(true);
		Result->SetHiddenInGame(false);
		AddInstanceComponent(Result);
		StaticMeshList.Add(Result);
	}
	return Result;
}

void ABSAGhostActor::PlayPosFromAnimation(KGObjectID CreatorID, bool bInLODSameAsCreator, KGObjectID AnimAssetID, bool bLoop, bool CopyMaterialParams)
{
	CopyPoseFromCreator(CreatorID, bInLODSameAsCreator, true, CopyMaterialParams);
	if (UAnimationAsset* AnimAsset = Cast<UAnimationAsset>(KGUtils::GetObjectByID(AnimAssetID)))
	{
		AActor* CreatorActor = KGUtils::GetActorByID(CreatorID);

		if (IC7ActorInterface* IC7Actor = Cast<IC7ActorInterface>(CreatorActor))
		{
			USceneComponent* MainMeshComp = IC7Actor->GetMainMesh();
			if (USkeletalMeshComponent* GhostMainMesh = Cast<USkeletalMeshComponent>(SpawnerCompToGhostComp.FindRef(MainMeshComp)))
			{
				GhostMainMesh->PlayAnimation(AnimAsset, bLoop);
			}
		}
		
		/*for (TArray<USkeletalMeshComponent*>::TIterator It(SkeletalMeshList); It; ++It)
		{
			(*It)->PlayAnimation(AnimAsset, bLoop);
		}*/
	}
}

void ABSAGhostActor::CopyPoseFromCreator(KGObjectID CreatorID, bool bInLODSameAsCreator, bool bInUseSkeletalMesh, bool bInCopyMaterialParams)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("ABSAGhostActor_CopyPoseFromCreator");
	AActor* Creator = KGUtils::GetActorByID(CreatorID);
	if (!Creator)
	{
		return;
	}
	bUseSkeletalMesh = bInUseSkeletalMesh;
	bLODSameAsCreator = bInLODSameAsCreator;
	bCopyMaterialParams = bInCopyMaterialParams;

	GhostCompToSpawnerComp.Add(RootComponent, Creator->GetRootComponent());
	SpawnerCompToGhostComp.Add(Creator->GetRootComponent(), RootComponent);
	CreateGhostMesh(Creator);
	//SetTickUpdatePos(true);
}

void ABSAGhostActor::CreateGhostMesh(AActor* InSourceActor)
{
	TArray<UMeshComponent*> MeshComps;
	InSourceActor->GetComponents<UMeshComponent>(MeshComps);

	for (int32 i = 0; i < MeshComps.Num(); ++i)
	{
		if (!MeshComps[i])
			continue;
		//UE_LOG(LogTemp, Warning, TEXT("zzp meshcomp name %s "), *MeshComps[i]->GetName());
		CreateSceneComponent(MeshComps[i]);
	}

	// 递归处理子对象
	for (int32 i = 0; i < InSourceActor->Children.Num(); ++i)
	{
		AActor* Child = InSourceActor->Children[i].Get();
		if (IsValid(Child))
		{
			CreateGhostMesh(Child);
		}
	}
}

void ABSAGhostActor::CreateSceneComponent(USceneComponent* InSourceComponent)
{
	if (!IsValid(InSourceComponent))
	{
		return;
	}

	// 创建组件
	USceneComponent* NewComponent = nullptr;
	if (USkeletalMeshComponent* SKComp = Cast<USkeletalMeshComponent>(InSourceComponent))
	{
		if (bUseSkeletalMesh)
		{
			if (USkeletalMeshComponent* SkeletalComp = GetSkeletalMeshComp())
			{
				NewComponent = SkeletalComp;
				SkeletalComp->SetSkinnedAssetAndUpdate(SKComp->GetSkeletalMeshAsset());
				SkeletalComp->SetCollisionEnabled(ECollisionEnabled::Type::NoCollision);
				SkeletalComp->SetAnimationMode(EAnimationMode::Type::AnimationSingleNode);

				int32 LOD = (bLODSameAsCreator ? SKComp->GetPredictedLODLevel() : SKComp->GetNumLODs()) + 1;
				SkeletalComp->SetForcedLOD(LOD);

				SkeletalComp->SetRenderCustomDepth(false);
				SkeletalComp->SetRenderInMainPass(true);
				SkeletalComp->SetCustomDepthStencilWriteMask(ERendererStencilMask::ERSM_Default);
				SkeletalComp->SetCustomDepthStencilValue(0);
				
				if (bCopyMaterialParams)
				{
					CopyMaterialParams(SKComp, SkeletalComp);
				}
			}
		}
		else
		{
			if (UPoseableMeshComponent* PoseComp = GetPoseableMeshComp())
			{
				NewComponent = PoseComp;
				PoseComp->SetSkinnedAssetAndUpdate(SKComp->GetSkeletalMeshAsset());
				PoseComp->SetCollisionEnabled(ECollisionEnabled::Type::NoCollision);

				int32 LOD = (bLODSameAsCreator ? SKComp->GetPredictedLODLevel() : SKComp->GetNumLODs()) + 1;
				PoseComp->SetForcedLOD(LOD);

				PoseComp->SetRenderCustomDepth(false);
				PoseComp->SetRenderInMainPass(true);
				PoseComp->SetCustomDepthStencilWriteMask(ERendererStencilMask::ERSM_Default);
				PoseComp->SetCustomDepthStencilValue(0);

				if (!SKComp->LeaderPoseComponent.IsValid())
				{
					PoseComp->CopyPoseFromSkeletalComponent(SKComp);
					PoseComp->RefreshBoneTransforms();
				}
				
				if (bCopyMaterialParams)
				{
					CopyMaterialParams(SKComp, PoseComp);
				}
			}
		}
	}
	else if (UStaticMeshComponent* STComp = Cast<UStaticMeshComponent>(InSourceComponent))
	{
		if (UStaticMeshComponent* NSTComp = GetStaticMeshComp())
		{
			NewComponent = NSTComp;
			NSTComp->SetStaticMesh(STComp->GetStaticMesh());
			NSTComp->SetCollisionEnabled(ECollisionEnabled::Type::NoCollision);

			int32 LOD = (bLODSameAsCreator ? NSTComp->ForcedLodModel : NSTComp->LODData.Num()) + 1;
			NSTComp->SetForcedLodModel(LOD); 

			NSTComp->SetRenderCustomDepth(false);
			NSTComp->SetRenderInMainPass(true);
			NSTComp->SetCustomDepthStencilWriteMask(ERendererStencilMask::ERSM_Default);
			NSTComp->SetCustomDepthStencilValue(0);
			
			if (bCopyMaterialParams)
			{
				CopyMaterialParams(STComp, NSTComp);
			}
		}
	}
	else
	{
		if (USceneComponent* NSComp = GetSceneComponent())
		{
			NewComponent = NSComp;
		}
	}
	if (!NewComponent)
	{
		return;
	}

	// 记录映射关系，方便后续快速查找
	GhostCompToSpawnerComp.Add(NewComponent, InSourceComponent);
	SpawnerCompToGhostComp.Add(InSourceComponent, NewComponent);

	// 找到 或 创建挂接父类
	USceneComponent* CurrentParent = InSourceComponent->GetAttachParent();
	if (USceneComponent** FindResult1 = SpawnerCompToGhostComp.Find(CurrentParent))
	{
		CurrentParent = *FindResult1;
	}
	else
	{
		CreateSceneComponent(CurrentParent);
		if (USceneComponent** FindResult2 = SpawnerCompToGhostComp.Find(CurrentParent))
		{
			CurrentParent = *FindResult2;
		}
		else
		{
			CurrentParent = nullptr;
		}
	}
	if (!CurrentParent)
	{
		return;
	}

	// 进行挂接
	if (NewComponent != CurrentParent)
	{
		NewComponent->AttachToComponent(CurrentParent, FAttachmentTransformRules::KeepRelativeTransform, InSourceComponent->GetAttachSocketName());
		NewComponent->SetRelativeTransform(InSourceComponent->GetRelativeTransform());
	}

	// 设置姿势领导
	USkinnedMeshComponent* CurrentLeader = nullptr;
	if (USkinnedMeshComponent* OriginMesh = Cast<USkinnedMeshComponent>(InSourceComponent))
	{
		if (USceneComponent** FindResult = SpawnerCompToGhostComp.Find(OriginMesh->LeaderPoseComponent.Get()))
		{
			CurrentLeader = Cast<USkinnedMeshComponent>(*FindResult);
		}
	}
	if (CurrentLeader)
	{
		if (USkinnedMeshComponent* NewSkinnedMesh = Cast<USkinnedMeshComponent>(NewComponent))
		{
			NewSkinnedMesh->SetLeaderPoseComponent(CurrentLeader);
		}
	}

	// 设置渲染信息
	UMeshComponent* SourceMesh = Cast<UMeshComponent>(InSourceComponent);
	UMeshComponent* NewMesh = Cast<UMeshComponent>(NewComponent);
	if (SourceMesh && NewMesh)
	{
		// 是否要隐藏该组件
		if (InSourceComponent->ComponentHasTag("HiddenInGhost") || (!InSourceComponent->IsVisible()))
		{
#if WITH_EDITOR
			NewMesh->SetVisibility(false);
#endif
			NewMesh->SetHiddenInGame(true);
		}
	}
}

void ABSAGhostActor::CopyMaterialParams(UMeshComponent* SourceComponent, UMeshComponent* TargetComponent)
{
	if (!IsValid(SourceComponent) || !IsValid(TargetComponent))
	{
		UE_LOG(LogTemp, Error, TEXT("ABSAGhostActor::CopyMaterialParams, invalid source or target component"));
		return;
	}
	
	const auto SourceMaterialSlotNum = SourceComponent->GetNumMaterials();
	const auto TargetMaterialSlotNum = TargetComponent->GetNumMaterials();
	if (SourceMaterialSlotNum != TargetMaterialSlotNum || SourceMaterialSlotNum == 0)
	{
		UE_LOG(LogTemp, Warning, TEXT("ABSAGhostActor::CopyMaterialParams, source or target component material slot num not equal"));
		return;
	}
	
	UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(this);
	if (!MaterialManager)
	{
		UE_LOG(LogTemp, Error, TEXT("ABSAGhostActor::CopyMaterialParams, invalid material manager"));
		return;
	}
	
	for (int32 i = 0; i < SourceMaterialSlotNum; i++)
	{
		// 如果source上是MI, 则无需拷贝材质参数
		UMaterialInstanceDynamic* SourceMID = Cast<UMaterialInstanceDynamic>(SourceComponent->GetMaterial(i));
		if (SourceMID == nullptr)
		{
			continue;
		}
		
		UMaterialInterface* SourceMI = SourceMID->Parent;
		if (!SourceMI)
		{
			continue;
		}
		
		// 有组装参数仅拷贝组装参数
		const auto MaterialCacheKey = KGMaterialUtils::GetMaterialCacheKey(i, false, false, false);
		if (auto* GetRoleCompositeParamCachePtr = MaterialManager->GetRoleCompositeParamCachePtr(SourceComponent, MaterialCacheKey))
		{
			UMaterialInstanceDynamic* TargetMID = Cast<UMaterialInstanceDynamic>(TargetComponent->GetMaterial(i));
			if (TargetMID == nullptr)
			{
				TargetMID = UMaterialInstanceDynamic::Create(SourceMI, nullptr);
			}
			
			if (TargetMID == nullptr)
			{
				continue;
			}
			
			for (const auto& Kvp : GetRoleCompositeParamCachePtr->ScalarParams)
			{
				TargetMID->SetScalarParameterValue(Kvp.Key, Kvp.Value);
			}
			
			for (const auto& Kvp : GetRoleCompositeParamCachePtr->VectorParams)
			{
				TargetMID->SetVectorParameterValue(Kvp.Key, Kvp.Value);
			}
			
			for (const auto& Kvp : GetRoleCompositeParamCachePtr->TextureParams)
			{
				TargetMID->SetTextureParameterValue(Kvp.Key, Kvp.Value.Get());
			}
			
			TargetComponent->SetMaterial(i, TargetMID);
		}
	}
}
