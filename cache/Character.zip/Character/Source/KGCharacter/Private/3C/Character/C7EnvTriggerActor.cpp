#include "3C/Character/C7EnvTriggerActor.h"

#include "Scene/Components/C7ShapeCollisionComponent.h"

AC7EnvTriggerActor::AC7EnvTriggerActor()
{
	ShapeCollision = CreateDefaultSubobject<UC7ShapeCollisionComponent>(TEXT("ShapeCollisionComponent0"));
	ShapeCollision->SetupAttachment(RootComponent);
	ULowLevelFunctions::EnableOverlapOptimization(ShapeCollision, true);

	static FName CollisionProfileName(TEXT("InteractablePreset"));
	ShapeCollision->SetCollisionProfileName(CollisionProfileName);
	ShapeCollision->SetMobility(EComponentMobility::Static);
}

void AC7EnvTriggerActor::BeginPlay()
{
	Super::BeginPlay();

	if(ShapeCollision != nullptr)
	{
		ShapeCollision->InitAsInteractable(0, false);
	}
}

void AC7EnvTriggerActor::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if(ShapeCollision != nullptr)
	{
		ShapeCollision->EnableInterActiveForDetect(false);
	}

	Super::EndPlay(EndPlayReason);
}
