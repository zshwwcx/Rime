#include "3C/Character/BaseCharacter.h"

#include "AkComponent.h"
#include "3C/Animation/BaseAnimInstance.h"
#include "CableComponent.h"
#include "Manager/KGCppAssetManager.h"
#include "Manager/KGPlatformScalabilitySettings.h"
#include "3C/Animation/AnimNotify/AnimNotifyState_C7AnimNotifyOnSurface.h"
#include "3C/Core/AttachJointComponent_V2.h"
#include "Kismet/KismetSystemLibrary.h"
#include "3C/Controller/BasePlayerController.h"

#include "Components/SkeletalMeshComponent.h"
#include "Components/CapsuleComponent.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "Misc/KGGameInstanceBase.h"
#include "Engine/World.h"

#include "NavigationData.h"
#include "AI/Navigation/NavigationTypes.h"
#include "NavigationSystemTypes.h"

#include "NavigationSystem.h"
#include "NavFilters/NavigationQueryFilter.h"
#include "NavMesh/NavMeshPath.h"
#include "3C/Movement/PathFollow/C7PathFollowComponent.h"

#include "Manager/KGObjectActorManager.h"
#include "3C/Core/KGUEActorManager.h"
#include "3C/Util/KGUtils.h"
#include "SkeletalMeshComponentBudgeted.h"
#include "Managers/KGDataCacheManager.h"
#include "3C/Material/KGMaterialManager.h"
#include "BlobShadowComponent.h"

const FName NAME_Pelvis(TEXT("Pelvis"));
const FName NAME_pelvis(TEXT("pelvis"));
const FName NAME_root(TEXT("root"));
const FName NAME_RagdollPose(TEXT("RagdollPose"));

#if UE_BUILD_DEVELOPMENT
TMap<TWeakObjectPtr<AActor>, FActorDebugSwitchConfig> ABaseCharacter::ActorDebugConfigMap{};
ISceneDrawerInterface* ABaseCharacter::SceneDrawerTool = nullptr;
#endif //  UE_BUILD_DEVELOPMENT

ABaseCharacter::ABaseCharacter(const FObjectInitializer& ObjectInitializer) : 
	Super(
		(ObjectInitializer.SetDefaultSubobjectClass<URoleMovementComponent>(ACharacter::CharacterMovementComponentName)
		,ObjectInitializer.SetDefaultSubobjectClass<USkeletalMeshComponentBudgeted>(ACharacter::MeshComponentName)
		)
		)
{
	PrimaryActorTick.bCanEverTick = true;
	PathFollowingComponent = CreateOptionalDefaultSubobject<UC7PathFollowComponent>(TEXT("PathFollowingComponent"));
	PathFollowingComponent->OnRequestFinished.AddUObject(this, &ABaseCharacter::OnPathFollowCompleted);
}

void ABaseCharacter::BeginPlay()
{
	Super::BeginPlay();

	if (!IsValid(PathFollowingComponent))
	{
		ensureAlways(false);
		return;
	}
	PathFollowingComponent->UpdateCachedComponents();
	if (URoleMovementComponent* RoleMoveComp = Cast<URoleMovementComponent>(GetCharacterMovement()))
	{
		RoleMoveComp->AddTickPrerequisiteComponent(PathFollowingComponent);
	}
	PathFollowingComponent->SetPreciseReachThreshold(1.1f, 2.0f);
	PathFollowingComponent->SetComponentTickEnabled(false);

	if(!CVarEnableClothPhysics)
	{
		CVarEnableClothPhysics = IConsoleManager::Get().FindConsoleVariable(TEXT("p.ClothPhysics"));
	}

	BlobShadowComponent = Cast<UBlobShadowComponent>(GetComponentByClass(UBlobShadowComponent::StaticClass()));
	if(IsValid(BlobShadowComponent))
	{
		BlobShadowComponent->SetHiddenInGame(true);
	}
}

void ABaseCharacter::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
	ClearGhostCloneCache();
}

void ABaseCharacter::Tick( float DeltaSeconds )
{
	Super::Tick(DeltaSeconds);
	TickBlobShadow(DeltaSeconds);
	if (bIsRagDoll)
	{
		RagdollUpdate(DeltaSeconds);
	}
}

void ABaseCharacter::ResetToDefaultsForCache()
{
	EnableBlobShadow(false);
	SetInScreen(true);
	StopPathFollow();
	EnableAnimTickOptimization(false);
}

void ABaseCharacter::AddMovementInput(FVector WorldDirection, float ScaleValue, bool bForce)
{
	URoleMovementComponent* MovementComponent = Cast<URoleMovementComponent>(GetMovementComponent());
	MovementComponent = MovementComponent->GetRealMovementControlViewProxy();
	if (MovementComponent)
	{
		MovementComponent->AddInputVector(WorldDirection * ScaleValue, bForce);
	}
	else
	{
		Internal_AddMovementInput(WorldDirection * ScaleValue, bForce);
	}
}
#pragma region Ragdoll
void ABaseCharacter::RagdollStart(FVector ImpactImpulse)
{
	bIsRagDoll = true; 
	GetCharacterMovement()->bIgnoreClientMovementErrorChecksAndCorrection = 1;
	TargetRagdollLocation = GetMesh()->GetSocketLocation(NAME_pelvis);
	bPreRagdollURO = GetMesh()->bEnableUpdateRateOptimizations;
	GetMesh()->bEnableUpdateRateOptimizations = false;
	GetMesh()->SetAllBodiesBelowSimulatePhysics(NAME_pelvis, true, true);
	
	if (!ImpactImpulse.IsZero())
	{
		GetMesh()->AddImpulse(ImpactImpulse, NAME_pelvis, true);
	}
	
	UBaseAnimInstance* AnimInst = Cast<UBaseAnimInstance>(GetMesh()->GetAnimInstance());
	if (AnimInst)
	{
		AnimInst->bIsRagDoll = true;
		AnimInst->Montage_Stop(0.2f);
	}
	GetMesh()->bOnlyAllowAutonomousTickPose = true;
}

void ABaseCharacter::RagdollEnd()
{
	// 先留着?  目前不需要起身，后续如果需要起身 调用一下方法，并在蓝图里配置一下起身动画GetGetUpAnimation
	GetMesh()->bEnableUpdateRateOptimizations = bPreRagdollURO;
	bIsRagDoll = false;
	GetCharacterMovement()->bIgnoreClientMovementErrorChecksAndCorrection = 0;
	GetMesh()->bOnlyAllowAutonomousTickPose = false;
	if (UBaseAnimInstance* AnimInst = Cast<UBaseAnimInstance>(GetMesh()->GetAnimInstance()))
	{
		AnimInst->bIsRagDoll = false;
		AnimInst->SavePoseSnapshot(NAME_RagdollPose);
	}
	if (bRagdollOnGround && GetMesh()->GetAnimInstance())
	{
		GetMesh()->GetAnimInstance()->Montage_Play(GetGetUpAnimation(bRagdollFaceUp), 1.0f, EMontagePlayReturnType::MontageLength, 0.0f, true);
	}
	GetMesh()->SetAllBodiesSimulatePhysics(false);
}

void ABaseCharacter::RagdollUpdate(float DeltaTime)
{
 	GetMesh()->bOnlyAllowAutonomousTickPose = false;

	const FVector NewRagdollVel = GetMesh()->GetPhysicsLinearVelocity(NAME_root);
	LastRagdollVelocity = (NewRagdollVel != FVector::ZeroVector) ? NewRagdollVel : LastRagdollVelocity / 2;

	const float SpringValue = FMath::GetMappedRangeValueClamped<float, float>({0.0f, 1000.0f}, {0.0f, 25000.0f},
	                                                            LastRagdollVelocity.Size());
	GetMesh()->SetAllMotorsAngularDriveParams(SpringValue, 0.0f, 0.0f, false);

	SetActorLocationDuringRagdoll(DeltaTime);
}

void ABaseCharacter::SetActorLocationDuringRagdoll(float DeltaTime)
{
	TargetRagdollLocation = GetMesh()->GetSocketLocation(NAME_pelvis);

	// Determine whether the ragdoll is facing up or down and set the target rotation accordingly.
	const FRotator PelvisRot = GetMesh()->GetSocketRotation(NAME_pelvis);

	bRagdollFaceUp = PelvisRot.Roll < 0.0f;

	const FRotator TargetRagdollRotation(0.0f, bRagdollFaceUp ? PelvisRot.Yaw - 180.0f : PelvisRot.Yaw, 0.0f);

	// Trace downward from the target location to offset the target location,
	// preventing the lower half of the capsule from going through the floor when the ragdoll is laying on the ground.
	const FVector TraceVect(TargetRagdollLocation.X, TargetRagdollLocation.Y,
							TargetRagdollLocation.Z - GetCapsuleComponent()->GetScaledCapsuleHalfHeight());

	UWorld* World = GetWorld();
	check(World);

	FCollisionQueryParams Params;
	Params.AddIgnoredActor(this);

	FHitResult HitResult;
	const bool bHit = World->LineTraceSingleByChannel(HitResult, TargetRagdollLocation, TraceVect,ECC_Visibility, Params);
	bRagdollOnGround = HitResult.IsValidBlockingHit();
	FVector NewRagdollLoc = TargetRagdollLocation;

	if (bRagdollOnGround)
	{
		const float ImpactDistZ = FMath::Abs(HitResult.ImpactPoint.Z - HitResult.TraceStart.Z);
		NewRagdollLoc.Z += GetCapsuleComponent()->GetScaledCapsuleHalfHeight() - ImpactDistZ + 2.0f;
	}
	
	SetActorLocationAndRotation(bRagdollOnGround ? NewRagdollLoc : TargetRagdollLocation, TargetRagdollRotation);
}
#pragma endregion	

void ABaseCharacter::MoveBlockedBy(const FHitResult& Impact)
{
	OnMoveBlockedBy(Impact);
}

bool ABaseCharacter::ProcessConsoleExec(const TCHAR* Cmd, FOutputDevice& Ar, UObject* Executor)
{
	if (FParse::Command(&Cmd, TEXT("RoleDebug")))
	{
		FString StrCmd(Cmd);
		OnProcessConsoleExec(StrCmd);
		return true;
	}

	return Super::ProcessConsoleExec(Cmd, Ar, Executor);
}

void ABaseCharacter::PostInitializeComponents()
{
	Super::PostInitializeComponents();
	OnPostInitializeComponents();
}

void ABaseCharacter::SetActorHiddenInGame(bool bNewHidden)
{
	Super::SetActorHiddenInGame(bNewHidden);

	if (bHiddenWithChildActor)
	{
		TMap<int64, int32>* childMapPtr = GetLogicChildMaskMap();
		UKGObjectActorManager* UOAM = UKGObjectActorManager::GetInstance(this);
		
		if (UOAM && childMapPtr)
		{
			for (auto pair : *childMapPtr)
			{
				if (AActor* Actor = Cast<AActor>( UOAM->GetObjectByID(pair.Key)))
				{
					Actor->SetActorHiddenInGame(bNewHidden);
				}
			}	
		}

		// 隐藏特效
		if (UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(this))
		{
			const auto TempActorID = KGUtils::GetIDByObject(this);
			EffectManager->UpdateEffectVisibilityBySpawnerID(TempActorID, !bNewHidden, static_cast<uint8>(EKGNiagaraHiddenReason::OWNER_SET_HIDDEN));
		}
	}
}

void ABaseCharacter::FaceRotation(FRotator NewControlRotation, float DeltaTime)
{
	if (URoleMovementComponent* MoveComp = FindComponentByClass<URoleMovementComponent>())
	{
		if (!MoveComp->AllowProactiveRotation())
		{
			return;
		}
	}
	
	// Only if we actually are going to use any component of rotation.
	if (bUseControllerRotationPitch || bUseControllerRotationYaw || bUseControllerRotationRoll)
	{
		const FRotator CurrentRotation = GetActorRotation();

		if (!bUseControllerRotationPitch)
		{
			NewControlRotation.Pitch = CurrentRotation.Pitch;
		}

		if (!bUseControllerRotationYaw)
		{
			NewControlRotation.Yaw = CurrentRotation.Yaw;
		}

		if (!bUseControllerRotationRoll)
		{
			NewControlRotation.Roll = CurrentRotation.Roll;
		}

		if (bCustomLockPitch)
		{
			NewControlRotation.Pitch = 0.0;
		}

		if (bCustomLockYaw)
		{
			NewControlRotation.Yaw = 0.0;
		}

		if (bCustomLockRoll)
		{
			NewControlRotation.Roll = 0.0;
		}

#if ENABLE_NAN_DIAGNOSTIC
		if (NewControlRotation.ContainsNaN())
		{
			logOrEnsureNanError(TEXT("APawn::FaceRotation about to apply NaN-containing rotation to actor! New:(%s), Current:(%s)"), *NewControlRotation.ToString(), *CurrentRotation.ToString());
		}
#endif
		
		SetActorRotation(NewControlRotation);
	}
	//Super::FaceRotation(NewControlRotation, DeltaTime);
}

UActorComponent* ABaseCharacter::RegisterComponentByClass(const TSubclassOf<UActorComponent> ComponentClass, FName Tag)
{
	if (!UKismetSystemLibrary::IsValidClass(ComponentClass))
		return nullptr;

	UActorComponent* NewComponent = NewObject<UActorComponent>(this, ComponentClass, Tag);
	if(!NewComponent)
		return nullptr;

	NewComponent->RegisterComponent();

	return NewComponent;
}

void ABaseCharacter::UpdateInvalidateCachedBounds()
{
	if (GetMesh())
	{
		GetMesh()->InvalidateCachedBounds();
		GetMesh()->UpdateBounds();
	}
}

void ABaseCharacter::SetEntityUID(int64 InEntityID)
{
	EntityUID = InEntityID;
}

bool ABaseCharacter::GetVirtualSocketLocation(const int64& SocketID, FVector& OutLocation)
{
	if (UAttachJointComponent_V2* AttachJointComponent = Cast<UAttachJointComponent_V2>(GetComponentByClass(UAttachJointComponent_V2::StaticClass())))
	{
		return AttachJointComponent->GetVirtualSocketLocation(SocketID, OutLocation);
	}
	return false;
}

#pragma region Common

bool ABaseCharacter::IsLocallyControlled() const
{
	if (Controller && Controller->IsLocalController() && Controller->IsA<APlayerController>())
	{
		return true;
	}

	if (bIsLocalAIPawn)
	{
		return true;
	}

	return false;
}

int32 ABaseCharacter::GetActorType() const
{ 
	return ActorType; 
}

void ABaseCharacter::ChangeModelColor(const FString& ModelName, const FString& ColorName)
{
	UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(this);
	if (!MaterialManager)
	{
		UE_LOG(LogTemp, Error, TEXT("ABaseCharacter::ChangeModelColor, MaterialManager is null, Actor:%s"), *GetName());
		return;
	}

	if (CurModelColorReqIDs.Num() > 0)
	{
		for (uint32 ReqID : CurModelColorReqIDs)
		{
			MaterialManager->RevertMaterial(ReqID);
		}
	}
	
	CurModelColorReqIDs = MaterialManager->ChangeModelColor(this, ModelName, ColorName);
}

void ABaseCharacter::RevertModelColor()
{
	if (CurModelColorReqIDs.Num() == 0)
	{
		return;
	}
	
	UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(this);
	if (!MaterialManager)
	{
		UE_LOG(LogTemp, Error, TEXT("ABaseCharacter::RevertModelColor, MaterialManager is null, Actor:%s"), *GetName());
		return;
	}

	for (uint32 ReqID : CurModelColorReqIDs)
	{
		MaterialManager->RevertMaterial(ReqID);
	}
	CurModelColorReqIDs.Empty();
}

void ABaseCharacter::SetActorLOD(int32 NewLOD)
{
	OnLODChanged(ActorLOD, NewLOD);
}

int32 ABaseCharacter::GetActorLOD() const
{
	return ActorLOD;
}

void ABaseCharacter::SetMainMeshForceLod(int32 lod)
{
	USkeletalMeshComponent* MeshComponent = GetMainMesh();
	if (MeshComponent)
	{
		MeshComponent->SetForcedLOD(lod);
	}
}

//////////////////////////////////////////////////////////////////////////
/// 1.动画Layer的延迟Link。能不能Link由LOD决定
/// 2.低LOD的情况可以关闭动画层，提高动画效率 DisableAnimFeatureLayer
/// 3.比较费性能的Kawaii和 Cloth 加一个上限控制，一旦拿到预算跟随整个生命周期
/// 4.Cable绳索的Tick控制
//////////////////////////////////////////////////////////////////////////
void ABaseCharacter::OnLODChanged(int oldValue, int NewValue)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("ABaseCharacter::OnLODChanged");
	
	ActorLOD = NewValue;
	
	UKGPlatformScalabilitySettings* PlatformScalabilitySettings = UKGPlatformScalabilitySettings::GetInstance(this);
	if (!PlatformScalabilitySettings)
	{
		return;
	}

	int CurrentActorLOD = ActorLOD;
	if(!EnableLOD)
	{
		CurrentActorLOD = 0;
	}

	const float RopePhysicSimulateTickInterval = PlatformScalabilitySettings->GetScalabilityLodValue<float>(CurrentActorLOD,"RopePhysicSimulate", "TickIntervalLODValue");
	const bool RopePhysicSimulateEnable =  PlatformScalabilitySettings->GetScalabilityLodValue<bool>(CurrentActorLOD,"RopePhysicSimulate", "EnableLODValue");

	auto Components = this->K2_GetComponentsByClass(UCableComponent::StaticClass());
	for (int32 i = 0; i < Components.Num(); ++i)
	{
		Components[i]->SetComponentTickEnabled(RopePhysicSimulateEnable);
		Components[i]->SetComponentTickInterval(RopePhysicSimulateTickInterval);
	}

	// AkComponentTick
	const bool AkComponentTickEnable = PlatformScalabilitySettings->GetScalabilityLodValue<bool>(CurrentActorLOD, "AkComponent", "EnableLODValue");
	const float AkComponentTickInterval = PlatformScalabilitySettings->GetScalabilityLodValue<float>(CurrentActorLOD, "AkComponent", "TickIntervalLODValue");
	
	auto AkComponents = K2_GetComponentsByClass(UAkComponent::StaticClass());
	for (auto& AkComponent : AkComponents)
	{
		AkComponent->SetComponentTickEnabled(AkComponentTickEnable);
		AkComponent->SetComponentTickInterval(AkComponentTickInterval);
	}

	if(URoleMovementComponent *RoleMovementCom = GetComponentByClass<URoleMovementComponent>())
	{
		RoleMovementCom->SetMovementLOD(
			CurrentActorLOD,
			PlatformScalabilitySettings->GetScalabilityLodValue<float>(CurrentActorLOD,"Movement", "SimulateDeltaThresholdByLod")
			);
	}

	if (UAttachJointComponent_V2* VirtualJointComponent = GetComponentByClass<UAttachJointComponent_V2>())
	{
		const bool EnableCollisionControl = PlatformScalabilitySettings->GetScalabilityLodValue<bool>(CurrentActorLOD,"AttachItemLOD", "VirtualAttach");
		VirtualJointComponent->UpdateIsLodEnableCollision(EnableCollisionControl);
	}

	if (IsCrowdNpc())
	{
		bool bEnableMassPhysicsOpz = PlatformScalabilitySettings->GetScalabilityValue<bool>("MassNPC", "EnablePhysicsOpz");
		if (bEnableMassPhysicsOpz)
		{
			if (URoleMovementComponent* RoleMovementCom = GetComponentByClass<URoleMovementComponent>())
			{
				if (CurrentActorLOD == 0)
				{
					RoleMovementCom->SetIsIgnorePhysFixup(false);
					RoleMovementCom->SetNeedFrameStickGroundForceValue(false, TEXT("CrowdNpcLOD"));
					RoleMovementCom->SetUseComplexFrameStickGround(true);
					RoleMovementCom->SetFrameStickGroundDistance(500);
				}
				else
				{
					RoleMovementCom->SetIsIgnorePhysFixup(true);
					RoleMovementCom->SetNeedFrameStickGroundForceValue(true, TEXT("CrowdNpcLOD"));
					RoleMovementCom->SetUseComplexFrameStickGround(false);
					float StickGroundDistance = PlatformScalabilitySettings->GetScalabilityValue<float>("MassNPC", "StickGroundDis");
					RoleMovementCom->SetFrameStickGroundDistance(StickGroundDistance);
				}
			}
		}
	}

	if(CheckCurrentAnimInstance())
	{
		const KGObjectID ActorID = KGUtils::GetIDByObject(this);
		const bool EnableHeadControl =  PlatformScalabilitySettings->GetScalabilityLodValue<bool>(CurrentActorLOD,"FaceControl", "EnableLODHeadControl");
		const bool EnableBodyControl =  PlatformScalabilitySettings->GetScalabilityLodValue<bool>(CurrentActorLOD,"FaceControl", "EnableLODBodyControl");
		CurrentAnimInstance->SetIsEnableHeadControl(EnableHeadControl);
		CurrentAnimInstance->SetIsEnableBodyControl(EnableBodyControl);
		
		//如果LOD管控，关闭SequenceFaceSlot权重
		if(EnableLOD)
		{
			CurrentAnimInstance->SetSequenceFaceBlendWeight(0);
		}
		
		for (auto AnimLayer : AnimLayerMap)
		{
			FName AnimLayerFName = FName(AnimLayer.Key);
			FString AnimLayerName = AnimLayer.Key;
			FString AnimLayerClassPath = AnimLayer.Value;
			if(AnimLayerName == KawaiiTag) 
			{
				bool bChaosClothPermit = false;
				bool bKawaiiPermit = false;
				GetClothAndKawaiiPermit(PlatformScalabilitySettings,ActorID, CurrentActorLOD,bChaosClothPermit,bKawaiiPermit);
				CurrentAnimInstance->UpdateChaosClothAndKawaii(bChaosClothPermit, false, bKawaiiPermit, AnimLayerFName, true, AnimLayerClassPath);
				continue;
			}
		
			const bool HasLink = CurrentAnimInstance->HasLinkFeatureAnimLayer(AnimLayerFName);
			bool LODPermit = PlatformScalabilitySettings->CheckLodBoolPermit( CurrentActorLOD, AnimLayerLinkLODTag, AnimLayerName);
			LODPermit = !EnableLOD || LODPermit;
			if(LODPermit)
			{
				if(HasLink)
				{
					CurrentAnimInstance->EnableAnimFeatureLayer(AnimLayerFName);
				}
				else
				{
					UKGCppAssetManager* CppAssetManager = UKGCppAssetManager::GetInstance(this);
					if (!CppAssetManager) {
						return;
					}

					UClass* AnimClassPtr = CppAssetManager->GetAnimABPClassCache(FName(AnimLayerClassPath));
					if (!AnimClassPtr) {
						UE_LOG(LogTemp, Error, TEXT("[ABaseCharacter::OnLODChanged]  GetAnimABPClass: UID:%lld cannot Get Anim Class By Path:%s"), EntityUID, *AnimLayerClassPath);
						return;
					}

					const TSubclassOf<UAnimInstance> AnimationClass(AnimClassPtr);
					//这里应该不会走到，目前只有Kawaii和IK两个Layer，FaceAnim和GazeTag业务按需Link
					CurrentAnimInstance->LinkFeatureAnimLayer(AnimLayerFName, AnimationClass);
				}
			}
			else
			{
				if(HasLink)
				{
					CurrentAnimInstance->DisableAnimFeatureLayer(AnimLayerFName);
				}
			}
		}
	}
}

void ABaseCharacter::EnableAnimTickOptimization(bool bEnable)
{
	ULowLevelFunctions::EnableAnimTickOptimization(GetMainMesh(), bEnable);
}

bool ABaseCharacter::CheckCurrentAnimInstance()
{
	if(!CurrentAnimInstance.IsValid() || CurrentAnimInstance->GetOwningActor() != this)
	{
		if(IC7ActorInterface* IC7Actor = Cast<IC7ActorInterface>(this))
		{
			if(const USkeletalMeshComponent* SKMesh = Cast<USkeletalMeshComponent>(IC7Actor->GetMainMesh()))
			{
				CurrentAnimInstance = Cast<UBaseAnimInstance>(SKMesh->GetAnimInstance());
			}
		}
	}
	
	if(CurrentAnimInstance == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("[ABaseCharacter::OnLODChanged] Can not find UBaseAnimInstance. eid:%lld Actor:%s"), EntityUID, *GetName());
		return false;
	}
	
	return true;
}

void ABaseCharacter::GetClothAndKawaiiPermit(UKGPlatformScalabilitySettings* PlatformScalabilitySettings,int64 ActorID, int Lod, bool& ClothPermit, bool& KawaiiPermit)
{
	bool EnableClothSetting = PlatformScalabilitySettings->GetScalabilityValue<bool>("Game", "EnableClothSetting");
	bool GameEnableCloth = EnableClothSetting && PlatformScalabilitySettings->GetScalabilityValue<bool>("Game", "EnableCloth");
	bool GameEnableKawaii = PlatformScalabilitySettings->GetScalabilityValue<bool>("Game", "EnableKawaii");
	bool EnableClothPhysics = false;
	if(CVarEnableClothPhysics)
	{
		EnableClothPhysics = CVarEnableClothPhysics->GetInt() > 0;
	}
	ClothPermit = EnableClothPhysics && GameEnableCloth && (!EnableLOD || PlatformScalabilitySettings->ConsumeActorLimitBudgetWithLod(ActorID, Lod, AnimLayerLinkLimitTag,AnimLayerLinkLODTag,ClothTag));
	KawaiiPermit = GameEnableKawaii && (!EnableLOD ||  PlatformScalabilitySettings->ConsumeActorLimitBudgetWithLod(ActorID, Lod, AnimLayerLinkLimitTag,AnimLayerLinkLODTag,KawaiiTag));
}

void ABaseCharacter::UpdateChaosClothAndKawaii(bool forceRecreateCloth)
{
	if(!AnimLayerMap.Contains(KawaiiTag) || !CheckCurrentAnimInstance())
	{
		return;
	}
	
	UKGPlatformScalabilitySettings* PlatformScalabilitySettings = UKGPlatformScalabilitySettings::GetInstance(this);
	if (!PlatformScalabilitySettings)
	{
		return;
	}
	
	int CurrentActorLOD = ActorLOD;
	if(!EnableLOD)
	{
		CurrentActorLOD = 0;
	}
	
	const FName AnimLayerFName = FName(KawaiiTag);
	const FString AnimLayerClassPath = AnimLayerMap[KawaiiTag];
	const KGObjectID ActorID = KGUtils::GetIDByObject(this);
	bool bChaosClothPermit = false;
	bool bKawaiiPermit = false;
	GetClothAndKawaiiPermit(PlatformScalabilitySettings,ActorID, CurrentActorLOD,bChaosClothPermit,bKawaiiPermit);
	CurrentAnimInstance->UpdateChaosClothAndKawaii(bChaosClothPermit, forceRecreateCloth, bKawaiiPermit, AnimLayerFName, true, AnimLayerClassPath);
}

void ABaseCharacter::ReleaseAllLimitBudget()
{
	if(UKGPlatformScalabilitySettings* PlatformScalabilitySettings = UKGPlatformScalabilitySettings::GetInstance(this))
	{
		const KGObjectID ActorID = KGUtils::GetIDByObject(this);
		PlatformScalabilitySettings->ReleaseActorAllLimitBudget(ActorID);
	}
}

void ABaseCharacter::SetIsLocalAIPawn(bool InIsLocalAIPawn)
{
	bIsLocalAIPawn = InIsLocalAIPawn;
}

void ABaseCharacter::SetCharacterRotation(FRotator NewRotator, bool bTeleportPhysics)
{
	K2_SetActorRotation(NewRotator, bTeleportPhysics);
}

void ABaseCharacter::SetCharacterMeshRotation(FRotator NewRotator, bool bSweep, FHitResult& SweepHitResult, bool bTeleport)
{
	USkeletalMeshComponent* MeshComponent = GetMesh();
	if (MeshComponent)
	{
		MeshComponent->K2_SetWorldRotation(NewRotator, bSweep, SweepHitResult, bTeleport);
	}
}

FRotator ABaseCharacter::GetCharacterMeshRotation()
{
	USkeletalMeshComponent* MeshComponent = GetMesh();
	if (MeshComponent)
	{
		return MeshComponent->K2_GetComponentRotation();
	}
	return FRotator();
}

FTransform ABaseCharacter::GetCharacterMeshRelativeTransform()
{
	USkeletalMeshComponent* MeshComponent = GetMesh();
	if (MeshComponent)
	{
		return MeshComponent->GetRelativeTransform();
	}
	return FTransform();
}

FVector ABaseCharacter::GetCharacterMeshLocation()
{
	USkeletalMeshComponent* MeshComponent = GetMesh();
	if (MeshComponent)
	{
		return MeshComponent->K2_GetComponentLocation();
	}
	return FVector();
}

//MainMeshKawaii的放到BaseCharacter，因为UBaseAnimInstance是可能换的，而SK的设置在动画设置之前
void ABaseCharacter::SetMainMeshKawaiiAlphaKeys(const int64& MeshComID, const TArray<FName>& KawaiiAlphaEnableArray, bool Enable, float WindScale)
{
	for(auto& MainMeshKawaiiAlpha : MainMeshKawaiiAlphaEnableMap)
	{
		MainMeshKawaiiAlpha.Value.Remove(MeshComID);
	}
	
	if(Enable)
	{
		for(auto KawaiiAlphaEnable : KawaiiAlphaEnableArray)
		{
			FString NewKawaiiAlphaEnableStr = KawaiiAlphaEnable.ToString();
			if(UBaseAnimInstance::UseKawaiiAllInOne)
			{
				NewKawaiiAlphaEnableStr.ReplaceInline(*UBaseAnimInstance::KawaiiAlphaPrefix, TEXT(""));
			}
			FName NewKawaiiAlphaEnable = FName(NewKawaiiAlphaEnableStr);
			auto& Value = MainMeshKawaiiAlphaEnableMap.FindOrAdd(NewKawaiiAlphaEnable);
			Value.Add(MeshComID);

			// set wind scale
			auto& WindScaleValue = MainMeshKawaiiWindScaleMap.FindOrAdd(NewKawaiiAlphaEnable);
            WindScaleValue = WindScale;
		}
	}
}

void ABaseCharacter::EnableBoneMask(bool Enable)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("ABaseCharacter::EnableBoneMask")
	if(URoleCompositeMgr* RoleCompositeMgr = URoleCompositeMgr::GetInstance(this))
	{
		USkeletalMeshComponent* MeshComponent = GetMesh();
		if(MeshComponent)
		{
			MeshComponent->SetBoneMaskEnable(false);
			MeshComponent->SetRefBoneMask();
		}

		if(!Enable)
		{
			return;
		}
		
        if (MeshComponent && MeshComponent->GetSkeletalMeshAsset() && MeshComponent->GetSkeletalMeshAsset()->GetSkeleton())
        {
        	TSharedPtr<FBoneContainer> sharedBones = MeshComponent->GetSharedRequiredBones();
        	MeshComponent->IntiBoneMasks(sharedBones->GetSkeletonToPoseBoneIndexArray().Num());
        	
	        const FName SkeletonName = MeshComponent->GetSkeletalMeshAsset()->GetSkeleton()->GetFName();
        	auto SkeletonBoneMaskData = RoleCompositeMgr->GetBoneMaskData(SkeletonName);
        	if(!SkeletonBoneMaskData)
        	{
        		return;
        	}

        	for (auto v : *SkeletonBoneMaskData)
        	{
        		for (int32 BoneIndex : v.Value)
        		{
        			MeshComponent->SetBoneMask(BoneIndex, true);
        		}
        	}
        	
        	for(auto& AlphaEnableMap : MainMeshKawaiiAlphaEnableMap)
        	{
        		if(AlphaEnableMap.Value.Num()>0)
        		{
        			TArray<int32>* BoneMaskData = RoleCompositeMgr->GetBoneMaskDataByRootName(SkeletonName, AlphaEnableMap.Key);
        			if(!BoneMaskData)
        			{
        				continue;
        			}
        			for (int32 BoneIndex : *BoneMaskData)
        			{
        				MeshComponent->SetBoneMask(BoneIndex, false);
        			}
        		}
        	}
        	MeshComponent->SetBoneMaskEnable(true);
        	MeshComponent->SetRefBoneMask();
        }
	}
}

#pragma endregion Common


#pragma region PathFollow
int32 ABaseCharacter::PathFollowToActor(FAIRequestID& RequestID, const AActor* Goal, float AcceptanceRadius, bool bFindPath) {
	UNavigationSystemV1* NavSys = FNavigationSystem::GetCurrent<UNavigationSystemV1>(GetWorld());
	if (NavSys == nullptr || Goal == nullptr)
	{
		UE_LOG(LogNavigation, Warning, TEXT("UNavigationSystemV1::SimpleMoveToActor called for NavSys:%s, Pawn:%s with goal actor %s (if any of these is None then there's your problem"),
			*GetNameSafe(NavSys), *GetNameSafe(this), *GetNameSafe(Goal));
		return EPathFollowingRequestResult::Failed;
	}

	UC7PathFollowComponent* PFollowComp = PathFollowingComponent.Get();

	if (PFollowComp == nullptr || !PFollowComp->IsPathFollowingAllowed())
	{
		return EPathFollowingRequestResult::Failed;
	}

	const bool bAlreadyAtGoal = PFollowComp->HasReached(*Goal, EPathFollowingReachMode::ExactLocation);

	// script source, keep only one move request at time
	if (PFollowComp->GetStatus() != EPathFollowingStatus::Idle)
	{
		PFollowComp->AbortMove(*NavSys, FPathFollowingResultFlags::ForcedScript | FPathFollowingResultFlags::NewRequest
			, FAIRequestID::AnyRequest, bAlreadyAtGoal ? EPathFollowingVelocityMode::Reset : EPathFollowingVelocityMode::Keep);
	}

	if (bAlreadyAtGoal)
	{
		RequestID = PFollowComp->RequestMoveWithImmediateFinish(EPathFollowingResult::Success);
		return EPathFollowingRequestResult::AlreadyAtGoal;
	}
	const FVector AgentNavLocation = GetNavAgentLocation();
	ANavigationData* NavData = NavSys->GetNavDataForProps(GetNavAgentPropertiesRef(), AgentNavLocation);
	if (!IsValid(NavData))
	{
		UE_LOG(LogTemp, Warning, TEXT("PathFollowToActor Failed! InValid NavData! Loc:%s"), *AgentNavLocation.ToString());
		return EPathFollowingRequestResult::Failed;
	}
	PFollowComp->UpdateNavData(NavData);

	FVector TargetPos = Goal->GetActorLocation();
	const INavAgentInterface* NavGoal = Cast<const INavAgentInterface>(Goal);
	if (NavGoal)
	{
		TargetPos = NavGoal->GetNavAgentLocation();
	}

	if (bFindPath)
	{
		FPathFindingQuery Query(this, *NavData, FindValidPathFollowStartLoc(), TargetPos);
		FPathFindingResult Result = NavSys->FindPathSync(Query);
		if (Result.IsSuccessful())
		{
			Result.Path->SetGoalActorObservation(*Goal, 100.0f);

			FAIMoveRequest MoveReq = FAIMoveRequest(Goal);
			MoveReq.SetAcceptanceRadius(AcceptanceRadius);
			MoveReq.SetReachTestIncludesGoalRadius(false);
			MoveReq.SetReachTestIncludesAgentRadius(false);
			RequestID = PFollowComp->RequestMove(MoveReq, Result.Path);

			PathFollowingComponent->SetComponentTickEnabled(true);
			return EPathFollowingRequestResult::RequestSuccessful;
		}
		else if (PFollowComp->GetStatus() != EPathFollowingStatus::Idle)
		{
			RequestID = PFollowComp->RequestMoveWithImmediateFinish(EPathFollowingResult::Invalid);
		}
	}
	else
	{
		FNavPathSharedPtr Path = MakeShareable(new FNavMeshPath());
		Path->GetPathPoints().Add(FNavPathPoint(AgentNavLocation));
		Path->GetPathPoints().Add(FNavPathPoint(TargetPos));
		Path->SetGoalActorObservation(*Goal, 100.0f);
		Path->MarkReady();
		FAIMoveRequest MoveReq = FAIMoveRequest(Goal);
		MoveReq.SetAcceptanceRadius(AcceptanceRadius);
		MoveReq.SetReachTestIncludesGoalRadius(false);
		MoveReq.SetReachTestIncludesAgentRadius(false);
		RequestID = PFollowComp->RequestMove(MoveReq, Path);
		PathFollowingComponent->SetComponentTickEnabled(true);
		return EPathFollowingRequestResult::RequestSuccessful;
	}

	return EPathFollowingRequestResult::Failed;
}

int32 ABaseCharacter::PathFollowToLocation(FAIRequestID& RequestID, const FVector& GoalLocation, float AcceptanceRadius, bool bFindPath) {
	UNavigationSystemV1* NavSys = FNavigationSystem::GetCurrent<UNavigationSystemV1>(GetWorld());
	if (NavSys == nullptr)
	{
		UE_LOG(LogNavigation, Warning, TEXT("UNavigationSystemV1::SimpleMoveToActor called for NavSys:%s, Pawn:%s (if any of these is None then there's your problem"),
			*GetNameSafe(NavSys), *GetNameSafe(this));
		return EPathFollowingRequestResult::Failed;
	}

	UC7PathFollowComponent* PFollowComp = PathFollowingComponent.Get();

	if (PFollowComp == nullptr || !PFollowComp->IsPathFollowingAllowed())
	{
		return EPathFollowingRequestResult::Failed;
	}

	const bool bAlreadyAtGoal = PFollowComp->HasReached(GoalLocation, EPathFollowingReachMode::ExactLocation);

	// script source, keep only one move request at time
	if (PFollowComp->GetStatus() != EPathFollowingStatus::Idle)
	{
		PFollowComp->AbortMove(*NavSys, FPathFollowingResultFlags::ForcedScript | FPathFollowingResultFlags::NewRequest
			, FAIRequestID::AnyRequest, bAlreadyAtGoal ? EPathFollowingVelocityMode::Reset : EPathFollowingVelocityMode::Keep);
	}

	// script source, keep only one move request at time
	if (PFollowComp->GetStatus() != EPathFollowingStatus::Idle)
	{
		PFollowComp->AbortMove(*NavSys, FPathFollowingResultFlags::ForcedScript | FPathFollowingResultFlags::NewRequest);
	}

	if (bAlreadyAtGoal)
	{
		RequestID = PFollowComp->RequestMoveWithImmediateFinish(EPathFollowingResult::Success);
		return EPathFollowingRequestResult::AlreadyAtGoal;
	}

	const FVector AgentNavLocation = GetNavAgentLocation();
	ANavigationData* NavData = NavSys->GetNavDataForProps(GetNavAgentPropertiesRef(), AgentNavLocation);
	if (!IsValid(NavData))
	{
		UE_LOG(LogTemp, Warning, TEXT("PathFollowToLocation Failed! InValid NavData! Loc:%s"), *AgentNavLocation.ToString());
		return EPathFollowingRequestResult::Failed;
	}
	PFollowComp->UpdateNavData(NavData);

	if (bFindPath)
	{
		FPathFindingQuery Query(this, *NavData, FindValidPathFollowStartLoc(), GoalLocation);
		FPathFindingResult Result = NavSys->FindPathSync(Query);
		if (Result.IsSuccessful())
		{
			FAIMoveRequest MoveReq = FAIMoveRequest(GoalLocation);
			MoveReq.SetAcceptanceRadius(AcceptanceRadius);
			MoveReq.SetReachTestIncludesGoalRadius(false);
			MoveReq.SetReachTestIncludesAgentRadius(false);
			RequestID = PFollowComp->RequestMove(MoveReq, Result.Path);
			PathFollowingComponent->SetComponentTickEnabled(true);
			return EPathFollowingRequestResult::RequestSuccessful;
		}
		else if (PFollowComp->GetStatus() != EPathFollowingStatus::Idle)
		{
			RequestID = PFollowComp->RequestMoveWithImmediateFinish(EPathFollowingResult::Invalid);
		}
	}
	else
	{
		FNavPathSharedPtr Path = MakeShareable(new FNavMeshPath());
		Path->GetPathPoints().Add(FNavPathPoint(AgentNavLocation));
		Path->GetPathPoints().Add(FNavPathPoint(GoalLocation));
		Path->MarkReady();
		FAIMoveRequest MoveReq = FAIMoveRequest(GoalLocation);
		MoveReq.SetAcceptanceRadius(AcceptanceRadius);
		MoveReq.SetReachTestIncludesGoalRadius(false);
		MoveReq.SetReachTestIncludesAgentRadius(false);
		RequestID = PFollowComp->RequestMove(MoveReq, Path);
		PathFollowingComponent->SetComponentTickEnabled(true);
		return EPathFollowingRequestResult::RequestSuccessful;
	}
	return EPathFollowingRequestResult::Failed;
}

void ABaseCharacter::OnPathFollowCompleted(FAIRequestID RequestID, const FPathFollowingResult& Result)
{
	CALL_LUA_ENTITY("KCB_OnReceivePathFollowCompleted", RequestID.GetID(), (int)(Result.Code));

	if (!PathFollowingComponent->GetNeedTick())
	{
		PathFollowingComponent->SetComponentTickEnabled(false);
	}
}

bool ABaseCharacter::PausePathFollow(FAIRequestID RequestToPause)
{
	if (!IsValid(PathFollowingComponent))
	{
		ensureAlways(false);
		return false;
	}
	
	if (RequestToPause.IsEquivalent(PathFollowingComponent->GetCurrentRequestId()))
	{
		PathFollowingComponent->PauseMove(RequestToPause, EPathFollowingVelocityMode::Reset);
		return true;
	}

	return false;
}

bool ABaseCharacter::ResumePathFollow(FAIRequestID RequestToResume)
{
	if (!IsValid(PathFollowingComponent))
	{
		ensureAlways(false);
		return false;
	}

	if (RequestToResume.IsEquivalent(PathFollowingComponent->GetCurrentRequestId()))
	{
		PathFollowingComponent->ResumeMove(RequestToResume);
		return true;
	}

	return false;
}

void ABaseCharacter::StopPathFollow()
{
	if (!IsValid(PathFollowingComponent))
	{
		ensureAlways(false);
		return;
	}

	PathFollowingComponent->AbortMove(*this, FPathFollowingResultFlags::MovementStop | FPathFollowingResultFlags::ForcedScript);
}

FVector ABaseCharacter::FindValidPathFollowStartLoc()
{
	FVector AgentNavLocation = GetNavAgentLocation();
	UNavigationSystemV1* NavSys = FNavigationSystem::GetCurrent<UNavigationSystemV1>(GetWorld());
	if (NavSys == nullptr) {
		return AgentNavLocation;
	}

	FNavLocation OutNewAgentNavLocation;
	if (IsValid(GetCapsuleComponent()))
	{
		float HalfHeight, Radius = 0.0f;
		GetCapsuleComponent()->GetScaledCapsuleSize(Radius, HalfHeight);
		if (NavSys->ProjectPointToNavigation(AgentNavLocation, OutNewAgentNavLocation, FVector(Radius, Radius, 50.0f)))
		{
			return OutNewAgentNavLocation.Location;
		}
		else if(Radius < 100.0f)
		{
			if (NavSys->ProjectPointToNavigation(AgentNavLocation, OutNewAgentNavLocation, FVector(100.0f, 100.0f, 50.0f)))
			{
				return OutNewAgentNavLocation.Location;
			}
		}
	}

	return AgentNavLocation;
}

FVector ABaseCharacter::GetMoveGoalOffset(const AActor* MovingActor) const
{
	if (MoveGoalOffsetMap.Contains(MovingActor))
	{
		return *MoveGoalOffsetMap.Find(MovingActor);
	}

	return FVector::ZeroVector;
}

void ABaseCharacter::SetMoveGoalOffsetMap(int64 InActorID, float InOffsetX, float InOffsetY, float InOffsetZ)
{
	if (UKGObjectActorManager* UOMgr = UKGObjectActorManager::GetInstance(this))
	{
		if (AActor* InActor = Cast<AActor>(UOMgr->GetObjectByID(InActorID)))
		{
			MoveGoalOffsetMap.Add(InActor, FVector(InOffsetX, InOffsetY, InOffsetZ));
		}
	}
}

void ABaseCharacter::ClearMoveGoalOffsetMap(int64 InActorID)
{
	if (UKGObjectActorManager* UOMgr = UKGObjectActorManager::GetInstance(this))
	{
		if (AActor* InActor = Cast<AActor>(UOMgr->GetObjectByID(InActorID)))
		{
			MoveGoalOffsetMap.Remove(InActor);
		}
	}
}

void ABaseCharacter::SetKeepingPahthFollowInfo(KGObjectID PathFollowTargetID, float InX, float InY, float InZ, float InGap)
{
	AActor* PathFollowTarget = KGUtils::GetActorByID(PathFollowTargetID);
	if (IsValid(PathFollowingComponent) && IsValid(PathFollowTarget))
	{
		PathFollowingComponent->SetKeepingPahthFollowInfo(PathFollowTarget, InX, InY, InZ, InGap);
	}
}

void ABaseCharacter::ResetKeepingPahthFollowInfo()
{
	if (IsValid(PathFollowingComponent))
	{
		PathFollowingComponent->ResetKeepingPahthFollowInfo();
		PathFollowingComponent->SetComponentTickEnabled(false);
	}
}

void ABaseCharacter::StartRestartCheck()
{
	if (IsValid(PathFollowingComponent))
	{
		PathFollowingComponent->StartRestartCheck();
		PathFollowingComponent->SetComponentTickEnabled(true);
	}
}

void ABaseCharacter::StopRestartCheck()
{
	if (IsValid(PathFollowingComponent))
	{
		PathFollowingComponent->StopRestartCheck();
		if (!PathFollowingComponent->GetNeedTick())
		{
			PathFollowingComponent->SetComponentTickEnabled(false);
		}
	}
}

void ABaseCharacter::StartChaseVelocityCheck(float InMinChaseSpeed, float InDefaultChaseSpeed, float InVelocitySuitGap, float InKeepingPathFollowAcceptanceRadius)
{
	if (IsValid(PathFollowingComponent))
	{
		PathFollowingComponent->StartChaseVelocityCheck(InMinChaseSpeed, InDefaultChaseSpeed, InVelocitySuitGap, InKeepingPathFollowAcceptanceRadius);
		PathFollowingComponent->SetComponentTickEnabled(true);
	}
}

void ABaseCharacter::StopChaseVelocityCheck()
{
	if (IsValid(PathFollowingComponent))
	{
		PathFollowingComponent->StopChaseVelocityCheck();
		if (!PathFollowingComponent->GetNeedTick())
		{
			PathFollowingComponent->SetComponentTickEnabled(false);
		}
	}
}

void ABaseCharacter::StartSimpleFollow(KGObjectID PathFollowTargetID, float InnerRadius, float OuterRadius, float OffsetX, float OffsetY, float OffsetZ, bool bEnableFrameStickGround)
{
	AActor* PathFollowTarget = KGUtils::GetActorByID(PathFollowTargetID);
	if (IsValid(PathFollowingComponent))
	{
		PathFollowingComponent->StartSimpleFollow(PathFollowTarget, InnerRadius, OuterRadius, OffsetX, OffsetY, OffsetZ, bEnableFrameStickGround);
	}
}

void ABaseCharacter::StopSimpleFollow()
{
	if (IsValid(PathFollowingComponent))
	{
		PathFollowingComponent->StopSimpleFollow();
	}
}


#pragma endregion PathFollow


#pragma region StickGround
bool ABaseCharacter::SimpleSetActorStickGroundWithCheckDistance(float CheckDistance)
{
	FVector StickGroundLoc = FVector();
	if (!SimpleCheckActorStickGround(StickGroundLoc, CheckDistance))
	{
		return false;
	}

	SetActorLocation(StickGroundLoc);
	return true;
}

FVector ABaseCharacter::SimpleGetStickGroundLocationFromSpecificLocation(const FVector& InLocation)
{
	if (!IsValid(GetRootComponent()) || !IsValid(GetCapsuleComponent()))
	{
		FVector OutLocation = InLocation;
		return OutLocation;
	}

	float HalfHeight = GetCapsuleComponent()->GetScaledCapsuleHalfHeight();
	return GetStickGroundLocationFromSpecificLocationCheckDistance(InLocation, HalfHeight * 4);
}

bool ABaseCharacter::SimpleGetAndCheckStickGroundLocationFromSpecificLocation(const FVector& InLocation, FVector& OutInLocation)
{
	if (!IsValid(GetRootComponent()) || !IsValid(GetCapsuleComponent()))
	{
		OutInLocation = InLocation;
		return false;
	}

	float HalfHeight = GetCapsuleComponent()->GetScaledCapsuleHalfHeight();
	return GetAndCheckStickGroundLocationFromSpecificLocationCheckDistance(InLocation, OutInLocation, HalfHeight * 4);
}

FVector ABaseCharacter::GetStickGroundLocationFromSpecificLocationCheckDistance(const FVector& InLocation, const float& InCheckDistance)
{
	FVector OutLocation = InLocation;

	if (!IsValid(GetRootComponent()))
	{
		return OutLocation;
	}

	if (CachedCollisionPresetName.IsNone()) {	
		if (URoleMovementComponent* MoveComp = FindComponentByClass<URoleMovementComponent>()){
			CachedCollisionPresetName = MoveComp->GetTrackFloorCollisionPresetName();
		}
		else {
			CachedCollisionPresetName = TEXT("Pawn");
		}
	}

	CheckActorStickGround(CachedCollisionPresetName, InCheckDistance, OutLocation, &InLocation);
	return OutLocation;
}

bool ABaseCharacter::GetAndCheckStickGroundLocationFromSpecificLocationCheckDistance(const FVector& InLocation,
	FVector& OutInLocation, const float& InCheckDistance)
{
	if (!IsValid(GetRootComponent()))
	{
		OutInLocation = InLocation;
		return false;
	}

	if (CachedCollisionPresetName.IsNone()) {
		if (URoleMovementComponent* MoveComp = FindComponentByClass<URoleMovementComponent>()) {
			CachedCollisionPresetName = MoveComp->GetTrackFloorCollisionPresetName();
		}
		else {
			CachedCollisionPresetName = TEXT("Pawn");
		}
	}

	bool bResult = CheckActorStickGround(CachedCollisionPresetName, InCheckDistance, OutInLocation, &InLocation);
	return bResult;
}

bool ABaseCharacter::SimpleSetActorStickGround()
{
	float HalfHeight = GetCapsuleComponent()->GetScaledCapsuleHalfHeight();
	return SimpleSetActorStickGroundWithCheckDistance(HalfHeight * 4.0f);
}

bool ABaseCharacter::SimpleCheckActorStickGround(FVector& OutStickGroundLoc, float CheckDistance)
{
	if (!IsValid(GetRootComponent()) || !IsValid(GetCapsuleComponent()))
	{
		return false;
	}

	if (CachedCollisionPresetName.IsNone()) {
		if (URoleMovementComponent* MoveComp = FindComponentByClass<URoleMovementComponent>()) {
			CachedCollisionPresetName = MoveComp->GetTrackFloorCollisionPresetName();
		}
		else {
			CachedCollisionPresetName = TEXT("Pawn");
		}
	}

	return CheckActorStickGround(CachedCollisionPresetName, CheckDistance, OutStickGroundLoc);
}

bool ABaseCharacter::CheckActorStickGround(const FName& InPresetName, float CheckDistance, FVector& OutStickGroundLoc, const FVector* SpecificLoc, const bool bUseComplex, const float RadiusRatio)
{
	if (!IsValid(GetRootComponent()) || !IsValid(GetCapsuleComponent()))
	{
		return false;
	}

	if (!CachedStickGroundCollisionProfile.IsSet()) 
	{
		FCollisionResponseTemplate TempCollisionResponseTemplate;
		if (!UCollisionProfile::Get()->GetProfileTemplate(InPresetName, TempCollisionResponseTemplate))
		{
			UE_LOG(LogTemp, Log, TEXT("Character:%s StickGround Failed! InValid CollisionPresetName:%s"), *GetName(), *InPresetName.ToString());
			return false;
		}
		CachedStickGroundCollisionProfile = TempCollisionResponseTemplate;
	}

	if (!CachedStickGroundQueryParams.IsSet()) 
	{
		CachedStickGroundQueryParams = FCollisionQueryParams(SCENE_QUERY_STAT(BaseCharacterStickGround), false, this);
		CachedStickGroundQueryParams.GetValue().bIgnoreTouches = true;
	}
	
	if (!CachedStickGroundCollisionResponseParams.IsSet()) {
		CachedStickGroundCollisionResponseParams = CachedStickGroundCollisionProfile.GetValue().ResponseToChannels;
	}
	if (!CachedStickGroundCollisionChannel.IsSet()) {
		CachedStickGroundCollisionChannel = CachedStickGroundCollisionProfile.GetValue().ObjectType;
	}

	const FVector CurrentLocation = SpecificLoc ? *SpecificLoc : GetRootComponent()->GetComponentLocation();
	float PawnRadius = 0.0f, PawnHalfHeight = 0.0f;
	GetCapsuleComponent()->GetScaledCapsuleSize(PawnRadius, PawnHalfHeight);
	PawnRadius *= RadiusRatio;

	if (bUseComplex)
	{
		return CheckComplexActorStickGround(OutStickGroundLoc, CurrentLocation, CheckDistance, CachedStickGroundCollisionChannel.GetValue(), PawnRadius, PawnHalfHeight,
			CachedStickGroundQueryParams.GetValue(), CachedStickGroundCollisionResponseParams.GetValue());
	}

	return CheckSimpleActorStickGround(OutStickGroundLoc, CurrentLocation, CheckDistance, CachedStickGroundCollisionChannel.GetValue(), PawnHalfHeight,
		CachedStickGroundQueryParams.GetValue(), CachedStickGroundCollisionResponseParams.GetValue());
}

bool ABaseCharacter::CheckComplexActorStickGround(FVector& OutStickGroundLoc, const FVector& CheckLocation, float CheckDistance, const ECollisionChannel& TraceChannel, float PawnRadius, float PawnHalfHeight, const FCollisionQueryParams& QueryParams, const FCollisionResponseParams& ResponseParam)
{
	TArray<FHitResult> OutHits;
	bool bGroundIsHigher = false;
	bool bGroundIsLower = false;
	float MinDistance = BIG_NUMBER;
	float HighestImpactLocZ = -BIG_NUMBER;
	FCollisionShape CollisionShape = FCollisionShape::MakeCapsule(PawnRadius, PawnHalfHeight);

	GetWorld()->SweepMultiByChannel(OutHits, CheckLocation, CheckLocation + FVector(0.0f, 0.0f, -CheckDistance), FQuat::Identity, TraceChannel, CollisionShape, QueryParams, ResponseParam);

#if UE_BUILD_DEVELOPMENT
	FString TracedComponentName = FString();
#endif //UE_BUILD_DEVELOPMENT

	for (int32 i = 0; i < OutHits.Num(); i++)
	{
		if (OutHits[i].bBlockingHit)
		{
			if (OutHits[i].Distance < SMALL_NUMBER)
			{
				bGroundIsHigher = true;
				HighestImpactLocZ = FMath::Max(HighestImpactLocZ, OutHits[i].ImpactPoint.Z);
			}
			else
			{
				bGroundIsLower = true;
#if UE_BUILD_DEVELOPMENT
				if (OutHits[i].Distance < MinDistance)
				{
					TracedComponentName = GetHitResCompName(OutHits[i]);
				}
#endif //UE_BUILD_DEVELOPMENT
				MinDistance = FMath::Min(MinDistance, OutHits[i].Distance);
			}
		}
	}

	if (bGroundIsHigher)
	{
		FHitResult OutHit;
		// 胶囊体已经插入地面的情况，将胶囊体底部抬高至ImpactPoint高度(多往上抬了FurtherLiftDist)，从该位置重新再做一次贴地检查
		FVector NewStartLocation = CheckLocation + FVector(0.0f, 0.0f, HighestImpactLocZ - (CheckLocation.Z - FMath::Max(PawnRadius, PawnHalfHeight)) + FurtherLiftDist);
		bool bSingleTraceSuccess = GetWorld()->SweepSingleByChannel(OutHit, NewStartLocation, NewStartLocation + FVector(0.0f, 0.0f, -CheckDistance), FQuat::Identity, TraceChannel, CollisionShape, QueryParams, ResponseParam);

		if (OutHit.bBlockingHit && OutHit.Distance > 0.0f)
		{
			OutStickGroundLoc = NewStartLocation + FVector(0.0f, 0.0f, -OutHit.Distance + UCharacterMovementComponent::MIN_FLOOR_DIST);
			if (MaxStickGroundLiftDist.IsSet()) {
				// 检查最多允许的抬升距离，超过这个距离视为贴地失败
				return MaxStickGroundLiftDist.GetValue() >= (OutStickGroundLoc.Z - CheckLocation.Z);
			}
			return true;
		}
		else if (!bSingleTraceSuccess)
		{
			// 对于一些楼梯的情况，前面找到的ImpactPoint可能不在胶囊体中轴线上，抬升的高度可能会过高，这时找不到TraceTarget，也认为是成功
			OutStickGroundLoc = NewStartLocation + FVector(0.0f, 0.0f, -FurtherLiftDist + UCharacterMovementComponent::MIN_FLOOR_DIST);
			if (MaxStickGroundLiftDist.IsSet()) {
				// 检查最多允许的抬升距离，超过这个距离视为贴地失败
				return MaxStickGroundLiftDist.GetValue() >= (OutStickGroundLoc.Z - CheckLocation.Z);
			}
			return true;
		}
		else
		{
			// 抬起胶囊体向下做trace，仍然是Penetrate的情况
			// 说明要么是顶到头了，要么是碰到墙了。
			// 卡住的情况不阻塞贴地判断了，直接使用默认位置通过
			OutStickGroundLoc = CheckLocation;
#if UE_BUILD_DEVELOPMENT
			UE_LOG(LogTemp, Warning, TEXT("Character:%s ComplexStickGround Failed! CharacterLoc:%s, Stuck in TracedComponent:%s, HighestImpactLocZ:%f"), *GetName(), *CheckLocation.ToString(), *GetHitResCompName(OutHit), HighestImpactLocZ);
			UE_LOG(LogTemp, Warning, TEXT("FirstHitsInfo:"));
			for (int32 i = 0; i < OutHits.Num(); i++)
			{
				UE_LOG(LogTemp, Warning, TEXT("%i: TracedComponent:%s, bBlockingHit:%d, Distance:%f, PenetrationDepth:%f, ImpactPoint:%s"), i, *GetHitResCompName(OutHits[i]), OutHits[i].bBlockingHit,
					OutHits[i].Distance, OutHits[i].PenetrationDepth, *OutHits[i].ImpactPoint.ToString());
			}
			UE_LOG(LogTemp, Warning, TEXT("SecondHitInfo: TracedComponent:%s, bBlockingHit:%d, Distance:%f, PenetrationDepth:%f, ImpactPoint:%s"), *GetHitResCompName(OutHit), OutHit.bBlockingHit,
				OutHit.Distance, OutHit.PenetrationDepth, *OutHit.ImpactPoint.ToString());
#endif //UE_BUILD_DEVELOPMENT
			// 这里不用检查，因为OutStickGroundLoc = CheckLocation
			//if (MaxStickGroundLiftDist.IsSet()) {
			//	// 检查最多允许的抬升距离，超过这个距离视为贴地失败
			//	return MaxStickGroundLiftDist.GetValue() >= (OutStickGroundLoc.Z - CheckLocation.Z);
			//}
			return true;
		}
	}
	else if (bGroundIsLower)
	{
		// 胶囊体距离地面有一定距离的情况，直接向下贴地设置新位置
		OutStickGroundLoc = CheckLocation + FVector(0.0f, 0.0f, -MinDistance + UCharacterMovementComponent::MIN_FLOOR_DIST);
// #if UE_BUILD_DEVELOPMENT
		//UE_LOG(LogTemp, Log, TEXT("Character:%s StickGround Success! TracedComponent:%s, CurrentLocation:%s, StickGourndLoc:%s"), *GetName(), *TracedComponentName, *CurrentLocation.ToString(), *OutStickGroundLoc.ToString());
// #endif //UE_BUILD_DEVELOPMENT
		if (MaxStickGroundLiftDist.IsSet()) {
			// 检查最多允许的抬升距离，超过这个距离视为贴地失败
			return MaxStickGroundLiftDist.GetValue() >= (OutStickGroundLoc.Z - CheckLocation.Z);
		}
		return true;
	}

// #if UE_BUILD_DEVELOPMENT
	// UE_LOG(LogTemp, Warning, TEXT("Character:%s StickGround Failed! No TracedComponent Found!"), *GetName());
// #endif //UE_BUILD_DEVELOPMENT
	return false;
}

bool ABaseCharacter::CheckSimpleActorStickGround(FVector& OutStickGroundLoc, const FVector& CheckLocation, float CheckDistance, const ECollisionChannel& TraceChannel, float PawnHalfHeight, const FCollisionQueryParams& QueryParams, const FCollisionResponseParams& ResponseParam)
{
	FHitResult Hit;
	if (!GetWorld()->LineTraceSingleByChannel(Hit, CheckLocation + FVector(0.0f, 0.0f, PawnHalfHeight + FurtherLiftDist), CheckLocation + FVector(0.0f, 0.0f, -PawnHalfHeight - CheckDistance), TraceChannel, QueryParams, ResponseParam))
	{
// #if UE_BUILD_DEVELOPMENT
	// UE_LOG(LogTemp, Warning, TEXT("Character:%s SimpleStickGround Failed! No TracedComponent Found!"), *GetName());
// #endif //UE_BUILD_DEVELOPMENT
		return false;
	}

	if (Hit.bBlockingHit && Hit.Distance > SMALL_NUMBER)
	{
		OutStickGroundLoc = CheckLocation + FVector(0.0f, 0.0f, PawnHalfHeight + FurtherLiftDist - Hit.Distance + PawnHalfHeight + UCharacterMovementComponent::MIN_FLOOR_DIST);
		if (MaxStickGroundLiftDist.IsSet()) {
			// 检查最多允许的抬升距离，超过这个距离视为贴地失败
			return MaxStickGroundLiftDist.GetValue() >= (OutStickGroundLoc.Z - CheckLocation.Z);
		}
		return true;
	}
#if UE_BUILD_DEVELOPMENT
	UE_LOG(LogTemp, Warning, TEXT("Character:%s SimpleStickGround Failed! CharacterLoc:%s"), *GetName(), *CheckLocation.ToString());
	UE_LOG(LogTemp, Warning, TEXT("HitsInfo: TracedComponent:%s, bBlockingHit:%d, Distance:%f, PenetrationDepth:%f, ImpactPoint:%s"), *GetHitResCompName(Hit), Hit.bBlockingHit,
		Hit.Distance, Hit.PenetrationDepth, *Hit.ImpactPoint.ToString());
#endif //UE_BUILD_DEVELOPMENT
	return false;
}

bool ABaseCharacter::SimpleCheckCollisionBetweenMoveDelta2D(FVector& OutMoveDelta, const FVector& InMoveDelta)
{
	if (InMoveDelta.Size2D() <= 0.0f) {
		OutMoveDelta = InMoveDelta;
		return true;
	}

	if (CachedCollisionPresetName.IsNone()) {
		if (URoleMovementComponent* MoveComp = FindComponentByClass<URoleMovementComponent>()) {
			CachedCollisionPresetName = MoveComp->GetTrackFloorCollisionPresetName();
		}
		else {
			CachedCollisionPresetName = TEXT("Pawn");
		}
	}
	if (!CachedStickGroundCollisionProfile.IsSet())
	{
		FCollisionResponseTemplate TempCollisionResponseTemplate;
		if (!UCollisionProfile::Get()->GetProfileTemplate(CachedCollisionPresetName, TempCollisionResponseTemplate))
		{
			UE_LOG(LogTemp, Log, TEXT("Character:%s StickGround Failed! InValid CollisionPresetName:%s"), *GetName(), *CachedCollisionPresetName.ToString());
			return false;
		}
		CachedStickGroundCollisionProfile = TempCollisionResponseTemplate;
	}

	if (!CachedStickGroundQueryParams.IsSet())
	{
		CachedStickGroundQueryParams = FCollisionQueryParams(SCENE_QUERY_STAT(BaseCharacterStickGround), false, this);
		CachedStickGroundQueryParams.GetValue().bIgnoreTouches = true;
	}

	if (!CachedStickGroundCollisionResponseParams.IsSet()) {
		CachedStickGroundCollisionResponseParams = CachedStickGroundCollisionProfile.GetValue().ResponseToChannels;
	}
	if (!CachedStickGroundCollisionChannel.IsSet()) {
		CachedStickGroundCollisionChannel = CachedStickGroundCollisionProfile.GetValue().ObjectType;
	}

	float PawnRadius = 0.0f, PawnHalfHeight = 0.0f;
	GetCapsuleComponent()->GetScaledCapsuleSize(PawnRadius, PawnHalfHeight);

	float InMoveDeltaSize2D = InMoveDelta.Size2D();
	FVector RealMoveDelta2D = InMoveDelta.GetSafeNormal2D() * (InMoveDeltaSize2D + PawnRadius);

	FVector CurLoc = GetRootComponent()->GetComponentLocation();
	FHitResult Hit;
	if (!GetWorld()->LineTraceSingleByChannel(Hit, CurLoc, CurLoc + RealMoveDelta2D, CachedStickGroundCollisionChannel.GetValue(),
		CachedStickGroundQueryParams.GetValue(), CachedStickGroundCollisionResponseParams.GetValue()))
	{
		OutMoveDelta = InMoveDelta;
		return true;
	}

	if (Hit.bBlockingHit && Hit.Distance > SMALL_NUMBER)
	{
		OutMoveDelta = InMoveDelta.GetSafeNormal2D() * FMath::Min(InMoveDeltaSize2D, FMath::Max(0.0f, Hit.Distance - PawnRadius));
		OutMoveDelta.Z = InMoveDelta.Z;
		return true;
	}

	OutMoveDelta.X = 0.0f;
	OutMoveDelta.Y = 0.0f;
	return true;
}

#if UE_BUILD_DEVELOPMENT
FString ABaseCharacter::GetHitResCompName(FHitResult& InHitRes)
{
	FString OutHitResCompName = FString();

	if (IsValid(InHitRes.GetComponent()))
	{
		if (IsValid(InHitRes.GetComponent()->GetOwner()))
		{
#if WITH_EDITOR
			OutHitResCompName.Append(InHitRes.GetComponent()->GetOwner()->GetActorLabel() + TEXT("||") + InHitRes.GetComponent()->GetOwner()->GetName());
#else
			OutHitResCompName.Append(InHitRes.GetComponent()->GetOwner()->GetName());
#endif
			OutHitResCompName.Append(TEXT(":"));
		}
		OutHitResCompName.Append(InHitRes.GetComponent()->GetName());
	}
	else
	{
		OutHitResCompName = TEXT("Invalid Hit Component");
	}

	return OutHitResCompName;
}
#endif //UE_BUILD_DEVELOPMENT
#pragma endregion StickGround


#pragma region Effect
bool ABaseCharacter::CheckAnimStateCondition(const FAnimNotifyOnSurface& AnimNotifyOnSurface)
{
	if (AnimNotifyOnSurface.Key == EAnimState::Normal)
	{
		// 普通类型：不会被这个判定拦截
		return true;		
	}
	
	URoleMovementComponent* RMComponent = Cast<URoleMovementComponent>(GetComponentByClass(URoleMovementComponent::StaticClass()));
	if (RMComponent == nullptr)
	{
		return false;
	}

	auto bDepthChecker = RMComponent->GetIsInWater() && (AnimNotifyOnSurface.CheckDepth <= 0 || RMComponent->GetCurWaterDepth() <= AnimNotifyOnSurface.CheckDepth);
	if (AnimNotifyOnSurface.Key == EAnimState::InWater)
	{
		// 水花：浅水正常播，超过一定深度不播
		return bDepthChecker;
	}
	
	if (AnimNotifyOnSurface.Key == EAnimState::FootPrint)
	{
		// 脚印：地面/浅水正常播，超过一定深度不播
		return RMComponent->GetNeedFootStepNotify() && (!RMComponent->GetIsInWater() || bDepthChecker);
	}
	
	if (AnimNotifyOnSurface.Key != EAnimState::FootPrint)
	{
		// 脚印, 按照CD间隔播放
		if (UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(this))
		{
			const FName NiagaraPath = *AnimNotifyOnSurface.Value.TemplatePath.ToString();
			float CdTimeSeconds;
			if (EffectManager->GetSurfaceCdInfo(NiagaraPath, CdTimeSeconds))
			{
				double CurrentTimeSeconds = FPlatformTime::Seconds();
				if (!SurfaceEffectCdMap.Contains(NiagaraPath) || SurfaceEffectCdMap[NiagaraPath] < CurrentTimeSeconds)
				{
					SurfaceEffectCdMap.Add(NiagaraPath, CurrentTimeSeconds + CdTimeSeconds);
					return true;
				}

				return false;
			}
		}
		else
		{
			UE_LOG(LogTemp, Error, TEXT("ABaseCharacter::CheckAnimStateCondition, invalid effect manager"));
		}
	}
	
	return false;
}

int32 ABaseCharacter::SpawnSurfaceEffect(const FAnimNotifyOnSurface& AnimNotifyOnSurface, USkeletalMeshComponent* MeshComp)
{
	if (!CheckAnimStateCondition(AnimNotifyOnSurface))
	{
		return 0;
	}
	
	if (!MeshComp)
	{
		UE_LOG(LogTemp, Warning, TEXT("ABaseCharacter::SpawnSurfaceEffect, invalid mesh component"));
		return 0;
	}

	UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(this);
	if (!EffectManager)
	{
		UE_LOG(LogTemp, Warning, TEXT("ABaseCharacter::SpawnSurfaceEffect, invalid effect manager"));
		return 0;
	}
	
	FKGPlayNiagaraParams PlayNiagaraParams;
	PlayNiagaraParams.NiagaraEffectPath = AnimNotifyOnSurface.Value.TemplatePath.ToString();
	PlayNiagaraParams.TotalLifeMs = AnimNotifyOnSurface.Value.TotalLifeSeconds > 0 ? AnimNotifyOnSurface.Value.TotalLifeSeconds * 1000 : -1;
	PlayNiagaraParams.SpawnerID = KGUtils::GetIDByObject(this);
	PlayNiagaraParams.StickGroundType = AnimNotifyOnSurface.Value.bNeedCheckGround ? EKGNiagaraStickGroundType::StickToWaterSurface : EKGNiagaraStickGroundType::DoNotStickToGround;
	if (!AnimNotifyOnSurface.Value.bNeedAttach)
	{
		FKGUnattachedNiagaraSpawnInfo UnattachedSpawnInfo;
		UnattachedSpawnInfo.SearchSpawnLocationType = EKGNiagaraSearchSpawnLocationType::UseCustomSpawnTrans;
		UnattachedSpawnInfo.WorldOrRelativeTrans = AnimNotifyOnSurface.Value.Transform * MeshComp->GetSocketTransform(AnimNotifyOnSurface.Value.SocketName, RTS_World);
		PlayNiagaraParams.SetUnattachedSpawnInfo(UnattachedSpawnInfo);
	}
	else
	{
		FKGAttachedNiagaraSpawnInfo AttachedSpawnInfo;
		AttachedSpawnInfo.RelativeTrans = AnimNotifyOnSurface.Value.Transform;
		AttachedSpawnInfo.SearchAttachComponentType = EKGNiagaraSearchAttachComponentType::UseCustomAttachComponent;
		AttachedSpawnInfo.CustomAttachComponent = MeshComp;
		AttachedSpawnInfo.AttachPointName = AnimNotifyOnSurface.Value.SocketName;
		AttachedSpawnInfo.bAbsoluteRotation = AnimNotifyOnSurface.Value.bAbsoluteRotation;
		AttachedSpawnInfo.bAbsoluteScale = AnimNotifyOnSurface.Value.bAbsoluteScale;
		PlayNiagaraParams.SetAttachedSpawnInfo(AttachedSpawnInfo);
	}
	
	if (AnimNotifyOnSurface.Key == EAnimState::FootPrint)
	{
		if (CurrentLeftFootEffectPath.IsEmpty() && CurrentRightFootEffectPath.IsEmpty())
		{
			UE_LOG(LogTemp, Warning, TEXT("ABaseCharacter::SpawnSurfaceEffect, FootPrint Effect Path is Empty"));
			return 0;
		}

		if (AnimNotifyOnSurface.Value.bIsRightSide)
		{
			PlayNiagaraParams.NiagaraEffectPath = CurrentRightFootEffectPath;
		}
		else
		{
			PlayNiagaraParams.NiagaraEffectPath = CurrentLeftFootEffectPath;
		}
	}

	return EffectManager->CreateNiagaraSystem(PlayNiagaraParams);
}

#pragma endregion Effect


#pragma region AnimNotify
bool ABaseCharacter::DoLocoDisableFromAnimNotify(int64 NotifyUniqueID, bool bDisableAllMove, bool bDisableLocoMove, bool bDisableLocoStart, bool bForceLocoStart,
	bool bDisableLocoJump, bool bDisableLocoDodge, bool bForceLocoGroundSupport, bool bForceIgnoreLocoGroundSupport)
{
	if (URoleMovementComponent* RoleMoveComp = Cast<URoleMovementComponent>(GetMovementComponent()))
	{
		URoleMovementComponent* MovementControlViewProxy = RoleMoveComp->GetRealMovementControlViewProxy();
		if (!MovementControlViewProxy->GetEnableLocoContol())
		{
			// 没有开启LocoContol，不允许执行C7LocoDisable
			return true;
		}

		if (NotifyUniqueIDToC7LocoDisableRMCMap.Contains(NotifyUniqueID))
		{
			// 重复进入，返回false异常，由NotifyState抛出异常日志信息
			return false;
		}
		else
		{
			NotifyUniqueIDToC7LocoDisableRMCMap.Add(NotifyUniqueID, TWeakObjectPtr<URoleMovementComponent>(MovementControlViewProxy));
		}

		if (bDisableLocoStart)
		{
			MovementControlViewProxy->SetDisableLocoStartForceValue(true, TEXT("LocoDisableAnimNotify"));
		}
		else if (bForceLocoStart)
		{
			MovementControlViewProxy->SetForceLocoStartToTrue();
		}

		if (bDisableAllMove)
		{
			MovementControlViewProxy->SetDisableMoveAllForceValue(true, TEXT("LocoDisableAnimNotify"));
		}
		if (bDisableLocoMove)
		{
			MovementControlViewProxy->SetDisableLocoMoveForceValue(true, TEXT("LocoDisableAnimNotify"));
		}
		if (bDisableLocoJump)
		{
			MovementControlViewProxy->SetDisableLocoJumpForceValue(true, TEXT("LocoDisableAnimNotify"), true);
		}
		if (bDisableLocoDodge)
		{
			MovementControlViewProxy->SetDisableLocoDodgeForceValue(true, TEXT("LocoDisableAnimNotify"), true);
		}

		if ((bDisableLocoStart || bDisableLocoMove) && !bForceLocoStart)
		{
			MovementControlViewProxy->ClearForceLocoStart();
		}

		if (bForceLocoGroundSupport || bForceIgnoreLocoGroundSupport)
		{
			int32 GroundSupportControlToken = MovementControlViewProxy->SetGroundSupportFromAnimNotify(bForceLocoGroundSupport, bForceIgnoreLocoGroundSupport);
			if (GroundSupportControlToken > 0)
			{
				if (NotifyUniqueIDToGroundSupportControlTokenMap.Contains(NotifyUniqueID))
				{
					UE_LOG(LogTemp, Warning, TEXT("[DoLocoDisableFromAnimNotify] Replicated GroundSupportControl!%s"), *GetName());
					NotifyUniqueIDToGroundSupportControlTokenMap[NotifyUniqueID] = GroundSupportControlToken;
				}
				else
				{
					NotifyUniqueIDToGroundSupportControlTokenMap.Add(NotifyUniqueID, GroundSupportControlToken);
				}
			}
			/*UE_LOG(LogTemp, Warning, TEXT("[szk]C7LocoDisable NotifyBegin, Token:%i, Force:%d, ForceIgnore:%d!"),
				GroundSupportControlToken, bForceLocoGroundSupport, bForceIgnoreLocoGroundSupport);*/
		}
	}

	return true;
}

bool ABaseCharacter::UnDoLocoDisableFromAnimNotify(int64 NotifyUniqueID, bool bDisableAllMove, bool bDisableLocoMove, bool bDisableLocoStart, bool bForceLocoStart,
	bool bDisableLocoJump, bool bDisableLocoDodge, bool bForceLocoGroundSupport, bool bForceIgnoreLocoGroundSupport)
{
	if (!NotifyUniqueIDToC7LocoDisableRMCMap.Contains(NotifyUniqueID))
	{
		return true;
	}

	if (!NotifyUniqueIDToC7LocoDisableRMCMap.Find(NotifyUniqueID)->IsValid())
	{
		NotifyUniqueIDToC7LocoDisableRMCMap.Remove(NotifyUniqueID);
		if (NotifyUniqueIDToGroundSupportControlTokenMap.Contains(NotifyUniqueID))
		{
			NotifyUniqueIDToGroundSupportControlTokenMap.Remove(NotifyUniqueID);
		}
		return true;
	}

	URoleMovementComponent* MovementControlViewProxy = NotifyUniqueIDToC7LocoDisableRMCMap.Find(NotifyUniqueID)->Get();
	NotifyUniqueIDToC7LocoDisableRMCMap.Remove(NotifyUniqueID);
	if (bDisableLocoStart)
	{
		MovementControlViewProxy->ClearDisableLocoStartForceValue(TEXT("LocoDisableAnimNotify"));
	}
	else if (bForceLocoStart)
	{
		MovementControlViewProxy->ClearForceLocoStart();
	}

	if (bDisableAllMove)
	{
		MovementControlViewProxy->ClearDisableMoveAllForceValue(TEXT("LocoDisableAnimNotify"));
	}
	if (bDisableLocoMove)
	{
		MovementControlViewProxy->ClearDisableLocoMoveForceValue(TEXT("LocoDisableAnimNotify"));
	}

	if (bDisableLocoJump)
	{
		MovementControlViewProxy->ClearDisableLocoJumpForceValue(TEXT("LocoDisableAnimNotify"), true);
	}
	if (bDisableLocoDodge)
	{
		MovementControlViewProxy->ClearDisableLocoDodgeForceValue(TEXT("LocoDisableAnimNotify"), true);
	}

	if (NotifyUniqueIDToGroundSupportControlTokenMap.Contains(NotifyUniqueID))
	{
		int32 GroundSupportControlToken = *NotifyUniqueIDToGroundSupportControlTokenMap.Find(NotifyUniqueID);
		if (GroundSupportControlToken > 0)
		{
			MovementControlViewProxy->ClearGroundSupportFromAnimNotify(GroundSupportControlToken);
		}
		NotifyUniqueIDToGroundSupportControlTokenMap.Remove(NotifyUniqueID);
	}

	return true;
}

bool ABaseCharacter::SaveMotionWarpMCTokenForAnimNotify(int64 NotifyUniqueID, int InToken)
{
	if (NotifyUniqueIDToMotionWarpMCTokenMap.Contains(NotifyUniqueID))
	{
		// 重复进入，返回false异常，由NotifyState抛出异常日志信息
		NotifyUniqueIDToMotionWarpMCTokenMap[NotifyUniqueID] = InToken;
		return false;
	}
	else
	{
		NotifyUniqueIDToMotionWarpMCTokenMap.Add(NotifyUniqueID, InToken);
	}

	return true;
}

int ABaseCharacter::GetAndClearMotionWarpMCTokenForAnimNotify(int64 NotifyUniqueID)
{
	if (NotifyUniqueIDToMotionWarpMCTokenMap.Contains(NotifyUniqueID))
	{
		int32 OutToken = NotifyUniqueIDToMotionWarpMCTokenMap[NotifyUniqueID];
		NotifyUniqueIDToMotionWarpMCTokenMap.Remove(NotifyUniqueID);
		return OutToken;
	}
	return -1;
}

bool ABaseCharacter::SaveC7VelocityStableRMCForAnimNotify(int64 NotifyUniqueID, class URoleMovementComponent* InRMC)
{
	if (NotifyUniqueIDToC7VelocityStableRMCMap.Contains(NotifyUniqueID))
	{
		// 重复进入，返回false异常，由NotifyState抛出异常日志信息
		NotifyUniqueIDToC7VelocityStableRMCMap[NotifyUniqueID] = InRMC;
		return false;
	}
	else
	{
		NotifyUniqueIDToC7VelocityStableRMCMap.Add(NotifyUniqueID, TWeakObjectPtr<URoleMovementComponent>(InRMC));
	}

	return true;
}

URoleMovementComponent* ABaseCharacter::GetAndClearC7VelocityStableRMCForAnimNotify(int64 NotifyUniqueID)
{
	URoleMovementComponent* OutRMC = nullptr;
	if (NotifyUniqueIDToC7VelocityStableRMCMap.Contains(NotifyUniqueID))
	{
		if (NotifyUniqueIDToC7VelocityStableRMCMap[NotifyUniqueID].IsValid())
		{
			OutRMC = NotifyUniqueIDToC7VelocityStableRMCMap[NotifyUniqueID].Get();
		}
		NotifyUniqueIDToC7VelocityStableRMCMap.Remove(NotifyUniqueID);
	}
	return OutRMC;
}

bool ABaseCharacter::SaveBikeShakeAkEventRMCForAnimNotify(int64 NotifyUniqueID, class URoleMovementComponent* InRMC)
{
	if (NotifyUniqueIDToBikeShakeAkEventRMCMap.Contains(NotifyUniqueID))
	{
		// 重复进入，返回false异常，由NotifyState抛出异常日志信息
		NotifyUniqueIDToBikeShakeAkEventRMCMap[NotifyUniqueID] = InRMC;
		return false;
	}
	else
	{
		NotifyUniqueIDToBikeShakeAkEventRMCMap.Add(NotifyUniqueID, TWeakObjectPtr<URoleMovementComponent>(InRMC));
	}

	return true;
}

URoleMovementComponent* ABaseCharacter::GetBikeShakeAkEventRMCForAnimNotify(int64 NotifyUniqueID)
{
	URoleMovementComponent* OutRMC = nullptr;
	if (NotifyUniqueIDToBikeShakeAkEventRMCMap.Contains(NotifyUniqueID))
	{
		if (NotifyUniqueIDToBikeShakeAkEventRMCMap[NotifyUniqueID].IsValid())
		{
			OutRMC = NotifyUniqueIDToBikeShakeAkEventRMCMap[NotifyUniqueID].Get();
		}
	}
	return OutRMC;
}

void ABaseCharacter::ClearBikeShakeAkEventRMCForAnimNotify(int64 NotifyUniqueID)
{
	if (NotifyUniqueIDToBikeShakeAkEventRMCMap.Contains(NotifyUniqueID))
	{
		NotifyUniqueIDToBikeShakeAkEventRMCMap.Remove(NotifyUniqueID);
	}
}

void ABaseCharacter::SaveLastPitchValueForAnimNotify(int64 NotifyUniqueID, float InLastPitchValue)
{
	if (NotifyUniqueIDToLastPitchValueMap.Contains(NotifyUniqueID))
	{
		NotifyUniqueIDToLastPitchValueMap[NotifyUniqueID] = InLastPitchValue;
	}
	else
	{
		NotifyUniqueIDToLastPitchValueMap.Add(NotifyUniqueID, InLastPitchValue);
	}
}

float ABaseCharacter::GetLastPitchValueForAnimNotify(int64 NotifyUniqueID)
{
	if (NotifyUniqueIDToLastPitchValueMap.Contains(NotifyUniqueID))
	{
		return NotifyUniqueIDToLastPitchValueMap[NotifyUniqueID];
	}
	return 0.0f;
}

void ABaseCharacter::ClearLastPitchValueForAnimNotify(int64 NotifyUniqueID)
{
	if (NotifyUniqueIDToLastPitchValueMap.Contains(NotifyUniqueID))
	{
		NotifyUniqueIDToLastPitchValueMap.Remove(NotifyUniqueID);
	}
}

void ABaseCharacter::SaveCurTriggerEventCoolDownForAnimNotify(int64 NotifyUniqueID, float InCurTriggerEventCoolDown)
{
	if (NotifyUniqueIDToCurTriggerEventCoolDownMap.Contains(NotifyUniqueID))
	{
		NotifyUniqueIDToCurTriggerEventCoolDownMap[NotifyUniqueID] = InCurTriggerEventCoolDown;
	}
	else
	{
		NotifyUniqueIDToCurTriggerEventCoolDownMap.Add(NotifyUniqueID, InCurTriggerEventCoolDown);
	}
}

float ABaseCharacter::GetCurTriggerEventCoolDownForAnimNotify(int64 NotifyUniqueID)
{
	if (NotifyUniqueIDToCurTriggerEventCoolDownMap.Contains(NotifyUniqueID))
	{
		return NotifyUniqueIDToCurTriggerEventCoolDownMap[NotifyUniqueID];
	}
	return 0.0f;
}

void ABaseCharacter::ClearCurTriggerEventCoolDownForAnimNotify(int64 NotifyUniqueID)
{
	if (NotifyUniqueIDToCurTriggerEventCoolDownMap.Contains(NotifyUniqueID))
	{
		NotifyUniqueIDToCurTriggerEventCoolDownMap.Remove(NotifyUniqueID);
	}
}

void ABaseCharacter::InitHistoryDeltaPitchListForAnimNotify(int64 NotifyUniqueID)
{
	if (NotifyUniqueIDToHistoryDeltaPitchListMap.Contains(NotifyUniqueID))
	{
		NotifyUniqueIDToHistoryDeltaPitchListMap[NotifyUniqueID].Empty();
	}
	else
	{
		NotifyUniqueIDToHistoryDeltaPitchListMap.Add(NotifyUniqueID, TArray<float>());
	}
}

TArray<float>* ABaseCharacter::GetHistoryDeltaPitchListForAnimNotify(int64 NotifyUniqueID)
{
	if (NotifyUniqueIDToHistoryDeltaPitchListMap.Contains(NotifyUniqueID))
	{
		return NotifyUniqueIDToHistoryDeltaPitchListMap.Find(NotifyUniqueID);
	}
	return nullptr;
}

void ABaseCharacter::ClearHistoryDeltaPitchListForAnimNotify(int64 NotifyUniqueID)
{
	if (NotifyUniqueIDToHistoryDeltaPitchListMap.Contains(NotifyUniqueID))
	{
		NotifyUniqueIDToHistoryDeltaPitchListMap.Remove(NotifyUniqueID);
	}
}
#pragma endregion AnimNotify


#pragma region GhostCloneCache

void ABaseCharacter::SetGhostCloneCacheCapacity(uint8 InCapacity)
{
	if(InCapacity<=0)
	{
		InCapacity = 1;
	}
	GhostCloneCacheCapacity = InCapacity;
}

AActor* ABaseCharacter::GetGhostCloneCache(int32 InAppearanceChangeCount)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("ABaseCharacter::GetGhostCloneCache");
	if(GhostCloneCache.Num()>0)
	{
		auto GhostClone = GhostCloneCache.Pop();
		if(!IsValid(GhostClone))
		{
			return nullptr;
		}
		
		ABaseCharacter* Character = Cast<ABaseCharacter>(GhostClone);
		if (Character && Character->GetAppearanceChangeCount() != InAppearanceChangeCount)
		{
			if (UWorld* World = GhostClone->GetWorld())
			{
				World->DestroyActor(GhostClone);
			}
			return nullptr;
		}
		
		return GhostClone;
	}
	
	return nullptr;
}

bool ABaseCharacter::AddGhostCloneCache(AActor* InActor, int32 InAppearanceChangeCount)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("ABaseCharacter::AddGhostCloneCache");
	while(GhostCloneCache.Num() >= GhostCloneCacheCapacity)
	{
		auto GhostClone = GhostCloneCache.Pop();
		if(!IsValid(GhostClone))
		{
			continue;
		}
		
		if (UWorld* World = GhostClone->GetWorld())
		{
			World->DestroyActor(GhostClone);
		}
	}
	if(GhostCloneCache.Num()<GhostCloneCacheCapacity)
	{
		ABaseCharacter* Character = Cast<ABaseCharacter>(InActor);
		if (Character)
		{
			Character->SetAppearanceChangeCount(InAppearanceChangeCount);
		}
		GhostCloneCache.Add(InActor);
		return true;
	}
	return false;
}

void ABaseCharacter::ClearGhostCloneCache()
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("ABaseCharacter::ClearGhostCloneCache");
	for(auto GhostClone:GhostCloneCache)
	{
		if(!IsValid(GhostClone))
		{
			continue;
		}
		
		if (UWorld* World = GhostClone->GetWorld())
		{
			World->DestroyActor(GhostClone);
		}
	}
	
	GhostCloneCache.Empty();
}
	
#pragma endregion


#pragma region BlobShadow

void ABaseCharacter::EnableBlobShadow(bool Enable)
{
	if(!IsValid(BlobShadowComponent))
	{
		return;
	}
	
	IsEnableBlobShadow = Enable;
	BlobShadowComponent->SetHiddenInGame(!Enable);
	if(Enable)
	{
		BlobShadowComponent->SetMobility(EComponentMobility::Movable);
	}
}

void ABaseCharacter::TickBlobShadow(float DeltaSeconds)
{
	if(!IsEnableBlobShadow)
	{
		return;
	}
	if(IsValid(BlobShadowComponent))
	{
		BlobShadowComponent->SetWorldLocation(GetActorLocation());
	}
}
	
#pragma endregion