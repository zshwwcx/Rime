#include "3C/SyncProtocol/HeartbeatManager.h"
#include "3C/SyncProtocol/SyncProtocol.h"
#include "Misc/LowLevelFunctions.h"
#include "Kismet/GameplayStatics.h"
#include "3C/Character/BaseCharacter.h"
#include "GameFramework/Character.h"
#include "Misc/KGGameInstanceBase.h"
#include "DoraSDK.h"
#include "Engine/World.h"

void FHeartbeatManager::TrySendHeartbeat(UWorld* World)
{
	int64 Now = GetLocalTime();
	if (Now - LastSendTime < SendHeartbeatInterval)
	{
		return;
	}
	LastSendTime = Now;

	ACharacter* MainPlayer = UGameplayStatics::GetPlayerCharacter(World, 0);
	if (!MainPlayer)
	{
		return;
	}
	ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(MainPlayer);
	if (!BaseCharacter)
	{
		UE_LOG(LogTemp, Error, TEXT("HeartbeatManager::TrySendHeartbeat cast to ABaseCharacter failed"));
		return;
	}
	int64 EntityId = BaseCharacter->GetEntityUID();

	SendBuffer.Clear();
	SendBuffer.PutUint8((uint8)NetChannelDataProtocol::Heartbeat);
	SendBuffer.PutInt64(Now);
	SendBuffer.PutInt64(EntityId);

	UDoraSDK::SendSceneMessage((uint64)EntityId, SendBuffer.GetDataBegin(), SendBuffer.GetWritten());
}

int64 FHeartbeatManager::GetLocalTime()
{
	return ULowLevelFunctions::GetUtcMillisecond();
}

void FHeartbeatManager::OnRecvResponse(int64 ClientTimestamp, int64 ServerTimestamp)
{
	int64 Now = GetLocalTime();
	CurrentRttHalf = (Now - ClientTimestamp) / 2.0f;
	CalculateDelay(ServerTimestamp, CurrentRttHalf, Now);
	//UE_LOG(LogTemp, Log, TEXT("HeartbeatManager::OnRecvResponse CurrentRttHalf[%f], SHRtt[%f], C2STimeDiff[%lld]"), CurrentRttHalf, SHRtt, C2STimeDiff);
}

void FHeartbeatManager::CalculateDelay(int64 RemoteTimestamp, float HalfRtt, int64 Now)
{
	if (SHRtt < 0)
	{
		SHRtt = HalfRtt;
		RttVar = 0.0f;
	}
	else if (!IsValidRtt(HalfRtt))
	{
		return;
	}
	else
	{
		RttVar = (1 - Beta) * RttVar + Beta * std::abs(SHRtt - HalfRtt);
		SHRtt = Alpha * HalfRtt + (1 - Alpha) * SHRtt;
	}
	C2STimeDiff = static_cast<int64>(RemoteTimestamp - Now + SHRtt);
}

bool FHeartbeatManager::IsValidRtt(float HalfRtt)
{
	if (HalfRtt < 0 || SHRtt < 0)
	{
		return false;
	}

	if (HalfRtt > SHRtt * FilterScale)
	{
		if (FilterCount <= FilterMax)
		{
			FilterCount++;
			return false;
		}
	}
	FilterCount = 0;
	return true;
}

void FHeartbeatManager::ResetServerTime(int64 RemoteTimestamp)
{
	SHRtt = -1.0f;
	int64 Now = GetLocalTime();
	CalculateDelay(RemoteTimestamp, 0.0f, Now);
}

int64 FHeartbeatManager::GetServerTimestamp()
{
	int64 Now = GetLocalTime();
	if (C2STimeDiff <= INVALID_TIMESTAMP_DIFF)
	{
		return Now;
	}
	return Now + C2STimeDiff;
}