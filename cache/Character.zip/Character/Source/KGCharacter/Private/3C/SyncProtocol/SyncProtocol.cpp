#include "3C/SyncProtocol/SyncProtocol.h"
#include "3C/Util/BinaryUtil.h"

void PackClientMoveMsg(WriteBuffer* Buffer, int32 SyncTimestamp, FVector Position, double Yaw, FVector Velocity, float MoveTime, uint8 LocomotionState, bool bJumping)
{
	Buffer->Clear();
	Buffer->PutUint8((uint8)NetChannelDataProtocol::ClientSyncMovement);
	Buffer->PutInt32(SyncTimestamp);
	Buffer->PutFVector32(Position); // TODO: 可以进一步压缩，每一位用3字节表示
	Buffer->PutInt16((int16)Yaw);
	Buffer->PutFVector32(Velocity); // TODO: 可以进一步压缩，每一位用2字节表示
	Buffer->PutInt16((int16)(MoveTime * 1000.0f));
	Buffer->PutUint8(LocomotionState);
	Buffer->PutUint8((uint8)bJumping); // TODO: 先跑通流程，验证效果，之后可以再优化协议
}

void PackHandshakeMsg(WriteBuffer* Buffer, int32 SpaceId)
{
	Buffer->Clear();
	Buffer->PutUint8((uint8)NetChannelDataProtocol::Handshake);
	Buffer->PutUint8(MovementHandshakeProtocol::Request);
	Buffer->PutInt32(SpaceId);
}

void PackRotateInstantlyMsg(WriteBuffer* Buffer, uint64 EntityId, int32 SyncTimestamp, double Yaw)
{
	Buffer->Clear();
	Buffer->PutUint8((uint8)NetChannelDataProtocol::RotateInstantly);
	Buffer->PutUint64(EntityId);
	Buffer->PutUint32(0); // Sequence
	Buffer->PutInt32(SyncTimestamp);
	Buffer->PutInt16((int16)Yaw);
	Buffer->PutUint8(0); // Flags
}

MovementData UnpackClientMoveMsg(ReadBuffer* Buffer)
{
	MovementData Data;
	Data.Protocol = NetChannelDataProtocol::ClientSyncMovement;
	Data.Timestamp = Buffer->ReadInt32();
	Buffer->ReadFVector32(&Data.Transform.Position);
	Data.Transform.Rotation.Yaw = Buffer->ReadInt16();
	Buffer->ReadFVector32(&Data.Transform.Velocity);
	Data.MoveTime = Buffer->ReadInt16();
	Data.LocomotionState = Buffer->ReadUint8();
	Data.Flags = Buffer->ReadUint8();
	if (Data.Flags & MovementSyncFlag::Extension)
	{
		Data.Flags |= (uint16)((uint16)Buffer->ReadUint8() << 8);
	}
	// 下面的解包顺序不能随便改，需要和服务端打包顺序一致
	if (Data.Flags & MovementSyncFlag::Riding)
	{
		Data.MountPitch = Buffer->ReadInt16();
		Data.MountRoll = Buffer->ReadInt16();
		Data.MountRootOffset = Buffer->ReadInt16();
	}
	if (Data.Flags & MovementSyncFlag::Relative)
	{
		Buffer->ReadFVector32(&Data.RelativeTranform.Position);
		Data.RelativeTranform.Rotation.Yaw = Buffer->ReadInt16();
		Buffer->ReadFVector32(&Data.RelativeTranform.Velocity);
	}
	if (Data.Flags & MovementSyncFlag::GravityScale)
	{
		Data.GravityScale = (float)Buffer->ReadInt16() / 100.0f;
	}
	else
	{
		Data.GravityScale = 0.0f; // 代表使用默认重力
	}
	if (Data.Flags & MovementSyncFlag::ControlEntity)
	{
		Data.ControlEntityId = Buffer->ReadUint64();
	}
	return Data;
}

MovementData UnpackServerMoveMsg(ReadBuffer* Buffer)
{
	MovementData Data;
	Data.Protocol = NetChannelDataProtocol::ServerSyncMovement;
	Data.Timestamp = Buffer->ReadInt32();
	Buffer->ReadFVector32(&Data.Transform.Position);
	Data.Transform.Rotation.Yaw = Buffer->ReadInt16();
	Buffer->ReadFVector32(&Data.Transform.Velocity);
	Data.MoveTime = Buffer->ReadInt16();
	Data.Flags = Buffer->ReadUint8();
	if (Data.Flags & MovementSyncFlag::Extension)
	{
		Data.Flags |= (uint16)((uint16)Buffer->ReadUint8() << 8);
	}
	if (Data.Flags & MovementSyncFlag::Use3DRotation)
	{
		Data.Transform.Rotation.Pitch = Buffer->ReadInt16();
		Data.Transform.Rotation.Roll = Buffer->ReadInt16();
	}
	Data.bHasTargetDirection = Data.Flags & MovementSyncFlag::TargetDirection;
	if (Data.bHasTargetDirection)
	{
		Data.TargetDirection = Buffer->ReadInt16();
	}
	if (Data.Flags & MovementSyncFlag::ServerLocoState)
	{
		Data.LocomotionState = Buffer->ReadUint8();
	}
	else
	{
		Data.LocomotionState = 0;
	}
	return Data;
}

MovementData UnpackServerBriefMoveMsg(ReadBuffer* Buffer)
{
	MovementData Data;
	Data.Protocol = NetChannelDataProtocol::ServerSyncBriefMovement;
	Data.Timestamp = Buffer->ReadInt32();
	Buffer->ReadFVector32(&Data.Transform.Position);
	Data.Transform.Rotation.Yaw = 0;
	Data.Transform.Velocity = FVector::Zero();
	Data.MoveTime = 0;
	Data.LocomotionState = 0;
	Data.Flags = 0;
	return Data;
}

MovementData UnpackFixedPathMoveMsg(ReadBuffer* Buffer)
{
	MovementData Data;
	Data.Protocol = NetChannelDataProtocol::FixedPathSyncMovement;
	Data.Timestamp = Buffer->ReadInt32();
	Data.FixedPath.PathId = Buffer->ReadUint32();
	Data.FixedPath.Frame = Buffer->ReadUint16();
	Data.FixedPath.Flag = Buffer->ReadUint8();
	Data.FixedPath.Speed = Buffer->ReadInt16();
	return Data;
}

LocomotionStateMsg UnpackLocomotionStateMsg(ReadBuffer* Buffer)
{
	LocomotionStateMsg Msg;
	Msg.State = Buffer->ReadUint8();
	Msg.MoveType = Buffer->ReadUint8();
	return Msg;
}

HeartbeatResponseMsg UnpackHeartbeatResponseMsg(ReadBuffer* Buffer)
{
	HeartbeatResponseMsg Msg;
	Msg.ClientTimestamp = Buffer->ReadInt64();
	Msg.ServerTimestamp = Buffer->ReadInt64();
	Msg.EntityId = Buffer->ReadInt64();
	return Msg;
}

TeleportMsg UnpackTeleportMsg(ReadBuffer* Buffer)
{
	TeleportMsg Msg;
	Msg.EntityId = Buffer->ReadUint64();
	Msg.Sequence = Buffer->ReadUint32();
	Buffer->ReadFVector32(&Msg.Position);
	Msg.Yaw = Buffer->ReadInt16();
	Msg.Type = Buffer->ReadUint8();
	Msg.NeedAck = Buffer->ReadUint8() != 0;
	Msg.ConfigId = Buffer->ReadUint32();
	return Msg;
}

TeleportToTargetMsg UnpackTeleportToTargetMsg(ReadBuffer* Buffer)
{
	TeleportToTargetMsg Msg;
	Msg.EntityId = Buffer->ReadUint64();
	Msg.Sequence = Buffer->ReadUint32();
	Msg.TargetId = Buffer->ReadUint64();
	Buffer->ReadFVector32(&Msg.RelativePosition);
	Msg.RelativeYaw = Buffer->ReadInt16();
	Msg.Type = Buffer->ReadUint8();
	Msg.NeedAck = Buffer->ReadUint8() != 0;
	Msg.ConfigId = Buffer->ReadUint32();
	return Msg;
}

RotateInstantlyMsg UnpackRotateInstantlyMsg(ReadBuffer* Buffer)
{
	RotateInstantlyMsg Msg;
	Msg.EntityId = Buffer->ReadUint64();
	Msg.Sequence = Buffer->ReadUint32();
	Msg.Timestamp = Buffer->ReadInt32();
	Msg.Rotation.Yaw = Buffer->ReadInt16();
	uint8 Flags = Buffer->ReadUint8();
	Msg.NeedAck = (Flags & 1) != 0;
	Msg.FromServer = (Flags & (1 << 1)) != 0;
	return Msg;
}

HandshakeMsg UnpackHandshakeMsg(ReadBuffer* Buffer)
{
	HandshakeMsg Msg;
	Msg.Protocol = Buffer->ReadUint8();
	Msg.SpaceId = Buffer->ReadInt32();
	return Msg;
}