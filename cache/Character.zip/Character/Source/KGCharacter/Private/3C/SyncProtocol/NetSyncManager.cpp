#include "3C/SyncProtocol/NetSyncManager.h"
#include "3C/Util/BinaryUtil.h"
#include "DoraSDK.h"
#include "Engine/Engine.h"
#include "Engine/GameViewportClient.h"
#include "3C/Core/KGUEActorManager.h"

void UNetSyncManager::DispatchSceneMessage(uint64_t EntityId, const char* Data, size_t Len)
{
	if (Len == 0)
	{
		return;
	}
	uint8 Protocol = Data[0];

	UWorld* World = GEngine->GameViewport->GetWorld();
	if (!World)
	{
		UE_LOG(LogTemp, Error, TEXT("UNetSyncManager::DispatchSceneMessage GetCurrentPlayWorld failed, EntityId[%llu], Protocol[%u], Len[%zu]"), EntityId, Protocol, Len);
		return;
	}
	auto ActorManager = UKGUEActorManager::GetInstance(World);
	if (!ActorManager)
	{
		UE_LOG(LogTemp, Error, TEXT("UNetSyncManager::DispatchSceneMessage get UKGUEActorManager failed, EntityId[%lld]"), EntityId);
		return;
	}
	auto Entity = ActorManager->GetLuaEntity(EntityId);
	if (!Entity)
	{
		UE_LOG(LogTemp, Warning, TEXT("UNetSyncManager::DispatchSceneMessage get Entity failed, EntityId[%lld], Protocol[%u]"), EntityId, Protocol);
		return;
	}
	Entity->HandleSyncMessage(Data, Len);
}

void UNetSyncManager::DispatchSceneProp(uint64_t EntityId, const void* MpObj)
{
	UWorld* World = GEngine->GameViewport->GetWorld();
	if (!World)
	{
		UE_LOG(LogTemp, Error, TEXT("UNetSyncManager::DispatchSceneProp GetCurrentPlayWorld failed, EntityId[%llu]"), EntityId);
		return;
	}
	auto ActorManager = UKGUEActorManager::GetInstance(World);
	if (!ActorManager)
	{
		UE_LOG(LogTemp, Error, TEXT("UNetSyncManager::DispatchSceneProp get UKGUEActorManager failed, EntityId[%lld]"), EntityId);
		return;
	}
	auto Entity = ActorManager->GetLuaEntity(EntityId);
	if (!Entity)
	{
		UE_LOG(LogTemp, Warning, TEXT("UNetSyncManager::DispatchSceneProp get Entity failed, EntityId[%lld]"), EntityId);
		return;
	}
	Entity->HandleSyncProp(MpObj);
}

