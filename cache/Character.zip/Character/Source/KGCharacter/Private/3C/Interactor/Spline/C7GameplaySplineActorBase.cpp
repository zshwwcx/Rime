// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Interactor/Spline/C7GameplaySplineActorBase.h"
#include "Components/SplineComponent.h"
#include "Managers/KGDataCacheManager.h"
#include "3C/Interactor/WorldManager.h"

AC7GameplaySplineActorBase::AC7GameplaySplineActorBase()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;
	PrimaryActorTick.bStartWithTickEnabled = false;

	SplineComponent = CreateDefaultSubobject<USplineComponent>(TEXT("SplineComponent"));
	if (SplineComponent.IsValid())
	{
		RootComponent = SplineComponent.Get();
		AddInstanceComponent(SplineComponent.Get());
	}
}

void AC7GameplaySplineActorBase::BeginPlay()
{
	Super::BeginPlay();
}

void AC7GameplaySplineActorBase::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
}

bool AC7GameplaySplineActorBase::InitSplinePathByInstanceID(const FString& InstanceID)
{
	if (!SplineComponent.IsValid())
	{
		UE_LOG(LogTemp, Error, TEXT("AC7GameplaySplineActorBase::InitSplinePathByInstanceID spline[%s] is invalid"), *InstanceID);
		return false;
	}
	
	// 初始化Spline曲线
	bool bSplineInitSuccess = InitSplineCurve(InstanceID);
	
	// 读取路点信息（站台、加减速等）
	bool bPointAttrInitSuccess = InitSplinePointAttributes(InstanceID);
	
	bSplineInitialized = bSplineInitSuccess && bPointAttrInitSuccess;
	return bSplineInitialized;
}

bool AC7GameplaySplineActorBase::InitSplineCurve(const FString& InstanceID)
{
	bool bSuccess = false;
	if (UKGDataCacheManager* DataCacheManager = UKGDataCacheManager::GetInstance(this))
	{
		if (FGameplaySplineData* SplineData = DataCacheManager->GetGameplaySplineData(InstanceID))
		{
			const int32 PointNum = SplineData->PathPoints.Num();
			if (PointNum > 2)
			{
				SplineComponent->ClearSplinePoints(false);
				SplineComponent->SetClosedLoop(SplineData->ClosedLoop);
				SplineComponent->SetWorldTransform(SplineData->SplineTransform);

				const auto& Points = SplineData->PathPoints;
				for (int32 PointIndex=0; PointIndex<PointNum; PointIndex++)
				{
					const auto& PointData = Points[PointIndex];
					auto SplinePoint = FSplinePoint(
						PointData.InputKey,
						PointData.Position,
						PointData.ArriveTangent,
						PointData.LeaveTangent,
						PointData.Rotation,
						FVector(1.0f),
						ConvertInterpCurveModeToSplinePointType(EInterpCurveMode(PointData.PointType))
						);
					SplineComponent->AddPoint(SplinePoint, PointIndex==PointNum-1);
				}
				bSuccess = true;
			}
			else
			{
				UE_LOG(LogTemp, Error, TEXT("AC7GameplaySplineActorBase::InitSplinePathByInstanceID found path data[:%s] invalid point number"), *InstanceID);
			}
		}
	}
	return bSuccess;
}

bool AC7GameplaySplineActorBase::InitSplineCurveByOtherSpline(class USplineComponent* OtherSpline)
{
	if (!SplineComponent.IsValid() || !OtherSpline)
	{
		UE_LOG(LogTemp, Error, TEXT("AC7GameplaySplineActorBase::InitSplineCurveByOtherSpline spline is invalid"));
		return false;
	}
	int32 NumPoints = OtherSpline->GetNumberOfSplinePoints();
	if (NumPoints < 2)
	{
		UE_LOG(LogTemp, Error, TEXT("AC7GameplaySplineActorBase::InitSplineCurveByOtherSpline invalid point number"));
		return false;
	}
	
	SplineComponent->ClearSplinePoints(false);
	SplineComponent->SetClosedLoop(OtherSpline->IsClosedLoop(), true);
	for (int32 i = 0; i < NumPoints; ++i)
	{
		FVector Location = OtherSpline->GetLocationAtSplinePoint(i, ESplineCoordinateSpace::Local);
		FVector ArriveTangent = OtherSpline->GetArriveTangentAtSplinePoint(i, ESplineCoordinateSpace::Local);
		FVector LeaveTangent = OtherSpline->GetLeaveTangentAtSplinePoint(i, ESplineCoordinateSpace::Local);
		FRotator Rotation = OtherSpline->GetRotationAtSplinePoint(i, ESplineCoordinateSpace::Local);
		FVector Scale = OtherSpline->GetScaleAtSplinePoint(i);
		ESplinePointType::Type PointType = OtherSpline->GetSplinePointType(i);
		FSplinePoint NewPoint(i, Location, ArriveTangent, LeaveTangent, Rotation, Scale, PointType);
		SplineComponent->AddPoint(NewPoint, i == NumPoints - 1);
	}
	return false;
}


