#include "3C/Interactor/Components/C7SimulatePhysicsBoxComponent.h"

UC7SimulatePhysicsBoxComponent::UC7SimulatePhysicsBoxComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

void UC7SimulatePhysicsBoxComponent::AddImpulseAtLocation(FVector Impulse, FVector Position, FName BoneName)
{
	ConstraintToApplyImpulse(Impulse, BoneName);
	
	Super::AddImpulseAtLocation(Impulse, Position, BoneName);
}

void UC7SimulatePhysicsBoxComponent::AddImpulse(FVector Impulse, FName BoneName, bool bVelChange)
{
	ConstraintToApplyImpulse(Impulse, BoneName);
	
	Super::AddImpulse(Impulse, BoneName, bVelChange);
}

void UC7SimulatePhysicsBoxComponent::AddForce(FVector Force, FName BoneName, bool bAccelChange)
{
	ConstraintToApplyForce(Force, BoneName);
	
	Super::AddForce(Force, BoneName, bAccelChange);
}

void UC7SimulatePhysicsBoxComponent::AddForceAtLocation(FVector Force, FVector Location, FName BoneName)
{
	ConstraintToApplyForce(Force, BoneName);
	
	Super::AddForceAtLocation(Force, Location, BoneName);
}

void UC7SimulatePhysicsBoxComponent::AddForceAtLocationLocal(FVector Force, FVector Location, FName BoneName)
{
	ConstraintToApplyForce(Force, BoneName);
	
	Super::AddForceAtLocationLocal(Force, Location, BoneName);
}

void UC7SimulatePhysicsBoxComponent::SetMaxOuterForceAndImpulse(const FVector& InMaxOuterForceVector, const FVector& InMaxOuterImpulseVector)
{
	MaxOuterForceVector = InMaxOuterForceVector;
	MaxOuterImpulseVector = InMaxOuterImpulseVector;
}

void UC7SimulatePhysicsBoxComponent::ConstraintToApplyForce(FVector& Force, FName BoneName)
{
	Force.X = ((uint8)EIgnorePhysicalForceType::X & (uint8)IgnoreOuterForceMask) ? 0 : Force.X;
	Force.Y = ((uint8)EIgnorePhysicalForceType::Y & (uint8)IgnoreOuterForceMask) ? 0 : Force.Y;
	Force.Z = ((uint8)EIgnorePhysicalForceType::Z & (uint8)IgnoreOuterForceMask) ? 0 : Force.Z;
	if (bConstraintMaxOuterForce)
	{
		ClampValueByAbsolute(Force.X, MaxOuterForceVector.X);
		ClampValueByAbsolute(Force.Y, MaxOuterForceVector.Y);
		ClampValueByAbsolute(Force.Z, MaxOuterForceVector.Z);
	}
}

void UC7SimulatePhysicsBoxComponent::ConstraintToApplyImpulse(FVector& Impulse, FName BoneName)
{
	Impulse.X = ((uint8)EIgnorePhysicalForceType::X & (uint8)IgnoreOuterImpulseMask) ? 0 : Impulse.X;
	Impulse.Y = ((uint8)EIgnorePhysicalForceType::X & (uint8)IgnoreOuterImpulseMask) ? 0 : Impulse.Y;
	Impulse.Z = ((uint8)EIgnorePhysicalForceType::X & (uint8)IgnoreOuterImpulseMask) ? 0 : Impulse.Z;
	if (bConstraintMaxOuterImpulse)
	{
		ClampValueByAbsolute(Impulse.X, MaxOuterImpulseVector.X);
		ClampValueByAbsolute(Impulse.Y, MaxOuterImpulseVector.Y);
		ClampValueByAbsolute(Impulse.Z, MaxOuterImpulseVector.Z);
	}
}

void UC7SimulatePhysicsBoxComponent::SetIgnoreImpulse(EIgnorePhysicalForceType InMask)
{
	IgnoreOuterImpulseMask = InMask;
}

void UC7SimulatePhysicsBoxComponent::SetIgnoreForce(EIgnorePhysicalForceType InMask)
{
	IgnoreOuterForceMask = InMask;
}

void UC7SimulatePhysicsBoxComponent::ClampValueByAbsolute(double& Value, const double& MaxAbsValue)
{
	if (MaxAbsValue >= 0)
	{
		if (MaxAbsValue < FMath::Abs(Value))
		{
			Value = Value > 0 ? MaxAbsValue : -MaxAbsValue;
		}
	}
}