// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Interactor/Components/C7TrackSplineComponent.h"
#include "NiagaraComponent.h"

#include "Kismet/KismetMathLibrary.h"
#include "Kismet/KismetSystemLibrary.h"

void UC7TrackSplineComponent::OnRegister()
{
	ClearSplinePoints(true);
	RefreshTrackEnable();
	
	Super::OnRegister();
}
void UC7TrackSplineComponent::OnComponentDestroyed(bool bDestroyingHierarchy)
{
	UE_LOG(LogTemp, Log, TEXT("UC7TrackSplineComponent::OnComponentDestroyed"));
	Super::OnComponentDestroyed(bDestroyingHierarchy);
}

// Called when the game starts
void UC7TrackSplineComponent::BeginPlay()
{
	Super::BeginPlay();
	
}

void UC7TrackSplineComponent::PrintPointInfo()
{
	if (AActor* Owner = GetOwner())
	{
		UE_LOG(LogTemp, Log, TEXT("[szk]UC7TrackSplineComponent Owner:%s, OwnerLoc:%s"), *Owner->GetName(), *Owner->GetActorLocation().ToString());
	}

	UE_LOG(LogTemp, Log, TEXT("[szk]UC7TrackSplineComponent WorldLoc:%s, RelativeLoc:%s"), *GetComponentLocation().ToString(), *GetRelativeLocation().ToString());

	const int32 NumPoints = SplineCurves.Position.Points.Num();
	for (int32 i = 0; i < NumPoints; i++)
	{
		FInterpCurvePoint tt = SplineCurves.Position.Points[i];

		const FTransform SplineToWorld = GetComponentToWorld();
		const FVector AbsoluteLocation = SplineToWorld.TransformPosition(tt.OutVal);
		UE_LOG(LogTemp, Log, TEXT("[szk]UC7TrackSplineComponent Points%i: InVal:%f, OutVal:%s, WorldLoc:%s"), i, tt.InVal, *tt.OutVal.ToString(), *AbsoluteLocation.ToString());
	}
}

void UC7TrackSplineComponent::SetTrackEnabled(bool bEnabled)
{
	if (bIsTrackEnabled == bEnabled)
	{
		return;
	}
	bIsTrackEnabled = bEnabled;
	RefreshTrackEnable();

	UpdateNiagara(bIsTrackEnabled);
}

void UC7TrackSplineComponent::UpdateNiagara(bool bActivate, bool bForceUpdate)
{
	if (bIsNiagraEnabled == bActivate && !bForceUpdate) { return; }
	bIsNiagraEnabled = bActivate;

	if (AActor* Owner = GetOwner())
	{
		if (UNiagaraComponent* NiagaraComp = Owner->GetComponentByClass<UNiagaraComponent>())
		{
			if (bActivate)
			{
				NiagaraComp->DeactivateImmediate();
				NiagaraComp->SetVariableFloat(SplineLengthParamName, 0.01f * GetSplineLength());
				NiagaraComp->SetVariableFloat(TrailSpeedParamName, TrailSpeed);
				if (PlayerSpeed > 0.0f) {
					NiagaraComp->SetVariableFloat(PlayerSpeedParamName, PlayerSpeed);
				}
				NiagaraComp->Activate();
			}
			else
			{
				NiagaraComp->DeactivateImmediate();
				PlayerSpeed = -1.0f;
			}
		}
	}
}

void UC7TrackSplineComponent::UpdatePlayerSpeed(float InPlayerSpeed)
{
	PlayerSpeed = InPlayerSpeed;
	if (bIsNiagraEnabled)
	{
		if (AActor* Owner = GetOwner())
		{
			if (UNiagaraComponent* NiagaraComp = Owner->GetComponentByClass<UNiagaraComponent>())
			{
				if (PlayerSpeed > 0.0f) {
					NiagaraComp->SetVariableFloat(PlayerSpeedParamName, PlayerSpeed);
				}
			}
		}
	}
}

void UC7TrackSplineComponent::RefreshTrackEnable()
{
	/*if (AActor* Owner = GetOwner())
	{
		Owner->SetActorHiddenInGame(!bIsTrackEnabled);
	}*/
	// SetVisibility(bIsTrackEnabled, true);
	if (!bIsTrackEnabled)
	{
		// ClearSplinePoints(true);
		// 必须要一个保底的bounds
		C7AddSplinePoint(FVector(0,0,0), ESplineCoordinateSpace::Local, false);
		C7AddSplinePoint(FVector(0,0,10), ESplineCoordinateSpace::Local, false);
		UpdateSpline();
		if (!CachedTrackPath.IsEmpty())
		{
			CachedTrackPath.Empty();
		}
	}
}

bool UC7TrackSplineComponent::IsSameStartAndEnd(const FVector &StartPos, const FVector &EndPos)
{
	if (CachedTrackPath.Num() <= 1)
	{
		return false;
	}
	if (UKismetMathLibrary::Vector_Distance2DSquared(CachedTrackPath[0], StartPos) > PosOffsetErrorSquared)
	{
		return false;
	}
	const int32 RealNum = CachedTrackPath.Num();
	if (UKismetMathLibrary::Vector_Distance2DSquared(CachedTrackPath[RealNum-1], EndPos) > PosOffsetErrorSquared)
	{
		return false;
	}
	return true;

}

bool UC7TrackSplineComponent::IsSameTrackFromCached(const TArray<FVector> &Points)
{
	const int32 RealNum = Points.Num();
	if (CachedTrackPath.Num() != RealNum)
	{
		return false;
	}
	return IsSameStartAndEnd(Points[0], Points[RealNum-1]);
}

void UC7TrackSplineComponent::UpdateTrackByPath(const TArray<FVector> &Points, bool bForceUpdate)
{
	if (Points.IsEmpty() || Points.Num() <= 1)
	{
		SetTrackEnabled(false);
		return;
	}
	if (!bForceUpdate && IsSameTrackFromCached(Points))
	{
		return;
	}
	DoUpdateTrack(Points);
}

void UC7TrackSplineComponent::UpdateTrackPointBehindCharacter(const TArray<FVector>& Points, const FVector& CurCharacterLocation)
{
	FSplineCurves Curves;
	Curves.Position.Reset();
	for (int32 Index = 0; Index < Points.Num(); ++Index)
	{
		Curves.Position.AddPoint(Index, Points[Index]);
	}
	float Dummy;
	float Key = Curves.Position.FindNearest(CurCharacterLocation, Dummy);
	int32 StartPointIndex = FMath::CeilToInt(Key);
	// UE_LOG(LogTemp, Warning, TEXT("[szk]%f / %i"), Key, Points.Num());

	if (StartPointIndex <= Points.Num() - 1)
	{
		TArray<FVector> RealPoints = TArray<FVector>();
		// 前后点位对比一下找个高度匹配的
		FVector FirstLoc = CurCharacterLocation;
		if (StartPointIndex > 1)
		{
			float Z1 = Points[StartPointIndex - 1].Z;
			float Z2 = Points[StartPointIndex].Z;
			float FinalZ = FMath::Abs(CurCharacterLocation.Z - Z1) >= FMath::Abs(CurCharacterLocation.Z - Z2) ? Z2 : Z1;
			if (FMath::Abs(CurCharacterLocation.Z - FinalZ) > 200.0f)
			{
				FinalZ = CurCharacterLocation.Z;
			}
			FirstLoc.Z = FinalZ;
		}
		else
		{
			float FinalZ = Points[StartPointIndex].Z;
			if (FMath::Abs(CurCharacterLocation.Z - FinalZ) > 200.0f)
			{
				FinalZ = CurCharacterLocation.Z;
			}
			FirstLoc.Z = FinalZ;
		}
		RealPoints.Add(FirstLoc);
		// UKismetSystemLibrary::DrawDebugPoint(this, RealPoints[RealPoints.Num() - 1], 20.0f, FLinearColor::Green, 1.0f);
		for (int32 i = StartPointIndex; i < Points.Num(); i++) {
			RealPoints.Add(Points[i]);
			// UKismetSystemLibrary::DrawDebugPoint(this, RealPoints[RealPoints.Num() - 1], 20.0f, FLinearColor::Green, 1.0f);
			// UKismetSystemLibrary::DrawDebugLine(this, RealPoints[RealPoints.Num()-2], RealPoints[RealPoints.Num() - 1], FLinearColor::Red, 1.0f, 5.0f);
		}

		UpdateTrackByPath(RealPoints);
		// 不改变Niagara显隐性，强制刷新数据
		UpdateNiagara(bIsNiagraEnabled, true);
	}
}

void UC7TrackSplineComponent::UpdateTrackByTailing(const TArray<FVector>& Points, int32 MoveStep, const FVector& CurLocation)
{
	if (MoveStep >= Points.Num() || MoveStep <= 0) return;

	const float TailingLength = PathMaxLength;
	TArray<FVector> Path;
	Path.Add(CurLocation);
	
	float AccumulatedDistance = 0.0;
	for (int32 Index=MoveStep; Index>=0; --Index)
	{
		const FVector &LastPos = Path.Last();
		const FVector &CurPos = Points[Index];
		FVector Direction = CurPos - LastPos;
		const float Distance = Direction.Size();
		if (AccumulatedDistance + Distance < TailingLength)
		{
			Path.Add(CurPos);
		}
		else
		{
			if (Direction.Normalize())
			{
				const float LeftDistance = FMath::Max(TailingLength - AccumulatedDistance, 1.0);
				Path.Add(LastPos + LeftDistance * Direction);
			}
			break;
		}
		AccumulatedDistance += Distance;
	}
	
	UpdateTrackByPath(Path);
}

void UC7TrackSplineComponent::CacheCurPath(const TArray<FVector> &Path)
{
	if (!CachedTrackPath.IsEmpty())
	{
		CachedTrackPath.Empty();
	}
	for (int32 Idx=0; Idx<Path.Num(); Idx++)
	{
		CachedTrackPath.Add(Path[Idx]);
	}
}

void UC7TrackSplineComponent::EnsureValidBounds()
{
	FBoxSphereBounds CurBounds = GetLocalBounds();
	if (CurBounds.ContainsNaN())
	{
		C7AddSplinePoint(FVector(0,0,0), ESplineCoordinateSpace::Local, false);
		C7AddSplinePoint(FVector(0,0,10), ESplineCoordinateSpace::Local, false);
		UpdateSpline();
	}
	else if(CurBounds.Origin.IsNearlyZero() || CurBounds.BoxExtent.IsNearlyZero() || CurBounds.SphereRadius <= 0)
	{
		C7AddSplinePoint(FVector(0,0,0), ESplineCoordinateSpace::Local, false);
		C7AddSplinePoint(FVector(0,0,10), ESplineCoordinateSpace::Local, false);
		UpdateSpline();
	}
}

void UC7TrackSplineComponent::TryCutPath(const TArray<FVector>& Points, TArray<FVector>& CutPoints)
{
	float AccumulatedDistance = 0.0;
	CutPoints.Add(Points[0]);
	for (int32 Idx=1; Idx<Points.Num(); Idx++)
	{
		const FVector &LastPos = Points[Idx-1];
		const FVector &CurPos = Points[Idx];
		FVector Direction = CurPos - LastPos;
		const float Distance = Direction.Size();
		if (AccumulatedDistance + Distance < PathMaxLength)
		{
			CutPoints.Add(Points[Idx]);
		}
		else
		{
			if (Direction.Normalize())
			{
				const float LeftDistance = FMath::Max(PathMaxLength - AccumulatedDistance, 1.0);
				CutPoints.Add(LastPos + LeftDistance * Direction);
			}
			break;
		}
		AccumulatedDistance += Distance;
	}
}

void UC7TrackSplineComponent::DoUpdateTrack(const TArray<FVector> &Points)
{
	if (Points.IsEmpty())
	{
		return;
	}
	
	TArray<FVector> CutPoints;
	TryCutPath(Points, CutPoints);
	ClearSplinePoints(false);
	if (AActor* Owner = GetOwner())
	{
		Owner->SetActorLocation(CutPoints[0]);
	}
	SetWorldLocation(CutPoints[0], false, nullptr, TeleportFlagToEnum(false));
	for (FVector &PathPoint: CutPoints)
	{
		C7AddSplinePoint(PathPoint, ESplineCoordinateSpace::World, false);
	}
	UpdateSpline();
	CacheCurPath(Points);
	// 不改变Niagara显隐性，强制刷新数据
	UpdateNiagara(bIsNiagraEnabled, true);
	
	EnsureValidBounds();
}

void UC7TrackSplineComponent::C7AddSplinePoint(const FVector& Position, ESplineCoordinateSpace::Type CoordinateSpace, bool bUpdateSpline)
{
	const FVector TransformedPosition = (CoordinateSpace == ESplineCoordinateSpace::World) ?
		GetComponentTransform().InverseTransformPosition(Position) : Position;

	// Add the spline point at the end of the array, adding 1.0 to the current last input key.
	// This continues the former behavior in which spline points had to be separated by an interval of 1.0.
	const float InKey = SplineCurves.Position.Points.Num() ? SplineCurves.Position.Points.Last().InVal + 1.0f : 0.0f;

	SplineCurves.Position.Points.Emplace(InKey, TransformedPosition, FVector::ZeroVector, FVector::ZeroVector, CIM_Linear);
	SplineCurves.Rotation.Points.Emplace(InKey, FQuat::Identity, FQuat::Identity, FQuat::Identity, CIM_Linear);
	SplineCurves.Scale.Points.Emplace(InKey, FVector(1.0f), FVector::ZeroVector, FVector::ZeroVector, CIM_Linear);
	USplineMetadata* Metadata = GetSplinePointsMetadata();
	if (Metadata)
	{
		Metadata->AddPoint(InKey);
	}

	if (bUpdateSpline)
	{
		UpdateSpline();
	}
}
