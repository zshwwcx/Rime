#include "3C/Interactor/RubiksCubeSpaceDivision.h"
#include "DrawDebugHelpers.h"
#include "3C/Interactor/WorldManager.h"

URubiksCubeSpaceDivision::URubiksCubeSpaceDivision(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer) {

}

void URubiksCubeSpaceDivision::Init(UWorldManager *WorldManager)
{
	OuterWorldManager = WorldManager;

	DivisionMinGridSize = FMath::Min3(DivisionGridSize.X, DivisionGridSize.Y, DivisionGridSize.Z);

	AllUniqueIDToElementMap.Reserve(512);
	UIDToSceneElementIdMapForAOI.Reserve(256);
	DivisionElementMap.Reserve(256);
	AllElementMap.Reserve(256);
	ElementIndexMap.Reserve(256);
	AOIElementStateMap.Reserve(64);
	TriggerObserverMap.Reserve(8);
	TriggerSubjectMap.Reserve(32);
	TriggerConsumeEnterEventMap.Reserve(8);
	TriggerConsumeLeaveEventMap.Reserve(8);
	PendingTriggerConsumeLeaveEventMap.Reserve(8);
	ObserverCallbackMapping.Reserve(32);
	TriggerCallbackMapping.Reserve(32);
	NeedCheckTriggerLogicTypes.Reset();
}

void URubiksCubeSpaceDivision::UnInit()
{
	OuterWorldManager.Reset();
	OnAOIStateChangedCB.Unbind();

	//清理TODO

}

int64 URubiksCubeSpaceDivision::ConsumeSceneElementID() {
	int64 ID = AvailableSceneElementID;
	AvailableSceneElementID += 1;
	if (AvailableSceneElementID > 864000) {
		AvailableSceneElementID = 1;
	}

	return ID;
}

bool URubiksCubeSpaceDivision::AddAOISceneElement(int64 UID, float PositionX, float PositionY, float PositionZ, float EntitySphereRadius) {
	if (UIDToSceneElementIdMapForAOI.Contains(UID)) {
		UE_LOG(LogTemp, Error, TEXT("[URubiksCubeSpaceDivision::AddAOISceneElement] Already Added To AOI Management:%lld "), UID);
		return false;
	}
	
	int64 UniqueSEId = ConsumeSceneElementID();
	UE_LOG(LogTemp, Log, TEXT("[URubiksCubeSpaceDivision::AddAOISceneElement] Adde To AOI Management UID:%lld, ElementID:%lld"), UID, UniqueSEId);
	
	AllUniqueIDToElementMap.Emplace(UniqueSEId, { UniqueSEId });
	UIDToSceneElementIdMapForAOI.Add(UID, UniqueSEId);

	auto& InElement = AllUniqueIDToElementMap[UniqueSEId];
	InElement.InitAsAOIElement(UID, EntitySphereRadius, FVector(PositionX, PositionY, PositionZ));

	DivisionElement(InElement);
	
	float CheckRadius = AOI_ActivedRadius + InElement.AOIRadiusShape.Radius;
	if (CheckElementInside(LastAoiCenter, InElement.Pos, CheckRadius))
	{
		OnAOIStateChanged(InElement, true);
	}
	return true;
}

bool URubiksCubeSpaceDivision::RemoveAOISceneElement(int64 UID) {
	if (!UIDToSceneElementIdMapForAOI.Contains(UID)) {
		UE_LOG(LogTemp, Log, TEXT("[URubiksCubeSpaceDivision::RemoveAOISceneElement]  Not In UIDToSceneElementIdMapForAOI :%lld "), UID);
		return false;
	}
	
	auto ElementId = UIDToSceneElementIdMapForAOI[UID];
	if (!AllUniqueIDToElementMap.Contains(ElementId)) {
		UE_LOG(LogTemp, Log, TEXT("[URubiksCubeSpaceDivision::RemoveAOISceneElement]  Not In AllUniqueIDToElementMap UID:%lld, ElementID:%lld"), UID, ElementId);
		return false;
	}

	UE_LOG(LogTemp, Log, TEXT("[URubiksCubeSpaceDivision::RemoveAOISceneElement]  Remove AOI Scene Element UID:%lld, ElementID:%lld"), UID, ElementId);
	if (FRubiksCubeIndexs* CubeIndexs = ElementIndexMap.Find(ElementId))
	{
		for (FRubiksCubeIndex& Index : CubeIndexs->Indexs)
		{
			if (FRubiksCubeElemIDs* Elems = DivisionElementMap.Find(Index))
			{
				Elems->ElementIDs.Remove(ElementId);
			}
		}

		ElementIndexMap.Remove(ElementId);
	}

	auto& Element = AllUniqueIDToElementMap[ElementId];


	AOIElementStateMap.Remove(Element.ElementUniqueID);
	UIDToSceneElementIdMapForAOI.Remove(Element.UID);
	// 注意上面是reference, 最后从容器中移除
	AllUniqueIDToElementMap.Remove(ElementId);
	
	return true;
}

void URubiksCubeSpaceDivision::UpdateAOIElement_Transform(const int64& UID, const FVector& InPos, const FRotator& InDir)
{
	if (int64 * ElementID = UIDToSceneElementIdMapForAOI.Find(UID))
	{
		if (auto Element = AllUniqueIDToElementMap.Find(*ElementID)) {

			Element->Pos = InPos;

			DivisionElement(*Element);
		}
	}
}

void URubiksCubeSpaceDivision::ViewTransformChanged(const FTransform& InViewTrans)
{
	UpdateAoiElements(InViewTrans.GetLocation());
}


const TMap<int64, FSDSceneElement>& URubiksCubeSpaceDivision::FindAllElements()
{
	return AllElementMap;
}


void URubiksCubeSpaceDivision::ClearAll()
{
	AllUniqueIDToElementMap.Empty();
	UIDToSceneElementIdMapForAOI.Empty();
	DivisionElementMap.Empty();
	//AllElementMap.Empty();
	ElementIndexMap.Empty();
	AOIElementStateMap.Empty();
	LastAoiCenter = FVector(FLT_MAX);
	ActivatedAoiCubeIndexMap.Empty();
	ElementAoiCheckMarkSet.Empty();

	TriggerObserverMap.Empty();
	TriggerSubjectMap.Empty();
	TriggerConsumeEnterEventMap.Empty();
	TriggerConsumeLeaveEventMap.Empty();
	PendingTriggerConsumeLeaveEventMap.Empty();
	ObserverCallbackMapping.Empty();
	TriggerCallbackMapping.Empty();
	NeedCheckTriggerLogicTypes.Reset();
	AvailableSceneElementID = 1;
}


void URubiksCubeSpaceDivision::MakeElementMovementDirty(int64 ElementId, const FVector& NewPosition) {
	if (!AllUniqueIDToElementMap.Contains(ElementId)) {
		return;
	}

	auto& Element = AllUniqueIDToElementMap[ElementId];
	Element.Pos = NewPosition;
	
	NeedCheckTriggerLogicTypes.Add(Element.TriggerLogicType);
}

int64 URubiksCubeSpaceDivision::RegisterGridLogicDetector(int32 TriggerLogicType, int64 UID, float PX, float PY, float PZ, float ObserverRadius, const FString& DetectCallbackName) {

	
	int64 UniqueSEId = ConsumeSceneElementID();

	AllUniqueIDToElementMap.Emplace(UniqueSEId, { UniqueSEId });
	auto& InElement = AllUniqueIDToElementMap[UniqueSEId];
	InElement.InitAsDetectElement(UID, TriggerLogicType, ObserverRadius, FVector(PX, PY, PZ));
	UE_LOG(LogTemp, Log, TEXT("[URubiksCubeSpaceDivision::RegisterGridLogicDetector]  Register GridLogic Detect AOI Scene Element UID:%lld, ElementID:%lld"), UID, UniqueSEId);
	
	FRubiksCubeElemIDs& ElemIDs = TriggerObserverMap.FindOrAdd(TriggerLogicType);
	ElemIDs.ElementIDs.Add(UniqueSEId);
	
	if (DetectCallbackName != "") {
		if (!ObserverCallbackMapping.Contains(TriggerLogicType)) {
			ObserverCallbackMapping.Add(TriggerLogicType, DetectCallbackName);
		}
		else if (ObserverCallbackMapping[TriggerLogicType] != DetectCallbackName){
			UE_LOG(LogTemp, Error, TEXT("[URubiksCubeSpaceDivision::RegisterGridLogicDetector] ObserverCallbackMapping  TriggerLogicType:%d  UID:%lld   Already Has Callback:%s, New Callback:%s"),
				TriggerLogicType, UID, *ObserverCallbackMapping[TriggerLogicType], *DetectCallbackName);
		}
	}
	
	NeedCheckTriggerLogicTypes.Add(TriggerLogicType);
	
	/*
	if (TriggerCallbackName != "") {
		if (!TriggerCallbackMapping.Contains(TriggerLogicType)) {
			TriggerCallbackMapping.Add(TriggerLogicType, TriggerCallbackName);
		}
		else {
			UE_LOG(LogTemp, Error, TEXT("[URubiksCubeSpaceDivision::RegisterGridTriggerDetector] TriggerCallbackName TriggerLogicType:%d  UID:%lld Already Has Callback:%s, New Callback:%s To AOI Management:%lld "),
				TriggerLogicType, UID, *TriggerCallbackMapping[TriggerLogicType], *TriggerCallbackName);
		}
	}
	/*/

	
	return UniqueSEId;
}

void URubiksCubeSpaceDivision::UpdateGridLogicDetectorRadius(int64 ElementID, float Radius) {
	if (!AllUniqueIDToElementMap.Contains(ElementID)) {
		return;
	}
	auto& InElement = AllUniqueIDToElementMap[ElementID];
	InElement.UpdataAOIRadiusShape(Radius);
	NeedCheckTriggerLogicTypes.Add(InElement.TriggerLogicType);
}

void URubiksCubeSpaceDivision::UnregisterGridLogicDetector(int64 ElementID, bool NeedHandleLeaveCB) {
	if (!AllUniqueIDToElementMap.Contains(ElementID)) {
		return;
	}

	auto& InElement = AllUniqueIDToElementMap[ElementID];
	

	UKGUEActorManager* ActorManager = nullptr;
	ICppEntityInterface* DetectScriptEntity = nullptr;
	if (OuterWorldManager.IsValid()) {
		ActorManager = UKGUEActorManager::GetInstance(OuterWorldManager.Get());
		DetectScriptEntity = ActorManager->GetLuaEntity(InElement.UID);
	}

	int32 TriggerLogicType = InElement.TriggerLogicType;
	FString* DetectCB = ObserverCallbackMapping.Find(TriggerLogicType);
	FString* TriggerCB = TriggerCallbackMapping.Find(TriggerLogicType);

#if !UE_BUILD_SHIPPING
	ensureAlwaysMsgf(
		!(DetectCB != nullptr && TriggerCB != nullptr),
		TEXT("[URubiksCubeSpaceDivision::UnregisterGridLogicDetector] Has Detect And Trigger CB Set at same Time, Unexpected! LogicTriggerType:%d  DetectCB:%s, TriggerCB:%s"),
		TriggerLogicType, **DetectCB, **TriggerCB
	);
#endif
	
	// observer 出场, 需要把之前的trigger出场逻辑处理一下
	if (FRubiksCubeTriggerData* TriggerDataPtr = TriggerSubjectMap.Find(InElement.TriggerLogicType))
	{
		if (FRubiksCubeElemIDs* TriggerIDs = TriggerDataPtr->ElemInsideTriggerIDsMap.Find(ElementID))
		{
			for (auto& TriggerID : TriggerIDs->ElementIDs)
			{
				if (FRubiksCubeElemIDs* InsideElemIDPtr = TriggerDataPtr->TriggerInsideMap.Find(TriggerID))
				{
					
					auto TriggerElement = AllUniqueIDToElementMap.Find(TriggerID);
					if (NeedHandleLeaveCB && TriggerElement) {

						if (DetectCB != nullptr && DetectScriptEntity) {
							DetectScriptEntity->GetLuaEntityBase()->CallLuaFunction(*DetectCB, TriggerElement->UID, TriggerLogicType, false);
						}

						if (TriggerCB != nullptr && ActorManager) {
							auto* TriggerScriptEntity = ActorManager->GetLuaEntity(TriggerElement->UID);
							if (TriggerScriptEntity) {
								TriggerScriptEntity->GetLuaEntityBase()->CallLuaFunction(*TriggerCB, InElement.UID, TriggerLogicType, false);
							}
						}

					}

					InsideElemIDPtr->ElementIDs.Remove(ElementID);
				}
			}
		}

		TriggerDataPtr->ElemInsideTriggerIDsMap.Remove(ElementID);
	}


	FRubiksCubeElemIDs* TriggerObserverMapValue = TriggerObserverMap.Find(InElement.TriggerLogicType);
	if (TriggerObserverMapValue) {
		TriggerObserverMapValue->ElementIDs.Remove(ElementID);
		if (TriggerObserverMapValue->ElementIDs.Num() == 0) {
			ObserverCallbackMapping.Remove(InElement.TriggerLogicType);
		}

	}

	AllUniqueIDToElementMap.Remove(ElementID);

	UE_LOG(LogTemp, Log, TEXT("[URubiksCubeSpaceDivision::UnregisterGridLogicDetector]  UnRegister GridLogic Detect AOI Scene Element ElementID:%lld"), ElementID);
	return;

}

int64 URubiksCubeSpaceDivision::RegisterGridLogicTrigger(int32 TriggerLogicType, int64 UID, float PX, float PY, float PZ, float Radius, const FString& TriggerCallbackName) {

	int64 UniqueSEId = ConsumeSceneElementID();

	AllUniqueIDToElementMap.Emplace(UniqueSEId, { UniqueSEId });
	auto& InElement = AllUniqueIDToElementMap[UniqueSEId];
	InElement.InitAsTriggerElement(UID, TriggerLogicType, Radius, FVector(PX, PY, PZ));
	UE_LOG(LogTemp, Log, TEXT("[URubiksCubeSpaceDivision::RegisterGridLogicTrigger]  Register GridLogic Trigger AOI Scene Element UID:%lld, ElementID:%lld"), UID, UniqueSEId);
	
	FRubiksCubeTriggerData& TriggerData = TriggerSubjectMap.FindOrAdd(TriggerLogicType);
	TriggerData.TriggerIDs.ElementIDs.Add(UniqueSEId);

	// 非单位是不会有回调的, 只有在detector上的回调到脚本做逻辑
	if (TriggerCallbackName != "" && UID != KG_INVALID_ENTITY_ID ) {
		if (!TriggerCallbackMapping.Contains(TriggerLogicType)) {
			TriggerCallbackMapping.Add(TriggerLogicType, TriggerCallbackName);
		}
		else if (TriggerCallbackMapping[TriggerLogicType] != TriggerCallbackName) {
			UE_LOG(LogTemp, Error, TEXT("[URubiksCubeSpaceDivision::RegisterGridLogicTrigger] TriggerCallbackMapping  TriggerLogicType:%d  UID:%lld Already Has Callback:%s, New Callback:%s "),
				TriggerLogicType, UID, *TriggerCallbackMapping[TriggerLogicType], *TriggerCallbackName);
		}
	}

	NeedCheckTriggerLogicTypes.Add(TriggerLogicType);

	return UniqueSEId;

}

void URubiksCubeSpaceDivision::UpdateGridLogicTriggerRadius(int64 ElementID, float Radius) {
	if (!AllUniqueIDToElementMap.Contains(ElementID)) {
		return;
	}
	auto& InElement = AllUniqueIDToElementMap[ElementID];
	InElement.UpdataAOIRadiusShape(Radius);
	NeedCheckTriggerLogicTypes.Add(InElement.TriggerLogicType);
}

void URubiksCubeSpaceDivision::UnregisterGridLogicTrigger(int64 ElementID, bool NeedHandleLeaveCB) {

	if (!AllUniqueIDToElementMap.Contains(ElementID)) {
		return;
	}

	auto& InElement = AllUniqueIDToElementMap[ElementID];
	
	UKGUEActorManager* ActorManager = nullptr;
	ICppEntityInterface* TriggerScriptEntity = nullptr;
	if (OuterWorldManager.IsValid()) {
		ActorManager = UKGUEActorManager::GetInstance(OuterWorldManager.Get());
		TriggerScriptEntity = ActorManager->GetLuaEntity(InElement.UID);
	}
	
	int32 TriggerLogicType = InElement.TriggerLogicType;
	FString* DetectCB = ObserverCallbackMapping.Find(TriggerLogicType);
	FString* TriggerCB = TriggerCallbackMapping.Find(TriggerLogicType);

#if !UE_BUILD_SHIPPING
	ensureAlwaysMsgf(
		!(DetectCB != nullptr && TriggerCB != nullptr), 
		TEXT("[URubiksCubeSpaceDivision::UnregisterGridLogicTrigger] Has Detect And Trigger CB Set at same Time, Unexpected! LogicTriggerType:%d  DetectCB:%s, TriggerCB:%s"),
		TriggerLogicType, **DetectCB, **TriggerCB
	);
#endif
	
	// 不漏回调的机制如果有性能问题, 脚本可以关闭回调开关, 就热点进行脚本特殊处理
	if (FRubiksCubeTriggerData* TriggerDataPtr = TriggerSubjectMap.Find(TriggerLogicType))
	{
		TriggerDataPtr->TriggerIDs.ElementIDs.Remove(ElementID);

		if (FRubiksCubeElemIDs* InsideElemIDPtr = TriggerDataPtr->TriggerInsideMap.Find(ElementID))
		{
			for (auto& ObElemID : InsideElemIDPtr->ElementIDs)
			{
				
				auto ObserverElement = AllUniqueIDToElementMap.Find(ObElemID);
				
				if (NeedHandleLeaveCB && ObserverElement) {

					if (TriggerCB != nullptr && TriggerScriptEntity) {
						TriggerScriptEntity->GetLuaEntityBase()->CallLuaFunction(*TriggerCB, ObserverElement->UID, TriggerLogicType, false);
					}
					
					if (DetectCB != nullptr && ActorManager) {
						auto * ObserverScriptEntity = ActorManager->GetLuaEntity(ObserverElement->UID);
						if (ObserverScriptEntity) {
							ObserverScriptEntity->GetLuaEntityBase()->CallLuaFunction(*DetectCB, InElement.UID, TriggerLogicType, false);
						}
					}

				}

				if (FRubiksCubeElemIDs* TriggerIDs = TriggerDataPtr->ElemInsideTriggerIDsMap.Find(ObElemID))
				{
					TriggerIDs->ElementIDs.Remove(ElementID);
				}
			}

			TriggerDataPtr->TriggerInsideMap.Remove(ElementID);
		}

		if (TriggerDataPtr->TriggerIDs.ElementIDs.Num() == 0) {
			TriggerCallbackMapping.Remove(InElement.TriggerLogicType);
		}
	}


	AllUniqueIDToElementMap.Remove(ElementID);
	UE_LOG(LogTemp, Log, TEXT("[URubiksCubeSpaceDivision::UnregisterGridLogicTrigger]  UnRegister GridLogic Trigger AOI Scene Element ElementID:%lld"), ElementID);
}

void URubiksCubeSpaceDivision::SetTriggerElementExitTolerantDistance(int64 ElementID, int DistanceCM) {
	if (!AllUniqueIDToElementMap.Contains(ElementID)) {
		return;
	}

	if (DistanceCM < 0) {
		DistanceCM = 10;
	}

	AllUniqueIDToElementMap[ElementID].TriggerExitTolerantDistance = DistanceCM;
}

void URubiksCubeSpaceDivision::UpdateTriggerState(float DeltaTime)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("[URubiksCubeSpaceDivision::UpdateTriggerState]");
	if (PendingTriggerConsumeLeaveEventMap.Num() > 0)
	{
		TriggerConsumeLeaveEventMap.Append(PendingTriggerConsumeLeaveEventMap);

		PendingTriggerConsumeLeaveEventMap.Reset();
	}

	if (!OuterWorldManager.IsValid()) {
		return;
	}


	auto* ActorManager = UKGUEActorManager::GetInstance(OuterWorldManager.Get());
	if (!ActorManager) {
		return;
	}
	
	// 复杂度: TriggerType(业务类型) * Observer数量 * Trigger数量
	// 理论上 observer和trigger 的中的单位, 在各个业务的类型中重叠度不高


	for (auto& TrggerLogicType : NeedCheckTriggerLogicTypes)
	{
		if (!TriggerSubjectMap.Contains(TrggerLogicType)) {
			continue;
		}

		FRubiksCubeTriggerData& TriggerData = TriggerSubjectMap[TrggerLogicType];

		// 遍历自己的trigger 者
		for (const int64& TriggerID : TriggerData.TriggerIDs.ElementIDs)
		{
			if (FSDSceneElement* TriggerElement = AllUniqueIDToElementMap.Find(TriggerID))
			{
				// trigger是有可能没有Entity的, 例如使用pos进行注册
				ICppEntityInterface* TriggerScriptEntity = ActorManager->GetLuaEntity(TriggerElement->UID);

				if (FRubiksCubeElemIDs* ObserverElemIDs = TriggerObserverMap.Find(TriggerElement->TriggerLogicType))
				{
					// Trigger对应的observer
					for (const int64& ObserverElemID : ObserverElemIDs->ElementIDs)
					{
						if (FSDSceneElement* ObserverElement = AllUniqueIDToElementMap.Find(ObserverElemID))
						{
							ICppEntityInterface* ObserverScriptEntity = ActorManager->GetLuaEntity(ObserverElement->UID);
							
							if (ObserverScriptEntity == nullptr && TriggerScriptEntity == nullptr) {
								continue;
							}
							
							float CheckRadius = TriggerElement->AOIRadiusShape.Radius + ObserverElement->AOIRadiusShape.Radius;
							
							bool AlreadyInside = false;
							FRubiksCubeElemIDs* InsideIDs = TriggerData.TriggerInsideMap.Find(TriggerElement->ElementUniqueID);
							if (InsideIDs && InsideIDs->ElementIDs.Find(ObserverElement->ElementUniqueID)) {
								
								AlreadyInside = true;
								CheckRadius += TriggerElement->TriggerExitTolerantDistance;
							}

							// 如果两者相交
							if (CheckElementInside(TriggerElement->Pos, ObserverElement->Pos, CheckRadius))
							{
								if (AlreadyInside == false) {
									if (InsideIDs == nullptr) {
										InsideIDs = &TriggerData.TriggerInsideMap.FindOrAdd(TriggerElement->ElementUniqueID);
									}
									// 记录trigger到observer的inside记录
									InsideIDs->ElementIDs.Add(ObserverElement->ElementUniqueID);
									//记录observer到trigger的inside记录
									FRubiksCubeElemIDs& TriggerIDs = TriggerData.ElemInsideTriggerIDsMap.FindOrAdd(ObserverElement->ElementUniqueID);
									TriggerIDs.ElementIDs.Add(TriggerElement->ElementUniqueID);

									FRubiksCubeElemIDs& EnterEventTriggerIDs = TriggerConsumeEnterEventMap.FindOrAdd(ObserverElement->ElementUniqueID);
									EnterEventTriggerIDs.ElementIDs.Add(TriggerElement->ElementUniqueID);
								}
							}
														
							else
							{
								if (AlreadyInside == true) {
									// 两者不相交, 并且之前是相交状态
									if (InsideIDs->ElementIDs.Find(ObserverElement->ElementUniqueID))
									{
										InsideIDs->ElementIDs.Remove(ObserverElement->ElementUniqueID);

										if (FRubiksCubeElemIDs* TriggerIDs = TriggerData.ElemInsideTriggerIDsMap.Find(ObserverElement->ElementUniqueID))
										{
											TriggerIDs->ElementIDs.Remove(TriggerElement->ElementUniqueID);
										}

										FRubiksCubeElemIDs& LeaveEventTriggerIDs = TriggerConsumeLeaveEventMap.FindOrAdd(ObserverElement->ElementUniqueID);
										LeaveEventTriggerIDs.ElementIDs.Add(TriggerElement->ElementUniqueID);

									}
								}
							}
						}
					}
				}
			}
		}
	}

	NeedCheckTriggerLogicTypes.Reset();


	for (auto& LeaveEvent : TriggerConsumeLeaveEventMap)
	{

		int64 DetectElementID = LeaveEvent.Key;
		if (!AllUniqueIDToElementMap.Contains(DetectElementID)) {
			continue;
		}

		auto& DetectElement = AllUniqueIDToElementMap[DetectElementID];
		int32 TriggerLogicType = DetectElement.TriggerLogicType;
		// 这里一定是对应好的logic trigger type
		FString* DetectCB = ObserverCallbackMapping.Find(TriggerLogicType);
		FString* TriggerCB = TriggerCallbackMapping.Find(TriggerLogicType);
#if !UE_BUILD_SHIPPING
		ensureAlwaysMsgf(
			!(DetectCB != nullptr && TriggerCB != nullptr),
			TEXT("[URubiksCubeSpaceDivision::UpdateTriggerState] Has Detect And Trigger CB Set at same Time, Unexpected! LogicTriggerType:%d  DetectCB:%s, TriggerCB:%s"),
			TriggerLogicType, **DetectCB, **TriggerCB
		);
#endif

		auto* DetectScriptEntity = ActorManager->GetLuaEntity(DetectElement.UID);
		if (!DetectScriptEntity) {
			continue;
		}

		for (auto& TriggerID : LeaveEvent.Value.ElementIDs)
		{
			if (!AllUniqueIDToElementMap.Contains(TriggerID)) {
				continue;
			}

			auto& TriggerElement = AllUniqueIDToElementMap[TriggerID];

			if (DetectCB != nullptr && DetectScriptEntity) {
				DetectScriptEntity->GetLuaEntityBase()->CallLuaFunction(*DetectCB, TriggerElement.UID, TriggerLogicType, false);
			}

			if (TriggerCB != nullptr && TriggerElement.UID != KG_INVALID_ENTITY_ID) {
				auto TriggerScriptEntity = ActorManager->GetLuaEntity(TriggerElement.UID);

				if (TriggerScriptEntity) {
					TriggerScriptEntity->GetLuaEntityBase()->CallLuaFunction(*TriggerCB, DetectElement.UID, TriggerLogicType, false);
				}
			}


		}
	}
	TriggerConsumeLeaveEventMap.Reset();


	for (auto& EnterEvent : TriggerConsumeEnterEventMap)
	{
		int64 DetectElementID = EnterEvent.Key;
		if (!AllUniqueIDToElementMap.Contains(DetectElementID)) {
			continue;
		}

		auto& DetectElement = AllUniqueIDToElementMap[DetectElementID];
		int32 TriggerLogicType = DetectElement.TriggerLogicType;
		// 这里一定是对应好的logic trigger type
		FString* DetectCB = ObserverCallbackMapping.Find(TriggerLogicType);
		FString* TriggerCB = TriggerCallbackMapping.Find(TriggerLogicType);

#if !UE_BUILD_SHIPPING
		ensureAlwaysMsgf(
			!(DetectCB != nullptr && TriggerCB != nullptr),
			TEXT("[URubiksCubeSpaceDivision::UpdateTriggerState] Has Detect And Trigger CB Set at same Time, Unexpected! LogicTriggerType:%d  DetectCB:%s, TriggerCB:%s"),
			TriggerLogicType, **DetectCB, **TriggerCB
		);
#endif

		auto* DetectScriptEntity = ActorManager->GetLuaEntity(DetectElement.UID);
		if (!DetectScriptEntity) {
			continue;
		}

		for (auto& TriggerID : EnterEvent.Value.ElementIDs)
		{
			if (!AllUniqueIDToElementMap.Contains(TriggerID)) {
				continue;
			}

			auto& TriggerElement = AllUniqueIDToElementMap[TriggerID];

			if (DetectCB != nullptr && DetectScriptEntity) {
				DetectScriptEntity->GetLuaEntityBase()->CallLuaFunction(*DetectCB, TriggerElement.UID, TriggerLogicType, true);
			}

			if (TriggerCB != nullptr && TriggerElement.UID != KG_INVALID_ENTITY_ID) {
				auto TriggerScriptEntity = ActorManager->GetLuaEntity(TriggerElement.UID);

				if (TriggerScriptEntity) {
					TriggerScriptEntity->GetLuaEntityBase()->CallLuaFunction(*TriggerCB, DetectElement.UID, TriggerLogicType, true);
				}
			}
		}
	}

	TriggerConsumeEnterEventMap.Reset();

}

void URubiksCubeSpaceDivision::DebugDrawTick(UWorld* InWorld, float DeltaTime)
{
	if(!InWorld)
		return ;

	//全部单位
	for (auto& Elem : AllElementMap)
	{
		const FSDSceneElement& Element = Elem.Value;

		FString Result = FString::Printf(TEXT("UID:%d TriggerLogicType:%d"), Element.UID, Element.TriggerLogicType);
		FVector DrawLoc = Element.Pos;

		if (bool* bEnterSpace = AOIElementStateMap.Find(Element.ElementUniqueID))
		{
			//单位 AOI状态
			DrawDebugString(InWorld, DrawLoc, Result, nullptr, *bEnterSpace? FColor::Green : FColor::Red, 0);
		}
		else
		{
			DrawDebugString(InWorld, DrawLoc, Result, nullptr, FColor::White, 0);
		}

		if (Element.AOIRadiusShape.Radius > 0)
		{
			DrawDebugSphere(InWorld, DrawLoc, Element.AOIRadiusShape.Radius, 16, FColor::Yellow, false, 0, 0, 8);
		}

	}

	//全部构建格子


	//已分配静态格子
	for (auto& Elem : DivisionElementMap)
	{
		const FRubiksCubeIndex& _CubeIndex = Elem.Key;
		const FRubiksCubeElemIDs& _ElemIDs = Elem.Value;

		FVector Center(DivisionGridSize.X * _CubeIndex.X, DivisionGridSize.Y * _CubeIndex.Y, DivisionGridSize.Z * _CubeIndex.Z);
		Center += BuildCenterPos;

		if (ActivatedAoiCubeIndexMap.Find(_CubeIndex))
		{
			//激活的格子
			DrawDebugBox(InWorld, Center, DivisionGridSize, FColor::Green, false, 0, 0, 20);
		}
		else
		{
			DrawDebugBox(InWorld, Center, DivisionGridSize, FColor::Black, false, 0, 0, 10);
		}
	}

	//AOI 内外圈
	DrawDebugSphere(InWorld, LastAoiCenter, AOI_ActivedRadius, 16, FColor::Green, false, 0, 0, 10);
}

void URubiksCubeSpaceDivision::OnAOIStateChanged(const FSDSceneElement& Element, const bool& bEnterSpace)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("[URubiksCubeSpaceDivision::OnAOIStateChanged]");
	if (bEnterSpace) {
		AOIElementStateMap.Add(Element.ElementUniqueID, bEnterSpace);
	}
	else {
		AOIElementStateMap.Remove(Element.ElementUniqueID);
	}


	//TODO 外部做帧分发
	OnAOIStateChangedCB.ExecuteIfBound(Element.UID, bEnterSpace);
}

void URubiksCubeSpaceDivision::UpdateAoiElements(const FVector& InCenter)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URubiksCubeSpaceDivision::UpdateAoiElements");
	if ((LastAoiCenter-InCenter).Size() > AOI_CheckIntervalDis)
	{
		LastAoiCenter = InCenter;

		UpdateAoiActiveCube();
	}
}

void URubiksCubeSpaceDivision::UpdateAoiActiveCube()
{
	ActivatedAoiCubeIndexMap.Reset();
	ElementAoiCheckMarkSet.Reset();
	TSet<int64> RetainActiveSet;

	// todo 这里有问题, 没有用上AOI的进入和退出的容忍逻辑处理
	//cppcheck:push ignore
	QueryNearCubeIter(LastAoiCenter, AOI_ActivedRadius, [&](const FRubiksCubeIndex& NewIndex) {
		// 这里确定掉哪些是一定Active的
		if (FRubiksCubeElemIDs* Elems = DivisionElementMap.Find(NewIndex))
		{
			for (const int64& ElementID : Elems->ElementIDs)
			{
				if (!AllUniqueIDToElementMap.Contains(ElementID)) {
					continue;
				}

				FSDSceneElement& Element = AllUniqueIDToElementMap[ElementID];

				if (ElementAoiCheckMarkSet.Find(Element.UID))
				{
					continue;
				}

				ElementAoiCheckMarkSet.Add(Element.UID);

				bool bOldEnterAoi(false);
				if (bool* bEnterSpace = AOIElementStateMap.Find(Element.ElementUniqueID))
				{
					bOldEnterAoi = *bEnterSpace;
				}
				const float CheckRadius = AOI_ActivedRadius + Element.AOIRadiusShape.Radius;
				if (CheckElementInside(LastAoiCenter, Element.Pos, CheckRadius))
				{
					if (!bOldEnterAoi)
					{
						OnAOIStateChanged(Element, true);
					}
				
					RetainActiveSet.Add(Element.ElementUniqueID);
				}
			}
		}

		ActivatedAoiCubeIndexMap.Add(NewIndex, true);
	});
	// cppcheck:pop

	TSet<int64> ActivatedElementIDs;
	AOIElementStateMap.GetKeys(ActivatedElementIDs);
	
	// 在失活的单位, 自己要用距离判断一次, 不能用失活格子, 因为距离容忍不是在格子层面处理的
	for (auto& ElementID : (ActivatedElementIDs.Difference(RetainActiveSet))) {
		
		const auto* ElementPtr = AllUniqueIDToElementMap.Find(ElementID);
		if (!ElementPtr) {
			continue;
		}
		const float CheckRadius = AOI_OuterCircleRadius + ElementPtr->AOIRadiusShape.Radius;
		if (!CheckElementInside(LastAoiCenter, ElementPtr->Pos, CheckRadius)) {
			OnAOIStateChanged(*ElementPtr, false);
		}
	}

}


void URubiksCubeSpaceDivision::DivisionElement(const FSDSceneElement& Element)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("[URubiksCubeSpaceDivision::DivisionElement]");
	const int64& ElementID = Element.ElementUniqueID;

	FRubiksCubeIndexs& CubeIndexs = ElementIndexMap.FindOrAdd(ElementID);
	TSet<FRubiksCubeIndex> OldCubeIndexs(CubeIndexs.Indexs);
	CubeIndexs.Indexs.Reset();

	// 这里有形状, 如果形状太大跨格子, 是考虑了跨格子的
	//cppcheck:push ignore
	QueryNearCubeIter(Element.Pos, Element.AOIRadiusShape.Radius, [this, &CubeIndexs, &ElementID, &OldCubeIndexs](const FRubiksCubeIndex& NewIndex) {
		CubeIndexs.Indexs.Add(NewIndex);
		if (!OldCubeIndexs.Find(NewIndex))
		{
			// 格子是稀疏创建的
			FRubiksCubeElemIDs& Elems = DivisionElementMap.FindOrAdd(NewIndex);
			Elems.ElementIDs.Add(ElementID);
		}
		else
		{
			OldCubeIndexs.Remove(NewIndex);
		}
	});
	//cppcheck:pop

	for (auto& _OldIndex : OldCubeIndexs)
	{
		if (FRubiksCubeElemIDs* Elems = DivisionElementMap.Find(_OldIndex))
		{
			Elems->ElementIDs.Remove(Element.ElementUniqueID);
		}
	}
}

FRubiksCubeIndex URubiksCubeSpaceDivision::CalculateCubeIndex(const FVector& InPos)
{
	FVector GapVec(InPos - BuildCenterPos);
	GapVec /= DivisionGridSize;

	if (!UsingZGrid) {
		GapVec.Z = 0;
	}

	return FRubiksCubeIndex(GapVec);
}

bool URubiksCubeSpaceDivision::CheckElementInside(const FVector& InTracePos, const FVector& AOIElementPos, float Radius)
{
	if (UsingZGrid) {
		return (InTracePos - AOIElementPos).Size() < Radius;
	}
	else {
		FVector P1 = InTracePos;
		P1.Z = 0;
		FVector P2 = AOIElementPos;
		P2.Z = 0;

		return (P1 - P2).Size() < Radius;
	}

}

void URubiksCubeSpaceDivision::QueryNearCubeIter(const FVector& InPos, float Radius, auto IterateFunc)
{
	FRubiksCubeIndex NewIndex(CalculateCubeIndex(InPos));
	
	if (Radius <= DivisionMinGridSize)
	{
		IterateFunc(NewIndex);
		return;
	}

	//先支持一种
	int32 GridNumX(0), GridNumY(0), GridNumZ(0);
	GridNumX = FMath::CeilToInt((Radius - DivisionGridSize.X * 0.5) / DivisionGridSize.X);
	GridNumY = FMath::CeilToInt((Radius - DivisionGridSize.Y * 0.5) / DivisionGridSize.Y);
	if (UsingZGrid) {
		GridNumZ = FMath::CeilToInt((Radius - DivisionGridSize.Z * 0.5) / DivisionGridSize.Z);
	}

	// 这里看似有半格偏移不准确(哪原始位置去推, 格子覆盖不准确), 但是因为大家都是按照同样规则处理的, 都偏移了半格, 所以基于各自的探测是准确的;
	for (int32 XIndex(NewIndex.X - GridNumX); XIndex < (NewIndex.X + GridNumX); ++XIndex)
	{
		for (int32 YIndex(NewIndex.Y - GridNumY); YIndex < (NewIndex.Y + GridNumY); ++YIndex)
		{
			if (UsingZGrid) {

				for (int32 ZIndex(NewIndex.Z - GridNumZ); ZIndex < (NewIndex.Z + GridNumZ); ++ZIndex)
				{
					FRubiksCubeIndex _Index(XIndex, YIndex, ZIndex);

					IterateFunc(_Index);
				}
			}
			else {
				FRubiksCubeIndex _Index(XIndex, YIndex, 0);

				IterateFunc(_Index);
			}
		}
	}
}