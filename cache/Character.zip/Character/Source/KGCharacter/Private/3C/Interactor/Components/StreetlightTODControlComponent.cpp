// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Interactor/Components/StreetlightTODControlComponent.h"
#include "Components/LightComponent.h"
#include "Components/StaticMeshComponent.h"

#include "Engine/World.h"
#include "3C/Interactor/WorldManager.h"

#if WITH_EDITOR
#include "GeographyClimateSubsystem.h"
#include "MainSkyPerformer.h"
#endif

UStreetlightTODControlComponent::UStreetlightTODControlComponent()
{
#if WITH_EDITOR
	PrimaryComponentTick.bCanEverTick = true;
#else
	PrimaryComponentTick.bCanEverTick = false;
#endif
}

void UStreetlightTODControlComponent::BeginPlay()
{
	Super::BeginPlay();

	InitLightDefaults();
	
	AActor* Actor = Cast<AActor>(GetOwner());
	if (UWorldManager* WorldManager = UWorldManager::GetInstance(this))
	{
		WorldManager->RegisterTODStreetlightActor(Actor, GetTurnOnDayOfTime(), GetTurnOffDayOfTime());
#if WITH_EDITOR
		SetComponentTickEnabled(false);
#endif
	}
#if WITH_EDITOR
	else
	{
		SetComponentTickEnabled(true);
		bInitLightDefaultsInEditor = false;
	}
#endif
}

void UStreetlightTODControlComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (AActor* Actor = Cast<AActor>(GetOwner()))
	{
		if (UWorldManager* WorldManager = UWorldManager::GetInstance(this))
		{
			WorldManager->UnRegisterTODStreetlightActor(Actor, GetTurnOnDayOfTime(), GetTurnOffDayOfTime());
		}
	}
	Super::EndPlay(EndPlayReason);
}

void UStreetlightTODControlComponent::SetTODStateAtOnce(bool bOff, bool bReverseIntensity)
{
	AActor* Actor = Cast<AActor>(GetOwner());
	
	if (ControlComponentTag != NAME_None)
	{
		TArray<UActorComponent*> Components = Actor->GetComponentsByTag(UPrimitiveComponent::StaticClass(), ControlComponentTag);
		for (auto Component : Components)
		{
			if (UPrimitiveComponent* PrimitiveComponent = Cast<UPrimitiveComponent>(Component))
			{
				PrimitiveComponent->SetHiddenInGame(bOff, false);
				PrimitiveComponent->SetVisibility(!bOff, false);
			}
		}
	}

	if (EmissiveColorComponentTag != NAME_None && EmissiveColorMaterialParameterName != NAME_None)
	{
		TOptional<FVector> OptionalEmissiveColor = bOff ? OptionalEmissiveColorWhenOff : OptionalEmissiveColorWhenOn;
		if (OptionalEmissiveColor.IsSet())
		{
			TArray<UActorComponent*> Components = Actor->GetComponentsByTag(UStaticMeshComponent::StaticClass(), EmissiveColorComponentTag);
			for (auto Component : Components)
			{
				if (UStaticMeshComponent* StaticMeshComponent = Cast<UStaticMeshComponent>(Component))
				{
					StaticMeshComponent->SetVectorParameterValueOnMaterials(EmissiveColorMaterialParameterName, OptionalEmissiveColor.GetValue());
				}
			}
		}
	}
	
	TArray<UActorComponent*> Components = Actor->K2_GetComponentsByClass(ULightComponent::StaticClass());
	for (auto Component : Components)
	{
		if (ULightComponent* LightComponent = Cast<ULightComponent>(Component))
		{
			LightComponent->SetHiddenInGame(bOff, false);
			bool bDefaultIntensity = bReverseIntensity ? bOff : !bOff;
			if (bDefaultIntensity)
			{
				if (DefaultIntensityMap.Contains(LightComponent))
				{
					LightComponent->SetIntensity(DefaultIntensityMap[LightComponent]);
				}
			}
			else
			{
				LightComponent->SetIntensity(0.f);
			}
		}
	}
}

void UStreetlightTODControlComponent::UpdateTODState(float Alpha, bool bTurningOff)
{
	for (auto LightElem : DefaultIntensityMap)
	{
		if (LightElem.Key.IsValid())
		{
			float DefaultIntensity = LightElem.Value;
			float CurrentIntensity = bTurningOff ? DefaultIntensity * (1 - Alpha) : DefaultIntensity * Alpha;
			LightElem.Key->SetIntensity(CurrentIntensity);
		}
	}
}

void UStreetlightTODControlComponent::SetLightBeforeComponentTagControl()
{
	AActor* Actor = Cast<AActor>(GetOwner());
	TArray<UActorComponent*> Components = Actor->K2_GetComponentsByClass(ULightComponent::StaticClass());
	for (auto Component : Components)
	{
		if (ULightComponent* LightComponent = Cast<ULightComponent>(Component))
		{
			LightComponent->SetHiddenInGame(false, false);
		}
	}
}

void UStreetlightTODControlComponent::InitLightDefaults()
{
	DefaultIntensityMap.Empty();
	if (AActor* Actor = Cast<AActor>(GetOwner()))
	{
		TArray<UActorComponent*> Components = Actor->K2_GetComponentsByClass(ULightComponent::StaticClass());
		for (auto Component : Components)
		{
			if (ULightComponent* LightComponent = Cast<ULightComponent>(Component))
			{
				DefaultIntensityMap.Add(LightComponent,
					OptionalIntensityWhenOn.IsSet() ?
					OptionalIntensityWhenOn.GetValue() :
					LightComponent->Intensity);
			}
		}
	}

#if WITH_EDITOR
	MainSkyPerformerInEditor.Reset();
	TArray<AActor*> Results;
	UGameplayStatics::GetAllActorsOfClass(GetWorld(), AMainSkyPerformer::StaticClass(), Results);
	for (AActor* Actor : Results)
	{
		if (AMainSkyPerformer* MainSkyPerformer = Cast<AMainSkyPerformer>(Actor))
		{
			MainSkyPerformerInEditor = MainSkyPerformer;
			break;
		}
	}
#endif
}

void UStreetlightTODControlComponent::UpdateLightControlByComponentTag(const TArray<FStreetLightControlByComponentTagParams>& LightParams, const float Percent)
{
	AActor* Actor = Cast<AActor>(GetOwner());
	for (auto Param : LightParams)
	{
		float CurrentIntensity = Percent * (Param.EndIntensity - Param.StartIntensity) + Param.StartIntensity;
		if (Param.ComponentTag != NAME_None)
		{
			TArray<UActorComponent*> Components = Actor->GetComponentsByTag(ULightComponent::StaticClass(), Param.ComponentTag);
			for (auto Component : Components)
			{
				if (ULightComponent* LightComponent = Cast<ULightComponent>(Component))
				{
					LightComponent->SetIntensity(CurrentIntensity);
				}
			}
		}
		else
		{
			TArray<UActorComponent*> Components = Actor->K2_GetComponentsByClass(ULightComponent::StaticClass());
			for (auto Component : Components)
			{
				if (ULightComponent* LightComponent = Cast<ULightComponent>(Component))
				{
					if (LightComponent->ComponentTags.IsEmpty())
					{
						LightComponent->SetIntensity(CurrentIntensity);
					}
				}
			}
		}
	}
}

#if WITH_EDITOR

float UStreetlightTODControlComponent::GetCurrentTimeOfDayInEditor() const
{
	if (UWorld* World = GetWorld())
	{
		if (World->WorldType == EWorldType::PIE)
		{
			if (UGeographyClimateSubsystem* GeographyClimateSystem = World->GetSubsystem<UGeographyClimateSubsystem>())
			{
				const FGeographyInfo& CurrentGeographyInfo = GeographyClimateSystem->GetGeographyInfo();
				return CurrentGeographyInfo.Hours + CurrentGeographyInfo.Minutes / 60.0f + CurrentGeographyInfo.Seconds / 3600.0f;
			}
		}
		else if (World->WorldType == EWorldType::Editor)
		{
			if (MainSkyPerformerInEditor.IsValid())
			{
				return MainSkyPerformerInEditor->LocalTimeOfDay;
			}
		}
	}

	return -1;
}

void UStreetlightTODControlComponent::TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (!GetWorld())
	{
		return;
	}

	bool bNeedInitTOD = !bInitLightDefaultsInEditor;
	if (!bInitLightDefaultsInEditor)
	{
		InitLightDefaults();
		
		bInitLightDefaultsInEditor = true;
	}
	
	float CurrentTimeOfDay = GetCurrentTimeOfDayInEditor();
	if (CurrentTimeOfDay < 0)
	{
		return;
	}

	const bool bInDayTime = CurrentTimeOfDay >= GetTurnOffDayOfTime() && CurrentTimeOfDay < GetTurnOnDayOfTime();
	if (bNeedInitTOD)
	{
		bInDayTimeInEditor = bInDayTime;
		TickTypeInEditor = EStreetlightTickTypeInEditor::None;
		SetTODStateAtOnce(bInDayTime, false);
		return;
	}
	
	if (bInDayTime != bInDayTimeInEditor)
	{
		SetTODStateAtOnce(bInDayTime, true);
		bInDayTimeInEditor = bInDayTime;
		TickTypeInEditor = bInDayTime ? EStreetlightTickTypeInEditor::TurnOff : EStreetlightTickTypeInEditor::TurnOn;
		CurrentTickTimeInEditor = 0.f;
	}

	if (TickTypeInEditor == EStreetlightTickTypeInEditor::TurnOff || TickTypeInEditor == EStreetlightTickTypeInEditor::TurnOn)
	{
		const bool bTurningOff = TickTypeInEditor == EStreetlightTickTypeInEditor::TurnOff;
		CurrentTickTimeInEditor += DeltaTime;
		float Alpha = StreetlightTODDurationInEditor > 0 && CurrentTickTimeInEditor < StreetlightTODDurationInEditor
			? CurrentTickTimeInEditor / StreetlightTODDurationInEditor
			: 1.0f;

		if (Alpha >= 1.0f)
		{
			SetTODStateAtOnce(bTurningOff, false);
			TickTypeInEditor = EStreetlightTickTypeInEditor::None;
		}
		else
		{
			UpdateTODState(Alpha, bTurningOff);
		}
	}
}

#endif
