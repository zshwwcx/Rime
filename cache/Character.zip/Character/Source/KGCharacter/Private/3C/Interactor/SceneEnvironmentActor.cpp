#include "3C/Interactor/SceneEnvironmentActor.h"
#include "Kismet/GameplayStatics.h"

UE_DISABLE_OPTIMIZATION

#if WITH_EDITOR


void ASceneEnvironmentActor::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	if (GetWorld())
	{
		if (FProperty* Property = PropertyChangedEvent.Property)
		{
			FString PropertyName = Property->GetName();

			EditorPostEditChangeProperty(PropertyName);
		}
	}
}

#endif

AActor* ASceneEnvironmentActor::GetTargetActor(FString Name)
{
	if (TSubclassOf<AActor>* ActorClass = LinkActorClassMap.Find(Name))
	{
		return UGameplayStatics::GetActorOfClass((UObject*)GetWorld(), *ActorClass);
	}

	return nullptr;
}

void ASceneEnvironmentActor::OnSwitchEnvironmentTheme(FString ThemeName, FString ThemeConfigPropMapName)
{
	for (FProperty* Property : TFieldRange<FProperty>(GetClass(), EFieldIteratorFlags::ExcludeSuper))
	{
		FString PropertyName = Property->GetName();
		if (PropertyName == ThemeConfigPropMapName)
		{
			if (FMapProperty* MapProperty = CastField<FMapProperty>(Property))
			{
				void* PropertyAddress = Property->ContainerPtrToValuePtr<void>(this);
				if (!PropertyAddress)
					continue;

				FScriptMapHelper ScriptMapHelper(MapProperty, PropertyAddress);
				FProperty* KeyProperty = ScriptMapHelper.GetKeyProperty();
				FProperty* ValueProperty = ScriptMapHelper.GetValueProperty();
				for (FScriptMapHelper::FIterator MapPropIt = ScriptMapHelper.CreateIterator(); MapPropIt; ++MapPropIt)
				{
					void* KeyAddress = ScriptMapHelper.GetKeyPtr(MapPropIt);
					if (!KeyAddress)
						continue;

					if (FStrProperty* KeyFStr = CastField<FStrProperty>(KeyProperty))
					{
						FString Key = *StaticCast<FString*>(KeyAddress);

						if (void* MapValueAddress = ScriptMapHelper.GetValuePtr(MapPropIt))
						{
							if (FStructProperty* StructProperty = CastField<FStructProperty>(ValueProperty))
							{
								if (const UScriptStruct* Struct = StructProperty->Struct)
								{
									for (FProperty* SProperty : TFieldRange<FProperty>(Struct))
									{
										FString PropConfigName = SProperty->GetName();

#if WITH_EDITOR
										if (const FString* FoundMetaData = SProperty->FindMetaData(FName(TEXT("DisplayName"))))
										{
											PropConfigName = *FoundMetaData;
										}
#endif
										if (AActor* TargetActor = GetTargetActor(PropConfigName))
										{
											if (void* StructValueAddress = SProperty->ContainerPtrToValuePtr<void>(MapValueAddress))
											{
												if (FStructProperty* SPropertyStruct = CastField<FStructProperty>(SProperty))
												{
													if (const UScriptStruct* SSubtruct = SPropertyStruct->Struct)
													{
														for (FProperty* SSubProperty : TFieldRange<FProperty>(SSubtruct))
														{
															if (void* SSubtructValueAddress = SSubProperty->ContainerPtrToValuePtr<void>(StructValueAddress))
															{
																for (FProperty* TargetActorProperty : TFieldRange<FProperty>(TargetActor->GetClass(), EFieldIteratorFlags::ExcludeSuper))
																{
																	FString SSubPropertyName = SSubProperty->GetName();
#if WITH_EDITOR
																	if (const FString* FoundSSubMetaData = SSubProperty->FindMetaData(FName(TEXT("DisplayName"))))
																	{
																		SSubPropertyName = *FoundSSubMetaData;
																	}
#endif
																	if (SSubPropertyName == TargetActorProperty->GetName())
																	{
																		if (void* TargetAddress = TargetActorProperty->ContainerPtrToValuePtr<void>(TargetActor))
																		{
																			TargetActorProperty->CopyCompleteValue(TargetAddress, SSubtructValueAddress);
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}

			break;
		}
	}
}

UE_ENABLE_OPTIMIZATION