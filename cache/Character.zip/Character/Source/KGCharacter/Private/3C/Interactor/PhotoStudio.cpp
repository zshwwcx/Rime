#include "3C/Interactor/PhotoStudio.h"

#include "Misc/LowLevelFunctions.h"



void APhotoStudio::BeginPlay()
{
	// 不是摆放在场景中的静态物体，所以实例ID要动态生成
	// Begin change by chengxu05@kuaishou.com
	if (!IsRunningCookCommandlet())
	{
		InstanceID = ULowLevelFunctions::GetGlobalUniqueID();
	}
	// End change by chengxu05@kuaishou.com
	Super::BeginPlay();
}
