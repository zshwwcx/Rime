// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Interactor/Components/TimeChessMoveComponent.h"

#include "Engine/StaticMesh.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Curves/CurveFloat.h"
#include "Components/InstancedStaticMeshComponent.h"

#define FUNC_NAME *FString(__FUNCTION__)

// Sets default values for this component's properties
UTimeChessMoveComponent::UTimeChessMoveComponent()
{
    // Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
    // off to improve performance if you don't need them.
    PrimaryComponentTick.bCanEverTick = true;
}

// Called every frame
void UTimeChessMoveComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
    Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

    TArray<int32> ToDeleteIndexes;
    for (int32 Idx = 0; Idx < TimeChessMoveTasks.Num(); ++Idx)
    {
        float bFinish = MoveChess(TimeChessMoveTasks[Idx], DeltaTime);
        if (bFinish)
        {
            OnChessLandedEvent.Broadcast();
            ToDeleteIndexes.Add(Idx);
        }
    }

    // 删除已完成的Task
    for (const int32& ToDeleteIndex : ToDeleteIndexes)
    {
        // UE_LOG(LogTemp, Log, TEXT("%s remove a %s task"), FUNC_NAME, *TimeChessMoveTasks[ToDeleteIndex].ISMComp->GetName());
        if (TimeChessMoveTasks.IsValidIndex(ToDeleteIndex))
        {
            TimeChessMoveTasks.RemoveAt(ToDeleteIndex);   
        }
    }
}

void UTimeChessMoveComponent::InitMoveParams(UCurveFloat* InHeightCurve, UCurveFloat* InSpeedCurve)
{
    TArray<UStaticMeshComponent*> StaticMeshComponents;
    GetOwner()->GetComponents<UStaticMeshComponent>(StaticMeshComponents);
    for (auto StaticMeshComponent : StaticMeshComponents)
    {
        if (StaticMeshComponent->GetName().Equals("InMovingChess"))
        {
            InMovingSmComp = StaticMeshComponent;
        }
    }
    
    HeightCurve = InHeightCurve;
    SpeedCurve = InSpeedCurve;
}

void UTimeChessMoveComponent::AddChessMoveTask(UInstancedStaticMeshComponent* ISMComp, const int32& InstanceIndex, const FTransform& TargetTrans)
{
    if (!ISMComp || !InMovingSmComp.IsValid())
    {
        UE_LOG(LogTemp, Error, TEXT("%s component invalid"), FUNC_NAME);
        return;
    }

    FTransform CurTransform;
    ISMComp->GetInstanceTransform(InstanceIndex, CurTransform);

    FTimeChessMoveTask NewTask;
    NewTask.Reset();
    NewTask.ISMComp = ISMComp;
    NewTask.InstanceIndex = InstanceIndex;
    NewTask.TargetLoc = TargetTrans.GetLocation();
    NewTask.StartLoc = CurTransform.GetLocation();
    NewTask.Rotator = TargetTrans.GetRotation().Rotator();
    TimeChessMoveTasks.Add(NewTask);
    // UE_LOG(LogTemp, Log, TEXT("%s add a %s task"), FUNC_NAME, *ISMComp->GetName());
    
    InMovingSmComp->SetRelativeTransform(TargetTrans);
}

bool UTimeChessMoveComponent::MoveChess(FTimeChessMoveTask& Task, float DeltaTime)
{
    if (!InMovingSmComp->GetVisibleFlag())
    {
        InMovingSmComp->SetVisibility(true);
        FTransform ISMTransform;
        Task.ISMComp->GetInstanceTransform(Task.InstanceIndex, ISMTransform);
        ISMTransform.SetScale3D(FVector::ZeroVector);
        Task.ISMComp->UpdateInstanceTransform(Task.InstanceIndex, ISMTransform);
    }
    
    Task.CurTime += DeltaTime;

    FTransform NextTransForm = InMovingSmComp->GetRelativeTransform();
    FVector NextLocation;

    // 计算水平位置
    const float AlphaRate = SpeedCurve->GetFloatValue(Task.CurTime);
    float Alpha = (Task.CurTime - 0.6) / 0.5 * AlphaRate;
    const bool bAlphaEnd = Alpha > 1;
    Alpha = Alpha > 1 ? 1.f : Alpha;
    NextLocation = FMath::Lerp(Task.StartLoc, Task.TargetLoc, Alpha);

    // 计算高度
    float NextHeight = HeightCurve->GetFloatValue(Task.CurTime);
    const bool bHeightEnd = NextHeight < 0;
    NextHeight = NextHeight < 0 ? 0.f : NextHeight;
    NextLocation.Z = NextHeight;

    NextTransForm.SetLocation(NextLocation);
    NextTransForm.SetRotation(Task.Rotator.Quaternion());
    InMovingSmComp->SetRelativeTransform(NextTransForm);

    // 如果高度为0且到达目标位置, 则认为移动结束
    if (bHeightEnd && bAlphaEnd)
    {
        Task.ISMComp->UpdateInstanceTransform(Task.InstanceIndex, NextTransForm);
        InMovingSmComp->SetVisibility(false);
        return true;
    }

    return false;
}
