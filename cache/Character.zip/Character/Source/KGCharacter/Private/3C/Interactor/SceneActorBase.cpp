#include "3C/Interactor/SceneActorBase.h"
#include "Engine/World.h"
#include "3C/Interactor/Components/ChildSceneActorComponent.h"
#include "3C/Interactor/WorldManager.h"

#if WITH_EDITORONLY_DATA
bool ASceneActorBase::bBatchMigrate = false;
#endif

ASceneActorBase::ASceneActorBase()
{
}

int64 ASceneActorBase::GetInstanceID() const
{
	if (IsChildActor()) // 此方法里已经判断了ParentComponent的有效性，下面直接Cast是安全的
	{
		if (UChildSceneActorComponent* ChildSceneActorComponent = Cast<UChildSceneActorComponent>(GetParentComponent()))
		{
			return ChildSceneActorComponent->GetInstanceID();
		}
	}
	return InstanceID;
}

void ASceneActorBase::BeginPlay()
{
	Super::BeginPlay();

	if (UWorldManager* WorldMgr = UWorldManager::GetInstance(GetWorld()))
	{
		WorldMgr->RegisterSceneActor(GetInstanceID(), this);
	}
}

void ASceneActorBase::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	if (UWorldManager* WorldMgr = UWorldManager::GetInstance(GetWorld()))
	{
		WorldMgr->UnRegisterSceneActor(GetInstanceID(), this);
	}
}

// Begin change by chengxu05@kuaishou.com
void ASceneActorBase::PostActorCreated()
{
	Super::PostActorCreated();

#if WITH_EDITOR
	if (!IsRunningCookCommandlet())
	{
		InstanceID = GetTypeHash(FGuid::NewGuid());
	}
#endif
}
// End change by chengxu05@kuaishou.com

#if WITH_EDITOR

void ASceneActorBase::PostDuplicate(EDuplicateMode::Type DuplicateMode)
{
#if WITH_EDITORONLY_DATA
	//迁移不重置InsID
	if (ASceneActorBase::bBatchMigrate)
		return ;
#endif

	if (GetWorld() && (!GetWorld()->IsPlayInEditor()))
	{
		Super::PostDuplicate(DuplicateMode);

		// If the entire world is being duplicated, do not change the InstanceID.
		if (DuplicateMode != EDuplicateMode::World)
		{
			InstanceID = GetTypeHash(FGuid::NewGuid());
		}
	}
}

#endif