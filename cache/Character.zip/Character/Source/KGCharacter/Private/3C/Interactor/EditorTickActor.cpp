#include "3C/Interactor/EditorTickActor.h"
#include "Engine/World.h"   
 
AEditorTickActor::AEditorTickActor()
{
	PrimaryActorTick.bCanEverTick = true;
}

bool AEditorTickActor::ShouldTickIfViewportsOnly() const
{
	return true;
}

void AEditorTickActor::Tick(float DeltaTime)
{
	//allow blueprint tick in editor view 
	FEditorScriptExecutionGuard scriptExecutionGuard;
	{
#if WITH_EDITOR
		if (GIsEditor && GetWorld() && !GetWorld()->IsGameWorld())
		{
			// Only execute in Editor
			OnEditorTickStart(DeltaTime);
		}
#endif
		Super::Tick(DeltaTime);
	}
	
}

#if WITH_EDITOR
void AEditorTickActor::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
	OnEditChangeProperty();
}
#endif

