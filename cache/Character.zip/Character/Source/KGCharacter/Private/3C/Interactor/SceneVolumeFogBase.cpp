#include "3C/Interactor/SceneVolumeFogBase.h"

#include "Components/StaticMeshComponent.h"
#include "Materials/Material.h"
#include "Materials/MaterialInstanceDynamic.h"

void ASceneVolumeFogBase::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);

	ApplyFogOpacity(OpacityLevel);
}

void ASceneVolumeFogBase::ApplyFogOpacity(float NewOpacity)
{
	if (OpacityMaterialParamName != NAME_None)
	{
		if (UActorComponent* ActorComponent = GetComponentByClass(UStaticMeshComponent::StaticClass()))
		{
			if (UStaticMeshComponent* CubeMeshComponent = Cast<UStaticMeshComponent>(ActorComponent))
			{
				if (UMaterialInstanceDynamic* MID = CubeMeshComponent->CreateDynamicMaterialInstance(0, MeshFogMaterial))
				{
					MID->SetScalarParameterValue(OpacityMaterialParamName, NewOpacity);
				}
			}
		}
	}
}