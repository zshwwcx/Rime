#include "3C/Interactor/Components/BookCorridorComponent.h"

#include "3C/Effect/KGEffectManager.h"
#include "NiagaraComponent.h"
#include "Misc/ObjCrashCollector.h"
#include "Components/StaticMeshComponent.h"

UBookCorridorComponent::UBookCorridorComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UBookCorridorComponent::BeginPlay()
{
	Super::BeginPlay();
	SetComponentTickEnabled(false);
}

void UBookCorridorComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	if (FollowActor.IsValid())
	{
		if (AActor* Owner = GetOwner())
		{
			FVector PlayerPos = FollowActor->GetActorLocation();
			FVector PlayerPosInterp = FMath::VInterpTo(PrePlayerPos, PlayerPos, DeltaTime, InterpSpeed);
			PrePlayerPos = PlayerPos;
			TArray<AActor*> ChildActors;
			Owner->GetAllChildActors(ChildActors, false);
			for (AActor* ChildActor : ChildActors)
			{
				TArray MeshComponents = ChildActor->K2_GetComponentsByClass(UStaticMeshComponent::StaticClass());
				for (int i = 0; i < MeshComponents.Num(); i++)
				{
					if (UStaticMeshComponent* MeshComponent = Cast<UStaticMeshComponent>(MeshComponents[i]))
					{
						MeshComponent->SetVectorParameterValueOnMaterials("PlayerPos", PlayerPos);
						MeshComponent->SetVectorParameterValueOnMaterials("PlayerPosFormer", PlayerPosInterp);
					}
				}
			}
			
			if (UKGEffectManager* EffectManager = UKGEffectManager::GetInstance(this))
			{
				UNiagaraComponent* NiagaraComponent = EffectManager->GetNiagaraComponentByNiagaraEffectId(EffectID);
				if (IsValid(NiagaraComponent))
				{
					FVector ActorRelativePos = Owner->GetActorTransform().InverseTransformPosition(FollowActor->GetActorLocation());
					FVector NiagaraRelativePos = NiagaraComponent->GetRelativeLocation();
					NiagaraRelativePos.X = FMath::Clamp(ActorRelativePos.X + NiagaraOffset, NiagaraOffset, TotalLength);
					NiagaraComponent->SetRelativeLocation(NiagaraRelativePos);
					if (NiagaraOffset <= NiagaraFadeDistance)
					{
						return;
					}
					if (ActorRelativePos.X + NiagaraOffset > TotalLength)
					{
						float Pos = ActorRelativePos.X - TotalLength + NiagaraOffset;
						float Percentage = FMath::Clamp((NiagaraOffset - NiagaraFadeDistance - Pos) / (NiagaraOffset - NiagaraFadeDistance) , 0.0f, 1.0f);
						NiagaraComponent->SetFloatParameter("Alpha", Percentage);
						NiagaraComponent->SetFloatParameter("SpawnRate", Percentage);
					}
				}
			}
		}
	}
}

void UBookCorridorComponent::InitBookCorridor(AActor* Player, float InInterpSpeed)
{
	c7_obj_check(Player);
	FollowActor = Player;
	InterpSpeed = InInterpSpeed;
	if (FollowActor.IsValid())
	{
		PrePlayerPos = FollowActor->GetActorLocation();
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("MainPlayer is null in UBookCorridorComponent::InitBookCorridor"));
		return;
	}
	SetComponentTickEnabled(true);
}

void UBookCorridorComponent::InitNiagaraComponent(int32 InEffectID, float Offset, float Length, float FadeDistance)
{
	EffectID = InEffectID;
	NiagaraOffset = Offset;
	TotalLength = Length;
	NiagaraFadeDistance = FadeDistance;
}
