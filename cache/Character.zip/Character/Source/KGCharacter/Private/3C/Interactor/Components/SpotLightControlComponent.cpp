// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Interactor/Components/SpotLightControlComponent.h"
#include "Components/SpotLightComponent.h"
#include "Engine/World.h"
#include "Kismet/KismetMathLibrary.h"

USpotLightControlComponent::USpotLightControlComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void USpotLightControlComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (!SpotLightComp.IsValid())
	{
		return;
	}

	// 聚光灯数值插值
	float CurrentTime = GetWorld()->GetTimeSeconds();
	if (CurrentTime - StartTime >= BlendTime)
	{
		StopBlend();
	}
	else
	{
		float BlendAlpha = (CurrentTime - StartTime) / BlendTime;
		SpotLightComp->SetIntensity(SourceIntensity + (TargetIntensity - SourceIntensity) * BlendAlpha);
		SpotLightComp->SetAttenuationRadius(SourceAttenuation + (TargetAttenuation - SourceAttenuation) * BlendAlpha);
		SpotLightComp->SetInnerConeAngle(SourceInnerConeAngle + (TargetInnerConeAngle - SourceInnerConeAngle) * BlendAlpha);
		SpotLightComp->SetOuterConeAngle(SourceOuterConeAngle + (TargetOuterConeAngle - SourceOuterConeAngle) * BlendAlpha);
	}

	// 聚光灯跟随插值
	if (FollowTarget.IsValid())
	{
		FVector CurrentLoc = SpotLightComp->GetComponentLocation();
		FVector TargetLoc = FollowTarget->GetActorLocation();
		FRotator LookAtRotator = UKismetMathLibrary::FindLookAtRotation(CurrentLoc, TargetLoc);
		SpotLightComp->SetWorldRotation(LookAtRotator);
	}

	if (!bInBlend && !FollowTarget.IsValid())
	{
		SetComponentTickEnabled(false);
	}
}

void USpotLightControlComponent::SetSpotLightComp(USpotLightComponent* InSpotLightComp)
{
	SpotLightComp = InSpotLightComp;
}

void USpotLightControlComponent::StartBlend(float InBlendTime, float InIntensity, float InAttenuation, float InInnerConeAngle, float InOuterConeAngle)
{
	if (!SpotLightComp.IsValid())
	{
		return;
	}
	
	if (bInBlend)
	{
		SpotLightComp->SetIntensity(TargetIntensity);
		SpotLightComp->SetAttenuationRadius(TargetAttenuation);
		SpotLightComp->SetInnerConeAngle(TargetInnerConeAngle);
		SpotLightComp->SetOuterConeAngle(TargetOuterConeAngle);
	}

	SourceIntensity = SpotLightComp->Intensity;
	SourceAttenuation = SpotLightComp->AttenuationRadius;
	SourceInnerConeAngle = SpotLightComp->InnerConeAngle;
	SourceOuterConeAngle = SpotLightComp->OuterConeAngle;

	TargetIntensity = InIntensity;
	TargetAttenuation = InAttenuation;
	TargetInnerConeAngle = InInnerConeAngle;
	TargetOuterConeAngle = InOuterConeAngle;

	StartTime = GetWorld()->GetTimeSeconds();
	BlendTime = FMath::IsNearlyZero(InBlendTime, 0.1f) ? 0.1f : InBlendTime;

	// 开始Tick
	bInBlend = true;
	SetComponentTickEnabled(true);
}

void USpotLightControlComponent::StopBlend()
{
	if (bInBlend)
	{
		SpotLightComp->SetIntensity(TargetIntensity);
		SpotLightComp->SetAttenuationRadius(TargetAttenuation);
		SpotLightComp->SetInnerConeAngle(TargetInnerConeAngle);
		SpotLightComp->SetOuterConeAngle(TargetOuterConeAngle);
	}

	bInBlend = false;
}

void USpotLightControlComponent::StartFollowTarget(class AActor* InFollowTarget)
{
	if (!IsValid(InFollowTarget))
	{
		return;
	}

	FollowTarget = InFollowTarget;
	SetComponentTickEnabled(true);
}

void USpotLightControlComponent::StopFollowTarget()
{
	FollowTarget.Reset();
}
