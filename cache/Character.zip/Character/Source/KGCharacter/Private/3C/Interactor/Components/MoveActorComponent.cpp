// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Interactor/Components/MoveActorComponent.h"
#include "Curves/CurveFloat.h"
#include "GameFramework/Actor.h"
#include "Components/SceneComponent.h"
#include "Manager/KGObjectActorManager.h"
#include "Misc/ObjCrashCollector.h"

UMoveActorComponent::UMoveActorComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UMoveActorComponent::BeginPlay()
{
	Super::BeginPlay();
	SetComponentTickEnabled(false);
}

void UMoveActorComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if ((int)EMoveActorMode::Rotate & (int)MoveMode)
	{
		TickRotateMode(DeltaTime);
	}
	if ((int)EMoveActorMode::RotateMesh & (int)MoveMode)
	{
		TickMeshRotateMode(DeltaTime);
	}
	if ((int)EMoveActorMode::TranslationMesh & (int)MoveMode)
	{
		TickMeshTranslationMode(DeltaTime);
	}
	if ((int)EMoveActorMode::TransformMesh & (int)MoveMode)
	{
		TickMeshTransformMode(DeltaTime);
	}
}

void UMoveActorComponent::TickRotateMode(float DeltaTime)
{
	MoveCurrentDeltaTime += DeltaTime;
	if (AActor* Owner = GetOwner())
	{
		bool bFinished = UpdateTargetRotateAngle();
		Owner->SetActorRotation(TargetRotator);
		if (bFinished)
		{
			SetActorRotateFinish();
		}
	}
}

bool UMoveActorComponent::UpdateTargetRotateAngle()
{
	bool bFinished = MoveCurrentDeltaTime >= MoveDuration || FMath::Abs(MoveDuration) <= UE_SMALL_NUMBER;
	
	float CurAngle;
	if (bFinished)
	{
		CurAngle = RotateAngleOffset + RotateFinalAngle;
	}
	else
	{
		CurAngle = RotateAngleOffset;
		if (IsValid(RotateCurve))
		{
			CurAngle += RotateCurve->GetFloatValue(MoveCurrentDeltaTime);
		}
		else
		{
			CurAngle += RotateInitAngle + (MoveCurrentDeltaTime / MoveDuration) * (RotateFinalAngle - RotateInitAngle);
		}
	}

	double& TargetAngle = RotateAxisType == EMoveActorRotateAxisType::Yaw ?
		TargetRotator.Yaw :
					(
						RotateAxisType == EMoveActorRotateAxisType::Pitch ?
						TargetRotator.Pitch :
						TargetRotator.Roll
					);
	TargetAngle = CurAngle;
	
	return bFinished;
}

void UMoveActorComponent::TickMeshRotateMode(float DeltaTime)
{
	MeshMoveCurrentDeltaTime += DeltaTime;
	USceneComponent* SceneComponent = Cast<USceneComponent>(UKGObjectActorManager::GetInstance(this)->GetObjectByID(RotateMeshID));
	if (!SceneComponent) {
		return;
	}
	FQuat DeltaRotation;
	if (MeshMoveCurrentDeltaTime < MeshMoveDuration && FMath::Abs(MeshMoveDuration) > UE_SMALL_NUMBER)
	{
		if (IsValid(MeshRotateCurve))
		{
			DeltaRotation = FQuat(MeshMoveRotateAxis, FMath::DegreesToRadians(MeshRotateCurve->GetFloatValue(MeshMoveCurrentDeltaTime)));
		}
		else
		{
			DeltaRotation = FQuat(MeshMoveRotateAxis, FMath::DegreesToRadians((MeshMoveCurrentDeltaTime / MeshMoveDuration) * MeshRotateAngle));
		}
		SceneComponent->SetWorldRotation(DeltaRotation * InitialMeshQuat);
	}
	else
	{
		DeltaRotation = FQuat(MeshMoveRotateAxis, FMath::DegreesToRadians(MeshRotateAngle));
		SceneComponent->SetWorldRotation(DeltaRotation * InitialMeshQuat);
		SetMeshRotateFinish();
	}

}

void UMoveActorComponent::TickMeshTranslationMode(float DeltaTime)
{
	if (MeshTranslationTasks.Num() <= 0)
	{
		MoveMode &= ~EMoveActorMode::TranslationMesh;
		if (MoveMode == EMoveActorMode::None)
		{
			SetComponentTickEnabled(false);
		}
		return;
	}
	for (int32 i = MeshTranslationTasks.Num() - 1; i >= 0; i--)
	{
		FMeshTranslationTask& Task = MeshTranslationTasks[i];
		Task.MeshTranslationCurrentDeltaTime += DeltaTime;
		USceneComponent* SceneComponent = Cast<USceneComponent>(UKGObjectActorManager::GetInstance(this)->GetObjectByID(Task.MeshID));
		if (!SceneComponent)
		{
			MeshTranslationTasks.RemoveAt(i);
			continue;
		}
		if (Task.MeshTranslationCurrentDeltaTime < Task.MeshTranslationDuration && FMath::Abs(Task.MeshTranslationDuration) > UE_SMALL_NUMBER)
		{
			FVector AddOffset;
			if (IsValid(Task.MeshTranslationCurve))
			{
				AddOffset = Task.MeshTranslationCurve->GetFloatValue(Task.MeshTranslationCurrentDeltaTime) * (Task.MeshTargetLocation - Task.MeshInitLocation);
			}
			else
			{
				AddOffset = (Task.MeshTranslationCurrentDeltaTime / Task.MeshTranslationDuration) * (Task.MeshTargetLocation - Task.MeshInitLocation);
			}
			SceneComponent->SetRelativeLocation(Task.MeshInitLocation + AddOffset);
		}
		else
		{
			SceneComponent->SetRelativeLocation(Task.MeshTargetLocation);
			int64 MeshID = Task.MeshID;
			MeshTranslationTasks.RemoveAt(i);
			SetMeshTranslationFinish(MeshID);
		}
	}
}

void UMoveActorComponent::TickMeshTransformMode(float DeltaTime)
{
	if (TransformMeshTasks.Num() <= 0)
	{
		MoveMode &= ~EMoveActorMode::TransformMesh;
		if (MoveMode == EMoveActorMode::None)
		{
			SetComponentTickEnabled(false);
		}
		return;
	}
	for (int32 i = TransformMeshTasks.Num() - 1; i >= 0; i--)
	{
		FTransformMeshTask& Task = TransformMeshTasks[i];
		Task.CurrentTime += DeltaTime;
		USceneComponent* SceneComponent = Cast<USceneComponent>(UKGObjectActorManager::GetInstance(this)->GetObjectByID(Task.MeshID));
		if (!SceneComponent)
		{
			TransformMeshTasks.RemoveAt(i);
			continue;
		}
		if (Task.CurrentTime < Task.Duration && FMath::Abs(Task.Duration) > UE_SMALL_NUMBER)
		{
			float Pivot = .0f;
			if (IsValid(Task.CurveFloat))
			{
				Pivot = FMath::Clamp(Task.CurveFloat->GetFloatValue(Task.CurrentTime / Task.Duration), .0f, 1.f);
			}
			else
			{
				Pivot = Task.CurrentTime / Task.Duration;
			}
			FTransform PivotTransform{};
			PivotTransform.SetLocation(FMath::Lerp(Task.InitTransform.GetLocation(), Task.TargetTransform.GetLocation(), Pivot));
			PivotTransform.SetRotation(FQuat::Slerp(Task.InitTransform.GetRotation(), Task.TargetTransform.GetRotation(), Pivot));
			PivotTransform.SetScale3D(FMath::Lerp(Task.InitTransform.GetScale3D(), Task.TargetTransform.GetScale3D(), Pivot));
			if (Task.bTransfromInWorldSpace)
			{
				SceneComponent->SetWorldTransform(PivotTransform);
			}
			else
			{
				SceneComponent->SetRelativeTransform(PivotTransform);
			}
		}
		else
		{
			if (Task.bTransfromInWorldSpace)
			{
				SceneComponent->SetWorldTransform(Task.TargetTransform);
			}
			else
			{
				SceneComponent->SetRelativeTransform(Task.TargetTransform);
			}
			int64 MeshID = Task.MeshID;
			TransformMeshTasks.RemoveAt(i);
		}
	}
}


void UMoveActorComponent::StartMoveByRotate(EMoveActorRotateAxisType AxisType, const float InitAngle, const float FinalAngle, const float AngleOffset, const float Duration, class UCurveFloat* CurveObject)
{
	RotateAxisType = AxisType;
	MoveDuration = Duration;
	MoveCurrentDeltaTime = 0.f;
	c7_obj_check(CurveObject);
	RotateCurve = CurveObject;
	RotateInitAngle = InitAngle;
	RotateFinalAngle = FinalAngle;
	RotateAngleOffset = AngleOffset;
	MoveMode |= EMoveActorMode::Rotate;
	if (AActor* Owner = GetOwner())
	{
		TargetRotator = Owner->GetActorRotation();
	}
	
	if (Duration > UE_SMALL_NUMBER)
	{
		SetComponentTickEnabled(true);
	}
	else
	{
		TickRotateMode(UE_SMALL_NUMBER);
	}
}

void UMoveActorComponent::SetActorRotateFinish()
{
	MoveMode &= ~EMoveActorMode::Rotate;
	if (MoveMode == EMoveActorMode::None) {
		SetComponentTickEnabled(false);
	}
	OnActorMoveFinish.Broadcast();
}

void UMoveActorComponent::StartMoveByRotateMesh(const int64& MeshID, const FVector& RotateAxis, const float RotateAngle, const float Duration, class UCurveFloat* CurveObject)
{
	AActor* Owner = GetOwner();
	if (!Owner) {
		return;
	}
	USceneComponent* SceneComponent = Cast<USceneComponent>(UKGObjectActorManager::GetInstance(this)->GetObjectByID(MeshID));
	if (!SceneComponent) {
		return;
	}
	MeshMoveDuration = FMath::Max(Duration, 0.1);
	if (Duration > 0.1)
	{
		RotateMeshID = MeshID;
		MoveMode |= EMoveActorMode::RotateMesh;
		MeshMoveCurrentDeltaTime = 0.f;
		MeshRotateAngle = RotateAngle;
		MeshMoveRotateAxis = RotateAxis;
		MeshRotateCurve = CurveObject;
		InitialMeshQuat = SceneComponent->GetComponentRotation().Quaternion();
		SetComponentTickEnabled(true);
	}
	else
	{
		SetMeshRotateFinish();
	}
}

void UMoveActorComponent::StartMoveByTranslationMesh(const int64& MeshID, const FVector& InitLocation, const FVector& TargetLocation, const float Duration, UCurveFloat* CurveObject)
{
	AActor* Owner = GetOwner();
	if (!Owner) {
		return;
	}
	USceneComponent* SceneComponent = Cast<USceneComponent>(UKGObjectActorManager::GetInstance(this)->GetObjectByID(MeshID));
	if (!SceneComponent) {
		return;
	}

	if (Duration > 0.1)
	{
		FMeshTranslationTask NewTask;
		NewTask.MeshTranslationDuration = FMath::Max(Duration, 0.1);
		NewTask.MeshID = MeshID;
		MoveMode |= EMoveActorMode::TranslationMesh;
		NewTask.MeshTranslationCurrentDeltaTime = 0.f;
		NewTask.MeshInitLocation = InitLocation;
		NewTask.MeshTargetLocation = TargetLocation;
		c7_obj_check(CurveObject);
		NewTask.MeshTranslationCurve = CurveObject;
		MeshTranslationTasks.Add(NewTask);
		SetComponentTickEnabled(true);
	}
	else
	{
		SetMeshTranslationFinish(MeshID);
	}
}

void UMoveActorComponent::StartMoveTransformMesh(const int64 MeshID, const FTransform& InitTransform, const FTransform& TargetTransform, const bool bTransfromInWorldSpace, const float Duration, const UCurveFloat* CurveObject)
{
	AActor* Owner = GetOwner();
	if (!Owner) {
		return;
	}
	USceneComponent* SceneComponent = Cast<USceneComponent>(UKGObjectActorManager::GetInstance(this)->GetObjectByID(MeshID));
	if (!SceneComponent) {
		return;
	}
	if (Duration > 0.1)
	{
		c7_obj_check(CurveObject);
		FTransformMeshTask TransformMeshTask;
		TransformMeshTask.MeshID = MeshID;
		TransformMeshTask.InitTransform = InitTransform;
		TransformMeshTask.TargetTransform = TargetTransform;
		TransformMeshTask.bTransfromInWorldSpace = bTransfromInWorldSpace;
		TransformMeshTask.Duration = Duration;
		TransformMeshTask.CurrentTime = .0f;
		TransformMeshTask.CurveFloat = CurveObject;
		MoveMode |= EMoveActorMode::TransformMesh;
		TransformMeshTasks.Add(TransformMeshTask);
		SetComponentTickEnabled(true);
	}
}


void UMoveActorComponent::SetMeshRotateFinish()
{
	MoveMode &= ~EMoveActorMode::RotateMesh;
	if (MoveMode == EMoveActorMode::None) {
		SetComponentTickEnabled(false);
	}
	OnMeshMoveFinish.Broadcast();
}

void UMoveActorComponent::SetMeshTranslationFinish(int64 MeshID)
{
	OnMeshTranslationFinish.Broadcast(MeshID);
	if (MeshTranslationTasks.Num() <= 0)
	{
		MoveMode &= ~EMoveActorMode::TranslationMesh;
		if (MoveMode == EMoveActorMode::None)
		{
			SetComponentTickEnabled(false);
		}
	}
}

void UMoveActorComponent::InterruptMove()
{
	MoveMode = EMoveActorMode::None;
	SetComponentTickEnabled(false);
}
