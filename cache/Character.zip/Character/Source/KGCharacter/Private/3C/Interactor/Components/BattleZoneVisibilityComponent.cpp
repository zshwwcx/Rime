#include "3C/Interactor/Components/BattleZoneVisibilityComponent.h"
#include "3C/Character/BaseCharacter.h"
#include "Manager/KGObjectActorManager.h"
#include "Components/MeshComponent.h"
#include "ProceduralMeshComponent.h"
#include "3C/Util/KGUtils.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Kismet/KismetRenderingLibrary.h"

struct BattleZoneSideParam
{
public:
	BattleZoneSideParam () = default;
	BattleZoneSideParam (const FVector& InStartLocation, const FVector& InDirection, const FVector& InNormal)
		: StartLocation (InStartLocation), Direction (InDirection), Normal (InNormal)
	{
		
	}
	FVector StartLocation;
	FVector Direction;
	FVector Normal;
};


UBattleZoneVisibilityComponent::UBattleZoneVisibilityComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UBattleZoneVisibilityComponent::BeginPlay()
{
	Super::BeginPlay();

	SetComponentTickEnabled(false);
}

void UBattleZoneVisibilityComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	AActor* OwningActor = GetOwner();
	if (OwningActor == nullptr)
	{
		return;
	}
	ABaseCharacter* MainPlayer = Cast<ABaseCharacter>(UKGObjectActorManager::GetInstance(this)->GetObjectByID(MainPlayerID));
	if (MainPlayer == nullptr)
	{
		return;
	}

	FVector PlayerPosition = MainPlayer->GetActorLocation();
	for (UActorComponent* Component : MeshComponents)
	{
		if (UMeshComponent* MeshComponent = Cast<UMeshComponent>(Component))
		{
			FVector MeshPosition = MeshComponent->GetComponentLocation();
			float Distance = FVector::Dist(PlayerPosition, MeshPosition);
			MeshComponent->SetVisibility(Distance <= VisibleDistance);

			MeshComponent->SetVectorParameterValueOnMaterials(MaterialParamName, PlayerPosition);
		}
	}

	if (ProceduralMeshComponent.IsValid())
	{
		for (int32 SectionIndex=0; SectionIndex<ProceduralMeshSectionLocations.Num(); SectionIndex++)
		{
			const FVector SectionPosition = ProceduralMeshSectionLocations[SectionIndex];
			float Distance = FVector::Dist(PlayerPosition, SectionPosition);
			ProceduralMeshComponent->SetMeshSectionVisible(SectionIndex, Distance <= VisibleDistance);
		}
		ProceduralMeshComponent->SetVectorParameterValueOnMaterials(MaterialParamName, PlayerPosition);
	}
}

int64 UBattleZoneVisibilityComponent::InitSphereProceduralMesh(int64 MaterialID,FName LengthParamName, float Radius, int32 SegmentNum, int32 SegmentHeight, bool bScaleUV, bool bUseNormalAndTangent)
{
	UMaterialInstanceDynamic* MaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(KGUtils::GetObjectByID(MaterialID));
	if (MaterialInstanceDynamic == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("InitSphereProceduralMesh material is in valid"));
		return KG_INVALID_ID;
	}
	if (Radius < UE_SMALL_NUMBER || SegmentNum <= 1 || SegmentHeight < 0)
	{
		UE_LOG(LogTemp, Error, TEXT("InitSphereProceduralMesh sphere params is wrong, Radius:%f, SegmentNum:%d, SegmentHeight:%d"), Radius, SegmentNum, SegmentHeight);
		return KG_INVALID_ID;
	}
	UProceduralMeshComponent* MeshComponent = FindOrAddProceduralMeshComponent();
	if (!MeshComponent)
	{
		UE_LOG(LogTemp, Error, TEXT("InitSphereProceduralMesh find or add UProceduralMeshComponent failed"));
		return KG_INVALID_ID;
	}
	
	FTransform ComponentToWorld = MeshComponent->GetComponentTransform();
	ProceduralMeshComponent = MeshComponent;
	ProceduralMeshSectionLocations.Empty();
	ProceduralMeshSectionLocations.Reserve(SegmentNum);

	float TotalLength = 0.f;
	// TArray<int32> Triangles = { 0,2,1, 1,2,0, 1,2,3, 3,2,1 };
	TArray<int32> Triangles = { 1,2,0, 1,2,3 };
    const float AngleStep = 2 * PI / SegmentNum;
	const float HalfHeight = SegmentHeight / 2;
    for (int32 SectionIdx = 0; SectionIdx < SegmentNum; ++SectionIdx)
    {  
    	TArray<FVector> Vertices;
    	TArray<FVector2D> UVs;
    	
        // 计算扇形两个极角
        const float CurAngle = SectionIdx * AngleStep;
        const float NextAngle = (SectionIdx + 1) * AngleStep;
 
        // 四个顶点
    	const float CurCos = Radius * FMath::Cos(CurAngle);
    	const float CurSin = Radius * FMath::Sin(CurAngle);
    	const float NextCos = Radius * FMath::Cos(NextAngle);
    	const float NextSin = Radius * FMath::Sin(NextAngle);
        FVector LeftTop(CurCos, CurSin, SegmentHeight);
        FVector RightTop(NextCos, NextSin, SegmentHeight);
        FVector LeftBottom(CurCos, CurSin, 0);
        FVector RightBottom(NextCos, NextSin, 0);
    	Vertices.Add(LeftTop);
    	Vertices.Add(RightTop);
    	Vertices.Add(LeftBottom);
    	Vertices.Add(RightBottom);
    	TotalLength += (LeftBottom - RightBottom).Size2D();
    	
    	TArray<FProcMeshTangent> Tangents;
    	TArray<FVector> Normals;
    	if (bUseNormalAndTangent)
    	{
    		Normals.Init(FVector(CurCos,CurSin,0), 4);
    		Tangents.Init(FProcMeshTangent(-CurSin,CurCos,0), 4);
    	}
    	else
    	{
    		Normals.Init(FVector(0,0,0), 4);
    		Tangents.Init(FProcMeshTangent(1,0,0), 4);
    	}
    	
    	FVector Center = ComponentToWorld.TransformPosition(FVector((CurCos+NextCos)/2, (CurSin+NextSin)/2, HalfHeight));
    	ProceduralMeshSectionLocations.Add(Center);

    	if (bScaleUV)
    	{
    		int32 i = SectionIdx+1;
    		float m = SegmentNum;
    		UVs.Add(FVector2D((i-1)/m,0)); // 0,0
    		UVs.Add(FVector2D(i/m,0));     // 1,0
    		UVs.Add(FVector2D((i-1)/m,1)); // 0,1
    		UVs.Add(FVector2D(i/m,1));     // 1,1
    		// DrawDebugString(GetWorld(), ComponentToWorld.TransformPosition(LeftTop), FString::Printf(TEXT("%.2f,%2d"), (i-1)/m,0), nullptr, FColor::Red, 60, false, 4);
    		// DrawDebugString(GetWorld(), ComponentToWorld.TransformPosition(RightTop), FString::Printf(TEXT("%.2f,%2d"), i/m,0), nullptr, FColor::Red, 60, false, 4);
    		// DrawDebugString(GetWorld(), ComponentToWorld.TransformPosition(LeftBottom), FString::Printf(TEXT("%.2f,%2d"), (i-1)/m,1), nullptr, FColor::Red, 60, false, 4);
    		// DrawDebugString(GetWorld(), ComponentToWorld.TransformPosition(RightBottom), FString::Printf(TEXT("%.2f,%2d"), i/m,1), nullptr, FColor::Red, 60, false, 4);
    	}
	    else
	    {
	    	UVs.Add(FVector2D(0, 0));
	    	UVs.Add(FVector2D(1, 0));
	    	UVs.Add(FVector2D(0, 1));
	    	UVs.Add(FVector2D(1, 1));
	    }
    	
    	// 创建section
    	MeshComponent->CreateMeshSection(SectionIdx, Vertices, Triangles, Normals, UVs, TArray<FColor>(), Tangents, false);
    	MeshComponent->SetMaterial(SectionIdx, MaterialInstanceDynamic);
    }
	
	if (!LengthParamName.IsNone() && TotalLength > UE_SMALL_NUMBER)
	{
		const float TotalLengthByCentimeter = TotalLength / 100.0f;
		MaterialInstanceDynamic->SetScalarParameterValue(LengthParamName, TotalLengthByCentimeter);
	}
	
	return KGUtils::GetIDByObject(MeshComponent);
}

int64 UBattleZoneVisibilityComponent::InitBoxProceduralMesh(int64 MaterialID, FName LengthParamName, float BoxExtentX, float BoxExtentY, int32 SegmentNum, int32 SegmentHeight, bool bScaleUV, bool bUseNormalAndTangent)
{
	UMaterialInstanceDynamic* MaterialInstanceDynamic = Cast<UMaterialInstanceDynamic>(KGUtils::GetObjectByID(MaterialID));
	if (MaterialInstanceDynamic == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("InitSphereProceduralMesh material is in valid"));
		return KG_INVALID_ID;
	}
	
	if (BoxExtentX <= UE_SMALL_NUMBER || BoxExtentY <= UE_SMALL_NUMBER || SegmentNum <= 1 || SegmentHeight < 0)
	{
		UE_LOG(LogTemp, Error, TEXT("InitBoxProceduralMesh box params is wrong, BoxExtentX:%f, BoxExtentY:%f, SegmentNum:%d, SegmentHeight:%d"), BoxExtentX, BoxExtentY, SegmentNum, SegmentHeight);
		return KG_INVALID_ID;
	}
	
	UProceduralMeshComponent* MeshComponent = FindOrAddProceduralMeshComponent();
	if (!MeshComponent)
	{
		UE_LOG(LogTemp, Error, TEXT("InitSphereProceduralMesh find or add UProceduralMeshComponent failed"));
		return KG_INVALID_ID;
	}
	
	FTransform ComponentToWorld = MeshComponent->GetComponentTransform();
	ProceduralMeshComponent = MeshComponent;
	ProceduralMeshSectionLocations.Empty();
	ProceduralMeshSectionLocations.Reserve(SegmentNum);
	
	const FVector BoxCenter = FVector(0, 0, 0);
	const FVector SegmentSize = FVector(BoxExtentX / SegmentNum * 2, BoxExtentY / SegmentNum * 2, 0);

	// 四条边对应的：起点、切线方向、法线方向
	TArray<BattleZoneSideParam> SideParams = {
		BattleZoneSideParam(BoxCenter + FVector(BoxExtentX, -BoxExtentY, 0), FVector(0,1,0), FVector(-1, 0, 0)),
		BattleZoneSideParam(BoxCenter + FVector(BoxExtentX, BoxExtentY, 0), FVector(-1,0,0), FVector(0, -1, 0)),
		BattleZoneSideParam(BoxCenter + FVector(-BoxExtentX, BoxExtentY, 0), FVector(0,-1,0), FVector(1, 0, 0)),
		BattleZoneSideParam(BoxCenter + FVector(-BoxExtentX, -BoxExtentY, 0), FVector(1,0,0), FVector(0, 1, 0)),
	};

	TArray<int32> Triangles = { 1,2,0, 1,2,3 };
	for (int32 Side = 0; Side <= 3; ++Side)
	{
		const auto& SideParam = SideParams[Side];
		const FVector& SideStart = SideParam.StartLocation;
		const FVector& SideDirection = SideParam.Direction;
		TArray<FProcMeshTangent> Tangents;
		TArray<FVector> Normals;
		if (bUseNormalAndTangent)
		{
			Normals.Init(SideParam.Normal, 4);
			Tangents.Init(FProcMeshTangent(SideDirection, false), 4);
		}
		else
		{
			Normals.Init(FVector(0,0,0), 4);
			Tangents.Init(FProcMeshTangent(1,0,0), 4);
		}
		
		for (int32 j=0; j < SegmentNum; ++j)
		{
			const int32 SectionIdx = Side * SegmentNum + j;
			
			TArray<FVector> Vertices;
			TArray<FVector2D> UVs;
			
			FVector BottomStart = SideStart + SideDirection * j * SegmentSize;
			FVector BottomEnd = BottomStart + SideDirection * SegmentSize;
			FVector TopStart = BottomStart + FVector(0, 0, SegmentHeight);
			FVector TopEnd = BottomEnd + FVector(0, 0, SegmentHeight);
			Vertices.Add(TopStart);
			Vertices.Add(TopEnd);
			Vertices.Add(BottomStart);
			Vertices.Add(BottomEnd);
    	
			FVector Center = ComponentToWorld.TransformPosition((BottomStart + TopEnd) / 2);
			ProceduralMeshSectionLocations.Add(Center);
			
			if (bScaleUV)
			{
				int32 i = SectionIdx+1;
				float m = 4 * SegmentNum;
				UVs.Add(FVector2D((i-1)/m,0)); // 0,0
				UVs.Add(FVector2D(i/m,0));		// 1,0
				UVs.Add(FVector2D((i-1)/m,1));	// 0,1
				UVs.Add(FVector2D(i/m,1));		// 1,1
			}
			else
			{
				UVs.Add(FVector2D(0, 0));
				UVs.Add(FVector2D(1, 0));
				UVs.Add(FVector2D(0, 1));
				UVs.Add(FVector2D(1, 1));
			}
			
			// 创建section
			MeshComponent->CreateMeshSection(SectionIdx, Vertices, Triangles, Normals, UVs, TArray<FColor>(), Tangents, false);
			MeshComponent->SetMaterial(SectionIdx, MaterialInstanceDynamic);
		}
	}
	
	float TotalLengthByCentimeter = ((BoxExtentX + BoxExtentY) * 2) / 100.0;
	if (!LengthParamName.IsNone() && TotalLengthByCentimeter > UE_SMALL_NUMBER)
	{
		MaterialInstanceDynamic->SetScalarParameterValue(LengthParamName, TotalLengthByCentimeter);
	}
	
	return KGUtils::GetIDByObject(MeshComponent);
}

class UProceduralMeshComponent* UBattleZoneVisibilityComponent::FindOrAddProceduralMeshComponent()
{
	if (AActor* Actor = Cast<AActor>(GetOwner()))
	{
		UProceduralMeshComponent* MeshComponent = nullptr;
		if (UActorComponent* ExistComponent = Actor->GetComponentByClass(UProceduralMeshComponent::StaticClass()))
		{
			MeshComponent = Cast<UProceduralMeshComponent>(ExistComponent);
		}
		if (MeshComponent == nullptr)
		{
			if (UActorComponent* ActorComponent = Actor->AddComponentByClass(UProceduralMeshComponent::StaticClass(), false, FTransform::Identity, false))
			{
				MeshComponent = Cast<UProceduralMeshComponent>(ActorComponent);
				if (MeshComponent)
				{
					if (USceneComponent* RootComponent = Actor->GetRootComponent())
					{
						MeshComponent->K2_AttachToComponent(RootComponent, "", EAttachmentRule::SnapToTarget, EAttachmentRule::SnapToTarget, EAttachmentRule::SnapToTarget, true);
						ULowLevelFunctions::EnableOverlapOptimization(MeshComponent, true);
#if WITH_EDITOR
						Actor->AddInstanceComponent(MeshComponent);
#endif // WITH_EDITOR						
					}
				}
			}
		}
		else
		{
			MeshComponent->ClearAllMeshSections();
			MeshComponent->ClearCollisionConvexMeshes();
		}
		return MeshComponent;
	}
	return nullptr;
}

void UBattleZoneVisibilityComponent::InitBattleZoneVisibilityCheck(int64 PlayerID, const FName& InMeshTag, float InVisibleDistance, const FName& InMaterialParamName, float TickInterval)
{
	SetComponentTickInterval(TickInterval);
	MainPlayerID = PlayerID;
	MeshTag = InMeshTag;
	VisibleDistance = InVisibleDistance;
	MaterialParamName = InMaterialParamName;

	AActor* OwningActor = GetOwner();
	if (OwningActor == nullptr)
	{
		return;
	}
	MeshComponents = OwningActor->GetComponentsByTag(UMeshComponent::StaticClass(), MeshTag);

	SetComponentTickEnabled(true);
}

