// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Interactor/Components/SplineMoveComponent.h"

#include "3C/Character/BaseCharacter.h"
#include "3C/Character/C7Actor.h"
#include "3C/Character/LuaActorBase.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/World.h"


USplineMoveComponent::USplineMoveComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void USplineMoveComponent::BeginPlay()
{
	Super::BeginPlay();
}

void USplineMoveComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (!bEnableMove)
	{
		return;
	}

	ProcessSplineMove(DeltaTime);
}

void USplineMoveComponent::InitMoveParams(double InitialSpeed, const TArray<FVector>& SplinePoints, bool InCycle, bool InPauseOnIndexChange,
	const TArray<double>& SpeedTargets, const TArray<double>& SpeedPeriods, bool bOnlyChangeYaw)
{
	if (SpeedTargets.Num() != SpeedPeriods.Num())
	{
		return;
	}

	bPauseOnIndexChange = InPauseOnIndexChange;
	bCycle = InCycle;
	CSpeed = InitialSpeed;
	DistanceAlongSpline = 0;
	CIndex = 0;
	CSpeedTimeAnchor = 0;
	CSpeedValueAnchor = 0;
	bKeepPitchRoll = bOnlyChangeYaw;

	// 构建SplineSpeed
	for (int32 Index = 0; Index < SpeedTargets.Num(); ++Index)
	{
		SplineMoveSpeeds.Add(FSplineMoveSpeed(SpeedTargets[Index], SpeedPeriods[Index]));
	}

	// 构建Spline
	ClearSplinePoints();
	for (auto& SplinePoint : SplinePoints)
	{
		AddSplinePoint(SplinePoint, ESplineCoordinateSpace::World);
	}
	SetClosedLoop(bCycle);

	// 构建Distances
	for (int32 Index = 1; Index < SplinePoints.Num(); ++Index)
	{
		Distances.Add(GetDistanceAlongSplineAtLocation(SplinePoints[Index], ESplineCoordinateSpace::World));
	}
	Distances.Add(GetSplineLength());
}

void USplineMoveComponent::InnerStartSplineMove()
{
	bEnableMove = true;
	if (AC7Actor* C7Actor = Cast<AC7Actor>(GetOwner()))
	{
		ACTOR_CALL_LUA_ENTITY(C7Actor, "KCB_NotifySplineMoveIndexChanged", CIndex);
	}
	else if (ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(GetOwner()))
	{
		ACTOR_CALL_LUA_ENTITY(BaseCharacter, "KCB_NotifySplineMoveIndexChanged", CIndex);
	}
}

void USplineMoveComponent::InnerStopSplineMove()
{
	bEnableMove = false;
}

void USplineMoveComponent::InnerPauseSplineMove()
{
	bEnableMove = false;
}

void USplineMoveComponent::InnerResumeSplineMove()
{
	bEnableMove = true;
}

void USplineMoveComponent::InnerRestartSplineMove()
{
	DistanceAlongSpline = 0;
	CIndex = 0;
	InnerStartSplineMove();
}

void USplineMoveComponent::ProcessSplineMove(float DeltaTime)
{
	AActor* OwnerActor = GetOwner();
	if (!IsValid(OwnerActor))
	{
		InnerStopSplineMove();
		return;
	}
	
	if (SplineMoveSpeeds.IsValidIndex(CIndex) == false || Distances.IsValidIndex(CIndex) == false)
	{
		return;
	}

	FSplineMoveSpeed CSplineMoveSpeed = SplineMoveSpeeds[CIndex];
	if (CSplineMoveSpeed.SpeedTarget > 0)
	{
		const double SpeedTimeDelta = GetWorld()->GetTimeSeconds() - CSpeedTimeAnchor;
		const float Alpha = SpeedTimeDelta / (CSplineMoveSpeed.SpeedPeriod > 0.1f ? CSplineMoveSpeed.SpeedPeriod : 0.1f);
		if (Alpha > 1)
		{
			CSpeed = CSplineMoveSpeed.SpeedTarget;
		}
		else
		{
			const float SpeedDelta = (CSplineMoveSpeed.SpeedTarget - CSpeedValueAnchor) * Alpha;
			CSpeed = CSpeedValueAnchor + SpeedDelta;
		}
	}

	DistanceAlongSpline += CSpeed * DeltaTime;

	// 计算Index是否需要更新
	if (DistanceAlongSpline > Distances[CIndex])
	{
		ChangeSplineMoveIndex();
	}

	// 设置当前位置
	const FVector Location = GetLocationAtDistanceAlongSpline(DistanceAlongSpline, ESplineCoordinateSpace::World);
	FRotator Rotation = GetRotationAtDistanceAlongSpline(DistanceAlongSpline, ESplineCoordinateSpace::World);
	if (bKeepPitchRoll)
	{
		const FRotator PlayerRotation = OwnerActor->GetActorRotation();
		Rotation.Pitch = PlayerRotation.Pitch;
		Rotation.Roll = PlayerRotation.Roll;
	}
	const FTransform NextTransform(Rotation.Quaternion(), Location);
	OwnerActor->SetActorTransform(NextTransform, false, nullptr, ETeleportType::ResetPhysics);
}

void USplineMoveComponent::ChangeSplineMoveIndex()
{
	CSpeedTimeAnchor = GetWorld()->GetTimeSeconds();
	CSpeedValueAnchor = CSpeed;

	if (CIndex >= Distances.Num() - 1)
	{
		if (bCycle)
		{
			DistanceAlongSpline = 0;
			CIndex = 0;	
		}
		else
		{
			InnerStopSplineMove();
		}
	}
	else
	{
		++CIndex;
	}

	// 第一段不会pause
	if (bPauseOnIndexChange && CIndex > 0)
	{
		InnerPauseSplineMove();
	}

	if (AC7Actor* C7Actor = Cast<AC7Actor>(GetOwner()))
	{
		ACTOR_CALL_LUA_ENTITY(C7Actor, "KCB_NotifySplineMoveIndexChanged", CIndex);
	}
	else if (ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(GetOwner()))
	{
		ACTOR_CALL_LUA_ENTITY(BaseCharacter, "KCB_NotifySplineMoveIndexChanged", CIndex);
	}
}
