// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Interactor/Components/CardScrollComponent.h"
#include "Engine/World.h"
#include "Components/TimelineComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Curves/CurveFloat.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Manager/KGObjectActorManager.h"
#include "Kismet/KismetMathLibrary.h"

// UE_DISABLE_OPTIMIZATION

UCardScrollComponent::UCardScrollComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UCardScrollComponent::BeginPlay()
{
	Super::BeginPlay();
	SetComponentTickEnabled(false);
	// OpacityCurve = LoadObject<UCurveFloat>(this, TEXT("/Game/Blueprint/RolePlayDisplay/CardOpacityCurve.CardOpacityCurve"));
}

void UCardScrollComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// 展开、折叠或脚本强设状态
	if ( (CollapseTimeLine.IsValid() && CollapseTimeLine->IsPlaying()) || (ExpandTimeLine.IsValid() && ExpandTimeLine->IsPlaying())
		|| CardWaveHide_ScriptFlag )
	{
		SetCardWaveHiddenInGame(true);
		return;
	}
	
	if (!bInTouch && bEnableScroll)
	{
		int32 &ScheduleTo = ScrollStatus.ScheduleTo;
		float &Velocity = ScrollStatus.Velocity;
		if (ScheduleTo != -1)
		{
			float CurIndex = GetKeyFromIndex(ScheduleTo);
			float DistanceToHalf = FMath::Abs(CurIndex - 0.5);
			if (DistanceToHalf <  UE_SMALL_NUMBER )
			{
				ScheduleTo = -1;
				OnFocus();
			}
			else if (CurIndex > 0.5)
			{
				Scroll(-FMath::Max(0.1, DistanceToHalf) * DeltaTime * 8000);
			}
			else
			{
				Scroll(-FMath::Max(0.1, DistanceToHalf) * DeltaTime * 8000);
			}
			SetCardWaveHiddenInGame(true);
		}
		else if (FMath::Abs(Velocity) > UE_SMALL_NUMBER)
		{
			Scroll(Velocity * DeltaTime * 10);
			// 匀减速, 但如果速度过小时经过某个可停靠位置，就直接停下
			if (FMath::Abs(Velocity) < 20.0 * ScrollParams.Damping)
			{
				if (FMath::Abs(FMath::Fmod((ScrollParams.CardNum + 1) * ScrollStatus.Anchor, 1.f)) < UE_SMALL_NUMBER)
				{
					Velocity = 0.f;
					OnFocus();
				}
			}
			else if (Velocity > 0)
			{
				Velocity -= 3.0 * ScrollParams.Damping;
			}
			else
			{
				Velocity += 3.0 * ScrollParams.Damping;
			}
			SetCardWaveHiddenInGame(true);
		}
		else if (ScrollParams.CardNum > 0)
		{
			const int32 CardNum = ScrollParams.CardNum;
			const float Anchor = ScrollStatus.Anchor;
			if (! (FMath::Abs(FMath::Fmod(Anchor * (CardNum + 1), 1.0f)) < UE_SMALL_NUMBER) )
			{
				if (FMath::Fmod(Anchor * (CardNum + 1), 1.0f) < 0.5)
				{
					Velocity = -20 * ScrollParams.Damping;
				}
				else
				{
					Velocity = 20 * ScrollParams.Damping;
				}
				SetCardWaveHiddenInGame(true);
			}
			else
			{
				SetCardWaveHiddenInGame(false);
			}
		}
		
	}
	else if (bEnableScroll)
	{
		if (FMath::Abs(FMath::Fmod(ScrollStatus.Anchor * (ScrollParams.CardNum + 1), 1.0f) ) < UE_SMALL_NUMBER)
		{
			SetCardWaveHiddenInGame(true);
		}
	}
	// UE_LOG(LogTemp, Log, TEXT("Scroll tick, Velocity=%f"), ScrollParams.Velocity);
	
}

void UCardScrollComponent::InitCards(class UCurveFloat* CurveObject, const TArray<FRolePlayCardActorInfo>& ChildActorList)
{
	OpacityCurve = CurveObject;
	if (AActor* Owner = GetOwner())
	{
		ChildCardActors.Empty();
		for (int32 Index=0; Index<ChildActorList.Num(); ++Index)
		{
			const auto& ActorInfo = ChildActorList[Index];
			const int64& ActorID = ActorInfo.ActorID;
			UKGObjectActorManager* UOAM = UKGObjectActorManager::GetInstance(this);
			if (UOAM)
			{
				if (UObject* UObj = UOAM->GetObjectByID(ActorID))
				{
					if (AActor* ChildActor = Cast<AActor>(UObj))
					{
						ChildActor->AttachToActor(Owner, FAttachmentTransformRules::KeepRelativeTransform);
						ChildCardActors.Add(ActorInfo);
					}
				}
			}
		}
	}
}

void UCardScrollComponent::RefreshCardInfo(const TMap<int32, int32>& DataIndexMap)
{
	ScrollStatus.Anchor = 0.f;
	int32 ChildNum = ChildCardActors.Num();
	for (const auto& Elem : DataIndexMap)
	{
		int32 ChildIndex = Elem.Key;
		if (ChildIndex>=0 && ChildIndex<ChildNum)
		{
			auto& CardActorInfo = ChildCardActors[ChildIndex];
			CardActorInfo.DataIndex = Elem.Value;
		}
	}
}

void UCardScrollComponent::DisableScroll()
{
	OnTimeLineFinishedDispatcher.Clear();
	OnCardWaveHiddenChangeDispatcher.Clear();
	OnCardScrollFocus.Clear();
	OnCardSlideAudio.Clear();
	OnCardScrollBehind.Clear();
	ChildCardActors.Empty();
	ResetScrollStatus(-1, 0.f, 0.f);
}

void UCardScrollComponent::EnableScroll(const FString& ExpandTimeLineName, const FString& CollapseTimeLineName)
{
	AActor* Owner = GetOwner();
	if (Owner)
	{
		TArray<UActorComponent*> Comps = Owner->K2_GetComponentsByClass(UTimelineComponent::StaticClass());
		for (UActorComponent* Comp : Comps)
		{
			if (UTimelineComponent* TimelineComponent = Cast<UTimelineComponent>(Comp))
			{
				FString CompName = TimelineComponent->GetName();
				if (CompName.Equals(ExpandTimeLineName, ESearchCase::IgnoreCase))
				{
					ExpandTimeLine = TimelineComponent;
					FScriptDelegate UpdateDelegate;
					UpdateDelegate.BindUFunction(this, "UpdateExpandTimeLine");
					ExpandTimeLine->SetTimelinePostUpdateFunc(FOnTimelineEvent(UpdateDelegate));
					TSet<UCurveBase*> AllCurves;
					TimelineComponent->GetAllCurves(AllCurves);
					for (UCurveBase* CurveBase : AllCurves)
					{
						if (UCurveFloat* FloatCurve = Cast<UCurveFloat>(CurveBase))
						{
							ExpandCurve = FloatCurve;
						}
					}
					
					FScriptDelegate FinishedDelegate;
					FinishedDelegate.BindUFunction(this, "OnExpandTimeLineFinished");
					ExpandTimeLine->SetTimelineFinishedFunc(FOnTimelineEvent(FinishedDelegate));
				}
				else if (CompName.Equals(CollapseTimeLineName, ESearchCase::IgnoreCase))
				{
					CollapseTimeLine = TimelineComponent;
					FScriptDelegate UpdateDelegate;
					UpdateDelegate.BindUFunction(this, "UpdateCollapseTimeLine");
					CollapseTimeLine->SetTimelinePostUpdateFunc(FOnTimelineEvent(UpdateDelegate));
					
					TSet<UCurveBase*> AllCurves;
					TimelineComponent->GetAllCurves(AllCurves);
					for (UCurveBase* CurveBase : AllCurves)
					{
						if (UCurveFloat* FloatCurve = Cast<UCurveFloat>(CurveBase))
						{
							CollapseCurve = FloatCurve;
						}
					}
				}
			}
		}
	}
}

void UCardScrollComponent::UpdateExpandTimeLine()
{
	if (UKGObjectActorManager* UOAM = UKGObjectActorManager::GetInstance(this))
	{
		float CurrentKey = 0.f;
		if (ExpandTimeLine.IsValid())
		{
			const float Position = ExpandTimeLine->GetPlaybackPosition();
			if (ExpandCurve.IsValid())
			{
				CurrentKey = ExpandCurve.Get()->GetFloatValue(Position);
			}
		}
		
		for (int32 Index=0; Index<ChildCardActors.Num(); ++Index)
		{
			auto& ActorInfo = ChildCardActors[Index];
			if (UObject* UObj = UOAM->GetObjectByID(ActorInfo.ActorID))
			{
				if (AActor* ChildActor = Cast<AActor>(UObj))
				{
					float Key = GetKeyFromIndex(Index);
					FTransform Transform;
					float Opacity = 0.f;
					// UE_LOG(LogTemp, Log, TEXT("UpdateExpandTimeLine, Key=%f"), Key);	
					GetKeyTransform(Key * (1 - CurrentKey), Transform, Opacity);
					// UE_LOG(LogTemp, Log, TEXT("UpdateExpandTimeLine, Opacity=%f"), Opacity);
					if (USceneComponent* RootComponent = ChildActor->GetRootComponent())
					{
						RootComponent->SetRelativeTransform(Transform);
						SetChildActorOpacity(UOAM, ActorInfo, Opacity);
					}
				}
			}
		}
	}
}

void UCardScrollComponent::OnExpandTimeLineFinished()
{
	OnTimeLineFinishedDispatcher.Broadcast();
}

void UCardScrollComponent::UpdateCollapseTimeLine()
{
	if (UKGObjectActorManager* UOAM = UKGObjectActorManager::GetInstance(this))
	{
		float CurrentKey = 0.f;
		if (CollapseTimeLine.IsValid())
		{
			const float Position = CollapseTimeLine->GetPlaybackPosition();
			if (CollapseCurve.IsValid())
			{
				CurrentKey = CollapseCurve.Get()->GetFloatValue(Position);
			}
		}
		
		// UE_LOG(LogTemp, Log, TEXT("UpdateCollapseTimeLine. CurrentKey=%f"), CurrentKey);	
		
		for (int32 Index=0; Index<ChildCardActors.Num(); ++Index)
		{
			auto& ActorInfo = ChildCardActors[Index];
			if (UObject* UObj = UOAM->GetObjectByID(ActorInfo.ActorID))
			{
				if (AActor* ChildActor = Cast<AActor>(UObj))
				{
					float Key = GetKeyFromIndex(Index);
					FTransform Transform;
					float Opacity = 0.f;
					float TransformKey = Key + 1 - CurrentKey;
					if (TransformKey < 0)
					{
						TransformKey = FMath::Fmod(TransformKey + 1, 1.0f);
					}
					else
					{
						TransformKey = FMath::Fmod(TransformKey, 1.0f);
					}
					GetKeyTransform(TransformKey, Transform, Opacity);
					if (USceneComponent* RootComponent = ChildActor->GetRootComponent())
					{
						RootComponent->SetRelativeTransform(Transform);
						if (FMath::Abs(FMath::Floor(Key + 1 - CurrentKey )) <= UE_SMALL_NUMBER)
						{
							SetChildActorOpacity(UOAM, ActorInfo, Opacity);
						}
						else
						{
							SetChildActorOpacity(UOAM, ActorInfo, 0.f);
						}
					}
				}
			}
		}
	}
}

void UCardScrollComponent::StartExpand()
{
	EndCollapse();
	if (ExpandTimeLine.IsValid())
	{
		ExpandTimeLine.Get()->PlayFromStart();
	}
}

void UCardScrollComponent::EndExpand()
{
	if (ExpandTimeLine.IsValid())
	{
		ExpandTimeLine.Get()->Stop();
	}
}

void UCardScrollComponent::StartCollapse()
{
	ScrollStatus.ScheduleTo = -1;
	ScrollStatus.Velocity = 0.f;
	ScrollStatus.Anchor = UKismetMathLibrary::SafeDivide(FMath::Floor((ScrollParams.CardNum + 1) * ScrollStatus.Anchor) * 1.0, ScrollParams.CardNum + 1);
	EndExpand();
	if (CollapseTimeLine.IsValid())
	{
		CollapseTimeLine.Get()->PlayFromStart();
	}
}

void UCardScrollComponent::EndCollapse()
{
	if (CollapseTimeLine.IsValid())
	{
		CollapseTimeLine.Get()->Stop();
	}
}


void UCardScrollComponent::EnableScrollTick(const bool bEnable)
{
	SetComponentTickEnabled(bEnable);
	
}

void UCardScrollComponent::SetCardWaveHiddenFlag(uint8 flag)
{
	CardWaveHide_ScriptFlag = flag;
}

void UCardScrollComponent::ResetScrollStatus(int32 ScheduleTo, float Velocity, float Anchor)
{
	ScrollStatus.ScheduleTo = ScheduleTo;
	ScrollStatus.Velocity = Velocity;
	ScrollStatus.Anchor = Anchor;
}

void UCardScrollComponent::SetTouchFlag(bool bTouch)
{
	bInTouch = bTouch;
}

void UCardScrollComponent::SetEnableScrollFlag(bool bInEnableScroll)
{
	bEnableScroll = bInEnableScroll;
}

float UCardScrollComponent::GetKeyFromIndex(int32 Index) const
{
	float Key = UKismetMathLibrary::SafeDivide(Index, ScrollParams.CardNum + 1) + ScrollStatus.Anchor;
	if ( Key < 1.0 )
	{
		return Key;
	}
	return FMath::Fmod(Key, 1.0f);
}

void UCardScrollComponent::GetKeyTransform(float Angle, FTransform& OutTransform, float& OutCurveValue) const
{
	int32 CardNum = ScrollParams.CardNum;
	float EllipseRightLength = ScrollParams.EllipseRightLength;
	float EllipseForwardLength = ScrollParams.EllipseForwardLength;

	float ConvertedAngle = UE_PI * (UKismetMathLibrary::SafeDivide(Angle, CardNum - 5) * (CardNum + 1) + UKismetMathLibrary::SafeDivide(CardNum - 11, 2 * (CardNum - 5)));
	FVector RelativeLocation;
	RelativeLocation.X = -FMath::Sin(ConvertedAngle) * EllipseRightLength;
	RelativeLocation.Y = -FMath::Cos(ConvertedAngle) * EllipseForwardLength;
	RelativeLocation.Z = 0;

	FRotator RelativeRotation;
	RelativeRotation.Roll = 0;
	RelativeRotation.Pitch = 0;
	float _Upper = EllipseRightLength * FMath::Cos(ConvertedAngle);
	float _Down = FMath::Sqrt(
		EllipseRightLength * EllipseRightLength * FMath::Cos(ConvertedAngle) * FMath::Cos(ConvertedAngle) +
		EllipseForwardLength * EllipseForwardLength * FMath::Sin(ConvertedAngle) * FMath::Sin(ConvertedAngle)
	);
	RelativeRotation.Yaw = FMath::Acos(UKismetMathLibrary::SafeDivide(_Upper, _Down)) * 180 / UE_PI;
	
	if (-FMath::Sin(ConvertedAngle) > 0)
		RelativeRotation.Yaw = FMath::Abs(RelativeRotation.Yaw) + 180;
	else
		RelativeRotation.Yaw = -FMath::Abs(RelativeRotation.Yaw) + 180;

	float CharacterScale = ScrollParams.CharacterScale;
	FVector RelativeScale(CharacterScale, CharacterScale, CharacterScale);
	if (FMath::Abs(Angle - 0.5) < UKismetMathLibrary::SafeDivide(1, CardNum + 1))
	{
		float Scale = (CardNum + 1) * CharacterScale *
		(FMath::Abs(Angle - 0.5) * 1 + (UKismetMathLibrary::SafeDivide(1, CardNum + 1) - FMath::Abs(Angle - 0.5)) * ScrollParams.ScaleMultiplier);
		RelativeScale.X = Scale;
		RelativeScale.Y = Scale;
		RelativeScale.Z = Scale;
	}
	OutTransform = FTransform(RelativeRotation, RelativeLocation, RelativeScale);
	if (IsValid(OpacityCurve))
	{
		OutCurveValue = OpacityCurve->GetFloatValue((ConvertedAngle * 180 / UE_PI));
	}
}

bool UCardScrollComponent::IsInExpandOrCollapse() const
{
	return (CollapseTimeLine.IsValid() && CollapseTimeLine->IsPlaying()) || (ExpandTimeLine.IsValid() && ExpandTimeLine->IsPlaying());
}

void UCardScrollComponent::ScrollToActor(AActor* TargetActor)
{
	if (ScrollStatus.ScheduleTo != -1) return;
	
	if ( (CollapseTimeLine.IsValid() && CollapseTimeLine->IsPlaying()) || (ExpandTimeLine.IsValid() && ExpandTimeLine->IsPlaying())
		|| CardWaveHide_ScriptFlag ) return;

	if (UKGObjectActorManager* UOAM = UKGObjectActorManager::GetInstance(this))
	{
		if (int64 TargetActorID = UOAM->GetIDByObejct(TargetActor))
		{
			for (int32 Index=0; Index<ChildCardActors.Num(); ++Index)
			{
				const auto& ActorInfo = ChildCardActors[Index];
				if (ActorInfo.ActorID == TargetActorID)
				{
					ScrollStatus.ScheduleTo = ActorInfo.DataIndex;
					break;
				}
			}
		}
	}
	
}

void UCardScrollComponent::SetChildActorOpacity(UKGObjectActorManager* UOAM, const FRolePlayCardActorInfo& ActorInfo, float Opacity)
{
	for (const auto& CompInfo : ActorInfo.OpacityUpdateCompValues)
	{
		if (UObject* UObj = UOAM->GetObjectByID(CompInfo.Key))
		{
			if (UMeshComponent* MeshComponent = Cast<UMeshComponent>(UObj))
			{
				if (UMaterialInterface* MaterialInterface = MeshComponent->GetMaterial(0))
				{
					if (UMaterialInstanceDynamic* MaterialDynamicInstance = Cast<UMaterialInstanceDynamic>(MaterialInterface))
					{
						MaterialDynamicInstance->SetScalarParameterValue(CompInfo.Value, Opacity);
					}
				}

			}
		}
	}
}

int32 UCardScrollComponent::GetCenterDataIndex()
{
	for (int32 Index=0; Index<ChildCardActors.Num(); ++Index)
	{
		auto& ActorInfo = ChildCardActors[Index];
		float Key = GetKeyFromIndex(Index);
		if (FMath::Abs(Key - 0.5) <= UE_SMALL_NUMBER)
		{
			return ActorInfo.DataIndex;
		}
		// if (UObject* UObj = UOAM->GetObjectByID(ActorInfo.ActorID))
		// {
		// 	if (AActor* ChildActor = Cast<AActor>(UObj))
		// 	{
		// 		float Key = GetKeyFromIndex(Index);
		// 		if (FMath::Abs(Key - 0.5) <= UE_SMALL_NUMBER)
		// 		{
		// 			if (USceneComponent* RootComponent = ChildActor->GetRootComponent())
		// 			{
		// 				if (FProperty* IndexProperty = ChildActor->GetClass()->FindPropertyByName("DataIndex"))
		// 				{
		// 					if (int32 *DataIndex = IndexProperty->ContainerPtrToValuePtr<int32>(Actor))
		// 					{
		// 						return *DataIndex;
		// 					}
		// 				}
		// 			}
		// 		}
		// 	}
		// }
	}
	return -1;
}

void UCardScrollComponent::SetCardWaveHiddenInGame(const bool bHide)
{
	if (bHide != bCardWaveHiddenInGame)
	{
		bCardWaveHiddenInGame = bHide;
		OnCardWaveHiddenChangeDispatcher.Broadcast(bHide);
	}
}

void UCardScrollComponent::OnFocus()
{
	ScrollStatus.Velocity = 0.f;

	int32 CenterIndex = GetCenterDataIndex();
	if (CenterIndex != -1)
	{
		OnCardScrollFocus.Broadcast(CenterIndex);
	}
}

void UCardScrollComponent::FinishScrollTouch()
{
	SetTouchFlag(false);
	if (IsInExpandOrCollapse()) return;
	
	InteriaSampleIndex = 1;
	const int32 SampleNum = VelocitySamples.Num();
	if (SampleNum <= 0)
	{
		ScrollStatus.Velocity = 0.f;
	}
	else
	{
		float ScrollVelocity = 0.f;
		for (const auto& Sample: VelocitySamples)
		{
			const float CurSeconds = GetWorld()->GetTimeSeconds();
			const float DeltaSeconds = CurSeconds - Sample.Timestamp;
			if (DeltaSeconds < InertiaSampleTimeOut * InertiaSampleNum)
			{
				ScrollVelocity += Sample.Delta;
			}
		}
		ScrollVelocity = UKismetMathLibrary::SafeDivide(ScrollVelocity, SampleNum) * 5.0;
		ScrollVelocity = FMath::Abs(ScrollVelocity) < 20.f ? 0 : ScrollVelocity;
		ScrollStatus.Velocity = FMath::Max(FMath::Min(ScrollVelocity, 200), -200);
		VelocitySamples.Empty();
	}
}


void UCardScrollComponent::BeginScrollTouch()
{
	SetTouchFlag(true);
	if (IsInExpandOrCollapse()) return;
	InteriaSampleIndex = 1;
	ScrollStatus.ScheduleTo = -1;
	ScrollStatus.Velocity = 0.f;
}

void UCardScrollComponent::ScrollList(float Distance)
{
	if (IsInExpandOrCollapse()) return;
	
	Scroll(Distance);

	int32 SampleNum = VelocitySamples.Num();
	if (SampleNum < InertiaSampleNum)
	{
		VelocitySamples.Add(FRolePlayCardScrollVelocitySample(GetWorld()->GetTimeSeconds(), Distance/2));
	}
	else
	{
		auto& Sample = VelocitySamples[SampleNum-1];
		Sample.Timestamp = GetWorld()->GetTimeSeconds();
		Sample.Delta = Distance;
		InteriaSampleIndex = InteriaSampleIndex % 10 + 1;
	}
}

void UCardScrollComponent::Scroll(float ScrollDelta)
{
	// UE_LOG(LogTemp, Log, TEXT("Scroll cpp, ScrollDelta=%f"), ScrollDelta);
	
	float ConvertedDelta = (ScrollDelta > 25.0 ? 25.0 : (ScrollDelta < -25.0 ? -25.0 : ScrollDelta)) * 0.0005;
	float DeltaForFrame;
	float &Anchor = ScrollStatus.Anchor;
	// UE_LOG(LogTemp, Log, TEXT("Scroll cpp, Anchor1=%f"), Anchor);
	int CardNumPlusOne = FMath::Max(ScrollParams.CardNum + 1, 1);
	if (FMath::Fmod(FMath::Abs((ScrollParams.CardNum + 1) * Anchor), 1.0) <= UE_SMALL_NUMBER)
	{
		DeltaForFrame = Anchor + ConvertedDelta;
	}
	else if ( (Anchor + ConvertedDelta) <= (( FMath::Floor((ScrollParams.CardNum + 1) * Anchor)) / CardNumPlusOne) )
	{
		DeltaForFrame = FMath::Floor((ScrollParams.CardNum + 1) * Anchor) / CardNumPlusOne;
		// Game.AkAudioManager:PostEvent2D("Play_UI_Menu_Perform_CardSlide")
		OnCardSlideAudio.Broadcast();
	}
	else if ( (Anchor + ConvertedDelta) >= (( FMath::Floor((ScrollParams.CardNum + 1) * Anchor) + 1) / CardNumPlusOne) )
	{
		DeltaForFrame = (( FMath::Floor((ScrollParams.CardNum + 1) * Anchor) + 1) / CardNumPlusOne);
		// Game.AkAudioManager:PostEvent2D("Play_UI_Menu_Perform_CardSlide")
		OnCardSlideAudio.Broadcast();
	}
	else
	{
		DeltaForFrame = Anchor + ConvertedDelta;
	}
	// UE_LOG(LogTemp, Log, TEXT("Scroll cpp, DeltaForFrame=%f"), DeltaForFrame);	
	if (DeltaForFrame < 0)
	{
		Anchor = FMath::Fmod(DeltaForFrame+1, 1.0f);
	}
	else
	{
		Anchor = FMath::Fmod(DeltaForFrame, 1.0f);
	}
	// UE_LOG(LogTemp, Log, TEXT("Scroll cpp, Anchor2=%f"), Anchor);	

	if (UKGObjectActorManager* UOAM = UKGObjectActorManager::GetInstance(this))
	{
		int32 CenterIndex = GetCenterDataIndex();
		int32 CardNum = ScrollParams.CardNum;
		for (int32 Index=0; Index<ChildCardActors.Num(); ++Index)
		{
			auto& ActorInfo = ChildCardActors[Index];
			if (UObject* UObj = UOAM->GetObjectByID(ActorInfo.ActorID))
			{
				if (AActor* ChildActor = Cast<AActor>(UObj))
				{
					float Key = GetKeyFromIndex(Index);
					// UE_LOG(LogTemp, Log, TEXT("Scroll cpp, Index=%d, Key=%f, Anchor=%f"), Index, Key, Anchor);	
					FTransform Transform;
					float Opacity = 0.f;
					GetKeyTransform(Key, Transform, Opacity);
					if (USceneComponent* RootComponent = ChildActor->GetRootComponent())
					{
						RootComponent->SetRelativeTransform(Transform);
						// FVector Location = Transform.GetLocation();
						// UE_LOG(LogTemp, Log, TEXT("Scroll cpp, Index=%d, (%f, %f, %f), Opacity:%f"), Index, Location.X, Location.Y, Location.Z, Opacity);
						SetChildActorOpacity(UOAM, ActorInfo, Opacity);
						if (FMath::Abs(Key) <= UE_SMALL_NUMBER)
						{
							if (CenterIndex != -1)
							{
								int32 Pivot = ((CenterIndex - ScrollParams.CardNum / 2 - 1) + ScrollParams.DataNum - 1) % ScrollParams.DataNum + 1;
								ActorInfo.DataIndex = Pivot;
								OnCardScrollBehind.Broadcast(Index, ActorInfo.DataIndex, CardNum);
							}
						}
						else if (CardNum > -1 && (FMath::Abs(Key - CardNum * 1.0 / (CardNum + 1)) <= UE_SMALL_NUMBER) )
						{
							if (CenterIndex != -1)
							{
								int32 Pivot = ((CenterIndex + ScrollParams.CardNum / 2) + ScrollParams.DataNum - 1) % ScrollParams.DataNum + 1;
								ActorInfo.DataIndex = Pivot;
								OnCardScrollBehind.Broadcast(Index, ActorInfo.DataIndex, CardNum);
							}
						}
					}
				}
			}
		}
	}
	
}


