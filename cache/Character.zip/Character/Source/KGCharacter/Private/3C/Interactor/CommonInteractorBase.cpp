#include "3C/Interactor/CommonInteractorBase.h"

#include "3C/Movement/SimpleMovementComponent.h"

ACommonInteractorBase::ACommonInteractorBase(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = false;
	SimpleMovementComponent = CreateDefaultSubobject<USimpleMovementComponent>(TEXT("SimpleMovement"));
}
