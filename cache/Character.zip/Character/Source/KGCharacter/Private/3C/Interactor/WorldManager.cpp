#include "3C/Interactor/WorldManager.h"
#include "LevelPreset/WorldLevelsPresetAsset.h"
#include "3C/Character/BriefCharacter.h"
#include "Engine/LocalPlayer.h"
#include "GameFramework/PlayerController.h"
#include "3C/Character/BaseCharacter.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Misc/KGGameInstanceBase.h"
#include "3C/Character/C7Actor.h"
#include "DrawDebugHelpers.h"
#include "WaterDynamicLocalWaveSubsystem.h"
#include "WaterDynamicLocalWaveLibrary.h"
#include "KGEngineCoreBPLibrary.h"
#include "LocalWindSubsystem.h"
#include "SceneView.h"
#include "Engine/Engine.h"
#include "Engine/GameViewportClient.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "3C/Interactor/RubiksCubeSpaceDivision.h"
#include "UObject/SoftObjectPath.h"
#include "EngineUtils.h"
#include "Engine/LevelStreaming.h"
#include "Manager/KGObjectActorManager.h"
#include "DeformableLandscapeSystem.h"
#include "DeformableLandscapeTrailTraceComponent.h"
#include "PhysicalMaterials/PhysicalMaterial.h"
#include "KGPhysicalMaterialMaskComponent.h"
#include "GeographyClimateSubsystem.h"
#include "3C/Util/KGUtils.h"
#include "MainSkyPerformer.h"
#include "Components/LightComponent.h"
#include "Engine/DirectionalLight.h"
#include "Engine/ExponentialHeightFog.h"
#include "EngineModule.h"
#include "Manager/KGCppAssetManager.h"
#include "KGLandscapeHeightDataSubsystem.h"
#include "Runtime/KGFaceControlSubsystem.h"
#include "3C/Interactor/Components/LightTODControlComponent.h"
#include "UnrealEngine.h"
#include "Engine/LevelStreamingDynamic.h"
#include "3C/Interactor/Spline/C7GameplaySplineActorBase.h"

//PRAGMA_DISABLE_OPTIMIZATION

static TAutoConsoleVariable<bool> CVarWorldManagerLODDebug(TEXT("WorldManager.DebugLod"), false, TEXT("Draw WorldManager LOD"));
static TAutoConsoleVariable<bool> CVarWorldManagerSpaceDivisionDebug(TEXT("WorldManager.SpaceDivisionDebug"), false, TEXT("Draw WorldManager SpaceDivision"));


UWorldManager::UWorldManager(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer), bViewMatrixChanged(false), bMgrInit(false)
{

}

#pragma region Important
void UWorldManager::NativeInit()
{
	Super::NativeInit();
	InitSpaceDivision();
	
	bMgrInit = true;

	using namespace NS_SLUA;
	REG_MANAGER_FUNC(UWorldManager, "QueryTerrainName", &UWorldManager::QueryTerrainName);
	REG_MANAGER_FUNC(UWorldManager, "SetQueryTerrainObjectTypes", &UWorldManager::SetQueryTerrainObjectTypes);
	REG_MANAGER_FUNC(UWorldManager, "InnerInitTerrainData", &UWorldManager::InnerInitTerrainData);
	REG_MANAGER_FUNC(UWorldManager, "InnerUpdateTerrainData", &UWorldManager::InnerUpdateTerrainData);
	REG_MANAGER_FUNC(UWorldManager, "InnerInitMaterialMaskData", &UWorldManager::InnerInitMaterialMaskData);
	REG_MANAGER_FUNC(UWorldManager, "InnerUpdateMaterialMaskData", &UWorldManager::InnerUpdateMaterialMaskData);

#pragma region TODLight
	REG_MANAGER_FUNC(UWorldManager, "SetStreetlightTODParams", &UWorldManager::SetStreetlightTODParams);
	REG_MANAGER_FUNC(UWorldManager, "SetStreetlightControlBySequence", &UWorldManager::SetStreetlightControlBySequence);
	REG_MANAGER_FUNC(UWorldManager, "SetupStreetlightControlByComponentTag", &UWorldManager::SetupStreetlightControlByComponentTag);
	REG_MANAGER_FUNC(UWorldManager, "UpdateStreetlightControlByComponentTag", &UWorldManager::UpdateStreetlightControlByComponentTag);
	REG_MANAGER_FUNC(UWorldManager, "EndStreetlightControlByComponentTag", &UWorldManager::EndStreetlightControlByComponentTag);
#pragma endregion TODLight
	
#pragma region DeformableLandscape
	REG_MANAGER_FUNC(UWorldManager, "EnableDeformableLandscapeSystem", &UWorldManager::EnableDeformableLandscapeSystem);
	REG_MANAGER_FUNC(UWorldManager, "IsEnabledDeformableLandscapeSystem", &UWorldManager::IsEnabledDeformableLandscapeSystem);
	REG_MANAGER_FUNC(UWorldManager, "SetPivotActorForDeformableLandscape", &UWorldManager::SetPivotActorForDeformableLandscape);
	REG_MANAGER_FUNC(UWorldManager, "CleanupPivotActorForDeformableLandscape", &UWorldManager::CleanupPivotActorForDeformableLandscape);
	REG_MANAGER_FUNC(UWorldManager, "EnableDeformableLandscapeCaptureMode", &UWorldManager::EnableDeformableLandscapeCaptureMode);
	REG_MANAGER_FUNC(UWorldManager, "EnableDeformableLandscapeSimpleMode", &UWorldManager::EnableDeformableLandscapeSimpleMode);
#pragma endregion DeformableLandscape

#pragma region LocalWindField
	REG_MANAGER_FUNC(UWorldManager, "EnableLocalWindField", &UWorldManager::EnableLocalWindField);
	REG_MANAGER_FUNC(UWorldManager, "IsEnableLocalWindField", &UWorldManager::IsEnableLocalWindField);
	REG_MANAGER_FUNC(UWorldManager, "IsCVarEnabledLocalWindField", &UWorldManager::IsCVarEnabledLocalWindField);
	REG_MANAGER_FUNC(UWorldManager, "SetPivotActorForLocalWindField", &UWorldManager::SetPivotActorForLocalWindField);
	REG_MANAGER_FUNC(UWorldManager, "CleanupPivotActorForLocalWindField", &UWorldManager::CleanupPivotActorForLocalWindField);
	REG_MANAGER_FUNC(UWorldManager, "AddMotorForLocalWindField", &UWorldManager::AddMotorForLocalWindField);
	REG_MANAGER_FUNC(UWorldManager, "BindRoleMovementWindField", &UWorldManager::BindRoleMovementWindField);
#pragma endregion  LocalWindField

#pragma region WaterSurfaceWave
	REG_MANAGER_FUNC(UWorldManager, "EnableDynamicWaterWave", &UWorldManager::EnableDynamicWaterWave);
	REG_MANAGER_FUNC(UWorldManager, "IsEnabledDynamicWaterWave", &UWorldManager::IsEnabledDynamicWaterWave);
	REG_MANAGER_FUNC(UWorldManager, "IsCVarEnabledDynamicWaterWave", &UWorldManager::IsCVarEnabledDynamicWaterWave);
	REG_MANAGER_FUNC(UWorldManager, "GetGlobalWaterWaveRequestId", &UWorldManager::GetGlobalWaterWaveRequestId);
	REG_MANAGER_FUNC(UWorldManager, "SetupDynamicWaterWaveMotorTextures", &UWorldManager::SetupDynamicWaterWaveMotorTextures);
	REG_MANAGER_FUNC(UWorldManager, "SetPivotActorForDynamicWaterWave", &UWorldManager::SetPivotActorForDynamicWaterWave);
	REG_MANAGER_FUNC(UWorldManager, "CleanupPivotActorForDynamicWaterWave", &UWorldManager::CleanupPivotActorForDynamicWaterWave);
	REG_MANAGER_FUNC(UWorldManager, "AddMotorForDynamicWaterWave", &UWorldManager::AddMotorForDynamicWaterWave);
	REG_MANAGER_FUNC(UWorldManager, "AddMotorForDynamicWaterWaveForSkill", &UWorldManager::AddMotorForDynamicWaterWaveForSkill);
	REG_MANAGER_FUNC(UWorldManager, "ExecuteMotorForDynamicWaterWave", &UWorldManager::ExecuteMotorForDynamicWaterWave);
	REG_MANAGER_FUNC(UWorldManager, "BindRoleMovementDynamicWaterWave", &UWorldManager::BindRoleMovementDynamicWaterWave);
	REG_MANAGER_FUNC(UWorldManager, "RegisterWaterWaveTick", &UWorldManager::RegisterWaterWaveTick);
	REG_MANAGER_FUNC(UWorldManager, "UnRegisterWaterWaveTick", &UWorldManager::UnRegisterWaterWaveTick);
#pragma endregion  WaterSurfaceWave

#pragma region KGEngineCore
	REG_MANAGER_FUNC(UWorldManager, "SetKGEngineCorePlayerActor", &UWorldManager::SetKGEngineCorePlayerActor);
	REG_MANAGER_FUNC(UWorldManager, "CleanupKGEngineCorePlayerActor", &UWorldManager::CleanupKGEngineCorePlayerActor);
#pragma endregion KGEngineCore

#pragma region Common
	REG_MANAGER_FUNC(UWorldManager, "EditorTick", &UWorldManager::EditorTick);
	REG_MANAGER_FUNC(UWorldManager, "InitParam", &UWorldManager::InitParam);
	REG_MANAGER_FUNC(UWorldManager, "SetGameInstance", &UWorldManager::SetGameInstance);
	REG_MANAGER_FUNC(UWorldManager, "UnRegisterSignActor", &UWorldManager::UnRegisterSignActor);
	REG_MANAGER_FUNC(UWorldManager, "RegisterLODSignActor", &UWorldManager::RegisterLODSignActor);
	REG_MANAGER_FUNC(UWorldManager, "SetLODRangeConfigList", &UWorldManager::SetLODRangeConfigList);
	REG_MANAGER_FUNC(UWorldManager, "FindSceneActor", &UWorldManager::FindSceneActor);
	REG_MANAGER_FUNC(UWorldManager, "RegisterClipObserver", &UWorldManager::RegisterClipObserver);
	REG_MANAGER_FUNC(UWorldManager, "UnRegisterClipObserver", &UWorldManager::UnRegisterClipObserver);
	REG_MANAGER_FUNC(UWorldManager, "SetClipFilterConfig", &UWorldManager::SetClipFilterConfig);
	REG_MANAGER_FUNC(UWorldManager, "ModifyClipParams", &UWorldManager::ModifyClipParams);
	REG_MANAGER_FUNC(UWorldManager, "ModifyClipPriority", &UWorldManager::ModifyClipPriority);
	REG_MANAGER_FUNC(UWorldManager, "HideAllPlayer", &UWorldManager::HideAllPlayer);
	REG_MANAGER_FUNC(UWorldManager, "SetPreviewWorld", &UWorldManager::SetPreviewWorld);
	REG_MANAGER_FUNC(UWorldManager, "EnableActorLimitClip", &UWorldManager::EnableActorLimitClip);
	REG_MANAGER_FUNC(UWorldManager, "EnableActorLod", &UWorldManager::EnableActorLod);
	REG_MANAGER_FUNC(UWorldManager, "EnableUseWasRecentlyRendered", &UWorldManager::EnableUseWasRecentlyRendered);
	REG_MANAGER_FUNC(UWorldManager, "EnableActorViewMatrixClip", &UWorldManager::EnableActorViewMatrixClip);
	REG_MANAGER_FUNC(UWorldManager, "EnableMainSkyPerformer", &UWorldManager::EnableMainSkyPerformer);
	REG_MANAGER_FUNC(UWorldManager, "EnableDirectionalLight", &UWorldManager::EnableDirectionalLight);
	REG_MANAGER_FUNC(UWorldManager, "EnableFogs", &UWorldManager::EnableFogs);
	REG_MANAGER_FUNC(UWorldManager, "EnableVolumetricLightmap", &UWorldManager::EnableVolumetricLightmap);
	REG_MANAGER_FUNC(UWorldManager, "SetPreviewCamera", &UWorldManager::SetPreviewCamera);
	REG_MANAGER_FUNC(UWorldManager, "KAPI_WorldManager_EnablePPVolumes", &UWorldManager::KAPI_WorldManager_EnablePPVolumes);
	REG_MANAGER_FUNC(UWorldManager, "GetAltitudeByLocation", &UWorldManager::GetAltitudeByLocation);
	REG_MANAGER_FUNC(UWorldManager, "ResetClipFilter", &UWorldManager::ResetClipFilter);
	REG_MANAGER_FUNC(UWorldManager, "EnableForceClipVisible", &UWorldManager::EnableForceClipVisible);
	REG_MANAGER_FUNC(UWorldManager, "EnableMainSkyPerformerVisibleAndTickable", &UWorldManager::EnableMainSkyPerformerVisibleAndTickable);
#pragma endregion Common

#pragma region SpaceDivision
	REG_MANAGER_FUNC(UWorldManager, "ClearAllElement", &UWorldManager::ClearAllElement);
	REG_MANAGER_FUNC(UWorldManager, "AddAOISceneElement", &UWorldManager::AddAOISceneElement);
	REG_MANAGER_FUNC(UWorldManager, "RemoveAOISceneElement", &UWorldManager::RemoveAOISceneElement);
	REG_MANAGER_FUNC(UWorldManager, "RegisterGridLogicDetector", &UWorldManager::RegisterGridLogicDetector);
	REG_MANAGER_FUNC(UWorldManager, "UnregisterGridLogicDetector", &UWorldManager::UnregisterGridLogicDetector);
	REG_MANAGER_FUNC(UWorldManager, "RegisterGridLogicTrigger", &UWorldManager::RegisterGridLogicTrigger);
	REG_MANAGER_FUNC(UWorldManager, "UnregisterGridLogicTrigger", &UWorldManager::UnregisterGridLogicTrigger);
	REG_MANAGER_FUNC(UWorldManager, "SetTriggerElementExitTolerantDistance", &UWorldManager::SetTriggerElementExitTolerantDistance);
	REG_MANAGER_FUNC(UWorldManager, "ConsumeSceneElementID", &UWorldManager::ConsumeSceneElementID);
	REG_MANAGER_FUNC(UWorldManager, "UpdateGridLogicDetectorRadius", &UWorldManager::UpdateGridLogicDetectorRadius);
	REG_MANAGER_FUNC(UWorldManager, "UpdateGridLogicTriggerRadius", &UWorldManager::UpdateGridLogicTriggerRadius);
#pragma endregion SpaceDivision

#pragma region VirtualTexture
	REG_MANAGER_FUNC(UWorldManager, "FlushVirtualTextureCache", &UWorldManager::FlushVirtualTextureCache);
#pragma endregion

#pragma region AnimationBudget
	REG_MANAGER_FUNC(UWorldManager, "EnableAnimationBudget", &UWorldManager::EnableAnimationBudget);
#pragma endregion AnimationBudget

#pragma region Brief
	REG_MANAGER_FUNC(UWorldManager, "InitBriefParams", &UWorldManager::InitBriefParams);
	REG_MANAGER_FUNC(UWorldManager, "RegisterBriefActor", &UWorldManager::RegisterBriefActor);
	REG_MANAGER_FUNC(UWorldManager, "ModifyBriefPriorityWithInfluenceDist", &UWorldManager::ModifyBriefPriorityWithInfluenceDist);
	REG_MANAGER_FUNC(UWorldManager, "ModifyBriefPriority", &UWorldManager::ModifyBriefPriority);
	REG_MANAGER_FUNC(UWorldManager, "UpdateBrief", &UWorldManager::UpdateBrief);
	REG_MANAGER_FUNC(UWorldManager, "InitCacheAvatarAndBriefList", &UWorldManager::InitCacheAvatarAndBriefList);
#pragma endregion Brief

#pragma region EnvironmentTheme
	REG_MANAGER_FUNC(UWorldManager, "PreloadLevelPresetForEnvironmentTheme", &UWorldManager::PreloadLevelPresetForEnvironmentTheme);
	REG_MANAGER_FUNC(UWorldManager, "EnableLevelPresetForEnvironmentTheme", &UWorldManager::EnableLevelPresetForEnvironmentTheme);
	REG_MANAGER_FUNC(UWorldManager, "SetStreamingLevelMobileName", &UWorldManager::SetStreamingLevelMobileName);
	REG_MANAGER_FUNC(UWorldManager, "GetStreamingLevelMobileName", &UWorldManager::GetStreamingLevelMobileName);
#pragma endregion EnvironmentTheme
	
#pragma region GameplaySpline
	REG_MANAGER_FUNC(UWorldManager, "RegisterSplineEntity", &UWorldManager::RegisterSplineEntity);
	REG_MANAGER_FUNC(UWorldManager, "UnRegisterSplineEntity", &UWorldManager::UnRegisterSplineEntity);
	REG_MANAGER_FUNC(UWorldManager, "OnSplineActorEnter", &UWorldManager::OnSplineActorEnter);
	REG_MANAGER_FUNC(UWorldManager, "OnSplineActorLeave", &UWorldManager::OnSplineActorLeave);
	REG_MANAGER_FUNC(UWorldManager, "ClearAllSplineItem", &UWorldManager::ClearAllSplineItem);
#pragma endregion GameplaySpline
}

void UWorldManager::SetGameInstance()
{
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}
	GIPtr = World->GetGameInstance();
}

void UWorldManager::NativeUninit()
{
	Super::NativeUninit();

	if (SpaceDivision)
	{
		SpaceDivision->UnInit();
		SpaceDivision = nullptr;
	}

	bMgrInit = false;

	for (auto& Elem : WorldSignObjectsMap)
	{
		RemoveSignObject(Elem.Value);
	}

	WorldSignObjectsMap.Empty();
	BriefSignObjectsMap.Empty();
	WorldSignObjsTransformChanged.Empty();

	ClearActorSpawnDelegate();
}

void UWorldManager::InitParam(float InPositionThreshold, float InRotationThreshold, float InClipDistancePrecision, float InAnimationBudgetUpdateDistance,
	int32 InMaxNotifyClipActorNum, int32 InMaxNotifyActorLODNum)
{
	PositionThreshold = InPositionThreshold;
	RotationThreshold = InRotationThreshold;
	ClipDistancePrecision = InClipDistancePrecision;
	AnimationBudgetUpdateDistance = InAnimationBudgetUpdateDistance;
	MaxNotifyClipActorNum = InMaxNotifyClipActorNum;
	MaxNotifyActorLODNum = InMaxNotifyActorLODNum;
}
	

#pragma endregion Important


#pragma region CharacterLOD

int32 UWorldManager::RegisterLODSignActor(int64 InActorID, FName TagType)
{
	auto InActor = KGUtils::GetActorByID(InActorID);
	if (!IsValid(InActor))
	{
		return 0;
	}

	if(ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(InActor))
	{
		FWorldSignObjectInfo& SignObjInfo = WorldSignObjectsMap.FindOrAdd(BaseCharacter);
		SignObjInfo.Actor = BaseCharacter;
		SignObjInfo.TagType = TagType;
		SignObjInfo.bRLOD = true;
		SignObjInfo.LOD = 0;
		if (GIPtr.IsValid() && IsValid(InActor))
		{
			ULocalPlayer const* const LP = GIPtr->GetFirstGamePlayer();
			if (LP && LP->ViewportClient)
			{

				if (APlayerController* PlayerController = LP->GetPlayerController(GIPtr->GetWorld())) {
					FVector LocPos(BaseCharacter->K2_GetActorLocation());
					if (PlayerController->GetPawn()) {
						LocPos = PlayerController->GetPawn()->K2_GetActorLocation();
					}

					FVector WorldLocation = InActor->GetActorLocation();
					float TDis = FVector::Dist(LocPos, WorldLocation);
					SignObjInfo.LastLodDistance = TDis;
					SignObjInfo.LOD = CalculateSignLod(TDis);

					if (IsUseAnimationBudget) {
						UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(this);
						if (ActorManager) {
							auto* CppEntity = ActorManager->GetLuaEntityByActor(InActor);
							if (CppEntity && CppEntity->GetIsUseAnimationBudget()) {
								TArray<ICppEntityInterface*> VisitedEnts;
								CppEntity->SkeletalMesh_SetSKBudgetedComponentSignificance(
								VisitedEnts,
									CalculateAnimationBudgetSignificance(SignObjInfo.LOD, CppEntity->GetEntitySignificance(), TDis)
								);
							}
						}
					}

				}
			}
		}

		if (BaseCharacter->GetRootComponent() && !BaseCharacter->GetRootComponent()->TransformUpdated.IsBoundToObject(this))
		{
			BaseCharacter->GetRootComponent()->TransformUpdated.AddUObject(this, &UWorldManager::OnComTransformChanged);
		}
		return 	SignObjInfo.LOD;
	}
	
	return 0;
}

void UWorldManager::UnRegisterSignActor(int64 InActorID)
{
	auto InActor = KGUtils::GetActorByID(InActorID);
	if (!IsValid(InActor))
	{
		return;
	}

	if(ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(InActor))
	{
		FWorldSignObjectInfo* SignObjInfo = WorldSignObjectsMap.Find(BaseCharacter);
		if (SignObjInfo)
		{
			RemoveSignObject(*SignObjInfo);
			WorldSignObjectsMap.Remove(BaseCharacter);
		}
	}

	BriefSignObjectsMap.Remove(InActorID);
}

void UWorldManager::SetLODRangeConfigList(const TArray<int32>& RangeList, float InLODStep)
{
	LODRangeList.Empty();
	LODRangeList.Append(RangeList);
	LODFastDisRefMap.Empty();
	LODStep = InLODStep;
	
	int32 IndexLod(0);
	int32 LastRangeMax(1);
	LODFastDisRefMap.Add(0, IndexLod);
	for (const int32& RangeValue : LODRangeList)
	{
		const int32 RangeMax = RangeValue / LODStep;

		for (int32 i(LastRangeMax); i < RangeMax; ++i) {
			LODFastDisRefMap.Add(i, IndexLod);
		}

		LastRangeMax = RangeMax;
		++IndexLod;
	}

	MaxLODRange = LastRangeMax * LODStep;
	MaxLODValue = LODRangeList.Num();
	bViewMatrixChanged = true;
}

int64 UWorldManager::FindSceneActor(int64 InstanceID)
{
	auto* Info = SceneActorMap.Find(InstanceID);
	if (Info) {
		return KGUtils::GetIDByObject(Info->Actor.Get());
	}
	return KG_INVALID_ACTOR_ID;
}

int32 UWorldManager::CalculateSignLod(const float& InDis)
{
	if (MaxLODRange <= InDis)
	{
		return MaxLODValue;
	}

	const int32 IDis = static_cast<int32>(InDis / LODStep);
	if (const int32* LodValue = LODFastDisRefMap.Find(IDis))
	{
		return *LodValue;
	}

	return MaxLODValue;
}

void UWorldManager::ActorLodChanged(ABaseCharacter* InActor, int32 NewLOD)
{
	if (InActor)
	{
		InActor->SetActorLOD(NewLOD);
		CallLuaFunction("OnActorLodChanged", InActor->GetEntityUID(),NewLOD);
	}
}
#pragma endregion CharacterLOD

#pragma region Breif

void UWorldManager::InitBriefParams(bool InEnableBriefUpdate, int32 InMaxAvatarActorCount, int32 InBriefPriorityMin, float InBriefUpdateTime, int32 InBriefChangeLimit, int InBriefChangeDownLimit, float InAgingForceTime)
{
	EnableBriefUpdate = InEnableBriefUpdate;
	MaxAvatarActorCount = InMaxAvatarActorCount;
	BriefPriorityMin = InBriefPriorityMin;
	BriefUpdateTime = InBriefUpdateTime;
	BriefChangeLimit = InBriefChangeLimit;
	BriefChangeDownLimit = InBriefChangeDownLimit;
	AgingForceTime = InAgingForceTime;
}

void UWorldManager::RegisterBriefActor(int64 InActorID)
{
	AActor* InActor = KGUtils::GetActorByID(InActorID);
	if(!IsValid(InActor))
	{
		return;
	}
	
	FBriefSignObjectInfo& SignObj = BriefSignObjectsMap.FindOrAdd(InActorID);
	SignObj.Actor = InActor;
}

void UWorldManager::ModifyBriefPriorityWithInfluenceDist(int64 InActorID, int32 Priority, float InfluenceDist)
{
	AActor* InActor = KGUtils::GetActorByID(InActorID);
	if(!IsValid(InActor))
	{
		return;
	}

	if(FBriefSignObjectInfo* SignObj = BriefSignObjectsMap.Find(InActorID))
	{
		SignObj->BriefPriority = Priority;
		SignObj->BriefInfluenceDist = InfluenceDist / ClipDistancePrecision;
	}
}

void UWorldManager::ModifyBriefPriority(int64 InActorID, int32 Priority)
{
	AActor* InActor = KGUtils::GetActorByID(InActorID);
	if(!IsValid(InActor))
	{
		return;
	}

	if(FBriefSignObjectInfo* SignObj = BriefSignObjectsMap.Find(InActorID))
	{
		SignObj->BriefPriority = Priority;
	}
}

void UWorldManager::UpdateBrief()
{
	if(!EnableBriefUpdate)
	{
		return;
	}

	CurBriefUpdateTime = BriefUpdateTime;
	const float CurrentTime = GetWorld()->GetTimeSeconds();

	QUICK_SCOPE_CYCLE_COUNTER(WorldManager_UpdateBrief);
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UWorldManager_UpdateBrief");

	FVector PlayerLocation = FVector(0, 0, 0);
	const APlayerController* PlayerController = UGameplayStatics::GetPlayerController(GetWorld(), 0);
	if (PlayerController && PlayerController->GetPawn())
	{
		PlayerLocation = PlayerController->GetPawn()->GetActorLocation();
	}

	BriefSignObjectsArray.Reset();
	CurAvatarActorCount = 0;
	for (auto It = BriefSignObjectsMap.CreateIterator(); It; ++It)
	{
		FBriefSignObjectInfo& SignObjInfo = It.Value();
		if(!SignObjInfo.Actor.IsValid())
		{
			It.RemoveCurrent();
			continue;
		}

		SignObjInfo.Age = CurrentTime - SignObjInfo.LastProcessTime;
		
		if(const ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(SignObjInfo.Actor))
		{
			SignObjInfo.IsBrief = false;
			FVector WorldLocation = BaseCharacter->GetActorLocation();
			SignObjInfo.Dis = FMath::Floor(FVector::Dist(PlayerLocation, WorldLocation)/ ClipDistancePrecision);
			CurAvatarActorCount ++;
			BriefSignObjectsArray.Add(&SignObjInfo);
		}
		else if(const ABriefCharacter* BriefCharacter = Cast<ABriefCharacter>(SignObjInfo.Actor))
		{
			FVector WorldLocation = BriefCharacter->GetBriefActorTransform()->GetLocation();
			SignObjInfo.Dis = FMath::Floor(FVector::Dist(PlayerLocation, WorldLocation)/ ClipDistancePrecision);
			SignObjInfo.IsBrief = true;
			BriefSignObjectsArray.Add(&SignObjInfo);
		}
		else
		{
			It.RemoveCurrent();
		}
	}

	const int32 totalActorCount = BriefSignObjectsMap.Num();
	const int32 briefActorCount = totalActorCount - CurAvatarActorCount;

	if(CurAvatarActorCount <= MaxAvatarActorCount && briefActorCount == 0)
	{
		return;
	}
	
	// cppcheck:push ignore
	BriefSignObjectsArray.Sort([](FBriefSignObjectInfo& A, FBriefSignObjectInfo& B) {return SortBriefActorsByDistanceAndPriority(A, B);});
	// cppcheck:pop
	
	// 构建需要转换的候选列表
	TArray<FBriefSignObjectInfo*> ToAvatarCandidates;
	TArray<FBriefSignObjectInfo*> ToBriefCandidates;
	ToAvatarCandidates.Reserve(BriefSignObjectsArray.Num());
	ToBriefCandidates.Reserve(BriefSignObjectsArray.Num());
	for(int i=0; i<BriefSignObjectsArray.Num(); i++)
	{
		FBriefSignObjectInfo* SignObjInfo = BriefSignObjectsArray[i];
		SignObjInfo->CurrentPriority = i;
		if(!SignObjInfo || !SignObjInfo->Actor.IsValid())
		{
			continue;
		}
		
		//强制显示的Avatar
		if(SignObjInfo->BriefPriority <= BriefPriorityMin)
		{
			if(SignObjInfo->IsBrief)
			{
				SignObjInfo->LastProcessTime = -1; //一定优先处理
				ToAvatarCandidates.Add(SignObjInfo);
			}
			else
            {
            	SignObjInfo->LastProcessTime = CurrentTime;
            }
		}
		else if(i < MaxAvatarActorCount)
		{
			if(SignObjInfo->IsBrief)
			{
				ToAvatarCandidates.Add(SignObjInfo);
			}
			else
			{
				SignObjInfo->LastProcessTime = CurrentTime;
			}
		}
		else
		{
			if(!SignObjInfo->IsBrief)
			{
				ToBriefCandidates.Add(SignObjInfo);
			}
			else
            {
            	SignObjInfo->LastProcessTime = CurrentTime;
            }
		}
	}

	TArray<int64> ToAvatarList;
	TArray<int64> ToBriefList;

	//优先处理LastProcessTime < 0的高优先对象
	for (auto It = ToAvatarCandidates.CreateIterator(); It; ++It)
	{
		FBriefSignObjectInfo* SignObjInfo = *It;
		if(SignObjInfo->LastProcessTime > 0)
		{
			break;
		}

		AActor* Actor = SignObjInfo->Actor.Get();
		if(IC7ActorInterface* C7Actor = Cast<IC7ActorInterface>(Actor))
		{
			ToAvatarList.Add(C7Actor->GetEntityUID());
			SignObjInfo->LastProcessTime = CurrentTime;
			It.RemoveCurrent();
		}
	}

	float InAgingForceTime = AgingForceTime;   // 超过 10 秒没处理 → 强制处理防止饿死
	if(InAgingForceTime>0)
	{
		// 按老化程度对候选对象排序（长时间未处理的优先）
		ToAvatarCandidates.Sort([InAgingForceTime](FBriefSignObjectInfo& A, FBriefSignObjectInfo& B) {
			const bool AForce = (A.Age >= InAgingForceTime);
			const bool BForce = (B.Age >= InAgingForceTime);

			// 若一方老化时间超过阈值 → 强制放前面
			if (AForce != BForce)
				return AForce;

			// 否则使用原逻辑：按当前优先级排序
			return A.CurrentPriority < B.CurrentPriority;
		});
	
		ToBriefCandidates.Sort([InAgingForceTime](FBriefSignObjectInfo& A, FBriefSignObjectInfo& B) {
			const bool AForce = (A.Age >= InAgingForceTime);
			const bool BForce = (B.Age >= InAgingForceTime);

			// 若一方老化时间超过阈值 → 强制放前面
			if (AForce != BForce)
				return AForce;

			// 否则使用原逻辑：按当前优先级排序
			return A.CurrentPriority < B.CurrentPriority;
		});
	}
	
	// 处理转为完整的候选对象（最多 BriefChangeLimit 个）
	for(int i = 0; i < ToAvatarCandidates.Num() && i < BriefChangeLimit; i++)
	{
		FBriefSignObjectInfo* SignObjInfo = ToAvatarCandidates[i];
		AActor* Actor = SignObjInfo->Actor.Get();
		if(IC7ActorInterface* C7Actor = Cast<IC7ActorInterface>(Actor))
		{
			ToAvatarList.Add(C7Actor->GetEntityUID());
			SignObjInfo->LastProcessTime = CurrentTime;
		}
	}

	//超过Actor上限了再考虑降级为Brief
	const int NextCurAvatarActorCount = CurAvatarActorCount + ToAvatarList.Num();
	if(NextCurAvatarActorCount > MaxAvatarActorCount)
	{
		// 处理转为简略的候选对象（最多 BriefChangeLimit 个）
		for(int i = 0; i < ToBriefCandidates.Num() && i < BriefChangeDownLimit; i++)
		{
			//Avatar个数不够了，停止降级为Brief
			if(NextCurAvatarActorCount-ToBriefList.Num() <= MaxAvatarActorCount)
			{
				break;
			}
			FBriefSignObjectInfo* SignObjInfo = ToBriefCandidates[i];
			AActor* Actor = SignObjInfo->Actor.Get();
			if(IC7ActorInterface* C7Actor = Cast<IC7ActorInterface>(Actor))
			{
				ToBriefList.Add(C7Actor->GetEntityUID());
				SignObjInfo->LastProcessTime = CurrentTime;
			}
		}
	}
	
	if(ToAvatarList.Num()>0 || ToBriefList.Num())
	{
		//CallLuaFunction("KCB_StartBatchChangeBrief", ToAvatarList, ToBriefList);
		UpdateAvatarAndBriefList(ToAvatarList, ToBriefList);
	}
}

void UWorldManager::InitCacheAvatarAndBriefList()
{
	auto LuaSelfTable = GetSelfTable();
	if (!LuaSelfTable.isValid())
	{
		return;
	}

	NS_SLUA::LuaState* State = NS_SLUA::LuaState::get(LuaSelfTable.getStateIndex());
	if (!State) 
	{
		return;
	}

	lua_State* L = State->getLuaState();
	NS_SLUA::AutoStack as(L);

	// 创建并缓存 AvatarList
	lua_newtable(L);
	CacheAvatarList = NS_SLUA::LuaVar(L, -1);
	LuaSelfTable.setToTable<true>("cachedAvatarList", CacheAvatarList);

	// 创建并缓存 BriefList
	lua_newtable(L);
	CacheBriefList = NS_SLUA::LuaVar(L, -1);
	LuaSelfTable.setToTable<true>("cachedBriefList", CacheBriefList);

	// AutoStack 自动清理栈
}

void UWorldManager::UpdateAvatarAndBriefList(const TArray<int64>& AvatarList, const TArray<int64>& BriefList)
{
	if (!CacheAvatarList.isValid() || !CacheBriefList.isValid()) {
		return;
	}

	lua_State* L = CacheAvatarList.getState();
	NS_SLUA::AutoStack as(L);  // 自动恢复栈

	// 更新 AvatarList
	CacheAvatarList.push(L);
	KGLuaObjectUtils::FillLuaTableFromArray<int64>(L, lua_gettop(L), AvatarList);

	// 更新 BriefList
	CacheBriefList.push(L);
	KGLuaObjectUtils::FillLuaTableFromArray<int64>(L, lua_gettop(L), BriefList);

	// AutoStack 自动清理栈，无需手动 pop
	CallLuaFunction("KCB_StartBatchChangeBrief_NoGC");
}

#pragma endregion Breif

#pragma region CharacterClip
void UWorldManager::RegisterClipObserver(int64 InActorID, int32 FilterType)
{
	AActor* InActor = KGUtils::GetActorByID(InActorID);
	if(!IsValid(InActor))
	{
		return;
	}

	if(ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(InActor))
	{
		FWorldSignObjectInfo* SignObj = WorldSignObjectsMap.Find(BaseCharacter);
		if (!SignObj)
		{
			RegisterLODSignActor(InActorID, FName("Clip"));

			SignObj = WorldSignObjectsMap.Find(BaseCharacter);
			if (SignObj)
			{
				SignObj->bRLOD = false;
			}
		}
		if (SignObj)
		{
			SignObj->ClipState = -1;
			SignObj->FilterType = FilterType;
			SignObj->Dis = 0.0f;
			SignObj->bOberverClip = true;
			PushTransformChangedSignObj(BaseCharacter);
			bViewMatrixChanged = true;
			ForceMaxNotifyClipActorNum = TNumericLimits<int32>::Max();
		}
	}
}

void UWorldManager::UnRegisterClipObserver(int64 InActorID)
{
	AActor* InActor = KGUtils::GetActorByID(InActorID);
	if(!IsValid(InActor))
	{
		return;
	}

	if(ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(InActor))
	{
		FWorldSignObjectInfo* SignObj = WorldSignObjectsMap.Find(BaseCharacter);
		if (SignObj)
		{
			SignObj->ClipState = -1;
			SignObj->FilterType = 0;
			SignObj->Dis = 0.0f;
			SignObj->bOberverClip = false;
			MarkClipStateChanged.Remove(BaseCharacter);
			if (SignObj->bRLOD == false)
			{
				WorldSignObjectsMap.Remove(BaseCharacter);
			}
		}
	}
}

void UWorldManager::ResetClipFilter()
{
	bViewMatrixChanged = true;
}

void UWorldManager::SetClipFilterConfig(int FilterType, int LimitNum)
{
	LimitClipNumMap.Add(FilterType, LimitNum);
	bViewMatrixChanged = true;
}

void UWorldManager::OnComTransformChanged(USceneComponent* Component, EUpdateTransformFlags UpdateTransformFlags, ETeleportType Teleport)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UWorldManager_OnComTransformChanged");
	AActor* Actor = Component->GetOwner();
	ABaseCharacter* baseActor = Cast<ABaseCharacter>(Actor);
	if(!IsValid(baseActor))
	{
		return;
	}
	
	if (WorldSignObjectsMap.Contains(baseActor))
	{
		PushTransformChangedSignObj(baseActor);
	}
}

void UWorldManager::ModifyClipParams(int64 InActorID, bool bIgnore)
{
	if(InActorID == 0)
	{
		for (auto& Elem : WorldSignObjectsMap)
		{
			Elem.Value.bIgnore = false;
		}
		return;
	}
	
	AActor* InActor = KGUtils::GetActorByID(InActorID);
	if(!IsValid(InActor))
	{
		return;
	}

	if(ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(InActor))
	{
		bViewMatrixChanged = true;
		FWorldSignObjectInfo* SignObj = WorldSignObjectsMap.Find(BaseCharacter);
		if (SignObj)
		{
			SignObj->bIgnore = bIgnore;
			ForceSetClipVisible(SignObj);
		}
	}
}

void UWorldManager::ForceSetClipVisible(FWorldSignObjectInfo* SignObj)
{
	if (!bEnableForceClipVisible || !SignObj)
	{
		return;
	}
	
	SignObj->LastClipState = SignObj->ClipState;
	SignObj->ClipState = 0;
	if (SignObj->Actor.IsValid())
	{
		CallLuaFunction("OnActorVisibleChanged",SignObj->Actor->GetEntityUID(), SignObj->FilterType, SignObj->ClipState, SignObj->InScreen, SignObj->LastClipState);
	}
}

void UWorldManager::HideAllPlayer(bool enable)
{
	bHideAllPlayer = enable;
}

void UWorldManager::ModifyClipPriority(int64 InActorID, int32 NewPriority, int32 ClipInfluenceDist)
{
	AActor* InActor = KGUtils::GetActorByID(InActorID);
	if(!IsValid(InActor))
	{
		return;
	}

	if(ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(InActor))
	{
		FWorldSignObjectInfo* SignObj = WorldSignObjectsMap.Find(BaseCharacter);
		if (SignObj)
		{
			SignObj->ClipPriority = NewPriority;
			SignObj->ClipInfluenceDist = ClipInfluenceDist / ClipDistancePrecision;
		}
	}
}

// #128596 当距离因子的权重低于其他关系时，仅在其他关系内进行距离的排序显示；
//当距离因子的权重高于其他关系时，优先以距离进行排序显示，当多个目标距离相同时，再根据其他对应低权重关系进行显示。@hujianglong
bool UWorldManager::SortFilterActorsByDistanceAndPriority(const FFilterActorData& A, const FFilterActorData& B, FWorldSignObjectInfo* A_SignObjInfo, FWorldSignObjectInfo* B_SignObjInfo)
{
	// 如果 A 或 B 没有对应的 WorldSignObjectInfo，直接返回距离的排序
	if (!A_SignObjInfo || !B_SignObjInfo)
	{
		return A.Dis < B.Dis;
	}

	const bool AInfluenceDist = A.Dis <= A_SignObjInfo->ClipInfluenceDist;
	const bool BInfluenceDist = B.Dis <= B_SignObjInfo->ClipInfluenceDist;
	
	if (AInfluenceDist && BInfluenceDist)
	{
		// 先按ClipPriority排序
		if (A_SignObjInfo->ClipPriority != B_SignObjInfo->ClipPriority)
		{
			return A_SignObjInfo->ClipPriority < B_SignObjInfo->ClipPriority;
		}
		// ClipPriority相同的按距离排序，距离相同的按EntityUID排序
		if (A_SignObjInfo->ClipPriority == B_SignObjInfo->ClipPriority)
		{
			if (FMath::IsNearlyEqual(A.Dis, B.Dis, 0.01F))
			{
				return A_SignObjInfo->Actor->GetEntityUID() < B_SignObjInfo->Actor->GetEntityUID();
			}
			return A.Dis < B.Dis;
		}
	}
	else if(AInfluenceDist || BInfluenceDist)
	{
		return AInfluenceDist;
	}

	//超出范围，直接返回距离的排序
	if (FMath::IsNearlyEqual(A.Dis, B.Dis, 0.01F))
	{
		// 如果ClipPriority和Dis相同，根据 Actor UID 排序
		return A_SignObjInfo->Actor->GetEntityUID() < B_SignObjInfo->Actor->GetEntityUID();
	}
		
	return A.Dis < B.Dis;
}


bool UWorldManager::SortBriefActorsByDistanceAndPriority(FBriefSignObjectInfo& A_BriefSignObjInfo, FBriefSignObjectInfo& B_BriefSignObjInfo)
{
	if(!A_BriefSignObjInfo.Actor.IsValid() || !B_BriefSignObjInfo.Actor.IsValid())
	{
		return A_BriefSignObjInfo.Dis < B_BriefSignObjInfo.Dis;
	}
	
	const bool AInfluenceDist = A_BriefSignObjInfo.Dis <= A_BriefSignObjInfo.BriefInfluenceDist;
	const bool BInfluenceDist = B_BriefSignObjInfo.Dis <= B_BriefSignObjInfo.BriefInfluenceDist;
	
	IC7ActorInterface* A_C7Actor = Cast<IC7ActorInterface>(A_BriefSignObjInfo.Actor);
	IC7ActorInterface* B_C7Actor = Cast<IC7ActorInterface>(B_BriefSignObjInfo.Actor);
	
	check(A_C7Actor)
	check(B_C7Actor)
	
	if (AInfluenceDist && BInfluenceDist)
	{
		// 先按ClipPriority排序
		if (A_BriefSignObjInfo.BriefPriority != B_BriefSignObjInfo.BriefPriority)
		{
			return A_BriefSignObjInfo.BriefPriority < B_BriefSignObjInfo.BriefPriority;
		}
		// ClipPriority相同的按距离排序，距离相同的按EntityUID排序
		if (A_BriefSignObjInfo.BriefPriority == B_BriefSignObjInfo.BriefPriority)
		{
			if (FMath::IsNearlyEqual(A_BriefSignObjInfo.Dis, B_BriefSignObjInfo.Dis, 0.01F))
			{
				return A_C7Actor->GetEntityUID() < B_C7Actor->GetEntityUID();
			}
			return A_BriefSignObjInfo.Dis < B_BriefSignObjInfo.Dis;
		}
	}
	else if(AInfluenceDist || BInfluenceDist)
	{
		return AInfluenceDist;
	}

	//超出范围，直接返回距离的排序
	if (FMath::IsNearlyEqual(A_BriefSignObjInfo.Dis, B_BriefSignObjInfo.Dis, 0.01F))
	{
		// 如果ClipPriority和Dis相同，根据 Actor UID 排序
		return A_C7Actor->GetEntityUID() < B_C7Actor->GetEntityUID();
	}
		
	return A_BriefSignObjInfo.Dis < B_BriefSignObjInfo.Dis;
}

void UWorldManager::SetClipObjectState(FWorldSignObjectInfo* SignObj,bool enable,bool bInScreen,bool bForce)
{
	if(!SignObj)
		return;
	//裁剪和是否在屏幕内是两个维度，没被裁剪但在屏幕外的也有处理逻辑(关tick,关动画等)
	if(!enable)
	{
		if (SignObj->ClipState != 0 && (bInScreen || bForce))
		{
			MarkClipStateChanged.Add(SignObj->Actor.Get(), 0);
			SignObj->LastClipState = SignObj->ClipState;
			SignObj->ClipState = 0;
		}
	}
	else
	{
		if (SignObj->ClipState != 1 || bInScreen != SignObj->InScreen)
		{
			MarkClipStateChanged.Add(SignObj->Actor.Get(), 1);
			SignObj->LastClipState = SignObj->ClipState;
			SignObj->ClipState = 1;
		}
	}

	SignObj->Actor->SetInScreen(bInScreen || !bEnableActorViewMatrixClipDisableVisible);
	SignObj->InScreen = bInScreen;
}

void UWorldManager::RemoveSignObject(FWorldSignObjectInfo& InSignObject)
{
	if (!InSignObject.Actor.IsValid() || !UKismetSystemLibrary::IsValid(InSignObject.Actor.Get()))
	{
		return;
	}

	if (UKismetSystemLibrary::IsValid(InSignObject.Actor->GetRootComponent()))
	{
		InSignObject.Actor->GetRootComponent()->TransformUpdated.RemoveAll(this);
	}
}

void UWorldManager::PushTransformChangedSignObj(ABaseCharacter* InActor)
{
	WorldSignObjsTransformChanged.Add(InActor, true);
}
#pragma endregion CharacterClip


void UWorldManager::EnableForceClipVisible(bool enable)
{
	bEnableForceClipVisible = enable;
}

void UWorldManager::EnableActorLimitClip(bool enable)
{
	bEnableActorLimitClip = enable;
}
 
void UWorldManager::EnableActorLod(bool enable)
{
	bEnableActorLod = enable;
}

void UWorldManager::EnableUseWasRecentlyRendered(bool enable, float checkTime)
{
	bUseWasRecentlyRendered = enable;
	bUseWasRecentlyRenderedCheckTimer = checkTime;
}
 
void UWorldManager::EnableActorViewMatrixClip(bool enable, bool enableVisible)
{
	bEnableActorViewMatrixClip = enable;
	bEnableActorViewMatrixClipDisableVisible = enableVisible;
}

void UWorldManager::EditorTick(float DeltaTime)
{
	ProcessWaterWaveEffect(DeltaTime);
}

void UWorldManager::SetPreviewCamera(int64 InActorID)
{
	AActor* CameraActor = KGUtils::GetActorByID(InActorID);
	UKGFaceControlSubsystem::GetInstance()->SetPreviewCamera(CameraActor);
}

void UWorldManager::OnPostLoadMapWithWorld(UWorld* World)
{
	if(World == nullptr || World->PersistentLevel == nullptr)
	{
		return;
	}
	TickFunction.UnRegisterTickFunction();
	TickFunction.Manager = this;
	TickFunction.TickGroup = ETickingGroup::TG_LastDemotable;
	TickFunction.RegisterTickFunction(World->PersistentLevel);

	// 默认切换world这里直接全清理
	bPostProcessVolumeEnabled = true;
	bDirectionalLightEnabled = true;
	FogSwitchCount = 1;
	DisabledPPVolumes.Empty();
	DisabledHeightFogs.Empty();
	DisabledMainSkyPerformers.Empty();
	DisabledDirectionalLights.Empty();
	ClearActorSpawnDelegate();
}

void UWorldManager::Tick(float DeltaTime)
{
	QUICK_SCOPE_CYCLE_COUNTER(WorldManager_Tick);
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UWorldManager_Tick");

	UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(this);
	if (!ActorManager) {
		return;
	}
	UpdateViewState(DeltaTime);

	if(CurClipLoopTime >= 0)
	{
		CurClipLoopTime -= DeltaTime;
	}

	if ((CurClipLoopTime < 0 || bViewMatrixChanged) && GIPtr.IsValid() && (bViewMatrixChanged || !WorldSignObjsTransformChanged.IsEmpty()))
	{
		CurClipLoopTime = ClipLoopTime;
		
		if (UGameViewportClient* ViewportClient = GIPtr->GetWorld()->GetGameViewport())
		{
			FSceneViewProjectionData ProjectionData;
			ULocalPlayer const* const LP = GIPtr->GetFirstGamePlayer();
			if (LP && LP->ViewportClient)
			{
				if (APlayerController* PlayerController = LP->GetPlayerController(GIPtr->GetWorld()))
				{
					if (APawn* _Pawn = PlayerController->GetPawn())
					{
						const FTransform& _PawnTF = _Pawn->GetTransform();
						if (!_PawnTF.EqualsNoScale(LastLocPlayerTransform))
						{
							LastLocPlayerTransform = _PawnTF;
							if (SpaceDivision)
							{
								SpaceDivision->ViewTransformChanged(LastLocPlayerTransform);
							}
						}
					}

					if (LP->GetProjectionData(ViewportClient->Viewport, ProjectionData))
					{
						FMatrix ViewProjectionMatrix;
						FVector2D ScreenPosition2D;
						FVector ViewPos = ProjectionData.ViewOrigin;
						FVector PlayerLoc(ViewPos);
						if (APawn* PawnActor = PlayerController->GetPawn())
						{
							PlayerLoc = PawnActor->GetActorLocation();
						}

						ViewProjectionMatrix = ProjectionData.ComputeViewProjectionMatrix();

						CurClipFilterMap.Reset();
						for (auto It = WorldSignObjectsMap.CreateIterator(); It; ++It)
						{
							FWorldSignObjectInfo& SignObj = It.Value();
							if (!SignObj.Actor.IsValid())
							{
								It.RemoveCurrent();
								continue;
							}

							if (!bViewMatrixChanged && (!SignObj.bOberverClip && !WorldSignObjsTransformChanged.Contains(It.Key())))
							{
								continue;
							}

							FVector WorldLocation = SignObj.Actor->GetActorLocation();
							bool bInScreen = FSceneView::ProjectWorldToScreen(WorldLocation, ProjectionData.GetConstrainedViewRect(), ViewProjectionMatrix, ScreenPosition2D);

							if(bUseWasRecentlyRendered)
							{
								//CVarRayTracingDynamicGeometryLastRenderTimeUpdateDistance RayTracing 和 DynamicShadow会导致WasRecentlyRendered失效，让不可见也Disable,但可能有潜在BUG
								//结合bUseScreenRenderStateForUpdate，主Mesh的bRecentlyRendered可以用来当可见性判断依据
								//bRecentlyRendered的更新是在TickComponent中执行，我们Invisible又会关闭Tick,所以我们这里自己算一下，LastRenderTimeOnScreen是渲染线程设置过来的
								USkeletalMeshComponent* MainMesh = SignObj.Actor->GetMainMesh();
								if(MainMesh && MainMesh->GetSkeletalMeshAsset())
								{
									// See if this mesh was rendered recently. This has to happen first because other data will rely on this
									bool WasRecentlyRendered = MainMesh->GetLastRenderTimeOnScreen() < 0 || MainMesh->GetLastRenderTimeOnScreen() > GetWorld()->TimeSeconds - bUseWasRecentlyRenderedCheckTimer;
									SignObj.Actor->EnableAnimTickOptimization(!WasRecentlyRendered);
									//UE_LOG(LogTemp, Warning, TEXT("[WorldManager::WasRecentlyRendered] WasRecentlyRendered name:%s bRecentlyRendered:%s bUseScreenRenderStateForUpdate:%s"), *SignObj.Actor->GetName(), WasRecentlyRendered ? TEXT("True"):TEXT("False"), MainMesh->bUseScreenRenderStateForUpdate ? TEXT("True"):TEXT("False"));
								}
							}
							
							if(SignObj.bOberverClip)
							{
								if (SignObj.bIgnore)
								{
									SetClipObjectState(&SignObj, false, bInScreen, true);
								}
								else if (bInScreen)
								{
									bool bShouldClip = bEnableActorLimitClip && bHideAllPlayer;
									SetClipObjectState(&SignObj, bShouldClip, true);
								}
								else
								{
									SetClipObjectState(&SignObj, bEnableActorViewMatrixClip, false);
								}
							
								if (bEnableActorLimitClip && !bHideAllPlayer)
								{
									FClipFilterParams& Params = CurClipFilterMap.FindOrAdd(SignObj.FilterType);
									Params.FilterType = SignObj.FilterType;
									FFilterActorData Data;
									Data.FilterActor = SignObj.Actor.Get();
									if (SignObj.bIgnore)
									{
										Params.IgnoreActors.Add(Data);
									}
									else
									{
										SignObj.Dis = FMath::Floor(FVector::Dist(PlayerLoc, WorldLocation)/ ClipDistancePrecision);
										Data.Dis = SignObj.Dis;
										Params.FilterActors.Add(Data);
									}
								}
							}
							

							if(bEnableActorLod && SignObj.bRLOD)
							{
								float TDis = FVector::Dist(PlayerLoc, WorldLocation);
								float OldLodDistance = SignObj.LastLodDistance;
								SignObj.LastLodDistance = TDis;
								int32 NewLOD(CalculateSignLod(TDis));
								bool IsLodChanged = SignObj.LOD != NewLOD;
								
								if (IsUseAnimationBudget) {
									if (fabsf(TDis - OldLodDistance) > AnimationBudgetUpdateDistance || IsLodChanged) {
										auto* CppEntity = ActorManager->GetLuaEntityByActor(SignObj.Actor.Get());
										if (CppEntity && CppEntity->GetIsUseAnimationBudget()) {
											TArray<ICppEntityInterface*> VisitedEnts;
											CppEntity->SkeletalMesh_SetSKBudgetedComponentSignificance(
											VisitedEnts,
												CalculateAnimationBudgetSignificance(NewLOD, CppEntity->GetEntitySignificance(), TDis)
											);
										}
									}
								}

								if (IsLodChanged)
								{
									MarkWorldSignLODChanged.Add(SignObj.Actor.Get(), NewLOD);
									SignObj.LOD = NewLOD;
								}
							}
						}

						if(bEnableActorLimitClip and !bHideAllPlayer)
						{
							for (auto& Elem : CurClipFilterMap)
							{
								FClipFilterParams& FilterData = Elem.Value;
								int32* Num = LimitClipNumMap.Find(FilterData.FilterType);
								if (!Num)
									continue;

								int32 LimitVisibleNum = *Num;
								int32 IgnoreNum = FilterData.IgnoreActors.Num();
								int32 FilterNum = FilterData.FilterActors.Num();

								int32 FinalVisibleNum = LimitVisibleNum - IgnoreNum;
								if (FilterNum <= FinalVisibleNum)
								{
									for (auto& FilterActorData : FilterData.FilterActors)
									{
										FWorldSignObjectInfo* SignObjInfo = WorldSignObjectsMap.Find(FilterActorData.FilterActor);
										SetClipObjectState(SignObjInfo, false, SignObjInfo->InScreen);
									}
								}
								else
								{
									// cppcheck:push ignore
									FilterData.FilterActors.Sort(
										[this](const FFilterActorData& A, const FFilterActorData& B)
										{
											FWorldSignObjectInfo* A_SignObjInfo = WorldSignObjectsMap.Find(A.FilterActor);
											FWorldSignObjectInfo* B_SignObjInfo = WorldSignObjectsMap.Find(B.FilterActor);
											return SortFilterActorsByDistanceAndPriority(A, B, A_SignObjInfo, B_SignObjInfo);
										}
									);
									// cppcheck:pop

									for (int32 i(0); i < FilterNum; ++i)
									{
										FFilterActorData& ActorData = FilterData.FilterActors[i];
										FWorldSignObjectInfo* SignObjInfo = WorldSignObjectsMap.Find(ActorData.FilterActor);
										if (!SignObjInfo)
											continue;

										SetClipObjectState(SignObjInfo, i >= FinalVisibleNum, SignObjInfo->InScreen);
									}
								}
							}
						}
						
						CurClipFilterMap.Reset();
					}
				}
			}
		}
		
		WorldSignObjsTransformChanged.Empty();
		bViewMatrixChanged = false;
	}

	int32 INotifyNum(0);
	for (TMap<ABaseCharacter*, int32>::TIterator ItrMap(MarkWorldSignLODChanged); ItrMap; ++ItrMap)
	{
		if (INotifyNum > MaxNotifyActorLODNum)
		{
			break;
		}
		++INotifyNum;

		ActorLodChanged(ItrMap.Key(), ItrMap.Value());

		ItrMap.RemoveCurrent();
	}

	INotifyNum = 0;
	int32 CurMaxNotifyClipActorNum = FMath::Max(MaxNotifyClipActorNum,ForceMaxNotifyClipActorNum);
	for (TMap<ABaseCharacter*, int32>::TIterator ItrMap(MarkClipStateChanged); ItrMap; ++ItrMap)
	{
		if (INotifyNum > CurMaxNotifyClipActorNum * 3)
		{
			break;
		}
		++INotifyNum;
		
		FWorldSignObjectInfo* SignObjInfo = WorldSignObjectsMap.Find(ItrMap.Key());
		if (SignObjInfo && SignObjInfo->Actor.IsValid())
		{
			if(SignObjInfo->InScreen && SignObjInfo->ClipState == 0)
			{
				CallLuaFunction("OnActorVisibleChanged",SignObjInfo->Actor->GetEntityUID(),SignObjInfo->FilterType, ItrMap.Value(), SignObjInfo->InScreen, SignObjInfo->LastClipState);
				ItrMap.RemoveCurrent();
			}
		}
	}

	INotifyNum = 0;
	for (TMap<ABaseCharacter*, int32>::TIterator ItrMap(MarkClipStateChanged); ItrMap; ++ItrMap)
	{
		if (INotifyNum > CurMaxNotifyClipActorNum)
		{
			break;
		}
		++INotifyNum;

		FWorldSignObjectInfo* SignObjInfo = WorldSignObjectsMap.Find(ItrMap.Key());
		if (SignObjInfo && SignObjInfo->Actor.IsValid())
		{
			CallLuaFunction("OnActorVisibleChanged",SignObjInfo->Actor->GetEntityUID(),SignObjInfo->FilterType, ItrMap.Value(), SignObjInfo->InScreen, SignObjInfo->LastClipState);
		}
		ItrMap.RemoveCurrent();
	}
	ForceMaxNotifyClipActorNum = 0;
	
	if (SpaceDivision)
	{
		SpaceDivision->UpdateTriggerState(DeltaTime);
	}

	CurBriefUpdateTime -= DeltaTime;
	if(CurBriefUpdateTime < 0)
	{
		UpdateBrief();
	}
	
	ProcessWaterWaveEffect(DeltaTime);
	ProcessWindMotorEffect(DeltaTime);
	DrawDebug(DeltaTime);

	InnerUpdateAllTODLightActors(DeltaTime);
}

void UWorldManager::DrawDebug(float DeltaTime)
{
	if (CVarWorldManagerLODDebug.GetValueOnAnyThread())
	{
		if (GIPtr.IsValid())
		{
			for (auto It = WorldSignObjectsMap.CreateIterator(); It; ++It)
			{
				const FWorldSignObjectInfo& SignObj = It.Value();
				if (SignObj.Actor.IsValid())
				{
					int32 Lod(SignObj.LOD);
					if (int32* MarkLOD = MarkWorldSignLODChanged.Find(It.Key()))
					{
						Lod = *MarkLOD;
					}

					FString Result = FString::Printf(TEXT("%d"), Lod);
					FVector DrawLoc = SignObj.Actor->GetActorLocation();
					DrawLoc += FVector(0, 0, 140);
					DrawDebugString(GIPtr->GetWorld(), DrawLoc, Result, 0, FColor::Yellow, DeltaTime);
				}
			}
		}
	}

	if (CVarWorldManagerSpaceDivisionDebug.GetValueOnAnyThread())
	{
		if (GIPtr.IsValid())
		{
			if (SpaceDivision)
			{
				SpaceDivision->DebugDrawTick(GIPtr->GetWorld(), DeltaTime);
			}
		}
	}
}

void UWorldManager::ProcessWaterWaveEffect(float DeltaTime)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UWorldManager_Tick_ProcessWaterWaveEffect");
	WaterWaveTickTaskToRemove.Reset();
	for (TMap<int64, FWaterWaveParameters>::TIterator ItrMap(WaterWaveParametersTickCache); ItrMap; ++ItrMap)
	{
		FWaterWaveParameters& Parameters = ItrMap.Value();
		Parameters.Timer = Parameters.Timer - DeltaTime;
		if (Parameters.Timer <= 0)
		{
			if(Parameters.MoveSpeed > 1)
			{
				float currentSpeed = Parameters.MoveSpeed;
				Parameters.PositionX += Parameters.MoveDirX * currentSpeed;
				Parameters.PositionY += Parameters.MoveDirY * currentSpeed;
			}
			ExecuteMotorForDynamicWaterWave(Parameters.MotorTextureID, Parameters.PositionX, Parameters.PositionY,
				Parameters.RotationYaw, Parameters.ScaleX, Parameters.ScaleY, Parameters.MaxHeight, Parameters.FoamScale);
			Parameters.Timer = Parameters.TimeGap;

			if (Parameters.bAutoStop)
			{
				if (--Parameters.WaveTimes <= 0)
				{
					WaterWaveTickTaskToRemove.Add(ItrMap.Key());
				}
			}
		}
	}

	for (auto& RequestID : WaterWaveTickTaskToRemove)
	{
		UnRegisterWaterWaveTick(RequestID);
	}
}

void UWorldManager::UpdateViewState(float DeltaTime)
{
	if (!GIPtr.IsValid())
		return;
	
	if (UGameViewportClient* ViewportClient = GIPtr->GetWorld()->GetGameViewport())
	{
		ULocalPlayer const* const LP = GIPtr->GetFirstGamePlayer();
		
		if (LP && LP->ViewportClient)
		{
			APlayerController* PlayerController = LP->GetPlayerController(GIPtr->GetWorld());
			if(!IsValid(PlayerController) || !IsValid(PlayerController->PlayerCameraManager))
			{
				return;
			}
			const FMinimalViewInfo CurrentViewInfo = PlayerController->PlayerCameraManager->GetCameraCacheView();

			FSceneViewProjectionData ProjectionData;
			if (LP->GetProjectionData(ViewportClient->Viewport, /*out*/ ProjectionData))
			{
				// 获取当前相机的位置和旋转
				FVector CurrentCameraPosition = CurrentViewInfo.Location;
				FRotator CurrentCameraRotation = CurrentViewInfo.Rotation;

				// 检查相机位置是否有显著变化
				float PositionDelta = FVector::Dist(CurrentCameraPosition, LastCameraPosition);
				if (PositionDelta > PositionThreshold)
				{
					bViewMatrixChanged = true;
				}

				// 检查相机旋转是否有显著变化
				float RotationDelta = FMath::Abs(CurrentCameraRotation.Pitch - LastCameraRotation.Pitch) +
									  FMath::Abs(CurrentCameraRotation.Yaw - LastCameraRotation.Yaw) +
									  FMath::Abs(CurrentCameraRotation.Roll - LastCameraRotation.Roll);
				if (RotationDelta > RotationThreshold)
				{
					bViewMatrixChanged = true;
				}

				if(bViewMatrixChanged)
				{
					// 更新上一次的位置和旋转
					LastCameraPosition = CurrentCameraPosition;
					LastCameraRotation = CurrentCameraRotation;
				}
			}
		}
	}
}

#pragma region SceneActor
void UWorldManager::EnableMainSkyPerformer(bool Enable)
{
	if (!GetWorld())
		return;

	if (UGeographyClimateSubsystem* GeographyClimateSystem = GetWorld()->GetSubsystem<UGeographyClimateSubsystem>())
	{
		GeographyClimateSystem->SetPerformerEnable(Enable);
	}
}

void UWorldManager::EnableMainSkyPerformerVisibleAndTickable(bool Enable)
{
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	TArray<AActor*> Results;
	UGameplayStatics::GetAllActorsOfClass(World, AMainSkyPerformer::StaticClass(), Results);
	for (AActor* Actor : Results)
	{
		if (AMainSkyPerformer* MainSkyPerformer = Cast<AMainSkyPerformer>(Actor))
		{
			MainSkyPerformer->SetVisibleAndTickable(Enable);
		}
	}
}


void UWorldManager::EnableDirectionalLight(bool bEnable)
{
	SCOPED_NAMED_EVENT(UWorldManager_EnableDirectionalLight, FColor::Red);
	
	if (bDirectionalLightEnabled == bEnable)
	{
		return;
	}
	
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}
	
	bDirectionalLightEnabled = bEnable;

	if (bDirectionalLightEnabled)
	{
		for (auto DisabledDirectionalLight : DisabledDirectionalLights)
		{
			if (DisabledDirectionalLight.IsValid())
			{
				DisableDirectionalLight(DisabledDirectionalLight.Get(), false);
			}
		}
		DisabledDirectionalLights.Empty();
	}
	else
	{
		TArray<AActor*> Results;
		UGameplayStatics::GetAllActorsOfClass(World, ADirectionalLight::StaticClass(), Results);
		for (AActor* Actor : Results)
		{
			if (ADirectionalLight* LightActor = Cast<ADirectionalLight>(Actor))
			{
				if (DisableDirectionalLight(LightActor, true))
				{
					DisabledDirectionalLights.Add(LightActor);
				}
			}
		}
	}
	
	RefreshActorSpawnDelegate();
}

void UWorldManager::EnableFogs(bool bEnable)
{
	SCOPED_NAMED_EVENT(UWorldManager_EnableFogs, FColor::Red);
	
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	// 目前铅笔画后效和角色展示界面都会控制这个开关, 为了避免冲突加一个计数器来处理
	bool bOldEnable = FogSwitchCount > 0;
	if (bEnable)
	{
		FogSwitchCount++;
	}
	else
	{
		FogSwitchCount--;
	}
	bool bNewEnable = FogSwitchCount > 0;

	if (bOldEnable == bNewEnable)
	{
		return;
	}

	if (bNewEnable)
	{
		for (auto DisabledHeightFog : DisabledHeightFogs)
		{
			if (DisabledHeightFog.IsValid())
			{
				DisableExponentialHeightFog(DisabledHeightFog.Get(), false);
			}
		}
		DisabledHeightFogs.Empty();
		
		for (auto DisabledMainSkyPerformer : DisabledMainSkyPerformers)
		{
			if (DisabledMainSkyPerformer.IsValid())
			{
				DisableMainSkyPerformerHeightFog(DisabledMainSkyPerformer.Get(), false);
			}
		}
		DisabledMainSkyPerformers.Empty();
	}
	else
	{
		TArray<AActor*> Results;
		UGameplayStatics::GetAllActorsOfClass(World, AExponentialHeightFog::StaticClass(), Results);
		for (AActor* Actor : Results)
		{
			if (AExponentialHeightFog* FogActor = Cast<AExponentialHeightFog>(Actor))
			{
				if (DisableExponentialHeightFog(FogActor, true))
				{
					DisabledHeightFogs.Add(FogActor);
				}
			}
		}
	
		UGameplayStatics::GetAllActorsOfClass(World, AMainSkyPerformer::StaticClass(), Results);
		for (AActor* Actor : Results)
		{
			if (AMainSkyPerformer* MainSkyPerformer = Cast<AMainSkyPerformer>(Actor))
			{
				if (DisableMainSkyPerformerHeightFog(MainSkyPerformer, true))
				{
					DisabledMainSkyPerformers.Add(MainSkyPerformer);
				}
			}
		}
	}

	RefreshActorSpawnDelegate();
}

void UWorldManager::EnableVolumetricLightmap(bool Enable)
{
	if (!GIPtr.IsValid())
		return;
	
	if (UGameViewportClient* ViewportClient = GIPtr->GetWorld()->GetGameViewport())
	{
		ViewportClient->EngineShowFlags.SetVolumetricLightmap(Enable);
	}
}

void UWorldManager::EnablePPVolumes(bool bEnable)
{
	SCOPED_NAMED_EVENT(UWorldManager_EnablePPVolumes, FColor::Red);
	
	if (bPostProcessVolumeEnabled == bEnable)
	{
		return;
	}
	
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}
	
	bPostProcessVolumeEnabled = bEnable;

	if (bPostProcessVolumeEnabled)
	{
		for (auto DisabledPPVolume : DisabledPPVolumes)
		{
			if (DisabledPPVolume.IsValid())
			{
				DisablePPVolume(DisabledPPVolume.Get(), false);
			}
		}
		DisabledPPVolumes.Empty();
	}
	else
	{
		TArray<AActor*> Results;
		UGameplayStatics::GetAllActorsOfClass(GetWorld(), APostProcessVolume::StaticClass(), Results);
		for (AActor* Actor : Results)
		{
			if (APostProcessVolume* PPVolume = Cast<APostProcessVolume>(Actor))
			{
				if (DisablePPVolume(PPVolume, true))
				{
					DisabledPPVolumes.Add(PPVolume);
				}
			}
		}
	}

	RefreshActorSpawnDelegate();
}

void UWorldManager::OnActorSpawned(AActor* InActor)
{
	if (InActor == nullptr)
	{
		return;
	}

	if (!bPostProcessVolumeEnabled)
	{
		if (APostProcessVolume* PostProcessVolume = Cast<APostProcessVolume>(InActor))
		{
			if (DisablePPVolume(PostProcessVolume, true))
			{
				DisabledPPVolumes.Add(PostProcessVolume);
			}
			return;
		}
	}

	if (FogSwitchCount <= 0)
	{
		if (AExponentialHeightFog* FogActor = Cast<AExponentialHeightFog>(InActor))
		{
			if (DisableExponentialHeightFog(FogActor, true))
			{
				DisabledHeightFogs.Add(FogActor);
			}
			return;
		}

		if (AMainSkyPerformer* MainSkyPerformer = Cast<AMainSkyPerformer>(InActor))
		{
			if (DisableMainSkyPerformerHeightFog(MainSkyPerformer, true))
			{
				DisabledMainSkyPerformers.Add(MainSkyPerformer);
			}
			return;
		}
	}

	if (!bDirectionalLightEnabled)
	{
		if (ADirectionalLight* LightActor = Cast<ADirectionalLight>(InActor))
		{
			if (DisableDirectionalLight(LightActor, true))
			{
				DisabledDirectionalLights.Add(LightActor);
			}
			return;
		}
	}
}

void UWorldManager::BindActorSpawnDelegate()
{
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	if (ActorSpawnedDelegateHandle.IsValid())
	{
		World->RemoveOnActorSpawnedHandler(ActorSpawnedDelegateHandle);
		ActorSpawnedDelegateHandle.Reset();	
	}

	FOnActorSpawned::FDelegate ActorSpawnedDelegate = FOnActorSpawned::FDelegate::CreateUObject(this, &UWorldManager::OnActorSpawned);
	ActorSpawnedDelegateHandle = World->AddOnActorSpawnedHandler(ActorSpawnedDelegate);
}

void UWorldManager::ClearActorSpawnDelegate()
{
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	if (!ActorSpawnedDelegateHandle.IsValid())
	{
		return;
	}
	
	World->RemoveOnActorSpawnedHandler(ActorSpawnedDelegateHandle);
	ActorSpawnedDelegateHandle.Reset();
}

void UWorldManager::RefreshActorSpawnDelegate()
{
	if (NeedToBindActorSpawnDelegate())
	{
		BindActorSpawnDelegate();
	}
	else
	{
		ClearActorSpawnDelegate();
	}
}

bool UWorldManager::DisablePPVolume(APostProcessVolume* PostProcessVolume, bool bDisable)
{
	if (!PostProcessVolume)
	{
		return false;
	}

	const bool bNewEnabled = !bDisable;
	if (PostProcessVolume->bEnabled == bNewEnabled)
	{
		return false;
	}

	// platform active优先级大于业务优先级
	if (!PostProcessVolume->Platforms.IsActive())
	{
		return false;
	}

	PostProcessVolume->bEnabled = bNewEnabled;
	return true;
}

bool UWorldManager::DisableExponentialHeightFog(AExponentialHeightFog* HeightFog, bool bDisable)
{
	if (!HeightFog)
	{
		return false;
	}

	if (HeightFog->IsHidden() == bDisable)
	{
		return false;
	}

	HeightFog->SetActorHiddenInGame(bDisable);
	return true;
}

bool UWorldManager::DisableMainSkyPerformerHeightFog(AMainSkyPerformer* MainSkyPerformer, bool bDisable)
{
	if (!MainSkyPerformer)
	{
		return false;
	}

	const bool bNewEnabled = !bDisable;
	if (MainSkyPerformer->EnableHeightFog == bNewEnabled)
	{
		return false;		
	}

	MainSkyPerformer->EnableHeightFog = !bDisable;
	return true;
}

bool UWorldManager::DisableDirectionalLight(ADirectionalLight* DirectionalLight, bool bDisable)
{
	if (!DirectionalLight)
	{
		return false;
	}

	if (DirectionalLight->IsHidden() == bDisable)
	{
		return false;
	}

	if (ULightComponent* LightComponent = DirectionalLight->GetLightComponent())
	{
		LightComponent->SetVisibility(!bDisable);
	}
	DirectionalLight->SetActorHiddenInGame(bDisable);
	return true;
}
#pragma endregion SceneActor

#pragma region SpaceDivision

void UWorldManager::RegisterSceneActor(int64 InstanceID, AC7Actor* InActor)
{
	if (!UKismetSystemLibrary::IsValid(InActor))
		return;

	FActorTypeInfo& ActorTypeInfo = ActorTypeMap.FindOrAdd(InActor->GetActorType());
	ActorTypeInfo.ActorMap.Add(InActor->GetEntityUID(), FWorldWeakActor(InActor));

	SceneActorMap.Add(InstanceID, FWorldWeakActor(InActor));
	int64 ActorID = KGUtils::GetIDByObject(InActor);
	FVector ActorLocation = InActor->K2_GetActorLocation();
	FRotator ActorRotator = InActor->K2_GetActorRotation();
	CallLuaFunction("OnSceneActorRegister", ActorID,InstanceID, InActor->GetActorType(),
		ActorLocation.X,ActorLocation.Y,ActorLocation.Z, ActorRotator.Pitch,ActorRotator.Yaw,ActorRotator.Roll);

}

void UWorldManager::UnRegisterSceneActor(int64 InstanceID, AC7Actor* InActor)
{
	if (IsValid(InActor))
	{
		CallLuaFunction("OnSceneActorUnRegister", InstanceID, InActor->GetActorType());
		
		if (FActorTypeInfo* ActorTypeInfo = ActorTypeMap.Find(InActor->GetActorType()))
		{
			ActorTypeInfo->ActorMap.Remove(InActor->GetEntityUID());
		}
	}
	SceneActorMap.Remove(InstanceID);
}

void UWorldManager::RegisterMassNPCActor(AActor* InActor, const FString& SuitLibKey, const FString& BodyType, const FString& Rank)
{
	if (!UKismetSystemLibrary::IsValid(InActor))
		return;
	int64 ActorID = KGUtils::GetIDByObject(InActor);
	CallLuaFunction("KCB_OnCrowdNPCRegister", ActorID, SuitLibKey, BodyType, Rank);
}

void UWorldManager::UnRegisterMassNPCActor(AActor* InActor, const FString& SuitLibKey, const FString& BodyType, const FString& Rank)
{
	if (!UKismetSystemLibrary::IsValid(InActor))
		return;
	int64 ActorID = KGUtils::GetIDByObject(InActor);
	CallLuaFunction("KCB_OnCrowdNPCUnRegister", ActorID, SuitLibKey, BodyType, Rank);
}

TArray<FString> UWorldManager::RandomCrowdNPCSuitData(const FString& CrowdNPCRank, const FString& BodyType)
{
	return CallLuaFunction<TArray<FString>>("KCB_RandomCrowdNPCSuitData", CrowdNPCRank, BodyType);
}


bool UWorldManager::AddAOISceneElement(KGEntityID UID, float PositionX, float PositionY, float PositionZ, float EntitySphereRadius) {
	if (!SpaceDivision) {
		UE_LOG(LogTemp, Error, TEXT("[WorldManager::AddStaticEntityToClientAOI] UnExpected SpaceDivision == nullptr"));
		return false;
	}
	
	return SpaceDivision->AddAOISceneElement(UID, PositionX, PositionY, PositionZ, EntitySphereRadius);
}

bool UWorldManager::RemoveAOISceneElement(KGEntityID UID) {
	if (!SpaceDivision) {
		UE_LOG(LogTemp, Error, TEXT("[WorldManager::RemoveAOISceneElement] UnExpected SpaceDivision == nullptr"));
		return false;
	}

	return SpaceDivision->RemoveAOISceneElement(UID);
}



void UWorldManager::UpdateAOIElement_Transform(const int64& UID, const FVector& InPos, const FRotator& InDir)
{
	if (SpaceDivision) {
		SpaceDivision->UpdateAOIElement_Transform(UID, InPos, InDir);
	}
}



void UWorldManager::ClearAllElement()
{
	if(SpaceDivision)
		SpaceDivision->ClearAll();

	ActorTransformBindMapForTriggerLogic.Reset();
	ElementIDToActorIDForTriggerLogic.Reset();
	ActorTransformHandleMapForTriggerLogic.Reset();
}



int64 UWorldManager::RegisterGridLogicDetector(bool IsMovable, int32 TriggerLogicType, int64 UID, float PX, float PY, float PZ, float Radius, const FString& DetectCallbackName)
{
	if (!SpaceDivision) {
		return -1;
	}

	int64 ElementID = SpaceDivision->RegisterGridLogicDetector(TriggerLogicType, UID, PX, PY, PZ, Radius, DetectCallbackName);

	if (IsMovable) {
		auto * DetectScriptEntity = UKGUEActorManager::GetLuaEntity(this, UID);
		AActor* BindedActor = DetectScriptEntity->GetLuaEntityBase()->GetActor();

		if (BindedActor){

			if (BindedActor->GetRootComponent())
			{
				KGActorID ActorID = DetectScriptEntity->GetLuaEntityBase()->GetActorID();
				if (!ActorTransformHandleMapForTriggerLogic.Contains(ActorID)) {

					ActorTransformBindMapForTriggerLogic.Add(ActorID, {});
					auto DeleHandle = BindedActor->GetRootComponent()->TransformUpdated.AddUObject(this, &UWorldManager::OnElement_TransformChanged);
					ActorTransformHandleMapForTriggerLogic.Add(ActorID, DeleHandle);

				}
				ActorTransformBindMapForTriggerLogic[ActorID].Add(ElementID);
				ElementIDToActorIDForTriggerLogic.Add(ElementID, ActorID);

			}
		}
		else {
			UE_LOG(LogTemp, Error, TEXT("[UWorldManager::RegisterGridLogicDetector] Movable Actor Need To Register After Actor Binded, LogicType:%d, UID:%lld"), TriggerLogicType, UID);
		}
		
	}
	return ElementID;

}

void UWorldManager::UpdateGridLogicDetectorRadius(int64 ElementID, float Radius) {
	if (!SpaceDivision) {
		return;
	}
	SpaceDivision->UpdateGridLogicDetectorRadius(ElementID, Radius);
}

void UWorldManager::UnregisterGridLogicDetector(int64 ElementID, bool NeedHandleLeaveCB) {
	if (!SpaceDivision) {
		return ;
	}

	if (KGActorID* ActorID = ElementIDToActorIDForTriggerLogic.Find(ElementID)) {
		if (auto* ElementIDSet = ActorTransformBindMapForTriggerLogic.Find(*ActorID)) {
			ElementIDSet->Remove(ElementID);

			if (ElementIDSet->Num() == 0) {
				if (auto* BindActor = KGUtils::GetActorByID(*ActorID)) {
					if (ActorTransformHandleMapForTriggerLogic.Contains(*ActorID)) {
						BindActor->GetRootComponent()->TransformUpdated.Remove(ActorTransformHandleMapForTriggerLogic[*ActorID]);
						ActorTransformHandleMapForTriggerLogic.Remove(*ActorID);
					}
				}
				ActorTransformBindMapForTriggerLogic.Remove(*ActorID);

			}
		}
		ElementIDToActorIDForTriggerLogic.Remove(ElementID);
	}
	
	SpaceDivision->UnregisterGridLogicDetector(ElementID, NeedHandleLeaveCB);

}

int64 UWorldManager::RegisterGridLogicTrigger(bool IsMovable, int32 TriggerLogicType, int64 UID, float PX, float PY, float PZ, float Radius, const FString& DetectCallbackName) {
	if (!SpaceDivision) {
		return -1;
	}

	 int64 ElementID = SpaceDivision->RegisterGridLogicTrigger(TriggerLogicType, UID, PX, PY, PZ, Radius, DetectCallbackName);

	 if (IsMovable && UID != KG_INVALID_ENTITY_ID) {
		 auto* DetectScriptEntity = UKGUEActorManager::GetLuaEntity(this, UID);
		 AActor* BindedActor = DetectScriptEntity->GetLuaEntityBase()->GetActor();

		 if (BindedActor) {
			
			 if (BindedActor->GetRootComponent())
			 {
				 KGActorID ActorID = DetectScriptEntity->GetLuaEntityBase()->GetActorID();
				 if (!ActorTransformHandleMapForTriggerLogic.Contains(ActorID)) {
				
					 ActorTransformBindMapForTriggerLogic.Add(ActorID, {});
					 auto DeleHandle = BindedActor->GetRootComponent()->TransformUpdated.AddUObject(this, &UWorldManager::OnElement_TransformChanged);
					 ActorTransformHandleMapForTriggerLogic.Add(ActorID, DeleHandle);

				}
				 ActorTransformBindMapForTriggerLogic[ActorID].Add(ElementID);
				 ElementIDToActorIDForTriggerLogic.Add(ElementID, ActorID);

			 }
		 }
		 else {
			 UE_LOG(LogTemp, Error, TEXT("[UWorldManager::RegisterGridLogicDetector] Movable Actor Need To Register After Actor Binded, LogicType:%d, UID:%lld"), TriggerLogicType, UID);
		 }

	 }

	 return ElementID;
}


void UWorldManager::UpdateGridLogicTriggerRadius(int64 ElementID, float Radius) {
	if (!SpaceDivision) {
		return;
	}
	SpaceDivision->UpdateGridLogicTriggerRadius(ElementID, Radius);
}


void UWorldManager::UnregisterGridLogicTrigger(int64 ElementID, bool NeedHandleLeaveCB) {
	if (!SpaceDivision) {
		return;
	}
	
	if (KGActorID *ActorID = ElementIDToActorIDForTriggerLogic.Find(ElementID)) {
		if (auto* ElementIDSet = ActorTransformBindMapForTriggerLogic.Find(*ActorID)) {
			ElementIDSet->Remove(ElementID);

			if (ElementIDSet->Num() == 0) {
				
				if (auto* BindActor = KGUtils::GetActorByID(*ActorID)) {
					if (ActorTransformHandleMapForTriggerLogic.Contains(*ActorID)) {
						BindActor->GetRootComponent()->TransformUpdated.Remove(ActorTransformHandleMapForTriggerLogic[*ActorID]);
						ActorTransformHandleMapForTriggerLogic.Remove(*ActorID);
					}
				}

				ActorTransformBindMapForTriggerLogic.Remove(*ActorID);
			}
			ElementIDToActorIDForTriggerLogic.Remove(ElementID);
		}
	}
	SpaceDivision->UnregisterGridLogicTrigger(ElementID, NeedHandleLeaveCB);

}

void UWorldManager::SetTriggerElementExitTolerantDistance(int64 ElementID, int DistanceCM) {
	if (!SpaceDivision) {
		return;
	}
	
	SpaceDivision->SetTriggerElementExitTolerantDistance(ElementID, DistanceCM);

}

int64 UWorldManager::ConsumeSceneElementID() {
	if (!SpaceDivision) {
		return -1;
	}

	return SpaceDivision->ConsumeSceneElementID();
}

void UWorldManager::InitSpaceDivision()
{

	SpaceDivision = NewObject<URubiksCubeSpaceDivision>(this, URubiksCubeSpaceDivision::StaticClass());
	SpaceDivision->Init(this);

	InitSpaceDivisionCallBack();
}

void UWorldManager::InitSpaceDivisionCallBack()
{
	if (SpaceDivision)
	{
		SpaceDivision->OnAOIStateChangedCB.BindUObject(this, &UWorldManager::CallFunc_OnAOIStateChanged);
	}
}

void UWorldManager::CallFunc_OnAOIStateChanged(const int64& UID, const bool& bEnterSpace)
{
	CallLuaFunction("OnAOIStateChanged", UID, bEnterSpace);
}

void UWorldManager::OnElement_TransformChanged(USceneComponent* Component, EUpdateTransformFlags UpdateTransformFlags, ETeleportType Teleport)
{
	AActor* Actor = Component->GetOwner();
	if (!Actor) {
		return;
	}

	if (SpaceDivision) {
		if (auto * ElementIDSet = ActorTransformBindMapForTriggerLogic.Find(KGUtils::GetIDByObject(Actor)))
		{
			FVector NewLocation = Actor->GetActorLocation();
			for (auto& ElementID : *ElementIDSet) {
				SpaceDivision->MakeElementMovementDirty(ElementID, NewLocation);
			}
		}
	}
}

AActor* UWorldManager::GetActorFromSoftPath(const FString& SoftPath)
{
	if(!GIPtr.IsValid())
		return nullptr;
		 
	FSoftObjectPath SoftObjectPath(SoftPath);
	if (UWorld* World = GEngine->GetWorldFromContextObject(GIPtr.Get(), EGetWorldErrorMode::LogAndReturnNull))
	{
		//begin add by tangzhangpeng@kuaishou.com
		//obj loaded by SoftObjectPath in PIE may be redirected to a copied object named with prefix "UEDPIE_PIEID". 
		//pie state will change in editor tick, see UEditorEngine::Tick
		// when we get actor from SoftObjectPath, but the pie state is not the same with last time ,then we will get a diffirent object
#if WITH_EDITOR
		FWorldContext* WorldContext = GEngine->GetWorldContextFromWorld(World);
		if (WorldContext)
		{
			FTemporaryPlayInEditorIDOverride PIEGuard(WorldContext->PIEInstance);
#endif
		//end add by tangzhangpeng@kuaishou.com
			if (World->IsPartitionedWorld())
			{
				UObject* ResolvedObject = nullptr;
				World->ResolveSubobject(*SoftObjectPath.GetSubPathString(), ResolvedObject, /*bLoadIfExists*/false);
				if (ResolvedObject)
				{
					if (AActor* _Actor = Cast<AActor>(ResolvedObject))
					{
						return _Actor;
					}
				}
			}
			else
			{
				if (UObject* ResolvedObject = SoftObjectPath.TryLoad())
				{
					if (AActor* _Actor = Cast<AActor>(ResolvedObject))
					{
						return _Actor;
					}
				}
			}
#if WITH_EDITOR
		}
#endif
	}

	return nullptr;
}

#pragma endregion SpaceDivision

void UWorldManager::SetPreviewWorld(KGObjectID WorldID)
{
	PreviewWorld = KGUtils::GetObjectByID<UWorld>(WorldID);
}

float UWorldManager::GetAltitudeByLocation(double X, double Y, double Z) const
{
	if (UKGLandscapeHeightDataSubsystem* LandscapeHeightDataSubsystem = GetWorld()->GetSubsystem<UKGLandscapeHeightDataSubsystem>())
	{
		return LandscapeHeightDataSubsystem->GetLandscapeHeight(FVector(X, Y, Z));
	}
	return 0.f;
}

UWorld* UWorldManager::GetRecentWorld()
{
	if (PreviewWorld.IsValid())
	{
		return PreviewWorld.Get();
	}

	if (GIPtr.IsValid() && GIPtr->GetWorld())
	{
		return GIPtr->GetWorld();
	}

	return nullptr;
}

#pragma region KGEngineCore
bool UWorldManager::SetKGEngineCorePlayerActor(int64 entityUid)
{
	auto RecentWorld = GetRecentWorld();
	if (!IsValid(RecentWorld)) {
		return false;
	}
	auto Entity = UKGUEActorManager::GetLuaEntity(RecentWorld, entityUid);
	if (!Entity)
	{
		UE_LOG(LogTemp, Error, TEXT("WorldManager::SetKGEngineCorePlayerActor get Entity failed"));
		return false;
	}
	auto Character = Cast<ABaseCharacter>(Entity->GetLuaEntityBase()->GetActor());
	if (!Character)
	{
		UE_LOG(LogTemp, Error, TEXT("WorldManager::SetKGEngineCorePlayerActor cast to ABaseCharacter failed"));
		return false;
	}
	UKGEngineCoreBPLibrary::SetPlayerActor(Character);

	return true;
}

void UWorldManager::CleanupKGEngineCorePlayerActor()
{
	UKGEngineCoreBPLibrary::SetPlayerActor(nullptr);
}
#pragma endregion KGEngineCore

#pragma region WaterSurfaceWave
#define ENSURE_DYNAMIC_WATER_SUBSYSTEM 	\
	auto recentWorld = GetRecentWorld();\
	if (!IsValid(recentWorld)){\
			return;}\
	auto dynamicWaterSubsystem = recentWorld->GetSubsystem<UWaterDynamicLocalWaveSubsystem>();\
	if (!dynamicWaterSubsystem) {\
		return;\
	}\

// 水体涟漪效果
void UWorldManager::EnableDynamicWaterWave(bool enable)
{
	bEnableDynamicWaterWave = enable;
}

bool UWorldManager::IsEnabledDynamicWaterWave()
{
	return bEnableDynamicWaterWave;
}

bool UWorldManager::IsCVarEnabledDynamicWaterWave()
{
	static IConsoleVariable* CVar = IConsoleManager::Get().FindConsoleVariable(TEXT("r.Water.DynamicLocalWave.Enable"));
	return CVar->GetInt() == 1;
}

int UWorldManager::GetGlobalWaterWaveRequestId()
{
	static int RequestID = 1;
	RequestID++;
	if (RequestID >= 0x7fffffff)
	{
		RequestID = 1;
	}
	return RequestID;
}

void UWorldManager::SetupDynamicWaterWaveMotorTextures(const TArray<FString>& TexturePaths)
{
	WaterWaveMotorTextures = TexturePaths;
	UWaterDynamicLocalWaveLibrary::SetupMotorTypeTextures(TexturePaths);
}

bool UWorldManager::SetPivotActorForDynamicWaterWave(int64 entityUid) {
	auto RecentWorld = GetRecentWorld();
	if (!IsValid(RecentWorld)) {
		return false;
	}
	auto dynamicWaterSubsystem = RecentWorld->GetSubsystem<UWaterDynamicLocalWaveSubsystem>();
	if (!dynamicWaterSubsystem) {
		UE_LOG(LogTemp, Error, TEXT("UWorldManager::SetPivotActorForDynamicWaterWave UWaterDynamicLocalWaveSubsystem is nullptr"));
		return false;
	}
	auto Entity = UKGUEActorManager::GetLuaEntity(RecentWorld, entityUid);
	if (!Entity)
	{
		UE_LOG(LogTemp, Error, TEXT("WorldManager::SetPivotActorForDynamicWaterWave get Entity failed"));
		return false;
	}
	auto Character = Cast<ABaseCharacter>(Entity->GetLuaEntityBase()->GetActor());
	if (!Character)
	{
		UE_LOG(LogTemp, Error, TEXT("WorldManager::SetPivotActorForDynamicWaterWave cast to ABaseCharacter failed"));
		return false;
	}
	dynamicWaterSubsystem->SetPivotActor(Character);
	return true;
}

void UWorldManager::CleanupPivotActorForDynamicWaterWave() {
	ENSURE_DYNAMIC_WATER_SUBSYSTEM
	dynamicWaterSubsystem->SetPivotActor(nullptr);
}

void UWorldManager::AddMotorForDynamicWaterWave(int32 requestId, int32 motorTextureId, float PositionX, float PositionY, float RotationYaw,
	float ScaleX, float ScaleY, float MaxHeight, float FoamScale, float TimeGap,
	float moveDirX, float moveDirY, float moveSpeed, int32 WaveTimes)
{
	if (!bEnableDynamicWaterWave)
	{
		return;
	}
	// TimeGap有值，需要注册Tick，保存参数调用
	if (TimeGap > 0)
	{
		RegisterWaterWaveTick(requestId, motorTextureId, PositionX, PositionY, RotationYaw, ScaleX, ScaleY, MaxHeight, FoamScale, TimeGap, moveDirX, moveDirY, moveSpeed, WaveTimes);
	}
	ExecuteMotorForDynamicWaterWave(motorTextureId, PositionX, PositionY, RotationYaw, ScaleX, ScaleY, MaxHeight, FoamScale);
}

void UWorldManager::AddMotorForDynamicWaterWaveForSkill(KGEntityID UID, int32 RequestId, int32 MotorTextureId, int MoveDirAngleOffset, float PositionOffsetX, float PositionOffsetY
	, float ScaleX, float ScaleY, float MaxHeight, float FoamScale, float TimeGap, float MoveSpeed, int32 WaveTimes)
{
	if (!bEnableDynamicWaterWave)
	{
		return;
	}
	
	const auto RecentWorld = GetRecentWorld();
	if (!IsValid(RecentWorld)) {
		return;
	}

	auto Entity = UKGUEActorManager::GetLuaEntity(RecentWorld, UID);
	if (!Entity)
	{
		UE_LOG(LogTemp, Error, TEXT("WorldManager::AddMotorForDynamicWaterWaveForSkill get Entity failed"));
		return;
	}

	// 1. 获取实体旋转和位置
	const FRotator EntityRotation = Entity->GetRotation();
	const float EntityYaw = EntityRotation.Yaw;
	const FRotator EntityYawRotator(0.f, EntityYaw, 0.f);
	FVector EntityPos = Entity->GetLocation();
	
	// 处理位置偏移
	if (PositionOffsetX != 0.f || PositionOffsetY != 0.f)
	{
		const FVector PositionOffset(PositionOffsetX, PositionOffsetY, 0.f);
		const FVector RotatedPositionOffset = EntityYawRotator.RotateVector(PositionOffset);
		EntityPos += RotatedPositionOffset;
	}

	//处理角度偏移
	float AngleRad = FMath::DegreesToRadians(MoveDirAngleOffset); // 角度转弧度
	float MoveDirX = FMath::Cos(AngleRad);
	float MoveDirY = FMath::Sin(AngleRad);
	const FVector MoveDirection(MoveDirX, MoveDirY, 0.f);
	const FVector RotatedMoveDirection = EntityYawRotator.RotateVector(MoveDirection);
	float MotorTextureYaw = FMath::Atan2(-RotatedMoveDirection.Y, RotatedMoveDirection.X);

	//UE_LOG(LogTemp, Log, TEXT("WaterWave : EntityYaw:%f MotorTextureYaw:%f"), EntityYaw, MotorTextureYaw);
	AddMotorForDynamicWaterWave(RequestId,MotorTextureId,EntityPos.X,EntityPos.Y,MotorTextureYaw,ScaleX,ScaleY,MaxHeight,FoamScale,TimeGap,RotatedMoveDirection.X,RotatedMoveDirection.Y,MoveSpeed, WaveTimes);
}

void UWorldManager::ExecuteMotorForDynamicWaterWave(int32 motorTextureId, float PositionX, float PositionY, float RotationYaw, float ScaleX, float ScaleY, float MaxHeight, float FoamScale)
{
	if (!bEnableDynamicWaterWave)
	{
		return;
	}
	ENSURE_DYNAMIC_WATER_SUBSYSTEM
	if(motorTextureId < WaterWaveMotorTextures.Num())
	{
		dynamicWaterSubsystem->AddMotor(motorTextureId, PositionX, PositionY, RotationYaw, ScaleX, ScaleY, MaxHeight, FoamScale);
	}
}

void UWorldManager::BindRoleMovementDynamicWaterWave(int64 ActorID, bool bBind)
{
	auto* UOM = UKGObjectActorManager::GetInstance(this);
	if (!UOM) {
		return;
	}
	
	ABaseCharacter* Char = Cast<ABaseCharacter>(UOM->GetObjectByID(ActorID));
	if (!Char) {
		return;
	}

	auto* MoveCom = Cast<URoleMovementComponent>(Char->GetCharacterMovement());
	if (MoveCom)
	{
		if (bBind)
		{
			MoveCom->OnAddMotorForDynamicWaterWave.BindUObject(this, &UWorldManager::AddMotorForDynamicWaterWave);
		}
		else
		{
			MoveCom->OnAddMotorForDynamicWaterWave.Unbind();
		}
	}
}

void UWorldManager::RegisterWaterWaveTick(int32 requestId, int32 motorTextureId, float PositionX, float PositionY, float RotationYaw, float ScaleX, float ScaleY, float MaxHeight, float FoamScale, float TimeGap,
	float moveDirX, float moveDirY, float moveSpeed, int32 WaveTimes)
{
	if (!bEnableDynamicWaterWave)
	{
		return;
	}
	WaterWaveParametersTickCache.Add(requestId,FWaterWaveParameters(motorTextureId, PositionX, PositionY, RotationYaw, ScaleX, ScaleY, MaxHeight, FoamScale, TimeGap,
		moveDirX, moveDirY, moveSpeed, WaveTimes));
}

void UWorldManager::UnRegisterWaterWaveTick(int32 requestId)
{
	WaterWaveParametersTickCache.Remove(requestId);
}

#undef ENSURE_DYNAMIC_WATER_SUBSYSTEM

#pragma endregion  WaterSurfaceWave

#pragma region LocalWindField
#define ENSURE_LOCAL_WIND_SUBSYSTEM  \
	auto recentWorld = GetRecentWorld();\
	if (!IsValid(recentWorld)){\
		return;}\
	auto localWindSubsystem = recentWorld->GetSubsystem<ULocalWindSubsystem>();\
	if (!localWindSubsystem) {\
		return;\
	}\

void UWorldManager::EnableLocalWindField(bool enable) {
	bEnableLocalWindField = enable;
}

bool UWorldManager::IsEnableLocalWindField() {
	return bEnableLocalWindField;
}

bool UWorldManager::IsCVarEnabledLocalWindField()
{
	static IConsoleVariable* CVar = IConsoleManager::Get().FindConsoleVariable(TEXT("r.LocalWind.Enable"));
	return CVar->GetInt() == 1;
}

bool UWorldManager::SetPivotActorForLocalWindField(int64 entityUid) {
	auto RecentWorld = GetRecentWorld();
	if (!IsValid(RecentWorld)) {
		return false;
	}
	auto localWindSubsystem = RecentWorld->GetSubsystem<ULocalWindSubsystem>();
	if (!localWindSubsystem) {
		UE_LOG(LogTemp, Error, TEXT("UWorldManager::SetPivotActorForLocalWindField ULocalWindSubsystem is nullptr"));
		return false;
	}
	auto Entity = UKGUEActorManager::GetLuaEntity(RecentWorld, entityUid);
	if (!Entity)
	{
		UE_LOG(LogTemp, Error, TEXT("WorldManager::SetPivotActorForLocalWindField get Entity failed"));
		return false;
	}
	auto Character = Cast<ABaseCharacter>(Entity->GetLuaEntityBase()->GetActor());
	if (!Character)
	{
		UE_LOG(LogTemp, Error, TEXT("WorldManager::SetPivotActorForLocalWindField cast to ABaseCharacter failed"));
		return false;
	}
	localWindSubsystem->SetPivotActor(Character);
	return true;
}

void UWorldManager::CleanupPivotActorForLocalWindField() {
	ENSURE_LOCAL_WIND_SUBSYSTEM
	localWindSubsystem->SetPivotActor(nullptr);
}

void UWorldManager::AddMotorForLocalWindField(int32 WindFieldType, float PositionX, float PositionY, float RotationYaw, float ScaleX, float ScaleY, float strength, float fanCenterAngle, float WindBlendTime, int32 WindBlendFreq)
{
	if (!bEnableLocalWindField)
	{
		return;
	}
	float StrengthAlpha = 1;
	if (WindBlendTime > 0 && WindBlendFreq > 0)
	{
		StrengthAlpha = 1 / WindBlendFreq;
		RegisterWindMotorTick(WindFieldType, PositionX, PositionY, RotationYaw, ScaleX, ScaleY, strength, fanCenterAngle, WindBlendTime, WindBlendFreq);
	}
	
	ENSURE_LOCAL_WIND_SUBSYSTEM
	localWindSubsystem->AddMotor((ELocalWindMotorType)WindFieldType, PositionX, PositionY, RotationYaw, ScaleX, ScaleY, StrengthAlpha * strength, fanCenterAngle);
}

void UWorldManager::RegisterWindMotorTick(int32 WindFieldType, float PositionX, float PositionY, float RotationYaw, float ScaleX, float ScaleY, float strength, float fanCenterAngle, float WindBlendTime, int32 WindBlendFreq)
{
	if (!bEnableLocalWindField)
	{
		return;
	}
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	float CurrentTime = World->GetTimeSeconds();
	WindMotorParametersTickCache.Add(FWindMotorParameters(WindFieldType, PositionX, PositionY, RotationYaw, ScaleX, ScaleY, strength, fanCenterAngle, WindBlendTime, WindBlendFreq, CurrentTime));
}

void UWorldManager::ProcessWindMotorEffect(float DeltaTime)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("ProcessWindMotorEffect")
	
	if (!bEnableLocalWindField)
    {
    	return;
    }
    	
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	ENSURE_LOCAL_WIND_SUBSYSTEM

	static TArray<int32> RemoveRequestIdxArray;
	RemoveRequestIdxArray.Reset();

	float CurrentTime = World->GetTimeSeconds();

	for (int32 Idx = 0; Idx < WindMotorParametersTickCache.Num(); ++Idx)
	{
		auto& Params = WindMotorParametersTickCache[Idx];
		float Interval = Params.WindBlendTime / Params.WindBlendFreq;
		if (CurrentTime < Params.LastProcessTime + Interval)
		{
			continue;
		}
		
		Params.LastProcessTime += Interval;
		++Params.WindMotorCount;
		float StrengthAlpha = Params.WindMotorCount / Params.WindBlendFreq;
		
		localWindSubsystem->AddMotor(
			(ELocalWindMotorType)Params.WindFieldType,
			Params.PositionX, Params.PositionY, Params.RotationYaw,
			Params.ScaleX, Params.ScaleY,
			StrengthAlpha * Params.strength, Params.fanCenterAngle);

		// UE_LOG(LogTemp, Log, TEXT("[ProcessWindMotorEffect] Count=%d"), Params.WindMotorCount);
		
		if (Params.WindMotorCount >= Params.WindBlendFreq)
		{
			RemoveRequestIdxArray.Add(Idx);
		}
	}

	for (int32 Idx = RemoveRequestIdxArray.Num() - 1; Idx >= 0; --Idx)
	{
		WindMotorParametersTickCache.RemoveAt(RemoveRequestIdxArray[Idx]);\
	}
}

void UWorldManager::BindRoleMovementWindField(int64 ActorID, bool bBind)
{
	auto* UOM = UKGObjectActorManager::GetInstance(this);
	if (!UOM) {
		return;
	}
	
	ABaseCharacter* Char = Cast<ABaseCharacter>(UOM->GetObjectByID(ActorID));
	if (!Char) {
		return;
	}

	auto* MoveCom = Cast<URoleMovementComponent>(Char->GetCharacterMovement());
	if (MoveCom)
	{
		if (bBind)
		{
			MoveCom->OnAddMotorForLocalWindField.BindUObject(this, &UWorldManager::AddMotorForLocalWindField);
		}
		else
		{
			MoveCom->OnAddMotorForLocalWindField.Unbind();
		}
	}
}

#undef ENSURE_LOCAL_WIND_SUBSYSTEM

#pragma endregion  LocalWindField

#pragma region DeformableLandscape
#define ENSURE_DEFORMABLE_LANDSCAPE_SUBSYSTEM(...) 	\
auto recentWorld = GetRecentWorld();\
if (!IsValid(recentWorld)){\
return __VA_ARGS__;}\
auto deformableLandscapeSystem = recentWorld->GetSubsystem<UDeformableLandscapeSystem>();\
if (!deformableLandscapeSystem) {\
return __VA_ARGS__;\
}\


//可交互地形(雪地，沙漠等)
void UWorldManager::EnableDeformableLandscapeSystem(bool Enable)
{
	ENSURE_DEFORMABLE_LANDSCAPE_SUBSYSTEM()
	deformableLandscapeSystem->Enable(Enable);
}

bool UWorldManager::IsUsingDeformableEffect()
{
	ENSURE_DEFORMABLE_LANDSCAPE_SUBSYSTEM(false)

	return deformableLandscapeSystem->IsEnabled();
}

bool UWorldManager::IsEnabledDeformableLandscapeSystem()
{
	static IConsoleVariable* CVar = IConsoleManager::Get().FindConsoleVariable(TEXT("r.DeformableLandscapeSystem.EnableFeature"));
	return CVar->GetInt() == 1;
}

void UWorldManager::SetPivotActorForDeformableLandscape(int64 entityUid)
{
	ENSURE_DEFORMABLE_LANDSCAPE_SUBSYSTEM()
	
	auto Entity = UKGUEActorManager::GetLuaEntity(recentWorld, entityUid);
	if (!Entity)
	{
		UE_LOG(LogTemp, Error, TEXT("WorldManager get Entity failed"));
		return;
	}
	
	AActor* OwnerActor = Entity->GetLuaEntityBase()->GetActor();
	if (OwnerActor == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("WorldManager can not get binded actor by EntityID[%lld]"), entityUid);
		return;
	}
	
	deformableLandscapeSystem->SetPivotActor(OwnerActor);
}

void UWorldManager::CleanupPivotActorForDeformableLandscape()
{
	ENSURE_DEFORMABLE_LANDSCAPE_SUBSYSTEM()
	deformableLandscapeSystem->SetPivotActor(nullptr);
}

void UWorldManager::EnableDeformableLandscapeCaptureMode(int64 entityUid, bool enable)
{
	ENSURE_DEFORMABLE_LANDSCAPE_SUBSYSTEM()
	
	auto Entity = UKGUEActorManager::GetLuaEntity(recentWorld, entityUid);
	if (!Entity)
	{
		UE_LOG(LogTemp, Error, TEXT("WorldManager get Entity failed"));
		return;
	}
	
	AActor* OwnerActor = Entity->GetLuaEntityBase()->GetActor();
	if (OwnerActor == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("WorldManager can not get binded actor by EntityID[%lld]"), entityUid);
		return;
	}

	if (enable)
	{
		deformableLandscapeSystem->AddCaptureActor(OwnerActor);
	}
	else
	{
		deformableLandscapeSystem->RemoveCaptureActor(OwnerActor);
	}
}

void UWorldManager::EnableDeformableLandscapeSimpleMode(int64 entityUid, const FName& SocketName, bool Enable)
{
	ENSURE_DEFORMABLE_LANDSCAPE_SUBSYSTEM()
	
	auto Entity = UKGUEActorManager::GetLuaEntity(recentWorld, entityUid);
	if (!Entity)
	{
		UE_LOG(LogTemp, Error, TEXT("WorldManager get Entity failed"));
		return;
	}
	
	AActor* OwnerActor = Entity->GetLuaEntityBase()->GetActor();
	if (OwnerActor == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("WorldManager can not get binded actor by EntityID[%lld]"), entityUid);
		return;
	}
	
	USkeletalMeshComponent* SkMeshComponent = OwnerActor->GetComponentByClass<USkeletalMeshComponent>();
	if(!SkMeshComponent || !SkMeshComponent->GetSkeletalMeshAsset() || SkMeshComponent->GetSkeletalMeshAsset()->GetRefSkeleton().FindBoneIndex(SocketName) == INDEX_NONE)
	{
		return;
	}

	UDeformableLandscapeTrailTraceComponent* DeformableLandscapeTrailTraceComponent = OwnerActor->FindComponentByTag<UDeformableLandscapeTrailTraceComponent>(SocketName);
	if (DeformableLandscapeTrailTraceComponent == nullptr && Enable)
	{
		DeformableLandscapeTrailTraceComponent = NewObject<UDeformableLandscapeTrailTraceComponent>(OwnerActor, UDeformableLandscapeTrailTraceComponent::StaticClass(), NAME_None, RF_Transient);
		if (!DeformableLandscapeTrailTraceComponent) {
			return;
		}
		DeformableLandscapeTrailTraceComponent->SetupAttachment(SkMeshComponent,SocketName);
		DeformableLandscapeTrailTraceComponent->SetMobility(EComponentMobility::Movable);
		DeformableLandscapeTrailTraceComponent->ComponentTags.AddUnique(SocketName);
		DeformableLandscapeTrailTraceComponent->TraceMode = EDeformableLandscapeTrailTraceMode::TTM_Simple;
		DeformableLandscapeTrailTraceComponent->RegisterComponent();
	}

	if (DeformableLandscapeTrailTraceComponent && DeformableLandscapeTrailTraceComponent->IsRegistered() && !Enable)
	{
		DeformableLandscapeTrailTraceComponent->DetachFromComponent(
			FDetachmentTransformRules::KeepRelativeTransform
		);
		DeformableLandscapeTrailTraceComponent->UnregisterComponent();
	}
}

#undef ENSURE_DEFORMABLE_LANDSCAPE_SUBSYSTEM
#pragma endregion  DeformableLandscape

#pragma region Terrain


FString UWorldManager::QueryTerrainName(const FVector& QueryLocation, double QueryDepth, bool bPrintDebugInfo)
{
	static TArray<AActor*> IgnoreActors;
	FVector EndLocation = QueryLocation - FVector(0, 0, QueryDepth);
	
	FHitResult HitResult;

	EDrawDebugTrace::Type DrawDebugTraceType = bPrintDebugInfo ? EDrawDebugTrace::ForDuration : EDrawDebugTrace::None;
	UKismetSystemLibrary::LineTraceSingleForObjects(this, QueryLocation, EndLocation, QueryTerrainObjectTypes, false, IgnoreActors, DrawDebugTraceType, HitResult, true, FColor::Green, FColor::Red, 3.0f);	
	
	AActor* HitActor = HitResult.GetActor();
	if (UKGPhysicalMaterialMaskComponent* MaterialMaskComponent = HitActor ? HitActor->GetComponentByClass<UKGPhysicalMaterialMaskComponent>() : nullptr)
	{
		uint8 MaterialIndex = MaterialMaskComponent->GetPhysicalMaterialIndex(HitResult.Location);

		if (bPrintDebugInfo)
		{
			UKismetSystemLibrary::PrintString(GetWorld(), FString::Format(TEXT("MaterialIndex = {0}"), {MaterialIndex}), true, true, FLinearColor::Green);
		}
		
		return GetTerrainNameByMaterialIndex(MaterialIndex);
	}
	
	TWeakObjectPtr<UPhysicalMaterial> PhysMaterial = HitResult.PhysMaterial;
	if (PhysMaterial.IsValid())
	{
		const FString& PhysMaterialName = PhysMaterial.Get()->GetName();

		if (bPrintDebugInfo)
		{
			UKismetSystemLibrary::PrintString(GetWorld(), FString::Format(TEXT("PhysMaterialName = {0}"), {PhysMaterialName}), true, true, FLinearColor::Green);
		}
		
		return GetTerrainNameByMaterialName(PhysMaterialName);
	}	

	return FString();
}

void UWorldManager::SetQueryTerrainObjectTypes(const TArray<int32>& InQueryTerrainObjectTypes)
{
	QueryTerrainObjectTypes.Empty();
	for (auto& InQueryTerrainObjectType : InQueryTerrainObjectTypes)
	{
		QueryTerrainObjectTypes.Add(static_cast<EObjectTypeQuery>(InQueryTerrainObjectType));	
	}
}

FString UWorldManager::TerrainNameInWater = TEXT("Water");

void UWorldManager::InnerInitTerrainData(const TMap<FString, FString>& InTerrain2Suffix, const TMap<FString, FString>& InTerrain2NiagaraPath, float InLightWaterDepthRegion, float InDeepWaterDepthRegion, const FString& InLightWaterTerrainName, const FString& InDeepWaterTerrainName)
{
	Terrain2Suffix = InTerrain2Suffix;
	Terrain2NiagaraPath = InTerrain2NiagaraPath;
	LightWaterDepthRegion = InLightWaterDepthRegion;
	DeepWaterDepthRegion = InDeepWaterDepthRegion;
	LightWaterTerrainName = InLightWaterTerrainName;
	DeepWaterTerrainName = InDeepWaterTerrainName;
}

FString UWorldManager::GetTerrainNameByMaterialName(const FString& MaterialName)
{
	if (Terrain2Suffix.Contains(MaterialName))
	{
		return Terrain2Suffix[MaterialName];
	}

	return TEXT("");
}

FString UWorldManager::GetNiagaraPathByTerrainName(const FString& InTerrainName)
{
	if (Terrain2NiagaraPath.Contains(InTerrainName))
	{
		return Terrain2NiagaraPath[InTerrainName];
	}
	
	return TEXT("");
}

void UWorldManager::InnerUpdateTerrainData(const FString& InTerrainName, const FString& InSuffix)
{
	Terrain2Suffix.Emplace(InTerrainName, InSuffix);
}

void UWorldManager::InnerInitMaterialMaskData(const TMap<uint8, FString>& InMaterialIndex2TerrainName)
{
	MaterialIndex2TerrainName = InMaterialIndex2TerrainName;
}

FString UWorldManager::GetTerrainNameByMaterialIndex(uint8 InMaterialMask)
{
	if (MaterialIndex2TerrainName.Contains(InMaterialMask))
	{
		return MaterialIndex2TerrainName[InMaterialMask];
	}
	
	return FString();
}

void UWorldManager::InnerUpdateMaterialMaskData(uint8 InMaterialMask, const FString& InTerrainName)
{
	MaterialIndex2TerrainName.Emplace(InMaterialMask, InTerrainName);
}

FString UWorldManager::GetTerrainNameByWaterDepth(float CurrentWaterDepth) const
{
	if (!IsInLegalWaterDepth(CurrentWaterDepth))
	{
		return TEXT("");
	}

	if (CurrentWaterDepth < LightWaterDepthRegion)
	{
		return LightWaterTerrainName;
	}
	else
	{
		return DeepWaterTerrainName;
	}
}

#pragma endregion Terrain

#pragma region TODLight

void UWorldManager::SetStreetlightControlBySequence(bool bInControl)
{
	bStreetlightControlBySequence = bInControl;
}

void UWorldManager::SetStreetlightTODParams(float InStreetlightTODDuration)
{
	StreetlightTODDuration = InStreetlightTODDuration;
}

void UWorldManager::RegisterTODStreetlightActor(AActor* Actor, const float TurnOnDayOfTime, const float TurnOffDayOfTime)
{
	TWeakObjectPtr<AActor> WeakActor = Actor;
	if (!WeakActor.IsValid())
	{
		UE_LOG(LogTemp, Error, TEXT("WorldManager::RegisterTODStreetlightActor can not get actor [%lld]"), WeakActor.KGGetObjectID());
		return;
	}
	
	if(UStreetlightTODControlComponent* Component = WeakActor->GetComponentByClass<UStreetlightTODControlComponent>())
	{
		FTODStreetLightPoolValue& PoolValue = TODStreetLightPool.FindOrAdd(FTODStreetLightPoolKey(TurnOnDayOfTime, TurnOffDayOfTime));
		PoolValue.AddStreetlightActor(WeakActor);
		if (bStreetlightControlBySequence)
		{
			Component->SetLightBeforeComponentTagControl();
		}
		else
		{
			Component->SetTODStateAtOnce(PoolValue.IsInDayTime(), false);
		}
	}
}


void UWorldManager::UnRegisterTODStreetlightActor(AActor* Actor, const float TurnOnDayOfTime, const float TurnOffDayOfTime)
{
	TWeakObjectPtr<AActor> WeakActor = Actor;
	if (!WeakActor.IsValid())
	{
		UE_LOG(LogTemp, Error, TEXT("WorldManager::UnRegisterTODStreetlightActor can not get actor [%lld]"), WeakActor.KGGetObjectID());
		return;
	}
	
	FTODStreetLightPoolKey PoolKey = FTODStreetLightPoolKey(TurnOnDayOfTime, TurnOffDayOfTime);
	if (FTODStreetLightPoolValue* PoolValue = TODStreetLightPool.Find(PoolKey))
	{
		const bool bIsPoolEmpty = PoolValue->RemoveStreetlightActor(WeakActor);
		if (bIsPoolEmpty)
		{
			TODStreetLightPool.Remove(PoolKey);
		}
	}
}

float UWorldManager::GetCurrentTimeOfDay() const
{
	if (UGeographyClimateSubsystem* GeographyClimateSystem = GetWorld()->GetSubsystem<UGeographyClimateSubsystem>())
	{
		const FGeographyInfo& CurrentGeographyInfo = GeographyClimateSystem->GetGeographyInfo();
		return CurrentGeographyInfo.Hours + CurrentGeographyInfo.Minutes / 60.0f + CurrentGeographyInfo.Seconds / 3600.0f;
	}
	return -1;
}

void UWorldManager::SetupStreetlightControlByComponentTag(const TArray<struct FStreetLightControlByComponentTagParams>& ControlParams, const float& StartTime, const float& EndTime)
{
	const float LightDuration = EndTime - StartTime;
	if (LightDuration <= 0.f)
	{
		UE_LOG(LogTemp, Error, TEXT("WorldManager::SetupStreetlightControlByComponentTag less zero duration [%f]"), LightDuration);
		return;
	}
	
	if (ControlParams.IsEmpty())
	{
		UE_LOG(LogTemp, Error, TEXT("WorldManager::SetupStreetlightControlByComponentTag get empty ControlParams"));
		return;
	}
	
	auto RecentWorld = GetRecentWorld();
	if (IsValid(RecentWorld))
	{
		for (auto& PoolElem: TODStreetLightPool)
		{
			auto& PoolValue = PoolElem.Value;
			PoolValue.UpdateControlParams(ControlParams, StartTime, EndTime, LightDuration);
			// sequence控制优先级高 直接打断
			PoolValue.UpdateTickType(FTODStreetLightPoolValue::EStreetlightTickType::ByComponentTag);
			
			for (TWeakObjectPtr<AActor> WeakActor: PoolValue.TODStreetlightActors)
			{
				if (!WeakActor.IsValid())
				{
					UE_LOG(LogTemp, Error, TEXT("WorldManager::SetupStreetlightControlByComponentTag can not get actor [%lld]"), WeakActor.KGGetObjectID());
					continue;
				}
				AActor* OwnerActor = WeakActor.Get();
				if(UStreetlightTODControlComponent* ControlComponent = OwnerActor->GetComponentByClass<UStreetlightTODControlComponent>())
				{
					ControlComponent->SetLightBeforeComponentTagControl();
				}
			}
		}
	}
}

void UWorldManager::UpdateStreetlightControlByComponentTag(const float& CurrentTime)
{
	auto RecentWorld = GetRecentWorld();
	if (IsValid(RecentWorld))
	{
		for (auto& PoolElem: TODStreetLightPool)
		{
			auto& PoolValue = PoolElem.Value;
			const float TimePercent = (CurrentTime - PoolValue.UpdateStartTime) / PoolValue.LightDuration;
			for (TWeakObjectPtr<AActor> WeakActor: PoolValue.TODStreetlightActors)
			{
				if (!WeakActor.IsValid())
				{
					UE_LOG(LogTemp, Error, TEXT("WorldManager::UpdateStreetlightControlByComponentTag can not get actor [%lld]"), WeakActor.KGGetObjectID());
					continue;
				}
				AActor* OwnerActor = WeakActor.Get();
				if(UStreetlightTODControlComponent* ControlComponent = OwnerActor->GetComponentByClass<UStreetlightTODControlComponent>())
				{
					ControlComponent->UpdateLightControlByComponentTag(PoolValue.ControlByTagParams, TimePercent);
				}
			}
		}
	}
}

void UWorldManager::EndStreetlightControlByComponentTag()
{
	auto RecentWorld = GetRecentWorld();
	if (IsValid(RecentWorld))
	{
		for (auto& PoolElem: TODStreetLightPool)
		{
			auto& PoolValue = PoolElem.Value;
			for (TWeakObjectPtr<AActor> WeakActor: PoolValue.TODStreetlightActors)
			{
				if (!WeakActor.IsValid())
				{
					UE_LOG(LogTemp, Error, TEXT("WorldManager::EndStreetlightControlByComponentTag can not get actor [%lld]"), WeakActor.KGGetObjectID());
					continue;
				}
				AActor* OwnerActor = WeakActor.Get();
				if(UStreetlightTODControlComponent* ControlComponent = OwnerActor->GetComponentByClass<UStreetlightTODControlComponent>())
				{
					// 恢复TOD状态
					ControlComponent->SetTODStateAtOnce(PoolValue.IsInDayTime(), false);
				}
			}
			PoolValue.UpdateTickType(FTODStreetLightPoolValue::EStreetlightTickType::None);
		}
	}
}

void UWorldManager::RegisterTODLightActor(AActor* Actor)
{
	TWeakObjectPtr<AActor> WeakActor = Actor;
	if (!WeakActor.IsValid())
	{
		UE_LOG(LogTemp, Error, TEXT("WorldManager::RegisterTODLightActor can not get actor [%lld]"), WeakActor.KGGetObjectID());
		return;
	}
	if(ULightTODControlComponent* ControlComponent = Actor->GetComponentByClass<ULightTODControlComponent>())
	{
		ControlComponent->UpdateTODState(GetCurrentTimeOfDay());
	}
	TODLightActors.Add(WeakActor);
}

void UWorldManager::UnRegisterTODLightActor(AActor* Actor)
{
	TWeakObjectPtr<AActor> WeakActor = Actor;
	if (!WeakActor.IsValid())
	{
		UE_LOG(LogTemp, Error, TEXT("WorldManager::UnRegisterTODLightActor can not get actor [%lld]"), WeakActor.KGGetObjectID());
		return;
	}
	TODLightActors.Remove(Actor);
}

void UWorldManager::InnerUpdateAllTODLightActors(float DeltaTime)
{
	auto RecentWorld = GetRecentWorld();
	if (!IsValid(RecentWorld))
	{
		return;
	}
	const float CurrentTimeOfDay = GetCurrentTimeOfDay();
	if (CurrentTimeOfDay < 0)
	{
		return;
	}
	
	InnerUpdateTODStreetlight(DeltaTime, CurrentTimeOfDay);

	InnerUpdateTODLight(DeltaTime, CurrentTimeOfDay);
}

void UWorldManager::InnerUpdateTODStreetlight(float DeltaTime, float CurrentTimeOfDay)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UWorldManager_Tick_TODStreetlight");
	
	// 更新每个池子里的路灯的DayTime状态，如果状态变化则开启tick。若当前在Sequence强控亮度的情况下，只更新DayTime状态不更新tick状态
	bool bNeedTickWhenDayTimeChange = StreetlightTODDuration > 0.f;
	for (auto& PoolElem: TODStreetLightPool)
	{
		bool bInDayTime = PoolElem.Key.DetermineIsInDayTime(CurrentTimeOfDay);
		auto& PoolValue = PoolElem.Value;
		if (bInDayTime != PoolValue.IsInDayTime())
		{
			PoolValue.SetIsInDayTime(bInDayTime);
			if (!bStreetlightControlBySequence)
			{
				for (TWeakObjectPtr<AActor> WeakActor: PoolValue.TODStreetlightActors)
				{
					if (!WeakActor.IsValid())
					{
						UE_LOG(LogTemp, Error, TEXT("WorldManager::InnerUpdateTODStreetlight can not get actor [%lld]"), WeakActor.KGGetObjectID());
						continue;
					}
					AActor* OwnerActor = WeakActor.Get();
					if(UStreetlightTODControlComponent* ControlComponent = OwnerActor->GetComponentByClass<UStreetlightTODControlComponent>())
					{
						// 如果需要tick，那么关灯的情况下，需要先把灯亮度设置到最大
						// 在后续的tick里更新变小，所以要ReverseIntensity
						ControlComponent->SetTODStateAtOnce(bInDayTime, bNeedTickWhenDayTimeChange);
					}
				}
				PoolValue.UpdateTickType(bNeedTickWhenDayTimeChange
					? (bInDayTime ? FTODStreetLightPoolValue::EStreetlightTickType::TurnOff : FTODStreetLightPoolValue::EStreetlightTickType::TurnOn)
					: FTODStreetLightPoolValue::EStreetlightTickType::None);
	
				if (bNeedTickWhenDayTimeChange)
				{
					PoolValue.LightDuration = StreetlightTODDuration;
					PoolValue.CurrentTickTime = 0.f;
				}
			}
		}
	}

	// 如果池子里路灯需要tick，则tick更新。若更新结束即关闭该池的tick
	for (auto& PoolElem: TODStreetLightPool)
	{
		auto& PoolValue = PoolElem.Value;
		if (PoolValue.TickType == FTODStreetLightPoolValue::EStreetlightTickType::TurnOff ||
		   PoolValue.TickType == FTODStreetLightPoolValue::EStreetlightTickType::TurnOn)
		{
			const bool bTurningOff = PoolValue.TickType == FTODStreetLightPoolValue::EStreetlightTickType::TurnOff;
			float& TickCurrentTime = PoolValue.CurrentTickTime;
			TickCurrentTime += DeltaTime;
			float Alpha = PoolValue.LightDuration > 0 && TickCurrentTime < PoolValue.LightDuration
				? TickCurrentTime / PoolValue.LightDuration
				: 1.0f;

			for (TWeakObjectPtr<AActor> WeakActor: PoolValue.TODStreetlightActors)
			{
				if (!WeakActor.IsValid())
				{
					UE_LOG(LogTemp, Error, TEXT("WorldManager::InnerUpdateTODStreetlight can not get actor [%lld]"), WeakActor.KGGetObjectID());
					continue;
				}
				AActor* OwnerActor = WeakActor.Get();
				if(UStreetlightTODControlComponent* ControlComponent = OwnerActor->GetComponentByClass<UStreetlightTODControlComponent>())
				{
					if (Alpha >= 1.0f)
					{
						ControlComponent->SetTODStateAtOnce(bTurningOff, false);
					}
					else
					{
						ControlComponent->UpdateTODState(Alpha, bTurningOff);
					}
				}
			}
			if (Alpha >= 1.0f)
			{
				PoolValue.UpdateTickType(FTODStreetLightPoolValue::EStreetlightTickType::None);
			}
		}
	}
}

void UWorldManager::InnerUpdateTODLight(float DeltaTime, float CurrentTimeOfDay)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UWorldManager_Tick_TODLightActor");
	
	for (TWeakObjectPtr<AActor> WeakActor: TODLightActors)
	{
		if (!WeakActor.IsValid())
		{
			UE_LOG(LogTemp, Error, TEXT("WorldManager::InnerUpdateTODLight actor not valid [%lld]"), WeakActor.KGGetObjectID());
			continue;
		}
		AActor* OwnerActor = WeakActor.Get();
		if(ULightTODControlComponent* ControlComponent = OwnerActor->GetComponentByClass<ULightTODControlComponent>())
		{
			ControlComponent->UpdateTODState(CurrentTimeOfDay);
		}
	}
}

#pragma endregion TODLight

#pragma region AnimationBudget

void UWorldManager::EnableAnimationBudget(bool Enable, float BudgetTime, int MinimumFullTickNum, bool UseQuadraticAlpha) {
	IsUseAnimationBudget = Enable;

	IConsoleVariable* CVarEnabled = IConsoleManager::Get().FindConsoleVariable(TEXT("a.Budget.Enabled"));
	CVarEnabled->SetWithCurrentPriority(Enable);
	

	if (Enable) {


		IConsoleVariable* CVarMinimumFullTickNumInBudget = IConsoleManager::Get().FindConsoleVariable(TEXT("a.Budget.MinimumFullTickNumInBudget"));
		CVarMinimumFullTickNumInBudget->SetWithCurrentPriority(MinimumFullTickNum);

		IConsoleVariable* CVarBudgetMs = IConsoleManager::Get().FindConsoleVariable(TEXT("a.Budget.BudgetMs"));
		CVarBudgetMs->SetWithCurrentPriority(BudgetTime);

		IConsoleVariable* CVarUseQuadraticToSetTickRate = IConsoleManager::Get().FindConsoleVariable(TEXT("a.Budget.UseQuadraticToSetTickRate"));
		CVarUseQuadraticToSetTickRate->SetWithCurrentPriority(UseQuadraticAlpha);
	}

}
#pragma endregion

#pragma region VirtualTexture
void UWorldManager::FlushVirtualTextureCache()
{
	GetRendererModule().FlushVirtualTextureCache(); 
}
#pragma endregion

#pragma region EnvironmentTheme

//1.预加载LoadLevelPreset，切地图的时候每次只能执行一个
//2.不加载LightingScenario类型
//3.默认同步加载，不显示
int UWorldManager::PreloadLevelPresetForEnvironmentTheme(const TArray<FString>& InPresetPathList, bool bMakeVisibleAfterLoad, bool bShouldBlockOnLoad)
{
	LoadedLevelPreset.Reset();
	IsDynamicLevelPreloadSet.Reset();
	UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this);
	if (!AssetManager)
	{
		return 0;
	}
	
	if (LoadLevelPresetID!=0)
	{
		AssetManager->CancelAsyncLoadByLoadID(LoadLevelPresetID);
		LoadLevelPresetID = 0;
	}
	
	LoadLevelPresetID = AssetManager->AsyncLoadAsset(InPresetPathList, FAsyncLoadListCompleteDelegate::CreateUObject(this, &UWorldManager::OnPreLoadLevelPresetLoaded, bMakeVisibleAfterLoad, bShouldBlockOnLoad), static_cast<int32>(EAssetLoadPriority::MoveCurve));
	return LoadLevelPresetID;
}

void UWorldManager::OnPreLoadLevelPresetLoaded(int LoadID, const TArray<UObject*>& InAssets, bool bMakeVisibleAfterLoad, bool bShouldBlockOnLoad)
{
	QUICK_SCOPE_CYCLE_COUNTER(UWorldManager_OnPreLoadLevelPresetLoaded);
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UWorldManager_OnPreLoadLevelPresetLoaded");
	
	LoadLevelPresetID = 0;
	
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}
	
	for (auto Asset : InAssets)
	{
		UWorldLevelsPresetAsset* WorldLevelsPresetAsset = Cast<UWorldLevelsPresetAsset>(Asset);
		if (!IsValid(WorldLevelsPresetAsset))
		{
			UE_LOG(LogTemp, Error, TEXT("[EnvironmentTheme] OnLoadLevelPresetLoaded, invalid WorldLevelsPresetAsset"));
			return;
		}

		LoadedLevelPreset.Add(WorldLevelsPresetAsset->GetPathName(), WorldLevelsPresetAsset);
		for (auto LevelInfo : WorldLevelsPresetAsset->Preset.Levels)
		{
			FString DisplayName = GetStreamingLevelMobileName(LevelInfo.DisplayName);
			FName SubLevelName = FName(DisplayName);
			ULevelStreaming* Level = UGameplayStatics::GetStreamingLevel(World, SubLevelName);
			if (!Level)
			{
				UE_LOG(LogTemp, Warning, TEXT("[EnvironmentTheme] OnPreLoadLevelPresetLoaded sublevel must in persistent level, invalid Level : %s"), *DisplayName);
				continue;
			}
			
			if (!LevelInfo.bIsLightingScenario)
			{
				if (LevelInfo.bIsVisibleInEditor && !Level->IsLevelLoaded())
				{
					//预加载的Level, Disable的时候不要去卸载，后面可能会用
					if (auto DynamicLevel = Cast<ULevelStreamingDynamic>(Level))
					{
						DynamicLevel->SetShouldBeVisible(bMakeVisibleAfterLoad); //这里false不会加载了????
						DynamicLevel->SetShouldBeLoaded(true);
						IsDynamicLevelPreloadSet.Add(DisplayName);
					}
				}
			}
		}
	}

	if (bShouldBlockOnLoad)
	{
		World->FlushLevelStreaming(EFlushLevelStreamingType::Full);
	}
	
	for (auto Asset : InAssets)
	{
		UWorldLevelsPresetAsset* WorldLevelsPresetAsset = Cast<UWorldLevelsPresetAsset>(Asset);
		if (!IsValid(WorldLevelsPresetAsset))
		{
			UE_LOG(LogTemp, Error, TEXT("[EnvironmentTheme] OnLoadLevelPresetLoaded, invalid WorldLevelsPresetAsset"));
			return;
		}
		
		for (auto LevelInfo : WorldLevelsPresetAsset->Preset.Levels)
		{
			FString DisplayName = GetStreamingLevelMobileName(LevelInfo.DisplayName);
			FName SubLevelName = FName(DisplayName);
			ULevelStreaming* Level = UGameplayStatics::GetStreamingLevel(World, SubLevelName);
			if (!Level)
			{
				UE_LOG(LogTemp, Warning, TEXT("[EnvironmentTheme] OnPreLoadLevelPresetLoaded sublevel must in persistent level, invalid Level : %s"), *DisplayName);
				continue;
			}
			
			if (!LevelInfo.bIsLightingScenario && !LevelInfo.bIsVisibleInEditor && Level->IsLevelVisible() && !bMakeVisibleAfterLoad)
			{
				if (ULevel* LoadedLevel = Level->GetLoadedLevel())
				{
					ActiveLevel(LoadedLevel, false, false);
				}
			}
		}
	}
	
	CallLuaFunction("OnPreLoadLevelPresetDone", LoadID);
}

bool UWorldManager::LoadLevelInstance(UWorld* World, FString& LevelPath, bool bMakeVisibleAfterLoad, bool bShouldBlockOnLoad)
{
	bool bSuccess = false;
	ULevelStreamingDynamic::FLoadLevelInstanceParams Params(World, LevelPath, FTransform::Identity);
	Params.bLoadAsTempPackage = true;
	Params.bInitiallyVisible  = bMakeVisibleAfterLoad;

	ULevelStreamingDynamic* LevelStreaming = ULevelStreamingDynamic::LoadLevelInstance(Params, bSuccess);
	if (!bSuccess || !LevelStreaming)
	{
		UE_LOG(LogTemp, Error, TEXT("[EnvironmentTheme] Failed to load level instance `%s`."), *LevelPath);
		return false;
	}
	LevelStreaming->bShouldBlockOnLoad = bShouldBlockOnLoad;
	return true;
}

void UWorldManager::OnPreLoadLevelPresetSubLevelLoaded(int32 UUID)
{
	UE_LOG(LogTemp, Log, TEXT("[EnvironmentTheme] OnPreLoadLevelPresetSubLevelLoaded %d"), UUID);
}

void UWorldManager::EnableLevelPresetForEnvironmentTheme(const FString& InPresetPath, int index, bool bIgnorePhysics, bool bMakeVisibleAfterLoad, bool bShouldBlockOnLoad)
{
	if (!LoadedLevelPreset.Contains(InPresetPath))
	{
		UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this);
		if (!AssetManager)
		{
			return;
		}
		
		AssetManager->AsyncLoadAsset(InPresetPath,
			FAsyncLoadCompleteDelegate::CreateUObject(this, &UWorldManager::OnEnabledLevelPresetLoaded, index, bIgnorePhysics, bMakeVisibleAfterLoad, bShouldBlockOnLoad),
			static_cast<int32>(EAssetLoadPriority::MoveCurve));
		
		return;
	}
	
	DoEnabledLevelPreset(LoadedLevelPreset[InPresetPath], index, bIgnorePhysics, bMakeVisibleAfterLoad, bShouldBlockOnLoad);
}

void UWorldManager::OnEnabledLevelPresetLoaded(int LoadID, UObject* Asset, int index, bool bIgnorePhysics, bool bMakeVisibleAfterLoad, bool bShouldBlockOnLoad)
{
	UWorldLevelsPresetAsset* WorldLevelsPresetAsset = Cast<UWorldLevelsPresetAsset>(Asset);
	if (!IsValid(WorldLevelsPresetAsset))
	{
		UE_LOG(LogTemp, Error, TEXT("[EnvironmentTheme] OnEnabledLevelPresetLoaded, invalid WorldLevelsPresetAsset LoadID : %d"), LoadID);
		return;
	}

	LoadedLevelPreset.Emplace(WorldLevelsPresetAsset->GetPathName(), WorldLevelsPresetAsset);
	DoEnabledLevelPreset(WorldLevelsPresetAsset, index, bIgnorePhysics, bMakeVisibleAfterLoad, bShouldBlockOnLoad);
}

void UWorldManager::OnEnabledLevelPresetSubLevelLoaded(int32 UUID)
{
	UE_LOG(LogTemp, Log, TEXT("[EnvironmentTheme] OnEnabledLevelPresetSubLevelLoaded %d"), UUID);
}

void UWorldManager::DoEnabledLevelPreset(UWorldLevelsPresetAsset* WorldLevelsPresetAsset, int index, bool bIgnorePhysics, bool bMakeVisibleAfterLoad, bool bShouldBlockOnLoad)
{
	QUICK_SCOPE_CYCLE_COUNTER(UWorldManager_DoEnabledLevelPreset);
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UWorldManager_DoEnabledLevelPreset");
	
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}
	
	if (!IsValid(WorldLevelsPresetAsset))
	{
		UE_LOG(LogTemp, Error, TEXT("[EnvironmentTheme] DoEnabledLevelPreset invalid WorldLevelsPresetAsset"));
		return;
	}
	
	for (int i=0; i < WorldLevelsPresetAsset->Preset.Levels.Num(); i++)
	{
		if (index >= 0 && index != i)
		{
			continue;
		}
		
		auto LevelInfo = WorldLevelsPresetAsset->Preset.Levels[i];
		FString DisplayName = GetStreamingLevelMobileName(LevelInfo.DisplayName);
		FName SubLevelName = FName(DisplayName);
		ULevelStreaming* Level = UGameplayStatics::GetStreamingLevel(World, SubLevelName);
		if (!Level)
		{
			UE_LOG(LogTemp, Warning, TEXT("[EnvironmentTheme] DoEnabledLevelPreset sublevel must in persistent level, invalid Level : %s"), *DisplayName);
			continue;
		}

		//不显示的Disable
        if (!LevelInfo.bIsVisibleInEditor)
        {
        	if (LevelInfo.bIsLightingScenario && Level->IsLevelLoaded())
        	{
        		if (auto DynamicLevel = Cast<ULevelStreamingDynamic>(Level))
        		{
        			DynamicLevel->SetShouldBeVisible(false);
        			DynamicLevel->SetShouldBeLoaded(false);
        			UE_LOG(LogTemp, Log, TEXT("[EnvironmentTheme] DoEnabledLevelPreset UnloadStreamLevel LightingScenario level : %s"), *DisplayName);
        		}
        	}
        	if (ULevel* LoadedLevel = Level->GetLoadedLevel())
        	{
        		//预加载的Level, Disable的时候不要去卸载，后面可能会用
        		bool NeedUnload = false;
        		if (auto DynamicLevel = Cast<ULevelStreamingDynamic>(Level))
        		{
        			if (!IsDynamicLevelPreloadSet.Contains(DisplayName))
        			{
        				DynamicLevel->SetShouldBeVisible(false);
        				DynamicLevel->SetShouldBeLoaded(false);
        				NeedUnload = true;
        				UE_LOG(LogTemp, Log, TEXT("[EnvironmentTheme] DoEnabledLevelPreset UnloadStreamLevel level : %s"), *DisplayName);
        			}
        		}
        		
        		if(!NeedUnload)
        		{
        			ActiveLevel(LoadedLevel, false, bIgnorePhysics);
        		}
        	}
        }

		//普通蓝图类型的，要显示的加载显示, 已经加载的但没显示的ActiveLevel
		if (LevelInfo.bIsVisibleInEditor)
		{
			if (!Level->IsLevelLoaded() || !Level->IsLevelVisible())
			{
				if (auto DynamicLevel = Cast<ULevelStreamingDynamic>(Level))
				{
					DynamicLevel->SetShouldBeVisible(true);
					DynamicLevel->SetShouldBeLoaded(true);
				}
				UE_LOG(LogTemp, Log, TEXT("[EnvironmentTheme] DoEnabledLevelPreset LoadStreamLevel level : %s"), *DisplayName);
			}
		}
	}

	if (bShouldBlockOnLoad)
	{
		World->FlushLevelStreaming(EFlushLevelStreamingType::Full);
	}

	for (int i=0; i < WorldLevelsPresetAsset->Preset.Levels.Num(); i++)
	{
		if (index >= 0 && index != i)
		{
			continue;
		}
		
		auto LevelInfo = WorldLevelsPresetAsset->Preset.Levels[i];
		FString DisplayName = GetStreamingLevelMobileName(LevelInfo.DisplayName);
		FName SubLevelName = FName(DisplayName);
		ULevelStreaming* Level = UGameplayStatics::GetStreamingLevel(World, SubLevelName);
		if (!Level)
		{
			UE_LOG(LogTemp, Warning, TEXT("[EnvironmentTheme] DoEnabledLevelPreset sublevel must in persistent level, invalid Level : %s"), *DisplayName);
			continue;
		}
		
		if (LevelInfo.bIsVisibleInEditor)
		{
			if (ULevel* LoadedLevel = Level->GetLoadedLevel())
			{
				ActiveLevel(LoadedLevel, true, bIgnorePhysics);
			}
		}
	}
	
	CallLuaFunction("DoEnabledLevelPresetDone");
}

void UWorldManager::SetStreamingLevelMobileName(FString StreamingDefaultLevelName, FString StreamingMobileLevelName, bool Enable)
{
	DefaultLevelName = StreamingDefaultLevelName;
	MobileLevelName = StreamingMobileLevelName;
	EnableEnvironmentThemePathReplace = Enable;
}

FString UWorldManager::GetStreamingLevelMobileName(FString StreamingLevelName) const
{
	if (!EnableEnvironmentThemePathReplace)
	{
		return StreamingLevelName;
	}
	
#if PLATFORM_WINDOWS
#if WITH_EDITOR
	FName CurPlatformName;
	GEngine->GetPreviewPlatformName(CurPlatformName);
	if (CurPlatformName == FName("Android") || CurPlatformName == FName("IOS"))
	{
		FString LevelName = StreamingLevelName.Replace(*DefaultLevelName, *MobileLevelName);
		return LevelName;
	}
#endif
	return StreamingLevelName;
#else
	FString LevelName = StreamingLevelName.Replace(*DefaultLevelName, *MobileLevelName);
	return LevelName;
#endif
}

///这里有坑，场景的切换非常依赖这个函数，需要不断补全各种关闭开启的逻辑 
bool UWorldManager::ActiveLevel(ULevel* Level, bool bActive, bool bIgnorePhysics)
{
	QUICK_SCOPE_CYCLE_COUNTER(UWorldManager_ActiveLevel);
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UWorldManager_ActiveLevel");
	
	if (nullptr == Level) { return false; }

	UE_LOG(LogTemp, Log, TEXT("UWorldManager::ActiveLevel, Level : %s"), *Level->GetName());
	
	FName VisibleTag = FName("KG_VisibleInGame");
	FName HiddenTag = FName("KG_HiddenInGame");

	for (auto& Actor : Level->Actors)
	{
		if (nullptr == Actor || Actor->GetClass() == AWorldSettings::StaticClass()) { continue; }

		// first
		if (!Actor->Tags.Contains(HiddenTag) && !Actor->Tags.Contains(VisibleTag))
		{
			if (Actor->IsHidden())
			{
				Actor->Tags.Add(HiddenTag);
			}
			else
			{
				Actor->Tags.Add(VisibleTag);
			}
		}

		if (Actor->Tags.Contains(VisibleTag))
		{
			Actor->SetActorHiddenInGame(!bActive);
		}

		Actor->SetActorTickEnabled(bActive);

		//PostProcessVolume后处理相关
		if (APostProcessVolume * pp = Cast<APostProcessVolume>(Actor))
		{
			if (pp->GetWorld())
			{
				if (bActive)
				{
					pp->GetWorld()->InsertPostProcessVolume(pp);
				}
				else
				{
					pp->GetWorld()->RemovePostProcessVolume(pp);
				}
			}
		}

		//Disable collision & physics
		if (!bIgnorePhysics)
		{
			Actor->SetActorEnableRuntimeCollision(bActive);
		}

		if (!bIgnorePhysics)
		{
			TInlineComponentArray<UActorComponent*> ActorComponents(Actor);
			for (UActorComponent* const ActorComponent : ActorComponents)
			{
				if (ActorComponent)
				{
					if (bActive)
					{
						ActorComponent->CreatePhysicsState();
					}
					else
					{
						ActorComponent->DestroyPhysicsState();
					}
				}
			}
		}
	}
	return true;
}
#pragma region GameplaySpline

void UWorldManager::RegisterSplineEntity(FString InsID, KGObjectID EntityID)
{
	if (GameplaySplines.Contains(InsID))
	{
		UE_LOG(LogTemp, Error, TEXT("[WorldManager::RegisterSplineEntity] InsID:%s, already register entity:%lld"), *InsID, GameplaySplines[InsID].EntityID);
		return;
	}
	
	FGameplaySplineItem NewItem(InsID, EntityID);
	GameplaySplines.Add(InsID, NewItem);
}

void UWorldManager::UnRegisterSplineEntity(FString InsID, KGObjectID EntityID)
{
	if (!GameplaySplines.Contains(InsID))
	{
		UE_LOG(LogTemp, Error, TEXT("[WorldManager::RegisterSplineEntity] InsID:%s, already register entity:%lld"), *InsID, GameplaySplines[InsID].EntityID);
		return;
	}
	
	GameplaySplines.Remove(InsID);
}

void UWorldManager::OnSplineActorEnter(FString InsID, KGObjectID EntityID)
{
	if (FGameplaySplineItem* Item = GameplaySplines.Find(InsID))
	{
		if (UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(this)) 
		{
			if (AC7GameplaySplineActorBase* SplineActorBase = Cast<AC7GameplaySplineActorBase>(ActorManager->GetActorByEntityID(EntityID)))
			{
				SplineActorBase->InitSplinePathByInstanceID(InsID);
				Item->bInWorld = true;
				Item->SplineActor = SplineActorBase;
			}
			else
			{
				UE_LOG(LogTemp, Error, TEXT("OnSplineActorEnter Actor not found or type error, %s, %lld"), *InsID, EntityID)
			}
		}
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("OnSplineActorEnter GameplaySplineItem not found, %s, %lld"), *InsID, EntityID)
	}
}

void UWorldManager::OnSplineActorLeave(FString InsID, KGObjectID EntityID)
{
	if (FGameplaySplineItem* Item = GameplaySplines.Find(InsID))
	{
		Item->bInWorld = true;
		Item->SplineActor = nullptr;
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("OnSplineActorLeave GameplaySplineItem not found, %s, %lld"), *InsID, EntityID)
	}
}

bool UWorldManager::IsGameplaySplineActorPendingLoad(FString InsID)
{
	if (FGameplaySplineItem* Item = GameplaySplines.Find(InsID))
	{
		if (!Item->bInWorld)
		{
			return true;
		}
	}
	return false;
}

class AC7GameplaySplineActorBase* UWorldManager::GetGameplaySplineActorIfReady(FString InsID)
{
	if (FGameplaySplineItem* Item = GameplaySplines.Find(InsID))
	{
		if (Item->bInWorld)
		{
			if (Item->SplineActor.IsValid())
			{
				return Item->SplineActor.Get();
			}
			if (!Item->bLoggedError)
			{
				UE_LOG(LogTemp, Error, TEXT("[WorldManager::GetGameplaySplineActor] InsID:%s, found spline item, but actor is invalid "), *InsID);
				Item->bLoggedError = true;
			}
		}
		return nullptr;
	}
	return nullptr;
}

void UWorldManager::ClearAllSplineItem()
{
	GameplaySplines.Empty();
}

#pragma endregion 
