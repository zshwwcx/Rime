#include "3C/Interactor/C7SceneTextGameActor.h"
#include "Components/WidgetComponent.h"
#include "Blueprint/UserWidget.h"
#include "UMG/Blueprint/KGUserWidget.h"
#include "UMG/Components/KGTextBlock.h"
#include "Engine/Font.h"
#include "Kismet/KismetMathLibrary.h"
#include "Kismet/GameplayStatics.h"

AC7SceneTextGameActor::AC7SceneTextGameActor()
{
	PrimaryActorTick.bCanEverTick = true;
}

void AC7SceneTextGameActor::BeginPlay()
{
	SetActorTickEnabled(false);
	
	Super::BeginPlay();
}

void AC7SceneTextGameActor::Tick(float DeltaSeconds)
{
	UpdateFollowCamera();
}

UKGTextBlock* AC7SceneTextGameActor::GetTextWidget()
{
	UKGTextBlock* TextWidget = nullptr;

	if (UWidgetComponent* WidgetComponent = GetWidgetComponent())
	{
		if (UUserWidget* Widget = WidgetComponent->GetWidget())
		{
			UKGTextBlock* NameWidget = Cast<UKGTextBlock>(Widget->GetWidgetFromName(TEXT("Text_Detail")));
			if (NameWidget)
			{
				TextWidget = NameWidget;
			}
		}
	}

	return TextWidget;
}

void AC7SceneTextGameActor::ShowText(bool bShow)
{
	if (UKGTextBlock* TextWidget = GetTextWidget())
	{
		if (bShow)
		{
			TextWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		}
		else
		{
			TextWidget->SetVisibility(ESlateVisibility::Collapsed);
		}
	}
}

void AC7SceneTextGameActor::SetDisplayText(const FString& DisplayText)
{
	if (UKGTextBlock* TextWidget = GetTextWidget())
	{
		TextWidget->SetText(FText::FromString(DisplayText));
	}
}

void AC7SceneTextGameActor::UpdateFontMaterial(UObject* InMaterial)
{
	if (UKGTextBlock* TextWidget = GetTextWidget())
	{
		FSlateFontInfo CurFontInfo = TextWidget->GetFont();
		CurFontInfo.FontMaterial = InMaterial;
		TextWidget->SetFont(CurFontInfo);
	}
}

void AC7SceneTextGameActor::UpdateFontTypeFace(const FString& FontFaceName)
{
	if (UKGTextBlock* TextWidget = GetTextWidget())
	{
		FSlateFontInfo CurFontInfo = TextWidget->GetFont();
		CurFontInfo.TypefaceFontName = FName(FontFaceName);
		TextWidget->SetFont(CurFontInfo);
	}
}

void AC7SceneTextGameActor::UpdateFontSize(const float FontSize)
{
	if (UKGTextBlock* TextWidget = GetTextWidget())
	{
		FSlateFontInfo CurFontInfo = TextWidget->GetFont();
		CurFontInfo.Size = FontSize < minTextSize ? minTextSize : FontSize;
		UpdateWidgetMaterialTextSizeParam(FontSize);
		TextWidget->SetFont(CurFontInfo);
	}
}

void AC7SceneTextGameActor::UpdateWidgetMaterialTextSizeParam(const float FontSize)
{
	if (UWidgetComponent* WidgetComponent = GetWidgetComponent())
	{
		if (UMaterialInstanceDynamic* MatrialInstance = WidgetComponent->GetMaterialInstance())
		{
			MatrialInstance->SetScalarParameterValue("SlateUIScale", FontSize < minTextSize ? minTextSize / FontSize : 1.0f);
		}
	}
}

void AC7SceneTextGameActor::UpdateFontLetterSpacing(const int32 letterSpacing)
{
	if (UKGTextBlock* TextWidget = GetTextWidget())
	{
		FSlateFontInfo CurFontInfo = TextWidget->GetFont();
		CurFontInfo.LetterSpacing = letterSpacing;
		TextWidget->SetFont(CurFontInfo);
	}
}

void AC7SceneTextGameActor::UpdateFontOutlineSetting(const int32 outlineSize, const bool bMiteredCorners, const bool bFillAlpha, const bool bDropShadows, 
	const float outlineColorR, const float outlineColorG, const float outlineColorB, const float outlineColorA)
{
	if (UKGTextBlock* TextWidget = GetTextWidget())
	{
		FSlateFontInfo CurFontInfo = TextWidget->GetFont();
		FFontOutlineSettings& OutlineSettings = CurFontInfo.OutlineSettings;
		OutlineSettings.OutlineSize = outlineSize;
		OutlineSettings.bMiteredCorners = bMiteredCorners;
		OutlineSettings.bSeparateFillAlpha = bFillAlpha;
		OutlineSettings.bApplyOutlineToDropShadows = bDropShadows;
		OutlineSettings.OutlineColor = FLinearColor(outlineColorR, outlineColorG, outlineColorB, outlineColorA);
		TextWidget->SetFont(CurFontInfo);
	}
}

void AC7SceneTextGameActor::UpdateFontMaterialIsStencil(bool bMaterialIsStencil)
{
	if (UKGTextBlock* TextWidget = GetTextWidget())
	{
		FSlateFontInfo CurFontInfo = TextWidget->GetFont();
		CurFontInfo.bMaterialIsStencil = bMaterialIsStencil;
		TextWidget->SetFont(CurFontInfo);
		if (auto* Mat = TextWidget->GetDynamicFontMaterial())
		{
			Mat->SetScalarParameterValue("UseSDFFont?", bMaterialIsStencil ? 1.0f:0.0f);
		}
	}
}

void AC7SceneTextGameActor::PlayAnimation(const FString& animName, const float duration)
{
	if (UWidgetComponent* WidgetComponent = GetWidgetComponent())
	{
		if (UKGUserWidget* Widget = Cast<UKGUserWidget>(WidgetComponent->GetWidget()))
		{
			if (auto* Animation = Widget->GetWidgetAnimationByName(Widget, animName))
			{
				float AnimDuration = Animation->GetEndTime();
				Widget->PlayAnimation(Animation, 0, 1, EUMGSequencePlayMode::Forward, AnimDuration / duration, false);
			}
		}
	}
}

void AC7SceneTextGameActor::SetIsAnimationFadeType(bool bIsAnimationFadeType)
{
	if (UKGTextBlock* TextWidget = GetTextWidget())
	{
		if (auto* Mat = TextWidget->GetDynamicFontMaterial())
		{
			Mat->SetScalarParameterValue("UseColorTex?", bIsAnimationFadeType ? 1.0f : 0.0f);
		}
	}
}

void AC7SceneTextGameActor::SetDisplayTextColor(const float colorR, const float colorG, const float colorB, const float colorA)
{
	if (UWidgetComponent* WidgetComponent = GetWidgetComponent())
	{
		WidgetComponent->SetTintColorAndOpacity(FLinearColor(colorR, colorG, colorB, colorA));
	}
}

void AC7SceneTextGameActor::SetDisplayTextJustification(const int32 Justification)
{
	if (UKGTextBlock* TextWidget = GetTextWidget())
	{
		TextWidget->SetJustification(ETextJustify::Type(Justification));
	}
}

UWidgetComponent* AC7SceneTextGameActor::GetWidgetComponent()
{
	if (UActorComponent* ActorComponent = GetComponentByClass(UWidgetComponent::StaticClass()))
	{
		if (UWidgetComponent* WidgetComponent = Cast<UWidgetComponent>(ActorComponent))
		{
			return WidgetComponent;
		}
	}
	return nullptr;
}

int32 AC7SceneTextGameActor::GetTextLineNum()
{
	if (UKGTextBlock* TextWidget = GetTextWidget())
	{
		return TextWidget->GetTextLineNum();
	}
	return 0;
}

TArray<FVector> AC7SceneTextGameActor::GetTextRunLocationByRange(int32 BeginIndex, int32 EndIndex, bool bInComponentSpace)
{
	TArray<FVector> Ret;
	if (UWidgetComponent* WidgetComponent = GetWidgetComponent())
	{
		FVector2D CurrentDrawSize = WidgetComponent->GetCurrentDrawSize();
		FTransform WorldTransform = WidgetComponent->GetComponentTransform();
		if (UKGTextBlock* TextBlock = GetTextWidget())
		{
			FVector2D LocationBegin = FVector2D::ZeroVector;
			FVector2D Size = FVector2D::ZeroVector;
			if (TextBlock->GetRunLocationAndSizeByRange(BeginIndex, EndIndex, LocationBegin, Size))
			{
				Ret.Reserve(2);
				FVector2D AbsoluteStart = LocationBegin;
				FVector ComponentSpaceLocalBeginPos(
					0,
					CurrentDrawSize.X/2 - AbsoluteStart.X,
					CurrentDrawSize.Y/2 - AbsoluteStart.Y
					);
				Ret.Emplace(bInComponentSpace ? ComponentSpaceLocalBeginPos : WorldTransform.TransformPosition(ComponentSpaceLocalBeginPos));
					
				FVector2D AbsoluteEnd = LocationBegin + Size;
				FVector ComponentSpaceLocalEndPos(
					0,
					CurrentDrawSize.X/2 - AbsoluteEnd.X,
					CurrentDrawSize.Y/2 - AbsoluteEnd.Y
				);
				Ret.Emplace(bInComponentSpace ? ComponentSpaceLocalEndPos : WorldTransform.TransformPosition(ComponentSpaceLocalEndPos));
				return Ret;
			}
		}
	}
	return Ret;
}

void AC7SceneTextGameActor::SetTextFollowCameraEnabled(bool bInEnable, bool bOnlyYaw)
{
	SetActorTickEnabled(bInEnable);
	
	bFollowingCamera = bInEnable;
	bOnlyFollowCameraYaw = bOnlyYaw;
}

void AC7SceneTextGameActor::UpdateFollowCamera()
{
	if (bFollowingCamera)
	{
		if (UWorld* World = GetWorld())
		{
			if (APlayerCameraManager* CameraManager = World->GetFirstPlayerController()->PlayerCameraManager)
			{
				if (UWidgetComponent* WidgetComponent = GetWidgetComponent())
				{
					FVector CameraLocation = CameraManager->GetCameraLocation();
					FVector WidgetLocation = WidgetComponent->GetComponentLocation();
					FVector DirectionToCamera = (CameraLocation - WidgetLocation).GetSafeNormal();
					FRotator TargetRotation = DirectionToCamera.Rotation();
					if (bOnlyFollowCameraYaw)
					{
						TargetRotation.Pitch = 0.0f;
						TargetRotation.Roll = 0.0f;
					}
					WidgetComponent->SetWorldRotation(TargetRotation);
				}
			}
		}
	}
}
