// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Interactor/Components/ChildSceneActorComponent.h"
#include "Engine/World.h"


#if WITH_EDITOR

void UChildSceneActorComponent::OnRegister()
{
	Super::OnRegister();
	
	ConditionalGenerateInstanceID(true);
}
// 不能放在PostDuplicate里
// 因为如果是蓝图Actor，在Editor下加载后都会执行AActor::RerunConstructionScripts
// 会从BP模板对Component从进行Duplicate，只有PostEditImport才是仅仅在编辑器中粘贴
void UChildSceneActorComponent::PostEditImport()
{
	Super::PostEditImport();

	ConditionalGenerateInstanceID(false);
}

void UChildSceneActorComponent::ConditionalGenerateInstanceID(bool bCheckZero)
{
	if (!HasAnyFlags(RF_ClassDefaultObject))
	{
		if (UWorld* World = GetWorld())
		{
			if (!World->IsInBlueprint() && World->WorldType == EWorldType::Editor)
			{
				if (!bCheckZero || InstanceID == 0)
				{
					InstanceID = GetTypeHash(FGuid::NewGuid());
				}
			}
		}
	}
}

#endif
