#include "3C/Interactor/Components/BookFloorComponent.h"

#include "WorldPartition/ContentBundle/ContentBundleLog.h"
#include "NiagaraComponent.h"
#include "Misc/ObjCrashCollector.h"
#include "Components/StaticMeshComponent.h"

UBookFloorComponent::UBookFloorComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UBookFloorComponent::BeginPlay()
{
	Super::BeginPlay();
	SetComponentTickEnabled(false);
}

void UBookFloorComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	if (!MainPlayer.IsValid())
	{
		return;
	}
	if (AActor* Owner = GetOwner())
	{
		FVector PlayerPos = MainPlayer->GetActorLocation();
		FVector PlayerPosInterp = FMath::VInterpTo(PrePlayerPos, PlayerPos, DeltaTime, InterpSpeed);
		PrePlayerPos = PlayerPos;
		TArray MeshComponents = Owner->K2_GetComponentsByClass(UStaticMeshComponent::StaticClass());
		for (int i = 0; i < MeshComponents.Num(); i++)
		{
			if (UStaticMeshComponent* MeshComponent = Cast<UStaticMeshComponent>(MeshComponents[i]))
			{
				MeshComponent->SetVectorParameterValueOnMaterials("PlayerPos", PlayerPos);
				MeshComponent->SetVectorParameterValueOnMaterials("PlayerPosFormer", PlayerPosInterp);
			}
		}
		if (NiagaraComponent.IsValid())
		{
			NiagaraComponent->SetRelativeLocation(FVector(PlayerPos.X, PlayerPos.Y, FloorZOffset));
		}
	}
}

void UBookFloorComponent::InitBookFloor(AActor* Player, UNiagaraComponent* InNiagaraComponent, float ZOffset, float InInterpSpeed)
{
	c7_obj_check(Player);
	MainPlayer = Player;
	c7_obj_check(InNiagaraComponent);
	NiagaraComponent = InNiagaraComponent;
	FloorZOffset = ZOffset;
	InterpSpeed = InInterpSpeed;
	
	if (MainPlayer.IsValid())
	{
		PrePlayerPos = MainPlayer->GetActorLocation();
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("MainPlayer is null in UBookFloorComponent::InitBookFloor"));
		return;
	}
	SetComponentTickEnabled(true);
}

void UBookFloorComponent::UnitBookFloor()
{
	SetComponentTickEnabled(false);
}


