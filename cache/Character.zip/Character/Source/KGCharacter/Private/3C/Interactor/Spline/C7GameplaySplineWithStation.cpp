// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Interactor/Spline/C7GameplaySplineWithStation.h"
#include "Components/SplineComponent.h"
#include "TypeDefines/LuaTypes.h"
#include "Managers/KGDataCacheManager.h"


AC7GameplaySplineWithStation::AC7GameplaySplineWithStation()
{
	SplineType = EGamePlaySplinePathType::Station;
}

bool AC7GameplaySplineWithStation::InitSplinePointAttributes(const FString& InstanceID)
{
	if (UKGDataCacheManager* DataCacheManager = UKGDataCacheManager::GetInstance(this))
	{
		if (FGameplaySplineStationData* StationData = DataCacheManager->GetGameplaySplineStationData(InstanceID))
		{
			Stations = StationData->Stations;
			
			const int32 SplineNum = SplineComponent->GetNumberOfSplinePoints();
			return SplineNum == Stations.Num();
		}
	}
	return false;
}
