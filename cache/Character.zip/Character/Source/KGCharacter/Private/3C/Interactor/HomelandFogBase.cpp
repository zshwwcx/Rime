#include "3C/Interactor/HomelandFogBase.h"

#include "Components/StaticMeshComponent.h"
#include "Materials/Material.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "ProceduralMeshComponent.h"
#include "3C/Material/KGMaterialManager.h"


void AHomelandFogBase::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	TWeakObjectPtr<UKGMaterialManager> MaterialManager = UKGMaterialManager::GetInstance(this);
	if (MaterialManager.IsValid())
	{
		if (MaterialUpdateTaskId > 0)
		{
			MaterialManager->RemoveMaterialParamUpdateTask(MaterialUpdateTaskId);
			MaterialUpdateTaskId = 0;
		}
	}
	Super::EndPlay(EndPlayReason);
}

void AHomelandFogBase::UpdateHomelandFogMaterialParam(const int32 CurrentLevel, const float MaterialUpdateDuration, const float StartVal, const float EndVal)
{
	FName* ParamName = LevelToMaterialParamName.Find(CurrentLevel);
	if (ParamName && !ParamName->IsNone())
	{
		// 雾的材质参数
		if (UActorComponent* ActorComponent = GetComponentByClass(UStaticMeshComponent::StaticClass()))
		{
			if (UStaticMeshComponent* FogMeshComponent = Cast<UStaticMeshComponent>(ActorComponent))
			{
				TWeakObjectPtr<UKGMaterialManager> MaterialManager = UKGMaterialManager::GetInstance(this);
				if (MaterialManager.IsValid())
				{
					if (MaterialUpdateTaskId > 0)
					{
						MaterialManager->RemoveMaterialParamUpdateTask(MaterialUpdateTaskId);
						MaterialUpdateTaskId = 0;
					}

					if (UMaterialInstanceDynamic* MID = FogMeshComponent->CreateDynamicMaterialInstance(0))
					{
						// for (const auto& Elem: LevelToMaterialParamName)
						// {
						// 	if (Elem.Value != *ParamName)
						// 	{
						// 		MID->SetScalarParameterValue(Elem.Value, 0.f);
						// 	}
						// }
						if (MaterialUpdateDuration > 0)
						{
							MaterialUpdateTaskId = MaterialManager->AddScalarLinearSampleParamByDynamicMaterialInstance(
								*ParamName,
								MID,
								StartVal,
								EndVal,
								MaterialUpdateDuration,
								false
							);
						}
						else
						{
							MID->SetScalarParameterValue(*ParamName, EndVal);
						}
					}
				}
			}
		}
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("UpdateLevelAndBlocks can not found material param name for level:%d"), CurrentLevel);
	}
}


void AHomelandFogBase::CreateHomelandFogBlocks(
		const EHomelandFogBlockType BlockType,
		const float& LeftTopX,
		const float& LeftTopY,
		const float& LeftBottomX,
		const float& LeftBottomY,
		const float& RightTopX,
		const float& RightTopY,
		const float& RightBottomX,
		const float& RightBottomY)
{
	if (UActorComponent* ActorComponent = GetComponentByClass(UProceduralMeshComponent::StaticClass()))
	{
		if (UProceduralMeshComponent* ProceduralMeshComponent = Cast<UProceduralMeshComponent>(ActorComponent))
		{
			int32 BlockTypeNumber = (int32)BlockType;
			
			TArray<FVector> Vertices;
			TArray<FVector> Normals;
			TArray<FProcMeshTangent> Tangents;
			TArray<FVector2D> UV0;
			TArray<int32> Triangles;
			TArray<FColor> VertexColors;

			ProceduralMeshComponent->ClearAllMeshSections();
			ProceduralMeshComponent->ClearCollisionConvexMeshes();
			FTransform ComponentToWorld = ProceduralMeshComponent->GetComponentToWorld();
			FVector LocalLeftTop = ComponentToWorld.InverseTransformPosition(FVector(LeftTopX, LeftTopY, 0));
			FVector LocalRightTop = ComponentToWorld.InverseTransformPosition(FVector(RightTopX, RightTopY, 0));
			FVector LocalLeftBottom = ComponentToWorld.InverseTransformPosition(FVector(LeftBottomX, LeftBottomY, 0));
			FVector LocalRightBottom = ComponentToWorld.InverseTransformPosition(FVector(RightBottomX, RightBottomY, 0));
			
			int32 Index = 0;
			if (BlockTypeNumber & (int32)EHomelandFogBlockType::Top)
			{
				GenerateProceduralMeshSection(ProceduralMeshComponent, LocalLeftTop, LocalRightTop, Index++, Vertices, Normals, UV0, Triangles);
			}
			if (BlockTypeNumber & (int32)EHomelandFogBlockType::Left)
			{
				GenerateProceduralMeshSection(ProceduralMeshComponent, LocalLeftTop, LocalLeftBottom, Index++, Vertices, Normals, UV0, Triangles);
			}
			if (BlockTypeNumber & (int32)EHomelandFogBlockType::Right)
			{
				GenerateProceduralMeshSection(ProceduralMeshComponent, LocalRightTop, LocalRightBottom, Index++, Vertices, Normals, UV0, Triangles);
			}
			if (BlockTypeNumber & (int32)EHomelandFogBlockType::Bottom)
			{
				GenerateProceduralMeshSection(ProceduralMeshComponent, LocalLeftBottom, LocalRightBottom, Index++, Vertices, Normals, UV0, Triangles);
			}
			ProceduralMeshComponent->CreateMeshSection(0, Vertices, Triangles, Normals, UV0, VertexColors, Tangents, true);
		}
	}
}

void AHomelandFogBase::GenerateProceduralMeshSection(class UProceduralMeshComponent* ProceduralMeshComponent, const FVector& StartLocation, const FVector& EndLocation, const int32& Index, TArray<FVector>& OutVertices, TArray<FVector>& OutNormals, TArray<FVector2D>& OutUV0, TArray<int32>& OutTriangles)
{
	FVector Scale = ProceduralMeshComponent->GetComponentScale();
	float BockHeightScale = FMath::Max(Scale.Z, 0.1);
	FVector HeightOffset = FVector(0,0,BlockHeight/BockHeightScale);
	FVector BottomOffset = FVector(0,0,-BlockHeight/BockHeightScale);
	FVector NormalF = FVector(0,0,0);
	
	FVector APoint = EndLocation + BottomOffset;
	FVector BPoint = StartLocation + BottomOffset;
	FVector CPoint = StartLocation + HeightOffset;
	FVector DPoint = EndLocation + HeightOffset;
	
	OutVertices.Add(APoint);
	OutVertices.Add(BPoint);
	OutVertices.Add(CPoint);
	OutVertices.Add(DPoint);

	OutTriangles.Add(0 + Index * 4);
	OutTriangles.Add(1 + Index * 4);
	OutTriangles.Add(3 + Index * 4);
	
	// OutTriangles.Add(3 + Index * 4);
	// OutTriangles.Add(1 + Index * 4);
	// OutTriangles.Add(0 + Index * 4);
	
	OutTriangles.Add(3 + Index * 4);
	OutTriangles.Add(1 + Index * 4);
	OutTriangles.Add(2 + Index * 4);
	
	// OutTriangles.Add(2 + Index * 4);
	// OutTriangles.Add(1 + Index * 4);
	// OutTriangles.Add(3 + Index * 4);

	OutNormals.Add(NormalF);
	OutNormals.Add(NormalF);
	OutNormals.Add(NormalF);
	OutNormals.Add(NormalF);

	OutUV0.Add(FVector2D(1,1));
	OutUV0.Add(FVector2D(0,1));
	OutUV0.Add(FVector2D(0,0));
	OutUV0.Add(FVector2D(1,0));

	// 沿着这个两点的正交方向给碰撞一定的厚度
	float CollisionThicknessScale = FMath::Max((Scale.X + Scale.Y)/2, 0.1);
	FVector XYDirectOrthogonal = FVector(StartLocation.Y - EndLocation.Y, -(StartLocation.X - EndLocation.X), 0);
	XYDirectOrthogonal.Normalize(1e-8);
	XYDirectOrthogonal = XYDirectOrthogonal * BlockThickness/CollisionThicknessScale;

	TArray<FVector> Collisions;
	Collisions.Add(APoint + XYDirectOrthogonal);
	Collisions.Add(APoint - XYDirectOrthogonal);
	Collisions.Add(BPoint + XYDirectOrthogonal);
	Collisions.Add(BPoint - XYDirectOrthogonal);
	Collisions.Add(CPoint + XYDirectOrthogonal);
	Collisions.Add(CPoint - XYDirectOrthogonal);
	Collisions.Add(DPoint + XYDirectOrthogonal);
	Collisions.Add(DPoint - XYDirectOrthogonal);
	
	ProceduralMeshComponent->AddCollisionConvexMesh(Collisions);
}
