// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Interactor/Components/LightTODControlComponent.h"
#include "Components/LightComponent.h"
#include "Engine/World.h"
#include "3C/Interactor/WorldManager.h"

ULightTODControlComponent::ULightTODControlComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

void ULightTODControlComponent::BeginPlay()
{
	Super::BeginPlay();

	if (!LightIntensityCurve)
	{
		UE_LOG(LogTemp, Error, TEXT("ULightTODControlComponent LightIntensityCurve is not set, Actor:%s"), *GetPathName());
		return;
	}
	
	AActor* Actor = Cast<AActor>(GetOwner());
	TArray<UActorComponent*> Components = LightComponentTag == NAME_None ?
		Actor->K2_GetComponentsByClass(ULightComponent::StaticClass())
		: Actor->GetComponentsByTag(ULightComponent::StaticClass(), LightComponentTag);
	DefaultIntensityMap.Empty();
	for (auto Component : Components)
	{
		if (ULightComponent* LightComponent = Cast<ULightComponent>(Component))
		{
			DefaultIntensityMap.Add(LightComponent, LightComponent->Intensity);
		}
	}
	if (DefaultIntensityMap.IsEmpty())
	{
		UE_LOG(LogTemp, Error, TEXT("ULightTODControlComponent cant not found light components, Actor:%s"), *GetPathName());
		return;
	}

	if (UWorldManager* WorldManager = UWorldManager::GetInstance(this))
	{
		WorldManager->RegisterTODLightActor(Actor);
		bRegisteredToManager = true;
	}
}

void ULightTODControlComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (bRegisteredToManager)
	{
		if (AActor* Actor = Cast<AActor>(GetOwner()))
		{
			if (UWorldManager* WorldManager = UWorldManager::GetInstance(this))
			{
				WorldManager->UnRegisterTODLightActor(Actor);
			}
		}
	}
	
	Super::EndPlay(EndPlayReason);
}

void ULightTODControlComponent::UpdateTODState(float CurrentTimeOfDay)
{
	for (auto LightElem : DefaultIntensityMap)
	{
		if (LightElem.Key.IsValid())
		{
			if (LightIntensityCurve)
			{
				const float CurrentIntensity = LightIntensityCurve->GetFloatValue(CurrentTimeOfDay);
				LightElem.Key->SetIntensity(CurrentIntensity);
			}
		}
	}
}