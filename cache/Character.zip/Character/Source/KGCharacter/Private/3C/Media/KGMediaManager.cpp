#include "3C/Media/KGMediaManager.h"
#include "BinkMediaPlayer.h"
#include "BinkMediaTexture.h"
#include "MediaSoundComponent.h"
#include "Manager/KGCppAssetManager.h"
#include "3C/Material/KGMaterialManager.h"
#include "Misc/ObjCrashCollector.h"
#include "UMG/Components/KGImage.h"
#include "3C/Util/KGUtils.h"

DEFINE_LOG_CATEGORY(LogKGMedia);
#define INVALID_MEDIA_PLAY_ID (0)

void UKGMediaManager::NativeInit()
{
	Super::NativeInit();

	using namespace NS_SLUA;
	REG_MANAGER_FUNC(UKGMediaManager, "KAPI_MediaManager_PlayBinkMedia", &UKGMediaManager::KAPI_MediaManager_PlayBinkMedia);
	REG_MANAGER_FUNC(UKGMediaManager, "KAPI_MediaManager_PlayRenderToTextureBinkMedia", &UKGMediaManager::KAPI_MediaManager_PlayRenderToTextureBinkMedia);
	REG_EXTENSION_METHOD(UKGMediaManager, "KAPI_MediaManager_PlayUIRenderToTextureBinkMedia", &UKGMediaManager::KAPI_MediaManager_PlayUIRenderToTextureBinkMedia);
	
	REG_MANAGER_FUNC(UKGMediaManager, "KAPI_MediaManager_OpenUrl", &UKGMediaManager::KAPI_MediaManager_OpenUrl);
	REG_MANAGER_FUNC(UKGMediaManager, "KAPI_MediaManager_CloseUrl", &UKGMediaManager::KAPI_MediaManager_CloseUrl);
	REG_MANAGER_FUNC(UKGMediaManager, "KAPI_MediaManager_SetLooping", &UKGMediaManager::KAPI_MediaManager_SetLooping);
	REG_MANAGER_FUNC(UKGMediaManager, "KAPI_MediaManager_SetPlayRate", &UKGMediaManager::KAPI_MediaManager_SetPlayRate);
	REG_MANAGER_FUNC(UKGMediaManager, "KAPI_MediaManager_RewindBinkMedia", &UKGMediaManager::KAPI_MediaManager_RewindBinkMedia);
	REG_MANAGER_FUNC(UKGMediaManager, "KAPI_MediaManager_StartBinkMedia", &UKGMediaManager::KAPI_MediaManager_StartBinkMedia);
	REG_MANAGER_FUNC(UKGMediaManager, "KAPI_MediaManager_PauseBinkMedia", &UKGMediaManager::KAPI_MediaManager_PauseBinkMedia);
	REG_MANAGER_FUNC(UKGMediaManager, "KAPI_MediaManager_SeekByTime", &UKGMediaManager::KAPI_MediaManager_SeekByTime);
	REG_MANAGER_FUNC(UKGMediaManager, "KAPI_MediaManager_SeekByPercent", &UKGMediaManager::KAPI_MediaManager_SeekByPercent);
	REG_MANAGER_FUNC(UKGMediaManager, "KAPI_MediaManager_UpdateMediaMaterialParamLinearSample", &UKGMediaManager::KAPI_MediaManager_UpdateMediaMaterialParamLinearSample);
	
	REG_MANAGER_FUNC(UKGMediaManager, "KAPI_MediaManager_StopBinkMedia", &UKGMediaManager::KAPI_MediaManager_StopBinkMedia);
	REG_MANAGER_FUNC(UKGMediaManager, "KAPI_MediaManager_StopAllBinkMedias", &UKGMediaManager::KAPI_MediaManager_StopAllBinkMedias);
	REG_MANAGER_FUNC(UKGMediaManager, "KAPI_MediaManager_StopBinkMediaByMediaPlayerPath", &UKGMediaManager::KAPI_MediaManager_StopBinkMediaByMediaPlayerPath);
	
	REG_MANAGER_FUNC(UKGMediaManager, "KAPI_MediaManager_GeneratePlayID", &UKGMediaManager::KAPI_MediaManager_GeneratePlayID);
	REG_EXTENSION_METHOD(UKGMediaManager, "KAPI_MediaManager_CreateMediaSoundComponent", &UKGMediaManager::KAPI_MediaManager_CreateMediaSoundComponent);
	REG_EXTENSION_METHOD(UKGMediaManager, "KAPI_MediaManager_DestroyMediaSoundComponent", &UKGMediaManager::KAPI_MediaManager_DestroyMediaSoundComponent);
}

void UKGMediaManager::NativeUninit()
{
	StopAllBinkMedias();
	Super::NativeUninit();
}

int32 UKGMediaManager::KAPI_MediaManager_PlayBinkMedia(
	const FString& MediaPlayerPath,
	bool bUseCustomUrl, const FString& Url,
	bool bUseCustomLoop, bool bLoop,
	bool bUseCustomStartImmediately, bool bStartImmediately,
	bool bUseCustomPlayRate, float PlayRate,
	bool bBindMediaReachEndCallback, bool bAutoStop)
{
	FKGPlayMediaRecord Record;
	Record.MediaPlayerPath = MediaPlayerPath;
	if (bUseCustomUrl)
	{
		Record.Url = Url;	
	}
	if (bUseCustomLoop)
	{
		Record.bLoop = bLoop;	
	}
	if (bUseCustomStartImmediately)
	{
		Record.bStartImmediately = bStartImmediately;
	}
	if (bUseCustomPlayRate)
	{
		Record.PlayRate = PlayRate;
	}
	Record.bBindMediaReachEndCallback = bBindMediaReachEndCallback;
	Record.bAutoStop = bAutoStop;

	const FName MediaPlayerPathName = *Record.MediaPlayerPath;
	// 当前不允许同一个Player被多个业务共用
	if (MediaPlayerPathToPlayIDs.Contains(MediaPlayerPathName))
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::PlayBinkMedia, MediaPlayerPathName already in use %s"), *Record.MediaPlayerPath);
		return INVALID_MEDIA_PLAY_ID;	
	}
	
	const int32 PlayID = GenerateID();
	
	UE_LOG(LogKGMedia, Log,
		TEXT("UKGMediaManager::PlayBinkMedia, MediaPlayerPathName: %s, Url: %s, PlayID: %d"),
		*Record.MediaPlayerPath,
		Record.Url.IsSet() ? *Record.Url.GetValue() : TEXT("unset"),
		PlayID);
	
	UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this);
	if (!AssetManager)
	{
		UE_LOG(LogKGMedia, Error, TEXT("cannot find asset manager"));
		return INVALID_MEDIA_PLAY_ID;
	}

	Record.AssetLoadID = AssetManager->AsyncLoadAsset(Record.MediaPlayerPath, FAsyncLoadCompleteDelegate::CreateUObject(this, &UKGMediaManager::OnMediaPlayerLoaded, PlayID));
	
	PlayMediaRecords.Add(PlayID, Record);
	MediaPlayerPathToPlayIDs.Add(MediaPlayerPathName, PlayID);
	return PlayID;
}

int32 UKGMediaManager::KAPI_MediaManager_PlayRenderToTextureBinkMedia(
	const FString& Url, bool bLoop, bool bStartImmediately, float PlayRate, bool bBindMediaReachEndCallback, bool bAutoStop,
	KGActorID OwnerActorID, const FString& MaterialPath, EKGSearchMeshType SearchMeshType, const FName& MeshName, EKGSearchMaterialType SearchMaterialType,
	const TArray<FName>& MaterialSlotNames, const FName& MediaTextureParamName, int32 CustomPlayID)
{
	AActor* OwnerActor = KGUtils::GetActorByID(OwnerActorID);
	if (!OwnerActor)
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::PlayRenderToTextureBinkMedia, cannot find OwnerActor by ID %lld"), OwnerActorID);
		return INVALID_MEDIA_PLAY_ID;
	}

	UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(this);
	if (!MaterialManager)
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::PlayRenderToTextureBinkMedia, cannot find material manager"));
		return INVALID_MEDIA_PLAY_ID;
	}

	if (MaterialPath.IsEmpty())
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::PlayRenderToTextureBinkMedia, MaterialPath is empty"));
		return INVALID_MEDIA_PLAY_ID;
	}
	
	const int32 PlayID = CustomPlayID == -1 ? GenerateID() : CustomPlayID;
	
	UE_LOG(LogKGMedia, Log,
		TEXT("UKGMediaManager::PlayRenderToTextureBinkMedia, Url: %s, PlayID: %d"), *Url,PlayID);
	
	if (PlayMediaRecords.Contains(PlayID))
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::PlayRenderToTextureBinkMedia, invalid PlayID %d"), PlayID);
		return INVALID_MEDIA_PLAY_ID;
	}
	
	UBinkMediaPlayer* BinkMediaPlayer = NewObject<UBinkMediaPlayer>();
	
	FKGPlayMediaRecord& Record = PlayMediaRecords.Add(PlayID);
	Record.Url = Url;
	Record.bLoop = bLoop;
	Record.bStartImmediately = bStartImmediately;
	Record.PlayRate = PlayRate;
	Record.bBindMediaReachEndCallback = bBindMediaReachEndCallback;
	Record.bAutoStop = bAutoStop;
	Record.BinkMediaPlayer = BinkMediaPlayer;
	
	InternalPlayBinkMedia(Record, PlayID);

	UBinkMediaTexture* MediaTexture = NewObject<UBinkMediaTexture>();
	MediaTexture->SetMediaPlayer(BinkMediaPlayer);
	Record.BinkMediaTexture = MediaTexture;
	
	FKGChangeMaterialRequest ChangeMaterialRequest;
	ChangeMaterialRequest.OwnerActor = OwnerActor;
	ChangeMaterialRequest.MaterialPath = MaterialPath;
	ChangeMaterialRequest.SearchMeshType = SearchMeshType;
	ChangeMaterialRequest.SearchMeshName = MeshName;
	ChangeMaterialRequest.SearchMaterialType = SearchMaterialType;
	ChangeMaterialRequest.MaterialSlotNames = MaterialSlotNames;
	Record.ChangeMaterialID = MaterialManager->ChangeMaterial(ChangeMaterialRequest);
	
	FKGChangeMaterialParamRequest ChangeMaterialParamRequest;
	ChangeMaterialParamRequest.OwnerActor = OwnerActor;
	ChangeMaterialParamRequest.SearchMeshType = SearchMeshType;
	ChangeMaterialParamRequest.SearchMeshName = MeshName;
	ChangeMaterialParamRequest.SearchMaterialType = SearchMaterialType;
	ChangeMaterialParamRequest.MaterialSlotNames = MaterialSlotNames;
	ChangeMaterialParamRequest.MediaTextureParams.Add(MediaTextureParamName, PlayID);
	Record.ChangeMaterialParamID = MaterialManager->ChangeMaterialParam(ChangeMaterialParamRequest);
	
	return PlayID;
}

int32 UKGMediaManager::KAPI_MediaManager_PlayUIRenderToTextureBinkMedia(
	const FString& Url, bool bLoop, bool bStartImmediately, float PlayRate, bool bBindMediaReachEndCallback, bool bAutoStop,
	UImage* ImageWidget, const FString& MaterialPath, const FName& MediaTextureParamName)
{
	c7_obj_check(ImageWidget);

	if (!IsValid(ImageWidget))
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::KAPI_MediaManager_PlayUIRenderToTextureBinkMedia, invalid ImageWidget"));
		return INVALID_MEDIA_PLAY_ID;
	}
	
	if (MaterialPath.IsEmpty())
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::KAPI_MediaManager_PlayUIRenderToTextureBinkMedia, MaterialPath is empty"));
		return INVALID_MEDIA_PLAY_ID;
	}

	UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this);
	if (!AssetManager)
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::KAPI_MediaManager_PlayUIRenderToTextureBinkMedia, cannot find asset manager"));
		return INVALID_MEDIA_PLAY_ID;
	}
	
	const int32 PlayID = GenerateID();
	
	FKGPlayMediaRecord& Record = PlayMediaRecords.Add(PlayID);
	Record.Url = Url;
	Record.bLoop = bLoop;
	Record.bStartImmediately = bStartImmediately;
	Record.PlayRate = PlayRate;
	Record.bBindMediaReachEndCallback = bBindMediaReachEndCallback;
	Record.bAutoStop = bAutoStop;
	Record.AssetLoadID = AssetManager->AsyncLoadAsset(
		MaterialPath, FAsyncLoadCompleteDelegate::CreateUObject(this, &UKGMediaManager::OnMaterialAssetLoaded, PlayID, MediaTextureParamName, TWeakObjectPtr(ImageWidget)));

	UE_LOG(LogKGMedia, Log,
		TEXT("UKGMediaManager::KAPI_MediaManager_PlayUIRenderToTextureBinkMedia, MaterialPath: %s, Url: %s, PlayID: %d"),
		*MaterialPath, *Url, PlayID);
	
	return PlayID;
}

bool UKGMediaManager::KAPI_MediaManager_OpenUrl(int32 PlayID, const FString& Url)
{
	FKGPlayMediaRecord* RecordPtr = PlayMediaRecords.Find(PlayID);
	if (RecordPtr == nullptr)
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::OpenUrl, cannot find PlayID %d"), PlayID);
		return false;
	}

	UE_LOG(LogKGMedia, Log, TEXT("UKGMediaManager::OpenUrl, MediaPlayerPathName: %s, Url: %s, PlayID: %d"),
		*RecordPtr->MediaPlayerPath, *Url, PlayID);
	
	if (RecordPtr->BinkMediaPlayer == nullptr)
	{
		RecordPtr->Url = Url;
		return true;
	}
	
	const bool bOpenResult = RecordPtr->BinkMediaPlayer->OpenUrl(Url);
	UE_CLOG(!bOpenResult, LogKGMedia, Error, TEXT("UKGMediaManager::OpenUrl, media URL open failed, MediaPlayerPath: %s, URL: %s"),
		*RecordPtr->MediaPlayerPath, *Url);

	return bOpenResult;
}

void UKGMediaManager::KAPI_MediaManager_CloseUrl(int32 PlayID)
{
	FKGPlayMediaRecord* RecordPtr = PlayMediaRecords.Find(PlayID);
	if (RecordPtr == nullptr)
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::CloseUrl, cannot find PlayID %d"), PlayID);
		return;
	}

	if (RecordPtr->BinkMediaPlayer == nullptr)
	{
		RecordPtr->Url.Reset();
	}
	else
	{
		RecordPtr->BinkMediaPlayer->CloseUrl();
	}
}

bool UKGMediaManager::KAPI_MediaManager_SetLooping(int32 PlayID, bool bLoop)
{
	FKGPlayMediaRecord* RecordPtr = PlayMediaRecords.Find(PlayID);
	if (RecordPtr == nullptr)
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::SetLoop, cannot find PlayID %d"), PlayID);
		return false;
	}

	if (RecordPtr->BinkMediaPlayer == nullptr)
	{
		RecordPtr->bLoop = bLoop;
		return true;
	}

	return RecordPtr->BinkMediaPlayer->SetLooping(bLoop);
}

bool UKGMediaManager::KAPI_MediaManager_SetPlayRate(int32 PlayID, float PlayRate)
{
	FKGPlayMediaRecord* RecordPtr = PlayMediaRecords.Find(PlayID);
	if (RecordPtr == nullptr)
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::SetPlayRate, cannot find PlayID %d"), PlayID);
		return false;
	}

	if (RecordPtr->BinkMediaPlayer == nullptr)
	{
		RecordPtr->PlayRate = PlayRate;
		return true;
	}

	return RecordPtr->BinkMediaPlayer->SetRate(PlayRate);
}

bool UKGMediaManager::KAPI_MediaManager_RewindBinkMedia(int32 PlayID)
{
	FKGPlayMediaRecord* RecordPtr = PlayMediaRecords.Find(PlayID);
	if (RecordPtr == nullptr)
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::RewindBinkMedia, cannot find PlayID %d"), PlayID);
		return false;
	}

	if (RecordPtr->BinkMediaPlayer != nullptr)
	{
		return RecordPtr->BinkMediaPlayer->Rewind();
	}

	// 暂未加载成功, 此时可以认为调用成功
	return true;
}

bool UKGMediaManager::KAPI_MediaManager_StartBinkMedia(int32 PlayID)
{
	FKGPlayMediaRecord* RecordPtr = PlayMediaRecords.Find(PlayID);
	if (RecordPtr == nullptr)
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::PauseBinkMedia, cannot find PlayID %d"), PlayID);
		return false;
	}

	if (RecordPtr->BinkMediaPlayer == nullptr)
	{
		RecordPtr->bStartImmediately = true;
		return true;
	}
	
	if (RecordPtr->PlayRate.IsSet())
	{
		return RecordPtr->BinkMediaPlayer->SetRate(RecordPtr->PlayRate.GetValue());
	}
	
	return RecordPtr->BinkMediaPlayer->Play();
}

bool UKGMediaManager::KAPI_MediaManager_PauseBinkMedia(int32 PlayID)
{
	FKGPlayMediaRecord* RecordPtr = PlayMediaRecords.Find(PlayID);
	if (RecordPtr == nullptr)
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::PauseBinkMedia, cannot find PlayID %d"), PlayID);
		return false;
	}

	if (RecordPtr->BinkMediaPlayer == nullptr)
	{
		RecordPtr->bStartImmediately = false;
		return true;
	}

	return RecordPtr->BinkMediaPlayer->Pause();
}

bool UKGMediaManager::KAPI_MediaManager_SeekByTime(int32 PlayID, double Time)
{
	FKGPlayMediaRecord* RecordPtr = PlayMediaRecords.Find(PlayID);
	if (RecordPtr == nullptr)
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::KAPI_MediaManager_SeekByTime, cannot find PlayID %d"), PlayID);
		return false;
	}

	UE_LOG(LogKGMedia, Log,
		TEXT("UKGMediaManager::KAPI_MediaManager_SeekByTime, %s, Time: %f, PlayID: %d"),
		*RecordPtr->GetDebugInfo(), Time, PlayID);

	if (RecordPtr->BinkMediaPlayer == nullptr)
	{
		RecordPtr->SeekTime = Time;
		RecordPtr->SeekPercent.Reset();
		return true;
	}
	
	return RecordPtr->BinkMediaPlayer->SeekByTime(Time);
}

bool UKGMediaManager::KAPI_MediaManager_SeekByPercent(int32 PlayID, double Percent)
{
	FKGPlayMediaRecord* RecordPtr = PlayMediaRecords.Find(PlayID);
	if (RecordPtr == nullptr)
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::KAPI_MediaManager_SeekByPercent, cannot find PlayID %d"), PlayID);
		return false;
	}
	
	UE_LOG(LogKGMedia, Log,
		TEXT("UKGMediaManager::KAPI_MediaManager_SeekByPercent, %s, Percent: %f, PlayID: %d"),
		*RecordPtr->GetDebugInfo(), Percent, PlayID);

	if (RecordPtr->BinkMediaPlayer == nullptr)
	{
		RecordPtr->SeekPercent = Percent;
		RecordPtr->SeekTime.Reset();
		return true;
	}
	
	return RecordPtr->BinkMediaPlayer->SeekByPercent(Percent);
}

bool UKGMediaManager::KAPI_MediaManager_UpdateMediaMaterialParamLinearSample(int32 PlayID, const FName& ParamName, float StartVal, float EndVal, float Duration)
{
	FKGPlayMediaRecord* RecordPtr = PlayMediaRecords.Find(PlayID);
	if (RecordPtr == nullptr)
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::KAPI_MediaManager_UpdateMediaMaterialParamLinearSample, cannot find PlayID %d"), PlayID);
		return false;
	}

	if (RecordPtr->MaterialInstanceDynamic == nullptr)
	{
		FKGLinearSampleParams<float> Param;
		Param.StartVal = StartVal;
		Param.EndVal = EndVal;
		Param.Duration = Duration;
		RecordPtr->ScalarLinearSampleParams.Add(ParamName, Param);
		return true;
	}
	
	UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(this);
	if (!MaterialManager)
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::KAPI_MediaManager_UpdateMediaMaterialParamLinearSample, cannot find material manager"));
		return false;
	}
	
	const auto TaskID = MaterialManager->AddScalarLinearSampleParamByDynamicMaterialInstance(
		ParamName, RecordPtr->MaterialInstanceDynamic, StartVal, EndVal, Duration, false);
	RecordPtr->MaterialParamUpdateTaskIDs.Add(TaskID);
	return true;
}

void UKGMediaManager::StopBinkMedia(int32 PlayID)
{
	FKGPlayMediaRecord* RecordPtr = PlayMediaRecords.Find(PlayID);
	if (RecordPtr == nullptr)
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::StopBinkMedia, cannot find PlayID %d"), PlayID);
		return;
	}

	UE_LOG(LogKGMedia, Log,
		TEXT("UKGMediaManager::StopBinkMedia, %s, PlayID: %d"),
		*RecordPtr->GetDebugInfo(), PlayID);

	if (RecordPtr->AssetLoadID != 0)
	{
		if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this))
		{
			AssetManager->CancelAsyncLoadByLoadID(RecordPtr->AssetLoadID);
		}
	}
	
	if (RecordPtr->bBinkMediaOldStartImmediately.IsSet())
	{
		RecordPtr->BinkMediaPlayer->StartImmediately = RecordPtr->bBinkMediaOldStartImmediately.GetValue();
	}
	
	if (RecordPtr->BinkMediaPlayer != nullptr)
	{
		RecordPtr->BinkMediaPlayer->Stop();
	}

	if (RecordPtr->ChangeMaterialID != 0 || RecordPtr->ChangeMaterialParamID != 0)
	{
		if (UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(this))
		{
			if (RecordPtr->ChangeMaterialID != 0)
			{
				MaterialManager->RevertMaterial(RecordPtr->ChangeMaterialID);	
			}
			if (RecordPtr->ChangeMaterialParamID != 0)
			{
				MaterialManager->RevertMaterialParam(RecordPtr->ChangeMaterialParamID);	
			}
		}
		else
		{
			UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::StopBinkMedia, cannot find material manager"));
		}
	}

	if (RecordPtr->MaterialParamUpdateTaskIDs.Num() > 0)
	{
		if (UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(this))
		{
			for (const auto TaskID : RecordPtr->MaterialParamUpdateTaskIDs)
			{
				MaterialManager->RemoveMaterialParamUpdateTask(TaskID);
			}
		}
		else
		{
			UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::StopBinkMedia, cannot find material manager"));
		}
	}
	
	const FName MediaPlayerPathName = *RecordPtr->MediaPlayerPath;
	if (MediaPlayerPathToPlayIDs.Contains(MediaPlayerPathName))
	{
		MediaPlayerPathToPlayIDs.Remove(MediaPlayerPathName);	
	}
	PlayMediaRecords.Remove(PlayID);
}

void UKGMediaManager::KAPI_MediaManager_StopBinkMediaByMediaPlayerPath(const FName& MediaPlayerPath)
{
	if (!MediaPlayerPathToPlayIDs.Contains(MediaPlayerPath))
	{
		UE_LOG(LogKGMedia, Warning, TEXT("UKGMediaManager::KAPI_MediaManager_StopBinkMediaByMediaPlayerPath, cannot find media player path record %s"), *MediaPlayerPath.ToString());
		return;
	}

	StopBinkMedia(MediaPlayerPathToPlayIDs[MediaPlayerPath]);
}

void UKGMediaManager::StopAllBinkMedias()
{
	TArray<int32> PlayIDs;
	PlayMediaRecords.GenerateKeyArray(PlayIDs);
	for (const auto PlayID : PlayIDs)
	{
		StopBinkMedia(PlayID);
	}
}

void UKGMediaManager::OnMediaReachEnd(int32 PlayID)
{
	FKGPlayMediaRecord* RecordPtr = PlayMediaRecords.Find(PlayID);
	if (RecordPtr == nullptr)
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::OnMediaReachEnd, cannot find PlayID %d"), PlayID);
		return;
	}

	UE_LOG(LogKGMedia, Log,
		TEXT("UKGMediaManager::OnMediaReachEnd, %s, PlayID: %d"),
		*RecordPtr->GetDebugInfo(), PlayID);

	if (RecordPtr->bBindMediaReachEndCallback)
	{
		CallLuaFunction("KG_OnMediaReachEnd", PlayID);	
	}

	if (RecordPtr->bAutoStop)
	{
		StopBinkMedia(PlayID);
	}
}

int32 UKGMediaManager::GenerateID()
{
	static uint32 MediaPlayId = 1;
	MediaPlayId++;
	if (MediaPlayId >= 0x7fffffff)
	{
		MediaPlayId = 1;
	}

	return MediaPlayId;
}

void UKGMediaManager::InternalPlayBinkMedia(FKGPlayMediaRecord& InOutRecord, int32 PlayID)
{
	UBinkMediaPlayer* BinkMediaPlayer = InOutRecord.BinkMediaPlayer;
	checkf(BinkMediaPlayer != nullptr, TEXT("UKGMediaManager::InternalPlayBinkMedia, invalid BinkMediaPlayer, PlayID: %d"), PlayID);
	
	if (InOutRecord.bStartImmediately.IsSet())
	{
		InOutRecord.bBinkMediaOldStartImmediately = BinkMediaPlayer->StartImmediately;
		BinkMediaPlayer->StartImmediately = InOutRecord.bStartImmediately.GetValue();
	}

	if (InOutRecord.Url.IsSet())
	{
		const bool bOpenResult = BinkMediaPlayer->OpenUrl(InOutRecord.Url.GetValue());
		UE_CLOG(!bOpenResult, LogKGMedia, Error, TEXT("UKGMediaManager::InternalPlayBinkMedia, media URL open failed, MediaPlayerPath: %s, URL: %s"),
			*InOutRecord.MediaPlayerPath, *InOutRecord.Url.GetValue());
	}
	else
	{
		BinkMediaPlayer->InitializePlayer();
	}

	if (InOutRecord.bLoop.IsSet())
	{
		BinkMediaPlayer->SetLooping(InOutRecord.bLoop.GetValue());
	}

	if (InOutRecord.bBindMediaReachEndCallback || InOutRecord.bAutoStop)
	{
		BinkMediaPlayer->OnKGMediaReachedEnd.AddUObject(this, &UKGMediaManager::OnMediaReachEnd, PlayID);
	}

	if (BinkMediaPlayer->StartImmediately)
	{
		if (InOutRecord.PlayRate.IsSet())
		{
			BinkMediaPlayer->SetRate(InOutRecord.PlayRate.GetValue());
		}
		else
		{
			BinkMediaPlayer->Play();
		}	
	}

	if (InOutRecord.SeekTime.IsSet())
	{
		BinkMediaPlayer->SeekByTime(InOutRecord.SeekTime.GetValue());
	}
	else if (InOutRecord.SeekPercent.IsSet())
	{
		BinkMediaPlayer->SeekByPercent(InOutRecord.SeekPercent.GetValue());
	}
}

void UKGMediaManager::OnMediaPlayerLoaded(int InLoadID, UObject* LoadedAsset, int32 PlayID)
{
	UE_LOG(LogKGMedia, Log, TEXT("UKGMediaManager::OnMediaPlayerLoaded, LoadedAsset: %s, PlayID: %d"), *GetNameSafe(LoadedAsset), PlayID);
	
	FKGPlayMediaRecord* RecordPtr = PlayMediaRecords.Find(PlayID);
	if (RecordPtr == nullptr)
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::OnMediaPlayerLoaded, cannot find record, PlayID: %d"), PlayID);
		StopBinkMedia(PlayID);
		return;
	}

	RecordPtr->AssetLoadID = 0;

	UBinkMediaPlayer* LoadedBinkMediaPlayer = Cast<UBinkMediaPlayer>(LoadedAsset);
	if (!LoadedBinkMediaPlayer)
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::OnMediaPlayerLoaded, invalid media player, %s"), *RecordPtr->MediaPlayerPath);
		StopBinkMedia(PlayID);
		return;
	}

	RecordPtr->BinkMediaPlayer = LoadedBinkMediaPlayer;
	InternalPlayBinkMedia(*RecordPtr, PlayID);
}

void UKGMediaManager::OnMaterialAssetLoaded(int InLoadID, UObject* LoadedAsset, int32 PlayID, FName MediaTextureParamName, TWeakObjectPtr<class UImage> ImageWidget)
{
	FKGPlayMediaRecord* RecordPtr = PlayMediaRecords.Find(PlayID);
	if (RecordPtr == nullptr)
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::OnMaterialAssetLoaded, cannot find record, PlayID: %d"), PlayID);
		return;
	}

	RecordPtr->AssetLoadID = 0;
	
	UMaterialInterface* LoadedMaterial = Cast<UMaterialInterface>(LoadedAsset);
	if (!LoadedMaterial)
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::OnMaterialAssetLoaded, invalid material asset, %s"), *RecordPtr->GetDebugInfo());
		return;
	}
	
	if (!ImageWidget.IsValid())
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::OnMaterialAssetLoaded, cannot find image widget by ID %s"), *RecordPtr->GetDebugInfo());
		return;
	}

	UMaterialInstanceDynamic* DynamicMaterial = KGMaterialUtils::CreateDynamicMaterialInstance(LoadedMaterial);
	if (!DynamicMaterial)
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::OnMaterialAssetLoaded, cannot create dynamic material instance, %s"), *RecordPtr->GetDebugInfo());
		return;
	}

	UE_LOG(LogKGMedia, Log, TEXT("UKGMediaManager::OnMaterialAssetLoaded, LoadedMaterial: %s, PlayID: %d"), *LoadedMaterial->GetPathName(), PlayID);

	RecordPtr->MaterialInstanceDynamic = DynamicMaterial;
	RecordPtr->BinkMediaPlayer = NewObject<UBinkMediaPlayer>();
	RecordPtr->BinkMediaTexture = NewObject<UBinkMediaTexture>();
	RecordPtr->BinkMediaTexture->SetMediaPlayer(RecordPtr->BinkMediaPlayer);
	DynamicMaterial->SetTextureParameterValue(MediaTextureParamName, RecordPtr->BinkMediaTexture);
	ImageWidget->SetBrushFromMaterial(DynamicMaterial);

	InternalPlayBinkMedia(*RecordPtr, PlayID);

	if (RecordPtr->ScalarLinearSampleParams.Num() > 0)
	{
		if (UKGMaterialManager* MaterialManager = UKGMaterialManager::GetInstance(this))
		{
			for (const auto& Kvp : RecordPtr->ScalarLinearSampleParams)
			{
				const auto TaskID = MaterialManager->AddScalarLinearSampleParamByDynamicMaterialInstance(
					Kvp.Key, DynamicMaterial, Kvp.Value.StartVal, Kvp.Value.EndVal, Kvp.Value.Duration, false);
				RecordPtr->MaterialParamUpdateTaskIDs.Add(TaskID);
			}
		}
		else
		{
			UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::OnMaterialAssetLoaded, cannot find material manager"));
		}
	}
}

void UKGMediaManager::KAPI_MediaManager_CreateMediaSoundComponent(UMediaPlayer* MediaPlayer, KGObjectID ActorID)
{
	if (!IsValid(MediaPlayer))
	{
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::KAPI_MediaManager_CreateMediaSoundComponent: invalid MediaPlayer"));
		return;
	}
	
	if (AActor* BindedActor = Cast<AActor>(KGUtils::GetObjectByID(ActorID)))
	{
		if (UMediaSoundComponent* ExistingMediaSoundComp = BindedActor->FindComponentByClass<UMediaSoundComponent>())
		{
			ExistingMediaSoundComp->SetMediaPlayer(MediaPlayer);
			return;
		}
		
		UActorComponent* Comp = BindedActor->AddComponentByClass(UMediaSoundComponent::StaticClass(), false, FTransform::Identity, false);
		if (UMediaSoundComponent* MediaSoundComp = Cast<UMediaSoundComponent>(Comp))
		{
			MediaSoundComp->SetMediaPlayer(MediaPlayer);
			return;
		}
		UE_LOG(LogKGMedia, Error, TEXT("UKGMediaManager::KAPI_MediaManager_CreateMediaSoundComponent: Failed to cast Comp to UMediaSoundComponent."));
		return;
	}
	UE_LOG(LogTemp, Warning, TEXT("KAPI_Actor_AddComponentByClassID: ActorID is InValid."));
}

void UKGMediaManager::KAPI_MediaManager_DestroyMediaSoundComponent(KGObjectID ActorID)
{
	if (AActor* BindedActor = Cast<AActor>(KGUtils::GetObjectByID(ActorID)))
	{
		UMediaSoundComponent* TargetComponent = BindedActor->FindComponentByClass<UMediaSoundComponent>();
		if (TargetComponent)
		{
			TargetComponent->DestroyComponent();
			UE_LOG(LogTemp, Log, TEXT("UKGMediaManager::KAPI_MediaManager_CreateMediaSoundComponent: Component successfully destroyed."));
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("UKGMediaManager::KAPI_MediaManager_CreateMediaSoundComponent,: Target component not found."));
		}
	}
}
