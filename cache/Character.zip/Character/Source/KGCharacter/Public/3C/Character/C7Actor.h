#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "3C/Core/C7ActorInterface.h"
#include "3C/Character/LuaActorBase.h"

#include "C7Actor.generated.h"

//所有项目自定义Actor的基类

UCLASS(BlueprintType, Blueprintable, Abstract)
class KGCHARACTER_API AC7Actor : public AActor, public IC7ActorInterface, public LuaActorBase<AC7Actor>
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable)
	const void SetActorType(int v) { ActorType = v; }
	UFUNCTION(BlueprintCallable)
	const int32& GetActorType() {return ActorType;}

	UFUNCTION(BlueprintCallable)
	bool SetCollisionPresetForRootAndMeshComponents(bool updatedateOverlaps, const FName& SceneRoorPresetName, const FName& ChildPresetName);

	UFUNCTION(BlueprintCallable)
	void SetTagFromRootAndMeshComps(const FString& InTag);

	UFUNCTION(BlueprintCallable)
    void SetMinLOD(int32 InNewMinLOD);

	/**
	 * @return 对于非Character单位,返回找到的第一个SkComp
	 */
	UFUNCTION(BlueprintCallable)
	class USkeletalMeshComponent* GetMainMesh() override;

	UFUNCTION(BlueprintCallable)
	class UCapsuleComponent* GetCapsule() override;

	UFUNCTION(BlueprintCallable)
	virtual int64 GetEntityUID() override { return EntityUID; }

	UFUNCTION(Blueprintable)
	virtual void SetEntityUID(int64 InEntityUID) override;

	UFUNCTION(Blueprintable)
	bool EnableLogicFeatureSynchronizeToChildsExposed(int64 logicChildID, int32 stateMask) { return EnableLogicFeatureSynchronizeToChilds(logicChildID, stateMask); }

	UFUNCTION(Blueprintable)
	bool DisableLogicFeatureSynchronizeToChildsExposed(int64 logicChildID, int32 stateMask) { return DisableLogicFeatureSynchronizeToChilds(logicChildID, stateMask); }

	UFUNCTION(Blueprintable)
	bool IsLogicFeatureSynchronizeToChildsExposed(int64 logicChildID, int32 stateMask) { return IsLogicFeatureSynchronizeToChilds(logicChildID, stateMask); }

	UFUNCTION(Blueprintable)
	bool HasLogicChildExposed(int64 logicChildId) { return HasLogicChild(logicChildId); }
	
	UFUNCTION(Blueprintable)
	bool AddAttachToLogicParentExposed(int64 parentLogicId) { return AddAttachToLogicParent(parentLogicId); }

	UFUNCTION(Blueprintable)
	bool RemoveAttachFromLogicParentExposed() { return RemoveAttachFromLogicParent(); }

	UFUNCTION(Blueprintable)
	void RemoveAllLogicChildExposed() { RemoveAllLogicChild(); }

	virtual void BeginPlay() override;

	virtual int64 GetLoigcParent() { return LogicParentActorId; }
	virtual TMap<int64, int32>* GetLogicChildMaskMap() { return &LogicChildObjectIdMapping; }


protected:

	virtual int64* GetLoigcParentInnerForModify() { return &LogicParentActorId; }


	int64 LogicParentActorId = 0;
	// ObjectId: SyncFeatureControlMask
	TMap<int64, int32> LogicChildObjectIdMapping;

	UPROPERTY(BlueprintReadWrite, EditDefaultsOnly)
	int32 ActorType;

	/**
	 * 新ID,遵循和BaseCharacter一样的用法
	 */
	int64 EntityUID;
};
