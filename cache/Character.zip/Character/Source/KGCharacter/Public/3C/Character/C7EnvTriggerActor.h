#pragma once

#include "CoreMinimal.h"
#include "3C/Character/C7Actor.h"
#include "C7EnvTriggerActor.generated.h"

UCLASS(BlueprintType, Blueprintable)
class KGCHARACTER_API AC7EnvTriggerActor : public AC7Actor
{
	GENERATED_BODY()

public:
	AC7EnvTriggerActor();

protected:
	virtual void BeginPlay() override;

	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	TObjectPtr<class UC7ShapeCollisionComponent> ShapeCollision = nullptr;
};
