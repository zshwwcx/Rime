#pragma once
#include "Engine/DecalActor.h"
#include "TypeDefines/LuaTypes.h"

#include "C7DecalActor.generated.h"

class UKGMaterialManager;
class UKGCombatUnitManager;
class UKGUEActorManager;
class UKGCppAssetManager;
class UTexture;


USTRUCT()
struct FKGDecalTextureParamLoadInfo
{
	GENERATED_BODY()

	UPROPERTY()
	UTexture* Texture = nullptr;

	FString TexturePath;
	int LoadID = 0;
};

UCLASS(Blueprintable, BlueprintType)
class AC7DecalActor : public ADecalActor
{
	GENERATED_BODY()

public:
	AC7DecalActor(const FObjectInitializer& ObjectInitializer);
	~AC7DecalActor() {}

	virtual void Tick(float DeltaSeconds) override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	
	bool InitParamsByTemplate(
		const FKGDecalConfigData& InDecalConfigData, TWeakObjectPtr<UKGUEActorManager> InActorManager, TWeakObjectPtr<UKGCombatUnitManager> InCombatUnitManager,
		KGEntityID InSpawnerEntityID, KGEntityID InInstigatorEntityID, 
		const FTransform& InTransform, EDecalPositionMode InPosMode, EDecalRotationMode InRotMode, const FName& InAttachBoneName, bool bInAbsoluteScale, float DecalSizeX,
		bool bInUseColor, float ColorR, float ColorG, float ColorB, float ColorA,
		bool bInUseGlowColor, float GlowColorR, float GlowColorG, float GlowColorB, float GlowColorA,
		bool bInNeedCheckGround, float InFadeInTimeSeconds, float InFadeOutTimeSeconds, float InLifeTimeSeconds, float InDissolveTimeSeconds,
		EDecalShapeType InShapeType, float InLength, float InWidth, float InAngle, float InRadius,
		float InInnerRadius, float InOuterRadius, float InFillingDuration, const FString& FillCurvePath, bool bLoopControl,
		EDecalPointAtTargetType PointAtTargetType, EDecalRecFillMode InRecFillMode, EDecalCircleLikeFillMode InCircleLikeFillMode,
		EDecalRecDissolveMode RecDissolveMode, EDecalCircleLikeDissolveMode CircleLikeDissolveMode);
	bool InitParamsCustomized(
		KGEntityID InSpawnerEntityID, TWeakObjectPtr<UKGUEActorManager> InActorManager, TWeakObjectPtr<UKGCombatUnitManager> InCombatUnitManager, KGEntityID InInstigatorEntityID,
		const FString& InMaterialPath, float DecalSizeX, float DecalSizeY, float DecalSizeZ, 
		EDecalPositionMode InPosMode, EDecalRotationMode InRotMode, const FName& AttachBoneName, bool bAbsoluteScale, bool bNeedCheckGround, const FTransform& InTransform,
		float InFadeInTimeSeconds, float InFadeOutTimeSeconds, float InLifeTimeSeconds, float InDissolveTimeSeconds,
		bool bOverrideAngle, float Angle, bool bOverrideInnerRadius, float InnerRadius, bool bOverrideOuterRadius, float OuterRadius,
		bool bOverrideControl, EDecalParamModifyType ControlModifyType, float ConstControlValue, float ControlDuration, const FString& InControlCurvePath,
		bool bLoopControl, EDecalPointAtTargetType PointAtTargetType);
	bool InitParamsByDecalSpawnParams(const struct FKGSimpleDecalSpawnParams& Params,
		TWeakObjectPtr<UKGUEActorManager> InActorManager, TWeakObjectPtr<UKGCombatUnitManager> InCombatUnitManager);
	
	void EnterWorld();
	void ExitWorld();
	bool FadeOut();
	void StartDissolve();

	void SetTextureMaterialParam(const FName& ParamName, const FString& TexturePath);
	void SetVectorMaterialParam(const FName& ParamName, const FLinearColor& Value);
	void SetFloatMaterialParam(const FName& ParamName, float Value);
	void SetDecalSize(float SizeX, float SizeY, float SizeZ);
	void SetAbsolute(bool bNewAbsoluteLocation, bool bNewAbsoluteRotation, bool bNewAbsoluteScale);
	KGActorID GetActorID();
	
	KGEntityID GetSpawnerEntityID() const { return SpawnerEntityID; }

	void SetDecalInstID(uint32 InDecalInstID) { DecalInstID = InDecalInstID; }
	uint32 GetDecalInstID() const { return DecalInstID; }

	void SetDecalHiddenInGame(bool bHiddenDecal, EKGDecalHiddenReason Reason);
	
protected:

	void UpdateDecalTransform(
		EDecalPositionMode InPosMode, EDecalRotationMode InRotMode, const FName& InAttachBoneName, bool bInAbsoluteScale, bool bInNeedCheckGround, const FTransform& InTransform);
	bool CalculateDecalSpawnTransform(EDecalPositionMode InPosMode, EDecalRotationMode InRotMode, const FTransform& InTransform, const FName& InAttachBoneName, FTransform& OutTransform);
	void TryFitGround(FTransform& OutTransform);
	AActor* GetSpawnerActor();
	void OnMaterialLoaded(int InLoadID, UObject* LoadedAsset, bool bAsyncAssetLoadCallback);
	void SetDecalPointAtInstigator();
	void OnLifeTimeExpired();
	void OnFadeOutTimeExpired();
	void ChangeMaterialParams();
	void OnTextureLoaded(int InLoadID, UObject* LoadedAsset, FName ParamName);
	bool UpdateAndCacheManagers();
	FString GetDebugInfo() const;
	
	FString MaterialPath;
	FVector DecalSize = FVector::OneVector;

	KGEntityID InstigatorEntityID = KG_INVALID_ENTITY_ID;
	KGEntityID SpawnerEntityID = KG_INVALID_ENTITY_ID;
	uint32 DecalInstID = 0;

	float FadeInTimeSeconds = 0.0f;
	float FadeOutTimeSeconds = 0.0f;
	float OpacityStartVal = 0.0f;
	float OpacityEndVal = 1.0f;
	uint32 OpacityChangeTaskID = 0;
	float LifeTimeSeconds = 1.0f;
	float FillingDuration = 0.0f;
	FString ControlCurvePath;
	bool bLoopControl = false;
	float DissolveTimeSeconds = 0.0f;
	EDecalPointAtTargetType PointAtTargetType = EDecalPointAtTargetType::None;

	EDecalPositionMode PosMode = EDecalPositionMode::Init;
	EDecalRotationMode RotMode = EDecalRotationMode::Init;
	FTransform DeltaTransform = FTransform::Identity;
	FName AttachBoneName = NAME_None;

	// 动态状态参数
	bool bAssetLoaded = false;
	int32 AssetLoadID = 0;
	bool bPointAtInstigator = false;
	FTimerHandle LifeTimerHandle;
	FTimerHandle DissolveTimerHandle;
	FTimerHandle FadeOutTimerHandle;
	bool bHasExitWorld = false;
	bool bShouldStartDissolve = false;

	TMap<FName, float> DynamicMaterialFloatParams;
	TMap<FName, FLinearColor> DynamicMaterialColorParams;
	UPROPERTY()
	TMap<FName, FKGDecalTextureParamLoadInfo> DynamicMaterialTextureParams;

	TArray<uint32> TickTaskIDs;

	TSet<EKGDecalHiddenReason> HiddenReason;
	
	TWeakObjectPtr<AActor> SpawnerActorPtr;
	TWeakObjectPtr<UKGUEActorManager> ActorManager;
	TWeakObjectPtr<UKGCombatUnitManager> CombatUnitManager;
	TWeakObjectPtr<UKGMaterialManager> MaterialManager;
	TWeakObjectPtr<UKGCppAssetManager> AssetManager;
};