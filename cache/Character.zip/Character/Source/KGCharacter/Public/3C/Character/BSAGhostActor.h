#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/PoseableMeshComponent.h"
#include "Misc/CommonDefines.h"

#include "3C/Core/C7ActorInterface.h"

#include "BSAGhostActor.generated.h"


UCLASS(Blueprintable, BlueprintType)
class KGCHARACTER_API ABSAGhostActor : public AActor, public IC7ActorInterface {
	GENERATED_BODY()

#pragma region Important

public:
	ABSAGhostActor(const FObjectInitializer& ObjectInitializer);

	~ABSAGhostActor();

	virtual void BeginPlay() override;


#pragma endregion Important


#pragma region Core

public:

	UFUNCTION(BlueprintCallable)
	void ClearRecord();

#pragma endregion Core


	UFUNCTION(Blueprintable)
	USceneComponent* GetSceneComponent();

	UFUNCTION(Blueprintable)
	USkeletalMeshComponent* GetSkeletalMeshComp();

	UFUNCTION(Blueprintable)
	UPoseableMeshComponent* GetPoseableMeshComp();

	UFUNCTION(Blueprintable)
	UStaticMeshComponent* GetStaticMeshComp();


	UFUNCTION(BlueprintCallable)
	class USkeletalMeshComponent* GetMainMesh() override;
	

	void PlayPosFromAnimation(KGObjectID CreatorID, bool bInLODSameAsCreator, KGObjectID AnimAssetID, bool bLoop, bool bCopyMaterialParams=false);

	void CopyPoseFromCreator(KGObjectID CreatorID, bool bInLODSameAsCreator, bool bInUseSkeletalMesh=false, bool bCopyMaterialParams=false);

	void CreateGhostMesh(AActor* InSourceActor);

	void CreateSceneComponent(USceneComponent* InSourceComponent);


protected:
	
	void CopyMaterialParams(UMeshComponent* SourceComponent, UMeshComponent* TargetComponent);
	
	// 正在使用的SceneComponent对象列表
	UPROPERTY(Transient)
	TArray<USceneComponent*> SceneCompList;

	// 正在使用的骨骼模型对象列表
	UPROPERTY(Transient)
	TArray<USkeletalMeshComponent*> SkeletalMeshList;

	// 正在使用的Pose模型对象列表
	UPROPERTY(Transient)
	TArray<UPoseableMeshComponent*> PoseableMeshList;

	// 正在使用的静态模型对象列表
	UPROPERTY(Transient)
	TArray<UStaticMeshComponent*> StaticMeshList;

	UPROPERTY(Transient)
	TMap<USceneComponent*, USceneComponent*> GhostCompToSpawnerComp;

	UPROPERTY(Transient)
	TMap<USceneComponent*, USceneComponent*> SpawnerCompToGhostComp;

	bool bUseSkeletalMesh = false;
	bool bCopyMaterialParams = false;

	bool bLODSameAsCreator = false;

public:
	UFUNCTION(BlueprintCallable)
	virtual int64 GetEntityUID() override { return EntityUID; }

	UFUNCTION(Blueprintable)
	virtual void SetEntityUID(int64 InEntityUID) override { EntityUID = InEntityUID; }

	int64 EntityUID = 0;

};
