// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "LuaOverriderInterface.h"
#include "3C/Character/C7Actor.h"
#include "BSForewarnActor.generated.h"

UCLASS(Abstract, BlueprintType, Blueprintable)
class KGCHARACTER_API ABSForewarnActor : public AC7Actor
{
	GENERATED_BODY()
public:
	ABSForewarnActor(const FObjectInitializer& ObjectInitializer);
};