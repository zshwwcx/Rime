#pragma once

#include "CoreMinimal.h"
#include "Engine/EngineTypes.h"
#include "GameFramework/Actor.h"
#include "3C/Movement/MovementSynchronization.h"
#include "3C/Character/C7Actor.h"
#include "BriefCharacter.generated.h"

/**
 * Brief角色类 @hujianglong
 * 只有一个功能：接收网络位置更新，更新血条位置
 * todo 目前的更新方案并不是最优的，最优的方式是设计单列模式，接受所有Brief的位置信息，直接设置WorldWidget的位置
*/

UCLASS(BlueprintType, Blueprintable)
class KGCHARACTER_API ABriefCharacter : public AC7Actor
{
	GENERATED_UCLASS_BODY()
	
protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

public:
    virtual void Tick(float DeltaTime) override;
	virtual bool IsBriefActor() override;
	virtual const FTransform* GetBriefActorTransform() const override { return &BriefTransform;}
	void SetBriefActorLocation(const FVector& InLocation) { BriefTransform.SetLocation(InLocation);};
	
	UFUNCTION(BlueprintCallable)
	void SetTickInterval(float TickInterval);

	void OnReceiveMovementData(MovementData &&Data);
    void ReceiveSetLocation(float X, float Y, float Z);

private:
	FTransform BriefTransform = FTransform::Identity;

	FMovementSimulator MovementSimulator;
};
