﻿#pragma once

#include "CoreMinimal.h"
#include "3C/Core/KGTimeDilationTimer.h"
#include "3C/Character/C7Actor.h"
#include "TypeDefines/LuaTypes.h"

#include "BulletActor.generated.h"

class UAttackCollisionComponent;
class UKGAkAudioManager;
class UKGEffectManager;

#define KG_ENABLE_BULLET_DRAW_DEBUG (!UE_BUILD_SHIPPING && !UE_BUILD_TEST)
#define KG_INVALID_BULLET_INST_ID (0)

UCLASS(Blueprintable, BlueprintType)
class ABulletActor : public AC7Actor
{
	GENERATED_BODY()

public:
	ABulletActor(const FObjectInitializer& ObjectInitializer);
	~ABulletActor() {}

	static bool CalculateSpawnTransform(
		UKGUEActorManager* ActorManager, const FBulletData& InBulletData, KGEntityID LauncherID, KGEntityID TargetID,
		const FVector& StartPos, const FRotator& StartRot, const FVector& ServerPosOffset,
		const FRotator& ServerRotOffset, EKGBulletOffsetMode OffsetMode, FTransform& OutTransform, bool bInALSAiming = false);

	virtual void PostInitializeComponents() override;
	virtual void Tick(float DeltaSeconds) override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	
	void InitParams(
		const FBulletData& InBulletData, KGEntityID InLauncherID, KGEntityID InInstigatorID, KGEntityID InTargetID, float InLifeTimeSeconds,
		const FVector& InTargetPosFromServer, const FVector& InStartPos, const FRotator& InStartRot, float InDestroyNiagaraLifeTimeSeconds,
		uint64 InInstID, int32 InBulletAudioFadeTimeMS);
	void EnterWorld();
	void ExitWorld(EKGBulletDestroyReason DestroyReason);

	void LoseTarget();
	uint64 GetInstID() const { return InstID; }
	KGEntityID GetInstigatorID() const { return InstigatorID; }

	// 使用自身的tick来累计子弹生命周期时间, 以应对完美闪避等时间膨胀效果
	void StartTimeDilationEffect(bool bInUseTimeDilation);
	void TryInheritTimeDilationEffect();
	
	void UpdateHiddenState(bool bNewHidden);
	
protected:

	int32 PlayNiagaraEffect(const FBulletEffectData& EffectData, float InLifeTimeSeconds, EKGBulletNiagaraFollowType FollowType, bool bDestroyWhenSpawnerExitWorld);
	int32 PlayAudio(const FString& AudioName, bool bPostOnActor);
	void StartBulletPerformance();
	void UpdateActorTickState();
	bool ShouldTickActor() const;

	void OnLifeTimerExpired();
	
	void LaunchBullet_Direction();
	void LaunchBullet_Line();
	void LaunchBullet_Missile();
	void LaunchBullet_MissileNoMiss();
	void LaunchBullet_Parabola();
	void LaunchBullet_ParabolaWithTrack();
	void LaunchBullet_Round();

	void StartPerfectDodgeCheck();
	
	FString GetDebugInfo() const;
	
	FBulletData BulletData;
	float LifeTimeSeconds = 0.0f;
	FVector StartPos = FVector::ZeroVector;
	FRotator StartRot = FRotator::ZeroRotator;
	FVector TargetPosFromServer = FVector::ZeroVector;
	float DestroyNiagaraLifeTimeSeconds = 1.0f;
	int32 BulletAudioFadeTimeMS = 600;
	KGEntityID InstigatorID = KG_INVALID_ENTITY_ID;
	KGEntityID LauncherID = KG_INVALID_ENTITY_ID;
	KGEntityID TargetID = KG_INVALID_ENTITY_ID;
	uint64 InstID = KG_INVALID_BULLET_INST_ID;
	
	int32 FireAudioPlayingID = 0;
	int32 FadeAudioPlayingID = 0;

	UPROPERTY()
	FKGTimeDilationTimer DelayPerformTimer;
	UPROPERTY()
	FKGTimeDilationTimer LifeTimer;
	bool bUseTimeDilation = false;
	
	TWeakObjectPtr<UKGEffectManager> EffectManagerPtr;
	TWeakObjectPtr<UKGAkAudioManager> AkAudioManagerPtr;
	TWeakObjectPtr<UKGUEActorManager> ActorManagerPtr;
	int32 TrailEffectID = 0;

	bool bHasExitWorld = false;
	bool bHasTarget = false;
	
	UPROPERTY()
	UAttackCollisionComponent* AttackCollisionComponent = nullptr;
	
	UPROPERTY()
	TObjectPtr<class USimpleMovementComponent> SimpleMovementComponent = nullptr;
	
	UPROPERTY(Transient)
	TObjectPtr<class UAkComponent> AkComponent = nullptr;
};
