#pragma once

#include "CoreMinimal.h"
#include "3C/Core/KGUEActorManager.h"
#include "slua.h"
#include "ICppEntity.h"

template<typename Derived>
class LuaActorBase
{
public:
	LuaActorBase() {
		static_assert(std::is_base_of_v<UObject, Derived>);
	}
	template<class ...ARGS>
	void CallLuaEntity(UObject* Self, KGEntityID EntID, const FString& FunctionName, ARGS&& ...Args) {
		const auto Buff = StringCast<ANSICHAR>(*FunctionName);
		CallLuaEntity<void>(Self, EntID, Buff.Get(), std::forward<ARGS>(Args)...);
	}

	template<class ...ARGS>
	void CallLuaEntity(UObject* Self, KGEntityID EntID, const char* FunctionName, ARGS&& ...Args) {
		CallLuaEntity<void>(Self, EntID, FunctionName, std::forward<ARGS>(Args)...);
	}

	template<class RET, class ...ARGS>
	RET CallLuaEntity(UObject* Self, KGEntityID EntID, const FString& FunctionName, ARGS&& ...Args) {
		const auto Buff = StringCast<ANSICHAR>(*FunctionName);
		return CallLuaEntity(Self, EntID, Buff.Get(), std::forward<ARGS>(Args)...);
	}

	template<class RET, class ...ARGS>
	RET CallLuaEntity(UObject* Self, KGEntityID EntID, const char* FunctionName, ARGS&& ...Args) {
		auto Mgr = UKGUEActorManager::GetInstance(Self);
		if (!Mgr) {
			return RET();
		}

		auto Ent = Mgr->GetLuaEntity(EntID);
		if (!Ent) {
			return RET();
		}

		return Ent->GetLuaEntityBase()->CallLuaFunction(FunctionName, std::forward<ARGS>(Args)...);
	}
};

#define CALL_LUA_ENTITY(FUNC, ...) CallLuaEntity(Cast<UObject>(this), GetEntityUID(), FUNC, ##__VA_ARGS__)
#define ACTOR_CALL_LUA_ENTITY(ACTOR, FUNC, ...) ACTOR->CallLuaEntity(Cast<UObject>(ACTOR), ACTOR->GetEntityUID(), FUNC, ##__VA_ARGS__)
   