#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "LuaOverriderInterface.h"
#include "3C/Character/BaseCharacterInternal.h"
#include "3C/Character/LuaActorBase.h"
#include "3C/Debug/SceneDrawerInterface.h"
#include "Misc/CommonDefines.h"
#include "3C/Animation/AnimNotify/AnimNotify_C7CommonStruct.h"
#include "Misc/Optional.h"

#include "BaseCharacter.generated.h"

/**
 * 角色基类
 */

class USceneDrawerSubsystem;
class UBaseAnimInstance;
class UKGPlatformScalabilitySettings;
class UBlobShadowComponent;

#if UE_BUILD_DEVELOPMENT
struct KGCHARACTER_API FActorDebugSwitchConfig
{
	bool bIsShowDriveYaw = false;
	bool bIsShowActorCoordinate = false;
	bool bIsShowMoveSyncHistory = false;
	bool bIsShowRootMotionDeltaData = false;
};
#endif

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FBaseCharacterLODChanged, class ABaseCharacter*, Character, int32, NewLOD);

UCLASS(BlueprintType, Blueprintable)
class KGCHARACTER_API ABaseCharacter : public ABaseCharacterInternal, public LuaActorBase<ABaseCharacter>
{
	GENERATED_UCLASS_BODY()

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void Tick( float DeltaSeconds ) override;
	virtual void MoveBlockedBy(const FHitResult& Impact);
	virtual bool ProcessConsoleExec(const TCHAR* Cmd, FOutputDevice& Ar, UObject* Executor) override;
	
public:
	virtual void FaceRotation(FRotator NewControlRotation, float DeltaTime = 0.f) override;
	virtual void PostInitializeComponents() override;
	virtual void SetActorHiddenInGame(bool bNewHidden) override;

	UFUNCTION(BlueprintCallable)
	UActorComponent* RegisterComponentByClass(const TSubclassOf<UActorComponent> ComponentClass, FName Tag = NAME_None);

	UFUNCTION(BlueprintCallable)
	virtual bool GetVirtualSocketLocation(const int64& SocketID, FVector& OutLocation) override;

	UFUNCTION(BlueprintCallable)
	void ResetToDefaultsForCache();

	virtual void AddMovementInput(FVector WorldDirection, float ScaleValue = 1.0f, bool bForce = false);
#pragma region Ragdoll
public:
	UPROPERTY(EditAnywhere, Category = "ALS|Ragdoll System")
	bool bDebugRagdollVelocity = false;
		
	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent, Category = "ALS|Ragdoll System")
	UAnimMontage* GetGetUpAnimation(bool bRagdollFaceUpState);
	
	UPROPERTY(BlueprintReadOnly, Category = "ALS|Ragdoll System")
	bool bRagdollOnGround = false;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Ragdoll System")
	bool bRagdollFaceUp = false;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Ragdoll System")
	FVector LastRagdollVelocity = FVector::ZeroVector;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Ragdoll System")
	FVector TargetRagdollLocation = FVector::ZeroVector; 

	bool bPreRagdollURO = false;
	bool bIsRagDoll = false;
	
	UFUNCTION(BlueprintCallable, Category = "ALS|Ragdoll System")
	virtual void RagdollStart(FVector ImpactImpulse);

	UFUNCTION(BlueprintCallable, Category = "ALS|Ragdoll System")
	virtual void RagdollEnd();
	
	virtual void RagdollUpdate(float DeltaTime);
	
	virtual void SetActorLocationDuringRagdoll(float DeltaTime);
	
#pragma endregion Ragdoll
protected:
	UFUNCTION(BlueprintImplementableEvent)
	void OnMoveBlockedBy(const FHitResult& Impact);

	//命令行
	UFUNCTION(BlueprintImplementableEvent)
	void OnProcessConsoleExec(const FString& Cmd);
	
	UFUNCTION(BlueprintImplementableEvent)
	void OnPostInitializeComponents();

protected:
	UFUNCTION(BlueprintImplementableEvent)
	FString GetPropEnityID();

	UFUNCTION(BlueprintImplementableEvent, BlueprintPure)
	bool IsDefaultCharacter();

public:
	UFUNCTION(BlueprintCallable)
	void UpdateInvalidateCachedBounds();

public:
	UPROPERTY(EditAnywhere, Category="Base Character")
	uint8 bCustomLockPitch:1;

	UPROPERTY(EditAnywhere, Category="Base Character")
	uint8 bCustomLockYaw:1;

	UPROPERTY(EditAnywhere, Category="Base Character")
	uint8 bCustomLockRoll:1;

public:
	UFUNCTION(BlueprintCallable)
	virtual int64 GetEntityUID() override { return EntityUID; }

	UFUNCTION(BlueprintCallable)
	virtual void SetEntityUID(int64 InEntityID) override;

private:
	int64 EntityUID = 0;


#pragma region Common
public:
	void SetIsHiddenWithChildActor(bool bNewHidden) { bHiddenWithChildActor = bNewHidden; }
	bool GetIsHiddenWithChildActor() { return bHiddenWithChildActor; }
protected:
	UPROPERTY(BlueprintReadWrite, Transient)
	int32 ActorType = 0;
	
	UPROPERTY(BlueprintReadWrite, Transient)
    bool InScreen = true;

	UPROPERTY(BlueprintReadWrite, Transient)
	int32 AppearanceChangeCount = 0;

	UPROPERTY(BlueprintReadWrite, Transient)
	bool bHiddenWithChildActor = false;
	
public:
	TMap<FName,TSet<int64>> MainMeshKawaiiAlphaEnableMap;

	TMap<FName, float> MainMeshKawaiiWindScaleMap;
	
	UPROPERTY(BlueprintReadWrite, Transient)
	bool bIsLocalAIPawn = false;
	
public:
	bool IsLocallyControlled() const override;
	
	UFUNCTION(BlueprintCallable)
	int32 GetActorType() const;
	
	UFUNCTION(BlueprintCallable)
	void SetActorType(int32 v) { ActorType = v; }
	
	UFUNCTION(BlueprintCallable)
	bool IsInScreen() override { return InScreen;}
	
	UFUNCTION(BlueprintCallable)
	void SetIsLocalAIPawn(bool InIsLocalAIPawn);

	UFUNCTION(BlueprintCallable)
	void SetCharacterRotation(FRotator NewRotator, bool bTeleportPhysics);

	UFUNCTION(BlueprintCallable)
	void SetCharacterMeshRotation(FRotator NewRotator, bool bSweep, FHitResult& SweepHitResult, bool bTeleport);

	UFUNCTION(BlueprintCallable)
	FRotator GetCharacterMeshRotation();

	UFUNCTION(BlueprintCallable)
	FTransform GetCharacterMeshRelativeTransform();

	UFUNCTION(BlueprintCallable)
	FVector GetCharacterMeshLocation();

	UFUNCTION(BlueprintCallable)
	void SetInScreen(bool Value) {InScreen = Value;}

	UFUNCTION(BlueprintCallable)
    void SetMainMeshKawaiiAlphaKeys(const int64& MeshComID, const TArray<FName>& KawaiiAlphaEnableArray, bool Enable, float WindScale);

	UFUNCTION(BlueprintCallable)
	void SetAppearanceChangeCount(int32 value) { AppearanceChangeCount = value;}

	UFUNCTION(BlueprintCallable)
	int32 GetAppearanceChangeCount() { return AppearanceChangeCount;}

	UFUNCTION(BlueprintCallable)
	void EnableBoneMask(bool Enable);

	UFUNCTION(BlueprintCallable)
	void SetMainMeshForceLod(int32 lod);

#pragma endregion Common

#pragma region ActorDebug
public:
	UFUNCTION(BlueprintImplementableEvent)
	bool UpdateScriptGameplayDebugInfo(FString& InfoTextStr);

#if WITH_EDITOR
	UFUNCTION(BlueprintImplementableEvent)
	bool GetEntityIDFromLua(FString& EntityIDStr);


	virtual bool ShouldTickIfViewportsOnly() const { return true; };
#endif

#pragma endregion ActorDebug

#if UE_BUILD_DEVELOPMENT
	static ISceneDrawerInterface* SceneDrawerTool;
	
	static TMap<TWeakObjectPtr<AActor>, FActorDebugSwitchConfig> ActorDebugConfigMap;

	static void SetSceneDrawerTool(ISceneDrawerInterface* InTool) { SceneDrawerTool = InTool; }

	static ISceneDrawerInterface* GetSceneDrawerTool() { return SceneDrawerTool; }
	
	static bool IsShowMoveSyncHistoryInConfig(AActor* actor) {
		if (!ABaseCharacter::ActorDebugConfigMap.Contains(actor)) {
			return false;
		}

		return ABaseCharacter::ActorDebugConfigMap[actor].bIsShowMoveSyncHistory;
	}
	static bool IsShowRootMotionDeltaDataInConfig(AActor* actor) {
		if (!ABaseCharacter::ActorDebugConfigMap.Contains(actor)) {
			return false;
		}

		return ABaseCharacter::ActorDebugConfigMap[actor].bIsShowRootMotionDeltaData;
	}
#endif //  UE_BUILD_DEVELOPMENT

#pragma region PathFollow
public:
	// 角色的寻路组件
	UPROPERTY(VisibleDefaultsOnly)
	TObjectPtr<class UC7PathFollowComponent> PathFollowingComponent = nullptr;


public:
	// 向目标Actor寻路(返回值对应EPathFollowingRequestResult::Type，直接使用会有引用错误待排查)
	UFUNCTION(BlueprintCallable)
	int32 PathFollowToActor(FAIRequestID& RequestID, const AActor* Goal, float AcceptanceRadius, bool bFindPath);

	// 向目标地点寻路(返回值对应EPathFollowingRequestResult::Type，直接使用会有引用错误待排查)
	UFUNCTION(BlueprintCallable)
	int32 PathFollowToLocation(FAIRequestID& RequestID, const FVector& GoalLocation, float AcceptanceRadius, bool bFindPath);

	// 暂停寻路
	UFUNCTION(BlueprintCallable)
	bool PausePathFollow(struct FAIRequestID RequestToPause);

	// 暂停状态恢复寻路
	UFUNCTION(BlueprintCallable)
	bool ResumePathFollow(struct FAIRequestID RequestToResume);

	// 停止寻路
	UFUNCTION(BlueprintCallable)
	void StopPathFollow();

	FVector FindValidPathFollowStartLoc();

protected:
	void OnPathFollowCompleted(struct FAIRequestID RequestID, const struct FPathFollowingResult& Result);

#pragma region MoveGoalOffset
public:
	//~ Begin INavAgentInterface Interface
	virtual FVector GetMoveGoalOffset(const AActor* MovingActor) const override;
	//~ End INavAgentInterface Interface

	UFUNCTION(BlueprintCallable)
	void SetMoveGoalOffsetMap(int64 InActorID, float InOffsetX, float InOffsetY, float InOffsetZ);

	UFUNCTION(BlueprintCallable)
	void ClearMoveGoalOffsetMap(int64 InActorID);

	UFUNCTION(BlueprintCallable)
	void ResetMoveGoalOffsetMap() { MoveGoalOffsetMap.Empty(); }



	void SetKeepingPahthFollowInfo(KGObjectID PathFollowTargetID, float InX, float InY, float InZ, float InGap);

	UFUNCTION(BlueprintCallable)
	void ResetKeepingPahthFollowInfo();

	UFUNCTION(BlueprintCallable)
	void StartRestartCheck();

	UFUNCTION(BlueprintCallable)
	void StopRestartCheck();

	UFUNCTION(BlueprintCallable)
	void StartChaseVelocityCheck(float InMinChaseSpeed, float InDefaultChaseSpeed, float InVelocitySuitGap, float InKeepingPathFollowAcceptanceRadius);

	UFUNCTION(BlueprintCallable)
	void StopChaseVelocityCheck();

	void StartSimpleFollow(KGObjectID PathFollowTargetID, float InnerRadius, float OuterRadius, float OffsetX, float OffsetY, float OffsetZ, bool bEnableFrameStickGround);

	UFUNCTION(BlueprintCallable)
	void StopSimpleFollow();

private:
	TMap<TWeakObjectPtr<AActor>, FVector> MoveGoalOffsetMap;
#pragma endregion MoveGoalOffset

#pragma endregion PathFollow

#pragma region StickGround
public:
	// 执行角色贴地的简单接口，返回值代表贴地是否成功
	UFUNCTION(BlueprintCallable)
	bool SimpleSetActorStickGround();
	bool SimpleSetActorStickGroundWithCheckDistance(float CheckDistance);

	// 使用角色的碰撞预设,获取某个点位的贴地位置,贴地失败就返回原位置
	FVector SimpleGetStickGroundLocationFromSpecificLocation(const FVector& InLocation);
	bool SimpleGetAndCheckStickGroundLocationFromSpecificLocation(const FVector& InLocation, FVector& OutInLocation);
	FVector GetStickGroundLocationFromSpecificLocationCheckDistance(const FVector& InLocation, const float& InCheckDistance);
	bool GetAndCheckStickGroundLocationFromSpecificLocationCheckDistance(const FVector& InLocation, FVector& OutInLocation, const float& InCheckDistance);

	// 检查角色是否贴地的方法，返回值代表贴地是否成功，OutStickGroundLoc表示计算出的贴地位置
	UFUNCTION(BlueprintCallable)
	bool SimpleCheckActorStickGround(FVector& OutStickGroundLoc, float CheckDistance);

	// 检查角色是否贴地的方法，返回值代表贴地是否成功，OutStickGroundLoc表示计算出的贴地位置
	bool CheckActorStickGround(const FName& InPresetName, float CheckDistance, FVector& OutStickGroundLoc, const FVector* SpecificLoc = nullptr, const bool bUseComplex = true, const float RadiusRatio = 0.5f);

public:
	bool SimpleCheckCollisionBetweenMoveDelta2D(FVector& OutMoveDelta, const FVector& InMoveDelta);

public:
	void SetFurtherLiftDist(float InFurtherLiftDist) { FurtherLiftDist = InFurtherLiftDist; }
	void SetMaxStickGroundLiftDist(float InMaxStickGroundLiftDist) { MaxStickGroundLiftDist = InMaxStickGroundLiftDist; }
	void ClearMaxStickGroundLiftDist() { MaxStickGroundLiftDist.Reset(); }
private:
	// 插入地面时，额外抬升检查的高度
	float FurtherLiftDist = 20.0f;
	// 贴地检查最多允许的抬升距离，超过这个距离视为贴地失败
	TOptional<float> MaxStickGroundLiftDist;

	bool CheckComplexActorStickGround(FVector& OutStickGroundLoc, const FVector& CheckLocation, float CheckDistance, const ECollisionChannel& TraceChannel, float PawnRadius, float PawnHalfHeight, const FCollisionQueryParams& QueryParams, const FCollisionResponseParams& ResponseParam);
	bool CheckSimpleActorStickGround(FVector& OutStickGroundLoc, const FVector& CheckLocation, float CheckDistance, const ECollisionChannel& TraceChannel, float PawnHalfHeight, const FCollisionQueryParams& QueryParams, const FCollisionResponseParams& ResponseParam);

#if UE_BUILD_DEVELOPMENT
	FString GetHitResCompName(FHitResult& InHitRes);
#endif //UE_BUILD_DEVELOPMENT

private:
	// 缓存一些贴地检查需要的参数
	FName CachedCollisionPresetName = FName(NAME_None);
	TOptional<FCollisionResponseTemplate> CachedStickGroundCollisionProfile;
	TOptional<FCollisionQueryParams> CachedStickGroundQueryParams;
	TOptional<FCollisionResponseParams> CachedStickGroundCollisionResponseParams;
	TOptional<ECollisionChannel> CachedStickGroundCollisionChannel;
#pragma endregion StickGround

#pragma region Effect
public:
	bool CheckAnimStateCondition(const FAnimNotifyOnSurface& AnimNotifyOnSurface);
	int32 SpawnSurfaceEffect(const FAnimNotifyOnSurface& AnimNotifyOnSurface, USkeletalMeshComponent* MeshComp);
	void SetFootEffectPath(const FString& LeftFootEffectPath, const FString& RightFootEffectPath)
	{
		CurrentLeftFootEffectPath = LeftFootEffectPath;
		CurrentRightFootEffectPath = RightFootEffectPath;
	}
	
	FString CurrentLeftFootEffectPath;
	FString CurrentRightFootEffectPath;
	TMap<FName, double> SurfaceEffectCdMap;

	void ChangeModelColor(const FString& ModelName, const FString& ColorName);
	void RevertModelColor();

	TArray<uint32> CurModelColorReqIDs;
	
#pragma endregion Effect

#pragma region LOD

public:
	void SetActorLOD(int32 NewLOD);
	int32 GetActorLOD() const;
	void EnableActorLOD(bool Enable) {EnableLOD = Enable;}
	void OnLODChanged(int oldValue, int NewValue);
	void UpdateChaosClothAndKawaii(bool forceRecreateCloth);
	void GetClothAndKawaiiPermit(UKGPlatformScalabilitySettings* PlatformScalabilitySettings,int64 ActorID, int Lod, bool& ClothPermit, bool& KawaiiPermit);
	bool CheckCurrentAnimInstance();
	void EnableAnimTickOptimization(bool bEnable);
	void SetAnimLayerMap(const TMap<FString, FString>& InAnimLayerMap){ AnimLayerMap = InAnimLayerMap; }
	void ReleaseAllLimitBudget();

protected:
	int32 ActorLOD = 0;
	bool EnableLOD = false;
	inline static IConsoleVariable* CVarEnableClothPhysics;
	TWeakObjectPtr<UBaseAnimInstance> CurrentAnimInstance;
	TMap<FString, FString> AnimLayerMap;

public:
	inline static FString AnimLayerLinkLODTag = "AnimLayerLinkLOD";
	inline static FString AnimLayerLinkLimitTag = "AnimLayerLinkLimit";
	inline static FString KawaiiTag = "Kawaii";
	inline static FString ClothTag = "Cloth";
	inline static FString FaceAnimTag = "FaceAnim";

#pragma endregion LOD

#pragma region AnimNotify
// UAnimNotifyState_C7LocoDisable Start
public:
	bool DoLocoDisableFromAnimNotify(int64 NotifyUniqueID, bool bDisableAllMove, bool bDisableLocoMove, bool bDisableLocoStart, bool bForceLocoStart,
		bool bDisableLocoJump, bool bDisableLocoDodge, bool bForceLocoGroundSupport, bool bForceIgnoreLocoGroundSupport);
	bool UnDoLocoDisableFromAnimNotify(int64 NotifyUniqueID, bool bDisableAllMove, bool bDisableLocoMove, bool bDisableLocoStart, bool bForceLocoStart,
		bool bDisableLocoJump, bool bDisableLocoDodge, bool bForceLocoGroundSupport, bool bForceIgnoreLocoGroundSupport);
private:
	TMap<int64, TWeakObjectPtr<class URoleMovementComponent>> NotifyUniqueIDToC7LocoDisableRMCMap;		// 记录UAnimNotifyState_C7LocoDisable执行逻辑的RoleMovementComp
	TMap<int64, int32> NotifyUniqueIDToGroundSupportControlTokenMap;	// 记录UAnimNotifyState_C7LocoDisable自己申请的GroundSupportControlToken
// UAnimNotifyState_C7LocoDisable End

// UAnimNotifyState_C7MotionWarping Start
public:
	bool SaveMotionWarpMCTokenForAnimNotify(int64 NotifyUniqueID, int InToken);
	int GetAndClearMotionWarpMCTokenForAnimNotify(int64 NotifyUniqueID);
private:
	TMap<int64, int> NotifyUniqueIDToMotionWarpMCTokenMap;	// 记录UAnimNotifyState_C7MotionWarping申请的RotationWarpWithLocoInputMode
// UAnimNotifyState_C7MotionWarping End

// UAnimNotifyState_C7VelocityStable Start
public:
	bool SaveC7VelocityStableRMCForAnimNotify(int64 NotifyUniqueID, class URoleMovementComponent* InRMC);
	class URoleMovementComponent* GetAndClearC7VelocityStableRMCForAnimNotify(int64 NotifyUniqueID);
private:
	TMap<int64, TWeakObjectPtr<class URoleMovementComponent>> NotifyUniqueIDToC7VelocityStableRMCMap;	// 记录UAnimNotifyState_C7VelocityStable执行逻辑的RoleMovementComp
// UAnimNotifyState_C7VelocityStable End

// UAnimNotifyState_BikeShakeAkEvent Start
public:
	bool SaveBikeShakeAkEventRMCForAnimNotify(int64 NotifyUniqueID, class URoleMovementComponent* InRMC);
	class URoleMovementComponent* GetBikeShakeAkEventRMCForAnimNotify(int64 NotifyUniqueID);
	void ClearBikeShakeAkEventRMCForAnimNotify(int64 NotifyUniqueID);

	void SaveLastPitchValueForAnimNotify(int64 NotifyUniqueID, float InLastPitchValue);
	float GetLastPitchValueForAnimNotify(int64 NotifyUniqueID);
	void ClearLastPitchValueForAnimNotify(int64 NotifyUniqueID);

	void SaveCurTriggerEventCoolDownForAnimNotify(int64 NotifyUniqueID, float InCurTriggerEventCoolDown);
	float GetCurTriggerEventCoolDownForAnimNotify(int64 NotifyUniqueID);
	void ClearCurTriggerEventCoolDownForAnimNotify(int64 NotifyUniqueID);

	void InitHistoryDeltaPitchListForAnimNotify(int64 NotifyUniqueID);
	TArray<float>* GetHistoryDeltaPitchListForAnimNotify(int64 NotifyUniqueID);
	void ClearHistoryDeltaPitchListForAnimNotify(int64 NotifyUniqueID);
private:
	TMap<int64, TWeakObjectPtr<class URoleMovementComponent>> NotifyUniqueIDToBikeShakeAkEventRMCMap;	// 记录UAnimNotifyState_BikeShakeAkEvent执行逻辑的RoleMovementComp
	TMap<int64, float> NotifyUniqueIDToLastPitchValueMap;
	TMap<int64, float> NotifyUniqueIDToCurTriggerEventCoolDownMap;
	TMap<int64, TArray<float>> NotifyUniqueIDToHistoryDeltaPitchListMap;
// UAnimNotifyState_BikeShakeAkEvent End
#pragma endregion AnimNotify

#pragma region GhostCloneCache

public:
	UPROPERTY(BlueprintReadWrite, Transient)
	TArray<TObjectPtr<AActor>> GhostCloneCache;

	uint8 GhostCloneCacheCapacity = 1;
	
	UFUNCTION(BlueprintCallable)
	void SetGhostCloneCacheCapacity(uint8 InCapacity);

	UFUNCTION(BlueprintCallable)
	AActor* GetGhostCloneCache(int32 InAppearanceChangeCount);

	UFUNCTION(BlueprintCallable)
	bool AddGhostCloneCache(AActor* InActor, int32 InAppearanceChangeCount);

	UFUNCTION(BlueprintCallable)
	void ClearGhostCloneCache();
	
#pragma endregion

#pragma region BlobShadow
	
public:
	UPROPERTY(Transient)
	TObjectPtr<class UBlobShadowComponent> BlobShadowComponent = nullptr;
	
	UPROPERTY(Transient)
	bool IsEnableBlobShadow = false;

	UFUNCTION(BlueprintCallable)
	void EnableBlobShadow(bool Enable);
	
	UFUNCTION(BlueprintCallable)
	void TickBlobShadow(float DeltaSeconds);
	
#pragma endregion
};
