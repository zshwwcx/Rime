#pragma once

#include "CoreMinimal.h"
#include "3C/Character/C7Actor.h"
#include "GameFramework/Actor.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/PoseableMeshComponent.h"
#include "AkComponent.h"
#include "3C/Movement/SimpleMovementComponent.h"

#include "BSUnit.generated.h"



UCLASS(Abstract, BlueprintType)
class KGCHARACTER_API ABSUnit : public AC7Actor {
	GENERATED_BODY()
	
#pragma region Important
public:	
	ABSUnit(const FObjectInitializer& ObjectInitializer);

	virtual ~ABSUnit();

	virtual void TickActor(float DeltaTime, enum ELevelTick TickType, FActorTickFunction& ThisTickFunction) override;

public:
#if WITH_EDITORONLY_DATA
	UPROPERTY(EditDefaultsOnly, AdvancedDisplay)
	TSubclassOf<UObject> StaticDataType = nullptr;
#endif
	UPROPERTY()
	TObjectPtr<class USimpleMovementComponent> SimpleMovementComponent = nullptr;
	
#pragma endregion Important



#pragma region Core
public:
	// 开始表演
	UFUNCTION(BlueprintCallable)
	virtual void StartPerformance(float InTotalLife = 1.0f);

	// 结束表演
	UFUNCTION(BlueprintCallable)
	virtual void FinishPerformance();

	// 生命已经结束
	UFUNCTION(BlueprintCallable)
	virtual bool LifeIsOver();

#pragma endregion Core



#pragma region StaticProp
public:
	// 设置总生命
	UFUNCTION(BlueprintCallable)
	virtual void SetTotalLife(float InTime);

	// 标记需要脚本Tick
	UFUNCTION(BlueprintCallable)
	virtual void SetScriptTick(bool InTick);

	// 标记生命结束
	UFUNCTION(BlueprintCallable)
	virtual void SetEndOfLife(bool InEnd);

	// 标记服务器控制生命
	UFUNCTION(BlueprintCallable)
	virtual void SetServerControlLife(bool InServerControl);

protected:
	// 总生命
	float TotalLife = 1.0f;

	// 是否执行脚本Tick
	bool bScriptTick = false;

	// 标记为生命结束
	bool bEndOfLife = false;

	// 服务器控制生命
	bool bServerControlLife = false;

#pragma endregion StaticProp



#pragma region DynamicProp
public:
	// 获取全局ID
	UFUNCTION(BlueprintCallable)
	virtual int64 GetGID();

	// 获取是否激活中
	UFUNCTION(BlueprintCallable)
	virtual bool GetIsActive();

	// 设置Tick系数
	UFUNCTION(BlueprintCallable)
	virtual void SetTickRate(float InRate);

	// 获取Tick系数
	UFUNCTION(BlueprintCallable)
	virtual float GetTickRate();

	// 设置当前生命
	UFUNCTION(BlueprintCallable)
	virtual void SetRunningTime(float InTime);

	// 获取当前生命
	UFUNCTION(BlueprintCallable)
	virtual float GetRunningTime();

protected:
	// 全局ID
	int64 GID = 0;

	// 是否激活
	bool bIsActive = false;

	// 当前生命
	float RunningTime = 0.0f;

#pragma endregion DynamicProp

};
