#pragma once
#include "3C/Character/C7Actor.h"
#include "3C/Core/MeshPropController.h"

#include "SeerAttachActor.generated.h"

class UKGDataCacheManager;
class UKGEffectManager;
class UKGMaterialManager;

enum class EKGAttachActorDissolveType
{
	NormalDissolve = 0, // 普通溶解, 调用溶解特效表中的参数实现溶解效果
	WeaponDissolve = 1, // 相比于普通溶解来说, 溶出只播放特效无材质效果; 溶入跟正常溶解没区别
	SeerCardDissolve = 2, // 占卜家卡牌定制溶解, 目前仅在剧情中用, 因为占卜家卡牌比较特殊, 分前后两个卡牌actor, 前后卡牌的mesh组织形式也不一样, 目前效果是完全定制的
};

struct FKGAttachExtraDissolveInfo
{
	FKGAttachExtraDissolveInfo() = default;
	FKGAttachExtraDissolveInfo(EKGAttachActorDissolveType InDissolveType) : DissolveType(InDissolveType) {}
	EKGAttachActorDissolveType DissolveType = EKGAttachActorDissolveType::NormalDissolve;
	bool bForwardCard = false;
	bool bBackCard = false;
};

//所有项目自定义Actor的基类

// ASeerAttachActor 原本是设计给占卜家卡牌专用的Actor、后续发现武器以及后面可能存在的C++里自己管理的Actor
// 可能需要具备相同的功能,所以这里 说明下 这个 Actor并非卡牌专用,所有需要走 Logic Parent-Child 同步材质显隐
// 以及其他类似效果的 Actor,如果没有 Entity类型 纯c++ 管理都可以使用这个 Actor !!!

UCLASS(BlueprintType, Blueprintable)
class KGCHARACTER_API ASeerAttachActor : public AC7Actor
{
	GENERATED_BODY()

public:
	ASeerAttachActor(const FObjectInitializer& ObjectInitializer);

	virtual void PostInitializeComponents() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

	virtual void SyncVisibilityFromParent(bool bVisible) override;
	void SetVisibilityBySelf(int32 EffectID, bool bVisible, const FKGAttachExtraDissolveInfo& ExtraDissolveInfo);
	
	void SetVisibilityWithDissolveEffect(int32 EffectID, bool bVisible, const FKGAttachExtraDissolveInfo& ExtraDissolveInfo);
	void OnDelayInvisibleTimerTimeout();
	void ClearDelayInvisibleTimer();
	void DoSetVisibilityByDissolveEffect(bool bVisible);

	void RefreshMaterialCacheOnAddMeshComponent(KGObjectID MeshComponentID, bool bInheritMaterialEffect);
	void RefreshMaterialCacheOnRemoveMeshComponent(KGObjectID MeshComponentID);
	
	FKGMeshPropController& GetMeshPropController() { return MeshPropController; }
	
protected:
	
	void StartSeerCardDissolveEffect(int32 EffectID, bool bVisible, const FKGAttachExtraDissolveInfo& ExtraDissolveInfo);
	void StartWeaponDissolveEffect(int32 EffectID, bool bVisible, const FKGAttachExtraDissolveInfo& ExtraDissolveInfo);
	void StartNormalDissolveEffect(int32 EffectID, bool bVisible, const FKGAttachExtraDissolveInfo& ExtraDissolveInfo);
	
	UKGMaterialManager* GetOrUpdateMaterialManager();
	UKGEffectManager* GetOrUpdateEffectManager();
	UKGDataCacheManager* GetOrUpdateDataCacheManager();
	
	bool bVisibleByParent = true;
	bool bVisibleBySelf = true;
	int32 DissolveEffectID = -1;
	
	FTimerHandle DelayInvisibleHandle;
	uint32 DissolveReqID = 0;
	
	FKGMeshPropController MeshPropController;
	TWeakObjectPtr<UKGMaterialManager> CachedMaterialManager;
	TWeakObjectPtr<UKGEffectManager> CachedEffectManager;
	TWeakObjectPtr<UKGDataCacheManager> CachedDataCacheManager;
};
