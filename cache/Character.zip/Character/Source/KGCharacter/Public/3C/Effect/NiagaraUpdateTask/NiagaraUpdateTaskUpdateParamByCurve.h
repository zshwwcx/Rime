﻿#pragma once
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskBase.h"

struct FKGNiagaraUpdateTaskUpdateParamByCurve : FKGNiagaraUpdateTaskBase
{
	virtual EKGNiagaraTickBehavior GetTickBehavior() const override { return EKGNiagaraTickBehavior::EveryFrame; }
	virtual EKGNiagaraUpdateTaskType GetTaskType() const override { return EKGNiagaraUpdateTaskType::UpdateParamByCurve; }
	virtual bool OnTaskInit(const FKGNiagaraUpdateTaskTarget& InTaskTarget) override;
	virtual bool OnTaskUpdate(float DeltaTime, const FKGNiagaraUpdateTaskTarget& InTaskTarget) override;
	virtual bool OnTaskDestroy(const FKGNiagaraUpdateTaskTarget& InTaskTarget) override;
	virtual bool IsFinished() const override { return bFinished; }

	void InternalOnFloatCurveAssetLoaded(int InLoadID, UObject* LoadedAssets);

	FName ParamName;
	bool bUseNiagaraAccumulatedTime = true;
	FKGCurveParams CurveParams;
	int32 CurveAssetLoadId = 0;
	bool bDestroyNiagaraOnCurveEvalFinished = false;

	FKGCurveFloatEvalHelper CurveFloatEvalHelper;
	bool bFinished = false;
};
