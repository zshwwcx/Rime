﻿#pragma once
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskBase.h"

struct FKGNiagaraUpdateTaskFollowActorRotation : FKGNiagaraUpdateTaskBase
{
	virtual EKGNiagaraTickBehavior GetTickBehavior() const override { return EKGNiagaraTickBehavior::EveryFrame; }
	virtual EKGNiagaraUpdateTaskType GetTaskType() const override { return EKGNiagaraUpdateTaskType::FollowActorRotation; }
	virtual bool OnTaskInit(const FKGNiagaraUpdateTaskTarget& InTaskTarget) override;
	virtual bool OnTaskUpdate(float DeltaTime, const FKGNiagaraUpdateTaskTarget& InTaskTarget) override;

	FQuat CachedInitRelativeRotation = FQuat::Identity;
};
