﻿#pragma once

#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskBase.h"

struct FKGNiagaraTextureParams
{
	int LoadID = 0;
	FString TexturePath;
	TStrongObjectPtr<UTexture> LoadedTexture;
};

struct FKGNiagaraUpdateTaskConstantNiagaraParams : FKGNiagaraUpdateTaskBase
{
	virtual EKGNiagaraUpdateTaskType GetTaskType() const override { return EKGNiagaraUpdateTaskType::ConstantNiagaraParams; }
	virtual bool OnTaskInit(const FKGNiagaraUpdateTaskTarget& TaskTarget) override;
	virtual bool OnTaskDestroy(const FKGNiagaraUpdateTaskTarget& TaskTarget) override;

	void SetCustomDepthInfo(bool bInEnableCustomDepth, int32 InCustomDepthStencilValue);
	void SetForceCustomDepthInfo(bool bInEnableCustomDepth, int32 InCustomDepthStencilValue);
	void RevertForceCustomDepthInfo();

	void SetSpiritualVisionColor(bool bInSpiritualVision, const FLinearColor& InSpiritualVisionMeshColor);
	void UpdateSpiritualVisionColorParams(const FName& ParamName, bool bEnableSpiritualVision);

	void SetTextureParam(const FName& ParamName, const FString& TexturePath);
	void RemoveTextureParam(const FName& ParamName);
	void InternalOnTextureAssetLoaded(int InLoadID, UObject* LoadedAssets, FName ParamName);
	
	TMap<FName, float> UserVals_Float;
	TMap<FName, FVector> UserVals_Vec3;
	TMap<FName, FVector2D> UserVals_Vec2;
	TMap<FName, FLinearColor> UserVals_LinearColor;
	TMap<FName, FKGNiagaraTextureParams> UserVals_Textures;

	TArray<FName> ComponentTags;
	
	bool bEnableCustomDepth = false;
	int32 CustomDepthStencilValue = 0;

	TOptional<bool> bForceRenderCustomDepth;
	int32 ForceCustomDepthStencilValue = 0;
	
	TOptional<bool> bRenderInMainPass;
	int32 TranslucencySortPriority = 0;
	int32 TranslucencySortDistanceOffset = 0;

	bool bSpiritualVision = false;
	FLinearColor SpiritualVisionMeshColor = FLinearColor::White;
};
