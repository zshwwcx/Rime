#pragma once

#include "CoreMinimal.h"
#include "Misc/CommonDefines.h"
#include "Containers/Union.h"
#include "Effect/KGEffectCommon.h"

#include "KGNiagaraCommon.generated.h"

class UCurveFloat;

#define KG_NIAGARA_MIN_PARTICLE_COLOR_SCALE (0.001f)
#define KG_NIAGARA_MAX_HIDDEN_REASONS (64)
#define KG_EFFECTMANAGER_ENABLE_STAT (!UE_BUILD_TEST && !UE_BUILD_SHIPPING)
#define KG_INVALID_UPDATE_TASK_ID (-1)

DECLARE_LOG_CATEGORY_EXTERN(LogEM, Log, All);

// 跟脚本的 Const.NIAGARA_HIDDEN_REASON 对应
enum class EKGNiagaraHiddenReason : uint8
{
	OWNER_SET_HIDDEN = 0,
	
	// cpp use
	HEIGHT_DIFF_OVER_THRESHOLD = 50,
	OTHER_PLAYER_QUALITY_LEVEL_LOW = 51,
	ATTACH_COMPONENT_HIDDEN = 52,
	Max = 64
};

UENUM(BlueprintType)
enum class EKGNiagaraPriorityType : uint8
{
	Ignorable = 0 UMETA(DisplayName="Ignorable"),
	Low = 1 UMETA(DisplayName="Low"),
	Medium = 2 UMETA(DisplayName="Medium"),
	High = 3 UMETA(DisplayName="High"),
	Vital = 4 UMETA(DisplayName="Vital"),
	MaxNum
};

enum class EKGNiagaraDestroyType : uint8
{
	DestroyImmediately = 1, // 特效直接destroy
	BlendOutBeforeDestroy = 2, // 特效先blend out再destroy
};

UENUM()
enum class EFKGNiagaraParamLinearSampleValueType : uint8
{
	Scalar = 0,
	Vector = 1
};

enum class EKGNiagaraUpdateTaskType : uint8
{
	FollowSlomo = 0,
	FollowCameraFOV = 1,
	FaceToLocation = 2,
	FaceToActor = 3,
	UpdateSplineParams = 4,
	FollowActorLocation = 5,
	FollowCameraArmLength = 6,
	UpdateParamByLinearSample = 7,
	UpdateParamByCurve = 8,
	UpdatePositionWithArcParams = 9,
	UpdateParticleColorScaleByCurve = 10,
	UpdateParticleColorScaleLinearSample = 11,
	ConstantNiagaraParams = 12,
	SetNiagaraMeshComponentInfo = 13,
	SetEffectAudio = 14,
	FollowActorRotation = 15,
	UpdateParamByHeightDiff = 16,
	StickOnGround = 17,
};

enum class EKGNiagaraFaceToActorRotationType : uint8
{
	OnlyRotateYaw = 0, // 仅旋转Yaw
	Rotate3D = 1 // 完整旋转
};

struct FKGMeshComponentNiagaraParam
{
	KGObjectID ComponentID = 0;
	bool bUseCloneMesh = false;
	bool bUseNiagaraComponentTransform = false;
	TArray<FName> SkeletalMeshFilterBones;
};

enum class EKGNiagaraSearchAttachComponentType : uint8
{
	UseRootComponent = 0,
	UseMainMeshComponent,
	UseCameraRootComponent,
	FindComponentByComponentClassType,
	FindComponentByComponentName,
	FindComponentBySocketName,
	UseCustomAttachComponent,
	UseMainMeshOrRootComponent,
	FindComponentByComponentTypeAndTag,
};

// 目前仅在技能编辑器中开放使用
UENUM()
enum class EKGNiagaraRotationMode : uint8
{
	Follow = 0 UMETA(ToolTip="挂接骨骼实时朝向+Transform.Rot（偏移）, 期间实时跟随"), 
	SocketInit = 1 UMETA(ToolTip="挂接骨骼初始朝向+Transform.Rot（偏移）, 不实时更新"),
	World = 2 UMETA(ToolTip="固定的世界朝向=Transform.Rot（偏移）"),
	SelfInit = 3 UMETA(ToolTip="创建者初始朝向+Transform.Rot（偏移）"),
	ToTimelinePlayer = 4 UMETA(ToolTip="特效挂接位置朝向TimeLine播放者的位置+Transform.Rot（偏移）"),
	ToCameraYaw = 5 UMETA(ToolTip="特效Yaw始终朝向摄像机Yaw, 再叠加朝向偏移"),
};

UENUM()
enum class EKGNiagaraPositionMode : uint8
{
	Follow = 0 UMETA(ToolTip="创建者实时位置+Transform.Pos（偏移），期间实时跟随"),
	SocketInit = 1 UMETA(ToolTip="创建者当时位置+Transform.Pos（偏移），不实时跟随"),
	World = 2 UMETA(ToolTip="固定的世界位置=Transform.Pos"),
};

enum class EKGNiagaraStickGroundType : uint8
{
	DoNotStickToGround = 0,
	StickToGround = 1,
	StickToWaterSurface = 2
};

struct FKGAttachedNiagaraSpawnInfo
{
	// 基础挂接信息
	EKGNiagaraSearchAttachComponentType SearchAttachComponentType = EKGNiagaraSearchAttachComponentType::UseRootComponent;
	TEnumAsByte<EAttachLocation::Type> LocationType = EAttachLocation::KeepRelativeOffset;
	bool bAbsolutePosition = false;
	bool bAbsoluteRotation = false;
	bool bAbsoluteScale = false;
	FTransform RelativeTrans = FTransform::Identity;
	FName AttachPointName = NAME_None;

	// 查找挂接组件相关信息
	FName ComponentTag = NAME_None;
	TWeakObjectPtr<USceneComponent> CustomAttachComponent;
	TWeakObjectPtr<UClass> ComponentClass;
};

enum class EKGNiagaraSearchSpawnLocationType : uint8
{
	UseCustomSpawnTrans,
	UseAttachSocketTransform,
	UseActorTransform,
};

struct FKGUnattachedNiagaraSpawnInfo
{
	// 基础transform信息
	EKGNiagaraSearchSpawnLocationType SearchSpawnLocationType = EKGNiagaraSearchSpawnLocationType::UseCustomSpawnTrans;
	FName AttachPointName = NAME_None;
	FTransform WorldOrRelativeTrans = FTransform::Identity;
	bool bAbsoluteScale = false;
};

enum class EKGNiagaraEffectTag : uint32
{
	// CommonEffectTag 最多64个 (CommonEffectTag是指在特效管理器中统一设置的EffectTag, 非业务传入的)
	BATTLE = 3,
	OTHER_PLAYER = 4,
	OTHER_PLAYER_LOW_QUALITY = 5,
	MAIN_PLAYER = 6,
	ENV = 7,
	
	// 业务用的Tag, 从64开始往下加
	APPEARANCE = 64,
	ENEMY_INDICATOR = 65,
	HATRED_INDICATOR = 66,
	TEAMMATE_INDICATOR = 67,
	WATER_MOVE = 68,
	SYSTEM_ACTION = 69,
	FLOWCHART = 70,
	CAMERA = 71,
	SKILL_INDICATOR = 72,  // 技能指示器
	SPIRITUAL_GLIDE_HAND_EFFECT = 73, // 灵性之跃手部特效
};

UENUM()
enum class EKGNiagaraQualityLevel : int8
{
	UnInit = -1 UMETA(Hidden),
	Low = 0, // 对于其他玩家来说, Low等价于隐藏
	Medium = 1,
	High = 2,
	Ultra = 3
};

UENUM()
enum class EKGNiagaraParticleColorScaleLevel : int8
{
	UnInit = -1 UMETA(Hidden),
	Low = 0,
	Medium = 1,
	High = 2,
	Ultra = 3
};

struct FKGPlayNiagaraParams
{
	FKGPlayNiagaraParams()
	{
		SpawnInfo.SetSubtype<FKGUnattachedNiagaraSpawnInfo>();
	}
	
	FString NiagaraEffectPath;

	KGObjectID SpawnerID = 0;
	KGEntityID SpawnerEntityID = KG_INVALID_ENTITY_ID;
	KGEntityID InstigatorEntityID = KG_INVALID_ENTITY_ID;
	// EffectTag分为两种
	// 1) CommonEffectTag, 最多64位, 定义在 NIAGARA_EFFECT_TAG 中, 这个使用非常高频, 通过一个int64在特效创建时传入
	// 2) 业务用EffectTag(ExtraEffectTag), 按照ID段划分, 不在创建特效时传入, 通过专用接口传入, 这部分数量不多
	TSet<EKGNiagaraEffectTag> EffectTags;

	bool bDestroyWhenSpawnerExitWorld = true;
	bool bPreCullCheck = true;
	bool bIsPlayerEffect = false;
	// 默认情况下, 为了避免同一帧特效创建数量过多, 创建特效前会将请求放进一个队列中，并在effect manager tick时再取出请求真正创建
	// 对于需要即时创建的特效, 可以标记bActivateImmediately为true
	bool bActivateImmediately = false;
	float EffectPlayRate = 1.0f;
	float TransparencyScale = 1.0f;

	float TotalLifeMs = -1.0f;
	EKGNiagaraDestroyType NiagaraDestroyType = EKGNiagaraDestroyType::BlendOutBeforeDestroy;
	float BlendInTimeSeconds = -1.0f;
	float BlendOutTimeSeconds = 0.5f;

	bool bFollowHidden = true;
	bool bFollowSlomo = true;
	bool bFollowCameraFOV = false;
	// attach模式下, 特效贴地仅在创建时做一次, 不做每帧贴地 
	EKGNiagaraStickGroundType StickGroundType = EKGNiagaraStickGroundType::DoNotStickToGround;
	// 技能特效定制创建参数
	bool bUseSkillNiagaraSpawnInfo = false;
	EKGNiagaraPositionMode PositionMode = EKGNiagaraPositionMode::Follow;
	EKGNiagaraRotationMode RotationMode = EKGNiagaraRotationMode::Follow;
	// 用于特效朝向的目标实体ID, 仅在RotationOverrideType为ConnectLine, 或者RotationMode为ToTimelinePlayer时有效
	KGEntityID RotationTargetEntityID = KG_INVALID_ENTITY_ID;
	FName AttachComponentName = NAME_None;
	// 这里是为了解决占卜家绝技问题新增的变量, 占卜家的绝技中, dynamic mesh不能保证在特效之前创建, 因此在播放特效时很有可能
	// 完全查不到对应的dynamic mesh记录, 这里会在dynamic mesh component中缓存对应的特效effect id, 并在后续dynamic mesh
	// 真正执行到create以后再应用对应的 effect id
	bool bCacheEvenIfDynamicMeshCtxNotFound = false;

	// 业务场景优先级, -1代表没配置，此时用资产上的优先级
	// 用于 NiagaraComponent->SetPriority()
	int32 NiagaraBusinessPriority = -1;

	// 仅内部使用
	// 用于entity enter world前播放特效, 先返回一个ID, 并不实际播放特效, 实际特效请求到enter world后再处理
	TOptional<int32> CustomEffectID;

	void SetAttachedSpawnInfo(const FKGAttachedNiagaraSpawnInfo& InSpawnInfo)
	{
		SpawnInfo.SetSubtype<FKGAttachedNiagaraSpawnInfo>(InSpawnInfo);
	}

	void SetUnattachedSpawnInfo(const FKGUnattachedNiagaraSpawnInfo& InSpawnInfo)
	{
		SpawnInfo.SetSubtype<FKGUnattachedNiagaraSpawnInfo>(InSpawnInfo);
	}

	bool NeedAttach() const
	{
		return SpawnInfo.HasSubtype<FKGAttachedNiagaraSpawnInfo>();
	}
	
	const FKGAttachedNiagaraSpawnInfo* GetAttachedSpawnInfoPtr() const
	{
		return SpawnInfo.HasSubtype<FKGAttachedNiagaraSpawnInfo>() ? 
			&SpawnInfo.GetSubtype<FKGAttachedNiagaraSpawnInfo>() : nullptr;
	}

	const FKGUnattachedNiagaraSpawnInfo* GetUnattachedSpawnInfoPtr() const
	{
		return SpawnInfo.HasSubtype<FKGUnattachedNiagaraSpawnInfo>() ? 
			&SpawnInfo.GetSubtype<FKGUnattachedNiagaraSpawnInfo>() : nullptr;
	}

	FKGAttachedNiagaraSpawnInfo& GetAttachedSpawnInfoChecked()
	{
		return SpawnInfo.GetSubtype<FKGAttachedNiagaraSpawnInfo>();
	}

	FKGUnattachedNiagaraSpawnInfo& GetUnattachedSpawnInfoChecked()
	{
		return SpawnInfo.GetSubtype<FKGUnattachedNiagaraSpawnInfo>();
	}

	const FKGAttachedNiagaraSpawnInfo& GetAttachedSpawnInfoChecked() const
	{
		return SpawnInfo.GetSubtype<FKGAttachedNiagaraSpawnInfo>();
	}

	const FKGUnattachedNiagaraSpawnInfo& GetUnattachedSpawnInfoChecked() const
	{
		return SpawnInfo.GetSubtype<FKGUnattachedNiagaraSpawnInfo>();
	}

private:
	
	TUnion<FKGAttachedNiagaraSpawnInfo, FKGUnattachedNiagaraSpawnInfo> SpawnInfo;
};
