﻿#pragma once
#include "NiagaraComponent.h"
#include "3C/Effect/KGNiagaraCommon.h"

class UKGEffectManager;
struct FKGNiagaraUpdateContext;

enum class EKGNiagaraUpdateTaskState
{
	UnInitialized = 0,
	Initialized = 1,
	Destroyed = 2,
};

// 目前仅在hidden状态下做降频处理
enum class EKGNiagaraTickBehavior : uint8
{
	Never = 0, // 无需更新
	EveryFrame = 1, // 仅在非hidden状态下每帧更新
	ForceEveryFrame = 2, // 强制每帧更新, 就算处于hidden状态下也会每帧更新
};

// 由于UE的UStruct不可以使用继承, 因此只能采用组合的方式支持task更新native niagara component
// 注意这里不可以缓存, 这里只是为了方便niagara update context更新时 避免每次都从task去取niagara update context导致额外的开销
struct FKGNiagaraUpdateTaskTarget
{
	FKGNiagaraUpdateTaskTarget() = default;
	FKGNiagaraUpdateTaskTarget(FKGNiagaraUpdateContext* UpdateContextPtr) : NiagaraUpdateContextPtr(UpdateContextPtr) {}
	FKGNiagaraUpdateTaskTarget(UNiagaraComponent* InNiagaraComponent) : NiagaraComponent(TWeakObjectPtr(InNiagaraComponent)) {}
	
	UNiagaraComponent* GetNiagaraComponent() const;
	AActor* GetSpawnerActor() const;
	FString GetDebugInfo() const;
	
	FKGNiagaraUpdateContext* NiagaraUpdateContextPtr = nullptr;
	TWeakObjectPtr<UNiagaraComponent> NiagaraComponent;
};

// 由于当前特效参数更新的方式和任务类型都在不停的扩展, 为了避免逻辑都在effect manager中难以管理，这里将需要tick更新特效参数的逻辑拆分出来
// 当前需要tick更新特效参数的特效数量不多, 特效更新任务暂时用Struct组织, 内存暂不用池, 而是通过智能指针分配
struct FKGNiagaraUpdateTaskBase
{
	FKGNiagaraUpdateTaskBase();
	virtual ~FKGNiagaraUpdateTaskBase() = default;

	void SetNiagaraUpdateContextInfo(FKGNiagaraUpdateContext* InOwnerContextPtr);
	void SetNativeNiagaraComponentInfo(UNiagaraComponent* InNiagaraComponent, UKGEffectManager* InEffectManager);
	FKGNiagaraUpdateContext* GetNiagaraUpdateContext() const;
	UNiagaraComponent* GetNativeNiagaraComponent() const;

	// 这里额外传入一个InOutContext是为了避免每次执行Init/Update/Destroy时从Task主动去找NiagaraUpdateContext会有额外的开销
	bool DoTaskInit(const FKGNiagaraUpdateTaskTarget& InTaskTarget);
	bool DoTaskUpdate(float DeltaTime, const FKGNiagaraUpdateTaskTarget& InTaskTarget);
	bool DoTaskDestroy(const FKGNiagaraUpdateTaskTarget& InTaskTarget);
	void AdvanceAccumulatedTime(float DeltaTime) { AccumulatedTime += DeltaTime; }
	void ResetAccumulatedTime() { AccumulatedTime = 0.0f; }
	
	virtual EKGNiagaraUpdateTaskType GetTaskType() const = 0;
	virtual EKGNiagaraTickBehavior GetTickBehavior() const { return EKGNiagaraTickBehavior::Never; }
	virtual bool IsFinished() const { return false; }
	virtual bool OnTaskInit(const FKGNiagaraUpdateTaskTarget& InTaskTarget) { return true; }
	virtual bool OnTaskUpdate(float DeltaTime, const FKGNiagaraUpdateTaskTarget& InTaskTarget) { return true; }
	virtual bool OnTaskDestroy(const FKGNiagaraUpdateTaskTarget& InTaskTarget) { return true; }

	uint32 GetTaskID() const { return TaskID; }
	bool ShouldAutoDestroyWhenFinished() const { return bAutoDestroyWhenFinished; }
	void SetAutoDestroyWhenFinished(bool bInAutoDestroyWhenFinished) { bAutoDestroyWhenFinished = bInAutoDestroyWhenFinished; }
	
protected:
	TWeakObjectPtr<UKGEffectManager> EffectManager;
	uint32 NiagaraEffectID = 0;
	// 这里仅当作用于UE原生NiagaraComponent时才有效
	TWeakObjectPtr<UNiagaraComponent> NativeNiagaraComponent;
	uint32 TaskID = 0;
	bool bAutoDestroyWhenFinished = true;
	EKGNiagaraUpdateTaskState TaskState = EKGNiagaraUpdateTaskState::UnInitialized;
	float AccumulatedTime = 0.0f;
};