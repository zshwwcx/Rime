#pragma once
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskBase.h"

class UAkComponent;

struct FKGNiagaraUpdateTaskSetEffectAudio : FKGNiagaraUpdateTaskBase
{
	FString AudioName = TEXT("");
	int32 AudioId = 0;
	
	virtual EKGNiagaraUpdateTaskType GetTaskType() const override { return EKGNiagaraUpdateTaskType::SetEffectAudio; }
	virtual bool OnTaskInit(const FKGNiagaraUpdateTaskTarget& InTaskTarget) override;
	virtual bool OnTaskDestroy(const FKGNiagaraUpdateTaskTarget& InTaskTarget) override;
	
	TWeakObjectPtr<UAkComponent> BindNiagaraAkComponent;
};
