﻿#pragma once

#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskBase.h"

struct FKGNiagaraUpdateTaskSetNiagaraMeshComponentInfo : FKGNiagaraUpdateTaskBase
{
	virtual EKGNiagaraUpdateTaskType GetTaskType() const override { return EKGNiagaraUpdateTaskType::SetNiagaraMeshComponentInfo; }
	virtual bool OnTaskInit(const FKGNiagaraUpdateTaskTarget& InTaskTarget) override;
	virtual bool OnTaskDestroy(const FKGNiagaraUpdateTaskTarget& InTaskTarget) override;

	KGObjectID OverrideSystemUserVariableMeshComponentWithCloneMesh(
		const FKGNiagaraUpdateTaskTarget& InTaskTarget, KGObjectID OriginMeshCompID, bool bUseNiagaraComponentTransform, const TArray<FName>& SkeletalMeshFilterBones);
	void OverrideSystemUserVariableMeshComponent(
		const FKGNiagaraUpdateTaskTarget& InTaskTarget, KGObjectID MeshCompID, const TArray<FName>& SkeletalMeshFilterBones);
	
	FString ParamName;
	FKGMeshComponentNiagaraParam MeshComponentInfo;;
	TWeakObjectPtr<AActor> CloneActor;
};
