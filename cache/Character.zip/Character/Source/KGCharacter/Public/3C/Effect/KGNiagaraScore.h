#pragma once
#include "CoreUObject.h"
#include "NiagaraSystemInstance.h"
#include "NiagaraSystemInstanceController.h"
#include "Engine/DataTable.h"
#include "3C/Effect/KGNiagaraCommon.h"
#include "reflection/CppReflectionMarco.h"
#include "KGNiagaraScore.generated.h"

// UE_DISABLE_OPTIMIZATION

USTRUCT(Blueprintable, BlueprintType)
struct FKGNiagaraScoreCapacitySettings
{
	GENERATED_BODY()
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector2D FpsRange = FVector2D(30, 60);

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector2D CapacityRange = FVector2D(512, 1024);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, EditFixedSize)
	TArray<float> PriorityCapacityPercentages {0.2f, 0.2f, 0.2f, 0.2f, 0.2f};
	
	float GetTotalCapacity() const;
	float GetSumCapacity(int32 InPriority) const;
	float GetCapacity(int32 InPriority) const;
};

USTRUCT(Blueprintable, BlueprintType)
struct FKGNiagaraScorePoolSettings
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FKGNiagaraScoreCapacitySettings QualityLevel0 = {};

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FKGNiagaraScoreCapacitySettings QualityLevel1 = {};
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FKGNiagaraScoreCapacitySettings QualityLevel2 = {};

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FKGNiagaraScoreCapacitySettings QualityLevel3 = {};

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FKGNiagaraScoreCapacitySettings QualityLevel4 = {};

	const FKGNiagaraScoreCapacitySettings* GetCapacitySettingsForQualityLevel(int32 InQualityLevel) const;
	void SetCapacitySettings(int32 InQualityLevel, const FKGNiagaraScoreCapacitySettings& InCapacitySettings);
};

USTRUCT(BlueprintType)
struct FKGNiagaraScoreData :public FTableRowBase
{
	GENERATED_BODY()

#pragma region Properties
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL0")
	uint8 Score_QL0_200 = 0;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL0")
	uint8 Score_QL0_500 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL0")
	uint8 Score_QL0_1000 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL0")
	uint8 Score_QL0_2000 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL0")
	uint8 Score_QL0_4000 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL0")
	uint8 Score_QL0_8000 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL1")
	uint8 Score_QL1_200 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL1")
	uint8 Score_QL1_500 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL1")
	uint8 Score_QL1_1000 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL1")
	uint8 Score_QL1_2000 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL1")
	uint8 Score_QL1_4000 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL1")
	uint8 Score_QL1_8000 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL2")
	uint8 Score_QL2_200 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL2")
	uint8 Score_QL2_500 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL2")
	uint8 Score_QL2_1000 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL2")
	uint8 Score_QL2_2000 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL2")
	uint8 Score_QL2_4000 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL2")
	uint8 Score_QL2_8000 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL3")
	uint8 Score_QL3_200 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL3")
	uint8 Score_QL3_500 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL3")
	uint8 Score_QL3_1000 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL3")
	uint8 Score_QL3_2000 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL3")
	uint8 Score_QL3_4000 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL3")
	uint8 Score_QL3_8000 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL4")
	uint8 Score_QL4_200 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL4")
	uint8 Score_QL4_500 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL4")
	uint8 Score_QL4_1000 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL4")
	uint8 Score_QL4_2000 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL4")
	uint8 Score_QL4_4000 = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="QL4")
	uint8 Score_QL4_8000 = 0;
#pragma endregion Properties
	
	uint8 GetNiagaraScoreValue(int32 InQualityLevel, float InDistance) const;
};

struct FNiagaraComponentBasicInfo
{
	int32 Priority;
	const FKGNiagaraScoreData* ScoreData = nullptr;       
};

KG_ATTR(nohotfix) struct FNiagaraScoreInstanceInfo
{
	const TWeakObjectPtr<UNiagaraComponent> ComponentPtr;
	const int32 Priority;
	const int32 QualityLevel = 0;
	
	FVector Location;
	float Score;				
	float Distance2ViewCenter;
	float Distance2Camera;

	FNiagaraScoreInstanceInfo(
		const TWeakObjectPtr<UNiagaraComponent>& InComponentPtr,
		int32 InPriority,
		int32 InQualityLevel)
		: ComponentPtr(InComponentPtr)
		, Priority(InPriority)
		, QualityLevel(InQualityLevel)
	{
		Location = FVector::ZeroVector;
		Score = 0.f;
		Distance2ViewCenter = 0.f;
		Distance2Camera = 0.f;
	}

	FNiagaraScoreInstanceInfo(
	const TWeakObjectPtr<UNiagaraComponent>& InComponentPtr,
	const FNiagaraComponentBasicInfo& BasicInfo, int32 InQualityLevel)
		: ComponentPtr(InComponentPtr)
		, Priority(BasicInfo.Priority)
		, QualityLevel(InQualityLevel)
	{
		Location = FVector::ZeroVector;
		Score = 0.f;
		Distance2ViewCenter = 0.f;
		Distance2Camera = 0.f;
	}
};

class FKGNiagaraScoreManager
{
public:
	void Init(UObject* InWorldContextObject);
	void Quit();
	void Tick(float InDeltaTime);
	
	bool IsBattleEffectScoreControlEnabled() const;
	bool IsEnvEffectSlowTickEnabled() const;
	bool IsBattleEffectSlowTickEnabled() const;
	
	void SetBattleEffectScoreControlForceEnabled(int Value);
	void SetBattleEffectScoreControlEnabled(bool bEnabled);
	void SetEnvEffectSlowTickForceEnabled(int Value);
	void SetEnvEffectSlowTickEnabled(bool bEnabled);
	void SetBattleEffectSlowTickForceEnabled(int Value, bool bIsDistanceCheckEnable);
	void SetBattleEffectSlowTickEnabled(bool bIsEnable);
	void SetBattleEffectIgnorePriority4(int Value);
	
	void SetNiagaraScoreCapacitySettings(int32 InQualityLevel, const FKGNiagaraScoreCapacitySettings& InCapacitySettings);
	void SetNiagaraScoreData(const FName& InNiagaraSystemPath, const FKGNiagaraScoreData& InNiagaraScoreData);

	// 检查池子是否有足够的空间塞下新特效，OutScoreToRelease代表还需要释放多少空间，OutScoreRequired表示该特效分数，用于最后统计
	bool CheckScorePoolAvailable(const UNiagaraSystem* UNiagaraSystem, const FName& NiagaraSystemPath, int32 InNiagaraPriority, float& OutScoreToRelease, float& OutMaxRequiredScore);
	// 创建完成后传入实例，并且隐藏一些不重要的特效
	bool PrepareNiagaraActivation(const TWeakObjectPtr<UNiagaraComponent>& InNiagaraComponent, const FName& NiagaraSystemPath, int32 InNiagaraPriority, float InScoreToRelease, float InMaxRequiredScore);
	void SetBattleEffectTickingRate(const TWeakObjectPtr<UNiagaraComponent>& InNiagaraComponent);
	
	void SetEnvEffectConfig(float InCheckInterval, float InDistance);
	void SetBattleEffectSlowTickConfig(float InDistance);
	void SetSlowTickRate(int InSlowTickRate, bool bIsForce);
private:
	bool LoadScoreSettings();
	void OnScoreTableLoaded(int32 InLoadingId, UObject* InLoadedObject);
	const FKGNiagaraScoreData* GetNiagaraScoreData(const FName& InNiagaraSystemPath) const;

	float GetSumScoreCapacity(int32 InPriority) const;
	float GetScoreCapacity(int32 InPriority) const;
	float GetUsedScore(int32 InPriority) const;
	float GetFixedUsedScore(int32 InNiagaraPriority) const;
	float GetRequiredScore(const FName& InNiagaraSystemPath, int32 InQualityLevel, float InDistance) const;
	
	void EnsureUpdateAllBattleEffectInfo();
	void EnsureUpdateAllEnvEffectInfo();
	bool TryFreeSpace(const int32& InPriority, const int32& InNeedScore, const float& InCurrentDistance);
	bool FreeLowerInstance(const FNiagaraScoreInstanceInfo& InInstanceInfo, const int32 InPriority);

	void OnNiagaraSystemInstanceAllocated(FNiagaraSystemInstancePtr& InNiagaraSystemInstancePtr);

	void OnEffectManagerNiagaraComponentActive(UNiagaraComponent* ComponentPtr, const FKGPlayNiagaraParams& Params);
	void OnEffectManagerNiagaraComponentDeActive(UNiagaraComponent* ComponentPtr, const FKGPlayNiagaraParams& Params);

	void ProcessPendingNiagaraComponent(UNiagaraComponent* ComponentPtr);
	void ControlAllEnvEffectsSlowTick();

	bool GetCachedViewCenterLocation(const UWorld* World);
	bool GetCachedCameraLocation(const UWorld* World);

	int32 GetQualityLevelOfComponent(const TWeakObjectPtr<UNiagaraComponent>& InNiagaraComponent);

	void SetTickingRate(const TWeakObjectPtr<UNiagaraComponent>& InNiagaraComponent, bool bIsSlowTick);
private:
	// Base Managers
	TWeakObjectPtr<class UKGCppAssetManager> AssetManager = nullptr;
	TWeakObjectPtr<class UKGEffectManager> EffectManager = nullptr;
	
	// Settings and Configs
	bool bShouldLoadSettings = true;
	FString NiagaraScoreTablePath = TEXT("");
	int32 NiagaraScoreSettingsLoadingId = 0;
	FKGNiagaraScorePoolSettings NiagaraScorePoolSettings = {};
	TMap<FName, FKGNiagaraScoreData> NiagaraScoreDataMap = {};

	bool bIsBattleScoreControlEnable = false;
	bool bIsEnvSlowTickEnable = false;
	bool bIsBattleSlowTickEnable = false;
	FDelegateHandle HandleForNiagaraSystemInstanceAllocated = {};
	FDelegateHandle HandleForEffectManagerNiagaraComponentActive = {};
	FDelegateHandle HandleForEffectManagerNiagaraComponentDeActive = {};
	
	TMap<int32, TArray<FNiagaraScoreInstanceInfo>> BattleEffectPriority2ComponentsMap = {};
	TMap<int32, float> BattleEffectPriority2ScoreMap = {};
	
	TMap<FObjectKey, FNiagaraComponentBasicInfo> ActiveBattleEffectMap = {};
	TMap<FObjectKey, FNiagaraComponentBasicInfo> ActiveEnvEffectMap = {};
	
	TArray<FNiagaraScoreInstanceInfo> EnvEffectArray = {};
	TArray<FObjectKey> AllocatedEffectPendingList = {};	// 以FObjectKey形式持有当前所有创建的特效

	float EnvEffectAccumTickTime = 0.0f;
	float EnvEffectIntervalCheckTime = 2.0f;
	float EnvEffectSlowTickDistance = 3000.0f;
	float BattleEffectSlowTickDistance = 1000.0f;
	
	uint64 BattleEffectInfoUpdateFrameCount = 0;
	uint64 EnvEffectInfoUpdateFrameCount = 0;
	uint64 CheckAllListFrameCount = 0;
	
	uint64 Distance2MainViewCheckFrameCount = 0;
	uint64 Distance2CameraCheckFrameCount = 0;

	FVector CachedViewCenterLocation = FVector::ZeroVector;
	FVector CachedCameraLocation = FVector::ZeroVector;
	
	const float MinSpawnDistance = 100.0f;
	const int32 MaxPriority = 4;
	const float DefaultScore = 20.0f;	// 如果没有评分，那么优先级是0，分数是20
	const float DefaultPriority = 0;

	TOptional<ETickingRate> SlowTickRate;
};


// UE_ENABLE_OPTIMIZATION