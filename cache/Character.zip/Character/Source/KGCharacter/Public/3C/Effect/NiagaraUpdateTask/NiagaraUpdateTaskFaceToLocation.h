﻿#pragma once
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskBase.h"

struct FKGNiagaraUpdateTaskFaceToLocation : FKGNiagaraUpdateTaskBase
{
	virtual EKGNiagaraTickBehavior GetTickBehavior() const override { return EKGNiagaraTickBehavior::EveryFrame; }
	virtual EKGNiagaraUpdateTaskType GetTaskType() const override { return EKGNiagaraUpdateTaskType::FaceToLocation; }
	virtual bool OnTaskInit(const FKGNiagaraUpdateTaskTarget& InTaskTarget) override;
	virtual bool OnTaskUpdate(float DeltaTime, const FKGNiagaraUpdateTaskTarget& InTaskTarget) override;
	
	// 目前仅支持2D Location, 但是存放的还是3D位置，为了方便计算Yaw
	FVector FacingTargetLocation = FVector::ZeroVector;

	float CachedInitRelativeYaw = 0.0f;
};
