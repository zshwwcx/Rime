#pragma once
#include "Misc/CommonDefines.h"
#include "3C/Core/KGTimeDilationTimer.h"
#include "3C/Effect/KGNiagaraCommon.h"
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskBase.h"
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskUpdateSplineParams.h"

#include "KGNiagaraUpdateContext.generated.h"

struct FKGNiagaraUpdateTaskUpdateParamByLinearSample;
class UKGEffectManager;
class UNiagaraComponent;
class UNiagaraSystem;

UENUM()
enum class EKGNiagaraBehaviorOnExtraSpawnerDestroy : uint8
{
	DestroyEffect = 0,
	HideEffect = 1
};

struct FKGNiagaraExtraSpawnerInfo
{
	EKGNiagaraBehaviorOnExtraSpawnerDestroy BehaviorOnDestroy = EKGNiagaraBehaviorOnExtraSpawnerDestroy::DestroyEffect;
	// 当特效被隐藏时的隐藏原因
	EKGNiagaraHiddenReason HiddenReason = EKGNiagaraHiddenReason::OWNER_SET_HIDDEN;
};

USTRUCT()
struct FKGNiagaraUpdateContext
{
	GENERATED_BODY()

	void OnNiagaraSystemActivate();
	void OnNiagaraSystemDestroyed();

	void DetachNiagaraEffect();

	// 常量参数更新接口
	void UpdateNiagaraFloatParam(const FName& ParamName, float InVal);
	void UpdateNiagaraVec2Param(const FName& ParamName, float InX, float InY);
	void UpdateNiagaraVec3Param(const FName& ParamName, float InX, float InY, float InZ);
	void UpdateNiagaraLinearColorParam(const FName& ParamName, float InR, float InG, float InB, float InA);
	void UpdateNiagaraTextureParam(const FName& ParamName, const FString& TexturePath);
	void RemoveNiagaraTextureParam(const FName& ParamName);
	void UpdateSystemUserVariableMeshComponent(
		const FString& ParamName, KGObjectID MeshCompID, const TArray<FName>& SkeletalMeshFilterBones,
		bool bUseCloneMeshCompOnSystemUserVariableMeshComponent, bool bUseNiagaraComponentTransform);
	void SetNiagaraComponentTags(const TArray<FName>& Tags);
	void InheritOwnerCustomDepthInfo();
	void SetCustomDepthInfo(bool bEnableCustomDepth, int32 CustomDepthStencilValue);
	void SetForceCustomDepthInfo(bool bEnableCustomDepth, int32 CustomDepthStencilValue);
	void RevertForceCustomDepthInfo();
	void SetNiagaraRenderInMainPass(bool bRenderInMainPass);
	void SetNiagaraTranslucentSortPriority(int32 TranslucencySortPriority);
	void SetNiagaraTranslucencySortDistanceOffset(int32 TranslucencySortDistanceOffset);
	void UpdateNiagaraHiddenState(bool bHidden, uint8 HiddenReason, bool bInitHiddenState);
	void RefreshNiagaraHiddenStateOnActivate();
	void CheckGroundOnActivate();
	void SetSpiritualVisionColor(bool bInSpiritualVision, const FLinearColor& InSpiritualVisionMeshColor);
	void UpdateSpiritualVisionColorParams(const FName& ParamName, bool bEnableSpiritualVision);
	bool RefreshAttachComponentOrSpawnTrans();
	bool RefreshAttachComponentOrSpawnTrans_Default();
	bool RefreshAttachComponentOrSpawnTrans_SkillInfo();
	bool RefreshAttachComponent(bool& bOutFailImmediately);
	void RefreshNiagaraCommonTags();
	void RefreshQualityLevelAndTransparencyScale();

	bool CalculateTransform_GetSocketTransform(AActor* Spawner, USceneComponent* SocketComponent, const FName& SocketName, bool bAbsoluteScale, FTransform& OutSocketTransform);
	bool CalculateTransform_GetRotationToTimelinePlayer(AActor* Spawner, bool bUseLineStartWorldPos, const FVector& LineStartWorldPos, FQuat& OutQuat);
	USceneComponent* GetAttachComponentByComponentName();

	// tick类型参数更新接口
	void UpdateNiagaraFollowActor(const FName& ParamName, KGObjectID FollowActorId, bool bAbsoluteNiagaraRotationInFollow);
	int32 SetNiagaraSplineLink(
		const FString& SplineBPPath, const FString& SplineUserVarName, const FKGNiagaraUpdateSplineTargetParams& TargetParams);
	int32 SetNiagaraSplineLinkTargetLocation(int32 InTaskId, float Yaw, const FVector& InTargetLocation);
	bool UpdateNiagaraSplineLinkTargetComponent(int32 InTaskId, KGObjectID TargetComponentId, FName TargetSocketName);
	void UpdateNiagaraCameraArmLengthParam(const FName& ParamName);
	void SetNiagaraFollowCameraFOV();
	void UpdateNiagaraPlayRate();
	void SetNiagaraFaceToActor(AActor* Actor, EKGNiagaraFaceToActorRotationType RotationType);
	void SetNiagaraFaceToLocation(float InLocationX, float InLocationY);
	void AddLinearSampleVectorParams(
		const FName& ParamName, float StartX, float StartY, float StartZ, float EndX, float EndY, float EndZ,
		float Duration, bool bUseNiagaraAccumulatedTime);
	void AddLinearSampleFloatParams(
		const FName& ParamName, float StartVal, float EndVal, float Duration, bool bUseNiagaraAccumulatedTime);
	bool UpdateLinearSampleParamTargetValue(const FName& ParamName, float TargetValue, bool bUseNewDuration, float NewDuration);
	void AddOrUpdateLinearSampleParamTargetValue(
		const FName& ParamName, float StartValue, float TargetValue, bool bUseNewDuration, float NewDuration);
	void FinishLinearSampleParamTask(const FName& ParamName);
	void UpdatePositionWithArcParams(const FName& ParamName, float Radius, float StartRelativeYaw, float RotateAngle, float Duration);
	void AddFloatCurveParams(
		FName ParamName, const FString& CurvePath, bool bNeedRemap, float RemapTime, bool bUseNiagaraAccumulatedTime, bool bDestroyNiagaraOnCurveEvalFinished);
	void SetParticleColorScaleUpdateCurve(const FString& CurvePath, float Duration);
	void SetLinearSampleParticleColorScaleUpdateTask(bool bBlendIn, float Duration, bool bInitBlendIn);
	void BlendOutNiagaraByNiagaraParam(const FString& CurvePath, const FName& ParamName, float StartVal, float EndVal, float Duration);
	void SetNiagaraFollowActorRotation();
	void UpdateParamByHeightDiff(const FString& CurvePath, const FName& ParamName, float VisibilityChangeBlendTime, float HeightDiffHalfLifeTime);
	void SetNiagaraStickOnGround(float UpCheckDistance, float DownCheckDistance, bool bUseNiagaraAsPivotPos);
	void SetNiagaraParamByEffectID(uint32 ParamID);
	void ChangeAttachSocket(const FName& NewSocketName);
	// 设置以后会强制使用absolute scale, 特效不跟随缩放
	// 对于挂接类的特效来说, 只需要修改bAbsoluteScale即可
	// 对于非挂接类特效, 如果特效缩放依赖角色自身transform或者socket transform, 需要在设置bForceUseAbsoluteScale为false时恢复对应的原始缩放
	// 需要注意这里并不完全等同于目前的bAbsoluteScale, 因为特效创建位置不能变化, 只影响特效大小
	void SetForceUseAbsoluteScale(bool bInForceUseAbsoluteScale);
	void SetNiagaraFollowSpawnerHiddenState(bool bInFollowSpawnerHiddenState);
	
	// Effect Audio
	void SetEffectAudio(const FString& AudioName);
	
	void RemoveAllParticleColorScaleUpdateTasks();
	void RemoveAllParticleRotationTasks();
	TSharedPtr<FKGNiagaraUpdateTaskUpdateParamByLinearSample> GetFloatLinearSampleUpdateTask(const FName& ParamName);
	
	float GetBaseTransparencyScaleFactor() const
	{
		return TransparencyScale * TransparencyScaleBySettings;
	}
	void RefreshTransparencyScale();
	
	template<typename T>
	typename TEnableIf<TIsDerivedFrom<T, FKGNiagaraUpdateTaskBase>::Value, TSharedPtr<T>>::Type GetOrCreateUpdateTask(EKGNiagaraUpdateTaskType TaskType)
	{
		auto& TaskIDs = TaskIDsByType.FindOrAdd(TaskType);
		if (TaskIDs.Num() > 0)
		{
			const auto TaskID = TaskIDs[0];
			return NiagaraUpdateTasks.Contains(TaskID) ? StaticCastSharedPtr<T>(NiagaraUpdateTasks[TaskID]) : nullptr;
		}
			
		return CreateUpdateTask<T>();
	}

	template<typename T>
	typename TEnableIf<TIsDerivedFrom<T, FKGNiagaraUpdateTaskBase>::Value, TSharedPtr<T>>::Type GetUpdateTask(int32 InTaskId)
	{
		TSharedPtr<FKGNiagaraUpdateTaskBase>* TaskBase = this->NiagaraUpdateTasks.Find(InTaskId);
		if (TaskBase == nullptr)
			return nullptr;
		return StaticCastSharedPtr<T>(*TaskBase);
	}
	
	template<typename T>
	typename TEnableIf<TIsDerivedFrom<T, FKGNiagaraUpdateTaskBase>::Value, TSharedPtr<T>>::Type CreateUpdateTask()
	{
		TSharedPtr<T> TaskPtr = MakeShared<T>();
		TaskPtr->SetNiagaraUpdateContextInfo(this);
		const auto TaskID = TaskPtr->GetTaskID();
		NiagaraUpdateTasks.Add(TaskID, TaskPtr);
		TaskIDsByType.FindOrAdd(TaskPtr->GetTaskType()).Add(TaskID);
		if (TaskPtr->GetTickBehavior() != EKGNiagaraTickBehavior::Never)
		{
			TickableNiagaraUpdateTaskIDs.Add(TaskID);
		}

		return TaskPtr;
	}
	
	void TickUpdateTasks(float DeltaTime);
	void RemoveUpdateTask(uint32 TaskID);
	void RemoveUpdateTasksByType(EKGNiagaraUpdateTaskType TaskType);
	void RemoveAllUpdateTasks();
	bool HasTaskByTaskType(EKGNiagaraUpdateTaskType TaskType) const
	{
		return TaskIDsByType.Contains(TaskType) && TaskIDsByType[TaskType].Num() > 0;
	}

	bool NeedsUpdate() const { return TickableNiagaraUpdateTaskIDs.Num() > 0; }
	bool IsHidden() const { return HiddenMask > 0; }

	FString ToString() const
	{
		return FString::Printf(TEXT("NiagaraEffectId: %d, NiagaraEffectPath: %s"), 
			NiagaraEffectId, *PlayNiagaraParams.NiagaraEffectPath);
	}
	
	void InternalSetNiagaraComponentHiddenState(bool bHidden);
	
	FKGPlayNiagaraParams PlayNiagaraParams;
	
	UPROPERTY(Transient)
	UNiagaraComponent* NiagaraComponent = nullptr;

	UPROPERTY(Transient)
	UNiagaraSystem* NiagaraSystem = nullptr;

	// NeedAttach时为RelativeTransform, 否则为 WorldSpaceTransform
	FTransform NewWorldSpaceOrRelativeSpawnTrans;

	// 如果一个 Attached 特效在 NiagaraComponent 或者 AttachComponent 还未创建好就需要 Detach 特效。
	// 需要等待 NiagaraComponent 创建成功，在 OnActivate 中执行 Detach 操作。
	bool bNeedDetachDeferred = false;

	// 这里标识特效需要在结束时清理add mesh上的缓存
	bool bNeedUnCacheNiagaraParamOnDestroy = false;

	bool bForceUseAbsoluteScale = false;
	// 特效本身有一个bFollowHidden, 这个是跟随spawner或者link target的显隐
	// bFollowSpawnerHiddenState是专用于确定特效是否跟随spawner显隐
	// follow spawner显隐, bFollowHidden && bFollowSpawnerHiddenState
	// follow link target显隐, bFollowHidden
	bool bFollowSpawnerHiddenState = true;
	
	TWeakObjectPtr<USceneComponent> AttachComponent;
	bool bRequiresAttachComponent = false;
	TOptional<int8> QualityLevel;
	// 初始外部给定的 TransparencyScale
	float TransparencyScale = 1.0f;
	// 战斗设置中给定的 TransparencyScale 作为最终结果传入
	float TransparencyScaleBySettings = 1.0f;
	uint64 HiddenMask = 0;

	EKGNiagaraPriorityType PriorityType = EKGNiagaraPriorityType::Low;
	
	TMap<EKGNiagaraUpdateTaskType, TArray<uint32>> TaskIDsByType;
	TSet<uint32> TickableNiagaraUpdateTaskIDs;
	TMap<uint32, TSharedPtr<FKGNiagaraUpdateTaskBase>> NiagaraUpdateTasks;

	// 特效资源加载时需要的资源列表
	bool bAssetLoaded = false;
	int AssetLoadID = 0;
	
	float AccumulatedTime = 0.0f;
	float DynamicPlayRate = 1.0f;
	
	int32 NiagaraEffectId = 0;
	// key: spawner id, value: 对应spawner销毁时是否销毁特效(true: 销毁, false: 隐藏)
	TMap<KGObjectID, FKGNiagaraExtraSpawnerInfo> ExtraSpawnerInfos;
	
	FKGTimeDilationTimer LifeTimeHandle;
	FKGTimeDilationTimer ChangeVisibilityTimerHandle;
	FTimerHandle WaitAttachComponentHandle;
	
	TWeakObjectPtr<UKGEffectManager> EffectManager;

#if KG_EFFECTMANAGER_ENABLE_STAT
	bool bEnableNiagaraEffectTypeDebugCheck = false;
	int32 SkillIdDebugUsage;
#endif
};
