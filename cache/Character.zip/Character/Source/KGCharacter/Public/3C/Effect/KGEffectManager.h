#pragma once

#include "Manager/KGObjectActorManager.h"
#include "CoreMinimal.h"
#include "3C/Effect/KGNiagaraScore.h"
#include "3C/Effect/KGNiagaraCommon.h"
#include "3C/Effect/KGNiagaraUpdateContext.h"
#include "Containers/Deque.h"
#include "Tickable.h"
#include "Niagara/Classes/NiagaraEffectType.h"
#include "Misc/CommonDefines.h"
#include "Manager/KGBasicManager.h"

#include "KGEffectManager.generated.h"

/*
 * 1, 关于在编辑器模式下第一次播放某个特效总是会报下面warning的问题
 * WorldNC Pool trying to reclaim a system for which it doesn't have a pool! Likely because SetAsset() has been called on this NC
 * 这是由于编辑器模式下，第一次播放niagara时，会尝试compile niagara, 此时会调用到UNiagaraComponentPool::RemoveComponentsBySystem, 
 * 导致 WorldParticleSystemPools 中对应的Niagara Pool被清理，导致相应NiagaraComponent ReleaseToPool的时候总是会出现相应的warning
 * 这个是引擎自身问题，看下来只会在编辑器模式下出一个warning，没有别的影响，暂不处理
 */

class AActor;
class UStaticMeshComponent;

UENUM()
enum class EKGNiagaraTimeoutState : uint8
{
	Deactivate = 0,
	Destroy = 1
};

UCLASS(Blueprintable, BlueprintType)
class KGCHARACTER_API UKGEffectManager : public UKGBasicManager, public FTickableGameObject
{
	GENERATED_BODY()

#pragma region Important
public:
	virtual void NativeInit() override;
	virtual void NativeUninit() override;
	virtual EManagerType GetManagerType() override { return EManagerType::EMT_EffectManager; }
	virtual void OnPostLoadMapWithWorld(UWorld* World) override;
	static UKGEffectManager* GetInstance(UObject* InContext)
	{
		return Cast<UKGEffectManager>(GetManagerByType(InContext, EManagerType::EMT_EffectManager));
	}
#pragma endregion Important


#pragma region Tick
public:
	virtual UWorld* GetTickableGameObjectWorld() const override { return GetOuter()->GetWorld(); }
	virtual ETickableTickType GetTickableTickType() const override { return IsTemplate() ? ETickableTickType::Never : ETickableTickType::Always; }
	virtual bool IsAllowedToTick() const override { return !IsTemplate(); }
	virtual TStatId GetStatId() const override { RETURN_QUICK_DECLARE_CYCLE_STAT(UKGEffectManager, STATGROUP_Tickables);}
	virtual void Tick(float DeltaTime) override;
	// virtual void OnPostLoadMapWithWorld(UWorld* World) override;
#if WITH_EDITOR
public:
	//编辑器下FTickableGameObject无法tick时，各编辑器主动调用
	UFUNCTION(BlueprintCallable)
	void EditorTick(float DeltaTime)
	{
		Tick(DeltaTime);
	}
#endif
	
#pragma endregion Tick

	
#pragma region Niagara Score
public:
	TSharedPtr<FKGNiagaraScoreManager> GetScoreManager() const { return NiagaraScoreManager; }

	void SetNiagaraScoreCapacity(
		int32 QualityLevel,
		float MinFPS, float MaxFPS,
		float MinCap, float MaxCap,
		const FString& PriorityPercentages);
	void SetNiagaraScoreData(const FString& InNiagaraSystemPath,
		uint8 Score_QL0_200, uint8 Score_QL0_500, uint8 Score_QL0_1000, uint8 Score_QL0_2000, uint8 Score_QL0_4000, uint8 Score_QL0_8000,
		uint8 Score_QL1_200, uint8 Score_QL1_500, uint8 Score_QL1_1000, uint8 Score_QL1_2000, uint8 Score_QL1_4000, uint8 Score_QL1_8000,
		uint8 Score_QL2_200, uint8 Score_QL2_500, uint8 Score_QL2_1000, uint8 Score_QL2_2000, uint8 Score_QL2_4000, uint8 Score_QL2_8000,
		uint8 Score_QL3_200, uint8 Score_QL3_500, uint8 Score_QL3_1000, uint8 Score_QL3_2000, uint8 Score_QL3_4000, uint8 Score_QL3_8000,
		uint8 Score_QL4_200, uint8 Score_QL4_500, uint8 Score_QL4_1000, uint8 Score_QL4_2000, uint8 Score_QL4_4000, uint8 Score_QL4_8000);
	void PrintNiagaraScoreDebugMessage() const;

	void SetBattleEffectScoreControlForceEnabled(int Value);
	void SetBattleEffectScoreControlEnabled(bool bEnabled);
	
	void SetEnvEffectSlowTickForceEnabled(int Value);
	void SetEnvEffectSlowTickEnabled(bool bEnabled);
	void SetEnvEffectConfig(float InCheckInterval, int InDistance) const;
	
	void SetBattleEffectIgnorePriority4(int Value);

	void SetBattleEffectSlowTickForceEnabled(int Value, bool bIsDistanceCheckEnable) const;
	void SetBattleEffectSlowTickEnabled(bool bEnabled) const;
	void SetBattleEffectSlowTickConfig(float InDistance) const;
	void SetSlowTickRate(int InSlowTickRate, bool bIsForce) const;
private:
	TSharedPtr<FKGNiagaraScoreManager> NiagaraScoreManager = nullptr;;
#pragma endregion Niagara Score

	
#pragma region Niagara
public:
	// 特效基础创建/销毁接口
	// lua调用版本
	// 这里只能将常用参数设置在这里, 不常用的参数需要通过专用接口额外设置, 避免这里的参数太多难以维护
	// @param CustomEffectID CustomEffectID大于0时使用外部传入EffectID, 否则内部自动生成EffectID
	int32 KAPI_EffectManager_CreateNiagaraSystemAtLocation(
		const FString& NiagaraEffectPath, int32 CustomEffectID,
		uint8 SearchSpawnLocationType, FName AttachPointName, bool bNeedFitGround,
		KGObjectID SpawnerID, KGEntityID SpawnerEntityID, KGEntityID InstigatorEntityID,
		bool bFollowHidden, bool bFollowSlomo, bool bFollowCameraFOV,
		float SpawnTrans_LX, float SpawnTrans_LY, float SpawnTrans_LZ,
		bool bUseQuat, float PitchOrX, float YawOrY, float RollOrZ, float W,
		float SpawnTrans_SX, float SpawnTrans_SY, float SpawnTrans_SZ,
		bool bIsPlayerEffect, bool bActivateImmediately, float TransparencyScale,
		float TotalLifeMs, uint8 NiagaraDestroyType, float BlendInTimeSeconds, float BlendOutTimeSeconds,
		float EffectPlayRate, bool bDestroyWhenSpawnerExitWorld, bool bBattleEffect,int32 NiagaraBusinessPriority);
	
	int32 KAPI_EffectManager_CreateNiagaraSystemAttached(
		const FString& NiagaraEffectPath, int32 CustomEffectID,
		uint8 SearchAttachComponentType, KGObjectID AttachComponentID, bool bAbsoluteScale, bool bAbsoluteRotation,
		FName AttachPointName, int32 LocationType, FName AttachComponentName, FName AttachComponentTag, UClass* ComponentClass,
		bool bCacheEvenIfDynamicMeshCtxNotFound, KGObjectID SpawnerID, KGEntityID SpawnerEntityID, KGEntityID InstigatorEntityID,
		bool bFollowHidden, bool bFollowSlomo, bool bFollowCameraFOV,
		float SpawnTrans_LX, float SpawnTrans_LY, float SpawnTrans_LZ,
		bool bUseQuat, float PitchOrX, float YawOrY, float RollOrZ, float W,
		float SpawnTrans_SX, float SpawnTrans_SY, float SpawnTrans_SZ,
		bool bIsPlayerEffect, bool bActivateImmediately, float TransparencyScale,
		float TotalLifeMs, uint8 NiagaraDestroyType, float BlendInTimeSeconds, float BlendOutTimeSeconds,
		float EffectPlayRate, bool bDestroyWhenSpawnerExitWorld, bool bBattleEffect, int32 NiagaraBusinessPriority);

	// simple 和 complex版本只差了5个参数, 暂时先只保留一个接口
	int32 KAPI_EffectManager_CreateSkillNiagaraSystemNew(
		const FString& NiagaraEffectPath, int32 CustomEffectID,
		uint8 SearchAttachComponentType, const FName& AttachComponentName, 
		bool bAbsoluteScale, EKGNiagaraPositionMode PositionMode, EKGNiagaraRotationMode RotationMode,
		FName AttachPointName, KGEntityID RotationTargetEntityID, bool bNeedFitGround, bool bCacheEvenIfDynamicMeshCtxNotFound,
		KGObjectID SpawnerID, KGEntityID SpawnerEntityID, KGEntityID InstigatorEntityID,
		float SpawnTrans_LX, float SpawnTrans_LY, float SpawnTrans_LZ,
		float Pitch, float Yaw, float Roll, 
		float SpawnTrans_SX, float SpawnTrans_SY, float SpawnTrans_SZ,
		float TransparencyScale, float TotalLifeMs, float BlendOutTimeSeconds,
		float EffectPlayRate, int32 NiagaraBusinessPriority);

	int32 KAPI_EffectManager_CreateNiagaraSystemByEffectDataID(
		int32 EffectDataID, float Duration, EKGNiagaraDestroyType DestroyType, float BlendOutTimeSeconds, bool bHasEffectTag, int32 ExtraEffectTag,
		KGActorID SpawnerID, KGEntityID SpawnerEntityID, uint32 CustomEffectID)
	{
		return CreateNiagaraSystemByAttachEffectDataID(
			EffectDataID, Duration, DestroyType, true, BlendOutTimeSeconds, bHasEffectTag, ExtraEffectTag, SpawnerID, SpawnerEntityID, CustomEffectID);
	}
	int32 CreateNiagaraSystemByAttachEffectDataID(
		int32 EffectDataID, float Duration, EKGNiagaraDestroyType DestroyType, bool bOverrideBlendOutTime, float BlendOutTimeSeconds,
		bool bHasEffectTag, int32 ExtraEffectTag, KGActorID SpawnerID, KGEntityID SpawnerEntityID, uint32 CustomEffectID=0);

	int32 KAPI_EffectManager_CreateWeaponDissolveNiagaraEffect(
		KGActorID WeaponActorID, KGActorID WeaponOwnerID, KGEntityID WeaponOwnerEntityID,
		const FString& SKWeaponDissolveEffectPath, const FString& SMWeaponDissolveEffectPath, float DissolveTime, bool bDissolveIn, 
		float EffectPlayRate, int32 CustomEffectID);
	int32 CreateWeaponDissolveNiagaraEffect(
		AActor* WeaponActor, KGActorID WeaponOwnerID, KGEntityID WeaponOwnerEntityID,
		const FString& SKWeaponDissolveEffectPath, const FString& SMWeaponDissolveEffectPath, float DissolveTime, bool bDissolveIn, 
		float EffectPlayRate, int32 CustomEffectID=0);
	
	bool KAPI_EffectManager_DeactivateNiagaraSystem(int32 NiagaraEffectId, bool bOverrideBlendOut, bool bNewNiagaraBlendOut, bool bOverrideBlendOutTime, float NewBlendOutTimeSeconds)
	{
		return DeactivateNiagaraSystem(NiagaraEffectId, bOverrideBlendOut, bNewNiagaraBlendOut, bOverrideBlendOutTime, NewBlendOutTimeSeconds);
	}
	bool DestroyNiagaraSystem(int32 NiagaraEffectId);
	void KAPI_EffectManager_DeactivateNiagaraSystemsByEffectTag(
		KGObjectID SpawnerId, int32 EffectTag, bool bOverrideBlendOut, bool bNewNiagaraBlendOut, bool bOverrideBlendOutTime, float NewBlendOutTimeSeconds);
	void KAPI_EffectManager_DestroyNiagaraSystemsByEffectTag(KGObjectID SpawnerId, int32 EffectTag);
	void DestroyNiagarasBySpawnerId(KGObjectID SpawnerId, bool bSpawnerExitWorld);
	void DeactivateNiagarasBySpawnerId(KGObjectID SpawnerId, bool bSpawnerExitWorld);
	void DestroyAllNiagaras();
	// cpp 调用版本特效创建
	int32 CreateNiagaraSystem(const FKGPlayNiagaraParams& PlayNiagaraParams);
	bool DeactivateNiagaraSystem(int32 NiagaraEffectId, bool bOverrideBlendOut, bool bNewNiagaraBlendOut, bool bOverrideBlendOutTime, float NewBlendOutTimeSeconds);
	bool DeactivateNiagaraSystem(int32 NiagaraEffectId) { return DeactivateNiagaraSystem(NiagaraEffectId, false, false, false, 0.0f); }
	
	// 特效参数更新等接口
	// external usage exposed to lua
	// 由于本身特效资源的加载是异步的, 且特效创建也会在cpp中分帧执行, 当外部在特效挂接组件存在时播放了特效, 并在特效真正创建之前销毁了挂接组件, 此时特效播放就会失败
	// 对于不存在异步加载和分帧创建的情况下, 挂接组件destroy会让特效detach, 并重新attach到挂接组件的parent（挂接组件是非root component的情况）
	// 相应地，为了屏蔽特效管理器内部的异步处理细节, 这里需要外部挂接组件销毁时通知到特效管理器, 在特效未创建之前，先更新特效创建的参数（改为在attach component最后一帧位置处的世界空间位置播放）
	// 为了简化逻辑, 这里不去处理destroy component时对应的promote children逻辑, 目前业务上本身也没有类似的用法
	void NotifyRemoveComponent(KGObjectID ActorId, KGObjectID ComponentId);
	// 对于技能特效来说, 很多特效会挂接在DynamicMesh上播放, 在特效播放时, 存在较大可能这些dynamic mesh component并未创建好
	// 此时特效会正常加载, 并在加载结束时再检查一次对应的attach component是否创建好, 如果还未创建好, 则等待最多5秒的时间, 如果还是未创建好, 则销毁特效
	void NotifyNiagaraAttachComponentCreated(int32 NiagaraEffectId);
	void SetNiagaraDelayDestroy(int32 NiagaraEffectId, float DelayDestroyTimeMs);
	void UpdateAllNiagaraFloatParamBySpawnerId(KGObjectID SpawnerId, const FName& ParamName, float InVal);
	void UpdateNiagaraFloatParam(int32 NiagaraEffectId, const FName& ParamName, float InVal);
	void UpdateNiagaraVec2Param(int32 NiagaraEffectId, const FName& ParamName, float InX, float InY);
	void UpdateNiagaraVec3Param(int32 NiagaraEffectId, const FName& ParamName, float InX, float InY, float InZ);
	void KAPI_EffectManager_UpdateNiagaraTextureParam(int32 NiagaraEffectId, const FName& ParamName, const FString& TexturePath);
	void KAPI_EffectManager_RemoveNiagaraTextureParam(int32 NiagaraEffectId, const FName& ParamName);
	void UpdateAllNiagaraLinearColorParamBySpawnerId(KGObjectID SpawnerId, const FName& ParamName, float InR, float InG, float InB, float InA);
	void UpdateAllSpiritualVisionMeshColorParam(KGObjectID SpawnerId, const FName& ParamName, bool bEnableSpiritualVision);
	void UpdateNiagaraLinearColorParam(int32 NiagaraEffectId, const FName& ParamName, float InR, float InG, float InB, float InA);
	void UpdateNiagaraFollowActor(int32 NiagaraEffectId, const FName& ParamName, KGObjectID FollowActorId, bool bAbsoluteNiagaraRotationInFollow);
	void UpdateNiagaraCameraArmLengthParam(int32 NiagaraEffectId, const FName& ParamName);
	void UpdatePositionWithArcParams(int32 NiagaraEffectId, const FName& ParamName, float Radius, float StartRelativeYaw, float RotateAngle, float Duration);
	bool UpdateLinearSampleParamTargetValue(int32 NiagaraEffectId, const FName& ParamName, float TargetValue, bool bUseNewDuration, float NewDuration);
	void AddOrUpdateLinearSampleParamTargetValueByEffectTag(
		EKGNiagaraEffectTag EffectTag, const FName& ParamName, float StartValue, float TargetValue, bool bUseNewDuration, float NewDuration);
	void AddOrUpdateLinearSampleParamTargetValue(
		int32 NiagaraEffectId, const FName& ParamName, float StartValue, float TargetValue, bool bUseNewDuration, float NewDuration);
	// 材质参数更新任务结束并停在当前值
	void KAPI_EffectManager_FinishLinearSampleParamTask(int32 NiagaraEffectId, const FName& ParamName) { FinishLinearSampleParamTask(NiagaraEffectId, ParamName); }
	void FinishLinearSampleParamTask(int32 NiagaraEffectId, const FName& ParamName);
	void SetNiagaraRenderCustomDepthBySpawnerId(KGObjectID SpawnerId, bool bEnableCustomDepth, float CustomDepthStencilValue);
	// 对于custom depth来说, 这里没有业务同时涉及到
	// 1) 特效本身需要设置一个固定的custom depth
	// 2) 需要根据特效所属spawner设置一个全局custom depth
	// 因此这里暂时先只提供一个force and weak barrier的控制接口, 后续需要时再按需扩展
	void ForceSetNiagaraRenderCustomDepthBySpawnerId(KGObjectID SpawnerId, bool bEnableCustomDepth, float CustomDepthStencilValue);
	void RevertForceNiagaraCustomDepthControlBySpawnerId(KGObjectID SpawnerId);
	void UpdateNiagaraHiddenState(int32 NiagaraEffectId, bool bHidden, uint8 HiddenReason, bool bUseBlendTime, float BlendTimeSeconds);
	void KAPI_EffectManager_UpdateNiagaraHiddenState(
		int32 NiagaraEffectId, bool bHidden, uint8 HiddenReason, bool bUseBlendTime, float BlendTimeSeconds)
	{
		UpdateNiagaraHiddenState(NiagaraEffectId, bHidden, HiddenReason, bUseBlendTime, BlendTimeSeconds);
	}
	void UpdateNiagaraHiddenStateByEffectTag(int32 EffectTag, bool bHidden, uint8 HiddenReason, bool bUseBlendTime, float BlendTimeSeconds);
	void KAPI_EffectManager_UpdateNiagaraHiddenStateByEffectTag(
		int32 EffectTag, bool bHidden, uint8 HiddenReason, bool bUseBlendTime, float BlendTimeSeconds)
	{
		UpdateNiagaraHiddenStateByEffectTag(EffectTag, bHidden, HiddenReason, bUseBlendTime, BlendTimeSeconds);
	}
	void UpdateEffectVisibilityBySpawnerID(KGObjectID SpawnerId, bool bVisible, uint8 HiddenReason);
	void UpdateSystemUserVariableMeshComponent(
		int32 NiagaraEffectId, const FString& ParamName, KGObjectID MeshCompID, const TArray<FName>& SkeletalMeshFilterBones,
		bool bUseCloneMeshCompOnSystemUserVariableMeshComponent, bool bUseNiagaraComponentTransform);
	void AddLinearSampleVectorParams(
		int32 NiagaraEffectId, const FName& ParamName, float StartX, float StartY, float StartZ, float EndX, float EndY, float EndZ,
		float Duration, bool bUseNiagaraAccumulatedTime);
	void AddLinearSampleFloatParams(
		int32 NiagaraEffectId, const FName& ParamName, float StartVal, float EndVal, float Duration, bool bUseNiagaraAccumulatedTime);
	void SetNiagaraFaceToLocation(int32 NiagaraEffectId, float InLocationX, float InLocationY);
	void KAPI_EffectManager_SetNiagaraFaceToActor(int32 NiagaraEffectId, KGObjectID FacingTargetActorId, EKGNiagaraFaceToActorRotationType RotationType);
	void KAPI_EffectManager_SetNiagaraFaceToCamera(int32 NiagaraEffectId, EKGNiagaraFaceToActorRotationType RotationType) { SetNiagaraFaceToCamera(NiagaraEffectId, RotationType); }
	void SetNiagaraFaceToCamera(int32 NiagaraEffectId, EKGNiagaraFaceToActorRotationType RotationType);
	void SetNiagaraFollowCameraFOV(int32 NiagaraEffectId);
	void SetNiagaraRenderCustomDepth(int32 NiagaraEffectId, bool bEnableCustomDepth, int32 CustomDepthStencilValue);
	void SetNiagaraComponentTags(int32 NiagaraEffectId, const TArray<FName>& ComponentTags);
	int32 SetNiagaraSplineLinkToComponent(
		int32 NiagaraEffectId, const FString& SplineBPPath, const FString& SplineUserVarName, KGObjectID TargetComponentId, FName TargetSocketName,
		EKGNiagaraBehaviorOnExtraSpawnerDestroy Behavior, EKGNiagaraHiddenReason HiddenReason);
	int32 SetNiagaraSplineLinkToLocation(int32 NiagaraEffectId, const FString& SplineBPPath, const FString& SplineUserVarName,
		float RelativeYaw, float TargetLocationX, float TargetLocationY, float TargetLocationZ, bool bCastToGround);
	// 注意这里 target location是 spawner 局部空间的坐标
	int32 UpdateNiagaraSplineLinkTargetLocation(
		int32 NiagaraEffectId, int32 UpdateTaskId, float Yaw, float TargetLocationX, float TargetLocationY, float TargetLocationZ);
	void KAPI_EffectManager_UpdateNiagaraSplineLinkTargetComponent(
		int32 NiagaraEffectId, int32 UpdateTaskId, KGObjectID TargetComponentId, FName TargetSocketName,
		EKGNiagaraBehaviorOnExtraSpawnerDestroy Behavior, EKGNiagaraHiddenReason HiddenReason);
	void AddFloatCurveParams(
		int32 NiagaraEffectId, FName ParamName, const FString& CurvePath, bool bNeedRemap, float RemapTime);
	bool IsNiagaraEffectValid(int32 EffectID) { return NiagaraUpdateContexts.Contains(EffectID); }
	void SetNiagaraRenderInMainPass(int32 EffectID, bool bRenderInMainPass);
	void SetNiagaraTranslucentSortPriority(int32 EffectID, int32 TranslucencySortPriority);
	void SetNiagaraTranslucencySortDistanceOffset(int32 EffectID, int32 TranslucencySortDistanceOffset);
	void AppendNiagaraExtraEffectTags(int32 EffectID, const TArray<int32>& ExtraEffectTags);
	// 目前绝大部分特效都只有一个extra effect tag, 单独提供一个接口, 避免Lua层操作TArray
	void AppendNiagaraExtraEffectTag(int32 EffectID, int32 ExtraEffectTag);
	void KAPI_EffectManager_EnableNiagaraEffectTypeDebugCheck(int32 EffectID, int32 SkillIdDebugUsage);
	void SetNiagaraEnableSpiritualVisionMeshColorChange(int32 EffectID, float InR, float InG, float InB, float InA);
	// particle color scale的设置目前有三块业务在用
	// 1) 支持设置P3角色的特效强度, 这个是作为particle color scale的最大值
	// 2) 支持外部通过设置particle color scale curve来控制特效淡入淡出
	// 3) 支持外部通过linear sample的方式来控制特效淡入淡出
	void KAPI_EffectManager_SetParticleColorScaleUpdateCurve(int32 NiagaraEffectId, const FString& CurvePath, float Duration);
	// 通过特效参数对特效进行淡出, 先保留这个做法, 基于ParticleColorScale的淡入淡出并不一定适用所有特效
	void KAPI_EffectManager_BlendOutNiagaraByNiagaraParam(
		int32 NiagaraEffectId, const FString& CurvePath, const FName& ParamName, float StartVal, float EndVal, float Duration);
	void KAPI_EffectManager_SetNiagaraFollowActorRotation(int32 NiagaraEffectId);
	void KAPI_EffectManager_UpdateParamByHeightDiff(int32 NiagaraEffectId, const FString& CurvePath, const FName& ParamName, float VisibilityChangeBlendTime, float HeightDiffHalfLifeTime);
	void KAPI_EffectManager_SetNiagaraStickOnGround(int32 NiagaraEffectId, float UpCheckDistance, float DownCheckDistance, bool bUseNiagaraAsPivotPos);
	// 当前会修改actor custom time dilation的地方非常少, 且大部分特效需要follow slomo,
	// 因此这里去掉niagara主动去拿custom time dilation的逻辑, 统一由外部控制特效的slomo参数
	// actor custom time dilation变化时手动更新对应特效的play rate参数
	void UpdateNiagaraPlayRateBySpawnerID(KGActorID SpawnerID);
	void KAPI_EffectManager_SetEffectAudio(int32 NiagaraEffectId, const FString& AudioName);
	void KAPI_EffectManager_SetNiagaraParamByEffectID(int32 NiagaraEffectId, uint32 ParamID);
	void KAPI_EffectManager_ChangeNiagaraAttachSocket(int32 NiagaraEffectId, const FName& NewSocketName);
	void KAPI_EffectManager_DetachNiagaraEffect(int32 NiagaraEffectId);
	void KAPI_EffectManager_SetActorForceUseAbsoluteScale(KGActorID ActorID, bool bForceUseAbsoluteScale);
	void KAPI_EffectManager_SetNiagaraFollowSpawnerHiddenState(uint32 NiagaraEffectId, bool bFollowSpawnerHiddenState);
	
	// internal usage exposed to lua
	void AddSurfaceCdInfo(const FName& EffectPath, float CdTimeSeconds) { SurfaceCdInfo.Add(EffectPath, CdTimeSeconds); }
	bool GetSurfaceCdInfo(const FName& EffectPath, float& OutCdTimeSeconds);
	void SetInWaterEffectOffset(float WaterEffectOffset) { InWaterEffectOffset = WaterEffectOffset; }
	float GetInWaterEffectOffset() const { return InWaterEffectOffset; }
	int32 GenerateEffectId();
	void SetNiagaraTickTimeLimit(float InTimeLimitSeconds) { TickTimeLimitSeconds = FMath::Max(0.001f, InTimeLimitSeconds); }
	void KAPI_EffectManager_SetWaitAttachComponentTimeoutSeconds(float InTimeoutSeconds)
	{
		// 设置特效等待attach component创建的超时时间, 默认是5秒
		WaitAttachComponentTimeoutSeconds = FMath::Max(0.001f, InTimeoutSeconds);
	}
	void KAPI_EffectManager_SetCheckGroundInfo(
		int32 InGroundCheckObjectType, float InCheckGroundOffsetUp, float InCheckGroundOffsetDown, float FinalAdjustment)
	{
		// 设置特效检查地面信息的object types和距离
		GroundCheckObjectType = static_cast<TEnumAsByte<ECollisionChannel>>(InGroundCheckObjectType);
		GroundCheckOffset = FVector(InCheckGroundOffsetUp, InCheckGroundOffsetDown, FinalAdjustment);
	}
	
	void KAPI_EffectManager_SetNiagaraQualityInfo(
		EKGNiagaraQualityLevel InPlayerNiagaraQualityLevel,
		EKGNiagaraParticleColorScaleLevel InPlayerParticleColorScaleLevel,
		EKGNiagaraQualityLevel InOtherPlayerNiagaraQualityLevel,
		EKGNiagaraParticleColorScaleLevel InOtherPlayerParticleColorScaleLevel,
		EKGNiagaraQualityLevel InEnvNiagaraQualityLevel,
		EKGNiagaraParticleColorScaleLevel InEnvParticleColorScaleLevel);
	EKGNiagaraQualityLevel GetPlayerNiagaraQualityLevel() const { return PlayerNiagaraQualityLevel; }
	float GetPlayerTransparencyScaleFactor() const { return PlayerTransparencyScaleFactor; }
	EKGNiagaraQualityLevel GetOtherPlayerNiagaraQualityLevel() const { return OtherPlayerNiagaraQualityLevel; }
	float GetOtherPlayerTransparencyScaleFactor() const { return OtherPlayerTransparencyScaleFactor; }
	EKGNiagaraQualityLevel GetEnvNiagaraQualityLevel() const { return EnvNiagaraQualityLevel; }
	float GetEnvTransparencyScaleFactor() const { return EnvTransparencyScaleFactor; }
	bool IsEnvNiagaraEffect(UNiagaraComponent* NiagaraComponent) const; 
	void KAPI_EffectManager_SetEnvNiagaraEffectTypeAssetPaths(const TArray<FString>& AssetPaths);
	void KAPI_EffectManager_SetOtherPlayerNiagaraPriorityThresholdIgnoreHidden(uint32 InThreshold) { OtherPlayerNiagaraPriorityThresholdIgnoreHidden = InThreshold; }
	uint32 GetOtherPlayerNiagaraPriorityThresholdIgnoreHidden() const { return OtherPlayerNiagaraPriorityThresholdIgnoreHidden; }
	
	void KAPI_EffectManager_DisableQualityLevelOffsetAndTransparencyScale(bool bDisable)
	{
		bDisableQualityLevelOffsetAndTransparencyScale = bDisable;
	}
	bool IsDisableQualityLevelOffsetAndTransparencyScale() const { return bDisableQualityLevelOffsetAndTransparencyScale; }
	
	TEnumAsByte<ECollisionChannel> GetGroundCheckObjectType() const { return GroundCheckObjectType; }
	void CheckGroundLocation(AActor* Spawner, bool bUsePlaneLocation, FVector& InOutLocation);

	void KAPI_EffectManager_SetWeaponDissolveEffectInfo(
		const FString& InWeaponDissolveSMParamName, const FString& InWeaponDissolveSKParamName, FName WeaponDissolveExistTimeParamName, float InWeaponDissolveExistingTimeRatio);
	
	// cpp use only
	UNiagaraComponent* GetNiagaraComponentByNiagaraEffectId(int32 NiagaraEffectId);
	FKGNiagaraUpdateContext* GetNiagaraUpdateContextPtr(int32 NiagaraEffectId) { return NiagaraUpdateContexts.Find(NiagaraEffectId); }
	bool GetNiagaraEffectIdByNiagaraComponent(UNiagaraComponent* NiagaraComponent, int32& OutNiagaraEffectId);

	// 设置timeout时间, 如果存在则直接覆盖
	void SetNiagaraLifeTimeTimer(int32 NiagaraEffectId, EKGNiagaraTimeoutState State, float DelayTimeSeconds);
	void RemoveNiagaraLifeTimeTimer(int32 NiagaraEffectId);
	
	void SetNiagaraWaitAttachComponentTimer(FKGNiagaraUpdateContext& InOutContext, float WaitTimeSeconds);
	void ClearNiagaraWaitAttachComponentTimer(FKGNiagaraUpdateContext& InOutContext);
	void OnNiagaraWaitAttachComponentTimerTimeout(int32 NiagaraEffectId);

	bool GetEffectTagMask(EKGNiagaraEffectTag EffectTag, TBitArray<>& OutMask) const;
	bool GetPlayNiagaraParams(TWeakObjectPtr<UNiagaraComponent> NiagaraComponentWeakPtr, FKGPlayNiagaraParams& OutParams);
	bool DoesActorForceUseAbsoluteScale(KGActorID ActorID);
	
	void SetActorEnableTimeDilation(KGActorID ActorID, bool bEnableTimeDilation);
	
	DECLARE_MULTICAST_DELEGATE_TwoParams(EffectManagerNiagaraComponentChangeDelegate, UNiagaraComponent* ComponentPtr, const FKGPlayNiagaraParams& Params);
	static EffectManagerNiagaraComponentChangeDelegate OnNiagaraComponentActive;
	static EffectManagerNiagaraComponentChangeDelegate OnNiagaraComponentDeActive;
protected:
	int32 ScriptCreateNiagaraSystemCommon(
		const FString& NiagaraEffectPath, int32 CustomEffectID,
		const FName& InAttachComponentName,  bool bCacheEvenIfDynamicMeshCtxNotFound,
		bool bNeedAttach, const FKGAttachedNiagaraSpawnInfo& AttachedSpawnInfo, const FKGUnattachedNiagaraSpawnInfo& UnattachedSpawnInfo,
		KGObjectID SpawnerID, KGEntityID SpawnerEntityID, KGEntityID InstigatorEntityID,
		bool bFollowHidden, bool bFollowSlomo, bool bFollowCameraFOV, bool bNeedFitGround,
		bool bIsPlayerEffect, bool bActivateImmediately, float TransparencyScale,
		float TotalLifeMs, uint8 NiagaraDestroyType, float BlendInTimeSeconds, float BlendOutTimeSeconds,
		float EffectPlayRate, bool bDestroyWhenSpawnerExitWorld, bool bBattleEffect, int32 NiagaraBusinessPriority);
	static void AssembleSpawnTrans(
		float SpawnTrans_LX, float SpawnTrans_LY, float SpawnTrans_LZ,
		bool bUseQuat, float PitchOrX, float YawOrY, float RollOrZ, float W,
		float SpawnTrans_SX, float SpawnTrans_SY, float SpawnTrans_SZ, FTransform& OutSpawnTrans);
	
	static int32 GenerateNiagaraEffectId();
	static int32 GenerateNiagaraBudgetToken();
	
	void OnNiagaraLifeTimeTimerExpired(int32 NiagaraEffectId, EKGNiagaraTimeoutState State);
	
	void RefreshNiagaraStateOnActivate(int32 NiagaraEffectId, FKGNiagaraUpdateContext& InOutNiagaraUpdateContext);
	void InternalSetLinearSampleParticleColorScaleUpdateTask(FKGNiagaraUpdateContext& InOutNiagaraUpdateContext, bool bBlendIn, float Duration, bool bInitBlendIn);
	
	void SetTransparencyScaleByEffectSettings(EKGNiagaraEffectTag EffectTag, float TransparencyScaleBySettings);
	void SetQualityLevelByEffectSettings(EKGNiagaraEffectTag EffectTag, EKGNiagaraQualityLevel QualityLevelBySettings);
	void OnNiagaraSystemInstancePreCreated(UNiagaraComponent* NiagaraComponent);
	void OnNiagaraSystemInstanceDeallocated(FNiagaraSystemInstancePtr& InNiagaraSystemInstancePtr);
	
	UNiagaraComponent* ActivateNiagaraSystem(int32 NiagaraEffectId);
	void DetachNiagaraEffect(int32 NiagaraEffectId);
	void InternalDetachNiagaraEffect(FKGNiagaraUpdateContext& InOutNiagaraUpdateContext);
	void BindEffectToSpawner(int32 NiagaraEffectId, KGObjectID SpawnerID, bool bIsSpawnerEffectOwner,
		EKGNiagaraBehaviorOnExtraSpawnerDestroy Behavior, EKGNiagaraHiddenReason HiddenReason, FKGNiagaraUpdateContext& InOutNiagaraUpdateContext);
	void BindEffectToLinkedComponent(
		KGObjectID ComponentID, int32 NiagaraEffectId, EKGNiagaraBehaviorOnExtraSpawnerDestroy Behavior, EKGNiagaraHiddenReason HiddenReason,
		FKGNiagaraUpdateContext& InOutNiagaraUpdateContext);
	// 进保留特效创建者对应的spawner 其他所有link目标对应的spawner都清理掉
	void ClearAllExtraSpawners(FKGNiagaraUpdateContext& InOutNiagaraUpdateContext);
	void DestroyOrDeactivateNiagarasBySpawnerId(KGObjectID SpawnerId, bool bSpawnerExitWorld, bool bDestroy);
	
	void InternalOnNiagaraAssetsLoaded(int InLoadID, UObject* NiagaraSystem, int32 NiagaraEffectId, bool bAsyncAssetLoadCallback);
	UFUNCTION()
	void InternalOnNiagaraSystemFinished(UNiagaraComponent* NiagaraComponent);
	bool InternalDestroyNiagaraSystem(int32 NiagaraEffectId);
	// 如果是bInitHiddenState, 则只要是当前hidden mask不为0, 则尝试隐藏特效
	void InternalUpdateNiagaraHiddenState(FKGNiagaraUpdateContext& InOutNiagaraUpdateContext, bool bHidden, uint8 HiddenReason, bool bInitHiddenState);
	void InternalUpdateNiagaraHiddenStateWithBlendTime(FKGNiagaraUpdateContext& InOutNiagaraUpdateContext, bool bHidden, uint8 HiddenReason, float BlendTime);
	void OnNiagaraHiddenDelayTimerExpired(int32 NiagaraEffectId, bool bHidden, uint8 HiddenReason);

	void UpdateDilationTimers(float DeltaTime);
	void SetTimerModeByActorID(KGActorID ActorID, bool bEnableTimeDilation);
	
	void UpdateNiagaras(float DeltaTime);
	void UpdatePerNiagaraContext(FKGNiagaraUpdateContext& InOutNiagaraUpdateContext, float DeltaTime);
	// 如果更新的参数会影响到特效是否需要tick 需要重新刷新needs update状态
	void UpdateTickableNiagaraIds(FKGNiagaraUpdateContext& InOutNiagaraUpdateContext);
	
	// 单个特效创建的开销可能比较高, 为了避免同一帧创建特效数量过多导致卡顿, 这里加了个队列分帧创建特效
	TDeque<int32> PendingActiveNiagaraIds;
	// 仅需要tick更新的特效id
	TSet<int32> TickableNiagaraIds;
	// 用于 niagara system finish时，快速查询到对应的niagara update context并清理对应的状态
	// 这里的niagara component是 effect manager管理的niagara component
	TMap<TWeakObjectPtr<UNiagaraComponent>, int32> NiagaraComponentToNiagaraId;
	// 这里是为了支持设置所有场景特效质量和透明度
	TSet<TWeakObjectPtr<UNiagaraComponent>> NativeEnvNiagaraComponents;
	
	TSet<KGActorID> ActorsWithTimeDilation;
	
	UPROPERTY(Transient)
	TSet<UNiagaraEffectType*> EnvNiagaraEffectTypes;
	
	UPROPERTY(Transient)
	TMap<int32, FKGNiagaraUpdateContext> NiagaraUpdateContexts;
	TMap<KGObjectID, TSet<int32>> SpawnerIdToEffectIds;
	TMap<EKGNiagaraEffectTag, TSet<int32>> EffectTagToEffectIds;
	TMap<EKGNiagaraEffectTag, TBitArray<>> EffectTagHiddenState;

	// 设置在这里面的Actor, 其创建的特效会强制使用absolute scale
	TSet<KGActorID> ForceUseAbsoluteScaleActors;
	
	// 角色水面特效播放数据, 为了避免每个角色初始化时都初始化相同数据, 直接放在effect manager上
	float InWaterEffectOffset = 5.0f;
	TMap<FName, float> SurfaceCdInfo; 
	// 默认单帧最多给5ms时间, 可以在lua层修改上限
	float TickTimeLimitSeconds = 0.005;
	// 等待attach component创建的超时时长
	float WaitAttachComponentTimeoutSeconds = 5.0f;
	TEnumAsByte<ECollisionChannel> GroundCheckObjectType;
	FVector GroundCheckOffset = FVector(-300.0f, 300.0f, 0.2f);

	// weapon dissolve params
	FString WeaponDissolveSMParamName;
	FString WeaponDissolveSKParamName;
	FName WeaponDissolveExistTimeParamName;
	float WeaponDissolveExistingTimeRatio = 0.2;
	
	bool bDisableQualityLevelOffsetAndTransparencyScale = false;
	
	EKGNiagaraQualityLevel PlayerNiagaraQualityLevel = EKGNiagaraQualityLevel::UnInit;
	EKGNiagaraParticleColorScaleLevel PlayerParticleColorScaleLevel = EKGNiagaraParticleColorScaleLevel::UnInit;
	float PlayerTransparencyScaleFactor = 1.0f;
	
	EKGNiagaraQualityLevel OtherPlayerNiagaraQualityLevel = EKGNiagaraQualityLevel::UnInit;
	EKGNiagaraParticleColorScaleLevel OtherPlayerParticleColorScaleLevel = EKGNiagaraParticleColorScaleLevel::UnInit;
	float OtherPlayerTransparencyScaleFactor = 1.0f;
	
	EKGNiagaraQualityLevel EnvNiagaraQualityLevel = EKGNiagaraQualityLevel::UnInit;
	EKGNiagaraParticleColorScaleLevel EnvParticleColorScaleLevel = EKGNiagaraParticleColorScaleLevel::UnInit;
	float EnvTransparencyScaleFactor = 1.0f;
	int32 OtherPlayerNiagaraPriorityThresholdIgnoreHidden = 4;
	
#pragma endregion Niagara

	
#pragma region NativeNiagaraComponent

	uint32 KAPI_EffectManager_AddNativeNiagaraLinearSampleFloatParam(
		KGObjectID NiagaraComponentID, const FName& ParamName, float StartVal, float EndVal, float Duration);
	uint32 KAPI_EffectManager_AddNativeNiagaraCurveParam(
		KGObjectID NiagaraComponentID, const FName& ParamName, const FString& CurvePath, bool bNeedRemap, float RemapTime);
	void KAPI_EffectManager_RemoveNativeNiagaraUpdateTask(uint32 TaskID) { RemoveNativeNiagaraUpdateTask(TaskID); }
	void KAPI_EffectManager_SetNativeNiagaraParamsByParamID(KGObjectID NiagaraComponentID, uint32 ParamID);
	void KAPI_EffectManager_SetNativeNiagaraParamsByNiagaraTagAndParamID(KGActorID ActorID, const FName& CompTag, uint32 ParamID);
	
	uint32 AddNativeNiagaraLinearSampleFloatParam(
		UNiagaraComponent* NiagaraComponent, const FName& ParamName, float StartVal, float EndVal, float Duration);
	uint32 AddNativeNiagaraCurveParam(
		UNiagaraComponent* NiagaraComponent, const FName& ParamName, const FString& CurvePath, bool bNeedRemap, float RemapTime);
	void SetNativeNiagaraParamsByParamID(UNiagaraComponent* NiagaraComponent, uint32 ParamID);
	void UpdateNativeNiagaraUpdateTasks(float DeltaTime);
	void RemoveNativeNiagaraUpdateTask(uint32 TaskID);
	
	TMap<uint32, TSharedPtr<FKGNiagaraUpdateTaskBase>> NativeNiagaraUpdateTasks;
#pragma endregion NativeNiagaraComponent
};
