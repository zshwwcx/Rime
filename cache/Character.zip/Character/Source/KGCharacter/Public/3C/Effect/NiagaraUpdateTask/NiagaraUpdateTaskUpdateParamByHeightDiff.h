﻿#pragma once
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskBase.h"

// 根据创建者以及特效的高度差从曲线中采样并设置指定特效参数
// 如果从曲线中采样为0则逐渐淡出并隐藏特效
struct FKGNiagaraUpdateTaskUpdateParamByHeightDiff : FKGNiagaraUpdateTaskBase
{
	virtual EKGNiagaraTickBehavior GetTickBehavior() const override { return EKGNiagaraTickBehavior::EveryFrame; }
	virtual EKGNiagaraUpdateTaskType GetTaskType() const override { return EKGNiagaraUpdateTaskType::UpdateParamByHeightDiff; }
	virtual bool OnTaskInit(const FKGNiagaraUpdateTaskTarget& InTaskTarget) override;
	virtual bool OnTaskUpdate(float DeltaTime, const FKGNiagaraUpdateTaskTarget& InTaskTarget) override;
	virtual bool OnTaskDestroy(const FKGNiagaraUpdateTaskTarget& InTaskTarget) override;

	void InternalOnFloatCurveAssetLoaded(int InLoadID, UObject* LoadedAssets);
	
	FString CurvePath;
	FName ParamName;
	float VisibilityChangeBlendTime = 0.2f;
	float CapsuleHalfHeight = 0.0f;
	float HeightDiffHalfLifeTime = 0.1f;

	TWeakObjectPtr<AActor> SpawnerActor;
	TStrongObjectPtr<UCurveFloat> CurveAsset;
	int32 CurveAssetLoadId = 0;
	bool bCurNiagaraHidden = false;
	TOptional<float> LastFrameHeightDiff;
};
