// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "3C/Camera/CameraAction/CameraActionBase.h"
#include "CameraAIMove.generated.h"

/**
 * 
 */
UCLASS()
class KGCHARACTER_API UCameraAIMove : public UCameraActionBase
{
	GENERATED_BODY()

public:
	void Init(const TArray<FVector>& InWorldLocations, const TArray<FRotator>& InWorldRotations, int InSampleRate, float InBlendInTime, float InBlendOutTime, float InPlayRate);

	void Init(const TArray<FVector>& InWorldLocations, const TArray<FRotator>& InWorldRotations, const TArray<FVector>& InPivotLocations, int InSampleRate, float InBlendInTime, float InBlendOutTime, float InPlayRate);

	virtual void ModifyViewPOV(float DeltaTime, struct FMinimalViewInfo& InOutPOV) override;

	virtual bool IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType) override { return false; };

	virtual bool ProcessViewRotation(class AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch, double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot) override;

private:
	// FCatmullRomSplineSmoothCurve CatmullRomMoveCurve;

	// 关键帧位置数据
	TArray<FVector> WorldLocations;
	TArray<FRotator> WorldRotations;
	TArray<FVector> PivotLocations;

	FVector ResultLocation = FVector::ZeroVector;
	FRotator ResultRotation = FRotator::ZeroRotator;
	FRotator DeltaAng = FRotator::ZeroRotator;

	int SampleRate = 15;

	FCollisionQueryParams QueryParams{SCENE_QUERY_STAT(CameraAIMove), false};

	UPROPERTY(Transient)
	TObjectPtr<USplineComponent> Spline;
};
