﻿#pragma once
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPNonMaterialBase.h"

class KGPPPhotoContrast : public KGPPNonMaterialBase
{
public:
	void InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType, const FString& ContrastCurvePath);
	virtual void SetManualWeightCurveValue(float Weight) override;

protected:
	int32 ColorContrastID = 0;
};

