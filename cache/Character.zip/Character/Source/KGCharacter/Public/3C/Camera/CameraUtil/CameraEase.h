// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CameraEase.generated.h"

UENUM(BlueprintType)
namespace ECameraEaseFunction
{
	enum Type : int
	{
		Linear,
		EaseInSine,
		EaseOutSine,
		EaseInOutSine,
		EaseInQuad,
		EaseOutQuad,
		EaseInOutQuad,
		EaseInCubic,
		EaseOutCubic,
		EaseInOutCubic,
		EaseInQuart,
		EaseOutQuart,
		EaseInOutQuart,
		EaseInQuint,
		EaseOutQuint,
		EaseInOutQuint,
		EaseInExpo,
		EaseOutExpo,
		EaseInOutExpo,
		EaseInCirc,
		EaseOutCirc,
		EaseInOutCirc,
		Spring,
		Decay,
		Curve
	};
}

class KGCHARACTER_API FCameraEaseCalculate
{
public:
	static FRotator LerpRotationWithShortestPath(const FRotator& Source, const FRotator& Target, float BlendPct);

	template <typename T>
	static T Evaluate(ECameraEaseFunction::Type EaseFunction, const T& Start, const T& End, float Pct);
	
	static float GetCurveNormalPct(class UCurveFloat* Curve, float Pct);
};

template <typename T>
T FCameraEaseCalculate::Evaluate(ECameraEaseFunction::Type EaseFunction, const T& Start, const T& End, float Pct)
{
	Pct = FMath::Clamp(Pct, 0.f, 1.f);
	switch (EaseFunction) {
	case ECameraEaseFunction::Linear:
		return Start + (End - Start) * Pct;
	case ECameraEaseFunction::EaseInSine:
		return Start + (End - Start) * (1 - FMath::Cos(Pct * UE_PI / 2));
	case ECameraEaseFunction::EaseOutSine:
		return Start + (End - Start) * FMath::Sin(Pct * UE_PI / 2);
	case ECameraEaseFunction::EaseInOutSine:
		return Start + (End - Start) * 0.5f * (1 - FMath::Cos(Pct * UE_PI));
	case ECameraEaseFunction::EaseInQuad:
		return Start + (End - Start) * FMath::Pow(Pct, 2);
	case ECameraEaseFunction::EaseOutQuad:
		return Start + (End - Start) * (1 - FMath::Pow(1 - Pct, 2));
	case ECameraEaseFunction::EaseInOutQuad:
		if(Pct < 0.5f)
		{
			return Start + (End - Start) * FMath::Pow(Pct, 2) * 2.f;
		}
		return Start + (End - Start) * (1.0f - 2.0f * (1.0f - Pct) * (1.0f - Pct));
	case ECameraEaseFunction::EaseInCubic:
		return Start + (End - Start) * FMath::Pow(Pct, 3);
	case ECameraEaseFunction::EaseOutCubic:
		return Start + (End - Start) * (1 - FMath::Pow(1 - Pct, 3));
	case ECameraEaseFunction::EaseInOutCubic:
		if(Pct < 0.5f)
		{
			return Start + (End - Start) * FMath::Pow(Pct, 3) * 4.f;
		}
		return Start + (End - Start) * (1.0f + 0.5f * FMath::Pow(2.0f * Pct - 2.0f, 3));
	case ECameraEaseFunction::EaseInQuart:
		return Start + (End - Start) * FMath::Pow(Pct, 4);
	case ECameraEaseFunction::EaseOutQuart:
		return Start + (End - Start) * (1 - FMath::Pow(1 - Pct, 4));
	case ECameraEaseFunction::EaseInOutQuart:
		if(Pct < 0.5f)
		{
			return Start + (End - Start) * FMath::Pow(Pct, 4) * 8.f;
		}
		return Start + (End - Start) * (1.0f - 8.f * FMath::Pow(1.0f - Pct, 4));
	case ECameraEaseFunction::EaseInQuint:
		return Start + (End - Start) * FMath::Pow(Pct, 5);
	case ECameraEaseFunction::EaseOutQuint:
		return Start + (End - Start) * (1 - FMath::Pow(1 - Pct, 5));
	case ECameraEaseFunction::EaseInOutQuint:
		if(Pct < 0.5f)
		{
			return Start + (End - Start) * FMath::Pow(Pct, 5) * 16.f;
		}
		return Start + (End - Start) * (1.f + 0.5f * FMath::Pow(2.0f * Pct - 2.0f, 5));
	case ECameraEaseFunction::EaseInExpo:
		return Start + (End - Start) * ((Pct == 0.0f) ? 0.0f : FMath::Pow(2.0f, 10.0f * (Pct - 1.0f)));
	case ECameraEaseFunction::EaseOutExpo:
		return Start + (End - Start) * ((Pct == 1.0f) ? 1.0f : 1.0f - FMath::Pow(2.0f, -10.0f * Pct));
	case ECameraEaseFunction::EaseInOutExpo:
		{
			float Factor;
			if (Pct == 0.0f || Pct == 1.0f)
			{
				Factor = Pct;
			}
			else if (Pct < 0.5f)
			{
				Factor = 0.5f * FMath::Pow(2.0f, 20.0f * Pct - 10.0f);
			}
			else
			{
				Factor = 1.0f - 0.5f * FMath::Pow(2.0f, -20.0f * Pct + 10.0f);
			}
			return Start + (End - Start) * Factor;
		}
	case ECameraEaseFunction::EaseInCirc:
		return Start + (End - Start) * (1 - FMath::Sqrt(1 - Pct * Pct));
	case ECameraEaseFunction::EaseOutCirc:
		return Start + (End - Start) * FMath::Sqrt(1 - (Pct - 1) * (Pct - 1));
	case ECameraEaseFunction::EaseInOutCirc:
		{
			float Factor;
			if (Pct < 0.5f)
			{
				Factor = 0.5 * (1.f - FMath::Sqrt(1 - 4.f * Pct * Pct));
			}
			else
			{
				Factor = 0.5f * (FMath::Sqrt(1.0f - (2.0f * Pct - 2.0f) * (2.0f * Pct - 2.0f)) + 1.0f);
			}
			return Start + (End - Start) * Factor;
		}
	default:
		return Start + (End - Start) * Pct;
	}
}

struct FCatmullRomSplineSmoothCurve
{
	void Init(const TArray<FVector>& InWorldLocations, float InAlpha = 0.5f, float InTension = 0.f);

	void Evaluate(float Pct, FVector& OutResult);

private:
	TArray<FVector> WorldLocation;
	int NumSegments = 0;
	float Alpha = 0.5f;
	float Tension = 0.f;
	bool bValid = false;
};
