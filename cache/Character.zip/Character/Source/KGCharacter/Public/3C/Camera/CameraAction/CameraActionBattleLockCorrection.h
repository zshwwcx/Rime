﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "3C/Camera/CameraAction/CameraActionBase.h"
#include "CameraActionBattleLockCorrection.generated.h"

/**
 * 
 */
UCLASS()
class KGCHARACTER_API UCameraActionBattleLockCorrection : public UCameraActionBase
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable)
	void Init(int64 LockActorID, int InBlendType, float InScreenThresholdUp, float InScreenThresholdDown, float InYawBlendParam, float InPitchBlendParam, float InSafeLockPitch, float InSafePitchMin, float InSafePitchMax, float InActionCD, float InRaisePitchOffsetMax, float InDropPitchOffsetMax, bool bClearCD = false);

	UFUNCTION(BlueprintCallable)
	void Refresh(int64 LockActorID);
	
	virtual void Play() override;
	virtual void Abort() override;
	virtual bool ProcessViewRotation(class AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch, double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot) override;

	virtual void ModifyCamera(float DeltaTime) override;

	virtual void DisableAction(bool bImmediate) override;

	// 有输入时进入冷却
	virtual bool IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType) override;

	virtual void DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode) override;

	virtual bool IsStronglySetRotation() const override { return false; };
private:
	void InitParams();

private:
	int BlendType = 0; // 测试用 0为半衰 1为弹簧
	float ScreenThresholdUp = 0.f;
	float ScreenThresholdDown = 0.f;
	float ScreenThresholdRad = 0.f;
	float YawBlendParam = 0.f;
	float PitchBlendParam = 0.f;

	float SafeLockPitch = 0.f;
	bool bUseSafeLockPitch = false;

	float SafePitchMin = 0.f;
	float SafePitchMax = 0.f;

	float PitchOffsetMin = 0.f;
	float PitchOffsetMax = 0.f;
	
	bool bNeedPitchOffset = false;
	bool bRaiseOffset = false;
	bool bStartFinish = false;;

	float RaisePitchOffsetMax = 0.f;
	float DropPitchOffsetMax = 0.f;
	
	float ActionCD = 0.f;
	float CurrentCDTime = -1.f;

	TWeakObjectPtr<USkeletalMeshComponent> LockSKMesh;
	TWeakObjectPtr<AActor> LockActor;

	static constexpr float CDCorrect = 0.1f;
	static constexpr float ScreenThresholdCorrect = 0.5f;
	static constexpr float PitchEqualTolerance = 3.f;
	static const FName CameraLookBoneName;
	
	float YawSmoothSpeed = 0.f;
	float PitchSmoothSpeed = 0.f;
	double PitchOffsetSmoothSpeed = 0;

	FVector CameraLockLocation = FVector::ZeroVector;

	float CachedTargetPitch = 0.f;
	float CachedTargetYaw = 0.f;

	double CurrentOffsetPitch = 0.f;
};
