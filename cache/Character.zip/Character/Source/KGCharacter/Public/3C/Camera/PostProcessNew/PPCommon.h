#pragma once
#include "CoreMinimal.h"
#include "Misc/CommonDefines.h"
#include "Effect/KGEffectCommon.h"
#include "HAL/IConsoleManager.h"

#define KG_ENABLE_PP_MANAGER_DEBUG (!UE_BUILD_SHIPPING && !UE_BUILD_TEST)
DECLARE_LOG_CATEGORY_EXTERN(LogKGPP, Log, All);

#define KG_PP_INVALID_PPID (0)
#define KG_PP_MAX_PRIORITY (0x7fffffff)
#define KG_PP_LENS_FLARES_TINTS_NUM (8)
#define KG_PP_INTENSITY_MAX (1.0f)
#define KG_PP_INTENSITY_MIN (0.0f)
// 这里定义了基础的后处理播放参数, 由于当前后处理播放接口较多, 用一个宏统一定义, 方便后续扩展
#define KG_PP_COMMON_PARAMS int32 InPriority, float InTotalLifeTimeSeconds, bool bInDestroyWhenLeaveSpace, bool bUsePPTag, uint32 PPTag, \
	int32 InSourceType, float InBlendInTime, float InBlendOutTime
#define KG_PP_COMMON_PARAMS_NAMES InPriority, InTotalLifeTimeSeconds, bInDestroyWhenLeaveSpace, bUsePPTag, PPTag, InSourceType, InBlendInTime, InBlendOutTime

#if WITH_EDITOR
extern TAutoConsoleVariable<float> CVarForcePPBlendWeight;
#endif

// 对于非材质类型的后处理, 需要在cpp中定义类型
// 对于材质类型的后处理来说, 绝大部分后处理效果实际对应的逻辑都是按照固定值/线性插值/曲线采样这几种形式来更新对应材质参数即可,
// 此时只需要外部传入对应的参数以及类型即可, 不需要在cpp中专门去定义类型, 因此这里不用枚举, 而是用了一个uint8来表示后处理类型
enum class EKGPostProcessType
{
	KG_PP_None = 0,
	KG_PP_Dummy,
	// 内置PP Start
	KG_PP_Start = 10,
	KG_PP_Bloom = 11,
	KG_PP_DepthOfField = 12,
	KG_PP_Darken = 13,
	KG_PP_GI_IndirectLight = 14,
	KG_PP_ChromaticAberration = 15,
	KG_PP_DirtMask = 16,
	KG_PP_LensFlares = 17,
	KG_PP_ImageEffects = 18,
	KG_PP_ColorGradingTemperature = 19,
	KG_PP_ColorGradingGlobal = 20,
	KG_PP_ColorGradingShadows = 21,
	KG_PP_ColorGradingMidtones = 22,
	KG_PP_ColorGradingHighlights = 23,
	KG_PP_ColorGradingMisc = 24,
	KG_PP_FilmGrain = 25,
	KG_PP_PhotoFilters = 26,
	KG_PP_PhotoContrast = 27,
	KG_PP_PhotoSaturation = 28,
	KG_PP_PhotoWhiteTemp = 29,
	KG_PP_PhotoWhiteTint = 30,
	KG_PP_PhotoExposure = 31,
	KG_PP_AutoExposureSpeedUp = 32,
	KG_PP_ChromaticAberrationByCameraArmLength = 33,
	
	KG_PP_Fog = 51,
	KG_PP_Phantom = 52,
	KG_PP_Sketch = 53,
	KG_PP_Clip = 54,
	KG_PP_BlackFog = 55,
	KG_PP_MultiTargetFog = 56,
};

enum class EKGPostProcessState : uint8
{
	UnInitialized = 0, // 未初始化
	Activated = 1,
	Deactivated = 2,
	// 对于复杂材质后处理, 如果优先级队列只存在一个后处理实例, 那么在打断该后处理时, 后处理可以淡出, 但此时后处理必须维持在优先级队列中
	// 此时不能执行后处理 TaskDeactivated, 直到同类型或者冲突类型新的后处理实例生效, 此时需要直接删除后处理实例
	InterruptedBlendingOut_Activated = 3,
	InterruptedBlendingOut_ActivatedFinished = 4, // 标记此时interrupted blend out结束, 可以清理后处理
	// 对于非复杂材质后处理, 在直接打断淡出时, 会将后处理实例移出优先队列, 避免其存在于后处理队列中, 会影响后续新的后处理效果,
	// 后处理实例会执行 TaskDeactivated, 但是仍然会输出后处理效果
	InterruptedBlendingOut_PendingDeactivated = 5, // blend out执行时立刻过渡到这个状态, 并会接着立刻过渡到 InterruptedBlendingOut_Deactivated
	InterruptedBlendingOut_Deactivated = 6, // 此时后处理实例已经执行 TaskDeactivated, 移出了优先级队列, 正处于淡出过程, 非disable状态下仍然可以输出后处理效果
	InterruptedBlendingOut_DeactivatedFinished = 7, // 标记此时interrupted blend out结束, 可以清理后处理
	Ended = 8,
};

enum class EKGPostProcessStopReason : uint8
{
	ExternalInterrupt,
	LifeTimeEnd,
	GameFinished,
	LeaveSpace,
	PostProcessDisabled,
	PriorityOccupy,
};

// 数字越大表示优先级越高, 高优先级的任务可以打断相同优先级的或者更低优先级的Blend
enum class EKGPostProcessBlendReason : uint8
{
	None = 0,
	LifeTimeBlend = 1,
	TaskActivationStateChange = 2,
	TaskInterrupted = 3,
};

enum class EKGPostProcessDisableReason : uint8
{
	GlobalDisable = 0,
	SourceTypeDisable = 1,
};

enum class EKGPostProcessQuality : uint8
{
	Low = 0,
	Medium,
	High,
	Ultra,
	Cinematic
};

enum class EKGPPSketchEffectType : uint8
{
	ClearLine = 0, // 去除笔触效果
	ExcludeTarget = 1, // 还原角色
	PaintRed = 2, // 变红色
};

struct FKGPPMaterialParams
{
	TMap<FName, float> ScalarParams;
	TMap<FName, FLinearColor> VectorParams;
	TMap<FName, FString> TextureParams;
	TMap<FName, FKGLinearSampleParams<float>> ScalarLinearSampleParams;
	TMap<FName, FKGLinearSampleParams<FLinearColor>> VectorLinearSampleParams;
	TMap<FName, FKGCurveParams> CurveParams;
	TMap<FName, TWeakObjectPtr<AActor>> ActorLocationParams;
	// 相比于 ActorLocationParams, 这里会处理Entity进出时重新对Actor进行绑定
	TMap<FName, KGEntityID> EntityLocationParams;
	TMap<FName, FKGLinearBlendInAndBlendOutParams<float>> ScalarLinearBlendParams;
};

struct FKGDepthOfFieldParams
{
	// mobile usage
	bool bMobileHQGaussian = false;
	float FocalRegion = 0.f;
	bool bMobileCustomTransition = false;
	float NearTransitionRegion = 300.f;
	float FarTransitionRegion = 8000.f;
	float Scale = 1.f;
	float NearBlurSize = 15.f;
	float FarBlurSize = 15.f;

	// PC usage
	float DepthOfFieldFstop = 4.0f;
	float DepthOfFieldMinFstop = 1.2f;
	int32 DepthOfFieldBladeCount = 5;
	float SensorWidth = 60.f;
	float SqueezeFactor = 2.f;
	float FocalDistance = 300.f;
	float DepthBlurAmount = 1.f;
	float DepthBlurRadius = 100.f;

	// common
	float FocalDistanceOffset = 0.0f;
	KGEntityID FocalEntityID = 0;
	TWeakObjectPtr<AActor> FocalTarget;
	FName SocketName;
};

enum class EKGFogShapeType : uint8
{
	Circle = 0,
	Ring = 1,
	Cross = 2,
	HalfField = 3,
};

struct FKGFogParams
{
	FName FogCenterPosParamName;
	FName FogOpacityParamName;
	FName FogColorParamName;
	FName SmoothDistParamName;
	FName MaxDistParamName;
	FName PlayerPosParamName;
	FName BossPosParamName;
	FName ShapeTypeName;
	FName ShapeTypeBName; // 过渡目标图形参数
	FName CircleRadiusName;
	FName RingPercentName;
	FName RingOuterRadiusName;
	FName CrossLengthName;
	FName CrossWidthName;
	FName HalfFieldWidthName;
	FName RangeSpawnRotationName;
	FName ShapeLerpName;
};

struct FKGPPCommonParams
{
	FKGPPCommonParams() = default;
	FKGPPCommonParams(KG_PP_COMMON_PARAMS) :
		Priority(InPriority),
		TotalLifeTimeSeconds(InTotalLifeTimeSeconds),
		bDestroyWhenLeaveSpace(bInDestroyWhenLeaveSpace),
		bUsePPTag(bUsePPTag),
		PPTag(PPTag),
		SourceType(InSourceType),
		BlendInTime(InBlendInTime),
		BlendOutTime(InBlendOutTime) 
	{}
	
	int32 Priority = 0;
	float TotalLifeTimeSeconds = 0.0f;
	bool bDestroyWhenLeaveSpace = true;
	bool bUsePPTag = false;
	uint32 PPTag = 0;
	int32 SourceType = 0; // 其实这个也可以用tag实现, 但是为了避免从Lua传入TArray, 还是使用一个int32来表示
	float BlendInTime = 0.0f; 
	float BlendOutTime = 0.0f;
};

struct FKGPPConfig
{
	FString TypeName;
	TArray<EKGPostProcessType> ConflictTypes;
	int32 ViewPriority = 0;
	FString MaterialPath;
	FString PlaneMeshMaterialPath;
	FName IntensityParamName = NAME_None;
};

class KGPPUtils
{
public:
	static uint32 GeneratePPID();
	static bool IsFogPP(EKGPostProcessType PPType) { return PPType == EKGPostProcessType::KG_PP_Fog || PPType == EKGPostProcessType::KG_PP_MultiTargetFog; }
};
