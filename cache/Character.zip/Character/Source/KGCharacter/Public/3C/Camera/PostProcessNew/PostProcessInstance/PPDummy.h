#pragma once
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPBase.h"

// 关于 Dummy PostProcess, 由于不同类型的后处理优先队列需要根据配置确定是否互相冲突, 以后处理类型A和B之间互相冲突为例, 这里的实现方案为
// A和B各有一个优先队列, 每当新增A或者B类型的后处理时, 除了在自身对应的类型新增一个后处理外, 还会在其他冲突的优先队列中新增一个dummy post process
// 且 dummy post process与自身生命周期完全绑定, 自身销毁时同步也会销毁dummy post process
// 因此 dummy post process instance无需任何逻辑处理
class KGPPDummy : public KGPPBase
{
public:

	void InitParams(int32 InPriority, TWeakObjectPtr<UPostProcessManager> InPPManager, int32 InSourcePPID, EKGPostProcessType InSourcePPType, EKGPostProcessType InTargetPPType);
	
	virtual EKGPostProcessType GetPPType() const override { return EKGPostProcessType::KG_PP_Dummy; }
	virtual FString GetDebugInfo() const override;
	virtual bool CanOutputPostProcess() const override { return false; }
	virtual bool GetPostProcessResult(FPostProcessSettings& OutPPSettings, float& OutPPBlendWeight, EViewTargetBlendOrder& OutPPBlendOrder) const override { return false; }
	int32 GetSourcePPID() const { return SourcePPID; }
	EKGPostProcessType GetTargetPPType() const { return TargetPPType; }
	
protected:
	int32 SourcePPID = 0;
	EKGPostProcessType SourcePPType = EKGPostProcessType::KG_PP_None;
	EKGPostProcessType TargetPPType = EKGPostProcessType::KG_PP_None;
};