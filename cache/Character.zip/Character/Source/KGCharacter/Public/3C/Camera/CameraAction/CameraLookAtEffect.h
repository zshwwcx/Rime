#pragma once

#include "CoreMinimal.h"
#include "3C/Camera/CameraAction/CameraActionBase.h"
#include "Camera/CameraModifier.h"
#include "CameraLookAtEffect.generated.h"



UCLASS( BlueprintType, Blueprintable)
class KGCHARACTER_API UCameraLookAtEffect : public UCameraActionBase
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable)
	void Init(const FVector& InLookAtLoc, int64 LookAtActorID, float InBlendInTime, float InBlendOutTime, float InDuration, bool bInRecover, const FRotator& InTargetRotDelta, bool bInUseManualControlPitch, bool bInCanInterrupt, ECameraEaseFunction::Type InBlendInMode, ECameraEaseFunction::Type InBlendOutMode, int64 BlendInCurveID, int64 BlendOuTCurveID, const FString& InBoneName, bool bContinue);

	virtual void Play() override;
	virtual bool ProcessViewRotation(class AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch, double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot) override;

	virtual void DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode) override;
	virtual bool IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType) override;

private:
	void InitParams();

	void CalDesiredRot(bool bInit);

protected:
	FVector LookAtLoc = FVector(0,0,0);

	TWeakObjectPtr<AActor> LookAtActor;
	bool bUseActor = false;
	bool bCppEntity = false;

	FRotator CurTargetDir = FRotator::ZeroRotator;
	FRotator OriginRotation = FRotator::ZeroRotator;
	FRotator TargetRot = FRotator::ZeroRotator;
	FRotator TargetRotDelta = FRotator::ZeroRotator;

	float RotateAlpha = 0;

	bool bFirstEnter = true;
	
	float CurTime = 0;

	bool bUseManualControlPitch = false;

	bool bCanInterrupt = false;

	FRotator CameraRotation = FRotator::ZeroRotator;

	float DesiredYaw = 0.f;
	float DesiredPitch = 0.f;
	float BaseYaw = 0.f;
	float BasePitch = 0.f;

	FName BoneName;
	bool bActionContinueDetect = false;
};





