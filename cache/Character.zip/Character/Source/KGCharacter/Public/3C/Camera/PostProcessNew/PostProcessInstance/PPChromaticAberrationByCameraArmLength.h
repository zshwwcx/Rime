﻿#pragma once
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPNonMaterialBase.h"

class ACameraManager;

class KGPPChromaticAberrationByCameraArmLength : public KGPPNonMaterialBase
{
public:
	void InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType, 
		float InMinCameraArmLength, float InMaxCameraArmLength, float InMinChromaticAberrationIntensity, float InMaxChromaticAberrationIntensity);
	
	virtual bool OnTaskStart() override;
	virtual void OnTaskTick(float DeltaTime) override;
	virtual FString GetDebugInfo() const override;
	
protected:
	
	TWeakObjectPtr<ACameraManager> CameraManager;
	
	float MinCameraArmLength = 0.0f;
	float MaxCameraArmLength = 0.0f;
	float MinChromaticAberrationIntensity = 0.0f;
	float MaxChromaticAberrationIntensity = 0.0f;
};

