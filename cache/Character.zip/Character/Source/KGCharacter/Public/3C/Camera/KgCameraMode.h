#pragma once

#include "3C/Camera/BaseCamera.h"
#include "3C/Camera/CameraUtil/CameraEase.h"
#include "Misc/CommonDefines.h"
#include "Camera/PlayerCameraManager.h"
#include "Curves/CurveFloat.h"
#include "Curves/CurveVector.h"
#include "LuaOverriderInterface.h"
#include "KgCameraMode.generated.h"

// // 供相机配置使用 仅配置
// UENUM()
// enum class EInitRotationOperation : uint8
// {
// 	//使用MODE设置的旋转
// 	USE_MODE_INIT_ARM_ROT   UMETA(DisplayName="Use Mode Config"),
// 	//保持上次退出的旋转
// 	REMAIN_LAST_EXIT_ROT   	UMETA(DisplayName="Keep Last Exit Rotation"),
// 	//保持上一Mode旋转	
// 	REMAIN_LAST_MODE_ROT	UMETA(DisplayName="Keep Last Mode Rotation"),
// 	//旋转到角色正面
// 	SET_TO_TARGET_FRONT		UMETA(DisplayName="Set To Character Front"),
// 	//旋转到角色背面
// 	SET_TO_TARGET_BACK 		UMETA(DisplayName="Set To Character Back"),
// 	//手动控制
// 	USE_MANUAL_CONTROL      UMETA(DisplayName="Manual Control"),
// };
//
// // 供相机配置使用 仅配置
// UENUM()
// enum class EInitArmLenOperation : uint8
// {
// 	//使用MODE设置的长度
// 	USE_MODE_CONFIG						UMETA(DisplayName="Use Mode Config"),
// 	//保持上次退出长度
// 	REMAIN_LAST_EXIT_LEN				UMETA(DisplayName="Keep Last Exit Length"),
// 	//保持上一Mode摇臂长
// 	REMAIN_LAST_MODE_LEN                UMETA(DisplayName="Keep Last Mode Length"),
// 	//设置到最大摇臂长度
// 	SET_TO_ZOOM_MAX_LEN					UMETA(DisplayName="Set To Max Zoom Length"),
// 	//设置到最小摇臂长度
// 	SET_TO_ZOOM_MIN_LEN               	UMETA(DisplayName="Set To Min Zoom Length"),
// 	//设置到摇臂长度范围中间点
// 	SET_TO_ZOOM_RANGE_MIDDLE  			UMETA(DisplayName="Set To Middle"),
// 	//手动控制
// 	USE_MANUAL_CONTROL      	UMETA(DisplayName="Manual Control(Do not use Controller Rotation"),
// };

// 场编使用
USTRUCT(BlueprintType)
struct FCameraModeCameraBasicConfig
{
	GENERATED_BODY()
public:
	FCameraModeCameraBasicConfig()
	{
	}
	;

#pragma region CameraBasicConfig
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float DefaultFOV = 90;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float ZoomMinLen = 200;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float ZoomMaxLen = 1000;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float ZoomStep = 40;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Init Rotation", meta=(HideInDetailPanel))
	FRotator ArmInitRotation = FRotator::ZeroRotator;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Init ArmLength")
	float ArmInitZoomLen = 700;

#pragma endregion ZoomConfig
};


struct FCameraModeConfig
{
public:
	FCameraModeConfig() {}

	FCameraMultiLayerParam DefaultFOV{90};

	FCameraMultiLayerParam ZoomMinLen{0};

	FCameraMultiLayerParam ZoomMaxLen{0};

	float ZoomStep = 0;

	float ArmInitZoomLen = 0;

	ECameraEaseFunction::Type ZoomLagEaseType = ECameraEaseFunction::Decay;

	FCameraMultiLayerParam ZoomLagEaseParam{0};

	int64 ZoomLagEaseCurveID = KG_INVALID_ID;
	
	FRotator ArmInitRotation = FRotator::ZeroRotator;
	
	ECameraEaseFunction::Type ZLagEaseType = ECameraEaseFunction::Decay;

	FCameraMultiLayerParam ZLagEaseParam{0};

	int64 ZLagEaseCurveID = KG_INVALID_ID;

	FCameraMultiLayerParam SoftZoneRadiusZ{0};
	
	ECameraEaseFunction::Type XOYLagEaseType = ECameraEaseFunction::Decay;

	FCameraMultiLayerParam XOYLagEaseParam{0};

	int64 XOYLagEaseCurveID = KG_INVALID_ID;

	FCameraMultiLayerParam SoftZoneRadiusXOY = 0;

	ECameraEaseFunction::Type RotationLagEaseType = ECameraEaseFunction::Decay;

	FCameraMultiLayerParam RotationLagEaseParam{0};

	int64 RotationLagEaseCurveID = KG_INVALID_ID;
	
	ECameraEaseFunction::Type ReleaseLagEaseType = ECameraEaseFunction::Decay;

	FCameraMultiLayerParam ReleaseLagEaseParam{0};

	int64 ReleaseLagEaseCurveID = KG_INVALID_ID;

	ECameraEaseFunction::Type CompressLagEaseType = ECameraEaseFunction::Decay;

	FCameraMultiLayerParam CompressLagEaseParam{0};

	int64 CompressLagEaseCurveID = KG_INVALID_ID;

	FCameraMultiLayerParam_FVector ViewOffset{FVector::ZeroVector};

	bool bEnableDitherFade = false;

	TArray<int> DitherFadeObjectTypesForStatic;
	TArray<int> DitherFadeObjectTypesForDynamic;
	float DitherFadeStaticDetectInterval = -1.f;
	float DitherFadeDynamicDetectInterval = -1.f;
	float CameraPosDiffThreshold = 0.f;

	EDitherFadeDetectType DetectType = EDitherFadeDetectType::SphereRayCastDetect;

	float DetectRadius = 50.f;
	float DetectPitch = 45.f;

	TWeakObjectPtr<AActor> LookAtTarget = nullptr;
	TWeakObjectPtr<AActor> ControlTarget = nullptr;

	FName LookAtBoneName = NAME_None;

	FVector LookAtBoneOffset = FVector::ZeroVector;

	ERelativeTransformSpace BoneOffsetTransSpace = ERelativeTransformSpace::RTS_Actor;

	FCameraMultiLayerParam CustomViewPitchMax{-89.9};
	FCameraMultiLayerParam CustomViewPitchMin{89.9};
	FCameraMultiLayerParam CustomViewYawMax{0.f};
	FCameraMultiLayerParam CustomViewYawMin{359.999f};
	FCameraMultiLayerParam CustomViewRollMax{-89.9};
	FCameraMultiLayerParam CustomViewRollMin{89.9};

	FCameraMultiLayerParam_FRotator CameraSocketRotOffset;
};

/**
 * 摄像机模式
 * 具体各模式摄像机由Lua实现
 */
UCLASS(BlueprintType, Blueprintable)
class KGCHARACTER_API UKgCameraMode : public UObject, public ILuaOverriderInterface
{
	GENERATED_UCLASS_BODY()
	
	virtual FString GetLuaFilePath_Implementation() const override { return TEXT("Gameplay.3C.Camera.UECameraMode.CameraModeBase"); }

public:
	virtual void Update(float DeltaTime);

	UFUNCTION(BlueprintCallable)
	void UpdateControlData(float DeltaTime);

	UFUNCTION(BlueprintImplementableEvent)
	void OnModeUpdate(float DeltaTime);

	UFUNCTION(BlueprintCallable)
	void SetCurCamera(AActor* Camera);

	UFUNCTION(BlueprintCallable)
	void SetCurCameraByID(int64 CameraActorID);
	
	UFUNCTION(BlueprintCallable)
	void UpdateCameraZoomLenClamp(float ZoomMax, float ZoomMin);

	UFUNCTION(BlueprintCallable)
	void SetCameraFOVCurveFromID(int64 FOVCurveID);

	UFUNCTION(BlueprintCallable)
	void SetCameraTargetLocationOffsetCurveFromID(int64 TargetLocationOffsetCurveID);

	UFUNCTION(BlueprintCallable)
	AActor* GetCurCamera();
	
	UFUNCTION(BlueprintCallable)
	ABaseCamera* GetCamera();

	UFUNCTION(BlueprintCallable)
	class UCameraComponent* GetCameraComponent();
	
	UFUNCTION(BlueprintCallable)
	class UCameraArmComponent* GetCameraArmComponent();
	
	UFUNCTION(BlueprintCallable)
	void ResetToDefault();
	
	UFUNCTION(BlueprintCallable)
	int64 GetActorID();

	UFUNCTION(BlueprintCallable)
	FRotator GetCameraRotation();

	UFUNCTION(BlueprintCallable)
	FVector GetCameraLocation();

	UFUNCTION(BlueprintCallable)
	void MarkActivate(bool Value);

	UFUNCTION(BlueprintCallable)
	bool IsActivate() const;

	UFUNCTION(BlueprintCallable)
	bool IsBlending();

	UFUNCTION(BlueprintCallable)
	void EnableApplyPOVPostProcess(bool bEnable);

	UFUNCTION(BlueprintCallable)
	void CopyAndRefreshControlData(UKgCameraMode* OtherCameraMode, int InPriority);

	UFUNCTION(BlueprintCallable)
	void RefreshControlData(
		int InPriority,
		float ZoomMin, float ZoomMax, float ZoomStep, float NewFOV,
		int EaseTypeZoomLag, float ParamZoomLag, int64 CurveIDZoomLag,
		int EaseTypeZLag, float ParamZLag, int64 CurveIDZLag, float NewSoftZoneRadiusZ,
		int EaseTypeXOYLag, float ParamXOYLag, int64 CurveIDXOYLag, float NewSoftZoneRadiusXOY,
		int EaseTypeRelease, float ParamRelease, int64 CurveIDRelease,
		int EaseTypeCompress, float ParamCompress, int64 CurveIDCompress,
		float ViewOffX, float ViewOffY,
		bool bEnableDitherFade, const TArray<int>& NewDitherFadeObjectTypesForStatic, const TArray<int>& NewDitherFadeObjectTypesForDynamic,
		int DetectType, float DetectRadius, float DetectPitch, float StaticDetectInterval, float DynamicDetectInterval, float CameraPosDiffThreshold,
		float InInitArmLen, const FRotator& InInitRot,
		float InYawSensitivity, float InPitchSensitivity, int64 TargetLocationOffsetCurveID, int64 FOVCurveID
	);

	UFUNCTION(BlueprintCallable)
	void SetInitArmLenAndDir(float TargetArmLen, const FRotator& TargetRot, const FRotator& BaseSpace, bool bSyncPlayerController = true);

	UFUNCTION(BlueprintCallable)
	void InitRotationLagParam(bool bNewEnableCameraRotationLag, ECameraEaseFunction::Type EaseType, float Param, int64 CurveID);

	UFUNCTION(BlueprintCallable)
	void ForceUpdate(bool bDoTrace = true);

	UFUNCTION(BlueprintCallable)
	void ForceUpdateWithBaseCollision();

	UFUNCTION(BlueprintCallable)
	void SetCameraRotSensitivity(float Yaw, float Pitch, int InPriority);

	UFUNCTION(BlueprintCallable)
	void RemoveCameraRotSensitivity(int InPriority);

	UFUNCTION(BlueprintCallable)
	float GetCameraRotYawSensitivity();

	UFUNCTION(BlueprintCallable)
	float GetCameraRotPitchSensitivity();

	UFUNCTION(BlueprintCallable)
	void SetZoomSetting(float Min, float Max, int InPriority = 0);

	void GetZoomSetting(float& Min, float& Max) const;

	UFUNCTION(BlueprintCallable)
	void SetZoomMaxSetting(float Max, int InPriority = 0);

	UFUNCTION(BlueprintCallable)
	void RemoveZoomSetting(int InPriority = 0, bool bNeedZoomFix = false);

	UFUNCTION(BlueprintCallable)
	void SetFOVSetting(float NewFOV, int InPriority = 0);

	UFUNCTION(BlueprintCallable)
	float GetFOVBelowPriority(int InPriority, float DefaultValue);
	
	UFUNCTION(BlueprintCallable)
	void AddFOVDelta(float NewFOVDelta);

	UFUNCTION(BlueprintCallable)
	void AddZoomDelta(float NewZoomDelta);

	UFUNCTION(BlueprintCallable)
	void RemoveFOVSetting(int InPriority = 0);

	UFUNCTION(BlueprintCallable)
	void SetCameraLookAt(int64 TargetActorID, int64 ControlActorID, const FName& NewBoneName, float NewBoneOffsetX, float NewBoneOffsetY, float NewBoneOffsetZ, ERelativeTransformSpace InTransformSpace = ERelativeTransformSpace::RTS_Actor);

	UFUNCTION(BlueprintCallable)
	void SetCameraLookAtWithStaticBoneOffsetZ(int64 TargetActorID, int64 ControlActorID, const FName& NewBoneName, float NewBoneOffsetX, float NewBoneOffsetY, float NewBoneOffsetZ, ERelativeTransformSpace InTransformSpace = ERelativeTransformSpace::RTS_Actor);

	UFUNCTION(BlueprintCallable)
	AActor* GetCameraLookAt();

	UFUNCTION(BlueprintCallable)
	void SetCameraLookAtWithWorldLoc(int64 TargetActorID, int64 ControlActorID, const FVector& WorldLoc);

	UFUNCTION(BlueprintCallable)
	void SetCameraLookAtWithPivotLoc(int64 TargetActorID, int64 ControlActorID, const FVector& WorldPivotLoc, const FRotator& CameraRot, float Zoom);

	UFUNCTION(BlueprintCallable)
	void SetCameraRotationLagSetting(float Param, int InPriority = 0);

	UFUNCTION(BlueprintCallable)
	void RemoveCameraRotationLagSetting(int InPriority = 0);

	UFUNCTION(BlueprintCallable)
	void SetCameraXOYLagSetting(float Param, int InPriority = 0);

	UFUNCTION(BlueprintCallable)
	float GetXOYLagBelowPriority(int InPriority, float DefaultValue);
	
	UFUNCTION(BlueprintCallable)
	void RemoveCameraXOYLagSetting(int InPriority = 0);

	float GetDesiredCameraXOYLag() const { return BasicConfig.XOYLagEaseParam.GetValue(); }
	
	UFUNCTION(BlueprintCallable)
	void SetCameraZLagSetting(float Param, int InPriority = 0);

	UFUNCTION(BlueprintCallable)
	float GetZLagBelowPriority(int InPriority, float DefaultValue);

	UFUNCTION(BlueprintCallable)
	void RemoveCameraZLagSetting(int InPriority = 0);

	float GetDesiredCameraZLag() const { return BasicConfig.ZLagEaseParam.GetValue(); }

	UFUNCTION(BlueprintCallable)
	void SetCameraXOYSoftRadiusSetting(float Param, int InPriority = 0);

	UFUNCTION(BlueprintCallable)
	float GetXOYSoftRadiusBelowPriority(int InPriority, float DefaultValue);
	
	UFUNCTION(BlueprintCallable)
	void RemoveCameraXOYSoftRadiusSetting(int InPriority = 0);

	float GetDesiredCameraXOYSoftRadius() const { return BasicConfig.SoftZoneRadiusXOY.GetValue(); }
	
	UFUNCTION(BlueprintCallable)
	void SetCameraZSoftRadiusSetting(float Param, int InPriority = 0);

	UFUNCTION(BlueprintCallable)
	float GetZSoftRadiusBelowPriority(int InPriority, float DefaultValue);

	UFUNCTION(BlueprintCallable)
	void RemoveCameraZSoftRadiusSetting(int InPriority = 0);

	float GetDesiredCameraZSoftRadius() const { return BasicConfig.SoftZoneRadiusZ.GetValue(); }
	
	float GetDesiredFOV() const { return BasicConfig.DefaultFOV.GetValue() + FOVDelta; }

	UFUNCTION(BlueprintCallable)
	void SetViewAngleSetting(float InViewPitchMin, float InViewPitchMax, float InViewYawMin, float InViewYawMax, float InViewRollMin, float InViewRollMax, int InPriority = 0);

	UFUNCTION(BlueprintCallable)
	void RemoveViewAngleSetting(int InPriority = 0);
	
	UFUNCTION(BlueprintCallable)
	void SetViewYawSetting(float Min, float Max, int InPriority = 0);

	UFUNCTION(BlueprintCallable)
	void SetViewRollSetting(float Min, float Max, int InPriority = 0);

	UFUNCTION(BlueprintCallable)
	void SetViewPitchSetting(float Min, float Max, int InPriority = 0);
	
	UFUNCTION(BlueprintCallable)
	void SetPivotOffsetFromScreenCoOffsetSetting(float OffX, float OffY, int InPriority = 0);

	UFUNCTION(BlueprintCallable)
	void RemovePivotOffsetFromScreenCoOffsetSetting(int InPriority );

	UFUNCTION(BlueprintCallable)
	FVector2D GetPivotOffsetBelowPriority(int InPriority, const FVector2D& DefaultValue);

	UFUNCTION(BlueprintCallable)
	FVector2D GetPivotOffsetSetting();
	
	UFUNCTION(BlueprintCallable)
	void SetCameraSocketRotOffsetSetting(const FRotator& Offset, int InPriority = 0);

	UFUNCTION(BlueprintCallable)
	void RemoveCameraSocketRotOffsetSetting(int InPriority );

	UFUNCTION(BlueprintCallable)
	FRotator GetCameraSocketRotOffsetBelowPriority(int InPriority, const FRotator& DefaultValue);

	UFUNCTION(BlueprintCallable)
	FRotator GetCameraSocketRotOffsetSetting();

	UFUNCTION(BlueprintCallable)
	void SetZoomWithAdsorption(float InAdsorptionSpeedX, float InAdsorptionSpeedXY, float InMaxX, float InMaxY, float InMaxYNeg, int EaseType, float InAdsorptionMinZoom, float InAdsorptionMaxZoom);

	UFUNCTION(BlueprintCallable)
	void CancelZoomAdsorption();

	UFUNCTION(BlueprintCallable)
	void SetCustomRotAndOffWithRecover(float DesiredPitch, float DesiredYaw, float DesiredRoll, float X, float Y, float Z, float BasePitch, float BaseYaw, float BaseRoll, ECameraEaseFunction::Type InRecoverEaseType);

	UFUNCTION(BlueprintCallable)
	void CancelCustomRotAndOffWithRecover();

	UFUNCTION(BlueprintCallable)
	void AddRotDelta(const FRotator& NewZoomDelta);
	
	UFUNCTION(BlueprintCallable)
	void UpdateZoomWithPivotAdsorption(float TargetZoom);

	UFUNCTION(BlueprintCallable)
	void AddSocketOffZWithPivotAdsorption(float Value);

	UFUNCTION(BlueprintCallable)
	void GetAdsorptionUpAndDownThreshold(float Height, float& DownThreshold, float& UpThreshold);
	
	// 捏脸专用接口
	UFUNCTION(BlueprintCallable)
	void SetCustomRoleLookAtBone(int64 LookAtTargetID, const FName& LookAtBone, float LookAtScreenX, float LookAtScreenY, const FName& CloseUpBone, float CloseUpScreenX, float CloseUpScreenY, float ViewOffsetHalfLife, float MaxZoom, float MinZoom, float ThresholdZoom, float InitZoom, float LookAtYaw, float CloseUpYaw, float InitPitch, float InitRoll, float PitchMin, float PitchMaxCloseUp, float PitchMaxThreshold, float YawMin, float YawMax);

	UFUNCTION(BlueprintCallable)
	void SetAdaptiveViewOffsetWithZoom(float ViewOffXWithZoomMax, float ViewOffXWithZoomMin, float ViewOffYWithZoomMax, float ViewOffYWithZoomMin, float HalfLife = 0.02f);

	UFUNCTION(BlueprintCallable)
	void CancelAdaptiveViewOffsetWithZoom();
	
	void ClearModeModifyDataAfterFrame();

	void SetOverrideZoomSetting(float Value, int Priority);

	void ClampZoomWithZoomSetting(float& Value);

	// 目前是场编在使用该接口
	void ManualSetZoom(float Value);

	float GetOverrideZoomBelowPriority(int Priority, float DefaultValue);

	void RemoveOverrideZoomSetting(int Priority);

	UFUNCTION(BlueprintCallable)
	void RemoveLookAtBoneRemainOffset();

	UFUNCTION(BlueprintCallable)
	void RecoverLookAt();

protected:
	ACameraManager* GetCameraManager();
	
protected:
	UPROPERTY(Transient, BlueprintReadWrite)
	TWeakObjectPtr<AActor> CurCameraPtr = nullptr;

	TWeakObjectPtr<ABaseCamera> CameraWeakPtr = nullptr;
	TWeakObjectPtr<UCameraArmComponent> ArmWeakPtr = nullptr;

	UPROPERTY(Transient, BlueprintReadWrite)
	TWeakObjectPtr<APlayerCameraManager> CurCameraMgr = nullptr;

	TWeakObjectPtr<ACameraManager> CurCameraManager = nullptr;

public:
	bool bEnableTick = false;

	UPROPERTY(Transient)
	int CameraModeTag = 0;

	FCameraModeConfig BasicConfig;

#pragma region ZoomCurve
	UPROPERTY(Transient)
	TObjectPtr<UCurveVector> TargetLocationOffsetCurve;

	UPROPERTY(Transient)
	TObjectPtr<UCurveFloat> FOVCurve;
#pragma endregion ZoomCurve

	int CameraModePriority = 0;

	FCameraMultiLayerParam YawSensitivity{1};

	FCameraMultiLayerParam PitchSensitivity{1};

	float FOVDelta = 0;

	FCameraMultiLayerParam OverrideZoom{-1.f};

	FRotator RotDelta = FRotator::ZeroRotator;

	float ZoomDelta = 0;

	bool bActivate = false;

	bool bApplyPOVPostProcess = true;

protected:
	bool bAdsorptionZoom = false;
	bool bRevertZoom = false;
	float RevertZoom = false;
	FVector RevertSocketOffset = FVector::ZeroVector;
	FVector2D PivotScreen = FVector2D::ZeroVector;
	ECameraEaseFunction::Type AdsorptionEaseType = ECameraEaseFunction::Linear;
	FVector2D AdsorptionSpeed = FVector2D::ZeroVector;
	FVector AdsorptionSpeedThreshold = FVector::ZeroVector;
	float AdsorptionMinZoom = 0.f;
	float AdsorptionMaxZoom = 0.f;

	bool bRotWithRecover = false;
	FRotator RotWithRecover = FRotator::ZeroRotator;
	FVector OffWithRecover = FVector::ZeroVector;
	ECameraEaseFunction::Type RecoverEaseType = ECameraEaseFunction::Linear;

	FVector2D MouseCoPos = FVector2D::ZeroVector;
	FVector2D ScreenOff = FVector2D::ZeroVector;

	// 捏脸特写所需参数
	bool bCustomRoleMode = false;
	float CachedThresholdRatio = 1.f;
	float CloseUpZOffset = 0.f;
	float LookAtZOffset = 0.f;
	float CustomRoleThresholdZoom = 0.f;
	float CustomRoleZoomDynamicMaxZoom = 0.f;
	float CustomRoleMaxPitchCloseUp = 0.f;
	float CustomRoleMaxPitchThreshold = 0.f;
	FRotator CustomRoleLookAtRot = FRotator::ZeroRotator;
	FRotator CustomRoleCloseUpRot = FRotator::ZeroRotator;
	FVector2D CustomRoleCloseUpViewOffset = FVector2D::ZeroVector;
	float CustomRoleViewOffsetHalfLife = 0.f;

	float CustomRolePreviousPitch = 0.f;
	// 全身展示所需
	bool bAdaptiveViewOffset = false;
	FVector2D AdaptiveViewOffsetXWithZoom = FVector2D::ZeroVector;
	FVector2D AdaptiveViewOffsetYWithZoom = FVector2D::ZeroVector;
	float AdaptiveViewOffsetHalfLife = 0.f;
};