// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Shakes/DefaultCameraShakeBase.h"
#include "Camera/CameraTypes.h"
#include "BaseCameraShake.generated.h"

/**
 * 
 */
UCLASS()
class KGCHARACTER_API UBaseCameraShake : public UDefaultCameraShakeBase
{
	GENERATED_BODY()

public:
	UBaseCameraShake(const FObjectInitializer& ObjectInitializer);

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float Scale = 1.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	ECameraShakePlaySpace PlaySpace = ECameraShakePlaySpace::CameraLocal;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition="PlaySpace == ECameraShakePlaySpace::UserDefined", EditConditionHides))
	FRotator UserPlaySpaceRot = FRotator::ZeroRotator;
};
