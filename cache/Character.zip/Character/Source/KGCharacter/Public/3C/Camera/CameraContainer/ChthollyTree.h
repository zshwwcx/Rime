﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once
#include "Containers/Set.h"

template <typename ValueType>
struct TChthollyNode
{
    int Left, Right;
	mutable ValueType Value;
	TChthollyNode(int L, int R, ValueType V) : Left(L), Right(R), Value(V) {}

	bool operator<(const TChthollyNode& Other) const { return Left < Other.Left; }
};

/**
 * 
 */
template <typename ValueType>
struct TChthollyTree
{
public:
	TChthollyTree();
	TChthollyTree(ValueType InDefaultValue);
	TChthollyTree(int InLeft, int InRight, ValueType InValue, ValueType InDefaultValue);

	void Assign(int Left, int Right, ValueType Value);

	ValueType Get(float Pos) const;

	ValueType GetDefault() const { return DefaultValue; };

private:
	int Split(int Pos);

	int LowerBound(float Pos) const;

private:
	TArray<TChthollyNode<ValueType>> Tree;
	ValueType DefaultValue;
};

template <typename ValueType>
TChthollyTree<ValueType>::TChthollyTree()
{
	Tree.Empty();
	DefaultValue = ValueType();
}

template <typename ValueType>
TChthollyTree<ValueType>::TChthollyTree(ValueType InDefaultValue)
{
	Tree.Empty();
	DefaultValue = InDefaultValue;
}

template <typename ValueType>
TChthollyTree<ValueType>::TChthollyTree(int InLeft, int InRight, ValueType InValue, ValueType InDefaultValue)
{
	Tree.Empty();
	Assign(InLeft, InRight, InValue);
	DefaultValue = InDefaultValue;
}

template <typename ValueType>
int TChthollyTree<ValueType>::Split(int Pos)
{
	int Index = LowerBound(Pos);
	if (Index < Tree.Num() && Tree[Index].Left == Pos)
	{
		return Index;
	}
	--Index;
	if(Index < 0)
	{
		TChthollyNode<ValueType>& Node = Tree[++Index];
		Tree.Insert(TChthollyNode<ValueType>(Pos, Node.Right - 1, DefaultValue), Index);
		return Index;
	}
	TChthollyNode<ValueType>& Node = Tree[Index];
	int Left = Node.Left, Right = Node.Right;
	ValueType Value = Node.Value;
	if(Pos >= Right)
	{
		Right = Pos + 1;
	}
	Tree.RemoveAt(Index);
	Tree.Insert(TChthollyNode<ValueType>(Left, Pos - 1, Value), Index);
	Tree.Insert(TChthollyNode<ValueType>(Pos, Right, DefaultValue), Index + 1);
	return Index + 1;
}

template <typename ValueType>
void TChthollyTree<ValueType>::Assign(int Left, int Right, ValueType Value)
{
	if(Tree.Num() == 0)
	{
		Tree.Emplace(TChthollyNode<ValueType>(Left, Right, Value));
		return;
	}

	int Begin = Split(Left);
	int End = Split(Right + 1);
	Tree.RemoveAt(Begin, End - Begin);
	Tree.Insert(TChthollyNode<ValueType>(Left, Right, Value), Begin);
}

template <typename ValueType>
int TChthollyTree<ValueType>::LowerBound(float Pos) const
{
	int Start = 0;
	int Last = Tree.Num();
	while (Start < Last)
	{
		int Mid = Start + ((Last - Start) >> 1);
		if (Tree[Mid].Left >= Pos)
		{
			Last = Mid;
		}
		else
		{
			Start = Mid + 1;
		}
	}
	return Start;
}

template <typename ValueType>
ValueType TChthollyTree<ValueType>::Get(float Pos) const
{
	int Index = 0;
	int Last = Tree.Num();
	while (Index < Last)
	{
		int Mid = Index + ((Last - Index) >> 1);
		if (Tree[Mid].Right < Pos)
		{
			Index = Mid + 1;
		}
		else
		{
			Last = Mid;
		}
	}

	if(Index < Tree.Num())
	{
		auto& Node = Tree[Index];
		return Node.Left <= Pos ? Node.Value : DefaultValue;
	}

	return DefaultValue;
}
