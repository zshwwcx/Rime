﻿#pragma once

#include "3C/Camera/PostProcessNew/PostProcessInstance/PPNonMaterialBase.h"
#include "Engine/Texture2D.h"
#include "3C/Camera/PostProcessNew/PPDataAsset.h"

class KGPPPhotoFilter : public KGPPNonMaterialBase
{
public:
	void InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType,
		const FString& InPhotoFilterDataAssetPath);

	virtual bool OnTaskStart() override;
	virtual void OnTaskEnd(EKGPostProcessStopReason StopReason) override;
	virtual bool CanOutputPostProcess() const override;
	
protected:
	void OnDataAssetLoaded(int InLoadID, UObject* Asset);

	int32 AssetLoadID = 0;
	FString PhotoFilterDataAssetPath;
	TStrongObjectPtr<UKGPhotoFilterPostProcessDataAsset> DataAsset;
};
