﻿#pragma once
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPMaterialFog.h"

struct FKGMultiTargetFogTargetInfo
{
	uint32 SlotIndex = 0;
	FTimerHandle RemoveTimerHandle;
};

/**
 * 相对与普通Fog来说, 普通Fog仅支持点亮主角脚底区域, 而MultiTargetFog支持点亮多个目标区域, 每个目标脚下的迷雾范围、强度都可以单独设置
 * 从逻辑层面, 可以直接在MaterialFog上做功能扩展, 但是从性能层面, MultiTargetFog材质如果直接在MaterialFog材质上做扩展, 会导致普通Fog的材质复杂度大幅提升,
 * 从TA层面上, 需要将两个材质分开, 按照之前定的规范, 后处理类型需要与材质一一对应, 因此这里扩展一个新的后处理类型, 并继承自MaterialFog
 */
class KGPPMaterialMultiTargetFog : public KGPPMaterialFog
{
public:
	void InitParams(const FKGPPCommonParams& CommonParams, 
		EKGPostProcessType InPPType, const FString& InMaterialPath, const FString& InPlaneMeshMaterialPath,
		int32 InViewPriority, const FName& InIntensityParamName, const FKGPPMaterialParams& InParams, TWeakObjectPtr<UPostProcessManager> InPPManager,
		float InBlendTimeSeconds, float InFogDistanceInMeters, float InHeadInfoHiddenDist, int32 InMaxExtraTargetNum);
	
	void AddOrUpdateFogTarget(
		KGEntityID EntityID, const FName& AvoidDistanceParamNamePrefix, float AvoidDistanceInMeters,
		const FName& AvoidSmoothDistParamNamePrefix, float AvoidSmoothDist, const FName& FogOpacityParamPrefix,
		const FName& EntityPosParamNamePrefix, float InBlendTimeSeconds);
	void RemoveFogTarget(KGEntityID EntityID, const FName& FogOpacityParamPrefix, float InBlendTimeSeconds);
	
protected:

	virtual void OnTaskEnd(EKGPostProcessStopReason StopReason) override;
	
	bool GetAvailableSlotIndex(uint32& OutSlotIndex);
	void OnTargetFogOpacityReachZero(KGEntityID EntityID);
	void InternalRemoveFogTarget(KGEntityID EntityID);
	
	static FName GetParamNameBySlotIndex(const FName& ParamNamePrefix, uint32 SlotIndex)
	{
		return FName(*FString::Printf(TEXT("%s%d"), *ParamNamePrefix.ToString(), SlotIndex));
	}
	
	int32 MaxExtraTargetNum = 0;
	TMap<KGEntityID, FKGMultiTargetFogTargetInfo> FogTargetInfos;
};
