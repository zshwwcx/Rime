#pragma once
#include "3C/Camera/PostProcessNew/PPCommon.h"
#include "Engine/Scene.h"
#include "Camera/PlayerCameraManager.h"

class UPostProcessManager;

struct FKGPPBlendWeightCalculator
{
	void StartBlendIn(float BlendInTime);
	void StartBlendOut(float BlendOutTime);
	void Tick(float DeltaTim);
	
	float CurrentBlendWeight = 0.0f;
	float AccumulatedTime = 0.0f;
	// 这个是由于优先级变化时, 可能会出现blend in过程中需要blend out, 或者blend out过程中需要blend in的情况
	// 为了不让当前权重突变, 因此开启blend时记录一下target值, 每次blend tick都按照 target 值进行blend
	float StartBlendWeight = 0.0f;
	float TargetBlendWeight = 0.0f;
	bool bBlendActive = false;
	float BlendTime = 0.0;
};

struct FKGPPCustomStencilInfo
{
	FKGPPCustomStencilInfo() = default;
	FKGPPCustomStencilInfo(int32 InLogicType, int32 InPriority, bool bInRenderCustomDepth, int32 InCustomDepthStencilValue, bool bInNiagaraRenderCustomDepth)
		: LogicType(InLogicType), Priority(InPriority), bRenderCustomDepth(bInRenderCustomDepth), CustomDepthStencilValue(InCustomDepthStencilValue),
			bNiagaraRenderCustomDepth(bInNiagaraRenderCustomDepth) {}
	
	int32 LogicType = -1;
	int32 Priority = 0;
	bool bRenderCustomDepth = true;
	int32 CustomDepthStencilValue = 0;
	bool bNiagaraRenderCustomDepth = false;
};

// 所有后处理效果基类, 定义后处理基础属性
class KGPPBase
{
public:

	KGPPBase();
	virtual ~KGPPBase() = default;

	void InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager);
	
	// 返回当前后处理类型
	virtual EKGPostProcessType GetPPType() const = 0;
	// 返回必要的PP Instance调试信息, 用于日志和屏幕绘制调试, 输出简单信息, 方便快速定位问题
	virtual FString GetDebugInfo() const = 0;
	// 真正返回后处理效果
	virtual bool CanOutputPostProcess() const { return IsActivated() || (IsBlendActive() && !IsDisabled()); }
	virtual bool GetPostProcessResult(FPostProcessSettings& OutPPSettings, float& OutPPBlendWeight, EViewTargetBlendOrder& OutPPBlendOrder) const = 0;
	
	virtual bool IsMaterialPP() const { return false; }
	virtual bool IsNonMaterialPP() const { return false; }

	// 通常情况下, 一个后处理同时只能存在一个实例生效, 并按照业务优先级来决定哪个实例生效
	// 但是后处理在打断结束时需要能够淡出, 对于被打断正在淡出的后处理效果, 不参与优先级比较, 允许多个后处理实例同时存在
	// 但是还存在一些相对复杂的后处理效果, 会修改角色材质, custom depth等效果, 这些类型的后处理无法同时存在
	// 1, 该类型后处理被抢占打断时, 不会淡出
	// 2, 该类型后处理结束时, 如果优先队列不为空, 则无法触发淡出
	// 3, 该类型的后处理当新的后处理效果生效时, 会尝试打断所有正在结束淡出的后处理实例
	virtual bool CanActivateMultiPPInstance() const { return true; }
	bool StartBlendInPP(bool bOverrideBlendInTime, float NewBlendInTime, EKGPostProcessBlendReason InBlendReason);
	bool StartBlendOutPP(bool bOverrideBlendOutTime, float NewBlendOutTime, EKGPostProcessBlendReason InBlendReason);
	bool IsInInterruptedBlendOut() const
	{
		return PostProcessState == EKGPostProcessState::InterruptedBlendingOut_Activated ||
			PostProcessState == EKGPostProcessState::InterruptedBlendingOut_PendingDeactivated ||
			PostProcessState == EKGPostProcessState::InterruptedBlendingOut_Deactivated;
	}
	bool CanInterruptedBlendOut() const { return PostProcessState == EKGPostProcessState::Activated; }
	
	bool DoTaskStart();
	void DoTaskEnd(EKGPostProcessStopReason StopReason);
	void DoTaskActivated();
	void DoTaskDeactivated();
	void DoTaskTick(float DeltaTime);
	
	bool IsLifeTimeExpired() const
	{
		return (TotalLifeTimeSeconds > 0 && AccumulateLifeTimeSeconds >= TotalLifeTimeSeconds) ||
			PostProcessState == EKGPostProcessState::InterruptedBlendingOut_ActivatedFinished ||
			PostProcessState == EKGPostProcessState::InterruptedBlendingOut_DeactivatedFinished;
	}
	int32 GetPriority() const { return Priority; }
	int32 GetSequenceID() const { return SequenceID; }
	int32 GetPostProcessID() const { return PostProcessID; }
	float GetTotalLifeTimeSeconds() const { return TotalLifeTimeSeconds; }
	bool ShouldDestroyWhenLeaveSpace() const { return bDestroyWhenLeaveSpace; }
	
	TArray<int32>& GetLinkedPostProcessIDs() { return LinkedPostProcessIDs; }
	bool IsActivated() const { return PostProcessState == EKGPostProcessState::Activated || PostProcessState == EKGPostProcessState::InterruptedBlendingOut_Activated; }
	EKGPostProcessState GetPostProcessState() const { return PostProcessState; }

	TSet<uint32>& GetPPTags() { return PPTags; }
	int32 GetSourceType() const { return SourceType; }

	void RegisterPostProcessQualityChangedDelegate();
	void UnregisterPostProcessQualityChangedDelegate();
	virtual void OnPostProcessQualityChanged(EKGPostProcessQuality NewQuality) {}

	void SetEntityCustomDepth(KGEntityID EntityID, int32 LogicType, int32 InPriority, bool bRenderCustomDepth, int32 CustomDepthStencilValue, bool bNiagaraRenderCustomDepth);
	void RevertEntityCustomDepth(KGEntityID EntityID);

	void AddDisableReason(EKGPostProcessDisableReason Reason) { DisableMask |= (1 << static_cast<uint32>(Reason)); }
	void RemoveDisableReason(EKGPostProcessDisableReason Reason) { DisableMask &= ~(1 << static_cast<uint32>(Reason)); }
	bool IsDisabled() const { return DisableMask != 0; }
	
	virtual void AdvancePPTime(float DeltaTime);
	
	bool operator<(const KGPPBase& Other) const
	{
		return Priority == Other.Priority ? 
			SequenceID > Other.SequenceID :
			Priority > Other.Priority;
	}
	
protected:

	// OnTaskStart&OnTaskEnd是后处理实例的开始与结束, 但是受优先级影响, 后处理start以后不一定能够立刻activate, OnTaskActivated&OnTaskDeactivated
	// 是对应后处理实例真正开始启用与停止的回调
	virtual bool OnTaskStart();
	virtual void OnTaskEnd(EKGPostProcessStopReason StopReason);
	virtual void OnTaskActivated();
	virtual void OnTaskDeactivated();
	virtual void OnTaskTick(float DeltaTime);

	bool IsBlendActive() const { return BlendWeightCalculator.bBlendActive; }
	virtual bool CanUseCommonBlend() const { return true; }
	virtual void OnBlendWeightChanged() {}
	void SetCurrentBlendWeight(float BlendWeight)
	{
		BlendWeightCalculator.CurrentBlendWeight = FMath::Clamp(BlendWeight, KG_PP_INTENSITY_MIN, KG_PP_INTENSITY_MAX);
		OnBlendWeightChanged();
	}
	
	void InternalSetCustomDepthInfo(KGEntityID EntityID);
	void InternalRevertCustomDepthInfo(KGEntityID EntityID);
	
	TSet<uint32> PPTags;
	int32 Priority = 0;
	int32 SequenceID = 0;
	int32 PostProcessID = 0;
	TArray<int32> LinkedPostProcessIDs;
	EKGPostProcessState PostProcessState = EKGPostProcessState::UnInitialized;
	// -1表示无限时长
	float TotalLifeTimeSeconds = -1.0f;
	float AccumulateLifeTimeSeconds = 0.0f;
	bool bDestroyWhenLeaveSpace = false;
	int32 SourceType = 0;
	TMap<KGEntityID, FKGPPCustomStencilInfo> CustomDepthEntityIDs;

	uint32 DisableMask = 0;
	
	float BlendInTime = 0.0f;
	float BlendOutTime = 0.0f;
	uint64 PPStartFrame = 0;
	EKGPostProcessBlendReason CurrentBlendReason = EKGPostProcessBlendReason::None;
	FKGPPBlendWeightCalculator BlendWeightCalculator;

	TWeakObjectPtr<UPostProcessManager> PostProcessManager;
};
