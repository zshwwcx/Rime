// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "3C/Camera/CameraAction/CameraActionBase.h"
#include "CameraNavigationMoveAction.generated.h"

/**
 * 
 */
UCLASS()
class KGCHARACTER_API UCameraNavigationMoveAction : public UCameraActionBase
{
	GENERATED_BODY()
public:
	UFUNCTION(BlueprintCallable)
	void Init(float InYawBlendParam, float InPitchBlendParam, float InLockPitch, float InActionCD);

	virtual void Play() override;
	virtual bool ProcessViewRotation(class AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch, double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot) override;

	// 有输入时进入冷却
	virtual bool IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType) override;

	virtual void DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode) override;

	virtual bool IsStronglySetRotation() const override { return false; };

private:
	void InitParams();

private:
	float YawBlendParam = 0.f;
	float PitchBlendParam = 0.f;

	float LockPitch = 0.f;
	float ActionCD = 0.f;
	float CurrentCDTime = 0.f;

	static constexpr float CDCorrect = 0.1f;
	
	TWeakObjectPtr<class URoleMovementComponent> MoveComponent = nullptr;
};
