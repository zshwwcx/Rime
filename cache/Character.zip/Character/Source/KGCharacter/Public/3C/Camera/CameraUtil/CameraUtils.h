// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "3C/Camera/CameraUtil/CameraEase.h"
#include "Misc/MathFormula.h"
#include "Curves/CurveBase.h"
#include "Curves/CurveFloat.h"

UENUM(BlueprintType)
namespace ECameraManualControlType
{
	enum Type : int
	{
		ManualZoom,
		ManualRot
	};
}



template <typename T>
class FCameraInterpolationEaseParam
{
public:
	FCameraInterpolationEaseParam() : EaseType(ECameraEaseFunction::Linear), BlendTime(0)
	{
	}

	FCameraInterpolationEaseParam(const T& InStart, const T& InEnd, const T& InBlendTime, ECameraEaseFunction::Type InEaseFunction) : Start(InStart), End(InEnd), Result(InStart), EaseType(InEaseFunction), BlendTime(InBlendTime), Pct(0.f), TotalTime(0.f) {}

	void Refresh(const T& InStart, const T& InEnd, float InBlendTime, ECameraEaseFunction::Type InEaseFunction = ECameraEaseFunction::Linear);
	void Refresh(const T& InStart, const T& InEnd);
	void RefreshEnd(const T& InEnd);
	void RefreshStart(const T& InStart);
	float GetParam() const { return BlendTime; }
	void SetParam(float NewParam) { BlendTime = NewParam; TotalTime = Pct * BlendTime; }
	bool IsEnd() const { return Pct == End; }
	void MarkFinish();

	T GetStart() { return Start; }
	T GetEnd() { return End; }

	T Evaluate(float DeltaTime);

private:
	T Start;
	T End;
	T Result;
	ECameraEaseFunction::Type EaseType;
	float BlendTime = 0.f;
	float Pct = 0.f;
	float TotalTime = 0.f;
};

template <typename T>
class FCameraInterpolationPara_Curve
{
public:
	FCameraInterpolationPara_Curve() {}

	FCameraInterpolationPara_Curve(const T& InStart, const T& InEnd, float InBlendTime, UCurveFloat* InCurve) :
		Start(InStart), End(InEnd), Result(InStart), BlendTime(InBlendTime), Pct(0.f), TotalTime(0.f), EaseCurve(InCurve), MinTime(0), MaxTime(0), MinValue(0),
		MaxValue(0)
	{
	}

	void Refresh(const T& InStart, const T& InEnd, float InBlendTime);
	void Refresh(const T& InStart, const T& InEnd);
	void RefreshEnd(const T& InEnd);
	void RefreshStart(const T& InStart);
	float GetParam() const { return BlendTime; }
	void SetParam(float NewParam) { BlendTime = NewParam; TotalTime = Pct * BlendTime;}
	bool IsEnd() const { return Result == End; }
	void MarkFinish();

	void SetCurve(UCurveFloat* InCurve);

	T GetStart() { return Start; }
	T GetEnd() { return End; }

	T Evaluate(float DeltaTime);

private:
	T Start;
	T End;
	T Result;
	float BlendTime = 0.f;
	float Pct = 1.f;
	float TotalTime = 0.f;

	TWeakObjectPtr<UCurveFloat> EaseCurve;
	float MinTime = 0.f;
	float MaxTime = 0.f;
	float MinValue = 0.f;
	float MaxValue = 0.f;
};

template <typename T>
class FCameraInterpolationParam_Decay
{
public:
	FCameraInterpolationParam_Decay() {}

	FCameraInterpolationParam_Decay(const T& InStart, const T& InEnd, float HalfLife) :
		Start(InStart), End(InEnd), HalfLife(HalfLife)
	{
	}

	void Refresh(const T& InStart, const T& InEnd, float InHalfLife);
	void Refresh(const T& InStart, const T& InEnd);
	void RefreshEnd(const T& InEnd);
	void RefreshStart(const T& InStart);
	void RefreshParam(float InHalfLife) { HalfLife = InHalfLife; }
	float GetParam() const { return HalfLife; }
	void SetParam(float NewParam) { HalfLife = NewParam; }
	bool IsEnd() const { return Start == End; }
	void MarkFinish();

	T GetStart() { return Start; }
	T GetEnd() { return End; }

	T Evaluate(float DeltaTime);

private:
	T Start;
	T End;
	float HalfLife = 0.f;
};

template <typename T>
class FCameraInterpolationParam_Spring
{
public:
	FCameraInterpolationParam_Spring() {}

	FCameraInterpolationParam_Spring(const T& InStart, const T& InEnd, float InSmoothTime, const T& InStartSpeed, const T& InTargetSpeed) :
		Start(InStart), End(InEnd), StartSpeed(InStartSpeed), InitSpeed(InStartSpeed), SmoothTime(InSmoothTime), TargetSpeed(InTargetSpeed)
	{
	}

	void Refresh(const T& InStart, const T& InEnd, float InSmoothTime, const T& InStartSpeed, const T& InTargetSpeed);
	void Refresh(const T& InStart, const T& InEnd, float InSmoothTime);
	void Refresh(const T& InStart, const T& InEnd);
	void RefreshEnd(const T& InEnd);
	void RefreshStart(const T& InStart);
	void RefreshParam(float InSmoothTime) { SmoothTime = InSmoothTime; };
	float GetParam() const { return SmoothTime; }
	void SetParam(float NewParam) { SmoothTime = NewParam; }
	bool IsEnd() const { return Start == End; }
	void MarkFinish();

	void SetTargetSpeed(const T& InTargetSpeed) { TargetSpeed = InTargetSpeed; }
	void SetStartSpeed(const T& InStartSpeed) { StartSpeed = InStartSpeed; }
	T GetStartSpeed() { return StartSpeed; }

	T GetStart() { return Start; }
	T GetEnd() { return End; }

	T Evaluate(float DeltaTime);

private:
	T Start;
	T End;
	T StartSpeed;
	T InitSpeed;
	float SmoothTime = 0.f;
	T TargetSpeed;
};

template <typename T>
struct FCameraInterpolationParam
{
public:
	FCameraInterpolationParam() : EaseType(ECameraEaseFunction::Linear) {}

	void Refresh(const T& InStart, const T& InEnd, float Param, const T& InStartSpeed, const T& InTargetSpeed, UCurveFloat* InCurve);
	void Refresh(const T& InStart, const T& InEnd, const T& InStartSpeed, const T& InTargetSpeed);
	void Refresh(const T& InEnd, const T& InStartSpeed, const T& InTargetSpeed);
	void Refresh(const T& InStart, const T& InEnd);
	void RefreshEnd(const T& InEnd);
	void RefreshStart(const T& InEnd);

	bool IsEnd() const;

	T GetStart();
	T GetEnd();
	
	void SetEase(const T& InStart, const T& InEnd, float InBlendTime);
	void SetEase(const T& InStart, const T& InEnd, float InBlendTime, ECameraEaseFunction::Type InEaseFunction);
	void SetDecay(const T& InStart, const T& InEnd, float InHalfLife);
	float GetParam() const;
	void SetParam(float NewParam);
	void SetSpring(const T& InStart, const T& InEnd, float InSmoothTime, const T& InStartSpeed, const T& InTargetSpeed);
	void SetSpring(const T& InStart, const T& InEnd, float InSmoothTime);
	void SetSpringSmoothTime(float InSmoothTime);
	void SetSpringTargetSpeed(const T& InTargetSpeed);
	T GetSpringStartSpeed() { return SpringParam.GetStartSpeed(); }
	void MarkFinish();
	float GetSpringSmoothTime() const { return SpringParam.GetParam(); };
	void SetCurve(const T& InStart, const T& InEnd, float InBlendTime, UCurveFloat* InCurve);
	void SetCurve(const T& InStart, const T& InEnd, float InBlendTime);

	T Evaluate(float DeltaTime);

	ECameraEaseFunction::Type EaseType;

private:
	FCameraInterpolationEaseParam<T> EaseParam;
	FCameraInterpolationParam_Decay<T> DecayParam;
	FCameraInterpolationParam_Spring<T> SpringParam;
	FCameraInterpolationPara_Curve<T> CurveParam;
};

struct FCameraMultiLayerParam
{
public:
	FCameraMultiLayerParam();
	FCameraMultiLayerParam(float Value);

	operator float() const; 
	
	void SetValueByPriority(float Value, int Priority = 0);

	float GetValueBelowPriority(int Priority, float DefaultValue) const;

	float GetValueByPriority(int Priority, float DefaultValue) const;

	float GetValueBelowOrEqualPriority(int Priority, float DefaultValue) const;

	void RemoveValueByPriority(int Priority);

	bool IsTopPriority(int Priority) const;

	bool GetValueSecondaryPriority(float& OutValue) const;

	void SetValueSecondaryPriority(float Value);
	
	void Reset(float Value);

	float GetValue() const;

	int GetTopPriority() const;
	int GetTopPriorityBelowPriority(int Priority) const;
	
	void RemoveValueWithoutBase();

	void UpdateAllAbovePriority(float Value, int Priority);

private:
	TArray<TPair<int, float>> Param;
};

struct FCameraMultiLayerParam_FVector
{
public:
	FCameraMultiLayerParam_FVector();
	FCameraMultiLayerParam_FVector(const FVector& Value);

	operator FVector() const; 

	void SetValueByPriority(const FVector& Value, int Priority = 0);

	FVector GetValueBelowPriority(int Priority, const FVector& DefaultValue) const;
	
	void RemoveValueByPriority(int Priority);

	bool IsTopPriority(int Priority) const;

	void Reset(FVector Value);

	bool GetValueSecondaryPriority(FVector& OutValue) const;

	void SetValueSecondaryPriority(const FVector& Value);
	
	FVector GetValue() const;

	int GetTopPriority() const;

	void RemoveValueWithoutBase();
	
private:
	TArray<TPair<int, FVector>> Param;
};

struct FCameraMultiLayerParam_FRotator
{
public:
	FCameraMultiLayerParam_FRotator();
	FCameraMultiLayerParam_FRotator(const FRotator& Value);

	operator FRotator() const; 

	void SetValueByPriority(const FRotator& Value, int Priority = 0);

	FRotator GetValueBelowPriority(int Priority, const FRotator& DefaultValue) const;
	
	void RemoveValueByPriority(int Priority);

	bool IsTopPriority(int Priority);

	void Reset(FRotator Value);

	bool GetValueSecondaryPriority(FRotator& OutValue);

	void SetValueSecondaryPriority(const FRotator& Value);
	
	FRotator GetValue() const;

	int GetTopPriority() const;

	void RemoveValueWithoutBase();

private:
	TArray<TPair<int, FRotator>> Param;
};

template <typename T>
void FCameraInterpolationEaseParam<T>::Refresh(const T& InStart, const T& InEnd, float InBlendTime, ECameraEaseFunction::Type InEaseFunction)
{
	Start = InStart;
	End = InEnd;
	BlendTime = InBlendTime;
	Pct = 0.f;
	TotalTime = 0.f;
	EaseType = InEaseFunction;
	Result = Start;
}

template <typename T>
void FCameraInterpolationEaseParam<T>::Refresh(const T& InStart, const T& InEnd)
{
	Start = InStart;
	End = InEnd;
	Result = Start;
	Pct = 0.f;
	TotalTime = 0.f;	
}

template <typename T>
void FCameraInterpolationEaseParam<T>::RefreshEnd(const T& InEnd)
{
	End = InEnd;
}

template <typename T>
void FCameraInterpolationEaseParam<T>::RefreshStart(const T& InStart)
{
	Start = InStart;
	Pct = 0.f;
	Result = Start;
	TotalTime = 0.f;
}

template <>
inline FRotator FCameraInterpolationEaseParam<FRotator>::Evaluate(float DeltaTime)
{
	if(BlendTime <= 0)
	{
		Result = End;
		return Result;
	}

	if(DeltaTime <= 0)
	{
		Pct = FMath::Min(1.f, TotalTime / BlendTime);
		const FRotator DeltaAng = (End - Start).GetNormalized();
		Result = Start + DeltaAng * FCameraEaseCalculate::Evaluate<float>(EaseType, 0, 1, Pct);
		return Result;
	}

	if(TotalTime <= BlendTime)
	{
		TotalTime += DeltaTime;
		Pct = FMath::Min(1.f, TotalTime / BlendTime);
	}

	const FRotator DeltaAng = (End - Start).GetNormalized();
	Result = Start + DeltaAng * FCameraEaseCalculate::Evaluate<float>(EaseType, 0, 1, Pct);
	return Result;
}

template <>
inline FQuat FCameraInterpolationEaseParam<FQuat>::Evaluate(float DeltaTime)
{
	if(BlendTime <= 0)
	{
		Result = End;
		return End;
	}

	if(DeltaTime <= 0)
	{
		Pct = FMath::Min(1.f, TotalTime / BlendTime);
		Result = FQuat::Slerp(Start, End, FCameraEaseCalculate::Evaluate<float>(EaseType, 0, 1, Pct));
		return Result;
	}

	if(TotalTime <= BlendTime)
	{
		TotalTime += DeltaTime;
		Pct = FMath::Min(1.f, TotalTime / BlendTime);
	}

	Result = FQuat::Slerp(Start, End, FCameraEaseCalculate::Evaluate<float>(EaseType, 0, 1, Pct));
	return Result;
}

template <typename T>
void FCameraInterpolationEaseParam<T>::MarkFinish()
{
	Result = End;
	Start = End;
	TotalTime = BlendTime;
	Pct = 1.f;
}

template <typename T>
T FCameraInterpolationEaseParam<T>::Evaluate(float DeltaTime)
{
	if(BlendTime <= 0)
	{
		Result = End;
		return End;
	}

	if(DeltaTime <= 0)
	{
		Pct = FMath::Min(1.f, TotalTime / BlendTime);
		Result = FCameraEaseCalculate::Evaluate(EaseType, Start, End, Pct);
		return Result;
	}

	if(TotalTime <= BlendTime)
	{
		TotalTime += DeltaTime;
		Pct = FMath::Min(1.f, TotalTime / BlendTime);
	}

	Result = FCameraEaseCalculate::Evaluate(EaseType, Start, End, Pct);
	return Result;
}

template <typename T>
void FCameraInterpolationPara_Curve<T>::Refresh(const T& InStart, const T& InEnd, float InBlendTime)
{
	Start = InStart;
	Result = Start;
	End = InEnd;
	BlendTime = InBlendTime;
	Pct = 0.f;
	TotalTime = 0.f;
}

template <typename T>
void FCameraInterpolationPara_Curve<T>::Refresh(const T& InStart, const T& InEnd)
{
	Start = InStart;
	Result = Start;
	End = InEnd;
	Pct = 0.f;
	TotalTime = 0.f;
}

template <typename T>
void FCameraInterpolationPara_Curve<T>::RefreshEnd(const T& InEnd)
{
	End = InEnd;
}

template <typename T>
void FCameraInterpolationPara_Curve<T>::RefreshStart(const T& InStart)
{
	Start = InStart;
	Result = Start;
	Pct = 0.f;
	TotalTime = 0.f;
}

template <typename T>
void FCameraInterpolationPara_Curve<T>::MarkFinish()
{
	Start = End;
	Result = End;
	Pct = 1.f;
	TotalTime = BlendTime;
}

template <typename T>
void FCameraInterpolationPara_Curve<T>::SetCurve(UCurveFloat* InCurve)
{
	EaseCurve = InCurve;
	if(EaseCurve.IsValid())
	{
		EaseCurve->GetValueRange(MinValue, MaxValue); 
		EaseCurve->GetTimeRange(MinTime, MaxTime); 
	}
}

template <>
inline FRotator FCameraInterpolationPara_Curve<FRotator>::Evaluate(float DeltaTime)
{
	if(!EaseCurve.IsValid() || BlendTime <= 0)
	{
		Result = End;
		return Result;
	}

	if(DeltaTime <= 0)
	{
		Pct = FMath::Min(1.f, TotalTime / BlendTime);
		float Factor = (EaseCurve->GetFloatValue(Pct * (MaxTime - MinTime) + MinTime) - MinValue) / (MaxValue - MinValue);
		const FRotator DeltaAng = (End - Start).GetNormalized();
		Result = Start + DeltaAng * Factor;
		return Result;
	}

	if (TotalTime <= BlendTime)
	{
		TotalTime += DeltaTime;
		Pct = FMath::Min(1.f, TotalTime / BlendTime);
	}

	float Factor = (EaseCurve->GetFloatValue(Pct * (MaxTime - MinTime) + MinTime) - MinValue) / (MaxValue - MinValue);
	const FRotator DeltaAng = (End - Start).GetNormalized();
	Result = Start + DeltaAng * Factor;
	return Result;
}

template <>
inline FQuat FCameraInterpolationPara_Curve<FQuat>::Evaluate(float DeltaTime)
{
	if(!EaseCurve.IsValid() || BlendTime <= 0)
	{
		Result = End;
		return Result;
	}

	if(DeltaTime <= 0)
	{
		Pct = FMath::Min(1.f, TotalTime / BlendTime);
		float Factor = (EaseCurve->GetFloatValue(Pct * (MaxTime - MinTime) + MinTime) - MinValue) / (MaxValue - MinValue);
		Result = FQuat::Slerp(Start, End, Factor);
		return Result;
	}

	if (TotalTime <= BlendTime)
	{
		TotalTime += DeltaTime;
		Pct = FMath::Min(1.f, TotalTime / BlendTime);
	}

	float Factor = (EaseCurve->GetFloatValue(Pct * (MaxTime - MinTime) + MinTime) - MinValue) / (MaxValue - MinValue);
	Result = FQuat::Slerp(Start, End, Factor);
	return Result;
}

template <typename T>
T FCameraInterpolationPara_Curve<T>::Evaluate(float DeltaTime)
{
	if(!EaseCurve.IsValid() || BlendTime <= 0)
	{
		Result = End;
		return Result;
	}

	if(DeltaTime <= 0)
	{
		Pct = FMath::Min(1.f, TotalTime / BlendTime);
		float Factor = (EaseCurve->GetFloatValue(Pct * (MaxTime - MinTime) + MinTime) - MinValue) / (MaxValue - MinValue);
		Result = Start + (End - Start) * Factor;
		return Result;
	}

	if (TotalTime <= BlendTime)
	{
		TotalTime += DeltaTime;
		Pct = FMath::Min(1.f, TotalTime / BlendTime);
	}

	float Factor = (EaseCurve->GetFloatValue(Pct * (MaxTime - MinTime) + MinTime) - MinValue) / (MaxValue - MinValue);
	Result = Start + (End - Start) * Factor;
	return Result;
}

template <typename T>
void FCameraInterpolationParam_Decay<T>::Refresh(const T& InStart, const T& InEnd, float InHalfLife)
{
	Start = InStart;
	End = InEnd;
	HalfLife = InHalfLife;
}

template <typename T>
void FCameraInterpolationParam_Decay<T>::Refresh(const T& InStart, const T& InEnd)
{
	Start = InStart;
	End = InEnd;
}

template <typename T>
void FCameraInterpolationParam_Decay<T>::RefreshEnd(const T& InEnd)
{
	End = InEnd;
}

template <typename T>
void FCameraInterpolationParam_Decay<T>::RefreshStart(const T& InStart)
{
	Start = InStart;
}

template <typename T>
void FCameraInterpolationParam_Decay<T>::MarkFinish()
{
	Start = End;
}

template <>
inline FRotator FCameraInterpolationParam_Decay<FRotator>::Evaluate(float DeltaTime)
{
	if(DeltaTime <= 0)
	{
		return Start;
	}

	if (HalfLife <= 0.0f)
	{
		Start = End;
		return End;
	}

	float Factor = 1 - FMath::Pow(0.5f, DeltaTime / HalfLife);
	const FRotator DeltaAng = (End - Start).GetNormalized();
	Start = Start + DeltaAng * Factor;
	return Start;
}

template <>
inline FQuat FCameraInterpolationParam_Decay<FQuat>::Evaluate(float DeltaTime)
{
	if(DeltaTime <= 0)
	{
		return Start;
	}

	if (HalfLife <= 0.0f)
	{
		Start = End;
		return End;
	}

	float Factor = FMath::Pow(0.5f, DeltaTime / HalfLife);
	Start = FQuat::Slerp(End, Start, Factor);
	return Start;
}

template <typename T>
T FCameraInterpolationParam_Decay<T>::Evaluate(float DeltaTime)
{
	if(DeltaTime <= 0)
	{
		return Start;
	}

	if (HalfLife <= 0.0f) {
		Start = End;
		return End;
	}
	float Factor = FMath::Pow(0.5f, DeltaTime / HalfLife);

	Start = End + (Start - End) * Factor;
	return Start;
}

template <typename T>
void FCameraInterpolationParam_Spring<T>::Refresh(const T& InStart, const T& InEnd, float InSmoothTime, const T& InStartSpeed,
												  const T& InTargetSpeed)
{
	Start = InStart;
	End = InEnd;
	SmoothTime = InSmoothTime;
	StartSpeed = InStartSpeed;
	InitSpeed = InStartSpeed;
	TargetSpeed = InTargetSpeed;
}

template <typename T>
void FCameraInterpolationParam_Spring<T>::Refresh(const T& InStart, const T& InEnd, float InSmoothTime)
{
	Start = InStart;
	End = InEnd;
	SmoothTime = InSmoothTime;
}

template <typename T>
void FCameraInterpolationParam_Spring<T>::Refresh(const T& InStart, const T& InEnd)
{
	Start = InStart;
	End = InEnd;
}

template <typename T>
void FCameraInterpolationParam_Spring<T>::RefreshEnd(const T& InEnd)
{
	End = InEnd;
}

template <typename T>
void FCameraInterpolationParam_Spring<T>::RefreshStart(const T& InStart)
{
	Start = InStart;
}

template <typename T>
void FCameraInterpolationParam_Spring<T>::MarkFinish()
{
	Start = End;
	StartSpeed = InitSpeed;
}

template <typename T>
T FCameraInterpolationParam_Spring<T>::Evaluate(float DeltaTime)
{
	if(DeltaTime <= 0)
	{
		return Start;
	}

	FMath::SpringDamperSmoothing(Start, StartSpeed, End, TargetSpeed, DeltaTime, SmoothTime, 1);
	return Start;
}

template <>
inline FRotator FCameraInterpolationParam_Spring<FRotator>::Evaluate(float DeltaTime)
{
	if(DeltaTime <= 0)
	{
		return Start;
	}

	if (SmoothTime <= 0.0f)
	{
		Start = End;
		return End;
	}
	
	float Factor = 1 - FMath::Pow(0.5f, DeltaTime / SmoothTime);
	const FRotator DeltaAng = (End - Start).GetNormalized();
	Start = Start + DeltaAng * Factor;
	return Start;
}

template <>
inline float FCameraInterpolationParam_Spring<float>::Evaluate(float DeltaTime)
{
	if(DeltaTime <= 0)
	{
		return Start;
	}

	//FMath::SpringDamperSmoothing(Start, StartSpeed, End, TargetSpeed, DeltaTime, SmoothTime, 1);
	Start = MathFormula::SmoothDamp(Start, End, StartSpeed, SmoothTime, DeltaTime);
	return Start;
}

template <>
inline FVector FCameraInterpolationParam_Spring<FVector>::Evaluate(float DeltaTime)
{
	if(DeltaTime <= 0)
	{
		return Start;
	}

	MathFormula::SmoothDamp(Start, Start, End, StartSpeed, SmoothTime, DeltaTime);
	return Start;
}

template <typename T>
void FCameraInterpolationParam<T>::Refresh(const T& InStart, const T& InEnd, float Param, const T& InStartSpeed,
                                           const T& InTargetSpeed, UCurveFloat* InCurve)
{
	switch (EaseType) {
	case ECameraEaseFunction::Spring:
		SetSpring(InStart, InEnd, Param, InStartSpeed, InTargetSpeed);
		break;
	case ECameraEaseFunction::Decay:
		SetDecay(InStart, InEnd, Param);
		break;
	case ECameraEaseFunction::Curve:
		SetCurve(InStart, InEnd, Param, InCurve);
		break;
	default:
		SetEase(InStart, InEnd, Param, EaseType);
	}
}

template <typename T>
void FCameraInterpolationParam<T>::Refresh(const T& InStart, const T& InEnd, const T& InStartSpeed, const T& InTargetSpeed)
{
	switch (EaseType) {
	case ECameraEaseFunction::Spring:
		SpringParam.Refresh(InStart, InEnd, InStartSpeed, InTargetSpeed);
		break;
	case ECameraEaseFunction::Decay:
		DecayParam.Refresh(InStart, InEnd);
		break;
	case ECameraEaseFunction::Curve:
		CurveParam.Refresh(InStart, InEnd);
		break;
	default:
		EaseParam.Refresh(InStart, InEnd);
		break;
	}
}

template <typename T>
void FCameraInterpolationParam<T>::Refresh(const T& InEnd, const T& InStartSpeed, const T& InTargetSpeed)
{
	switch (EaseType) {
	case ECameraEaseFunction::Spring:
		SpringParam.Refresh(InEnd, InStartSpeed, InTargetSpeed);
		break;
	case ECameraEaseFunction::Decay:
		DecayParam.Refresh(InEnd);
		break;
	case ECameraEaseFunction::Curve:
		CurveParam.Refresh(InEnd);
		break;
	default:
		EaseParam.Refresh(InEnd);
		break;
	}
}

template <typename T>
void FCameraInterpolationParam<T>::Refresh(const T& InStart, const T& InEnd)
{
	switch (EaseType) {
	case ECameraEaseFunction::Spring:
		SpringParam.Refresh(InStart, InEnd);
		break;
	case ECameraEaseFunction::Decay:
		DecayParam.Refresh(InStart, InEnd);
		break;
	case ECameraEaseFunction::Curve:
		CurveParam.Refresh(InStart, InEnd);
		break;
	default:
		EaseParam.Refresh(InStart, InEnd);
		break;
	}
}

template <typename T>
void FCameraInterpolationParam<T>::RefreshEnd(const T& InEnd)
{
	switch (EaseType) {
	case ECameraEaseFunction::Spring:
		SpringParam.RefreshEnd(InEnd);
		break;
	case ECameraEaseFunction::Decay:
		DecayParam.RefreshEnd(InEnd);
		break;
	case ECameraEaseFunction::Curve:
		CurveParam.RefreshEnd(InEnd);
		break;
	default:
		EaseParam.RefreshEnd(InEnd);
		break;
	}
}

template <typename T>
void FCameraInterpolationParam<T>::RefreshStart(const T& InEnd)
{
	switch (EaseType) {
	case ECameraEaseFunction::Spring:
		SpringParam.RefreshStart(InEnd);
		break;
	case ECameraEaseFunction::Decay:
		DecayParam.RefreshStart(InEnd);
		break;
	case ECameraEaseFunction::Curve:
		CurveParam.RefreshStart(InEnd);
		break;
	default:
		EaseParam.RefreshStart(InEnd);
		break;
	}
}

template <typename T>
bool FCameraInterpolationParam<T>::IsEnd() const
{
	switch (EaseType) {
	case ECameraEaseFunction::Spring:
		return SpringParam.IsEnd();
	case ECameraEaseFunction::Decay:
		return DecayParam.IsEnd();
	case ECameraEaseFunction::Curve:
		return CurveParam.IsEnd();
	default:
		return EaseParam.IsEnd();
	}
}

template <typename T>
T FCameraInterpolationParam<T>::GetStart()
{
	switch (EaseType) {
	case ECameraEaseFunction::Spring:
		return SpringParam.GetStart();
	case ECameraEaseFunction::Decay:
		return DecayParam.GetStart();
	case ECameraEaseFunction::Curve:
		return CurveParam.GetStart();
	default:
		return EaseParam.GetStart();
	}
}

template <typename T>
T FCameraInterpolationParam<T>::GetEnd()
{
	switch (EaseType) {
	case ECameraEaseFunction::Spring:
		return SpringParam.GetEnd();
	case ECameraEaseFunction::Decay:
		return DecayParam.GetEnd();
	case ECameraEaseFunction::Curve:
		return CurveParam.GetEnd();
	default:
		return EaseParam.GetEnd();
	}
}

template <typename T>
void FCameraInterpolationParam<T>::SetEase(const T& InStart, const T& InEnd, float InBlendTime)
{
	EaseParam.Refresh(InStart, InEnd, InBlendTime, EaseType);
}

template <typename T>
void FCameraInterpolationParam<T>::SetEase(const T& InStart, const T& InEnd, float InBlendTime,
                                        ECameraEaseFunction::Type InEaseFunction)
{
	EaseParam.Refresh(InStart, InEnd, InBlendTime, InEaseFunction);
	EaseType = InEaseFunction;
}

template <typename T>
void FCameraInterpolationParam<T>::SetDecay(const T& InStart, const T& InEnd, float InHalfLife)
{
	DecayParam.Refresh(InStart, InEnd, InHalfLife);
	EaseType = ECameraEaseFunction::Decay;
}

template <typename T>
float FCameraInterpolationParam<T>::GetParam() const
{
	switch (EaseType)
	{
	case ECameraEaseFunction::Spring:
		return SpringParam.GetParam();
	case ECameraEaseFunction::Decay:
		return DecayParam.GetParam();
	case ECameraEaseFunction::Curve:
		return CurveParam.GetParam();
	default:
		return EaseParam.GetParam();
	}
}

template <typename T>
void FCameraInterpolationParam<T>::SetParam(float NewParam)
{
	switch (EaseType)
	{
	case ECameraEaseFunction::Spring:
		SpringParam.SetParam(NewParam);
		break;
	case ECameraEaseFunction::Decay:
		DecayParam.SetParam(NewParam);
		break;
	case ECameraEaseFunction::Curve:
		CurveParam.SetParam(NewParam);
		break;
	default:
		EaseParam.SetParam(NewParam);
		break;
	}
}

template <typename T>
void FCameraInterpolationParam<T>::SetSpring(const T& InStart, const T& InEnd, float InSmoothTime,
                                             const T& InStartSpeed, const T& InTargetSpeed)
{
	SpringParam.Refresh(InStart, InEnd, InSmoothTime, InStartSpeed, InTargetSpeed);
	EaseType = ECameraEaseFunction::Spring;
}

template <typename T>
void FCameraInterpolationParam<T>::SetSpring(const T& InStart, const T& InEnd, float InSmoothTime)
{
	SpringParam.Refresh(InStart, InEnd, InSmoothTime);
	EaseType = ECameraEaseFunction::Spring;
}

template <typename T>
void FCameraInterpolationParam<T>::SetSpringSmoothTime(float InSmoothTime)
{
	SpringParam.RefreshParam(InSmoothTime);
}

template <typename T>
void FCameraInterpolationParam<T>::SetSpringTargetSpeed(const T& InTargetSpeed)
{
	SpringParam.SetTargetSpeed(InTargetSpeed);
}

template <typename T>
void FCameraInterpolationParam<T>::MarkFinish()
{
	switch (EaseType)
	{
	case ECameraEaseFunction::Spring:
		return SpringParam.MarkFinish();
	case ECameraEaseFunction::Decay:
		return DecayParam.MarkFinish();
	case ECameraEaseFunction::Curve:
		return CurveParam.MarkFinish();
	default:
		return EaseParam.MarkFinish();
	}
}

template <typename T>
void FCameraInterpolationParam<T>::SetCurve(const T& InStart, const T& InEnd, float InBlendTime,
                                            UCurveFloat* InCurve)
{
	CurveParam.Refresh(InStart, InEnd, InBlendTime);
	CurveParam.SetCurve(InCurve);
	EaseType = ECameraEaseFunction::Curve;
}

template <typename T>
void FCameraInterpolationParam<T>::SetCurve(const T& InStart, const T& InEnd, float InBlendTime)
{
	CurveParam.Refresh(InStart, InEnd, InBlendTime);
	EaseType = ECameraEaseFunction::Curve;
}

template <typename T>
T FCameraInterpolationParam<T>::Evaluate(float DeltaTime)
{
	switch (EaseType)
	{
	case ECameraEaseFunction::Spring:
		return SpringParam.Evaluate(DeltaTime);
	case ECameraEaseFunction::Decay:
		return DecayParam.Evaluate(DeltaTime);
	case ECameraEaseFunction::Curve:
		return CurveParam.Evaluate(DeltaTime);
	default:
		return EaseParam.Evaluate(DeltaTime);
	}
}
