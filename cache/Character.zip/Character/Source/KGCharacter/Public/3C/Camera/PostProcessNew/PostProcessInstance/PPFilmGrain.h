#pragma once

#include "3C/Camera/PostProcessNew/PostProcessInstance/PPNonMaterialBase.h"
#include "Engine/Texture2D.h"

class KGPPFilmGrain : public KGPPNonMaterialBase
{
public:
	void InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType,
		const FPostProcessSettings& InPostProcessSettings, const FString& InFilmGrainTexturePath);

	virtual bool OnTaskStart() override;
	virtual void OnTaskEnd(EKGPostProcessStopReason StopReason) override;
	virtual bool CanOutputPostProcess() const override;
	
protected:

	void OnFilmGrainTextureLoaded(int InLoadID, UObject* Asset);

	uint32 AssetLoadID = 0;
	FString FilmGrainTexturePath;
	TStrongObjectPtr<UTexture2D> FilmGrainTexture;
};
