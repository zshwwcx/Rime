﻿#pragma once
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPMaterialBase.h"

struct FKGPPEffectInfo
{
	TArray<uint32> ChangeMaterialReqIDs;
	TArray<uint32> ChangeMaterialParamReqIDs;
	EKGPPSketchEffectType EffectType = EKGPPSketchEffectType::ClearLine;
	bool bChangeCustomDepth = false;
	int32 LogicType = 0;
	int32 Priority = 0;
	int32 CustomStencilValue = 0;

	bool HasTakenEffect() const
	{
		return ChangeMaterialReqIDs.Num() > 0 || ChangeMaterialParamReqIDs.Num() > 0;
	}
};

class KGPPMaterialSketch : public KGPPMaterialBase
{
public:
	virtual bool CanActivateMultiPPInstance() const override { return false; }
	
	virtual bool OnTaskStart() override;
	virtual void OnTaskEnd(EKGPostProcessStopReason StopReason) override;
	virtual void OnTaskActivated() override;
	virtual void OnTaskDeactivated() override;

	void AddSketchTarget(KGEntityID EntityID, bool bChangeCustomDepth, int32 LogicType, int32 InPriority, int32 CustomStencilValue, EKGPPSketchEffectType EffectType);
	void RemoveSketchTarget(KGEntityID EntityID);
	
protected:

	void InternalChangeEntityMaterialEffect(KGEntityID EntityID);
	void InternalRevertEntityMaterialEffect(KGEntityID EntityID);
	void OnActorLoaded(KGEntityID EntityID, AActor* Actor);

	TMap<KGEntityID, FKGPPEffectInfo> TargetEffectInfo;
};
