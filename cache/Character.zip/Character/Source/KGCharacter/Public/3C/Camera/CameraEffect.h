#pragma once

#include "CoreMinimal.h"
#include "Camera/CameraModifier.h"

#include "CameraEffect.generated.h"



/**
 * 摄像机效果基类
 * 具体各效果由ModifyCamera 和 ModifyPostProcess覆盖实现
 */
UCLASS(Abstract, BlueprintType, Blueprintable)
class KGCHARACTER_API UCameraEffect : public UCameraModifier
{
	GENERATED_BODY()

#pragma region Override
public:
	virtual void UpdateAlpha(float DeltaTime) override;

	virtual void ToggleModifier() override;

	virtual void SetAlphaInTime(float InTime) { AlphaInTime = InTime; }

	virtual void SetAlphaOutTime(float OutTime) { AlphaOutTime = OutTime; }

	virtual void SetAlphaInCurve(UCurveFloat* InCurve) { BlendInCurve = InCurve; }

	virtual void SetAlphaOutCurve(UCurveFloat* InCurve) { BlendOutCurve = InCurve; }

	virtual void DisableModifier(bool bImmediate = false) override;

#pragma endregion Override


#pragma region Common

protected:
	UPROPERTY()
	float LinerAlpha;

	UPROPERTY()
	TObjectPtr<UCurveFloat> BlendInCurve;

	UPROPERTY()
	TObjectPtr<UCurveFloat> BlendOutCurve;

#pragma endregion Common


#pragma region Property
public:
	UFUNCTION(BlueprintCallable)
	void SetAutoRemoveFromList(bool bNeedRemove);

	virtual void OnInterrupt();

	bool ShouldDelete() const { return bMarkDelete;}

protected:
	// 是否自动从CameraManager的列表中移除
	bool bAutoRemoveFromList = true;

	// 是否自动从CameraManager的列表中移除
	bool bMarkDelete = false;

#pragma endregion Property
};


#pragma region PostProcess
UCLASS(Abstract, BlueprintType, Blueprintable)
class KGCHARACTER_API UCEPostProcess : public UCameraEffect
{
	GENERATED_BODY()
};



// 改变后处理材质
UCLASS(BlueprintType, Blueprintable)
class KGCHARACTER_API UCEPPMaterial : public UCEPostProcess
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FWeightedBlendable Blendable;

public:
	virtual void ModifyPostProcess(float DeltaTime, float& PostProcessBlendWeight, FPostProcessSettings& PostProcessSettings) override;
};



// PC端改变景深参数
UCLASS(BlueprintType, Blueprintable)
class KGCHARACTER_API UCEPPDepthOfField_PC : public UCEPostProcess
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float SensorWidth = 60.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float SqueezeFactor = 2.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float FocalDistance = 300.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float DepthBlurAmount = 1.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float BlurRadius = 100.f;

public:
	virtual void ModifyPostProcess(float DeltaTime, float& PostProcessBlendWeight, FPostProcessSettings& PostProcessSettings) override;
};



// 改变景深参数
UCLASS(BlueprintType, Blueprintable)
class KGCHARACTER_API UCEPPDepthOfField : public UCEPostProcess
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bMobileHQGaussian = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float FocalRegion = 0.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float NearTransitionRegion = 300.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float FarTransitionRegion = 8000.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float Scale = 1.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float NearBlurSize = 15.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float FarBlurSize = 15.f;

public:
	virtual void ModifyPostProcess(float DeltaTime, float& PostProcessBlendWeight, FPostProcessSettings& PostProcessSettings) override;
};



// 改变曝光参数
UCLASS(BlueprintType, Blueprintable)
class KGCHARACTER_API UCEPPBloom : public UCEPostProcess
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 bOverride_BloomMethod : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 bOverride_BloomIntensity : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 bOverride_BloomThreshold : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 bOverride_Bloom1Tint : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 bOverride_Bloom1Size : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 bOverride_Bloom2Size : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 bOverride_Bloom2Tint : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 bOverride_Bloom3Tint : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 bOverride_Bloom3Size : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 bOverride_Bloom4Tint : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 bOverride_Bloom4Size : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 bOverride_Bloom5Tint : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 bOverride_Bloom5Size : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 bOverride_Bloom6Tint : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 bOverride_Bloom6Size : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 bOverride_BloomSizeScale : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 bOverride_BloomConvolutionTexture : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 bOverride_BloomConvolutionSize : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 bOverride_BloomConvolutionCenterUV : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 bOverride_BloomConvolutionPreFilterMin : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 bOverride_BloomConvolutionPreFilterMax : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 bOverride_BloomConvolutionPreFilterMult : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 bOverride_BloomConvolutionBufferScale : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TEnumAsByte<enum EBloomMethod> BloomMethod;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float BloomIntensity;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float BloomThreshold;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float BloomSizeScale;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float Bloom1Size;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float Bloom2Size;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float Bloom3Size;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float Bloom4Size;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float Bloom5Size;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float Bloom6Size;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FLinearColor Bloom1Tint;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FLinearColor Bloom2Tint;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FLinearColor Bloom3Tint;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FLinearColor Bloom4Tint;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FLinearColor Bloom5Tint;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FLinearColor Bloom6Tint;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float BloomConvolutionSize;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	class UTexture2D* BloomConvolutionTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector2D BloomConvolutionCenterUV;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float BloomConvolutionPreFilterMin;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float BloomConvolutionPreFilterMax;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float BloomConvolutionPreFilterMult;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float BloomConvolutionBufferScale;

public:
	virtual void ModifyPostProcess(float DeltaTime, float& PostProcessBlendWeight, FPostProcessSettings& PostProcessSettings) override;
};

#pragma endregion PostProcess
