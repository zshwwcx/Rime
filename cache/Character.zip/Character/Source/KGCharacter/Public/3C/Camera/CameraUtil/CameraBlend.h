// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Camera/CameraTypes.h"
#include "CameraBlend.generated.h"

UENUM(BlueprintType)
namespace ECameraViewBlendFunction
{
	enum Type : int
	{
		Liner,
		Polar,
		PolarWithPivotLerp
	};
}

USTRUCT(Blueprintable)
struct FCameraSnapShot
{
	GENERATED_BODY()

	UPROPERTY(transient)
	FMinimalViewInfo POV;

	UPROPERTY(transient)
	float RealArmLen = 0.f;
	
	UPROPERTY(transient)
	FVector PivotLocation = FVector::ZeroVector;

	UPROPERTY(transient)
	TWeakObjectPtr<AActor> LookAtActor = nullptr;
	
	UPROPERTY(transient)
	FVector LookAtActorLocation = FVector::ZeroVector;

	UPROPERTY(transient)
	FRotator PivotRotation = FRotator::ZeroRotator;
	
	UPROPERTY(transient)
	FVector2D ScreenOffset = FVector2D::ZeroVector;

	UPROPERTY(transient)
	FVector SocketOffset = FVector::ZeroVector;
	
	UPROPERTY(transient)
	FRotator SocketRotOffset = FRotator::ZeroRotator;

	UPROPERTY(transient)
	TWeakObjectPtr<AActor> CameraTarget = nullptr;

	UPROPERTY(transient)
	TWeakObjectPtr<APlayerController> PlayerController = nullptr;
};

class FCameraBlend
{
public:
	void SetViewBlendType(ECameraViewBlendFunction::Type NewBlendType);

	void CustomBlendPOV(FCameraSnapShot& OutSnapShot, const FCameraSnapShot& Source, const FCameraSnapShot& Target, float BlendPct, bool bHasRotationInput, bool bHasModifyRotation, bool& bDoDotBlendRot, class ACameraManager* CameraManager);

	void BlendPOV_Liner(FCameraSnapShot& OutSnapShot, const FCameraSnapShot& Source, const FCameraSnapShot& Target, float BlendPct);

	void BlendPOV_RotateWithTarget(FCameraSnapShot& OutSnapShot, const FCameraSnapShot& Source, const FCameraSnapShot& Target, float BlendPct, bool bForcePivotLerp, bool bHasRotationInput, bool bHasModifyRotation, bool& bDoDotBlendRot, class ACameraManager* CameraManager);

	void BlendNormalParams(FCameraSnapShot& OutSnapShot, const FCameraSnapShot& Source, const FCameraSnapShot& Target, float BlendPct);

private:
	ECameraViewBlendFunction::Type BlendType = ECameraViewBlendFunction::Liner;
};
