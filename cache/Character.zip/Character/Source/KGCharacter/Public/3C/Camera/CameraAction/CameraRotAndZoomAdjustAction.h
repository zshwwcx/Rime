// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "3C/Camera/CameraAction/CameraActionBase.h"
#include "CameraRotAndZoomAdjustAction.generated.h"

/**
 * 
 */
UCLASS()
class KGCHARACTER_API UCameraRotAndZoomAdjustAction : public UCameraActionBase
{
	GENERATED_BODY()

public:
	void Init(float Pitch, float Yaw, float Zoom, float InBlendInTime, float InBlendOutTime, float InDuration, bool bInRecover, ECameraEaseFunction::Type InBlendInType, ECameraEaseFunction::Type InBlendOutType, int64 InBlendInCurve, int64 InBlendOutCurve);

	virtual void Play() override;
	
	virtual void ModifyCamera(float DeltaTime) override;

	virtual bool ProcessViewRotation(class AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch, double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot) override;

	virtual bool IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType) override { return true; };

	virtual void DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode) override;

	virtual void Abort() override;

private:
	void InitParams();

private:
	FRotator TargetRotation = FRotator::ZeroRotator;
	FRotator RotateBase = FRotator::ZeroRotator;

	float TargetZoom = 0.f;
	float ZoomBase = 0.f;
};
