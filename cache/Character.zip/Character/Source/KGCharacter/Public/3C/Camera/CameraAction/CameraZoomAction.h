// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "3C/Camera/CameraAction/CameraActionBase.h"
#include "CameraZoomAction.generated.h"

/**
 * 
 */
UCLASS()
class KGCHARACTER_API UCameraZoomAction : public UCameraActionBase
{
	GENERATED_BODY()

public:
	void Init(float Zoom, float ZoomOffset, bool bInRecover, bool bInCanInterrupt, float InBlendInTime, float InBlendOutTime, float InDuration, ECameraEaseFunction::Type InBlendInType, ECameraEaseFunction::Type InBlendOutType, int64 InBlendInCurve, int64 InBlendOutCurve);

	virtual void Play() override;

	virtual void ModifyCamera(float DeltaTime) override;

	virtual void Abort() override;
	
	virtual void DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode) override;
	
	virtual bool IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType) override;

private:
	void InitParams();

private:
	float TargetZoom = -1.f;
	float ZoomBase = 0.f;

	float TargetZoomOffset = 0.f;
	float ZoomOffsetBase = 0.f;

	bool bCanInterrupt = false;
};
