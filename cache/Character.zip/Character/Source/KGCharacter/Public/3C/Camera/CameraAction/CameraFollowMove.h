// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "3C/Camera/CameraAction/CameraActionBase.h"
#include "Containers/Queue.h"
#include "CameraFollowMove.generated.h"

/**
 * 
 */
UCLASS()
class KGCHARACTER_API UCameraFollowMove : public UCameraActionBase
{
	GENERATED_BODY()
public:
	UFUNCTION(BlueprintCallable)
	void Init(float InYawBlendParam, float InYawBlendSubParam, float InPitchBlendParam, float InVelocityThreshold, float InLookPitchOffset, float InContinuousInputDurationThreshold, float InPitchSampleDuration, float InActionCD, float InInputThreshold);

	virtual void Play() override;
	virtual void Abort() override;
	virtual bool ProcessViewRotation(class AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch, double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot) override;

	// 有输入时进入冷却
	virtual bool IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType) override;

	virtual void DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode) override;

	virtual bool IsStronglySetRotation() const override { return false; };

private:
	void InitParams();

private:
	float YawBlendParam = 0.f;
	float YawBlendSubParam = 0.f;
	float PitchBlendParam = 0.f;

	float VelocityThreshold = 0.f;

	float LookPitchOffset = 0.f;
	float ActionCD = 0.f;
	float InputThreshold = 0.f;
	float CurrentCDTime = 0.f;
	float ContinuousInputDurationThreshold = 0.f;
	float CurrentInputDuration = 0.f;
	float PitchSampleDuration = 0.f; 

	float YawSmoothSpeed = 0.f;
	float YawBlend = 0.f;
	float PitchBlend = 0.f;
	float YawSign = 1.f;

	static constexpr float CDCorrect = 0.1f;

	TWeakObjectPtr<class URoleMovementComponent> MoveComponent = nullptr;
	TQueue<FVector> MoveNormalQueue;
	TQueue<float> MoveNormalTimeStampQueue;

	FVector MoveNormal = FVector::ZeroVector;

	float CapsuleRadius = 0.f;
	float CapsuleHalfHeight = 0.f;
	TWeakObjectPtr<class ABaseCharacter> LookAt;
};
