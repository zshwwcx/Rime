#pragma once

#include "3C/Camera/CameraAction/CameraActionBase.h"
#include "CameraActionFocusOnTarget.generated.h"



UCLASS(Blueprintable)
class KGCHARACTER_API UCameraActionFocusOnTarget : public UObject
{
	GENERATED_BODY()

public:
	static int GetFocusOnAdaptiveRotator(FRotator& Result, const FVector& ActorLocation, APlayerController* PC, ABaseCamera* InCamera, float InLeftX, float InRightX, float InUpY, float InDownY, float InCheckInScreenError, float InMiddleLockHeight, bool InbForceLockMiddle);

protected:
	static bool ScreenDeltaYawToCameraDeltaYaw(float CameraRootToCamera, float TargetToCameraRoot, float ScreenDeltaYaw, float& CameraDeltaYaw);
	static bool ScreenDeltaPitchToCameraDeltaPitch(float CameraRootToCamera, float TargetToCameraRoot, float ScreenDeltaPitch, float& CameraDeltaPitch);
	static bool CheckCanReachComfortRegion(bool bForceLockMiddle, const FVector& ActorLocation, ABaseCamera* Camera, float DeltaYaw, float UpAngle, float DownAngle);

};