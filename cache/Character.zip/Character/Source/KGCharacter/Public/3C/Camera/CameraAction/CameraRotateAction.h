// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "3C/Camera/CameraAction/CameraActionBase.h"
#include "CameraRotateAction.generated.h"

/**
 * 
 */
UCLASS()
class KGCHARACTER_API UCameraRotateAction : public UCameraActionBase
{
	GENERATED_BODY()

public:
	void Init(float Pitch, float Yaw, float Roll, float PitchOffset, float YawOffset, float RollOffset, bool bInRecover, bool bInCanInterrupt, float InBlendInTime, float InBlendOutTime, float InDuration, ECameraEaseFunction::Type InBlendInType, ECameraEaseFunction::Type InBlendOutType, int64 InBlendInCurve, int64 InBlendOutCurve);

	virtual bool ProcessViewRotation(class AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch, double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot) override;

	virtual void ModifyCamera(float DeltaTime) override;
	
	virtual void Play() override;

	virtual bool IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType) override;

	virtual void DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode) override;

private:
	void InitParams();

private:
	FRotator TargetRotate = FRotator::ZeroRotator;
	FRotator RotateBase = FRotator::ZeroRotator;

	FRotator TargetRotateOffset = FRotator::ZeroRotator;
	FRotator RotateOffsetBase = FRotator::ZeroRotator;

	bool bCanInterrupt = false;
};
