﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "3C/Camera/CameraAction/CameraActionBase.h"
#include "CameraActionBattleCorrection.generated.h"

/**
 * 
 */
UCLASS()
class KGCHARACTER_API UCameraActionBattleCorrection : public UCameraActionBase
{
	GENERATED_BODY()

public:
	// 轴以点->目标为坐标系为正方向判断
	UFUNCTION(BlueprintCallable)
	void Init(int64 TargetActorID, float BufferYawLeft, float SafeYawLeft, float SafeYawRight, float BufferYawRight, float BufferPitchHigh, float SafePitchHigh, float SafePitchLow, float BufferPitchLow, float NewBlendTime, int NewBlendInType, int64 NewCurveID, float NewAdaptiveRatio = 1.f);
	
	virtual void Play() override;
	virtual bool ProcessViewRotation(class AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch, double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot) override;
	virtual void Abort() override;

	// LUA手动控制 这里关掉
	virtual bool IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType) override { return false; }

	virtual void DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode) override;

	virtual bool IsStronglySetRotation() const override { return false; };
public:
	void CheckCameraRotationValid();

private:
	void NormalizeAxisRotator(FRotator& InRotator);

private:
	float AdaptiveRatio = 1.f;

	float BufferZoneYawLeft;
	float BufferZoneYawRight;
	float BufferZonePitchHigh;
	float BufferZonePitchLow;

	float SafeZoneYawLeft;
	float SafeZoneYawRight;
	float SafeZonePitchHigh;
	float SafeZonePitchLow;

	TWeakObjectPtr<USkeletalMeshComponent> LookSKMesh;
	TWeakObjectPtr<AActor> LookActor;

	FRotator ResultRotator = FRotator::ZeroRotator;
	FRotator BaseRotator = FRotator::ZeroRotator;

	bool bYawValid = false;
	bool bPitchValid = false;

	static const FName CameraLookBoneName;
};
