#pragma once

#include "3C/Camera/PostProcessNew/PostProcessInstance/PPNonMaterialBase.h"

class UTexture;

class KGPPDirtMask : public KGPPNonMaterialBase
{
public:
	void InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType,
		const FPostProcessSettings& InPostProcessSettings, const FString& InBloomDirtMaskTexturePath);

	virtual bool OnTaskStart() override;
	virtual void OnTaskEnd(EKGPostProcessStopReason StopReason) override;
	virtual bool CanOutputPostProcess() const override;
	
protected:

	void OnBloomDirtMaskTextureLoaded(int InLoadID, UObject* Asset);

	uint32 AssetLoadID = 0;
	FString BloomDirtMaskTexturePath;
	TStrongObjectPtr<UTexture> BloomDirtMaskTexture;
};
