#pragma once

#include "CoreMinimal.h"
#include "3C/Camera/CameraAction/CameraActionBase.h"
#include "Camera/CameraModifier.h"
#include "3C/Camera/CameraEffect.h"
#include "CameraLockLookForward.generated.h"



UCLASS( BlueprintType, Blueprintable)
class KGCHARACTER_API UCameraLockLookForward : public UCameraActionBase
{
	GENERATED_BODY()

public:
	void Init(int64 ActorID, float InRotSpeed);

	virtual bool ProcessViewRotation(class AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch, double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot) override;

	virtual void Play() override;

	virtual bool IsStronglySetRotation() const override { return false; };
private:
	TWeakObjectPtr<AActor> ForwardActor = nullptr;

	float RotSpeed = 5;
};
