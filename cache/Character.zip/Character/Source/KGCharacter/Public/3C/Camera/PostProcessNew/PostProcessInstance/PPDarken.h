#pragma once
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPNonMaterialBase.h"

class KGPPDarken : public KGPPNonMaterialBase
{
public:
	void InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType,
		const FPostProcessSettings& InPostProcessSettings, float InBaseExposureBias);

	virtual void OnTaskActivated() override;
	virtual void OnTaskDeactivated() override;
	
	virtual FString GetDebugInfo() const override;
	
protected:

	// 默认100%受光照影响
	float BaseExposureBias = 1.0f;
};
