#pragma once
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPMaterialBase.h"

class KGPPMaterialFog : public KGPPMaterialBase
{
public:

	void InitParams(const FKGPPCommonParams& CommonParams, EKGPostProcessType InPPType, const FString& InMaterialPath, const FString& InPlaneMeshMaterialPath,
		int32 InViewPriority, const FName& InIntensityParamName, const FKGPPMaterialParams& InParams, TWeakObjectPtr<UPostProcessManager> InPPManager,
		bool bInOverrideClimate, int32 InOverrideClimateID, float InFogDistanceInMeters, float InHeadInfoHiddenDist, float InBlendTimeSeconds);

	virtual void OnTaskEnd(EKGPostProcessStopReason StopReason) override;
	virtual void OnTaskActivated() override;
	virtual void OnTaskDeactivated() override;
	
	void UpdateFogDistance(const FName& FogDistanceParamName, float InFogDistance, float InHeadInfoHiddenDist, bool bOverrideBlendTime, float NewBlendTime);
	void UpdateFogOpacity(const FName& FogOpacityParamName, float TargetFogOpacity, float NewDuration);
	void UpdateFogParams(
		float HeadInfoHideDistInMeters, bool bInOverrideClimate, int32 InOverrideClimateID, float InBlendTimeSeconds,
		const FName& FogOpacityParamName, float FogOpacityTargetVal,
		const FName& MaxDistParamName, float MaxDistInMetersTargetVal,
		const FName& FogColorParamName, float FogColorR, float FogColorG, float FogColorB, float FogColorA,
		const FName& SmoothDistParamName, float SmoothDistInMetersTargetVal);

	void InternalUpdateFogDistance(const FName& FogDistanceParamName, float InFogDistance, float InHeadInfoHiddenDist, bool bOverrideBlendTime, float NewBlendTime);
	void OnOpacityReachZero();

protected:
	bool bOverrideClimate = false;
	int32 OverrideClimateID = 0;
	float FogDistanceInMeters = 0.0f;
	float HeadInfoHiddenDistInMeters = 0.0f;
	float BlendTimeSeconds = 0.0f;
	FTimerHandle OpacityReachZeroTimerHandle;
};
