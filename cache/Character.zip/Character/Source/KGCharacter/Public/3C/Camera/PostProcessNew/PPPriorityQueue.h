#pragma once
#include "3C/Camera/PostProcessNew/PPCommon.h"

class KGPPBase;

class KGPostProcessPriorityQueue
{
public:
	KGPostProcessPriorityQueue() = default;

	void AddNewPostProcess(TSharedPtr<KGPPBase> PPInst);
	void RemovePostProcess(int32 PostProcessID);
	KGPPBase* GetActivePostProcessInstance();
	KGPPBase* GetFirstNonDummyInstance();
	int32 GetNum() const { return PPInstances.Num(); }
	
private:
	
	TArray<TWeakPtr<KGPPBase>> PPInstances;
};
