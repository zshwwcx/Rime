// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CineCameraComponent.h"
#include "Misc/CommonDefines.h"
#include "BaseCineCameraComponent.generated.h"

/**
 * 
 */
UCLASS(HideCategories = (CameraSettings), HideFunctions = (SetFieldOfView, SetAspectRatio), Blueprintable, ClassGroup = Camera, meta = (BlueprintSpawnableComponent))
class KGCHARACTER_API UBaseCineCameraComponent : public UCineCameraComponent
{
	GENERATED_BODY()

public:
	UBaseCineCameraComponent();

	virtual void TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

	void ClearDitherFade();

private:
	void PostProcess(float DeltaTime);

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="PostProcess | Dither", meta=(DisplayName="是否启用虚化探测"))
	bool bDitherFadeDetect = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="PostProcess | Dither", meta=(DisplayName="虚化探测半径", EditCondition="bDitherFadeDetect == true", EditConditionHides))
	float DitherDetectRadius = 0.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PostProcess | Dither", meta=(DisplayName="虚化探测类型", EditCondition="bDitherFadeDetect == true", EditConditionHides))
	TArray<TEnumAsByte<EObjectTypeQuery>> DitherFadeObjectTypes;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PostProcess | Dither", meta=(DisplayName="虚化探测Actor类型匹配", EditCondition="bDitherFadeDetect == true", EditConditionHides, Tooltips = "若存在,只有符合类型的检测结果才能被虚化"))
	TArray<TSubclassOf<AActor>> DitherFadeObjectMatchActor;

private:
	TSet<int64> DetectDitherComponents;
	TMap<KGObjectID, TWeakObjectPtr<AActor>> DitherComponentToActor;

	FCollisionShape CollisionShape;
	FCollisionQueryParams CollisionQueryParams;
};
