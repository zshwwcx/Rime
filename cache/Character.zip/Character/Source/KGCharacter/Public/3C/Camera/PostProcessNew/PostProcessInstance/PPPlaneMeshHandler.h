﻿#pragma once

#include "GameFramework/Actor.h"
#include "UObject/StrongObjectPtr.h"

#include "PPPlaneMeshHandler.generated.h"

class UPostProcessManager;
class APlayerCameraManager;
class UStaticMeshComponent;
class UMaterialInstanceDynamic;

class KGPPPlaneMeshHandlerBase
{
public:
	virtual ~KGPPPlaneMeshHandlerBase() = default;
	
	virtual bool InitPlaneMeshHandler(TWeakObjectPtr<UPostProcessManager> PostProcessManager, UMaterialInstanceDynamic* PPMaterial, float PlaneMeshDistance) = 0;
	virtual void DestroyPlaneMeshHandler() = 0;
	virtual void UpdatePlaneMeshOnPPInstanceUpdate() {}
	virtual void UpdatePlaneMeshOnViewportUpdate(const FVector& Pos, const FRotator& Rot, float NewFOV) {}

	UStaticMeshComponent* GetPlaneMeshComponent() const
	{
		return PlaneMeshComponent.IsValid() ? PlaneMeshComponent.Get() : nullptr;
	}
	
protected:
	
	TStrongObjectPtr<UStaticMeshComponent> PlaneMeshComponent;

	FVector InitMeshComponentScale = FVector(1.0f, 1.0f, 1.0f);
	float CacheCameraFOV = -1.0f;
};

class KGPPPlaneMeshHandlerCameraManager : public KGPPPlaneMeshHandlerBase
{
public:
	virtual bool InitPlaneMeshHandler(TWeakObjectPtr<UPostProcessManager> PostProcessManager, UMaterialInstanceDynamic* PPMaterial, float PlaneMeshDistance) override;
	virtual void DestroyPlaneMeshHandler() override;
	virtual void UpdatePlaneMeshOnPPInstanceUpdate() override;

protected:
	
	TWeakObjectPtr<APlayerCameraManager> CachedCameraManager;
};

UCLASS()
class AKGPlaneMeshActor : public AActor
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual bool IsSelectable() const override { return false; }
#endif
};

// 在编辑器模式下, 可以实现面片跟随视角位置和朝向, 但是如果在视角位置放置一个mesh的话, 会导致所有的点选功能全部被这个mesh拦截掉, 导致无法选中viewport中的单位
// 后续引擎会单独开发接口来实现编辑器模式下的mesh面片后处理渲染
// 这里实现方式在引擎接口提供以后进行替换
class KGPPPlaneMeshHandlerViewport : public KGPPPlaneMeshHandlerBase
{
public:
	virtual bool InitPlaneMeshHandler(TWeakObjectPtr<UPostProcessManager> PostProcessManager, UMaterialInstanceDynamic* PPMaterial, float InPlaneMeshDistance) override;
	virtual void DestroyPlaneMeshHandler() override;
	virtual void UpdatePlaneMeshOnViewportUpdate(const FVector& Pos, const FRotator& Rot, float NewFOV) override;

protected:
	TWeakObjectPtr<AActor> PlaneMeshActor;
	FTransform RelativeTransform;
};