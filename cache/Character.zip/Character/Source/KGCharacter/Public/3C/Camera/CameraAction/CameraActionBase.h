#pragma once

#include "CoreMinimal.h"
#include "Misc/CommonDefines.h"
#include "3C/Camera/CameraManager.h"
#include "3C/Camera/KgCameraMode.h"
#include "3C/Camera/CameraUtil/CameraUtils.h"
#include "3C/Camera/CameraUtil/CameraEase.h"
#include "CameraActionBase.generated.h"

UCLASS(Abstract, Blueprintable, EditInlineNew)
class KGCHARACTER_API UCameraActionBase : public UObject
{
	friend class UCameraActionHandler;

	GENERATED_BODY()

public:
	UCameraActionBase(const FObjectInitializer& ObjectInitializer);

	void SetEaseInType(ECameraEaseFunction::Type NewEaseInType, float NewBlendInTime, KGObjectID CurveID);
	void SetEaseOutType(ECameraEaseFunction::Type NewEaseOutType, float NewBlendOutTime, KGObjectID CurveID);
	
	virtual void DisableAction(bool bImmediate = false);

	void OverrideBlendOutTime(float NewValue) { BlendOutTime = NewValue; InnerUpdateAlpha(0.f);}
	
	virtual void Play();
	void UpdateAlpha(float DeltaTime);
	virtual void UpdateAfterFrame();
	virtual void ModifyCamera(float DeltaTime);
	virtual void ModifyViewPOV(float DeltaTime, struct FMinimalViewInfo& InOutPOV);
	virtual bool ProcessViewRotation(class AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch, double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot);
	virtual void Abort();
	
	virtual bool IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType) { return true; }

	virtual void DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode);

	virtual bool IsStronglySetRotation() const { return true; }

	void SetPlayRate(float NewPlayRate) { PlayRate = NewPlayRate; }
	void SetPause(bool bNewPause) { bPause = bNewPause; }
	void SetPlayAt(float InAlpha) { RunningTime = FMath::Clamp(InAlpha, 0.f, 1.f) * Duration; InnerUpdateAlpha(0.f);}

protected:
	void InnerUpdateAlpha(float DeltaTime);
	
public:
	int64 ActionID = 0;

	UPROPERTY(transient)
	TWeakObjectPtr<ACameraManager> CameraManager;

	UPROPERTY(transient)
	TWeakObjectPtr<class UCameraActionHandler> ActionHandlerOwner;

	// 当前作用Mode
	UPROPERTY(transient)
	TWeakObjectPtr<UKgCameraMode> CameraMode;

	TArray<int> EffectCameraModesTag;

	float BlendInTime = 0.0f;
	float BlendOutTime = 0.0f;
	float Duration = 0.0f;
	float RunningTime = 0.0f;
	float PlayRate = 1.f;
	bool bPause = false;

	ECameraEaseFunction::Type BlendInType = ECameraEaseFunction::Linear;
	ECameraEaseFunction::Type BlendOutType = ECameraEaseFunction::Linear;
	bool bStartBlendOut = false;
	bool bStartBlendIn = false;

	UPROPERTY()
	TObjectPtr<UCurveFloat> BlendInCurve = nullptr;
	UPROPERTY()
	TObjectPtr<UCurveFloat> BlendOutCurve = nullptr;

	float Alpha = 0.f;

	bool bFinished = true;
	bool bRecover = true;

	bool bTickCurrentFrame = false;
	bool bAutoExitWhileModeDeActive = false;

	bool bNeedTick = false;
	int64 Priority = 0;
};