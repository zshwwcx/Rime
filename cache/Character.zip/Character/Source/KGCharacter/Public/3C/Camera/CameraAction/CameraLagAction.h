// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "3C/Camera/CameraAction/CameraActionBase.h"
#include "CameraLagAction.generated.h"

/**
 * 
 */
UCLASS()
class KGCHARACTER_API UCameraLagAction : public UCameraActionBase
{
	GENERATED_BODY()

public:
	void Init(float XYLag, float ZLag, float XYSoftRadius, float ZSoftRadius, float InBlendInTime, float InBlendOutTime, float InDuration, ECameraEaseFunction::Type InBlendInType, ECameraEaseFunction::Type InBlendOutType, int64 InBlendInCurve, int64 InBlendOutCurve);

	virtual void Play() override;

	virtual void ModifyCamera(float DeltaTime) override;

	virtual void Abort() override;
	
	virtual void DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode) override;
	
	virtual bool IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType) override { return false; };

private:
	void InitParams();

private:
	float TargetXYLag = -1.f;
	float XYLagBase = 0.f;

	float TargetZLag = -1.f;
	float ZLagBase = 0.f;

	float TargetXYSoftRadius = -1.f;
	float XYSoftRadiusBase = 0.f;

	float TargetZSoftRadius = -1.f;
	float ZSoftRadiusBase = 0.f;
};
