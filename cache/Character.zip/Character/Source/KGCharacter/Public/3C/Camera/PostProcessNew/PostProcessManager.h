#pragma once
#include "Manager/KGBasicManager.h"
#include "3C/Material/KGMaterialCommon.h"
#include "3C/Camera/PostProcessNew/PPCommon.h"
#include "3C/Camera/PostProcessNew/PPPriorityQueue.h"
#include "Engine/Scene.h"
#include "Camera/PlayerCameraManager.h"

#include "PostProcessManager.generated.h"

class KGPPBase;
class KGPPMaterialBase;
class KGPPNonMaterialBase;
class UStaticMesh;

DECLARE_MULTICAST_DELEGATE_OneParam(FKGPPOnPostProcessQualityChanged, EKGPostProcessQuality);

UCLASS(Blueprintable)
class KGCHARACTER_API UPostProcessManager : public UKGBasicManager, public FTickableGameObject
{
	GENERATED_BODY()

public:
	virtual void NativeInit() override;
	virtual void NativeUninit() override;
	virtual EManagerType GetManagerType() override { return EManagerType::EMT_PostProcessManager; }
	static UPostProcessManager* GetInstance(UObject* InContext)
	{
		return Cast<UPostProcessManager>(GetManagerByType(InContext, EManagerType::EMT_PostProcessManager));
	}

#pragma region Tick
	virtual UWorld* GetTickableGameObjectWorld() const override { return GetOuter()->GetWorld(); }
	virtual ETickableTickType GetTickableTickType() const override { return IsTemplate() ? ETickableTickType::Never : ETickableTickType::Always; }
	virtual bool IsAllowedToTick() const override { return !IsTemplate(); }
	virtual TStatId GetStatId() const override { RETURN_QUICK_DECLARE_CYCLE_STAT(UPostProcessManager, STATGROUP_Tickables);}
	virtual void Tick(float DeltaTime) override;

#if WITH_EDITOR
public:
	//编辑器下FTickableGameObject无法tick时，各编辑器主动调用
	UFUNCTION(BlueprintCallable)
	void EditorTick(float DeltaTime)
	{
		Tick(DeltaTime);
	}
#endif
#pragma endregion Tick

#pragma region PostProcess
public:
	// --------------------------------------------------------------------------------------------
	// 对于材质相关的后处理, 提供一个通用的后处理开始接口, 所有非材质后处理以及特殊材质后处理, 每个提供单独的开始接口
	// 对外的一些后效开始结束接口
	uint32 KAPI_PostProcessManager_StartCommonPostProcessWithMaterial(
		KG_PP_COMMON_PARAMS,
		EKGPostProcessType EffectType);	
	void InnerSetScalarParam(uint32 PPID, const FName& ParamName, float ParamVal);
	void InnerSetVectorParam(uint32 PPID, const FName& ParamName, float R, float G, float B, float A);
	void InnerSetTextureParam(uint32 PPID, const FName& ParamName, const FString& TexturePath);
	void InnerSetLinearSampleScalarParam(uint32 PPID, const FName& ParamName, float StartVal, float EndVal, float Duration);
	void InnerSetLinearSampleVectorParam(uint32 PPID, const FName& ParamName, float StartR, float StartG, float StartB, float StartA,
		float EndR, float EndG, float EndB, float EndA, float Duration);
	void InnerSetLinearBlendScalarParam(uint32 PPID, const FName& ParamName, float StartVal, float EndVal, float BlendInTime, float BlendOutTime, float Duration);
	void InnerSetCurveParam(uint32 PPID, const FName& ParamName, const FString& CurvePath, bool bNeedRemap, float RemapTime, bool bLoop);
	void InnerSetActorLocationParam(uint32 PPID, const FName& ParamName, KGObjectID ActorId);
	void InnerSetEntityLocationParam(uint32 PPID, const FName& ParamName, KGEntityID EntityID);
	void ActivateCommonPostProcessWithMaterial(uint32 PPID);
	
	// cpp版本调用接口
	uint32 StartCommonPostProcessWithMaterial(
		KG_PP_COMMON_PARAMS,
		EKGPostProcessType EffectType, const FKGPPMaterialParams& Params, bool bManualActivated=false);
	
	uint32 KAPI_PostProcessManager_StartBloomPP(
		KG_PP_COMMON_PARAMS,
		bool bOverride_BloomMethod, int32 BloomMethod,
		bool bOverride_BloomIntensity, float BloomIntensity,
		bool bOverride_BloomThreshold, float BloomThreshold,
		bool bOverride_BloomSizeScale, float BloomSizeScale);

	uint32 KAPI_PostProcessManager_StartGIIndirectLightPP(
		KG_PP_COMMON_PARAMS,
		bool bOverride_IndirectLightingColor,
		float IndirectLightingColorR, float IndirectLightingColorG, float IndirectLightingColorB, float IndirectLightingColorA,
		bool bOverride_IndirectLightingIntensity,
		float IndirectLightingIntensity);

	uint32 KAPI_PostProcessManager_StartChromaticAberrationPP(
		KG_PP_COMMON_PARAMS,
		bool bOverride_SceneFringeIntensity, float SceneFringeIntensity,
		bool bOverride_ChromaticAberrationStartOffset, float ChromaticAberrationStartOffset);

	uint32 KAPI_PostProcessManager_StartChromaticAberrationByCameraArmLengthPP(
		KG_PP_COMMON_PARAMS, float InMinCameraArmLength, float InMaxCameraArmLength, float InMinChromaticAberrationIntensity, float InMaxChromaticAberrationIntensity);
	
	// DirtMask
	uint32 KAPI_PostProcessManager_StartDirtMaskPP(
	    KG_PP_COMMON_PARAMS,
	    bool bOverride_BloomDirtMask, const FString& BloomDirtMaskTexturePath,
	    bool bOverride_BloomDirtMaskIntensity, float BloomDirtMaskIntensity,
	    bool bOverride_BloomDirtMaskTint, float BloomDirtMaskTintR, float BloomDirtMaskTintG, float BloomDirtMaskTintB, float BloomDirtMaskTintA);

	// LensFlares
	uint32 KAPI_PostProcessManager_StartLensFlaresPP(
	    KG_PP_COMMON_PARAMS,
	    bool bOverride_LensFlareIntensity, float LensFlareIntensity,
	    bool bOverride_LensFlareTint, float LensFlareTintR, float LensFlareTintG, float LensFlareTintB, float LensFlareTintA,
	    bool bOverride_LensFlareBokehSize, float LensFlareBokehSize,
	    bool bOverride_LensFlareThreshold, float LensFlareThreshold,
	    bool bOverride_LensFlareBokehShape, const FString& LensFlareBokehShapePath,
	    bool bOverride_LensFlareTints, const TArray<float>& LensFlareTints,
	    bool bOverride_LensFlareScales, const TArray<float>& LensFlareScales);

	// ImageEffects
	uint32 KAPI_PostProcessManager_StartImageEffectsPP(
	    KG_PP_COMMON_PARAMS,
	    bool bOverride_VignetteIntensity, float VignetteIntensity,
	    bool bOverride_Sharpen, float Sharpen);

	// ColorGradingTemperature
	uint32 KAPI_PostProcessManager_StartColorGradingTemperaturePP(
	    KG_PP_COMMON_PARAMS,
	    bool bOverride_TemperatureType, int32 TemperatureType,
	    bool bOverride_WhiteTemp, float WhiteTemp,
	    bool bOverride_WhiteTint, float WhiteTint);

	// ColorGradingGlobal
	uint32 KAPI_PostProcessManager_StartColorGradingGlobalPP(
	    KG_PP_COMMON_PARAMS,
	    bool bOverride_ColorSaturation, float ColorSaturationR, float ColorSaturationG, float ColorSaturationB, float ColorSaturationA,
	    bool bOverride_ColorContrast, float ColorContrastR, float ColorContrastG, float ColorContrastB, float ColorContrastA,
	    bool bOverride_ColorGamma, float ColorGammaR, float ColorGammaG, float ColorGammaB, float ColorGammaA,
	    bool bOverride_ColorGain, float ColorGainR, float ColorGainG, float ColorGainB, float ColorGainA,
	    bool bOverride_ColorOffset, float ColorOffsetR, float ColorOffsetG, float ColorOffsetB, float ColorOffsetA);
	
	// Color Grading Shadows
	uint32 KAPI_PostProcessManager_StartColorGradingShadowsPP(
		KG_PP_COMMON_PARAMS,
		bool bOverride_ColorSaturationShadows, float ColorSaturationShadowsR, float ColorSaturationShadowsG, float ColorSaturationShadowsB, float ColorSaturationShadowsA,
		bool bOverride_ColorContrastShadows, float ColorContrastShadowsR, float ColorContrastShadowsG, float ColorContrastShadowsB, float ColorContrastShadowsA,
		bool bOverride_ColorGammaShadows, float ColorGammaShadowsR, float ColorGammaShadowsG, float ColorGammaShadowsB, float ColorGammaShadowsA,
		bool bOverride_ColorGainShadows, float ColorGainShadowsR, float ColorGainShadowsG, float ColorGainShadowsB, float ColorGainShadowsA,
		bool bOverride_ColorOffsetShadows, float ColorOffsetShadowsR, float ColorOffsetShadowsG, float ColorOffsetShadowsB, float ColorOffsetShadowsA);
	
	// Color Grading Midtones
	uint32 KAPI_PostProcessManager_StartColorGradingMidtonesPP(
	    KG_PP_COMMON_PARAMS,
	    bool bOverride_ColorSaturationMidtones, float ColorSaturationMidtonesR, float ColorSaturationMidtonesG, float ColorSaturationMidtonesB, float ColorSaturationMidtonesA,
	    bool bOverride_ColorContrastMidtones, float ColorContrastMidtonesR, float ColorContrastMidtonesG, float ColorContrastMidtonesB, float ColorContrastMidtonesA,
	    bool bOverride_ColorGammaMidtones, float ColorGammaMidtonesR, float ColorGammaMidtonesG, float ColorGammaMidtonesB, float ColorGammaMidtonesA,
	    bool bOverride_ColorGainMidtones, float ColorGainMidtonesR, float ColorGainMidtonesG, float ColorGainMidtonesB, float ColorGainMidtonesA,
	    bool bOverride_ColorOffsetMidtones, float ColorOffsetMidtonesR, float ColorOffsetMidtonesG, float ColorOffsetMidtonesB, float ColorOffsetMidtonesA);

	// Color Grading Highlights
	uint32 KAPI_PostProcessManager_StartColorGradingHighlightsPP(
	    KG_PP_COMMON_PARAMS,
	    bool bOverride_ColorSaturationHighlights, float ColorSaturationHighlightsR, float ColorSaturationHighlightsG, float ColorSaturationHighlightsB, float ColorSaturationHighlightsA,
	    bool bOverride_ColorContrastHighlights, float ColorContrastHighlightsR, float ColorContrastHighlightsG, float ColorContrastHighlightsB, float ColorContrastHighlightsA,
	    bool bOverride_ColorGammaHighlights, float ColorGammaHighlightsR, float ColorGammaHighlightsG, float ColorGammaHighlightsB, float ColorGammaHighlightsA,
	    bool bOverride_ColorGainHighlights, float ColorGainHighlightsR, float ColorGainHighlightsG, float ColorGainHighlightsB, float ColorGainHighlightsA,
	    bool bOverride_ColorOffsetHighlights, float ColorOffsetHighlightsR, float ColorOffsetHighlightsG, float ColorOffsetHighlightsB, float ColorOffsetHighlightsA,
	    bool bOverride_ColorCorrectionHighlightsMin, float ColorCorrectionHighlightsMin,
	    bool bOverride_ColorCorrectionHighlightsMax, float ColorCorrectionHighlightsMax);

	// Color Grading Misc
	uint32 KAPI_PostProcessManager_StartColorGradingMiscPP(
	    KG_PP_COMMON_PARAMS,
	    bool bOverride_ColorGradingIntensity, float ColorGradingIntensity,
	    bool bOverride_ColorGradingLUT, const FString& ColorGradingLUTPath);

	// Film Grain
	uint32 KAPI_PostProcessManager_StartFilmGrainPP(
	    KG_PP_COMMON_PARAMS,
	    bool bOverride_FilmGrainIntensity, float FilmGrainIntensity,
	    bool bOverride_FilmGrainIntensityShadows, float FilmGrainIntensityShadows,
	    bool bOverride_FilmGrainIntensityMidtones, float FilmGrainIntensityMidtones,
	    bool bOverride_FilmGrainIntensityHighlights, float FilmGrainIntensityHighlights,
	    bool bOverride_FilmGrainShadowsMax, float FilmGrainShadowsMax,
	    bool bOverride_FilmGrainHighlightsMin, float FilmGrainHighlightsMin,
	    bool bOverride_FilmGrainHighlightsMax, float FilmGrainHighlightsMax,
	    bool bOverride_FilmGrainTexelSize, float FilmGrainTexelSize,
	    bool bOverride_FilmGrainTexture, const FString& FilmGrainTexturePath);
	
	uint32 KAPI_PostProcessManager_StartDarkenPP(
		KG_PP_COMMON_PARAMS,
		float BaseExposureBias,
		bool bOverride_AdditionalAutoExposureBias, float AdditionalAutoExposureBias,
		bool bOverride_AutoExposureBias, float AutoExposureBias);

	uint32 KAPI_PostProcessManager_StartDepthOfFieldPP(
		KG_PP_COMMON_PARAMS,
		bool bMobileHQGaussian, float FocalRegion, bool bMobileCustomTransition, float NearTransitionRegion, float FarTransitionRegion, float Scale, float NearBlurSize, float FarBlurSize,
		float DepthOfFieldFstop, float DepthOfFieldMinFstop, int32 DepthOfFieldBladeCount, float SensorWidth, float SqueezeFactor, float FocalDistance,
		float DepthBlurAmount, float DepthBlurRadius, float FocalDistanceOffset,
		bool bUseActorID, KGObjectID FocalActorID, KGEntityID FocalEntityID, const FName& SocketName);

	uint32 KAPI_PostProcessManager_StartPhotoFilterPP(KG_PP_COMMON_PARAMS, const FString& PhotoFilterAssetPath);
	uint32 KAPI_PostProcessManager_StartPhotoContrastPP(KG_PP_COMMON_PARAMS, const FString& ColorContrastCurvePath);
	uint32 KAPI_PostProcessManager_StartPhotoSaturationPP(KG_PP_COMMON_PARAMS, const FString& ColorSaturationCurvePath);
	uint32 KAPI_PostProcessManager_StartPhotoWhiteTintPP(KG_PP_COMMON_PARAMS, const FString& WhiteTintCurvePath);
	uint32 KAPI_PostProcessManager_StartPhotoWhiteTempPP(KG_PP_COMMON_PARAMS, const FString& WhiteTempCurvePath);
	uint32 KAPI_PostProcessManager_StartPhotoExposurePP(KG_PP_COMMON_PARAMS, const FString& ExposureCurvePath, float InBaseExposureBias);
	
	uint32 KAPI_PostProcessManager_StartAutoExposureSpeedUpPP(KG_PP_COMMON_PARAMS, float AutoExposureSpeedUp);
	
	uint32 KAPI_PostProcessManager_StartPhantomPP(
		KG_PP_COMMON_PARAMS,
		const FName& GapParamName, float Gap,
		const FName& SpeedParamName, float Speed,
		const FName& DirParamName, float DirR, float DirG, float DirB, float DirA,
		const FString& NiagaraPath, const FName& AttachSocketName, KGEntityID EntityID, EKGPostProcessQuality PostProcessQuality,
		int32 InCustomDepthLogicType, int32 CustomDepthPriority, int32 InCustomDepthStencilValue, uint32 InCustomPPID);

	uint32 KAPI_PostProcessManager_StartFogPP(
		KG_PP_COMMON_PARAMS,
		float HeadInfoHideDistInMeters, bool bOverrideClimate, int32 OverrideClimateID, float BlendTimeSeconds,
		const FName& LocationBindParamName, KGEntityID LocationBindEntityID, KGActorID LocationBindActorID,
		const FName& FogOpacityParamName, float FogOpacityStartVal, float FogOpacityEndVal,
		const FName& MaxDistParamName, float MaxDistInMetersStartVal, float MaxDistInMetersEndVal,
		bool bOverrideFogColor, const FName& FogColorParamName, float FogColorR, float FogColorG, float FogColorB, float FogColorA,
		const FName& SmoothDistParamName, float SmoothDistInMetersStartVal, float SmoothDistInMetersEndVal);

	uint32 KAPI_PostProcessManager_StartSketchPP(KG_PP_COMMON_PARAMS);
	
	uint32 KAPI_PostProcessManager_StartClipPP(
		KG_PP_COMMON_PARAMS,
		const FName& ClipColorParamName, float ColorR, float ColorG, float ColorB, float ColorA,
		const FName& BackgroundColorParamName, float BGColorR, float BGColorG, float BGColorB, float BGColorA);

	uint32 KAPI_PostProcessManager_StartBlackFog(
		KG_PP_COMMON_PARAMS,
		float BlendTimeSeconds, KGEntityID PlayerEntityID, KGEntityID BossEntityID,
		bool bOverrideCenterPos, float CenterPosX, float CenterPosY, float CenterPosZ,
		bool bOverrideFogOpacity, float FogOpacity,
		bool bOverrideFogColor, float FogColorR, float FogColorG, float FogColorB, float FogColorA,
		bool bOverrideSmoothDist, float SmoothDistInMeters,
		EKGFogShapeType ShapeType, float CircleRadius, float RingPercent, float RingOuterRadius,
		float CrossLength, float CrossWidth, float HalfFieldWidth, bool bOverrideRangeSpawnRotation, float RangeSpawnRotation);

	uint32 KAPI_PostProcessManager_StartMultiTargetFog(
		KG_PP_COMMON_PARAMS,
		float HeadInfoHideDistInMeters, float BlendTimeSeconds, int32 MaxTargetNum,
		const FName& LocationBindParamName, KGEntityID LocationBindEntityID,
		const FName& FogOpacityParamName, float FogOpacityStartVal, float FogOpacityEndVal,
		const FName& MaxDistParamName, float MaxDistInMetersStartVal, float MaxDistInMetersEndVal,
		bool bOverrideFogColor, const FName& FogColorParamName, float FogColorR, float FogColorG, float FogColorB, float FogColorA,
		const FName& SmoothDistParamName, float SmoothDistInMetersStartVal, float SmoothDistInMetersEndVal);
	
	// cpp版本调用接口
	uint32 StartCommonPostProcess(
		KG_PP_COMMON_PARAMS, EKGPostProcessType EffectType, const FPostProcessSettings& PostProcessSettings);
	
	void KAPI_PostProcessManager_InterruptPostProcess(uint32 PPID, bool bOverrideBlendOutTime, float NewBlendOutTime)
	{ 
		InterruptPostProcess(PPID, bOverrideBlendOutTime, NewBlendOutTime);
	}
	void InterruptPostProcess(uint32 PPID, bool bOverrideBlendOutTime, float NewBlendOutTime);
	void KAPI_PostProcessManager_InterruptPostProcessByPPTag(uint32 PPTag, bool bOverrideBlendOutTime, float NewBlendOutTime)
	{
		InterruptPostProcessByPPTag(PPTag, bOverrideBlendOutTime, NewBlendOutTime);
	}
	void InterruptPostProcessByPPTag(uint32 PPTag, bool bOverrideBlendOutTime, float NewBlendOutTime);
	void KAPI_PostProcessManager_InterruptPostProcessByType(EKGPostProcessType PPType, bool bOverrideBlendOutTime, float NewBlendOutTime)
	{
		InterruptPostProcessByType(PPType, bOverrideBlendOutTime, NewBlendOutTime);
	}
	void InterruptPostProcessByType(EKGPostProcessType PPType, bool bOverrideBlendOutTime, float NewBlendOutTime);
	void KAPI_PostProcessManager_InterruptPostProcessByPPTypeAndSourceType(EKGPostProcessType PPType, uint32 SourceType, bool bOverrideBlendOutTime, float NewBlendOutTime)
	{
		InterruptPostProcessByPPTypeAndSourceType(PPType, SourceType, bOverrideBlendOutTime, NewBlendOutTime);
	}
	void InterruptPostProcessByPPTypeAndSourceType(EKGPostProcessType PPType, uint32 SourceType, bool bOverrideBlendOutTime, float NewBlendOutTime);
	void KAPI_PostProcessManager_RemovePPInstancesOnLeaveSpace() { RemovePPInstancesOnLeaveSpace(); }
	void RemovePPInstancesOnLeaveSpace();
	// --------------------------------------------------------------------------------------------
	
	void StartPostProcess(TSharedPtr<KGPPBase> PPInstance);
	void StopPostProcess(uint32 PPID, EKGPostProcessStopReason StopReason, bool bOverrideBlendOutTime=false, float NewBlendOutTime=0.0f);
	KGPPBase* GetPPInstance(uint32 PPID) { return PostProcessInstances.Contains(PPID) ? PostProcessInstances[PPID].Get(): nullptr; }
	TSharedPtr<KGPPBase> GetPPInstanceSharedPtr(uint32 PPID) { return PostProcessInstances.Contains(PPID) ? PostProcessInstances[PPID] : nullptr; }
	int32 GetPPNumByPPType(EKGPostProcessType PPType) { return PPTypeToPriorityQueues.Contains(PPType) ? PPTypeToPriorityQueues[PPType].GetNum() : 0; }

	void KAPI_PostProcessManager_AddPPConfig(
		EKGPostProcessType PPType, const FString& TypeName, const TArray<EKGPostProcessType>& ConflictTypes,
		int32 ViewPriority, const FString& MaterialPath, const FString& PlaneMeshMaterialPath, const FName& IntensityParamName);
	void KAPI_PostProcessManager_ClearPPConfigs() { PPConfigs.Empty(); }
	int32 GetPPViewPriority(EKGPostProcessType PPType) const { return PPConfigs.Contains(PPType) ? PPConfigs[PPType].ViewPriority : 0; }
	FString GetPPTypeName(EKGPostProcessType PPType) const { return PPConfigs.Contains(PPType) ? PPConfigs[PPType].TypeName : TEXT("[invalid]"); }

	void SetPPBlendOutTimeOnInterrupt(float InPPBlendOutTimeOnInterrupt) { PPBlendOutTimeOnInterrupt = InPPBlendOutTimeOnInterrupt; }
	float GetPPBlendOutTimeOnInterrupt() const { return PPBlendOutTimeOnInterrupt; }

	UStaticMesh* GetPlaneMeshAsset() const { return PlaneMeshAsset; }
	bool IsPlaneMeshPostProcessEnabled() const { return bEnablePlaneMeshPostProcess; }
	bool UseViewportPlaneMeshHandler() const { return bUseViewportPlaneMeshHandler; }
	float GetPlaneMeshDistance(KGPPMaterialBase* NewPPInstance);
	const FRotator& GetPlaneMeshRotation() const { return PlaneMeshRotation; }
	const FVector& GetPlaneMeshScale() const { return PlaneMeshScale; }
	void KAPI_PostProcessManager_SetPlaneMeshInfo(
		const FString& AssetPath, float MinDist, float MaxDist, float Pitch, float Yaw, float Roll, float ScaleX, float ScaleY, float ScaleZ);
	void KAPI_PostProcessManager_SetEnablePlaneMeshPostProcess(bool bEnable) { bEnablePlaneMeshPostProcess = bEnable; }
	void KAPI_PostProcessManager_SetUseViewportPlaneMeshHandler(bool bInUseViewportPlaneMeshHandler) { bUseViewportPlaneMeshHandler = bInUseViewportPlaneMeshHandler; }
	
	void GetCachedPostProcessBlends(TArray<FPostProcessSettings> const*& OutPPSettings, TArray<float> const*& OutBlendWeights) const;
	void GetCachedPostProcessBlends(TArray<FPostProcessSettings>& OutPPSettings, TArray<float>& OutBlendWeights, TArray<EViewTargetBlendOrder>& OutBlendOrders) const;
	void AccumulateCachedPostProcessBlends(TArray<FPostProcessSettings>& OutPPSettings, TArray<float>& OutBlendWeights, TArray<EViewTargetBlendOrder>& OutBlendOrders) const;

	void UpdatePostProcessQuality(EKGPostProcessQuality PostProcessQuality);
	EKGPostProcessQuality GetPostProcessQuality() const { return CurrentPostProcessQuality; }
	FKGPPOnPostProcessQualityChanged& GetOnPostProcessQualityChanged() { return OnPostProcessQualityChanged; }
	
	/**
	 * 由于当前一些后处理效果不仅仅是设置后处理, 还会存在例如设置角色材质, 修改角色custom stencil, 设置全局天气/雾效/camera dither等等效果
	 * 因此disable不能仅仅是不对Camera输出后处理结果, 比如将所有当前正在生效的后处理实例deactivate掉才行
	 */
	void DisablePostProcess(bool bDisable);
	void KAPI_PostProcessManager_DisablePostProcess(bool bDisable) { DisablePostProcess(bDisable); }
	void DisablePostProcessBySourceType(uint32 SourceType, bool bDisable);
	void KAPI_PostProcessManager_DisablePostProcessBySourceType(uint32 SourceType, bool bDisable) { DisablePostProcessBySourceType(SourceType, bDisable); }

	void KAPI_PostProcessManager_SetPhotoPPBlendWeight(uint32 PPID, float BlendWeight);
	void KAPI_PostProcessManager_SetManualBlendWeight(uint32 PPID, float BlendWeight);
	void KAPI_PostProcessManager_ClearManualBlendWeight(uint32 PPID);
	void KAPI_PostProcessManager_SetEntityCustomDepth(
		uint32 PPID, KGEntityID EntityID, int32 LogicType, int32 Priority, bool bEnableClip, int32 CustomDepthStencilValue, bool bNiagaraRenderCustomDepth);
	void KAPI_PostProcessManager_RevertEntityCustomDepth(uint32 PPID, KGEntityID EntityID);
	uint32 KPAI_PostProcessManager_GeneratePPID() { return KGPPUtils::GeneratePPID(); }
	void KAPI_PostProcessManager_AdvancePPTime(uint32 PPID, float DeltaTime);
	
	uint32 GetPPInstanceIDByPPType(EKGPostProcessType PPType);
	void UpdateActorLocationMaterialParam(uint32 PPID, const FName& ParamName, KGActorID ActorID);
	void UpdateEntityLocationMaterialParam(uint32 PPID, const FName& ParamName, KGEntityID EntityID);
	void RemoveActorLocationMaterialParam(uint32 PPID, const FName& ParamName);
	void RemoveEntityLocationMaterialParam(uint32 PPID, const FName& ParamName);

	// fog相关设置
	void KAPI_PostProcessManager_UpdateFogParams(
		uint32 PPID, float HeadInfoHideDistInMeters, bool bInOverrideClimate, int32 OverrideClimateID, float InBlendTimeSeconds,
		const FName& FogOpacityParamName, float FogOpacityTargetVal,
		const FName& MaxDistParamName, float MaxDistInMetersTargetVal,
		const FName& FogColorParamName, float FogColorR, float FogColorG, float FogColorB, float FogColorA,
		const FName& SmoothDistParamName, float SmoothDistInMetersTargetVal);
	void KAPI_PostProcessManager_UpdateFogOpacity(uint32 PPID, const FName& FogOpacityParamName, float TargetFogOpacity, float NewDuration);
	void KAPI_PostProcessManager_UpdateFogTargetActorBySourceType(uint32 SourceType, const FName& PlayerPosParamName, KGActorID ActorID);
	int32 GetFogPPIDBySourceType(int32 SourceType);
	int32 KAPI_PostProcessManager_GetFogPPIDBySourceType(int32 SourceType) { return GetFogPPIDBySourceType(SourceType); }
	void KCB_ChangeClimate(int32 OverrideClimateID);
	void KCB_ResetCurrentClimate();

	void KAPI_PostProcessManager_AddOrUpdateFogTarget(
		uint32 PPID, KGEntityID EntityID, const FName& AvoidDistanceParamNamePrefix, float AvoidDistanceInMeters,
		const FName& AvoidSmoothDistParamNamePrefix, float AvoidSmoothDist, const FName& FogOpacityParamPrefix,
		const FName& EntityPosParamNamePrefix, float InBlendTimeSeconds);
	void KAPI_PostProcessManager_RemoveFogTarget(uint32 PPID, KGEntityID EntityID, const FName& FogOpacityParamPrefix, float InBlendTimeSeconds);
	
	void KAPI_PostProcessManager_UpdateBlackFogParams(
		uint32 PPID, float BlendTimeSeconds,
		bool bOverrideCenterPos, float CenterPosX, float CenterPosY, float CenterPosZ,
		bool bOverrideFogOpacity, float FogOpacity,
		bool bOverrideFogColor, float FogColorR, float FogColorG, float FogColorB, float FogColorA,
		bool bOverrideSmoothDist, float SmoothDistInMeters,
		EKGFogShapeType ShapeType, float CircleRadius, float RingPercent, float RingOuterRadius,
		float CrossLength, float CrossWidth, float HalfFieldWidth, bool bOverrideRangeSpawnRotation, float RangeSpawnRotation);
	
	void KAPI_PostProcessManager_SetFogParamName(
		const FName& InFogCenterPosParamName, const FName& InFogOpacityParamName, const FName& InFogColorParamName, const FName& InSmoothDistParamName, 
		const FName& InMaxDistParamName, const FName& InPlayerPosParamName, const FName& InBossPosParamName,
		const FName& InShapeTypeName, const FName& ShapeTypeBName, const FName& InCircleRadiusName, const FName& InRingPercentName, const FName& InRingOuterRadiusName,
		const FName& InCrossLengthName, const FName& InCrossWidthName, const FName& InHalfFieldWidthName, const FName& InRangeSpawnRotationName,
		const FName& ShapeLerpName);
	
	// sketch相关设置
	void KAPI_PostProcessManager_AddSketchChangeMaterialInfo(
		const FString& MaterialPath, const TArray<FName>& ExcludeMeshComponentTags, const TArray<FName>& SlotNames);
	void KAPI_PostProcessManager_AddSketchChangeMaterialParamInfo(
		EKGPPSketchEffectType EffectType, const TArray<FName>& SlotNames, const TArray<FName>& InheritTextureMaterialParamName, const TMap<FName, FLinearColor>& VectorParams);
	const TArray<FKGChangeMaterialRequest>& GetSketchMaterialRequests() const { return SketchMaterialRequests; }
	const TArray<FKGChangeMaterialParamRequest>* GetSketchMaterialParamRequestsPtr(EKGPPSketchEffectType EffectType) const { return SketchMaterialParamRequests.Find(EffectType); }
	void KAPI_PostProcessManager_AddSketchTarget(uint32 PPID, KGEntityID EntityID, bool bChangeCustomDepth, int32 LogicType, int32 Priority, int32 CustomStencilValue, EKGPPSketchEffectType EffectType);
	void KAPI_PostProcessManager_RemoveSketchTarget(uint32 PPID, KGEntityID EntityID);
	
protected:

	void UpdatePostProcessBlendCache();
	void AddPostProcessResult(KGPPBase* PPInstance);
	
	bool InternalBlendOutPostProcess(TSharedPtr<KGPPBase> PPInstance, bool bOverrideBlendOutTime, float NewBlendOutTime, EKGPostProcessBlendReason InBlendReason);
	// 对于所有打断淡出的后处理来说, 会将其从优先队列中移除, 以实现同类型多个后处理同时生效的效果
	// 这些后处理需要在同类型新的后处理开始时, 被全部移除
	void RemoveInterruptedBlendingOutPostProcess(TSharedPtr<KGPPBase> PPInstance);
	void RemovePostProcessPriorityInfo(TSharedPtr<KGPPBase> PPInstance);
	void AddPostProcessPriorityInfo(TSharedPtr<KGPPBase> PPInstance);
	void InternalUpdatePostProcessDisableState(TSharedPtr<KGPPBase> PPInstance, bool bDisable, EKGPostProcessDisableReason Reason);
	void InternalStopPostProcess(uint32 PPID, EKGPostProcessStopReason StopReason);
	
	KGPPMaterialBase* GetMaterialPPInstance(uint32 PPID);
	KGPostProcessPriorityQueue& GetOrCreatePostProcessPriorityQueue(EKGPostProcessType PPType) { return PPTypeToPriorityQueues.FindOrAdd(PPType); }
	KGPPBase* GetActivePPInstanceByType(EKGPostProcessType PPType);
	// 获取对应类型的后处理实例, 存在多个则返回第一个, 如果没有则返回nullptr
	KGPPBase* GetPPInstanceByType(EKGPostProcessType PPType);
	void GetPlaneMeshPPMaterialInstances(TArray<KGPPMaterialBase*>& OutMaterialInstances);
	
	static void ProcessLinearSampleParams(
		const FName& ParamName, float StartVal, float EndVal, float Duration, FKGPPMaterialParams& OutParams);
	
	UPROPERTY(transient)
	TArray<FPostProcessSettings> PostProcessBlendCache;
	TArray<float> PostProcessBlendCacheWeights;
	TArray<EViewTargetBlendOrder> PostProcessBlendCacheOrders;

	UPROPERTY(Transient)
	UStaticMesh* PlaneMeshAsset;
	float PlaneMeshMinDist = 40.0f;
	float PlaneMeshMaxDist = 60.0f;
	FRotator PlaneMeshRotation = FRotator(0.0f, 0.0f, 0.0f);
	FVector PlaneMeshScale = FVector(1.0f, 1.0f, 1.0f);
	bool bEnablePlaneMeshPostProcess = true;
	bool bUseViewportPlaneMeshHandler = false;
	
	// 所有后处理实例
	TMap<uint32, TSharedPtr<KGPPBase>> PostProcessInstances;
	// 实际只有非dummy的后效才会tick或者输出, 这里额外存一份non dummy pp instance, 避免tick做无效操作
	TSet<uint32> NonDummyPostProcessInstanceIDs;
	// 后效优先级队列
	TMap<EKGPostProcessType, KGPostProcessPriorityQueue> PPTypeToPriorityQueues;
	
	TMap<EKGPostProcessType, FKGPPConfig> PPConfigs;
	
	float PPBlendOutTimeOnInterrupt = 0.1f;
	EKGPostProcessQuality CurrentPostProcessQuality = EKGPostProcessQuality::High;
	FKGPPOnPostProcessQualityChanged OnPostProcessQualityChanged;

	// sketch材质设置相关参数
	TArray<FKGChangeMaterialRequest> SketchMaterialRequests;
	TMap<EKGPPSketchEffectType, TArray<FKGChangeMaterialParamRequest>> SketchMaterialParamRequests;

	// fog params
	FKGFogParams FogParams;
	
	bool bPostProcessDisabled = false;
	TSet<uint32> DisabledPostProcessSourceTypes;
	
#pragma endregion PostProcess
};
