﻿#pragma once
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPNonMaterialBase.h"

class KGPPPhotoWhiteTint : public KGPPNonMaterialBase
{
public:
	void InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType, const FString& WhiteTintCurvePath);
	virtual void SetManualWeightCurveValue(float Weight) override;

protected:
	int32 WhiteTintID = 0;
};

