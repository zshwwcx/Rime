﻿#pragma once
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPMaterialBase.h"

class KGPPMaterialPhantom : public KGPPMaterialBase
{
public:
	KGPPMaterialPhantom() = default;
	KGPPMaterialPhantom(uint32 InCustomPPID);
	
	void InitParams(const FKGPPCommonParams& CommonParams, const FString& InNiagaraPath, EKGPostProcessQuality InPPQualityThreshold, const FName& InAttachSocketName,
		const TWeakObjectPtr<AActor>& InAttachActor, const TWeakObjectPtr<USceneComponent> InAttachComponent,
		KGEntityID InCustomDepthEntityID, int32 InCustomDepthLogicType, int32 InCustomDepthPriority, int32 InCustomDepthStencilValue,
		EKGPostProcessType InPPType, const FString& InMaterialPath, const FString& InPlaneMeshMaterialPath,
		int32 InViewPriority, const FName& InIntensityParamName, const FKGPPMaterialParams& InParams, TWeakObjectPtr<UPostProcessManager> InPPManager);

	virtual bool OnTaskStart() override;
	virtual void OnTaskEnd(EKGPostProcessStopReason StopReason) override;
	virtual void OnTaskActivated() override;
	virtual void OnTaskDeactivated() override;

	virtual bool CanActivateMultiPPInstance() const override { return false; }
	
	virtual void OnPostProcessQualityChanged(EKGPostProcessQuality NewQuality) override;
	virtual bool CanOutputPostProcess() const override;
	virtual FString GetDebugInfo() const override;
	
	bool UsePostProcess(EKGPostProcessQuality CurrentQuality) const { return CurrentQuality >= PPQualityThreshold; }
	void RefreshEffect(EKGPostProcessQuality CurrentQuality);
	
protected:

	bool bEnablePostProcess = false;
	bool bEnableNiagara = false;
	FString NiagaraPath;
	FName AttachSocketName;
	TWeakObjectPtr<AActor> AttachActor;
	TWeakObjectPtr<USceneComponent> AttachComponent;
	int32 NiagaraEffectID = 0;

	KGEntityID CustomDepthEntityID = 0;
	int32 CustomDepthStencilValue = 0;
	int32 CustomDepthLogicType = 0;
	int32 CustomDepthPriority = 0;
	// 大于等于此等级使用后效, 否则退化为特效
	EKGPostProcessQuality PPQualityThreshold = EKGPostProcessQuality::High;
};
