#pragma once

#include "CoreMinimal.h"
#include "3C/Camera/CameraAction/CameraActionBase.h"
#include "CameraSplineMoveModifier.generated.h"


UCLASS( BlueprintType, Blueprintable)
class KGCHARACTER_API UCameraSplineMoveModifier : public UCameraActionBase
{
	GENERATED_BODY()

public:
	virtual void ModifyViewPOV(float DeltaTime, struct FMinimalViewInfo& InOutPOV) override;
};





