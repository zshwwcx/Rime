#pragma once
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPBase.h"

class UCurveFloat;

enum class EKGManualWeightCurveType : uint8
{
	FloatCurve = 1,
	ColorCurve = 2,
};

struct FKGManualWeightCurveInfo
{
	FString CurvePath;
	TStrongObjectPtr<UCurveBase> CurveInfo;
	int32 AssetLoadID = 0;
	EKGManualWeightCurveType CurveType = EKGManualWeightCurveType::FloatCurve;
};

#define KG_PP_SET_FLOAT_CURVE_PARAM(ParamName) \
	do { \
		float OutValue = 0.0f; \
		if (GetFloatCurveValue(ParamName##ID, OutValue)) \
		{ \
			PostProcessSettings.bOverride_##ParamName = true; \
			PostProcessSettings.ParamName = OutValue; \
		} \
	} while(0)

#define KG_PP_SET_LINEAR_COLOR_CURVE_PARAM(ParamName) \
	do { \
		FLinearColor OutValue = FLinearColor::Black; \
		if (GetLinearColorCurveValue(ParamName##ID, OutValue)) \
		{ \
			PostProcessSettings.bOverride_##ParamName = true; \
			PostProcessSettings.ParamName = OutValue; \
		} \
	} while(0)

/*
 * 所有使用后处理材质实现的后处理效果基类
 * 1, 跟TA/美术侧约定, 所有非材质后处理在打断时给0.1s的淡出过渡
 * 2, 所有非材质后处理必须在cpp中派生 KGPPNonMaterialBase 并给出具体的实现
 * 3, 绝大部分非材质类型后处理都可以直接使用 KGPPNonMaterialBase 作为自身implemented class, 如果后处理有特殊的逻辑, 可以通过派生 KGPPMaterialBase 来实现自身特定的逻辑
 */
class KGPPNonMaterialBase : public KGPPBase
{
public:
	
	void InitParams(
		const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType,
		const FPostProcessSettings& InPostProcessSettings);
	void InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType);

	virtual void OnTaskEnd(EKGPostProcessStopReason StopReason) override;
	
	virtual bool IsNonMaterialPP() const override { return true; }
	virtual EKGPostProcessType GetPPType() const override { return PPType; }
	virtual bool GetPostProcessResult(FPostProcessSettings& OutPPSettings, float& OutPPBlendWeight, EViewTargetBlendOrder& OutPPBlendOrder) const override final;
	virtual FString GetDebugInfo() const override;

	float GetCurrentBlendWeight() const;
	void SetManualBlendWeight(float InManualBlendWeight) { ManualBlendWeight = FMath::Clamp(InManualBlendWeight, 0.0f, 1.0f); }
	void ClearManualBlendWeight() { ManualBlendWeight.Reset(); }

	uint32 RegisterManualWeightCurve(const FString& CurvePath, EKGManualWeightCurveType CurveType);
	virtual void SetManualWeightCurveValue(float Weight) { CurManualWeight = Weight; }
	bool HasManualWeightCurve() const { return ManualWeightCurveInfos.Num() > 0; }
	bool GetFloatCurveValue(int32 CurveParamID, float& OutValue);
	bool GetLinearColorCurveValue(int32 CurveParamID, FLinearColor& OutValue);
	
protected:

	void OnManualWeightCurveLoaded(int InLoadID, UObject* Asset);
	
	// 这里无需UPROPERTY标记, 因为本身非材质类型这里不会有任何UObject
	FPostProcessSettings PostProcessSettings;
	// 支持外部手动设置blend weight, 目前在拍照中使用
	TOptional<float> ManualBlendWeight;
	// 默认材质后处理的类型由外部传入, 自定义材质后处理可以override GetPPType, 返回自身对应的PPType
	EKGPostProcessType PPType = EKGPostProcessType::KG_PP_None;
	
	float CurManualWeight = 0.5f;
	TMap<uint32, FKGManualWeightCurveInfo> ManualWeightCurveInfos;
};
