// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "3C/Camera/CameraAction/CameraActionBase.h"
#include "CameraScreenViewOffsetAction.generated.h"

/**
 * 
 */
UCLASS()
class KGCHARACTER_API UCameraScreenViewOffsetAction : public UCameraActionBase
{
	GENERATED_BODY()

public:
	void Init(float InOffsetX, float InOffsetY, float InBlendInTime, float InBlendOutTime, float InDuration, ECameraEaseFunction::Type InBlendInType, ECameraEaseFunction::Type InBlendOutType, int64 InBlendInCurve, int64 InBlendOutCurve);

	virtual void Play() override;

	virtual void ModifyCamera(float DeltaTime) override;
	
	virtual void Abort() override;
	
	virtual void DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode) override;
	
	virtual bool IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType) override { return false; };

private:
	void InitParams();

private:
	FVector2D Offset = FVector2D::ZeroVector;
	FVector2D BaseOffset = FVector2D::ZeroVector;
};
