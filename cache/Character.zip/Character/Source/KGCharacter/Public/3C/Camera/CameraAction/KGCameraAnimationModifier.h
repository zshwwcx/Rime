// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "Camera/CameraTypes.h"
#include "Animations/CameraAnimationCameraModifier.h"
#include "3C/Camera/CameraUtil/CameraEase.h"
#include "KGCameraAnimationModifier.generated.h"

class UCameraAnimationSequence;
class UCameraAnimationSequenceCameraStandIn;
class UCameraAnimationSequencePlayer;
struct FMinimalViewInfo;


UCLASS(config=Camera)
class KGCHARACTER_API UKGCameraAnimationCameraModifier : public UCameraAnimationCameraModifier
{
	GENERATED_BODY()

public:
	virtual bool ModifyCamera(float DeltaTime, FMinimalViewInfo& InOutPOV) override;

	virtual bool ProcessViewRotation(AActor* ViewTarget, float DeltaTime, FRotator& OutViewRotation, FRotator& OutDeltaRot) override;
	virtual bool ProcessViewRotation(AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch, double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot);

	virtual void KGTickAnimation(FActiveCameraAnimationInfo& CameraAnimation, float DeltaTime, FMinimalViewInfo& InOutPOV);

	void ApplyPOV(UCameraAnimationSequenceCameraStandIn* CameraStandIn, FMinimalViewInfo& InOutPOV) const;

	void StopKGCameraAnimation(uint32 HandleHash, bool bImmediate = false);

	UFUNCTION(BlueprintCallable)
	void Pause(int CameraAnimHandleHash, bool bInPause);

	UFUNCTION(BlueprintCallable)
	void SetPlayRate(int CameraAnimHandleHash, float NewPlayRate);

	UFUNCTION(BlueprintCallable)
	void SetLoop(int CameraAnimHandleHash, bool bInLoop);

	UFUNCTION(BlueprintCallable)
	void SetAnimationPlayAt(int CameraAnimHandleHash, float Pct);
	
	UFUNCTION(BlueprintCallable)
	int64 PlayCameraAnimationAtLocation(int64 GUID, int64 SequenceID, float Duration, float EaseInDuration, ECameraEaseFunction::Type EaseInType, float EaseOutDuration, ECameraEaseFunction::Type EaseOutType, FCameraAnimationParams Params, int CollisionCheckCnt, const FVector& PlayLoc, int64 UserSpacePlayer, bool bInUseTargetScale = false, bool bInUseMeshSpace = false, bool bInLockOutgoing = false, bool bInAdaptiveCameraRot = false, bool bInCustomPitch = false, double InCustomPitch = 0.0);

	void OnModeActivate(int ModeTag);

	void SetEffectModeTags(const TArray<int>& InModeTags, int CurrentActivateModeTag);

	void SetActionHandlerOwner(class UCameraActionHandler* ActionOwner);

	static bool CollisionCheck(UWorld* World, UCameraAnimationSequence* Sequence, const FTransform& PivotTM, int Count);

private:
	TWeakObjectPtr<class UCameraActionHandler> ActionHandlerOwner = nullptr;

	FCameraAnimationHandle LocationPlayCameraAnimation;

	TArray<int> EffectCameraTags;

	bool bPause = false;

	TMap<uint32, int64> AnimationHandleToGUID;

	bool bCanActivate = false;

	float DesiredPlayTimePct = -1.f;

	FMinimalViewInfo POVCache;
	FMinimalViewInfo POVCacheLockOutgoing;

	float AlphaCache = 0.f;
	float PlayDuration = 0.f;
	float TotalPlayTime = 0.f;
	float BlendInTime = 0.f;
	float BlendOutTime = 0.f;
	ECameraEaseFunction::Type BlendInType = ECameraEaseFunction::Linear;
	ECameraEaseFunction::Type BlendOutType = ECameraEaseFunction::Linear;
	float SampleTime = 0.f;
	bool bStartBlendOut = false;
	bool bAdaptiveCameraRot = false;
	bool bCustomPitch = false;
	bool bLockOutgoing = false;

	FRotator AdaptiveRot = FRotator::ZeroRotator;
	
	TWeakObjectPtr<AActor> UserSpacePlayerActor = nullptr;
	TWeakObjectPtr<USkeletalMeshComponent> UserSpacePlayerActorMesh = nullptr;

	FVector AnimPlayLoc = FVector::ZeroVector;
	bool bUseTargetScale = false;
	bool bUseMeshSpace = false;

	static const FName RootName;

	TWeakObjectPtr<class ACameraManager> CameraMgr = nullptr;
};

