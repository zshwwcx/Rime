#pragma once
#include "Effect/KGEffectCommon.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPBase.h"
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPPlaneMeshHandler.h"
#include "Materials/MaterialInstanceDynamic.h"

class UKGUEActorManager;
class UKGMaterialManager;
class UMaterialInterface;
class UStaticMeshComponent;

/*
 * 所有使用后处理材质实现的后处理效果基类
 * 1, 跟TA/美术侧约定, 对于所有使用材质的后处理效果, 默认淡出都是用统一的材质参数实现, PostProcessBlendWeight一直给1.0
 * 2, 材质后处理在打断时不做淡出处理
 * 3, 绝大部分材质类型后处理都可以直接使用 KGPPMaterialBase 作为自身implemented class, 这里提供了按照固定值、线性插值以及曲线的方式来更新材质参数, 支持的
 * 材质参数类型包括 float LinearColor Texture, 如果后处理有特殊的逻辑, 可以通过派生 KGPPMaterialBase 来实现自身特定的逻辑
 */
class KGPPMaterialBase : public KGPPBase
{
public:
	KGPPMaterialBase() = default;

	void InitParams(const FKGPPCommonParams& CommonParams, EKGPostProcessType InPPType, const FString& InMaterialPath, const FString& InPlaneMeshMaterialPath,
		int32 InViewPriority, const FName& InIntensityParamName, const FKGPPMaterialParams& InParams, TWeakObjectPtr<UPostProcessManager> InPPManager);

	virtual bool OnTaskStart() override;
	virtual void OnTaskTick(float DeltaTime) override;
	virtual void OnTaskEnd(EKGPostProcessStopReason StopReason) override;

	virtual bool IsMaterialPP() const override { return true; }
	virtual EKGPostProcessType GetPPType() const override { return PPType; }
	virtual FString GetDebugInfo() const override;
	FString GetMaterialParamDebugInfo();
	virtual bool CanOutputPostProcess() const override;
	virtual bool GetPostProcessResult(FPostProcessSettings& OutPPSettings, float& OutPPBlendWeight, EViewTargetBlendOrder& OutPPBlendOrder) const override final;
	
	virtual bool CanUseCommonBlend() const override { return !IntensityParamName.IsNone(); }
	virtual void OnBlendWeightChanged() override;
	
	const FString& GetMaterialPath() const { return PlaneMeshHandler.IsValid() ? PlaneMeshMaterialPath : MaterialPath; }
	bool UsePlaneMesh() const { return PlaneMeshHandler.IsValid(); }
	bool IsPlaneMeshVisible() const;
	float GetPlaneMeshDistance() const { return PlaneMeshDistance; }
	int32 GetViewPriority() const { return ViewPriority; }
	
	virtual void AdvancePPTime(float DeltaTime) override;
	
	TMap<FName, FString>& GetTextureParams() { return PPMaterialParams.TextureParams; }
	TMap<FName, FKGLinearSampleParams<float>>& GetScalarLinearSampleParams() { return PPMaterialParams.ScalarLinearSampleParams; }
	TMap<FName, FKGLinearSampleParams<FLinearColor>>& GetVectorLinearSampleParams() { return PPMaterialParams.VectorLinearSampleParams; }
	TMap<FName, FKGCurveParams>& GetCurveParams() { return PPMaterialParams.CurveParams; }
	TMap<FName, FKGLinearBlendInAndBlendOutParams<float>>& GetScalarLinearBlendParams() { return PPMaterialParams.ScalarLinearBlendParams; }

	// 接口按需补充
	void UpdateScalarParam(const FName& ParamName, float ParamValue);
	void UpdateVectorParam(const FName& ParamName, const FLinearColor& ParamValue);
	void UpdateActorLocationParam(const FName& ParamName, TWeakObjectPtr<AActor> ParamValue);
	void RemoveActorLocationParam(const FName& ParamName);
	void UpdateEntityLocationParams(const FName& ParamName, KGEntityID EntityID);
	void RemoveEntityLocationParam(const FName& ParamName);
	// 总是先删除当前ParamName的线性采样任务, 接着将材质参数从StartVal到EndVal进行线性更新
	void AddScalarLinearSampleParamTargetValue(const FName& ParamName, float StartValue, float EndVal, float Duration);
	// 对于ParamName的材质参数, 从当前值更新到目标值TargetVal, 如果当前没有active的线性插值任务, 则会报错
	void UpdateScalarLinearSampleParamTargetValue(const FName& ParamName, float TargetValue, bool bUseNewDuration, float NewDuration);
	// 对于ParamName的材质参数, 如果当前没有active的线性插值任务, 则新增一个从StartVal到TargetVal的线性插值任务, 否则更新当前任务的目标值为TargetVal
	void AddOrUpdateScalarLinearSampleParamTargetValue(const FName& ParamName, float StartValue, float TargetValue, bool bUseNewDuration, float NewDuration);
	
protected:

	void TryLoadAssets();
	void OnAssetsLoaded(int InLoadID, const TArray<UObject*>& Assets);
	void ApplyPPMaterialParams();
	void InitConstMaterialParams();
	uint32 DoAddEntityLocationUpdateTask(const FName& ParamName, KGEntityID EntityID, UKGUEActorManager* ActorManager);
	
	FKGPPMaterialParams PPMaterialParams;

	// 是否启用面片来替换后处理材质, 暂不支持两种方案的动态切换
	float PlaneMeshDistance = 0.0f;
	FString PlaneMeshMaterialPath;
	
	FString MaterialPath;
	
	TArray<FString> AssetsToLoad;
	TArray<FName> ParamNamesNeedLoadAssets;
	
	TStrongObjectPtr<UMaterialInstanceDynamic> PPMaterial;
	
	TMap<FName, TStrongObjectPtr<UObject>> ParamNameToAssets;
	TMap<FName, uint32> MaterialParamUpdateTaskIDs;
	TMap<uint32, TArray<FName>> EntityIDToParamNames;
	// 为了避免材质替换上去以后, 相关材质参数资产还在加载过程中导致表现异常问题, 后处理需要等到所有资产一次性全部加载完毕以后才开始生效
	int AssetLoadID = 0;
	TWeakObjectPtr<UKGMaterialManager> MaterialManager;
	TSharedPtr<KGPPPlaneMeshHandlerBase> PlaneMeshHandler;
	
	// 默认材质后处理的类型由外部传入, 自定义材质后处理可以override GetPPType, 返回自身对应的PPType
	EKGPostProcessType PPType = EKGPostProcessType::KG_PP_None;
	int32 ViewPriority = 0;
	FName IntensityParamName = NAME_None;
};
