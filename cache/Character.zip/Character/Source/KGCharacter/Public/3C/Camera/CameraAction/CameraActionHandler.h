#pragma once

#include "CoreMinimal.h"
#include "3C/Camera/CameraUtil/CameraUtils.h"
#include "3C/Camera/CameraAction/CameraActionBase.h"
#include "3C/Camera/CameraUtil/CameraEase.h"
#include "3C/Camera/CameraAction/KGCameraAnimationModifier.h"
#include "CameraActionHandler.generated.h"

UCLASS(BlueprintType, Blueprintable)
class KGCHARACTER_API UCameraActionHandler : public UObject, public ILuaOverriderInterface
{
	GENERATED_BODY()

public:
	UCameraActionHandler(const FObjectInitializer& ObjectInitializer);

	void Init();

	const FCameraMultiLayerParam& GetControllerRotation_Pitch() const { return ControllerRotation_Pitch; }
	const FCameraMultiLayerParam& GetControllerRotation_Yaw() const { return ControllerRotation_Yaw; }
	const FCameraMultiLayerParam& GetControllerRotation_Roll() const { return ControllerRotation_Roll; }
	void GetRotationRecoverTo(int Priority, float& OutPitch, float& OutYaw, float& OutRoll) const;
	void GetRotationRecoverTo(int Priority, FRotator& OutRot) const;

	bool HsaModifyPitch() const { return bHasModifyPitch; }
	bool HsaModifyYaw() const { return bHasModifyYaw; }
	bool HsaModifyRoll() const { return bHasModifyRoll; }
	
	UPROPERTY(transient, BlueprintReadOnly)
	ACameraManager* CameraManagerOwner;

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_StopAllAction();

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_StartBattleCameraCorrectAction(int Priority, const TArray<int>& EffectCameraModesTag, int64 TargetActorID, float BufferYawLeft, float SafeYawLeft, float SafeYawRight, float BufferYawRight, float BufferPitchHigh, float SafePitchHigh, float SafePitchLow, float BufferPitchLow, float NewBlendTime, int NewBlendInType, int64 NewCurveID, float NewAdaptiveRatio);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_ReStartBattleCameraCorrectAction(int64 ActionID, int Priority, const TArray<int>& EffectCameraModesTag, int64 TargetActorID, float BufferYawLeft, float SafeYawLeft, float SafeYawRight, float BufferYawRight, float BufferPitchHigh, float SafePitchHigh, float SafePitchLow, float BufferPitchLow, float NewBlendTime, int NewBlendInType, int64 NewCurveID, float NewAdaptiveRatio);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_StartCameraParamAdditionalAction(int Priority, const TArray<int>& EffectCameraModesTag, float InFadeInTime, float InDurationTime, float InFadeOutTime, float InYawOffSet, float InPitchOffSet, float InZoomOffSet, float InFOVOffSet, ECameraEaseFunction::Type InBlendInMode = ECameraEaseFunction::Linear, ECameraEaseFunction::Type InBlendOutMode = ECameraEaseFunction::Linear, int64 InFadeInCurveID = 0, int64 InFadeOutCurveID = 0, bool InbDisableLimitView = false);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_StartCameraParamOverrideAction(int Priority, const TArray<int>& EffectCameraModesTag, float InFadeInTime, float InDurationTime, float InFadeOutTime, int64 ViewActorIDForRotator, bool bInUseYawAdjust, float TargetYaw, bool bInUsePitchAdjust, float TargetPitch, bool bInUseRollAdjust, float TargetRoll, float InArmLength, float InFOV, float XOYLag, float ZLag, float XOYSoftRadius, float ZSoftRadius, bool bInUseViewOffsetAdjust, float ViewOffsetX, float ViewOffsetY, ECameraEaseFunction::Type InBlendInMode = ECameraEaseFunction::Linear, ECameraEaseFunction::Type InBlendOutMode = ECameraEaseFunction::Linear, int64 InFadeInCurveID = 0, int64 InFadeOutCurveID = 0, bool InbDisableLimitView = false);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_StartCameraTurnToLockAction(int Priority, const TArray<int>& EffectCameraModesTag, int64 TargetComID, float NewYawDemarcation, float NewWideAngleBlendTime, float NewNarrowAngleBlendTime);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_ReStartCameraTurnToLockAction(int64 ActionID, int Priority, const TArray<int>& EffectCameraModesTag, int64 TargetComID, float NewYawDemarcation, float NewWideAngleBlendTime, float NewNarrowAngleBlendTime);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_StartCameraLockActorForwardAction(int Priority, const TArray<int>& EffectCameraModesTag, int64 ActorID, float InRotSpeed);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_StartCameraLookAtAction(int Priority, const TArray<int>& EffectCameraModesTag, float LookAtX, float LookAtY, float LookAtZ, int64 LookAtActorID, float InBlendInTime, float InBlendOutTime, float InDuration, bool bInRecover, float PitchOff, float YawOff, float RollOff, bool bInUseManualControlPitch, bool bInCanInterrupt, bool bContinue, ECameraEaseFunction::Type InBlendInMode, ECameraEaseFunction::Type InBlendOutMode, int64 BlendInCurveID, int64 BlendOutCurveID, const FString& BoneName);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_ReStartCameraLookAtAction(int64 ActionID, int Priority, const TArray<int>& EffectCameraModesTag, float LookAtX, float LookAtY, float LookAtZ, int64 LookAtActorID, float InBlendInTime, float InBlendOutTime, float InDuration, bool bInRecover, float PitchOff, float YawOff, float RollOff, bool bInUseManualControlPitch, bool bInCanInterrupt, bool bContinue, ECameraEaseFunction::Type InBlendInMode, ECameraEaseFunction::Type InBlendOutMode, int64 BlendInCurveID, int64 BlendOutCurveID, const FString& BoneName);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_StartCameraViewOffByRotAction(int Priority, const TArray<int>& EffectCameraModesTag, float CoordX, float CoordY, float InBlendInTime, float InBlendOutTime, ECameraEaseFunction::Type InBlendInType, ECameraEaseFunction::Type InBlendOutType, int64 BlendInCurve, int64 BlendOutCurve);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_ModifyCameraViewOffByRotAction(int64 ActionID, float CoordX, float CoordY, float InBlendInTime);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_StartCameraViewOffAction(int Priority, const TArray<int>& EffectCameraModesTag, float CoordX, float CoordY, float InBlendInTime, float InBlendOutTime, float InDuration, ECameraEaseFunction::Type InBlendInType, ECameraEaseFunction::Type InBlendOutType, int64 BlendInCurve, int64 BlendOutCurve);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_RefreshCameraViewOffAction(int64 ActionID, float CoordX, float CoordY, float InBlendInTime, float InBlendOutTime, float InDuration, ECameraEaseFunction::Type InBlendInType, ECameraEaseFunction::Type InBlendOutType, int64 BlendInCurve, int64 BlendOutCurve);
	
	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_StartCameraRotZoomAdjustAction(int Priority, const TArray<int>& EffectCameraModesTag, float Pitch, float Yaw, float Zoom, float BlendInTime, float BlendOutTime, float InDuration, bool bInRecover, ECameraEaseFunction::Type BlendInType, ECameraEaseFunction::Type BlendOutType, int64 BlendInCurve, int64 BlendOutCurve);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_StartCameraRotateAction(int Priority, const TArray<int>& EffectCameraModesTag, float Pitch, float Yaw, float Roll, float PitchOffset, float YawOffset, float RollOffset, bool bInRecover, bool bInCanInterrupt, float InBlendInTime, float InBlendOutTime, float InDuration, ECameraEaseFunction::Type InBlendInType, ECameraEaseFunction::Type InBlendOutType, int64 BlendInCurve, int64 BlendOutCurve);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_StartCameraZoomAction(int Priority, const TArray<int>& EffectCameraModesTag, float Zoom, float ZoomOffset, bool bInRecover, bool bInCanInterrupt, float InBlendInTime, float InBlendOutTime, float InDuration, ECameraEaseFunction::Type InBlendInType, ECameraEaseFunction::Type InBlendOutType, int64 BlendInCurve, int64 BlendOutCurve);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_StartCameraFOVAction(int Priority, const TArray<int>& EffectCameraModesTag, float FOV, float FOVOffset, bool bInRecover, float InBlendInTime, float InBlendOutTime, float InDuration, ECameraEaseFunction::Type InBlendInType, ECameraEaseFunction::Type InBlendOutType, int64 BlendInCurve, int64 BlendOutCurve);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_StartCameraLagAction(int Priority, const TArray<int>& EffectCameraModesTag, float XYLag, float ZLag, float XYSoftRadius, float ZSoftRadius, float InBlendInTime, float InBlendOutTime, float InDuration, ECameraEaseFunction::Type InBlendInType, ECameraEaseFunction::Type InBlendOutType, int64 BlendInCurve, int64 BlendOutCurve);
	
	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_InitCameraFollowLookAtSplineMove(int Priority, const TArray<int>& EffectCameraModesTag, int64 SplineID, bool bInYawOffset, float InYawOffset, bool bInPitch, float InPitch, float InRotationLagParams);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_RefreshCameraFollowLookAtSplineMove(int64 ActionID, bool bInYawOffset, float InYawOffset, bool bInPitch, float InPitch, float InRotationLagParams);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraAIMovePriorityAndModesTag(int Priority, const TArray<int>& EffectCameraModesTag);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_StartCameraAIMove(const TArray<FVector>& WorldLocations, const TArray<FRotator>& WorldRotations, int SampleRate, float BlendInTime = 0.f, float BlendOutTime = 0.f, float PlayRate = 1.f);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_StartCameraAIMoveWithPivot(const TArray<FVector>& WorldLocations, const TArray<FRotator>& WorldRotations, const TArray<FVector>& CameraPivotLocations, int SampleRate, float BlendInTime = 0.f, float BlendOutTime = 0.f, float PlayRate = 1.f);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_StartCameraLock(int Priority, const TArray<int>& EffectCameraModesTag, int64 LockActorID, int InBlendType, float InScreenThresholdUp, float InScreenThresholdDown, float InYawBlendParam, float InPitchBlendParam, float InSafeLockPitch, float InSafePitchMin, float InSafePitchMax, float InActionCD, float InRaisePitchOffsetMax, float InDropPitchOffsetMax, bool bClearCD);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_StartCameraNavigationMove(int Priority, const TArray<int>& EffectCameraModesTag, float InYawBlendParam, float InPitchBlendParam, float InLockPitch, float InActionCD);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_StartCameraFollowMove(int Priority, const TArray<int>& EffectCameraModesTag, float InYawBlendParam, float InYawBlendSubParam, float InPitchBlendParam, float InVelocityThreshold, float InLookPitchOffset, float InContinuousInputDurationThreshold, float InPitchSampleDuration, float InActionCD, float InInputThreshold);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_StartActionPlayRate(int64 ActionID, float NewPlayRate);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetActionPlayAt(int64 ActionID, float NewPct);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetActionPause(int64 ActionID, bool bPause);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetActionRecover(int64 Action, bool bRecover);

	UFUNCTION(BlueprintCallable)
	void ProcessViewRotation(class AActor* ViewTarget, float DeltaTime, FRotator& OutViewRotation, FRotator& OutDeltaRot);

	void OnChangeViewRotation(int Priority, bool bChangePitch, double Pitch, bool bChangeYaw, double Yaw, bool bChangeRoll, double Roll, bool bStrongSet);
	
	UFUNCTION(BlueprintCallable)
	void UpdateCameraActions(float DeltaTime);

	UFUNCTION(BlueprintCallable)
	void ModifyViewPOV(float DeltaTime, struct FMinimalViewInfo& InOutPOV);

	UFUNCTION(BlueprintCallable)
	void UpdateAfterFrame();
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_DisableCameraAction(int64 CameraActionID, bool bImmediate = false);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_DisableCameraActionWithBlend(int64 CameraActionID, float OverrideBlendOutTime);

	UFUNCTION(BlueprintCallable)
	bool KAPI_Camera_CheckCameraActionActivate(int64 CameraActionID);

	UFUNCTION(BlueprintCallable)
	void OnManalControl(ECameraManualControlType::Type ControlType);

	UFUNCTION(BlueprintImplementableEvent)
	void OnActionAbort(int64 CameraActionID);

	UCameraActionBase* CreateCameraAction(const TSubclassOf<UCameraActionBase>& NewActionClass, int64 Priority, const TArray<int>& EffectCameraModesTag, bool bUnique = false);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_StartCameraAction(int64 ActionID);

	void StartCameraAction(UCameraActionBase* NewAction);

	void OnModeActivate(UKgCameraMode* ActivateMode);

	void BlockAllAction(bool bBlock);

	bool IsBlockingCameraActions() const { return bBlockActions; }

	void ClearAllAction();

	UKGCameraAnimationCameraModifier* GetCameraAnimationModifier() { return CameraAnimModifier; }

	void SetCameraAnimationPlaying(bool Value) { bPlayingCameraAnimation = Value; }

	void RefreshActionModeParams(UCameraActionBase* Action, int Priority, const TArray<int>& EffectCameraModesTag) const;

	UCameraActionBase* GetActionByID(int64 ActionID);

	bool HasHigherPriorityAction(int Priority);

protected:
	void ReImportCameraAction(UCameraActionBase* NewAction);
	
protected:
	// 当前正在运行的CameraAction
	UPROPERTY(Transient)
	TArray<TObjectPtr<UCameraActionBase>> ActiveCameraActions;

	UPROPERTY(Transient)
	TArray<TObjectPtr<UCameraActionBase>> DeActiveCameraActions;

	TMap<int64, TWeakObjectPtr<UCameraActionBase>> IDToCameraActions;

	UPROPERTY(Transient)
	TObjectPtr<UKGCameraAnimationCameraModifier> CameraAnimModifier;

	bool bBlockActions = false;
	bool bPlayingCameraAnimation = false;

	int CameraAIMovePriority = 0;
	TArray<int> AIMoveEffectCameraModesTag;

	FCameraMultiLayerParam ControllerRotation_Pitch;
	FCameraMultiLayerParam RecoverRotation_Pitch;
	FCameraMultiLayerParam ControllerRotation_Roll;
	FCameraMultiLayerParam RecoverRotation_Roll;
	FCameraMultiLayerParam ControllerRotation_Yaw;
	FCameraMultiLayerParam RecoverRotation_Yaw;

	FRotator CachedRotation = FRotator::ZeroRotator;

	// 不允许 Strong 和 Weak 的Priority一致
	int LastStrongSetPitchPriority = -1;
	int LastStrongSetYawPriority = -1;
	int LastStrongSetRollPriority = -1;

	int LastWeakSetPitchPriority = -1;
	int LastWeakSetYawPriority = -1;
	int LastWeakSetRollPriority = -1;

	bool bHasModifyPitch = false;
	bool bHasModifyYaw = false;
	bool bHasModifyRoll = false;
};