﻿#pragma once
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPNonMaterialBase.h"

class KGPPPhotoExposure : public KGPPNonMaterialBase
{
public:
	void InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType,
		const FString& ExposureCurvePath, float InBaseExposureBias);
	virtual void SetManualWeightCurveValue(float Weight) override;
	
protected:
	int32 AdditionalAutoExposureBiasID = 0;
	float BaseExposureBias = 1.0f;
};

