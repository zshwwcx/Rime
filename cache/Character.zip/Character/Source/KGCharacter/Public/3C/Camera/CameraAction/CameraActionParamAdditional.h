﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "3C/Camera/CameraAction/CameraActionBase.h"
#include "3C/Camera/CameraUtil/CameraEase.h"
#include "CameraActionParamAdditional.generated.h"

/**
 * 
 */
UCLASS()
class KGCHARACTER_API UCameraActionParamAdditional : public UCameraActionBase
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable)
	void InitParamAdditional(float InFadeInTime, float InDurationTime, float InFadeOutTime,
	                         float InYawOffSet, float InPitchOffSet, float InZoomOffSet, float InFOVOffSet,
	                         ECameraEaseFunction::Type InBlendInMode = ECameraEaseFunction::Linear,
	                         ECameraEaseFunction::Type InBlendOutMode = ECameraEaseFunction::Linear,
	                         int64 InFadeInCurveID = 0, int64 InFadeOutCurveID = 0, bool InbDisableLimitView = false);

	virtual void Play() override;
	virtual void ModifyCamera(float DeltaTime) override;

	virtual void Abort() override;

	virtual bool IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType) override { return false; }
	
private:
	FRotator RotationOffSet = FRotator::ZeroRotator;
	FRotator RotationBase = FRotator::ZeroRotator;
	float ZoomOffset = 0.f;
	float ZoomBase = 0.f;
	float FOVOffset = 0.f;
	float FOVBase = 0.f;

	bool bDisableLimitView = false;
	bool bRowDisableLimitView = false;
};
