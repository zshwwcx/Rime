// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "3C/Camera/CameraAction/CameraActionBase.h"
#include "CameraMoveFollowLookAtSplineMove.generated.h"

/**
 * 
 */
UCLASS()
class KGCHARACTER_API UCameraMoveFollowLookAtSplineMove : public UCameraActionBase
{
	GENERATED_BODY()

public:
	void Init(class USplineComponent* SplineCom, bool bInYawOffset, float InYawOffset, bool bInPitch, float InPitch, float InRotationLagParams);

	void Refresh(bool bInYawOffset, float InYawOffset, bool bInPitch, float InPitch, float InRotationLagParams);
	
	virtual void Play() override;

	virtual bool ProcessViewRotation(class AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch, double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot) override;

	virtual void ModifyCamera(float DeltaTime) override;
	
	virtual void Abort() override;

	virtual void DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode) override;

	virtual bool IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType) override { return false; };

private:
	void CancelFollowLookAtSpineMove();

	void InitParams();

private:
	UPROPERTY(Transient)
	TObjectPtr<class USplineComponent> FollowLookAtSplineCom = nullptr;

	TWeakObjectPtr<class URoleMovementComponent> LookAtRoleMovementCom = nullptr;

	float RotationLagParams = 0.f;

	bool bYawOffset = false;
	float YawOffset = 0.f;
	bool bPitch = false;
	float Pitch = 0.f;
};
