#pragma once
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPMaterialBase.h"

class KGPPMaterialClip : public KGPPMaterialBase
{
public:
	virtual bool CanActivateMultiPPInstance() const override { return false; }
	
	virtual void OnTaskActivated() override;
	virtual void OnTaskDeactivated() override;
};
