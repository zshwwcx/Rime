﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "3C/Camera/CameraAction/CameraActionBase.h"
#include "3C/Camera/CameraUtil/CameraEase.h"
#include "CameraActionParamOverride.generated.h"

/**
 * 
 */
UCLASS()
class KGCHARACTER_API UCameraActionParamOverride : public UCameraActionBase
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable)
	void InitParamOverride(float InFadeInTime, float InDurationTime, float InFadeOutTime,
	                       const FRotator& PlayerRotator, bool bInUseYawAdjust, float TargetYaw, bool bInUsePitchAdjust,
	                       float TargetPitch, bool bInUseRollAdjust, float TargetRoll, float InArmLength, float InFOV,
	                       float XOYLag, float ZLag, float XOYSoftRadius, float ZSoftRadius, bool bInUseViewOffsetAdjust,
	                       float ViewOffsetX, float ViewOffsetY,
	                       ECameraEaseFunction::Type InBlendInMode = ECameraEaseFunction::Linear,
	                       ECameraEaseFunction::Type InBlendOutMode = ECameraEaseFunction::Linear,
	                       int64 InFadeInCurveID = 0, int64 InFadeOutCurveID = 0, bool InbDisableLimitView = false);

	virtual void Play() override;
	virtual void ModifyCamera(float DeltaTime) override;
	virtual bool ProcessViewRotation(class AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch, double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot) override;

	virtual void Abort() override;

	virtual bool IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType) override { return false; }

	virtual void DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode) override;

private:
	void InitBaseParam();

private:
	bool bUseYawAdjust = false;
	bool bUsePitchAdjust = false;
	bool bUseRollAdjust = false;
	FRotator RotationAdaptive = FRotator::ZeroRotator;
	FRotator RotationBase = FRotator::ZeroRotator;
	float TargetArmLength = -1.f;
	float ArmBase = 0.f;
	float TargetCameraFOV = -1.f;
	float FOVBase = 0.f;
	float TargetCameraXOYLag = -1;
	float TargetCameraZLag = -1;
	float XOYLagBase = 0;
	float ZLagBase = 0;
	float TargetCameraXOYSoftRadius = -1;
	float TargetCameraZSoftRadius = -1;
	float XOYSoftRadiusBase = 0;
	float ZSoftRadiusBase = 0;

	bool bAdjustViewOffset = false;
	FVector2D TargetViewOffset = FVector2D::ZeroVector;
	FVector2D ViewOffsetBase = FVector2D::ZeroVector;

	bool bDisableLimitView = false;
	bool bRowDisableLimitView = false;
};
