#pragma once

#include "CoreMinimal.h"
#include "3C/Camera/BaseCamera.h"
#include "3C/Camera/CameraUtil/CameraBlend.h"
#include "Camera/PlayerCameraManager.h"
#include "LuaOverriderInterface.h"
#include "3C/Camera/CameraContainer/ChthollyTree.h"
#include "Kismet/KismetMathLibrary.h"
#include "CameraManager.generated.h"

class USplineComponent;
class UCameraActionHandler;
class UWaveOscillatorCameraShakePatternV2;
class UCameraAnimationSequence;

/**
 * 摄像机管理器, 具体逻辑在Lua
 */
UCLASS(BlueprintType, Blueprintable)
class KGCHARACTER_API ACameraManager : public APlayerCameraManager
		, public ILuaOverriderInterface
{
	GENERATED_UCLASS_BODY()

public:
	virtual FString GetLuaFilePath_Implementation() const override { return TEXT("Gameplay.3C.Camera.CameraManager"); }

public:
	virtual void InitializeFor(class APlayerController* PC) override;

	virtual void SetViewTarget(class AActor* NewViewTarget, FViewTargetTransitionParams TransitionParams = FViewTargetTransitionParams()) override;

	void CustomSetViewTarget(class AActor* NewViewTarget, ECameraEaseFunction::Type EaseType, ECameraViewBlendFunction::Type BlendType, float BlendTime, bool bLockOutgoing, UCurveFloat* BlendCurve, bool bDoDotBlendRot = false);

	virtual void ApplyCameraModifiers(float DeltaTime, FMinimalViewInfo& InOutPOV) override;

	void OnCustomShakePatternTeardown(UWaveOscillatorCameraShakePatternV2* WaveOscillatorCameraShakePatternV2);;

	UFUNCTION(Exec)
	void PlayCameraShake(const FString& AssetPath, float Scale = 1.f);

	/** 
	 * Called to give PlayerCameraManager a chance to adjust view rotation updates before they are applied. 
	 * e.g. The base implementation enforces view rotation limits using LimitViewPitch, et al. 
	 * @param DeltaTime - Frame time in seconds.
	 * @param OutViewRotation - In/out. The view rotation to modify.
	 * @param OutDeltaRot - In/out. How much the rotation changed this frame.
	 */
	virtual void ProcessViewRotation(float DeltaTime, FRotator& OutViewRotation, FRotator& OutDeltaRot) override;

	virtual void AssignViewTarget(AActor* NewTarget, FTViewTarget& VT, struct FViewTargetTransitionParams TransitionParams = FViewTargetTransitionParams()) override;

	UFUNCTION(BlueprintCallable)
	static float GetCameraShakeDurationFromCDO(TSubclassOf<UCameraShakeBase> CameraShakeClass);

	UFUNCTION(BlueprintCallable)
	virtual UCameraShakeBase* StartCameraShakeWithDuration(TSubclassOf<UCameraShakeBase> ShakeClass, float Scale = 1.f, ECameraShakePlaySpace PlaySpace = ECameraShakePlaySpace::CameraLocal, FRotator UserPlaySpaceRot = FRotator::ZeroRotator,float Duration = 0);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_StartCameraShakeWithDuration(int64 ShakeClassID, float Scale = 1.f, ECameraShakePlaySpace PlaySpace = ECameraShakePlaySpace::CameraLocal, FRotator UserPlaySpaceRot = FRotator::ZeroRotator,float Duration = 0);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_StopCameraShake(int64 ShakeInstID, bool bImmediately = true);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCanRotInputWhileBlend(bool bValue) { bCanRotInputWhileBlend = bValue; }

	UFUNCTION(BlueprintCallable)
	bool KAPI_Camera_CanRotInputWhileBlend() const { return bCanRotInputWhileBlend; }

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetViewTargetWithBlendCustom(class AActor* NewViewTarget, float BlendTime = 0, ECameraEaseFunction::Type EaseFunc = ECameraEaseFunction::Linear, ECameraViewBlendFunction::Type BlendType = ECameraViewBlendFunction::Polar, bool bLockOutgoing = false, int64 CameraBlendCurveID = 0, bool bInDoNotBlendRot = false);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetViewTargetWithBlendCustomByID(int64 NewViewTargetID, float BlendTime = 0, ECameraEaseFunction::Type EaseFunc = ECameraEaseFunction::Linear, ECameraViewBlendFunction::Type BlendType = ECameraViewBlendFunction::Polar, bool bLockOutgoing = false, int64 CameraBlendCurveID = 0, bool bInDoNotBlendRot = false);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetViewTargetWithBlendCustomByCameraComponentID(int64 NewViewTargetID, float BlendTime = 0, ECameraEaseFunction::Type EaseFunc = ECameraEaseFunction::Linear, ECameraViewBlendFunction::Type BlendType = ECameraViewBlendFunction::Polar, bool bLockOutgoing = false, int64 CameraBlendCurveID = 0);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetViewTargetWithBlendByID(int64 NewViewTargetID, float BlendTime = 0, enum EViewTargetBlendFunction BlendFunc = VTBlend_Linear, float BlendExp = 0, bool bLockOutgoing = false);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetViewTargetWithBlendByCameraComponentID(int64 NewViewTargetID, float BlendTime = 0, enum EViewTargetBlendFunction BlendFunc = VTBlend_Linear, float BlendExp = 0, bool bLockOutgoing = false);

	void Update(float DeltaTime);

	TArray<TObjectPtr<UCameraModifier>>& GetModiferList(){ return ModifierList; };

	virtual void StopCameraFade() override;

	virtual UCameraShakeBase* StartCameraShake(TSubclassOf<UCameraShakeBase> ShakeClass, float Scale = 1.f, ECameraShakePlaySpace PlaySpace = ECameraShakePlaySpace::CameraLocal, FRotator UserPlaySpaceRot = FRotator::ZeroRotator) override;

	static void SetEnableDebug(bool bEnable) { bEnableDebug = bEnable; }
	static bool IsCameraDebug() { return bEnableDebug; }

protected:
	UFUNCTION(BlueprintImplementableEvent)
	void OnInitializeFor(class APlayerController* PC);

	// 相机Blend重新计算POV
	/** Internal function conditionally called from UpdateCamera to do the actual work of updating the camera. */
	virtual void DoUpdateCamera(float DeltaTime) override;
	
	void UpdateView(FTViewTarget& OutVT, FCameraSnapShot& OutSnapShot, float DeltaTime);

public:
	UFUNCTION(BlueprintImplementableEvent)
	void OnAutoManageActiveCameraTarget(AActor* SuggestedTarget);

	UFUNCTION(BlueprintCallable)
	UKgCameraMode* GetCurCameraMode();

	UFUNCTION(BlueprintImplementableEvent)
	int KCB_GetCurCameraModeTag();

	//是否开启相机修改器效果(抖动,后期效果等)
	UFUNCTION(BlueprintCallable)
	void SetEnableCameraModifier(bool bEnable);

	UFUNCTION(BlueprintCallable)
	void K2_ClearCachedPPBlends();

	UFUNCTION(BlueprintCallable)
	void DisableViewLimit(bool Disable) { Disable ? ++DisableLimitView : --DisableLimitView; };

	UFUNCTION(BlueprintCallable)
	bool IsDisableViewLimit() const { return DisableLimitView > 0; };
	
	UFUNCTION(BlueprintCallable)
	float GetCurrentBlendTime() const { return BlendParams.BlendTime; };

	UFUNCTION(BlueprintCallable)
	bool IsBlending();

	void OnBlendFinish();

	UFUNCTION(BlueprintImplementableEvent)
	void OnBlendFinishForScript();

	UFUNCTION(BlueprintCallable)
	void SetNotifyScriptWhenBlendFinish(bool Value) { bNeedNotifyScriptWhenBlendFinish = Value; }

	UFUNCTION(BlueprintCallable)
	void RearrangeModifiers();

	UFUNCTION(BlueprintCallable)
	void SetAudioCameraDistanceRtpcName(FString Name, float Tolerance);

	void ClearModeModifyDataAfterFrame();

public:
	UPROPERTY(transient)
	FCameraSnapShot ViewTargetSnapShot; 

	UPROPERTY(transient)
	FCameraSnapShot ViewCachedSnapShot; 
	
	UPROPERTY(transient)
	FCameraSnapShot ViewPendingTargetSnapShot;

	UPROPERTY(transient)
	float PCAspectRatio = 16.f / 9.f; 

	UPROPERTY(transient)
	TObjectPtr<UCurveFloat> CurveForFade = nullptr;

	// CameraActionHandlerClass
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = PlayerController)
	TSubclassOf<UCameraActionHandler> CameraActionHandlerClass;

	static constexpr int32 THIRD_CAMERA_INDEX = 0;

protected:
	UPROPERTY(Transient)
	TMap<int32, TObjectPtr<UKgCameraMode>> CameraModes;

	UPROPERTY(Transient)
	TObjectPtr<ABaseCamera> CameraForGaming;

	UPROPERTY(Transient)
	TObjectPtr<ABaseCamera> CineCameraForGaming;

	UPROPERTY(Transient)
	TMap<int64, TObjectPtr<UCurveBase>> CameraCurves;

	int64 CurveLoadID = -1;
	TArray<int64> CurveIDs;

	UPROPERTY(Transient, BlueprintReadWrite)
	uint32 bEnableCameraModifier : 1;

	UPROPERTY(Transient, BlueprintReadWrite)
	TObjectPtr<UCameraActionHandler> CameraActionHandler = nullptr;

	bool bHasRotationInput = false;

	static bool bEnableDebug;
protected:
	TArray<TWeakObjectPtr<UWaveOscillatorCameraShakePatternV2>> CustomShakePatternList;

	FVector CameraPivotBoneOffset = FVector::ZeroVector;

	FString AudioCameraDistanceRtpcName;

	float CurrentCameraDistanceRtpcValue = 0.0f;

	float AudioCameraDistanceTolerance = 1.0f;

	int DisableLimitView = 0;

	int ActivateCameraModeTag = -1;

	bool bCutSceneActivate = false;

	bool bACTMode = false;

	TSet<int> NotApplyPOVPostProcess;

private:
	FCameraInterpolationParam<float> CameraBlendParam;
	FCameraBlend CameraViewBlendProxy;
	
	bool bNeedNotifyScriptWhenBlendFinish = false;

	bool bUseCustomBlend = false;
	bool bDoNotBlendRot = false;

	bool bCanRotInputWhileBlend = false;

#pragma region CameraBase
public:
	UCameraActionHandler* GetActionHandler() { return CameraActionHandler; }
	bool HasRotationInput() const { return bHasRotationInput; }

	AActor* KAPI_Camera_GetLookAtTarget();

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_GetLookAtTargetActorID();

	UFUNCTION(BlueprintCallable)
	void KAPI_LoadCurves(const TArray<FString>& Curves, const TArray<int64>& CurvesID);

	void OnLoadedCurves(int InLoadID, const TArray<UObject*>& Curves);

	UFUNCTION(BlueprintImplementableEvent)
	void KCB_Camera_OnLoadedCurves(const TMap<int64, int64>& CurveIDToObjectID);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetACTMode(bool bEnable);

	UFUNCTION(BlueprintCallable)
	bool KAPI_Camera_GetACTMode() const { return bACTMode; };
	
	UFUNCTION(BlueprintCallable)
	int KAPI_Camera_GetActiveCameraModeTag() const { return ActivateCameraModeTag; };

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetViewAngleSetting(int64 CameraModeID, float InViewPitchMin, float InViewPitchMax, float InViewYawMin, float InViewYawMax, float InViewRollMin, float InViewRollMax, int Priority = 0);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_RemoveViewAngleSetting(int64 CameraModeID, int Priority = 0);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetViewYawSetting(int64 CameraModeID, float Min, float Max, int Priority = 0);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetViewRollSetting(int64 CameraModeID, float Min, float Max, int Priority = 0);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetViewPitchSetting(int64 CameraModeID, float Min, float Max, int Priority = 0);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SyncModeViewLimitSetting(int64 CameraModeID);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_ClearMode();

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_GetOrCreateCamera(int CameraModeTag, bool bCinematic = false);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_GetOrCreateGameControlCamera(int64 GPEMCameraID, const FVector& Loc, const FRotator& Rot);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_CreateCameraMode(int CameraModeTag);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_FindCameraByName(const FName& CameraMane);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_GetViewTargetActorID();

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_EnableModeApplyPOVPostProcess(int64 CameraModeID, bool bEnable);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_CopyAndRefreshControlData(int64 PreviousCameraModeID, int64 CurrentCameraModeID, int Priority);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_RefreshControlData(
		int64 CameraModeID, int Priority,
		float ZoomMin, float ZoomMax, float ZoomStep, float NewFOV,
		int EaseTypeZoomLag, float ParamZoomLag, int64 CurveIDZoomLag,
		int EaseTypeZLag, float ParamZLag, int64 CurveIDZLag, float NewSoftZoneRadiusZ,
		int EaseTypeXOYLag, float ParamXOYLag, int64 CurveIDXOYLag, float NewSoftZoneRadiusXOY,
		int EaseTypeRelease, float ParamRelease, int64 CurveIDRelease,
		int EaseTypeCompress, float ParamCompress, int64 CurveIDCompress,
		float ViewOffX, float ViewOffY,
		bool bEnableDitherFade, const TArray<int>& NewDitherFadeObjectTypesForStatic, const TArray<int>& NewDitherFadeObjectTypesForDynamic,
		int DetectType, float DetectRadius, float DetectPitch, float AngleMin, float AngleMax, float StaticDetectInterval, float DynamicDetectInterval, float CameraPosDiffThreshold,
		float InitArmLen, const FRotator& InitRot,
		float YawSensitivity, float PitchSensitivity, int64 TargetLocationOffsetCurveID, int64 FOVCurveID
	);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_InitRotationLagParam(int64 CameraModeID, bool bNewEnableCameraRotationLag, ECameraEaseFunction::Type EaseType, float Param, int64 CurveID);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_ResetCamera(int64 CameraModeID);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_EnableModeTick(int64 CameraModeID, bool bEnable);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_ForceUpdate(int64 CameraModeID, bool bDoTrace = true);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_MarkInstantBlend(int64 CameraActorID, bool bMarkInstantBlend);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_ForceUpdateWithBaseCollision(int64 CameraModeID);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_MarkModeActivate(int64 CameraModeID, bool Value);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetLookAtTargetByID(int64 CameraID, int64 TargetID);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_AfterModeActivate(int64 CameraModeID);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetInitArmLenAndDir(int64 CameraModeID, float TargetArmLen, const FRotator& TargetRot, const FRotator& BaseSpace, bool bSyncPlayerController = true);
	
	UFUNCTION(BlueprintCallable)
	float KAPI_Camera_GetZoomMin(int64 CameraModeID) const;

	UFUNCTION(BlueprintCallable)
	float KAPI_Camera_GetZoomMax(int64 CameraModeID) const;

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetZoomSetting(int64 CameraModeID, float ZoomMin, float ZoomMax, int Priority = 0);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_GetZoomSetting(int64 CameraModeID, float& ZoomMin, float& ZoomMax);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetOverrideZoomSetting(int64 CameraModeID, float OverrideZoom, int Priority = 0);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetZoomMaxSetting(int64 CameraModeID, float ZoomMax, int Priority = 0);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_RemoveZoomSetting(int64 CameraModeID, int Priority = 0, bool bNeedZoomFix = false);

	UFUNCTION(BlueprintCallable)
	FVector KAPI_Camera_GetCameraViewForwardDirection();

	UFUNCTION(BlueprintCallable)
	FVector KAPI_Camera_GetCameraViewRightDirection();

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetFOVSetting(int64 CameraModeID, float NewFOV, int Priority = 0);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_RemoveFOVSetting(int64 CameraModeID, int Priority = 0);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraZLagSetting(int64 CameraModeID, float Param, int Priority = 0);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraZSoftRadiusSetting(int64 CameraModeID, float Param, int Priority = 0);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraXOYLagSetting(int64 CameraModeID, float Param, int Priority = 0);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraXOYSoftRadiusSetting(int64 CameraModeID, float Param, int Priority = 0);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_RemoveCameraZLagSetting(int64 CameraModeID, int Priority = 0);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_RemoveCameraZSoftRadiusSetting(int64 CameraModeID, int Priority = 0);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_RemoveCameraXOYLagSetting(int64 CameraModeID, int Priority = 0);

	UFUNCTION(BlueprintCallable)
	void Kapi_Camera_RemoveCameraXoySoftRadiusSetting(int64 CameraModeID, int Priority = 0);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraLookAt(int64 CameraModeID, int64 TargetActorID, int64 ControlActorID, const FName& NewBoneName, float NewBoneOffsetX, float NewBoneOffsetY, float NewBoneOffsetZ, ERelativeTransformSpace InTransformSpace = ERelativeTransformSpace::RTS_Actor);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraLookAtWithStaticBoneOffsetZ(int64 CameraModeID, int64 TargetActorID, int64 ControlActorID, const FName& NewBoneName, float NewBoneOffsetX, float NewBoneOffsetY, float NewBoneOffsetZ, ERelativeTransformSpace InTransformSpace = ERelativeTransformSpace::RTS_Actor);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_GetCameraLookAt(int64 CameraModeID);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraLookAtWithWorldLoc(int64 CameraModeID, int64 TargetID, int64 TargetActorID, const FVector& WorldLoc);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraLookAtWithPivotLoc(int64 CameraModeID, int64 TargetID, int64 TargetActorID, float PivotLocX, float PivotLocY, float PivotLocZ, float CameraPitch, float CameraYaw, float CameraRoll, float Zoom);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraScreenViewOffsetSetting(int64 CameraModeID, float X, float Y, int Priority = 0);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_RemoveCameraScreenViewOffsetSetting(int64 CameraModeID, int Priority);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_GetCameraScreenViewOffsetSetting(int64 CameraModeID, float& OutX, float& OutY);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraAdaptiveScreenViewOffsetSettingWithZoom(int64 CameraModeID, float ViewOffXWithZoomMax, float ViewOffXWithZoomMin, float ViewOffYWithZoomMax, float ViewOffYWithZoomMin, float HalfLift = 0.02f);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_UpdateZoom(int64 CameraActorID, float TargetZoom, bool bAbsolute = false);

	UFUNCTION(BlueprintCallable)
	int KAPI_Camera_GetCameraTargetZoomLen(int64 CameraActorID);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_EnableCameraTick(int64 CameraActorID, bool bEnable);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_EnableCameraModeTick(int64 CameraModeID, bool bEnable);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_EnableCameraNewCollision(int64 CameraActorID, bool bEnable, const TArray<int>& NewCollisionDetectTypes);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_EnableCameraCollision(int64 CameraActorID, bool bEnable);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraRotSensitivity(int64 CameraModeID, float Yaw, float Pitch, int Priority);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_RemoveCameraRotSensitivity(int64 CameraModeID, int Priority);

	UFUNCTION(BlueprintCallable)
	float KAPI_Camera_GetCameraRotYawSensitivity(int64 CameraModeID);

	UFUNCTION(BlueprintCallable)
	float KAPI_Camera_GetCameraRotPitchSensitivity(int64 CameraModeID);
	
	UFUNCTION(BlueprintCallable)
	FVector KAPI_Camera_GetCameraRootLocation(int64 CameraActorID);

	UFUNCTION(BlueprintCallable)
	FRotator KAPI_Camera_GetCameraRootRotation(int64 CameraActorID);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraRootLocation(int64 CameraActorID, const FVector& NewLocation);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraRootRelativeLocation(int64 CameraActorID, float X, float Y, float Z);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraArmRelativeRotation(int64 CameraActorID, const FRotator& NewRelative);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraRootRotation(int64 CameraActorID, const FRotator& NewRotation);

	UFUNCTION(BlueprintCallable)
	FVector KAPI_Camera_GetCameraCachedArmOrigin(int64 CameraActorID);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_CopyTransformFromCamera(int64 CameraActorIDA, int64 CameraActorIDB);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_CopyTransformFromView(int64 CameraActorIDA);
	
	UFUNCTION(BlueprintCallable)
	FVector KAPI_Camera_GetCameraLocation(int64 CameraActorID);

	UFUNCTION(BlueprintCallable)
	FRotator KAPI_Camera_GetCameraRotation(int64 CameraActorID);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_GetCameraActorRotationByAxis(int64 CameraActorID, float& Pitch, float& Yaw, float& Roll);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraActorPitch(int64 CameraActorID, float Pitch);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraActorRoll(int64 CameraActorID, float Roll);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraActorYaw(int64 CameraActorID, float Yaw);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_AdjustTargetOffsetWhenLookAtMove(int64 CameraActorID, const FVector& LookAtNewPos);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraTargetOffset(int64 CameraActorID, float X, float Y, float Z);

	UFUNCTION(BlueprintCallable)
	float KAPI_Camera_GetCameraTargetOffsetZ(int64 CameraActorID);

	UFUNCTION(BlueprintCallable)
	float KAPI_Camera_GetCameraTargetOffsetY(int64 CameraActorID);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_AddCameraTargetOffsetZWithClamp(int64 CameraActorID, float ZDelta, float Min, float Max);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_AddCameraTargetOffsetYWithClamp(int64 CameraActorID, float YDelta, float Min, float Max);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraSocketOffset(int64 CameraActorID, float X, float Y, float Z);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraSocketRotOffset(int64 CameraActorID, float Pitch, float Yaw, float Roll);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_GetCameraSocketRotOffset(int64 CameraActorID, float& Pitch, float& Yaw, float& Roll);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_AddCameraSocketOffset(int64 CameraActorID, float X, float Y, float Z);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_AddCameraOriginWorldOffset(int64 CameraActorID, float X, float Y, float Z);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_AddCameraSocketOffsetXWithClamp(int64 CameraActorID, float X, float Min, float Max);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_AddCameraSocketOffsetYWithClamp(int64 CameraActorID, float Y, float Min, float Max);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_AddCameraSocketOffsetZWithClamp(int64 CameraActorID, float Z, float Min, float Max);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraSocketOffsetX(int64 CameraActorID, float X);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraSocketOffsetY(int64 CameraActorID, float Y);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraSocketOffsetZ(int64 CameraActorID, float Z);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_GetCameraOriginWorldOffset(int64 CameraActorID, float& X, float& Y, float& Z);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_GetCameraSocketOffset(int64 CameraActorID, float& X, float& Y, float& Z);

	UFUNCTION(BlueprintCallable)
	float KAPI_Camera_GetCameraSocketOffsetZ(int64 CameraActorID);

	UFUNCTION(BlueprintCallable)
	float KAPI_Camera_GetCameraFOV(int64 CameraActorID);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetOnlyUseBoneLocationZ(int64 CameraActorID, bool bEnable);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_InitManualMove(int64 CameraActorID, bool bEnable, bool bLimitRot = false, float NewPitchMin = -60.f, float NewPitchMax = 60.f, float NewYawMin = -179.99f, float NewYawMax = 180.f);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_InitLimitRot(int64 CameraActorID, bool bLimitRot = false, float NewPitchMin = -60.f, float NewPitchMax = 60.f, float NewYawMin = -179.99f, float NewYawMax = 180.f);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_InitLimitPitchRot(int64 CameraActorID, bool bLimitRot = false, float NewPitchMin = -60.f, float NewPitchMax = 60.f);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_MoveX(int64 CameraActorID, float X, bool bLimitZone = false);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_MoveY(int64 CameraActorID, float Y, bool bLimitZone = false);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_MoveZ(int64 CameraActorID, float Z, bool bLimitZone = false);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_MoveZToXOY(int64 CameraActorID, float Z, bool bLimitZone = false);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_LookUp(int64 CameraActorID, float Value);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_Turn(int64 CameraActorID, float Value);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_CopyFOVFromCamera(int64 CameraActorIDA, int64 CameraActorIDB);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_CopyPPFromCamera(int64 CameraActorIDA, int64 CameraActorIDB);

	UFUNCTION(BlueprintCallable)
	int KAPI_Camera_GetFocusOnAdaptiveRotator(int64 CameraActorID, FRotator& Result, const FVector& ActorLocation, float InLeftX, float InRightX, float InUpY, float InDownY, float InCheckInScreenError, float InMiddleLockHeight, bool InbForceLockMiddle);
	
	UFUNCTION(BlueprintCallable)
	FPostProcessSettings KAPI_Camera_GetPPSetting(int64 CameraActorID);

	UFUNCTION(BlueprintCallable)
	void KAPI_CineCamera_SetActorTrackFocusSetting(int64 CameraActorID, int64 TrackActorID, const FVector& Offset);

	UFUNCTION(BlueprintCallable)
	void KAPI_CineCamera_SetManualFocusSetting(int64 CameraActorID, float ManualFocusDistance);

	UFUNCTION(BlueprintCallable)
	void KAPI_CineCamera_SetFocusLengthSetting(int64 CameraActorID, float FocusLength);

	UFUNCTION(BlueprintCallable)
	float KAPI_CineCamera_GetCameraFocalLength(int64 CameraActorID);

	UFUNCTION(BlueprintCallable)
	void KAPI_CineCamera_SetApertureSetting(int64 CameraActorID, float Aperture);

	UFUNCTION(BlueprintCallable)
	FRotator KAPI_Camera_GetAppropriateRotationForInteractive(int64 ActorAID, int64 ActorBID, int64 ActorCID);

	UFUNCTION(BlueprintCallable)
	FTransform KAPI_Camera_GetCorrectInteractiveCameraRotAndZoom(int64 OriginActorID, int64 DestinationActorID, const FRotator& CurrentDir, float DesiredPitch, float DesiredYawToOrigin, float DesiredYawToDestination, float DesiredZoom, float MinZoom, bool bCoaxial = true);

	UFUNCTION(BlueprintCallable)
	FTransform KAPI_Camera_GetCorrectInteractiveCameraRotAndZoomForDualCamera(int64 OriginActorID, int64 DestinationActorID, const FRotator& CurrentDir, float DesiredPitch, float DesiredYawToOrigin, float DesiredZoom, float MinZoom);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_UpdateZoomWithPivotAdsorption(int64 CameraModeID, float TargetZoom);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_AddSocketOffZWithPivotAdsorption(int64 CameraModeID, float Value, float UpThreshold, float DownThreshold);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetZoomWithAdsorption(int64 CameraModeID, float InAdsorptionSpeedX, float InAdsorptionSpeedXY, float InMaxX, float InMaxY, float InMaxYNeg, int EaseType, float AdsorptionMinZoom, float AdsorptionMaxZoom);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_CancelZoomAdsorption(int64 CameraModeID);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_GetAdsorptionUpAndDownThreshold(int64 CameraModeID, float Height, float& DownThreshold, float& UpThreshold);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCustomRotAndOffWithRecover(int64 CameraModeID, float DesiredPitch, float DesiredYaw, float DesiredRoll, float X, float Y, float Z, float BasePitch, float BaseYaw, float BaseRoll, ECameraEaseFunction::Type InRecoverEaseType);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_CancelCustomRotAndOffWithRecover(int64 CameraModeID);
	
	UFUNCTION(BlueprintCallable)
	FRotator KAPI_Camera_CalcOrientFromPosToPos(float StartX, float StartY, float StartZ, float EndX, float EndY, float EndZ);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_EnableCameraDitherFade(int Reason, bool bEnable);

	UFUNCTION(BlueprintCallable)
	int KAPI_Camera_GetCameraDitherFadeSwitcher() const { return CameraDitherFadeSwitcher; }

	UFUNCTION(BlueprintCallable)
	bool KAPI_Camera_CanCameraDitherFade() const { return CameraDitherFadeSwitcher == 0; }

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCineCameraDitherFade(int64 CameraActorID, bool bEnable);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_StartManualCameraFade(float Duration, int64 FadeCurveID, float R, float G, float B, float A);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetWaterHeightCorrectParams(int64 CameraActorID, bool bEnableWaterDetect, float InWaterHeightCorrect);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_SetCameraCustomRoleInitParams(int64 CameraModeID, int64 LookAtTargetID, const FName& LookAtBone, float LookAtScreenX, float LookAtScreenY, const FName& CloseUpBone, float CloseUpScreenX, float CloseUpScreenY, float HalfLife, float MaxZoom, float MinZoom, float ThresholdZoom, float InitZoom, float LookAtYaw, float CloseUpYaw, float InitPitch, float InitRoll, float PitchMin, float PitchMaxCloseUp, float PitchMaxThreshold, float YawMin, float YawMax);

	UFUNCTION(BlueprintImplementableEvent)
	void KCB_NotifyCustomRoleCameraRot(float DeltaRotPitch);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_RemoveLookAtBoneRemainOffset(int64 CameraModeID);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_RecoverCameraLookAt(int64 CameraModeID);

	static int CAMERA_BASE_SETTING_PRIORITY;

protected:
	// == 0 表示无限制 != 0表示有限制
	int CameraDitherFadeSwitcher = 0;
#pragma endregion CameraBase

#pragma region DialogueCamera

public:

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_DialogueCamera_SetCameraPostProcessSetting(int64 CameraActorID, bool bOverride_DepthOfFieldFocalDistance, float DepthOfFieldFocalDistance, bool bOverride_DepthOfFieldFstop, float DepthOfFieldFstop, bool bOverride_DepthOfFieldSensorWidth, float DepthOfFieldSensorWidth, bool bOverride_DepthOfFieldFocalRegion, float DepthOfFieldFocalRegion, bool bOverride_DepthOfFieldNearTransitionRegion, float DepthOfFieldNearTransitionRegion, bool bOverride_DepthOfFieldFarTransitionRegion, float DepthOfFieldFarTransitionRegion, bool bMobileHQGaussian, bool bOverride_DepthOfFieldScale, bool bOverride_DepthOfFieldNearBlurSize, bool bOverride_DepthOfFieldFarBlurSize, float FieldOfView);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_DialogueCamera_SetCameraDOFDistance(int64 CameraActorID, float DOFDistance);

	UFUNCTION(BlueprintCallable)
	float KAPI_Camera_DialogueCamera_GetCameraDOFDistance(int64 CameraActorID);

	UFUNCTION(BlueprintCallable)
	float KAPI_Camera_DialogueCamera_GetCameraDOFDistanceFromViewportCenter(int64 CameraActorID);
	
	UFUNCTION(BlueprintCallable)
	FVector KAPI_Camera_DialogueCamera_GetViewportCenterWorldPosition();

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_DialogueCamera_SetCameraDOFOverride(int64 CameraActorID, bool bOverride_DOFFstop, bool bOverride_DOFSensorWidth, bool bOverride_DOFFocalDistance);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_DialogueCamera_SetCameraDOFParams(int64 CameraActorID, float DOFDistance, float DOFSensorWidth, float DOFFstop);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_DialogueCamera_SetCameraFOV(int64 CameraActorID, float FOVValue);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_DialogueCamera_SetCameraAspectRatioAxisConstraint(int64 CameraActorID, int NewEAspectRatioAxisConstraint);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_DialogueCamera_SetCameraOverrideAspectRatioAxisConstraint(int64 CameraActorID, bool bNewOverrideAspectRatioAxisConstraint);
    
    UFUNCTION(Blueprintcallable)
    void KAPI_Camera_DialogueCamera_SetAspectRatio(int64 CameraActorID, float InAspectRatio);
    
    UFUNCTION(BlueprintCallable)
    void KAPI_Camera_DialogueCamera_SetConstraintAspectRatio(int64 CameraActorID, bool bInConstrainAspectRatio);

#pragma endregion DialogueCamera
	
#pragma region Modifier
public:
	UFUNCTION(BlueprintCallable)
	bool KAPI_Camera_IsNotApplyPOVPostProcess() const { return NotApplyPOVPostProcess.Num() > 0; };

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_EnablePOVPostProcess(bool bEnable, int Tag);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_CutSceneActivate(bool bActivate);

	UFUNCTION(BlueprintCallable)
	bool KAPI_Camera_IsCutSceneActivate() const { return bCutSceneActivate; };

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_BlockAllCameraActions(bool Value);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_AddNewCameraModifier(TSubclassOf<UCameraModifier> ModifierClass);
	
	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_RemoveCameraModifier(int64 ModifierID);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_EnableModifier(int64 ModifierID);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_DisableModifier(int64 ModifierID, bool bImmediate = false);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_CameraEffect_DisableModifier(int64 ModifierID, bool bImmediate = false);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_CameraEffect_SetAlphaOutTime(int64 ModifierID, float OutTime);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_CameraEffect_SetAlphaInTime(int64 ModifierID, float InTime);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_CameraEffect_SetAutoRemoveFromList(int64 ModifierID, bool bNeedRemove);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_PPMaterial_SetBlendableWeight(int64 ModifierID, float Weight);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_PPMaterial_SetBlendableObject(int64 ModifierID, UObject* NewObject);

	UFUNCTION(BlueprintCallable)
	int KAPI_Camera_CameraAnimation_PlayCameraAnimationAtLocation(const TArray<int>& EffectCameraTags, int64 GUID, int64 SequenceID, float PlayRate, bool bLoop, float Duration, float EaseInDuration, ECameraEaseFunction::Type EaseInType, float EaseOutDuration, ECameraEaseFunction::Type EaseOutType, const FRotator& UserPlaySpaceRot, const FVector& UserPlaySpaceLoc, int64 UserSpacePlayer, int CollisionCheckCount, bool bUseTargetScale = false, bool bUseMeshSpace = false, bool bLockOutgoing = false, bool bInAdaptiveCameraRot = false, bool bCustomPitch = false, double CustomPitch = 0.0);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_CameraAnimation_SetPause(int CameraAnimHandleHash, bool bPause);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_CameraAnimation_SetPlayRate(int CameraAnimHandleHash, float NewPlayRate);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_CameraAnimation_SetPlayAt(int CameraAnimHandleHash, float NewPct);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_CameraAnimation_SetLoop(int CameraAnimHandleHash, bool bLoop);

	UFUNCTION(BlueprintCallable)
	void KAPI_Camera_CameraAnimation_StopCameraAnimation(int CameraAnimHandleHash, bool bImmediate = false);

	UFUNCTION(BlueprintCallable)
	double KAPI_Camera_GetCameraAnimationLength(int64 CameraAnimationID);

	UFUNCTION(BlueprintImplementableEvent)
	void KCB_Camera_OnCameraAnimStartBlendOut(int64 GUID);

	UFUNCTION(BlueprintCallable)
	int64 KCB_Camera_StartCameraAIMove(const TArray<FVector>& WorldLocations, const TArray<FRotator>& WorldRotations, int SampleRate, float BlendInTime = 0.f, float BlendOutTime = 0.f, float PlayRate = 1.f);

	UFUNCTION(BlueprintCallable)
	int64 KCB_Camera_StartCameraAIMoveWithPivot(const TArray<FVector>& WorldLocations, const TArray<FRotator>& WorldRotations, const TArray<FVector>& PivotLocations, int SampleRate, float BlendInTime = 0.f, float BlendOutTime = 0.f, float PlayRate = 1.f);
	
#pragma endregion Modifier
	
#pragma region utils
public:
	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_GetCameraManagerActorID();

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_GetCameraManagerRootComponentID();
	
	// 返回第一个找到的BaseCamera
	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_GetCurrentSceneBaseCameraActor(const FString& CameraNamePattern);

	// 找对应第一个CameraComponent的父亲Actor
	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_GetCurrentSceneBaseCameraActorFromSceneActorID(int64 SceneActorID);

	UFUNCTION(BlueprintCallable)
	int64 KAPI_Camera_GetCurrentSceneBaseCameraActorFromSceneActorIDByTag(int64 SceneActorID, const FName& ComponentTag);
	
	// 跳字Scale相关
	UFUNCTION(BlueprintCallable)
	void AssignScale(int Left, int Right, float Value);

	// 跳字Scale相关
	UFUNCTION(BlueprintCallable)
	float CalScaleForDamage(int64 TargetActorID);

	UFUNCTION(BlueprintCallable)
	float GetCorrectInteractiveCameraRotAndZoom(const FVector& PosA, const FVector& PosB, const FVector& StartPos, const FRotator& InitRot, int DesiredPitch, int YawOff, int ZoomMinOff, int ZoomDesireOff, FRotator& ResultRot);

	UFUNCTION(BlueprintCallable)
	void ModifyIncreasingCurve(UCurveVector* Curve, float MinX, float MaxX, FVector MinY, FVector MaxY);
	
private:
	TChthollyTree<float> ScaleContainer = {1};
#pragma endregion
	
#pragma region CameraViewModifier
public:

#pragma endregion CameraViewModifier

public:
	UFUNCTION(BlueprintImplementableEvent)
	bool UpdateScriptGameplayDebugInfo(FString& InfoTextStr);
};

