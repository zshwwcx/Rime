﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "3C/Camera/CameraAction/CameraActionBase.h"
#include "CameraActionTurnToLock.generated.h"

/**
 * 
 */
UCLASS()
class KGCHARACTER_API UCameraActionTurnToLock : public UCameraActionBase
{
	GENERATED_BODY()
public:
	UFUNCTION(BlueprintCallable)
	void Init(int64 TargetActorID, float NewYawDemarcation, float NewWideAngleBlendTime, float NewNarrowAngleBlendTime);
	
	virtual void Play() override;
	virtual bool ProcessViewRotation(class AActor* ViewTarget, float DeltaTime, bool& bOutChangePitch, double& OutPitch, bool& bOutChangeYaw, double& OutYaw, bool& bOutChangeRoll, double& OutRoll, FRotator& OutDeltaRot) override;

	virtual bool IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType) override;

	virtual void DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode) override;

private:
	void CalDesiredRot(bool bInit);

private:
	TWeakObjectPtr<USkeletalMeshComponent> LockSKMesh;
	TWeakObjectPtr<AActor> LockActor;

	FRotator ResultRotator = FRotator::ZeroRotator;
	double CurSmoothSpeed = 0.f;
	double MaxSmoothSpeed = 1000.f;
	
	float WideAngleBlendTime = 0.f;
	float NarrowAngleBlendTime = 0.f;
	float YawDemarcation = 80;

	FVector CameraLocation = FVector::ZeroVector;
	FRotator CameraRotation = FRotator::ZeroRotator;

	float DesiredYaw = 0.f;
	float BaseYaw = 0.f;
	float LastAlpha = 0.f;
	
	static const FName CameraLookBoneName;
};
