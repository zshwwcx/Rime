#pragma once

#include "CoreMinimal.h"
#include "CollisionQueryParams.h"
#include "CollisionShape.h"
// #include "WorldCollision.h"
#include "Misc/CommonDefines.h"
#include "3C/Camera/CameraUtil/CameraUtils.h"
#include "Engine/HitResult.h"
#include "Engine/EngineTypes.h"
#include "Components/SceneComponent.h"
#include "CameraArmComponent.generated.h"

UENUM(Blueprintable)
enum EDitherFadeDetectType
{
	DitherFadeDetectNone = 0,
	//起点->终点 类圆柱形检测
	SphereRayCastDetect = 1,
	//跟随目标
	SphereDetect = 2,
};

/**
 * 相机摇臂
 * 对USpringArmComponent改造 部分逻辑后续改造成Lua
 */
UCLASS(meta=(BlueprintSpawnableComponent), hideCategories=(Mobility))
class KGCHARACTER_API UCameraArmComponent : public USceneComponent
{
	GENERATED_UCLASS_BODY()

	friend class ACameraManager;

#pragma region Base
public:
	FRotator GetControlRotation();

	//下一帧直接到插值结束的位置，跳过中间插值过程。
	UFUNCTION(BlueprintCallable)
	void MarkInstantBlend(bool bEnable);
	
	UFUNCTION(BlueprintCallable)
	void SetControlConfig(class UKgCameraMode* TargetMode);

	UFUNCTION(BlueprintCallable)
	void MarkDeActiveByMode();
	
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

	void ResetConfig();

	// UActorComponent interface
	virtual void OnRegister() override;
	virtual void OnUnregister() override;
	virtual void TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	virtual void PostLoad() override;
	// End of UActorComponent interface

	// USceneComponent interface
	virtual bool HasAnySockets() const override;
	virtual FTransform GetSocketTransform(FName InSocketName, ERelativeTransformSpace TransformSpace = RTS_World) const override;
	virtual void QuerySupportedSockets(TArray<FComponentSocketDescription>& OutSockets) const override;
	// End of USceneComponent interface

	UFUNCTION(BlueprintCallable)
	void ForceUpdate(bool bDoTrace = true);

	UFUNCTION(BlueprintCallable)
	void ForceUpdateWithBaseCollision();

	UFUNCTION(BlueprintCallable)
	void UpdateArms(float DeltaTime);

protected:
	/** Updates the desired arm location, calling BlendLocations to do the actual blending if a trace is done */
	virtual void UpdateDesiredArmLocation(bool bDoTrace, bool bDoLocationLag, bool bDoRotationLag, float DeltaTime, bool bForceUpdate = false);

public:
	UPROPERTY()
	bool bMarkInstantBlend = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bUsePawnControlRotation = true;

	/** Should we inherit pitch from parent component. Does nothing if using Absolute Rotation. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bInheritPitch = true;

	/** Should we inherit yaw from parent component. Does nothing if using Absolute Rotation. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bInheritYaw = true;

	/** Should we inherit roll from parent component. Does nothing if using Absolute Rotation. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bInheritRoll = true;

	UPROPERTY(Transient)
	TWeakObjectPtr<AActor> ControlActor;

	UPROPERTY(Transient)
	TWeakObjectPtr<AActor> LookAtTarget;

	bool bLookAtMainPlayer = false;

	static const FName SocketName;
	static const TEnumAsByte<ECollisionChannel> ProbeChannel;
	static const FCollisionShape ProbeSphereShape;
	static const float ProbeSize;

	UFUNCTION(BlueprintCallable)
	void SetSocketOffset(float X, float Y, float Z) {SocketOffset.X = X; SocketOffset.Y = Y; SocketOffset.Z = Z;}

	UFUNCTION(BlueprintCallable)
	void SetSocketOffsetByVector(const FVector& InTargetOffset) { SocketOffset = InTargetOffset;}

	UFUNCTION(BlueprintCallable)
	void SetSocketRotOffset(float Pitch, float Yaw, float Roll) {SocketRotOffset.Pitch = Pitch; SocketRotOffset.Yaw = Yaw; SocketRotOffset.Roll = Roll;}

	void SetSocketRotOffset(const FRotator& Value) { SocketRotOffset = Value; }

	UFUNCTION(BlueprintCallable)
	FRotator GetSocketRotOffset() {return SocketRotOffset;}

	UFUNCTION(BlueprintCallable)
	FVector GetOriginWorldOffset() { return OriginWorldOffset; }
	
	UFUNCTION(BlueprintCallable)
	void AddOriginWorldOffset(float X, float Y, float Z) {OriginWorldOffset.X += X; OriginWorldOffset.Y += Y; OriginWorldOffset.Z += Z;}

	UFUNCTION(BlueprintCallable)
	void AddSocketOffset(float X, float Y, float Z) {SocketOffset.X += X; SocketOffset.Y += Y; SocketOffset.Z += Z;}

	UFUNCTION(BlueprintCallable)
	void AddSocketOffsetByVector(const FVector& InDelta) { SocketOffset += InDelta;}
	
	UFUNCTION(BlueprintCallable)
	void SetSocketOffsetX(float X) {SocketOffset.X = X;}

	UFUNCTION(BlueprintCallable)
	void SetSocketOffsetY(float Y) {SocketOffset.Y = Y;}
	
	UFUNCTION(BlueprintCallable)
	void SetSocketOffsetZ(float Z) {SocketOffset.Z = Z;}

	UFUNCTION(BlueprintCallable)
	FVector GetSocketOffset() { return SocketOffset; }

	UFUNCTION(BlueprintCallable)
	float GetSocketOffsetY() { return SocketOffset.Y; }

	UFUNCTION(BlueprintCallable)
	float GetSocketOffsetZ() { return SocketOffset.Z; }

	UFUNCTION(BlueprintCallable)
	void SetTargetOffset(const FVector& NewOffset) { TargetOffset = NewOffset; }

	UFUNCTION(BlueprintCallable)
	FVector GetTargetOffset() const { return TargetOffset; }

	UFUNCTION(BlueprintCallable)
	float GetTargetOffsetZ() const { return TargetOffset.Z; }

	UFUNCTION(BlueprintCallable)
	void SetTargetOffsetZ(float NewZ) { TargetOffset.Z = NewZ; }

	UFUNCTION(BlueprintCallable)
	float GetTargetOffsetY() const { return TargetOffset.Y; }

	UFUNCTION(BlueprintCallable)
	void SetTargetOffsetY(float NewY) { TargetOffset.Y = NewY; }

	UFUNCTION(BlueprintCallable)
	float GetTargetOffsetX() const { return TargetOffset.X; }

	UFUNCTION(BlueprintCallable)
	void SetTargetOffsetX(float NewX) { TargetOffset.X = NewX; }

	UFUNCTION(BlueprintCallable)
	void SetTargetRotOffsetByRotator(const FRotator& NewRotOffset) { TargetRotOffset = NewRotOffset; }

	UFUNCTION(BlueprintCallable)
	const FVector& GetCachedPivotLocation() const { return CachedPivotLocation; }

	UFUNCTION(BlueprintCallable)
	const FVector& GetCachedPivotLocationAfterOffset() const { return CachedPivotLocationAfterOffset; }

	UFUNCTION(BlueprintCallable)
	const FVector& GetCachedArmOrigin() const { return CachedArmOrigin; }

	UFUNCTION(BlueprintCallable)
	const FRotator& GetCachedPivotRotation() const { return CachedPivotRotation; }

	UFUNCTION(BlueprintCallable)
	const FVector& GetPreviousResultLoc() const { return PreviousResultLoc; }

	UFUNCTION(BlueprintCallable)
	const FVector2D& GetScreenOffset() const { return ScreenViewOffset; }

	UFUNCTION(BlueprintCallable)
	const FVector& GetCachedSpeed() const { return CachedSpeed; }

	UFUNCTION(BlueprintCallable)
	const FVector& GetCachedTargetSpeed() const { return CachedTargetSpeed; }

	UFUNCTION(BlueprintCallable)
	const FVector& GetCachedArmOriginAfterLag() const { return CachedArmOriginAfterLag; }

	UFUNCTION(BlueprintCallable)
	const FVector& GetCachedArmOriginAfterRadius() const { return CachedArmOriginAfterRadius; }

protected:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Camera)
	FVector SocketOffset = FVector::ZeroVector;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Camera)
	FRotator SocketRotOffset = FRotator::ZeroRotator;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Camera)
	FVector TargetOffset = FVector::ZeroVector;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Camera)
	FVector OriginWorldOffset = FVector::ZeroVector;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Camera)
	FRotator TargetRotOffset = FRotator::ZeroRotator;

	FVector PreviousResultLoc = FVector::ZeroVector;

	FVector RelativeSocketLocation = FVector::ZeroVector;
	FQuat RelativeSocketRotation = FQuat::Identity;

	float RealArmLen = 0;
	FVector PreviousDesiredLoc = FVector::ZeroVector;

	TWeakObjectPtr<class UKgCameraMode> CurActivateMode = nullptr;

	FCollisionQueryParams QueryParams{SCENE_QUERY_STAT(CameraAIMove), false};

	FRotator CachedPivotRotation = FRotator::ZeroRotator;
	FVector CachedPivotLocation = FVector::ZeroVector;
	FVector CachedPivotLocationAfterOffset = FVector::ZeroVector;
	FVector CachedArmOrigin = FVector::ZeroVector;
	FVector CachedSpeed = FVector::ZeroVector;
	FVector CachedTargetSpeed = FVector::ZeroVector;
	FVector CachedArmOriginAfterLag = FVector::ZeroVector;
	FVector CachedArmOriginAfterRadius = FVector::ZeroVector;
#pragma endregion Base

	
#pragma region Lag
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Lag, AdvancedDisplay)
	bool bUseCameraLagSubstepping = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Lag, AdvancedDisplay, meta=(editcondition = "bUseCameraLagSubstepping", ClampMin="0.005", ClampMax="0.5", UIMin = "0.005", UIMax = "0.5"))
	float CameraLagMaxTimeStep = 0.005f;
	
#pragma endregion Lag


#pragma region RotationLag
public:
	UFUNCTION(Blueprintable, Category = LocationLag)
	void SetRotationLagParam(float Param);

	UFUNCTION(Blueprintable, Category = RotationLag)
	void InitRotationLagParam(bool bNewEnableCameraRotationLag, ECameraEaseFunction::Type EaseType, float Param, int64 CurveID);

protected:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = RotationLag)
	bool bEnableCameraRotationLag = true;

	FCameraInterpolationParam<FQuat> CameraRotationEaseParam;

#pragma endregion RotationLag 


#pragma region LocationLag
public:
	UFUNCTION(Blueprintable, Category = LocationLag)
	void InitLocationLagParamForXOY(ECameraEaseFunction::Type EaseType, float Param, int64 CurveID, float NewSoftZoneRadiusXOY);
	
	UFUNCTION(Blueprintable, Category = LocationLag)
	void SetLocationLagParamForXOY(float Param);
	
	UFUNCTION(Blueprintable, Category = LocationLag)
	void InitLocationLagParamForZ(ECameraEaseFunction::Type EaseType, float Param, int64 CurveID, float NewSoftZoneRadiusZ);

	UFUNCTION(Blueprintable, Category = LocationLag)
	void SetLocationLagParamForZ(float Param);

	UFUNCTION(Blueprintable, Category = LocationLag)
	void SetLocationSoftRadiusParamForXOY(float Param);
	
	UFUNCTION(Blueprintable, Category = LocationLag)
	void SetLocationSoftRadiusParamForZ(float Param);

protected:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = LocationLag)
	bool bEnableCameraLag = true;

	FCameraInterpolationParam<FVector> CameraLocationEaseParam;
	FVector LagLocation = FVector::ZeroVector;
	FCameraInterpolationParam<float> CameraLocationEaseParamZ;

	float SoftZoneRadiusXOY = 0.f;
	float SoftZoneRadiusZ = 0.f;

#pragma endregion LocationLag


#pragma region ArmLengthLerp
public:
	UFUNCTION(BlueprintCallable)
	void InitArmLagParam(ECameraEaseFunction::Type EaseType, float Param, int64 CurveID);

	UFUNCTION(BlueprintCallable)
	void SetZoomSetting(float Min, float Max, bool bFix = false);

	UFUNCTION(BlueprintCallable)
	virtual void OnUpdateZoom(float Target, bool bImmediate = false);

	UFUNCTION(BlueprintCallable)
	void ManualSetZoom(float InZoom);
	
	UFUNCTION(BlueprintCallable)
	void SetOverrideZoom(float CurZoom);

	UFUNCTION(BlueprintCallable)
    void SetZoomOffset(float Target);

	// 在允许zoom内部插值时为目标Zoom，不允许时为当前Zoom
	UFUNCTION(BlueprintCallable)
	float GetTargetCameraZoomLen();

	// 始终返回当前Zoom
	UFUNCTION(BlueprintCallable)
	float GetCameraCurrentBaseZoomLen();

	UFUNCTION(BlueprintCallable)
	float GetCameraCurrentZoomLen();

	UFUNCTION(BlueprintCallable)
	float GetCameraCachedBaseArmLen();

	UFUNCTION(BlueprintCallable)
	float GetZoomMax() const {return MaxZoom; }  

	UFUNCTION(BlueprintCallable)
	float GetZoomMin() const {return MinZoom; }  

	UFUNCTION(BlueprintCallable)
	float GetRealCameraArmLen() const;

	UFUNCTION(BlueprintCallable)
	FVector2D GetCameraXYZLagParam() const;

	UFUNCTION(BlueprintCallable)
    void SetCameraXYZLagParam(const FVector2D& NewXYZLag);

protected:
	FCameraInterpolationParam<float> TargetArmLength;

	float OverrideZoom = -1.f;

	float MinZoom = 0;

	float MaxZoom = 0;

	float ArmZoomOffset;

	float CurArmLength;
	float CachedBaseArmLength;

	TWeakObjectPtr<class ABasePlayerController> PC = nullptr;
	TWeakObjectPtr<class ACameraManager> CameraMgr = nullptr;
	TWeakObjectPtr<class UCameraComponent> CameraOwner = nullptr;
	TWeakObjectPtr<class AActor> CameraActorOwner = nullptr;

#pragma endregion ArmLengthLerp


#pragma region ScreenViewOffset
public:
	UFUNCTION(BlueprintCallable)
	void SetPivotOffsetFromScreenCoOffset(float OffX, float OffY);

	FVector2D GetPivotOffsetFromScreenCoOffset() const { return ScreenViewOffset; }
	
	FVector GetRelativeCachedPivotOffset() const { return RelativeCachedPivotOffset; }
	float GetCachedPivotOffsetZ() const { return PivotOffsetForScreenCoOff.Z; }

protected:
	virtual void UpdatePivotOffsetFromScreenCoOffset(FVector& DesiredLoc, const FRotator& CamRot, float ArmLen, float TimeDelta);

protected:
	FVector PivotOffsetForScreenCoOff = FVector::ZeroVector;
	FVector RelativeCachedPivotOffset = FVector::ZeroVector;
	FVector2D ScreenViewOffset;

#pragma endregion ScreenViewOffset


#pragma region Collision
public:
	UFUNCTION(BlueprintCallable)
	FVector GetUnfixedCameraPosition() const;

	UFUNCTION(BlueprintCallable)
	bool IsCollisionFixApplied() const;

	UFUNCTION(BlueprintCallable)
	void InitCollisionReleaseLagParam(ECameraEaseFunction::Type EaseType, float Param, int64 CurveID);

	UFUNCTION(BlueprintCallable)
	void InitCollisionCompressLagParam(ECameraEaseFunction::Type EaseType, float Param, int64 CurveID);

	UFUNCTION(BlueprintCallable)
	void EnableNewCollision(bool bEnable, const TArray<int>& NewCollisionDetectTypes);

protected:
	FVector BlendCollisionLocations(const FVector& ArmOrigin, const FVector& DesiredArmLocation,
	                                const FVector& TraceHitLocation, bool bHitSomething, bool bDoLocationLag,
	                                float DeltaTime);
	
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=CameraCollision)
	bool bDoCollisionTest = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=CameraCollision)
	bool bNewCollision = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Overlap)
	TEnumAsByte<ECollisionChannel> HideMeshCollisionChannel = ECollisionChannel::ECC_GameTraceChannel2;
	
	UPROPERTY(Transient)
	float PreviousHitBlendLength = 0.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Transient)
	float WaterHeightCorrect = 0.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Transient)
	bool bWaterCollision = false;

	FCameraInterpolationParam<float> CollisionSpringReleaseParam;
	FCameraInterpolationParam<float> CollisionSpringCompressParam;

protected:
	bool bIsCameraFixed = false;
	bool bIsHitReleaseComplete = true;
	bool bIsPreviousBlockingHit = false;
	FVector UnfixedCameraPosition = FVector::ZeroVector;
	TArray<TEnumAsByte<EObjectTypeQuery>> CollisionDetectTypes;
	FCollisionObjectQueryParams NewCollisionDetectQueryParam;
	TArray<FHitResult> HitResults;
	TArray<FHitResult> SelfHitResults;
	
#pragma endregion RotationLag


#pragma region PostProcess
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera | PostProcess | DitherFade")
	uint8 DitherFadeDetectType = 1;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera | PostProcess | DitherFade")
	float DitherFadeDetectRadius = 50.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera | PostProcess | DitherFade")
	float DitherFadeDetectPitch = 45.f;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera | PostProcess | DitherFade")
	bool bEnableDitherFade = false;

	bool bEnableGlobalDitherFade = false;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera | PostProcess | DitherFade")
	TArray<TEnumAsByte<EObjectTypeQuery>> DitherFadeObjectTypes;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera | PostProcess | DitherFade")
	TArray<TEnumAsByte<EObjectTypeQuery>> DitherFadeObjectTypesForStatic;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera | PostProcess | DitherFade")
	TArray<TEnumAsByte<EObjectTypeQuery>> DitherFadeObjectTypesForDynamic;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera | PostProcess | DitherFade")
	float DitherStaticDetectInterval = -1.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera | PostProcess | DitherFade")
	float DitherDynamicDetectInterval = -1.f;

	TSet<int64> DetectDitherComponentsForStatic;

	TSet<int64> DetectDitherComponentsForDynamic;

	TMap<KGObjectID, TWeakObjectPtr<AActor>> DitherComponentToActorForStatic;
	TMap<KGObjectID, TWeakObjectPtr<AActor>> DitherComponentToActorForDynamic;

	bool bMainPlayerPitchDitherFade = false;
	int bMainPlayerDistanceDitherFade = 0;
	
	UFUNCTION(BlueprintCallable, Category = "Camera | PostProcess | DitherFade")
	void EnableDitherFade(bool bEnable, const TArray<int>& NewDitherFadeObjectTypesForStatic, const TArray<int>& NewDitherFadeObjectTypesForDynamic, int DetectType = 1, float Radius = 1.f, float InDetectPitch = 0.f, float StaticDetectInterval = 0.2f, float DynamicDetectInterval = 0.2f, float InCameraDiffThreshold = 5.f);

	void EnableGlobalDitherFade(bool bEnable);
	
	void PostProcess(float DeltaTime, const FVector& CameraStartPos, const FVector& CameraEndPos, float CamPitch);

	// void OnDitherFadeQueryFinished(const FTraceHandle& Handle, FOverlapDatum& OverlapDatum);
	
private:
	FCollisionShape CollisionShape;
	FCollisionQueryParams CollisionQueryParams;
	float TimeSinceLastStaticDitherDetect = 0.f;
	float TimeSinceLastDynamicDitherDetect = 0.f;
	float CameraPosDiffThreshold = 0.f;
	bool bHasPlayerInput = false;
	bool bNeedDitherStatic = false;

	// FTraceHandle QueryHandle;
	// FOverlapDelegate DitherFadeQueryDelegate;
#pragma endregion PostProcess
};
