#pragma once

#include "3C/Camera/PostProcessNew/PostProcessInstance/PPNonMaterialBase.h"

class UTexture;

class KGPPColorGradingMisc : public KGPPNonMaterialBase
{
public:

	void InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType,
		const FPostProcessSettings& InPostProcessSettings, const FString& InColorGradingLUTPath);

	virtual bool OnTaskStart() override;
	virtual void OnTaskEnd(EKGPostProcessStopReason StopReason) override;
	virtual bool CanOutputPostProcess() const override;
	
protected:

	void OnColorGradingLUTTextureLoaded(int InLoadID, UObject* Asset);

	uint32 AssetLoadID = 0;
	FString ColorGradingLUTPath;
	TStrongObjectPtr<UTexture> ColorGradingLUTTexture;
};
