﻿#pragma once
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPNonMaterialBase.h"

class KGPPPhotoWhiteTemp : public KGPPNonMaterialBase
{
public:
	void InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType, const FString& WhiteTempCurvePath);
	virtual void SetManualWeightCurveValue(float Weight) override;

protected:
	int32 WhiteTempID = 0;
};

