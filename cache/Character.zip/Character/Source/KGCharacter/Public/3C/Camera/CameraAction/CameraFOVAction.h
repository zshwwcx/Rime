// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "3C/Camera/CameraAction/CameraActionBase.h"
#include "CameraFOVAction.generated.h"

/**
 * 
 */
UCLASS()
class KGCHARACTER_API UCameraFOVAction : public UCameraActionBase
{
	GENERATED_BODY()

public:
	void Init(float FOV, float FOVOffset, bool bInRecover, float InBlendInTime, float InBlendOutTime, float InDuration, ECameraEaseFunction::Type InBlendInType, ECameraEaseFunction::Type InBlendOutType, int64 InBlendInCurve, int64 InBlendOutCurve);

	virtual void Play() override;

	virtual void ModifyCamera(float DeltaTime) override;
	
	virtual void Abort() override;
	
	virtual void DoWhenEffectModeActivate(UKgCameraMode* ActivateCameraMode) override;
	
	virtual bool IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType) override { return false; };

private:
	void InitParams();

private:
	float TargetFOV = 0.f;
	float FOVBase = 0.f;

	float TargetFOVOffset = 0.f;
	float FOVOffsetBase = 0.f;
};
