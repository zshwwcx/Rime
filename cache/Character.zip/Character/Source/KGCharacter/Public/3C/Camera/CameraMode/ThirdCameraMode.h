#pragma once

#include "CoreMinimal.h"
#include "3C/Camera/KgCameraMode.h"

#include "ThirdCameraMode.generated.h"


UCLASS(BlueprintType, Blueprintable)
class KGCHARACTER_API UThirdCameraModeBase : public UKgCameraMode
{

	GENERATED_UCLASS_BODY()

public:
	
};