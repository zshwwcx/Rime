#pragma once

#include "CoreMinimal.h"
#include "Tickable.h"
#include "3C/Camera/CameraArmComponent.h"
#include "Camera/CameraActor.h"
#include "BaseCamera.generated.h"

/**
 * 摄像机基类
 * 具体摄像机在Lua中添加组件
 * 
 */
UCLASS()
class KGCHARACTER_API ABaseCamera : public ACameraActor
{
	friend class ACameraManager;

	GENERATED_UCLASS_BODY()

public:
	void Tick(float DeltaSeconds);

	void TickCamera(float DeltaSeconds);
	
	//设置关联目标
	UFUNCTION(BlueprintCallable)
	void SetControlledTarget(AActor* Target);

	UFUNCTION(BlueprintCallable)
	void SetLookAtTargetByID(int64 TargetID);
	
	UFUNCTION(BlueprintCallable)
	void SetLookAtTarget(AActor* InTargetActor, AActor* ControlActor, const FName& NewBoneName, const FVector& Offset, ERelativeTransformSpace InTransformSpace = ERelativeTransformSpace::RTS_Actor);

	UFUNCTION(BlueprintCallable)
	AActor* GetLookAtTarget();

	void SetBoneOffset(const FVector& Offset, ERelativeTransformSpace InTransformSpace = ERelativeTransformSpace::RTS_Actor);

	void SetBoneOffsetZ(float NewZ);

	float GetBoneOffsetZ() const { return BoneOffset.Z; }
	
	UFUNCTION(BlueprintCallable)
	AActor* GetControlledTarget() const  { return TargetActor.IsValid() ? TargetActor.Get() : nullptr; };
	
	UFUNCTION(BlueprintCallable)
	void SetArmUsingAbsoluteRotation(bool bInAbsoluteRotation);

	UFUNCTION(BlueprintCallable)
	UCameraComponent* GetCameraCom() const { return GetCameraComponent(); }

	UFUNCTION(BlueprintCallable)
	UCameraArmComponent* GetCameraArmComponent() const { return CameraArmComponent; }

	UFUNCTION(BlueprintCallable)
	void SetControlConfig(class UKgCameraMode* TargetMode);

	UFUNCTION(BlueprintCallable)
	virtual void ResetConfig();

	class UKgCameraMode* GetCurActivateMode() const;

	bool IsLinkedTarget() const;

	UFUNCTION(BlueprintCallable)
	FVector GetCameraLocation();

	UFUNCTION(BlueprintCallable)
	FRotator GetCameraRotation();
	
	UFUNCTION(BlueprintCallable)
	void LookUp_Axis(float Value);
	
	UFUNCTION(BlueprintCallable)
	void Turn_Axis(float Value);

	UFUNCTION(BlueprintCallable)
	void ForceUpdateCamera(bool bDoTrace = true);

	UFUNCTION(BlueprintCallable)
	void ForceUpdateCameraWithBaseCollision();

	UFUNCTION(BlueprintCallable)
	void EnableCameraTick(bool bEnable);

	// 只是用目标骨骼的Z轴位置 XY用Actor坐标
	UFUNCTION(BlueprintCallable)
	void SetOnlyUseBoneLocationZ(bool bEnable) { bOnlyUseBoneZ = bEnable; };
	
	// 手动移动前请调用一次来初始化目标位置
	UFUNCTION(BlueprintCallable)
	void InitManualMove(bool bEnable, bool bLimitRot = false, float NewPitchMin = -60.f, float NewPitchMax = 60.f, float NewYawMin = -179.99f, float NewYawMax = 180.f);

	UFUNCTION(BlueprintCallable)
	void InitLimitRot(bool bLimitRot = false, float NewPitchMin = -60.f, float NewPitchMax = 60.f, float NewYawMin = -179.99f, float NewYawMax = 180.f);

	UFUNCTION(BlueprintCallable)
	void InitLimitPitchRot(bool bLimitRot = false, float NewPitchMin = -60.f, float NewPitchMax = 60.f);
	
	UFUNCTION(BlueprintCallable)
	void Move_X(float Value, bool bLimit = false);

	UFUNCTION(BlueprintCallable)
	void Move_Y(float Value, bool bLimit = false);

	UFUNCTION(BlueprintCallable)
	void Move_Z(float Value, bool bLimit = false);
	
	UFUNCTION(BlueprintCallable)
	void Move_ZToXOY(float Value, bool bLimit = false);

	UFUNCTION(BlueprintCallable)
    void SetCameraFOV(float NewFOV);

	UFUNCTION(BlueprintCallable)
	float GetCameraFOV();

	UFUNCTION(BlueprintCallable)
	void MarkDeActiveByMode();

	// 定制给追逐镜头使用 按照当前lookat对象的曲线移动调整相机
	UFUNCTION(BlueprintCallable)
	void InitFollowLookAtSpineMove();

	UFUNCTION(BlueprintCallable)
	void CancelFollowLookAtSpineMove();

	UFUNCTION(BlueprintCallable)
	void SetCameraFollowLookAtSplineMoveLocation(const FVector& Loc) { FollowSplineMoveLocation = Loc; };

	UFUNCTION(BlueprintCallable)
	void RemoveLookAtBoneRemainOffset();
	
	bool HasRotationInput() const { return bHasRotationInput; }

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

protected:
	UPROPERTY(Transient, VisibleAnywhere, BlueprintReadWrite)
	TObjectPtr<UCameraArmComponent> CameraArmComponent = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Camera)
	FVector BoneOffset = FVector::Zero();

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Camera)
	FName LookAtBoneName = NAME_None;

	ERelativeTransformSpace TransformSpace = ERelativeTransformSpace::RTS_Actor;

	FVector PreviousCameraLocation = FVector::ZeroVector;
	
	TWeakObjectPtr<class UKgCameraMode> CurActivateMode;

	TWeakObjectPtr<AActor> TargetActor;

	TWeakObjectPtr<AActor> LookAtTarget;

	FVector TargetLoc = FVector::ZeroVector;
	bool bManualControl = false;
	bool bOnlyUseBoneZ = false;
	bool bLimitedYawRot = false;
	bool bLimitedPitchRot = false;
	float PitchMin = -89.9f;
	float PitchMax = -30.f;
	float YawMax = 180.f;
	float YawMin = -179.999;

	bool bSplineControl = false;
	FVector FollowSplineMoveLocation = FVector::ZeroVector;

	FRotator RotationInput = FRotator::ZeroRotator;
	bool bHasRotationInput = false;

private:
	TUniquePtr<class FCameraProxyTickableObject> CameraTickProxy;
};

// 相机位置更新依赖RoleMovement LateUpdate RoleMovement依赖动画更新 可能导致 大家都是PostPhysics Camera强顺序依赖 因此挪至TickableObject
class FCameraProxyTickableObject : public FTickableGameObject
{
public:
	TWeakObjectPtr<ABaseCamera> Camera;
	bool bCanCameraTick = false;

	FCameraProxyTickableObject(ABaseCamera* CameraToTick): Camera(CameraToTick)
	{
	}

	virtual TStatId GetStatId() const override
	{
		RETURN_QUICK_DECLARE_CYCLE_STAT(FCameraProxyTickableObject, STATGROUP_Tickables);
	}

	//Make sure it always ticks, otherwise we can miss recording, in particularly when time code is always increasing throughout the system.
	virtual ETickableTickType GetTickableTickType() const override { return ETickableTickType::Conditional; }

	virtual bool IsTickableInEditor() const override
	{
		return true;
	}

	virtual bool IsTickable() const override { return bCanCameraTick && FTickableGameObject::IsTickable(); };
	
	virtual UWorld* GetTickableGameObjectWorld() const override
	{
		return Camera.IsValid() ? Camera->GetWorld() : nullptr;
	}

	virtual void Tick(float DeltaTime) override
	{
		if (ABaseCamera* CameraPtr = Camera.Get())
		{
			CameraPtr->Tick(DeltaTime);
		}
	}
};