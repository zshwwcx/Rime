// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Shakes/WaveOscillatorCameraShakePattern.h"
#include "Curves/CurveFloat.h"
#include "WaveOscillatorCameraShakePatternV2.generated.h"

class ABaseCamera;
class ACameraActor;
class ACameraManager;
/**
 * 
 */
UCLASS(meta = (DisplayName = "波振荡器摄像机晃动模式V2"))
class KGCHARACTER_API UWaveOscillatorCameraShakePatternV2 : public UWaveOscillatorCameraShakePattern
{
	GENERATED_BODY()

public:
	void SetArmLen(float InArmLen);
	bool IsUsePivotRotation() const { return bUsePivotRotation; }

	void SetCameraMgr(ACameraManager* CameraMgrPtr);

protected:
	TWeakObjectPtr<ACameraManager> CameraMgrOwner;
	float ArmLen = 0.f;

private:

	using ECameraShakeUpdateResultFlags = ECameraShakePatternUpdateResultFlags;
	using FCameraShakeStartParams = FCameraShakePatternStartParams;
	using FCameraShakeUpdateParams = FCameraShakePatternUpdateParams;
	using FCameraShakeScrubParams = FCameraShakePatternScrubParams;
	using FCameraShakeStopParams = FCameraShakePatternStopParams;
	using FCameraShakeUpdateResult = FCameraShakePatternUpdateResult;
	
	// UCameraShakePattern interface
	virtual void StartShakePatternImpl(const FCameraShakeStartParams& Params) override;
	virtual void UpdateShakePatternImpl(const FCameraShakeUpdateParams& Params, FCameraShakeUpdateResult& OutResult) override;
	virtual void ScrubShakePatternImpl(const FCameraShakeScrubParams& Params, FCameraShakeUpdateResult& OutResult) override;
	virtual void TeardownShakePatternImpl()  override;

	void UpdateOscillatorsV2(float DeltaTime, FCameraShakeUpdateResult& OutResult, const FMinimalViewInfo& POV);

	float GetNormalBlendInCurveValue(float Ratio) const;
	float GetNormalBlendOutCurveValue(float Ratio) const;
private:

	/** Initial sinusoidal offset for location oscillation. */
	FVector3f InitialLocationOffset;
	/** Current sinusoidal offset for location oscillation. */
	FVector3f CurrentLocationOffset;

	/** Initial sinusoidal offset for rotation oscillation. */
	FVector3f InitialRotationOffset;
	/** Current sinusoidal offset for rotation oscillation. */
	FVector3f CurrentRotationOffset;

	/** Initial sinusoidal offset for FOV oscillation */
	float InitialFOVOffset;
	/** Current sinusoidal offset for FOV oscillation */
	float CurrentFOVOffset;

	UPROPERTY(EditAnywhere, meta=(AllowPrivateAccess))
	uint8 bUsePivotRotation : 1;

	UPROPERTY(EditAnywhere, meta=(AllowPrivateAccess))
	bool bUseBlendInCurve;
	
	UPROPERTY(EditAnywhere, meta=(AllowPrivateAccess, EditCondition=bUseBlendInCurve, EditConditionHides))
	FRuntimeFloatCurve BlendInCurve;

	UPROPERTY(EditAnywhere, meta=(AllowPrivateAccess))
	bool bUseBlendOutCurve;
	
	UPROPERTY(EditAnywhere, meta=(AllowPrivateAccess, EditCondition=bUseBlendOutCurve, EditConditionHides))
	FRuntimeFloatCurve BlendOutCurve;
};
