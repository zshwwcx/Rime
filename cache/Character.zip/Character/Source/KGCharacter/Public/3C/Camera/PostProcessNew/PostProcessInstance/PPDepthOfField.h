#pragma once
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPNonMaterialBase.h"

class KGPPDepthOfField : public KGPPNonMaterialBase
{
public:

	void InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType,
		const FKGDepthOfFieldParams& InDepthOfFieldParams);

	virtual bool OnTaskStart() override;
	virtual void OnTaskTick(float DeltaTime) override;
	
	virtual FString GetDebugInfo() const override;

protected:

	TWeakObjectPtr<APlayerCameraManager> CameraManager;
	bool bIsMobile = false;
	FKGDepthOfFieldParams DepthOfFieldParams;
};

