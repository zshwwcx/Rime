﻿#pragma once
#include "3C/Camera/PostProcessNew/PostProcessInstance/PPMaterialBase.h"

class KGPPMaterialBlackFog : public KGPPMaterialBase
{
public:
	void InitParams(const FKGPPCommonParams& CommonParams, EKGPostProcessType InPPType, const FString& InMaterialPath, const FString& InPlaneMeshMaterialPath,
		int32 InViewPriority, const FName& InIntensityParamName, const FKGPPMaterialParams& InParams, TWeakObjectPtr<UPostProcessManager> InPPManager,
		const FKGFogParams& InFogParams);
	
	void UpdateBlackFogParams(
		float BlendTime, bool bOverrideCenterPos, const FVector& CenterPos,
		bool bOverrideFogOpacity, float FogOpacity, bool bOverrideFogColor, const FLinearColor& FogColor,
		bool bOverrideSmoothDist, float SmoothDistInMeters, EKGFogShapeType ShapeType, float CircleRadius, float RingPercent, float RingOuterRadius,
		float CrossLength, float CrossWidth, float HalfFieldWidth, bool bOverrideRangeSpawnRotation, float RangeSpawnRotation);

	virtual void OnTaskEnd(EKGPostProcessStopReason StopReason) override;
	
private:
	void OnOpacityReachZero();
	
	EKGFogShapeType CurShapeType = EKGFogShapeType::Circle;
	FKGFogParams FogParams;
	FTimerHandle OpacityReachZeroTimerHandle;
};
