#pragma once

#include "CoreMinimal.h"
#include "CineCameraComponent.h"
#include "3C/Camera/BaseCamera.h"
#include "BaseCineCamera.generated.h"

/**
 * 摄像机基类
 * 具体摄像机在Lua中添加组件
 * 
 */
UCLASS()
class KGCHARACTER_API ABaseCineCamera : public ABaseCamera
{
	friend class ACameraManager;

	GENERATED_UCLASS_BODY()

public:
	UCineCameraComponent* GetCineCameraComponent();
};