#pragma once

#include "CoreMinimal.h"
#include "3C/Camera/BaseCamera.h"
#include "3C/Camera/CameraAction/CameraActionBase.h"
#include "CameraViewOffsetEffect.generated.h"


UCLASS( BlueprintType, Blueprintable)
class KGCHARACTER_API UCameraViewOffsetEffect : public UCameraActionBase
{
	GENERATED_BODY()

public:
	void ModifyParams(float CoordX, float CoordY, float InBlendInTime);

	void Init(float CoordX, float CoordY, float InBlendInTime, float InBlendOutTime, ECameraEaseFunction::Type InBlendInType, ECameraEaseFunction::Type InBlendOutType, int64 InBlendInCurve, int64 InBlendOutCurve);

	virtual void ModifyViewPOV(float DeltaTime, struct FMinimalViewInfo& InOutPOV) override;

	virtual void Play() override;

	virtual void Abort() override;

	virtual bool IsNeedDeActiveWhenManualControl(ECameraManualControlType::Type ControlType) override { return false; }

	virtual void DisableAction(bool bImmediate) override;
public:
	FVector2D FocusScreenCoord = FVector2D::ZeroVector;
	FRotator LastRotationDelta = FRotator::ZeroRotator;
	FRotator RotationBase = FRotator::ZeroRotator;
	float RotationDeltaInterpDelta = -1;

	TWeakObjectPtr<APlayerController> PlayerController;
};





