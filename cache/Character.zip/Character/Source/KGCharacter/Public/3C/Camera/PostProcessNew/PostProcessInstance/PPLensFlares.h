#pragma once

#include "3C/Camera/PostProcessNew/PostProcessInstance/PPNonMaterialBase.h"

class UTexture;

class KGPPLensFlares : public KGPPNonMaterialBase
{
public:
	void InitParams(const FKGPPCommonParams& CommonParams, TWeakObjectPtr<UPostProcessManager> InPPManager, EKGPostProcessType InPPType,
		const FPostProcessSettings& InPostProcessSettings, const FString& InLensFlareBokehShapePath);

	virtual bool OnTaskStart() override;
	virtual void OnTaskEnd(EKGPostProcessStopReason StopReason) override;
	virtual bool CanOutputPostProcess() const override;
	
protected:

	void OnLensFlareBokehShapeTextureLoaded(int InLoadID, UObject* Asset);

	uint32 AssetLoadID = 0;
	FString LensFlareBokehShapePath;
	TStrongObjectPtr<UTexture> LensFlareBokehShapeTexture;
};
