﻿#pragma once
#include "CoreMinimal.h"
#include "Misc/CommonDefines.h"
#include "Containers/Union.h"
#include "TypeDefines/LuaTypes.h"
#include "UObject/WeakInterfacePtr.h"

#include "TargetSelectUtils.generated.h"

class ACameraManager;
class UKGDataCacheManager;
class UKGUEActorManager;
class UKGCombatSettingsManager;
class ICppEntityInterface;

UENUM()
enum class EKGFactionType : uint32
{
	None = 0,           // 全体(不筛选)
	TeamMate = 2,       // 小队队友(友方阵营)
	GroupMate = 4,      // 团队队友(友方阵营)
	Allies = 8,         // 联盟盟友(友方阵营)
	Neutral = 16,       // 中立
	Enemy = 32,         // 敌对

	Self = 1,           // 即相同的始作俑者(Same Root)
	SelfExclusive = 64, //-@deprecated
	SelfSibling = 128,  // 同一父节点下的所有子节点 (Same Parent)
};

enum class EKGInputTransType : uint8
{
	CenterTrans = 1,
	SelfTrans = 2,
};

struct FKGTargetSelectParamsSimple
{
	TWeakInterfacePtr<ICppEntityInterface> BaseEntity;
	// staticBlackboard上的lock target 需要外部主动传入
	TWeakInterfacePtr<ICppEntityInterface> TargetEntity;
	
	TOptional<FVector> CenterPos;
	TOptional<float> Yaw;
	TOptional<FVector> SearchPos;
	KGEntityID SearchTargetID = KG_INVALID_ENTITY_ID;
	TOptional<FVector> InputPos;
	TOptional<float> InputYaw;
	uint32 SkillID = 0;
	
	// 激光特效技能定制
	TOptional<EKGTargetSelectCoordinateType> OverrideCoordinateType;
	TOptional<float> OverrideClockwiseRotation;
	TOptional<FVector> OverrideCoordinateOffset;
	
	bool bIsEditor = false;
	// 从lua端发起的target select会执行condition过滤, 因此绘制都从lua端过滤完以后再回到cpp执行
	bool bDrawQueryResults = true;
};

struct FKGTargetSelectParams
{
	FKGTargetSelectParams() {}
	FKGTargetSelectParams(const FKGTargetSelectParamsSimple& InParams);

	TWeakInterfacePtr<ICppEntityInterface> BaseEntity;
	// staticBlackboard上的lock target 需要外部主动传入
	TWeakInterfacePtr<ICppEntityInterface> TargetEntity;
	
	// 确定基准位置和朝向
	TOptional<FVector> CenterPos;
	TOptional<float> Yaw;
	TOptional<FVector> SearchPos;
	KGEntityID SearchTargetID = KG_INVALID_ENTITY_ID;
	TOptional<FVector> InputPos;
	TOptional<float> InputYaw;
	uint32 SkillID = 0;
	
	// 形状参数
	FKGSearchRangeParams SearchRangeParams;
	
	// 筛选参数
	// MaxNum的含义
	// 0 或者 大于AOE筛选最大值: 使用AOE筛选最大值
	// 小于0, 不进行数量层面限制
	FKGSearchTargetParams SearchTargetParams;
	int32 MaxNum = 0;
	
	// 排序参数
	EKGTargetSortStrategy SortStrategy = EKGTargetSortStrategy::None;
	bool bDistanceSortUseIncOrder = false;
	
	// 其他参数
	bool bIsEditor = false;
	// 从lua端发起的target select会执行condition过滤, 因此绘制都从lua端过滤完以后再回到cpp执行
	bool bDrawQueryResults = true;
	uint32 BackupRuleID = 0;
	EKGTargetSelectBackupMode BackupMode = EKGTargetSelectBackupMode::UseNewSelectRule;
	uint32 BackupSearchReentranceNum = 0; 
	
	// 其他参数
	TOptional<EKGTargetSelectCoordinateType> OverrideCoordinateType;
	TOptional<float> OverrideClockwiseRotation;
	TOptional<FVector> OverrideCoordinateOffset;
};

struct FKGTargetSelectResult
{
	TArray<KGEntityID> EntityIDs;
	TArray<KGEntityID> OtherEntityIDs;
	
	// 由于目前用到了基于血量进行排序, 但是血量变化非常频繁, 不太好同步到cpp
	// 因此如果排序规则是基于血量进行排序的话, 则需要在返回lua层进行排序
	bool bSortDone = true;
	uint32 MaxNumUsed = 0;
};

// 计算目标筛选逻辑的辅助数据结构, 避免一些数据重复计算
struct FKGTargetSelectContext
{
	bool Initialize();
	FString GetDebugInfo() const;
	ICppEntityInterface* GetBaseEntityInstigator();
	ACameraManager* GetCameraManager();
	APlayerController* GetPlayerController();
	AActor* GetMainPlayerActor();
	
	FKGTargetSelectParams TargetSelectParams;
	// 这里是根据传入的最大数量确定的当前目标筛选的最大数量
	int32 MaxNumUsed = -1;
	
	TSet<KGEntityID> AllEntityIDSet;
	TWeakObjectPtr<AActor> BaseActor;
	TWeakObjectPtr<AActor> TargetActor;
	
	TWeakInterfacePtr<ICppEntityInterface> BaseEntityInstigator;
	TWeakInterfacePtr<ICppEntityInterface> TargetEntityInstigator;
	
	TWeakObjectPtr<UKGCombatSettingsManager> CombatSettingsManager;
	TWeakObjectPtr<UKGUEActorManager> ActorManager;
	TWeakObjectPtr<UKGDataCacheManager> DataCacheManager;
	TWeakObjectPtr<ACameraManager> CamaraManager;
	TWeakObjectPtr<APlayerController> PlayerController;
	TWeakObjectPtr<AActor> MainPlayerActor;
};

class KGCHARACTER_API TargetSelectorUtils
{
public:
	/**
	 * 1, 客户端目前目标筛选必须有主角参与(主角作为BaseActor去筛选别的目标单位, 或者别的目标单位筛选主角, 否则阵营筛选会出问题)
	 * 2, 当前一些基于血量的排序规则暂时未在cpp层实现, 如果有类似需求, 只能调用lua层接口发起目标筛选, 如果直接从cpp中发起目标筛选, 相应筛选规则无法生效
	 */
	static bool QueryEntities(FKGTargetSelectParams&& InParams, FKGTargetSelectResult& OutResult);
	static bool QueryEntitiesBySelectRuleID(const FKGTargetSelectParamsSimple& InParams, uint32 TargetSelectRuleID, FKGTargetSelectResult& OutResult);
	static bool QueryEntitiesBySkillID(const FKGTargetSelectParamsSimple& InParams, uint32 SkillID, FKGTargetSelectResult& OutResult);
	static bool QueryEntitiesBySpellFieldID(const FKGTargetSelectParamsSimple& InParams, uint32 SpellFieldID, FKGTargetSelectResult& OutResult);
	
	static bool IsValidTarget(const FKGSearchTargetParams& InParams, ICppEntityInterface* BaseEntity, KGEntityID TargetEntityID, bool bIsEditor);
	
	static ICppEntityInterface* GetEntityInstigator(ICppEntityInterface* InEntity, UKGUEActorManager* ActorManager);
	static void DrawDebugSortResultFromLua(ICppEntityInterface* BaseEntity, const TArray<KGEntityID>& SortedEntityIDs);

private:
	// core
	static bool QueryEntitiesInSingleRange(FKGTargetSelectContext& InOutContext, const FKGSingleRangeData& RangeData, FKGTargetSelectResult& OutResult);
	static bool CalcRangeBasePosAndYaw(FKGTargetSelectContext& InOutContext, const FKGSingleRangeData& RangeData, FVector& OutBasePos, float& OutBaseYaw);
	static void CheckTargetAndFillResult(FKGTargetSelectContext& InOutContext, const TArray<AActor*>& TargetActors, FKGTargetSelectResult& OutResult);
	static void DoBackupQuery(FKGTargetSelectContext& InOutContext, FKGTargetSelectResult& OutResult);

	// sort
	static void SortTargetEntities(FKGTargetSelectContext& InOutContext, const FVector& CenterPos, FKGTargetSelectResult& OutResult);
	static void DoDefaultSort(FKGTargetSelectContext& InOutContext, FKGTargetSelectResult& OutResult);
	static void DoDistanceSort(FKGTargetSelectContext& InOutContext, const FVector& CenterPos, FKGTargetSelectResult& OutResult);
	static void DoRandomSort(FKGTargetSelectContext& InOutContext, FKGTargetSelectResult& OutResult);
	static void DoCameraDirSort(FKGTargetSelectContext& InOutContext, const FVector& CenterPos, FKGTargetSelectResult& OutResult);
	
	// check
	static bool IsValidFightTarget(ICppEntityInterface* SourceEntity, ICppEntityInterface* TargetEntity, FKGTargetSelectContext& InOutContext);
	static bool IsValidFightTargetFaction(ICppEntityInterface* SourceEntity, ICppEntityInterface* TargetEntity, FKGTargetSelectContext& InOutContext);
	static bool IsValidFightTargetTargetType(ICppEntityInterface* SourceEntity, ICppEntityInterface* TargetEntity, FKGTargetSelectContext& InOutContext);
	static bool IsValidFightTargetClassType(ICppEntityInterface* TargetEntity, FKGTargetSelectContext& InOutContext);
	static bool IsValidFightTargetReviseType(ICppEntityInterface* SourceEntity, ICppEntityInterface* TargetEntity, FKGTargetSelectContext& InOutContext);
	static bool CanTargetBeHit(ICppEntityInterface* SourceEntity, ICppEntityInterface* TargetEntity, FKGTargetSelectContext& InOutContext);
	static bool CheckTargetFaction(ICppEntityInterface* SourceEntity, ICppEntityInterface* TargetEntity, FKGTargetSelectContext& InOutContext, uint32 FactionMask);
	
	// misc
	// static void MergeQueryResult(const TSet<KGEntityID>& EntityIDsFoundCurRange, TSet<KGEntityID>& FinalEntityIDs, EKGSelectionSetOperateType OperateType);
	static bool GetFloorPosition(AActor* InActor, FVector& OutFloorPosition);
	static void DrawDebugEntityCapsule(UKGUEActorManager* ActorManager, KGEntityID EntityID, const FColor& Color, float Duration, float Thickness);
	static void DrawDebugSequenceInfo(UKGUEActorManager* ActorManager, KGEntityID EntityID, int32 SeqID);
	static void DrawDebugFan3D(
		UWorld* WorldContext, const FVector& Center, float InnerRadius, float OuterRadius, int32 Segments, const FRotator& Rotation,
		float HalfAngle, float Height, const FColor& Color, float Duration, float Thickness);
};
