#pragma once
#include "Framework/Application/IInputProcessor.h"

enum EInputEvent : int;
struct FKey;

DECLARE_DELEGATE(FPressAnyKeyInputPreProcessorCanceled);
DECLARE_DELEGATE_TwoParams(FPressAnyKeyInputPreProcessorKeySelected, const FKey&, EInputEvent Type);

class FPressAnyKeyInputProcessor : public IInputProcessor
{
public:
	virtual void Tick(const float DeltaTime, FSlateApplication& SlateApp, TSharedRef<ICursor> Cursor) override;
	virtual bool HandleKeyDownEvent(FSlateApplication& SlateApp, const FKeyEvent& InKeyEvent) override;
	virtual bool HandleKeyUpEvent(FSlateApplication& SlateApp, const FKeyEvent& InKeyEvent) override;
	virtual bool HandleMouseButtonDownEvent( FSlateApplication& SlateApp, const FPointerEvent& MouseEvent) override;
	virtual bool HandleMouseButtonUpEvent( FSlateApplication& SlateApp, const FPointerEvent& MouseEvent) override;
	virtual bool HandleMouseButtonDoubleClickEvent(FSlateApplication& SlateApp, const FPointerEvent& MouseEvent) override;
	virtual bool HandleMouseWheelOrGestureEvent(FSlateApplication& SlateApp, const FPointerEvent& InWheelEvent, const FPointerEvent* InGestureEvent) override;

	FPressAnyKeyInputPreProcessorCanceled OnKeySelectionCanceled;
	FPressAnyKeyInputPreProcessorKeySelected OnKeySelected;
	
private:
	void HandleKey(const FKey& Key, const EInputEvent EventType) const;
};
