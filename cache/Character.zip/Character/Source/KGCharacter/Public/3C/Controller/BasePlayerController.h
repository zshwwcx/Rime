#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "GameFramework/PlayerInput.h"
#include "LuaOverriderInterface.h"
#include "NavFilters/NavigationQueryFilter.h"
#include "Navigation/PathFollowingComponent.h"
#include "BasePlayerController.generated.h"

class UInputAction;
enum class EPlayerMappableKeySlot : uint8;
struct FEnhancedInputActionEventBinding;
enum class ETriggerEvent : uint8;
enum class EAudioListenerMode : uint8;
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FPlayerMoveCompleted, FAIRequestID, RequestID, EPathFollowingResult::Type, Result);
DECLARE_DELEGATE_RetVal(bool, FPlayerControllerRequestVirtualJoystickInitVisible);
class UInputMappingContext;
class FPressAnyKeyInputProcessor;

UENUM(BlueprintType)
enum class EVirtualJoystickPendingState : uint8
{
    None = 0,
    PendingShown = 1,
    PendingHidden = 2,
};

/**
 * 主角控制器
 */
UCLASS()
class KGCHARACTER_API ABasePlayerController : public APlayerController
		, public ILuaOverriderInterface
{
	GENERATED_UCLASS_BODY()

    bool bVirtualJoystickVisible = true;
public:
    static FPlayerControllerRequestVirtualJoystickInitVisible OnRequestVirtualJoystickInitVisible;
    
	virtual FString GetLuaFilePath_Implementation() const override { return TEXT("Gameplay.3C.Controller.PlayerController"); };

public:
	virtual void TickActor(float DeltaTime, enum ELevelTick TickType, FActorTickFunction& ThisTickFunction) override;

	virtual void CreateTouchInterface() override;
	virtual TSharedPtr<class SVirtualJoystick> CreateVirtualJoystick() override;
	virtual void CleanupGameViewport() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

public:
	virtual void PostInitializeComponents() override;
	virtual void AutoManageActiveCameraTarget(AActor* SuggestedTarget) override;

	UFUNCTION(BlueprintCallable)
	void SetViewTargetWithBlendByID(int64 NewViewTargetID, float BlendTime = 0, enum EViewTargetBlendFunction BlendFunc = VTBlend_Linear, float BlendExp = 0, bool bLockOutgoing = false);
	
	UFUNCTION(BlueprintCallable)
	bool PossessWithActorID(int64 ActorID) ;
	
	UFUNCTION(BlueprintCallable)
	FQuat GetLocoInputDirectionAsQuat();
	
	UFUNCTION(BlueprintCallable)
	FVector GetLocoInputDirectionAsVec();
	
	UFUNCTION(BlueprintCallable)
	int64 GetControlledPawnObjectID();
    
    virtual void SetVirtualJoystickVisibility(bool bVisible) override;
protected:

	UFUNCTION(BlueprintCallable)
	void AutoActiveCameraTarget(AActor* SuggestedTarget);

protected:
	UFUNCTION(BlueprintImplementableEvent)
	void OnPostInitializeComponents();
	UFUNCTION(BlueprintImplementableEvent)
	void PreTickActor(float DeltaTime, int32 TickType);
	UFUNCTION(BlueprintImplementableEvent)
	void ReceiveOnPossess(APawn* aPawn);
	UFUNCTION(BlueprintImplementableEvent)
	void ReceiveOnUnPossess();
	UFUNCTION(BlueprintCallable)
	static bool IsValidMoveRequestID(const FAIRequestID& RequestID);

	UFUNCTION(BlueprintImplementableEvent)
	void OnLeftMouseSelectActor(AActor* InActor);

	UFUNCTION(BlueprintCallable)
	void K2_SetShowMouseCursor(bool bShow) {SetShowMouseCursor(bShow);};

public:
	UFUNCTION(BlueprintCallable)
	bool GetHitResultUnderCursorWithIgnoreActors(ECollisionChannel TraceChannel, bool bTraceComplex, FHitResult& HitResult,const TArray<AActor*> IngoreActors) const;
	
	UFUNCTION(BlueprintCallable)
	bool GetHitResultUnderFingerWithIgnoreActors(ETouchIndex::Type FingerIndex, ECollisionChannel TraceChannel, bool bTraceComplex, FHitResult& HitResult,const TArray<AActor*> IngoreActors) const;
	
	/**
	 * Get the intersection point between the mouse position ray and a plane
	 */	
	UFUNCTION(BlueprintCallable)
	bool GetMouseRayPlaneIntersection(float Height, float& PositionX, float& PositionY, float& PositionZ);
	
#pragma region PathFollow
public:
	void OnMoveCompleted(FAIRequestID RequestID, const FPathFollowingResult& Result);

	UFUNCTION(BlueprintCallable, Meta = (AdvancedDisplay = "bStopOnOverlap, bCanStrafe, bAllowPartialPath"))
	EPathFollowingRequestResult::Type MoveToActor(FAIRequestID& RequestID, AActor* Goal, float AcceptanceRadius, TSubclassOf<UNavigationQueryFilter> FilterClass, bool bStopOnOverlap = true, bool bUsePathfinding = true, bool bCanStrafe = true, bool bAllowPartialPath = true, float MultiHalfHeight = 7.0f);

	UFUNCTION(BlueprintCallable, Meta = (AdvancedDisplay = "bStopOnOverlap, bCanStrafe, bAllowPartialPath"))
	EPathFollowingRequestResult::Type MoveToLocation(FAIRequestID& RequestID, const FVector& Dest, float AcceptanceRadius, TSubclassOf<UNavigationQueryFilter> FilterClass, bool bStopOnOverlap = true, bool bUsePathfinding = true, bool bProjectDestinationToNavigation = false, bool bCanStrafe = true, bool bAllowPartialPath = true, float MultiHalfHeight = 7.0f);

	FPathFollowingRequestResult MoveTo(const FAIMoveRequest& MoveRequest, FNavPathSharedPtr* OutPath = nullptr);

	FAIRequestID RequestMove(const FAIMoveRequest& MoveRequest, FNavPathSharedPtr Path);

	void FindPathForMoveRequest(const FAIMoveRequest& MoveRequest, FPathFindingQuery& Query, FNavPathSharedPtr& OutPath) const;

	bool BuildPathfindingQuery(const FAIMoveRequest& MoveRequest, FPathFindingQuery& Query) const;

	bool PauseMove(FAIRequestID RequestToPause);

	bool ResumeMove(FAIRequestID RequestToResume);

	void StopMovement() override;

public:
	UPROPERTY(BlueprintAssignable, meta = (DisplayName = "MoveCompleted"))
	FPlayerMoveCompleted ReceiveMoveCompleted;

private:
	// 玩家的寻路组件
	UPROPERTY(VisibleDefaultsOnly)
	UPathFollowingComponent* PathFollowingComponent = nullptr;

#pragma endregion PathFollow



#pragma region RawLocoInput
public:
	// 判断是否有玩家摇杆/键盘WASD的原始位移输入
	UFUNCTION(BlueprintCallable)
	bool GetHasRawLocoInput() { return bHasRawLocoInput; }

private:
	bool bHasRawLocoInput = false;
	bool bLastHasRawLocoInput = false;

#pragma endregion RawLocoInput

#pragma region AudioListener

public:
	virtual void GetAudioListenerPosition(FVector& OutLocation, FVector& OutFrontDir, FVector& OutRightDir) const override;
	void SwitchAudioListenerMode(EAudioListenerMode InAudioListenerMode);

private:
	EAudioListenerMode AudioListenerMode;
	
#pragma endregion AudioListener


	///主角在切换地图前，从服务器下发新地图坐标，在切换中，进行使用，仅主玩家有效
public:
	UFUNCTION(BlueprintCallable)
	virtual	void SetSpawnPoint(float X, float Y, float Z, float Pitch, float Yaw, float Roll);

	UFUNCTION(BlueprintCallable)
	void GetSpawnPoint(FVector& OutLocation, FRotator& OutRotation);

	UFUNCTION(BlueprintCallable)
	FVector GetSpawnLocation();
	
	TSharedPtr<class SKGVirtualJoystick> GetVirtualJoystick() { return KGVirtualJoystick; }
private:
	FVector SpawnLocation;
	FRotator SpawnRotation;
	TSharedPtr<class SKGVirtualJoystick> KGVirtualJoystick;


#pragma region Input
	
public:
#if WITH_EDITOR
	virtual void PostProcessInput(const float DeltaTime, const bool bGamePaused) override;

	UFUNCTION(BlueprintImplementableEvent)
	void ExecuteCustomCommand(const FString& Command, const FString& Params);
#endif
	
	void TickMouseMove(float DeltaTime);
	UFUNCTION(BlueprintCallable)
	void EnabledTickMouseMove(bool bEnabled);
	UFUNCTION(BlueprintImplementableEvent)
	void OnMouseMoved(FVector2D Offset);
private:
	bool bEnabledTickMouseMove;
	FVector2D LastMousePosition;
	
public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Input")
	TObjectPtr<UInputMappingContext> DefaultMappingContext;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Input")
	TArray<TObjectPtr<UInputAction>> ChordActionIAArray;	
	UPROPERTY(Transient, VisibleAnywhere, Category="Input")
	TObjectPtr<UInputMappingContext> RuntimeMappingContext;
	
	UFUNCTION(BlueprintCallable)
	UInputComponent* GetInputComponent() { return InputComponent; }
	
	virtual void InitInputSystem() override;
	UFUNCTION(BlueprintImplementableEvent)
	void OnInitInputSystem();
	
	// 这里的输入不做任何的处理, 处理放到使用的地方, 根据后续的基础移动、技能操控等逻辑业务需要自己来解释语义
	UFUNCTION(BlueprintCallable)
	void InputMoveAxis2D(float X, float Y);
	UFUNCTION(BlueprintCallable)
	void InputMoveAxis_X(float X);
	UFUNCTION(BlueprintCallable)
	void InputMoveAxis_Y(float Y);
	UFUNCTION(BlueprintCallable)
	bool HasMoveAxisInput() const;
	
	UFUNCTION(BlueprintCallable)
	bool K2_IsInputKeyDown(const FString Key) const;
	UFUNCTION(BlueprintCallable)
	bool IsPressed(const FName& KeyName) const;
	UFUNCTION(BlueprintCallable)
	bool Key_IsMouseButton(const FName& KeyName) const;
	UFUNCTION(BlueprintCallable)
	bool Key_IsKeyboardKey(const FName& KeyName) const;

	UFUNCTION(BlueprintCallable)
	void SetDebugExecEnabled(const bool bEnabled);
private:
	TArray<FKeyBind> CacheDebugExecBindings;
	
	
public:
	UFUNCTION(BlueprintImplementableEvent, Category = "Input")
	void ReceiveAction(int ActionIndex, ETriggerEvent TriggerEvent, float AxisX, float AxisY);
private:
	TMap<FName, TMap<ETriggerEvent, uint32>> BindActionMap;
	
	UFUNCTION(BlueprintCallable, Category = "Input")
	void BindAction(const FName& ActionName, int ActionIndex, ETriggerEvent TriggerEvent);
	UFUNCTION(BlueprintCallable, Category = "Input")
	void UnBindAction(const FName& ActionName, ETriggerEvent TriggerEvent);
	UFUNCTION(BlueprintCallable, Category = "Input")
	void BindKey(const FName& ActionName, const FName& KeyName, EInputActionValueType Type, int ChordActionIndex);
	UFUNCTION(BlueprintCallable, Category = "Input")
	void UnBindKey(const FName& ActionName, const FName& KeyName) const;
	UFUNCTION(BlueprintCallable, Category = "Input")
	void UnmapAllKeysFromAction(const FName& ActionName) const;
	UFUNCTION(BlueprintCallable)
	void RequestRebuildControlMappings() const;

public:
	UFUNCTION(BlueprintCallable)
	void ActivePressAnyKey();
	UFUNCTION(BlueprintCallable)
	void DeactivePressAnyKey() const;
	UFUNCTION(BlueprintImplementableEvent)
	void OnHandleKeySelected(const FName& InKeyName, const EInputEvent EventType);
	UFUNCTION(BlueprintImplementableEvent)
	void OnHandleKeySelectionCanceled() const;

private:
	void HandleKeySelected(const FKey& InKey, const EInputEvent EventType);
	void HandleKeySelectionCanceled() const;
	TSharedPtr<FPressAnyKeyInputProcessor> InputProcessor;
	
#pragma endregion Input
};