﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"

class KGCHARACTER_API ISceneDrawerInterface
{
public:
	virtual void DrawMoveSyncData(const FVector& Location, const FRotator& rotator, const FColor & color) = 0;
};
