#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"

#include "AnimNotifyState_C7HideMesh.generated.h"

class UMeshComponent;
class UCurveFloat;

UENUM(BlueprintType)
enum class EKGHideMeshLifeTimeMode : uint8
{
	BindState = 0 UMETA(DisplayName = "BindState"),
	FixedTime = 1 UMETA(DisplayName = "FixedTime"),
};

UCLASS(meta = (DisplayName = "C7HideMesh", ToolTip="显隐模型, 不支持预览"))
class UAnimNotifyState_C7HideMesh : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) override;

#if WITH_EDITOR
	virtual void ValidateAssociatedAssets() override;
#endif
	
private:
	
	UPROPERTY(EditAnywhere, meta=(DisplayName="模型显影的控制模式", Category="Basic"))
	EKGHideMeshLifeTimeMode LifeTimeMode = EKGHideMeshLifeTimeMode::BindState;

	UPROPERTY(EditAnywhere, meta=(DisplayName="模型显影的目标Alpha值", ClampMin="0.0", ClampMax="1.0", Category="Basic"))
	float TargetAlpha = 0.0f;

	UPROPERTY(EditAnywhere, meta=(DisplayName="淡入时间(s)", Category="Basic"))
	float FadeInTime = 0.2f;
	
	UPROPERTY(EditAnywhere, meta=(DisplayName="持续时长(s)", Category="Basic", ToolTip="总时间=淡入时间+持续时间+淡出时间", EditCondition="LifeTimeMode==EKGHideMeshLifeTimeMode::FixedTime", EditConditionHides))
	float Duration = 0.0f;
	
	UPROPERTY(EditAnywhere, meta=(DisplayName="淡出时间(s)", Category="Basic"))
	float FadeOutTime = 0.2f;

	TMap<TWeakObjectPtr<UMeshComponent>, uint32> ReqIDsMapping;
};
