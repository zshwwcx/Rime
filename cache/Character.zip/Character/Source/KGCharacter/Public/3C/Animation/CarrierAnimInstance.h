#pragma once

#include "3C/Animation/BaseAnimInstance.h"
#include "CarrierAnimInstance.generated.h"

UENUM()
enum class EMountIKType : uint8
{
	None = 0,			// 不做IK
	BikeIK,				// 自行车IK模式
	CommonVehicleIK		// 通用载具IK模式
};

struct FMountBikeInfo
{
	FMountBikeInfo() {}

	// 自行车，角色Root到前轮底部的距离
	float MountFrontLength = 60.0f;
	// 自行车，角色Root到后轮底部的距离
	float MountEndLength = 60.f;
	// 自行车，前轮半径
	float MountFrontRadius = 60.0f;
	// 自行车，后轮半径
	float MountEndRadius = 60.f;
	// 自行车前轮骨骼名称
	FName FrontWheelName;
	// 自行车后轮骨骼名称
	FName RearWheelName;
	// 自行车 Pitch 调整半衰时间
	float MountPitchHalfTime = 0.05f;
	// 自行车 Root偏移调整半衰时间
	float MountRootOffsetHalfTime = 0.f;
};

/**
 * 动画蓝图基类
 */
UCLASS(BlueprintType, Blueprintable)
class KGCHARACTER_API UCarrierAnimInstance : public UBaseAnimInstance
{
	GENERATED_UCLASS_BODY()

public:
	virtual void NativeInitializeAnimation() override;
	virtual void NativeUpdateAnimation(float DeltaSeconds) override;
	
	// 坐骑通用接口
	UFUNCTION(BlueprintCallable)
	void SetRelLocToRider(const float& DeltaX, const float& DeltaY, const float& DeltaZ);
	UFUNCTION(BlueprintCallable)
	void InitMountBornPitch();
	
	// 自行车坐骑相关接口
	UFUNCTION(BlueprintCallable)
	void SetBikeLength(float InFrontLength, float InEndLength) { BikeInfo.MountFrontLength = InFrontLength; BikeInfo.MountEndLength = InEndLength; }
	UFUNCTION(BlueprintCallable)
	void SetBikeRadius(const float& InFrontRadius, const float& InEndRadius) { BikeInfo.MountFrontRadius = InFrontRadius; BikeInfo.MountEndRadius = InEndRadius; }
	UFUNCTION(BlueprintCallable)
	void SetBikeWheelParam(FName FWheelName, FName RWheelName) { BikeInfo.FrontWheelName = FWheelName; BikeInfo.RearWheelName = RWheelName; }
	UFUNCTION(BlueprintCallable)
	void SetBikePostureParam(float HalfTime, float OffsetHalfTime) { BikeInfo.MountPitchHalfTime = HalfTime; BikeInfo.MountRootOffsetHalfTime = OffsetHalfTime; }
	UFUNCTION(BlueprintCallable)
	void SetBikeOffset(float InHeadOffset, float InSeatOffset);
	// 测试函数,不能作为正式功能调用
	UFUNCTION(BlueprintCallable)
	void SetMountEnablePostureCal(bool bEnable) { bNeedCalculateMountPos = bEnable; }
	
	void CalculateMountPosture(float DeltaTime);
	void ApplyMountPosture();
	void ApplyBikePosture();
	void ApplyFourWheelCarPosture();
	// 计算骑乘 自行车状态下角色姿态
	void CalculateRideBikePosture(float DeltaTime);
	// 计算驾驶 老爷车状态下角色姿态
	void CalculateDriveCarPosture(float DeltaTime);
	// 初始化数据
	void InitData();
	// 设置坐骑姿态 如果外部调用了设置姿态参数的接口则表明数据由外部传入,动画蓝图则不会再进行相应计算
	void UpdateMountPostureParam(const float& Pitch, const float& Roll, const float& RootOffset);

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "MountAnim Config")
	EMountIKType MountIKType = EMountIKType::None;

	// 配置相关
	UPROPERTY(EditDefaultsOnly, Category=IK, meta = (DisplayName = "姿态调整骨骼", EditCondition="MountIKType != EMountIKType::None", EditConditionHides))
	FName RootBoneName = "root";

	// 姿态角度检测误差限制(超出误差范围则使用胶囊体周边检测结果)
	UPROPERTY(EditDefaultsOnly, Category=IK, meta = (DisplayName = "姿态误差限制", EditCondition="MountIKType != EMountIKType::None", EditConditionHides))
	float PostureAngleCheckLimit = 5;
	
	UPROPERTY(EditDefaultsOnly, Category=IK, meta = (DisplayName = "检测对象", EditCondition="MountIKType != EMountIKType::None", EditConditionHides))
	TEnumAsByte<ECollisionChannel> BlockChannel = ECollisionChannel::ECC_WorldStatic;

	UPROPERTY(EditDefaultsOnly, Category=IK, meta = (DisplayName = "向下检测距离", EditCondition="MountIKType != EMountIKType::None", EditConditionHides))
	float TraceLength = 200.f;
	
	UPROPERTY(EditDefaultsOnly, Category=IK, meta = (DisplayName = "Pitch 调整半衰时间", EditCondition="MountIKType != EMountIKType::None", EditConditionHides))
	float PitchHalfTime = 0.05f;

	UPROPERTY(EditDefaultsOnly, Category=IK, meta = (DisplayName = "Pitch 调整半衰时间", EditCondition="MountIKType != EMountIKType::None", EditConditionHides))
	float RollHalfTime = 0.05f;
	
	UPROPERTY(EditDefaultsOnly, Category=IK, meta = (DisplayName = "Root偏移调整半衰时间", EditCondition="MountIKType != EMountIKType::None", EditConditionHides))
	float RootOffsetHalfTime = 0.05f;

	UPROPERTY(EditDefaultsOnly, Category=IK, meta = (DisplayName = "射线绘制", EditCondition="MountIKType != EMountIKType::None", EditConditionHides))
	TEnumAsByte<EDrawDebugTrace::Type> DebugTrace = EDrawDebugTrace::None;

	UPROPERTY(EditDefaultsOnly, Category=IK, meta = (DisplayName = "是否需要调整Pitch", EditCondition="MountIKType == EMountIKType::CommonVehicleIK", EditConditionHides))
	bool bApplyPitchPosture = true;

	UPROPERTY(EditDefaultsOnly, Category=IK, meta = (DisplayName = "最大Pitch角度", EditCondition="MountIKType == EMountIKType::CommonVehicleIK && bApplyPitchPosture", EditConditionHides))
	float ApplyMaxPitch = 70.f;
	
	UPROPERTY(EditDefaultsOnly, Category=IK, meta = (DisplayName = "是否需要调整Roll", EditCondition="MountIKType == EMountIKType::CommonVehicleIK", EditConditionHides))
	bool bApplyRollPosture = true;

	UPROPERTY(EditDefaultsOnly, Category=IK, meta = (DisplayName = "最大Roll角度", EditCondition="MountIKType == EMountIKType::CommonVehicleIK && bApplyRollPosture", EditConditionHides))
	float ApplyMaxRoll = 70.f;
	
	// 通用载具IK 基本配置方式(自行车样式可前后各配一个,轮椅样式可前面/后面配两个,三轮车样式可前面一个后面两个(倒三轮反之),四轮前后各配两个即可,更多轮胎的载具也只需选定四个点即可)
	UPROPERTY(EditDefaultsOnly, Category=IK, meta = (DisplayName = "车前轮胎列表(数量0-2)", EditCondition="MountIKType == EMountIKType::CommonVehicleIK", EditConditionHides))
	TArray<FWheelInfo> FrontWheelArray;

	UPROPERTY(EditDefaultsOnly, Category=IK, meta = (DisplayName = "车后轮胎列表(数量0-2)", EditCondition="MountIKType == EMountIKType::CommonVehicleIK", EditConditionHides))
	TArray<FWheelInfo> BackWheelArray;

	UPROPERTY(EditDefaultsOnly, Category=IK, meta = (DisplayName = "前方轮胎滚动列表(区分前后避免前后轮大小不一致导致旋转不一致)", EditCondition="MountIKType == EMountIKType::CommonVehicleIK", EditConditionHides))
	TArray<FWheelInfo> FrontScrollWheelArray;

	UPROPERTY(EditDefaultsOnly, Category=IK, meta = (DisplayName = "后方轮胎滚动列表(区分前后避免前后轮大小不一致导致旋转不一致)", EditCondition="MountIKType == EMountIKType::CommonVehicleIK", EditConditionHides))
	TArray<FWheelInfo> BackScrollWheelArray;

	UPROPERTY(EditDefaultsOnly, Category=IK, meta = (DisplayName = "轮胎转向列表", EditCondition="MountIKType == EMountIKType::CommonVehicleIK", EditConditionHides))
	TArray<FWheelInfo> RotateWheelArray;
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "MountAnim Config")
	FIKConfig_Mount MountIKConfig;
	
	// 姿态参数
	UPROPERTY(Transient, BlueprintReadOnly)
	float MountPitch = 0.f;
	UPROPERTY(Transient, BlueprintReadOnly)
	float MountRoll = 0.f;
	UPROPERTY(Transient, BlueprintReadOnly)
	float MountRootOffset = 0.f;

	// 自行车龙头 & 坐垫偏移
	UPROPERTY(Transient, BlueprintReadOnly)
	float BikeHeadOffset = 0.f;
	UPROPERTY(Transient, BlueprintReadOnly)
	float BikeSeatOffset = 0.f;
private:
	// 自行车姿态计算相关
	FMountBikeInfo BikeInfo;

	FVector LastMountLoc = FVector::ZeroVector;

	// 通用姿态参数
	float DestPitch = 0.f;
	float DestRoll = 0.f;
	float DestRootOffset = 0.f;
	
	// 坐骑计算控制变量
	bool bNeedCalculateMountPos = true;
	bool bNeedInitData = true;

	// 坐骑坐标偏移转换
	FVector RelLocToRider = FVector::ZeroVector;
	
	// 自行车姿态补偿计算相关变量
	
	float PitchExtraCorrect = 0.f;
	float InitDeltaPitch = 360;
	bool bAirPitchAdjust = false;
	bool bExtraAdjust = false;

	// 其它
	TArray<TEnumAsByte<EObjectTypeQuery>> TraceArr;
};
