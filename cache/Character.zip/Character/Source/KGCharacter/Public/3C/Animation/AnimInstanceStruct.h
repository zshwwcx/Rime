#pragma once
#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "UObject/ScriptMacros.h"

#include "AnimInstanceStruct.generated.h"


USTRUCT(BlueprintType)
struct KGCHARACTER_API FAISAttachmentInfo
{
	GENERATED_USTRUCT_BODY()

public:
	// Owner的LocoState
	UPROPERTY(Transient, BlueprintReadOnly)
	int32 OwnerLocoState = 0;

	// Owner的LocoStateInnerState
	UPROPERTY(Transient, BlueprintReadOnly)
	int32 OwnerLocoStateInnerState = 0;

	// Owner的CachedFootPosture
	UPROPERTY(Transient, BlueprintReadOnly)
	int32 OwnerCachedFootPosture = 0;

	// Owner的DelayedAnimMovePosture
	UPROPERTY(Transient, BlueprintReadOnly)
	int32 OwnerDelayedAnimMovePosture = 0;

public:
	// 坐骑朝向与角色朝向的差值
	UPROPERTY(Transient, BlueprintReadOnly)
	float MountDirYawToActorYawDelta = 0.f;

	// 实际坐骑朝向与角色朝向的差值的缩放系数
	UPROPERTY(Transient, BlueprintReadOnly)
	float RealMountDeltaYawScale = 0.75f;

	// MountDirYawToActorYawDelta * RealMountDeltaYawScale
	UPROPERTY(Transient, BlueprintReadOnly)
	float RealMountDirYawToActorYawDelta = 0.f;

	// 坐骑前轮的移动角度
	UPROPERTY(Transient, BlueprintReadOnly)
	float MountFrontMoveAngle = 0.f;

	// 坐骑后轮的移动角度
	UPROPERTY(Transient, BlueprintReadOnly)
	float MountEndMoveAngle = 0.f;

	// 坐骑把手偏移
	UPROPERTY(Transient, BlueprintReadOnly)
	float MountHeadOffset = 0.f;

	// 坐骑座位高度偏移
	UPROPERTY(Transient, BlueprintReadOnly)
	float MountSeatOffset = 0.f;
};

USTRUCT(BlueprintType)
struct KGCHARACTER_API FRideMountAnimDataInfo
{
	GENERATED_USTRUCT_BODY()
	
	// 骑乘时角色 Pitch角度
	UPROPERTY(Transient, BlueprintReadOnly)
	float RiderPitch = 0.f;

	// 骑乘时角色 Root偏移
	UPROPERTY(Transient, BlueprintReadOnly)
	float RiderRootOffset = 0.f;

	// 骑乘时角色 左手位置
	UPROPERTY(Transient, BlueprintReadOnly)
	FVector RiderHandLLocation;

	// 骑乘时角色 右手位置
	UPROPERTY(Transient, BlueprintReadOnly)
	FVector RiderHandRLocation;
	
	// 骑乘时角色 左脚位置
	UPROPERTY(Transient, BlueprintReadOnly)
	FVector RiderFootLLocation;

	// 骑乘时角色 右脚位置
	UPROPERTY(Transient, BlueprintReadOnly)
	FVector RiderFootRLocation;
};