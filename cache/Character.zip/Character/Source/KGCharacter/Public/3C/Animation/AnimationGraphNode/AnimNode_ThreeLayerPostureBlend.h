#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Animation/InputScaleBias.h"
#include "Animation/AnimNodeBase.h"
#include "3C/Animation/AnimationGraphNode/CustomAnimNodeDefine.h"
#include "AlphaBlend.h"
#include "AnimNode_ThreeLayerPostureBlend.generated.h"

UENUM()
enum class EActionBlendRule : uint8
{
	FullBodyOverride UMETA(DisplayName = "FullBody Override"),
	PartBodyOverride UMETA(DisplayName = "PartBody Override"),
	PartBodyOverrideOnlyWhenMoving UMETA(DisplayName = "Partbody Overide When Loco Moving"),
};

USTRUCT(BlueprintType)
struct FThreeLayerPostureParam
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bAlwaysUpdateLocoPose = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float ActionBlendTime = 0.1f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float PerformBlendTime = 0.1f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bActionWorking = false;
	
	// Action层总是override, 且有全身和非全身两种组合形式	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	EActionBlendRule ActionBlendRule= EActionBlendRule::FullBodyOverride;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bLocoMoving = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bActionMeshSpaceBlend = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName  ActionFilterBoneName = NAME_None;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8  ActionFilterBoneDepth = 2;

	// Perform总是叠加, 只有非全身的设计
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bPerformWorking = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	EActionBlendRule PerformBlendRule = EActionBlendRule::FullBodyOverride;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName  PerformFilterBoneName = NAME_None;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8  PerformFilterBoneDepth = 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float  AdditiveAlpha = 1.0;
};

struct ThreeLayerBlendFilterKeyStruct {

public:
	ThreeLayerBlendFilterKeyStruct(const FGuid & SGuid, const FGuid & VBGuid, FName boneName, uint8 boneDepth, int32 requiredBonesNum, int32 LodLevel) :
	SkeletonGuid(SGuid), VirtualBoneGuid(VBGuid), BoneName(boneName), BoneDepth(boneDepth),RequiredBonesNum(requiredBonesNum), LODLevel(LodLevel) {}

private:
	FGuid SkeletonGuid;
	FGuid VirtualBoneGuid;
	FName BoneName=EName::None;
	uint8 BoneDepth=0;
	int32 RequiredBonesNum=0;
	int32 LODLevel=0;

public:
	friend inline bool operator == (const ThreeLayerBlendFilterKeyStruct& A, const ThreeLayerBlendFilterKeyStruct& B) {
		return A.SkeletonGuid == B.SkeletonGuid && A.VirtualBoneGuid == B.VirtualBoneGuid && A.BoneName == B.BoneName && A.BoneDepth == B.BoneDepth  && A.RequiredBonesNum == B.RequiredBonesNum &&
			A.LODLevel == B.LODLevel;
	}
	
	friend inline uint32 GetTypeHash(const ThreeLayerBlendFilterKeyStruct& key) {
		uint32 hash = 0;

		hash = HashCombine(hash, GetTypeHash(key.SkeletonGuid));
		hash = HashCombine(hash, GetTypeHash(key.VirtualBoneGuid));
		hash = HashCombine(hash, GetTypeHash(key.BoneName));
		hash = HashCombine(hash, GetTypeHash(key.BoneDepth));
		hash = HashCombine(hash, GetTypeHash(key.RequiredBonesNum));
		hash = HashCombine(hash, GetTypeHash(key.LODLevel));

		return  hash;
	}
};

USTRUCT(BlueprintType)
struct KGCHARACTER_API FAnimNode_ThreeLayerPostureBlend: public FAnimNode_Base
{
	GENERATED_USTRUCT_BODY()

public:
	virtual void GatherDebugData(FNodeDebugData& DebugData) override;
	
protected:
	UPROPERTY(EditAnywhere, EditFixedSize, Category=Links)
	FPoseLink LocomotionPose;

	UPROPERTY(EditAnywhere, EditFixedSize, Category = Links)
	FPoseLink ActionPose;

	UPROPERTY(EditAnywhere, EditFixedSize, Category = Links)
	FPoseLink PerformAdditivePose;

#if WITH_EDITORONLY_DATA

	UPROPERTY(EditAnywhere, meta = (AlwaysAsPin, FoldProperty))
	FThreeLayerPostureParam ThreeLayerPostureParam;
	
#endif

protected:

	FName CurrentActionBoneRootName = NAME_None;
	TArray<FPerBoneBlendWeight> TemplateActionBlendWeights;
	TArray<FPerBoneBlendWeight> CurrentActionBlendWeights;
	uint8 CurrentActionBoneDepth = 1;

	FName CurrentPerformBoneRootName = NAME_None;
	TArray<FPerBoneBlendWeight> TemplatePerformBlendWeights;
	TArray<FPerBoneBlendWeight> CurrentPerformBlendWeights;
	uint8 CurrentPerformBoneDepth = 0;
	
	FThreeLayerPostureParam CurPostureParam;

	bool TargetActionWorking = false;
	bool TargetPerformWorking = false;
	bool TargetIsLocoMoving = false;
	
	FAlphaBlend ActionBlend;
	FAlphaBlend ActionPartBodyWhenMovingBlend;
	FAlphaBlend PerformBlend;
	FAlphaBlend PerformPartBodyWhenMovingBlend;

	float CachedActionLayerWeight = 0.0f;
	float CachedActionPartBodyWeight = 0.0f;
	float CachedPerformLayerWeight = 0.0f;
	float CachedPerformPartBodyWeight = 0.0f;
	
	// possiblely performance hotspot, 10 us in PC
	TMap<ThreeLayerBlendFilterKeyStruct, TArray<FPerBoneBlendWeight>> CachedBlendBoneWeights;

	
public:
	FAnimNode_ThreeLayerPostureBlend()
	{
	}

	// FAnimNode_Base interface
	virtual void Initialize_AnyThread(const FAnimationInitializeContext& Context) override;
	virtual void Update_AnyThread(const FAnimationUpdateContext& Context) override;
	virtual void CacheBones_AnyThread(const FAnimationCacheBonesContext& Context) override;
	virtual void Evaluate_AnyThread(FPoseContext& Output) override;
	// End of FAnimNode_Base interface

protected:
	bool EnsureBlendWeights(const FBoneContainer& RequiredBones, const USkeleton* skePtr, const ThreeLayerBlendFilterKeyStruct& keyStruct, const FName& boneName, uint8 boneDepth, TArray<FPerBoneBlendWeight>& outWeights);
	bool IsAnyBlendWorking();
	
	bool IsActionFullBodyOverride() { return CurPostureParam.ActionBlendRule == EActionBlendRule::FullBodyOverride; }

};
