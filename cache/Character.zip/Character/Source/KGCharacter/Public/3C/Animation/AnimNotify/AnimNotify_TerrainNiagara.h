// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "NiagaraSystem.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "AnimNotify_TerrainNiagara.generated.h"

USTRUCT(BlueprintType)
struct FTerrainNiagaraParams
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "特效资产"))
	TSoftObjectPtr<UNiagaraSystem> Niagara;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "特效偏移"))
	FTransform NiagaraTransform;

	/**
	 * 位置偏移基于Socket当前位置,朝向偏移基于当前角色实际朝向
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "特效播放基准骨骼"))
	FName NiagaraBaseSocket;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "特效是否挂接"))
	bool bNiagaraAttach;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "挂接时是否使用绝对朝向"))
	bool bNiagaraUseAbsoluteRotation = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "特效是否贴地"))
	bool bNiagaraStickGround;
};

UCLASS(DisplayName = "单发地形对应特效")
class KGCHARACTER_API UAnimNotify_TerrainNiagara : public UAnimNotify
{
	GENERATED_BODY()
protected:
	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) override;
	
public:
	/**
	 * Key对应[[TerrainMaterial_地表材质.xlsx]]的[[TerrainPhysicalMaterial]]页的[[Name]]列
	 */
	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "地表材质对应特效参数"))
	TMap<FString, FTerrainNiagaraParams> Terrain2Niagara;
};
