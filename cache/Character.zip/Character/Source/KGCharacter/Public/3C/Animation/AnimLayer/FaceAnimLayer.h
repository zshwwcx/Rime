#pragma once

#include "3C/Animation/AnimLayer/BaseAnimLayer.h"
#include "UObject/UnrealType.h"
#include "FaceAnimLayer.generated.h"

UCLASS(BlueprintType, Blueprintable)
class KGCHARACTER_API  UFaceAnimLayer : public UBaseAnimLayer
{
	GENERATED_UCLASS_BODY()

public:

	void NativeInitializeAnimation() override;

	void NativeUpdateAnimation(float DeltaSeconds) override;
	void NativeUninitializeAnimation() override;

public:

	UPROPERTY(BlueprintReadWrite)
	FName FaceControlStructName;

	UPROPERTY(BlueprintReadWrite)
	int FacePerformMode;

	UPROPERTY(BlueprintReadWrite)
	float EyeBlinkWeight = 0.0;

	UPROPERTY(BlueprintReadWrite)
	float FaceBlendWeight = 1.0;

	UFUNCTION(BlueprintCallable)
	void SetDefaultPerformMode(int mode) { DefaultPerformMode = mode; }

	UFUNCTION(BlueprintCallable)
	void SetEyeBlinkWeight(float weight) { EyeBlinkWeight = weight; }

	UFUNCTION(BlueprintCallable)
	void SetFaceBlendWeight(float weight) { FaceBlendWeight = weight; }
	
	UFUNCTION(BlueprintCallable)
	void SetHighPriorityPerformMode(int mode) { HighPriorityPerformMode = mode; }

	UFUNCTION(BlueprintCallable)
	virtual void SetAnimLayerAnimAsset(const TMap<FName, UAnimSequenceBase*>& InAnimMap) override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TMap<FName, UAnimSequenceBase*> FaceAnimMap;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	TMap<FName, float> FaceChannelValueMap;

protected:
	TMap<FName, FProperty*> FaceFloatPropertys;
	TMap<FName, uint8*> FaceFloatPropertyAddrs;
	uint8* FaceContrlStructBaseAddr = nullptr;
	bool SetFloatProperty(FName PropName, float value) override;
	bool SetFloatPropertys(const TMap<FName, float> & floatValues) override;

	int HighPriorityPerformMode = -1;
	
	int DefaultPerformMode = 0;
};