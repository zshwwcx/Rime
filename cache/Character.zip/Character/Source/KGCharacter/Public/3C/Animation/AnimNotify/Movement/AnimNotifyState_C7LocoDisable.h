// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once
#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "3C/Animation/AnimNotify/Movement/AnimNotify_RotateInstantly.h"
#include "AnimNotifyState_C7LocoDisable.generated.h"

class UAnimSequenceBase;

/** AnimNotifyState used to define a motion warping window in the animation */
UCLASS(meta = (DisplayName = "C7 LocoDisable"))
class KGCHARACTER_API UAnimNotifyState_C7LocoDisable : public UAnimNotifyState, public IAnimNotify_MovementControlInterface
{
	GENERATED_BODY()

public:
    void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference) override;
	void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) override;

public:
	// 是否禁止所有位移闪避，包含bDisableLocoMove的功能
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bDisableAllMove = false;
	
	// 禁止输入向量产生，一定也会阻止LocoStart产生
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (EditCondition = "!bDisableAllMove"))
	bool bDisableLocoMove = false;

	// 禁止LocoStart产生，输入向量仍可以存在，与ForceLocoStart不可同时为true
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bDisableLocoStart = false;

	// 强制LocoStart产生，即使输入向量为0，与DisableLocoStart不可同时为true
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bForceLocoStart = false;

	// 是否禁止跳跃（暂时只开放给主玩家）
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bDisableLocoJump = false;

	// 是否禁止闪避（暂时只开放给主玩家）
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bDisableLocoDodge = false;

	// 是否硬控地面支撑，强迫IsGrounded为true，与bForceIgnoreLocoGroundSupport不可同时为true（暂时只开放给主玩家）
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bForceLocoGroundSupport = false;

	// 是否硬取消地面支撑，强迫IsGrounded为false，与bForceLocoGroundSupport不可同时为true（暂时只开放给主玩家）
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bForceIgnoreLocoGroundSupport = false;

#if WITH_EDITOR
public:
	void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

#endif
};

