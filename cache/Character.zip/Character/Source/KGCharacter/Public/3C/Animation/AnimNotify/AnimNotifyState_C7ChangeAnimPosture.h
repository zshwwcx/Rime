// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "AnimNotifyState_C7ChangeAnimPosture.generated.h"

/**
 * 
 */
UCLASS(meta = (DisplayName = "C7 Change Anim Posture"))
class KGCHARACTER_API UAnimNotifyState_C7ChangeAnimPosture : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration) override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(NoResetToDefault))
	FString AnimPostureName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(NoResetToDefault))
	bool TargetValue = false;
};
