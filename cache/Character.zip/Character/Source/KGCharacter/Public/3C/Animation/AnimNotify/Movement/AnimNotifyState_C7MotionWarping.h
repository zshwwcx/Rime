// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once
#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "3C/Animation/AnimCommon.h"
#include "3C/Animation/AnimNotify/Movement/IAnimNotify_MovementControlInterface.h"
#include "AnimNotifyState_C7MotionWarping.generated.h"

class UAnimSequenceBase;

/** AnimNotifyState used to define a motion warping window in the animation */
UCLASS(meta = (DisplayName = "C7 Motion Warping"))
class KGCHARACTER_API UAnimNotifyState_C7MotionWarping : public UAnimNotifyState, public IAnimNotify_MovementControlInterface
{
	GENERATED_BODY()

public:
    void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference) override;
	void NotifyTick(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float FrameDeltaTime, const FAnimNotifyEventReference& EventReference) override;
	void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) override;


	virtual void PreSave(FObjectPreSaveContext ObjectSaveContext) override;

	FName GetWarpTargetName() const { return WarpTargetName; }
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bUsingLocoInput = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (EditCondition = "bUsingLocoInput == false", EditConditionHides))
	bool bNeedReset = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	ERotationWrapDirection WrapRotationDirection = ERotationWrapDirection::Auto;

	UPROPERTY(EditAnywhere, BlueprintReadWrite,  meta = (EditCondition = "bUsingLocoInput == true", EditConditionHides))
	EFaceDirectionInputMode WarpTargetRotationSource = EFaceDirectionInputMode::VelocityDirection;

	UPROPERTY(EditAnywhere, BlueprintReadWrite,  meta = (EditCondition = "bUsingLocoInput == true", EditConditionHides, ClampMin=0.00f, ClampMax=1.0f))
	float LocoInputQueryTime = 0.2;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName WarpTargetName = NAME_None;
};

