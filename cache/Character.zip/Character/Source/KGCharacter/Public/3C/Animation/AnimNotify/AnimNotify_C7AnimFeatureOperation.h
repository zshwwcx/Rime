﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "AnimNotify_C7AnimFeatureOperation.generated.h"

UENUM(BlueprintType, Blueprintable)
enum class EAnimFeatureNotifyType : uint8
{
	AttachItem,
	AnimPoseRdy,
	EnvInteractRdyForOut
};

UENUM(BlueprintType)
namespace EAnimPoseTag
{
	enum Type : int
	{
		Fashion
	};
}

UENUM(BlueprintType, Blueprintable)
enum class EAnimFeatureAttachNotifyType : uint8
{
	Show,
	Hide,
};

USTRUCT(BlueprintType, Blueprintable)
struct FAnimLibAttachItemName
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(NoResetToDefault))
	FString AttachItemName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(NoResetToDefault))
	EAnimFeatureAttachNotifyType AttachNotifyType = EAnimFeatureAttachNotifyType::Show;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(NoResetToDefault))
	bool bAttachFadeInOut = false;
};

/**
 * 
 */
UCLASS(meta = (DisplayName = "C7 Anim Feature Operation"))
class KGCHARACTER_API UAnimNotify_C7AnimFeatureOperation : public UAnimNotify
{
	GENERATED_BODY()
	
public:
	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) override;

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(NoResetToDefault))
	EAnimFeatureNotifyType AnimFeatureType = EAnimFeatureNotifyType::AttachItem;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition="AnimFeatureType == EAnimFeatureNotifyType::AttachItem", EditConditionHides, NoResetToDefault))
	FAnimLibAttachItemName AttachItem;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition="AnimFeatureType == EAnimFeatureNotifyType::AnimPoseRdy", EditConditionHides, NoResetToDefault))
	TEnumAsByte<EAnimPoseTag::Type> PoseRdyTag = EAnimPoseTag::Fashion;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition="AnimFeatureType == EAnimFeatureNotifyType::EnvInteractRdyForOut", EditConditionHides, NoResetToDefault))
	FString EnvInteractTag;
};
