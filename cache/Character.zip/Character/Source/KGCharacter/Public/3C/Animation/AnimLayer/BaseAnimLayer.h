#pragma once

#include "CoreMinimal.h"
#include "3C/Animation/AnimCommon.h"
#include "Animation/AnimInstance.h"
#include "BaseAnimLayer.generated.h"

/**
 * 动画蓝图功能Layer基类
 */
UCLASS(BlueprintType, Blueprintable)
class KGCHARACTER_API UBaseAnimLayer: public UAnimInstance
{
	GENERATED_UCLASS_BODY()

public:
	FString LayerTag;

	TMap<FName, FProperty*> PropertyContainerPtrCacheMap;

	UPROPERTY(BlueprintReadOnly)
	bool bEnableAnimLayerTick = true;
public:
	
	virtual void UpdateAnimLayer(UAnimLayerContext& InOutSharedLayerContext) {}
	virtual bool SetFloatProperty(FName PropName, float value) { return false; }
	virtual bool SetFloatPropertys(const TMap<FName, float> & floatValues) { return false; }
	virtual void SetAnimLayerAnimAsset(const TMap<FName, UAnimSequenceBase*>& InAnimMap){}

	void SetEnableAnimLayerTick(bool bEnable) { bEnableAnimLayerTick = bEnable; }
	
	template<typename PropertyType>
	PropertyType* GetPropertyPtr(FName PropertyName)
	{
		if(FProperty** CachedProperty = PropertyContainerPtrCacheMap.Find(PropertyName))
		{
			if(PropertyType* TypedProperty = CastField<PropertyType>(*CachedProperty))
			{
				return TypedProperty;
			}
			PropertyContainerPtrCacheMap.Remove(PropertyName);
		}
		
		for (TFieldIterator<FProperty> It(this->GetClass(), EFieldIteratorFlags::IncludeSuper); It; ++It)
		{
			if (PropertyType* Property = CastField<PropertyType>(*It))
			{
				if (Property->GetFName() == PropertyName)
				{
					PropertyContainerPtrCacheMap.Add(PropertyName, CastField<FProperty>(Property));
					return Property;
				}
			}
		}
	
		return nullptr;
	}
};
