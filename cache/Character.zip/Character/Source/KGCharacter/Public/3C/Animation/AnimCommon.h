#pragma once

#include "CoreMinimal.h"
#include "3C/Animation/AnimationGraphNode/AnimNode_ThreeLayerPostureBlend.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "Kismet/KismetSystemLibrary.h"
#include "3C/Core/3CCommon.h"
#include "Animation/AnimSequence.h"
#include "Misc/CommonDefines.h"
#include "Animation/BoneSocketReference.h"
#include "CommonAnimTypes.h"
#include "AnimCommon.generated.h"




UENUM(BlueprintType)
enum class EVelocityStableMode: uint8
{
	AvgSpeedMode = 0,
	ThrusterBlendInMode = 1,
};

UENUM(BlueprintType)
enum class EFaceDirectionInputMode : uint8
{
	VelocityDirection = 0,
	CameraControlDirection=1,
};

/**
 * 动画通用声明
 */

UENUM()
enum class ERotationWrapDirection : int8
{
	Auto = 0 UMETA(DisplayName = "自动计算转向方向"),
	Left = 1 UMETA(DisplayName = "逆时针-左方向转"),
	Right = 2 UMETA(DisplayName = "顺时针-右方向转"),
};


//曲线名称定义
UENUM(BlueprintType)
enum class	EAnimCurveName : uint8
{
	//足曲线
	FootState UMETA(DisplayName = "FootState")
};

#define NULL_RETURN_V(param)\
if(!param)\
{\
	return ;\
}\

#define NULL_RETURN_P(param, r)\
if(!param)\
{\
	return r;\
}\

#define VALID_CLASS(classp)\
UKismetSystemLibrary::IsValidClass(classp)\

#define VALID_OBJ(obj)\
UKismetSystemLibrary::IsValid(obj)\

UENUM()
enum class EAttachType : uint8
{
	//开始后直接挂接
	AttachOnAnimBegin,
	//等待动画通知
	AnimNotify
};


//口型资源信息
USTRUCT(BlueprintType)
struct FLipSyncAssetInfo
{
	GENERATED_BODY()
public:
	//类别
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	UStruct* VisemeStruct;

	//角色口型所在文件夹
	UPROPERTY(config, EditAnywhere, Category = Packaging, AdvancedDisplay, meta = (RelativeToGameContentDir))
	TArray<FDirectoryPath> VisemeFolderList;

	//触发表情类
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	UStruct* TriggerFaceStruct;

	//触发表情数据所在文件夹
	UPROPERTY(config, EditAnywhere, Category = Packaging, AdvancedDisplay, meta = (RelativeToGameContentDir))
	TArray<FDirectoryPath> TriggerFaceFolderList;
};

//追踪目标骨骼
USTRUCT(BlueprintType)
struct FTrackTargetBone 
{
	GENERATED_BODY()
public:
	//参考mesh
	UPROPERTY(BlueprintReadWrite)
	TWeakObjectPtr<USkeletalMeshComponent> ReferenceMesh;
	//参考骨骼
	UPROPERTY(BlueprintReadWrite)
	FString ReferenceBone;

	//作用骨骼
	UPROPERTY(BlueprintReadWrite)
	FString EffectBone;

	//作用剩余时间(超过就删除)
	UPROPERTY(BlueprintReadWrite)
	float RemainTime = .0f;

	//是否中断
	UPROPERTY(BlueprintReadWrite)
	bool bBreak = false;

	//作用偏移
	UPROPERTY(BlueprintReadWrite)
	FTransform Offset;
	//最终参考
	UPROPERTY(BlueprintReadWrite)
	FTransform FinalTF;
};

USTRUCT(BlueprintType)
struct FBoneTrackActorInfo
{
	GENERATED_BODY()

public:

	FBoneTrackActorInfo() {};

	FBoneTrackActorInfo(KGObjectID InTrackedActorID, float InSpeed, FVector InTargetPosOffset, float InTrackDuration)
		:TrackedActorID(InTrackedActorID),
		Speed(InSpeed),
		TargetPosOffset(InTargetPosOffset),
		TrackDuration(InTrackDuration){};

	KGObjectID TrackedActorID;

	UPROPERTY(BlueprintReadWrite)
	float Speed;

	FVector TargetPosOffset;

	float RunningDuration = 0;

	float TrackDuration = 0;

};

//动画资源规范ID
USTRUCT(BlueprintType, Blueprintable)
struct KGCHARACTER_API FAnimAssetID
{
	GENERATED_BODY()

	FAnimAssetID() {};

	FAnimAssetID(FString InID)
		:AssetID(InID)
	{};

	FAnimAssetID(FString InID, int InAssetCategory)
		:AssetID(InID)
		, AssetCategory(InAssetCategory)
	{
	}

	FORCEINLINE bool operator==(const FAnimAssetID& Other)
	{
		return Other.GetID() == AssetID;
	}

	friend inline bool operator==(const FAnimAssetID& A, const FAnimAssetID& B)
	{
		return A.AssetID == B.AssetID;
	}

	friend inline uint32 GetTypeHash(const FAnimAssetID& Key)
	{
		uint32 Hash = 0;

		Hash = HashCombine(Hash, GetTypeHash(Key.AssetID));
		return Hash;
	}

public:
	FString GetID()const { return AssetID; }

	FName GetNameID() const { return FName(AssetID); }

#if WITH_EDITOR
public:
	//获取对应集合规范名称列表
	static void GetAnimAssetNameList(int AssetCategory, TArray<FString>& OutNameList);

	static void GetAnimCategoryList(TArray<FString>& OutNameList);
#endif

public:
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FString AssetID;

public:
	int AssetCategory = 0;
};

//基础动画资源规范ID
USTRUCT(BlueprintType)
struct KGCHARACTER_API FAnimAssetID_BaseAnim : public FAnimAssetID
{
	GENERATED_BODY()
	FAnimAssetID_BaseAnim()
		:FAnimAssetID("", 0) {};

	FAnimAssetID_BaseAnim(FString InID)
		:FAnimAssetID(InID, 0) {};
};


USTRUCT(BlueprintType, Blueprintable)
struct KGCHARACTER_API FDynamicMontageParam
{
	GENERATED_BODY()

public:
	UPROPERTY(Transient,BlueprintReadWrite)
	UAnimSequenceBase* Asset = nullptr;

	UPROPERTY(Transient, BlueprintReadWrite)
	FName SlotNodeName = "DefaultSlot";

	UPROPERTY(Transient, BlueprintReadWrite)
	float BlendInTime = 0.25f;

	UPROPERTY(Transient, BlueprintReadWrite)
	float BlendOutTime = 0.25f; 

	UPROPERTY(Transient, BlueprintReadWrite)
	float InPlayRate = 1.0f; 

	UPROPERTY(Transient, BlueprintReadWrite)
	int32 LoopCount = 1; 

	UPROPERTY(Transient, BlueprintReadWrite)
	float BlendOutTriggerTime = -1.0f;

	UPROPERTY(Transient, BlueprintReadWrite)
	float InTimeToStartMontageAt = 0.0f;

	UPROPERTY(Transient, BlueprintReadWrite)
	TArray<FName> MetaCurves;
};

UCLASS()
class KGCHARACTER_API UAnimCommonUtility : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintPure, meta = (DisplayName = "CurveName", CompactNodeTitle = "->", BlueprintAutocast), Category = "AnimCommonUtility")
	static FName GetAnimCurveName(EAnimCurveName CurveNameType)
	{
		static UEnum* EAnimCurveNameEnum = StaticEnum<EAnimCurveName>();

		if (EAnimCurveNameEnum)
		{
			FText Name = EAnimCurveNameEnum->GetDisplayNameTextByIndex((uint8)CurveNameType);
			return FName(Name.ToString());
		}

		return FName();
	};
	//根据曲线数据获取当前是否出左脚
	UFUNCTION(BlueprintPure, meta = (BlueprintThreadSafe))
	static bool IsLeftFootState(const float& CurFootCurveValue, const float& LastFootCurveValue);

	//UFUNCTION(BlueprintCallable)
	//static void DestoryObject(UObject* Obj);

	UFUNCTION(BlueprintCallable)
	static class UAnimMontage* CreateDynamicMontage(const FDynamicMontageParam& CreateParam);

	UFUNCTION(BlueprintCallable)
	void AddMetaDataCurveRuntime(UAnimSequenceBase* Montage,FName& CurveName);

};





class UAnimLayerSharedData;

#define DECLARE_SHARED_DATA(Struct)\
protected:\
	Struct _##Struct;\
public:\
	const Struct& Get##Struct()\
	{\
		return _##Struct;\
	};\
	void Struct##FreshData(const UAnimLayerContext* InLayerContext)\
	{\
		_##Struct.FreshData(InLayerContext);\
	};\
	\
	static const Struct& Get##Struct(UAnimLayerContext* InLayerContext)\
	{\
		check(InLayerContext);\
		check(InLayerContext->AnimLayerSharedData);\
		const Struct& _Struct = InLayerContext->AnimLayerSharedData->Get##Struct();\
		if(!InLayerContext->AnimLayerSharedData->CheckRefreshed((int64)(&_Struct)))\
		{\
			InLayerContext->AnimLayerSharedData->Struct##FreshData(InLayerContext);\
			InLayerContext->AnimLayerSharedData->MarkRefreshed((int64)(&_Struct));\
		}\
		return _Struct;\
	};\

//Movement
USTRUCT(BlueprintType)
struct FSharedMovementInfo
{
	GENERATED_BODY()

public:
	//当前位置
	UPROPERTY(Transient, BlueprintReadOnly)
	FVector Pos = FVector::ZeroVector;
	//当前速度
	UPROPERTY(Transient, BlueprintReadOnly)
	float Speed = .0f;
	//速度方向
	UPROPERTY(Transient, BlueprintReadOnly)
	FVector VelocityDir = FVector::ZeroVector;
	//是否输入加速度
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bAcceleration = false;
	//运动状态
	UPROPERTY(Transient, BlueprintReadOnly)
	ESpeedStage SpeedState = ESpeedStage::Idle;
	//角色 前向
	UPROPERTY(Transient, BlueprintReadOnly)
	FVector ForwardDir = FVector::ZeroVector;
	//角色 右向
	UPROPERTY(Transient, BlueprintReadOnly)
	FVector RightDir = FVector::ZeroVector;
	//角色 上向
	UPROPERTY(Transient, BlueprintReadOnly)
	FVector UpDir = FVector::ZeroVector;

public:
	void FreshData(const UAnimLayerContext* InLayerContext);
};

//BoneTransform
// USTRUCT(BlueprintType)
// struct FSharedBoneTransformInfo
// {
// 	GENERATED_BODY()
// public:
// 	//面朝方向
// 	UPROPERTY(Transient, BlueprintReadOnly)
// 	FRotator FaceRotator = FRotator::ZeroRotator;
// 	//面部位置
// 	UPROPERTY(Transient, BlueprintReadOnly)
// 	FVector FacePos = FVector::ZeroVector;
// 	//Root位置
// 	UPROPERTY(Transient, BlueprintReadOnly)
// 	FVector RootPos = FVector::ZeroVector;
// 	//ik_foot_l TF
// 	UPROPERTY(Transient, BlueprintReadOnly)
// 	FTransform IKFootLTF = FTransform::Identity;
// 	//ik_foot_r TF
// 	UPROPERTY(Transient, BlueprintReadOnly)
// 	FTransform IKFootRTF = FTransform::Identity;
//
// 	UPROPERTY(Transient, BlueprintReadOnly)
// 	FTransform Eye_l = FTransform::Identity;
// 	UPROPERTY(Transient, BlueprintReadOnly)
// 	FTransform Eye_R = FTransform::Identity;
// 	
//
// public:
// 	void FreshData(const UAnimLayerContext* InLayerContext);
// };


UCLASS(BlueprintType)
class KGCHARACTER_API UAnimLayerContext : public UObject
{
	GENERATED_UCLASS_BODY()

public:
	//间隔时间(s)
	UPROPERTY(BlueprintReadWrite, Transient, Category = "Time")
	float DeltaTime = .0f;

	//当前角色位置
	UPROPERTY(BlueprintReadWrite, Transient, Category = "Character|Move")
	FVector Pos;

	//角色
	UPROPERTY(BlueprintReadWrite, Transient, Category = "Character")
	TWeakObjectPtr<class AActor> Character = nullptr;

	//基础角色(非该类型为空)
	UPROPERTY(BlueprintReadWrite, Transient, Category = "Character")
	TWeakObjectPtr<class ABaseCharacter> BaseCharacter = nullptr;
	//角色的骨骼Mesh(目前修改一个SKMesh)
	UPROPERTY(BlueprintReadWrite, Transient, Category = "Character|Anim")
	TWeakObjectPtr<class USkeletalMeshComponent> SMC = nullptr;
	//角色动画蓝图实例
	UPROPERTY(BlueprintReadWrite, Transient, Category = "Character|Anim")
	TWeakObjectPtr<class UBaseAnimInstance> AnimInstance = nullptr;

	//移动组件
	UPROPERTY(BlueprintReadWrite, Transient, Category = "Character|Movement")
	TWeakObjectPtr<class UCharacterMovementComponent> CharacterMovementC = nullptr;

public:
	//共享数据
	UPROPERTY(BlueprintReadOnly, Transient, Category = "Character|Anim")
	UAnimLayerSharedData* AnimLayerSharedData = nullptr;

	//角色属性值 Int
	UPROPERTY(BlueprintReadWrite, Transient, Category = "Character|Anim")
	TMap<FString, int32> PropIntValueMap;
	//角色属性值 Float
	UPROPERTY(BlueprintReadWrite, Transient, Category = "Character|Anim")
	TMap<FString, float> PropFloatValueMap;
	//角色属性值 String
	UPROPERTY(BlueprintReadWrite, Transient, Category = "Character|Anim")
	TMap<FString, FString> PropStringValueMap;


	UFUNCTION(BlueprintPure)
	int32 GetPropValue(const FString& PropName);

public:
	//获取角色骨骼Mesh
	UFUNCTION(BlueprintPure, Category = "Mesh")
	class USkeletalMeshComponent* GetOwnSkeletalMeshComponent() { return SMC.Get(); };
};


//共享数据类
// 所有结构体必需有 void FreshData(const UAnimLayerContext* InLayerContext);
UCLASS(BlueprintType)
class KGCHARACTER_API UAnimLayerSharedData : public UObject
{
	friend class UAnimLayerContext;

	GENERATED_UCLASS_BODY()

public:
	void Reset(UAnimLayerContext* InLayerContext);

protected:
	bool CheckRefreshed(int64 Address);
	void MarkRefreshed(int64 Address);

	//Movement
	DECLARE_SHARED_DATA(FSharedMovementInfo)
	//BoneTransform
	// DECLARE_SHARED_DATA(FSharedBoneTransformInfo)


private:
	
	TWeakObjectPtr<UAnimLayerContext> AnimLayerContext = nullptr;

	TSet<int64> MarkRefreshedSet;
};

namespace C7ThreeLayerAnimationConst
{
	static const FName ACTION_LAYER_SLOT = TEXT("Action");
	static const FName PERFORM_ADDITIVE_LAYER_SLOT = TEXT("PerformAdditive");
	static const FName LOWER_LOCO_LAYER_SLOT = TEXT("PerformAdditive");
}

UENUM()
namespace EThreeLayerAnimationType
{
	enum Type : uint8
	{
		None,
		Action,
		PerformAdditive,
	};
}

UENUM()
namespace EAnimStopReason
{
	enum Type : uint8
	{
		AutoBlendOut,
		PositiveStop,
		StopByOther,
		ReplacePlay,
		LoadAssetError,
		PlayError,
		ParamsReset
	};
}

using KGAnimPlayReqID = int64;

struct KGAnimPlayViewConfig
{
	KGAnimPlayReqID AnimPlayReqID = 0;
	float PlayRate = 1.f;
	float BlendInTime = -1.f;
	float BlendOutTime = -1.f;
	float TimeToStopMontageAt = 0.f;
	float TimeToStartMontageAt = 0.f;
	int FilterBoneDepth = 1;

	KGAnimPlayReqID LeadingAnimPlayReqID = 0;
	KGObjectID SKMeshID = 0;
	
	TWeakObjectPtr<UAnimMontage> PlayingMontage = nullptr;
	
	bool bLoop = false;
	bool bDisableRootMotion = false;
	bool bAutoStop = false;
	bool bLeadingAnimation = false;
	bool bFollowAnimation = false;
	bool bSingleAnimationMode = false;
	bool bRefreshViewWhenSameMontage = true;
	bool bActionMeshSpaceBlend = false;
	bool bLowerLocoWork = false;
	bool bPause = false;

	bool bHasRepeatMontage = false;
	bool bRepeatDisableRootMotion = false;

	bool bCustomBlendInArgs = false;
	bool bCustomBlendOutArgs = false;
	EAlphaBlendOption BlendInOption = EAlphaBlendOption::Linear;
	EAlphaBlendOption BlendOutOption = EAlphaBlendOption::Linear;

	EActionBlendRule ActionBlendRule = EActionBlendRule::FullBodyOverride; 
	EThreeLayerAnimationType::Type ThreeLayerAnimationType = EThreeLayerAnimationType::None; 

	FName FilterBoneName = NAME_None;
	FName JumpToSection = NAME_None;
	FName LayerName = NAME_None;
	FName AnimSlotName = NAME_None;
};

struct KGAnimPlayReqConfig
{
	KGAnimPlayReqID GUID = 0;
	int LoopCount = 1;
	int64 PlayTimeStamp = 0;

	KGObjectID SKMeshID = 0;

	bool bAdaptivePlayTimeStamp = true;
	bool bWithOutCache = false;
	bool bLowPriorityAnim = false;

	FName AnimSlotName = NAME_None;
	FString AnimPath;
	FString CallBackLuaFuncName;

	TSharedPtr<KGAnimPlayViewConfig> AnimViewConfig;
};

UENUM(BlueprintType)
enum class EC7BoneModificationMode : uint8
{
	/** The modifier ignores this channel (keeps the existing bone translation, rotation, or scale). */
	BMM_Ignore UMETA(DisplayName = "Ignore"),

	/** The modifier replaces the existing translation, rotation, or scale. */
	BMM_Replace UMETA(DisplayName = "Replace Existing"),

	/** The modifier adds to the existing translation, rotation, or scale. */
	BMM_Additive UMETA(DisplayName = "Add to Existing")
};

USTRUCT(BlueprintType)
struct FC7ModifyBones_Params
{
	GENERATED_USTRUCT_BODY()

	/** Name of bone to control. This is the main bone chain to modify from. **/
	UPROPERTY(EditAnywhere, Category=SkeletalControl) 
	FName BoneToModify;

	UPROPERTY(EditAnywhere, Category=SkeletalControl) 
	EC7BoneModificationMode TranslationMode;

	UPROPERTY(EditAnywhere, Category=SkeletalControl) 
	EC7BoneModificationMode RotationMode;

	UPROPERTY(EditAnywhere, Category=SkeletalControl) 
	EC7BoneModificationMode ScaleMode;

	UPROPERTY(EditAnywhere, Category=SkeletalControl) 
	TEnumAsByte<EBoneControlSpace> BoneControlSpace;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=SkeletalControl, meta=(PinShownByDefault))
	FTransform Transform = FTransform(FRotator::ZeroRotator, FVector::ZeroVector, FVector(1.0f));

	UPROPERTY(EditAnywhere, Category=SkeletalControl)
	FName AlphaCurveName = NAME_None;

	UPROPERTY(EditAnywhere, Category=SkeletalControl)
	float AlphaDefaultValue = 0;
	
	UPROPERTY(EditAnywhere, Category=SkeletalControl)
	float BlendAlpha = 1.0f;
};

UENUM(BlueprintType)
enum class EC7TwoBoneIKModificationMode : uint8
{
	/** The modifier replaces the existing translation, rotation, or scale. */
	TBMM_Replace UMETA(DisplayName = "Replace Existing"),

	/** The modifier adds to the existing translation, rotation, or scale. */
	TBMM_Additive UMETA(DisplayName = "Add to Existing")
};

USTRUCT(BlueprintType)
struct FC7BatchTwoBoneIKB_Params
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, Category=SkeletalControl)
	FBoneReference IKBone;

	UPROPERTY(EditAnywhere, Category = SkeletalControl)
	FBoneSocketTarget JointTarget;
	
	UPROPERTY(EditAnywhere, Category=SkeletalControl)
	FBoneSocketTarget EffectorTarget;
	
	UPROPERTY(EditAnywhere, Category=SkeletalControl) 
	TEnumAsByte<EBoneControlSpace> EffectorLocationSpace = EBoneControlSpace::BCS_ComponentSpace;

	UPROPERTY(EditAnywhere, Category=SkeletalControl) 
	EC7TwoBoneIKModificationMode EffectorLocationMode = EC7TwoBoneIKModificationMode::TBMM_Replace;
	
	/** Reference frame of Joint Target Location. */
	UPROPERTY(EditAnywhere, Category=SkeletalControl)
	TEnumAsByte<enum EBoneControlSpace> JointTargetLocationSpace = EBoneControlSpace::BCS_ComponentSpace;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=SkeletalControl, meta=(PinShownByDefault))
	FVector EffectorLocation {0, 0, 0};
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=SkeletalControl, meta=(PinShownByDefault))
	FVector JointTargetLocation{0, 0, 0};

	UPROPERTY(EditAnywhere, Category=SkeletalControl)
	FName AlphaCurveName = NAME_None;

	UPROPERTY(EditAnywhere, Category=SkeletalControl)
	float AlphaDefaultValue = 0.f;

	UPROPERTY(EditAnywhere, Category=SkeletalControl)
	float BlendAlpha = 1.0f;

	UPROPERTY(EditAnywhere, Category=SkeletalControl)
	FAxis TwistAxis{FVector::ForwardVector};

	UPROPERTY(EditAnywhere, Category=SkeletalControl)
	float StartStretchRatio = 1.0f;
	UPROPERTY(EditAnywhere, Category=SkeletalControl)
	float MaxStretchScale = 1.2f;

	UPROPERTY(EditAnywhere, Category=SkeletalControl)
	bool bAllowStretching = false;
	UPROPERTY(EditAnywhere, Category=SkeletalControl)
	bool bAllowTwist = true;
	
	UPROPERTY(EditAnywhere, Category=SkeletalControl)
	bool bTakeRotationFromEffectorSpace = false;

	/** Keep local rotation of end bone */
	UPROPERTY(EditAnywhere, Category = SkeletalControl)
	bool bMaintainEffectorRelRot = false;
};

UENUM(BlueprintType)
enum class ELogicParentFeatureSynchronizeMask : uint8
{
	None = 0,
	AnimationLocoState = 1 << 0
};

UENUM(BlueprintType)
enum class EBodyLeanAxisDataSource : uint8
{
	None,				// 不做计算
	FaceRadian,			// 输入向量
	AngleAccumulate,	// 角度累计
	DestAngle			// 目标角度
};

UENUM(BlueprintType)
enum class EMountType : uint8
{
	Bike = 0,
	Horse = 1,
	Car = 2,
};

enum class EDialogueStage : uint8
{
	None,
	Idle,
	MoveStart,
	MoveLoop,
	MoveEnd
};

USTRUCT(BlueprintType)
struct FIKConfig_HandFoot
{
	GENERATED_BODY()
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FName HandLBoneName = FName("hand_l");
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FName HandRBoneName = FName("hand_R");
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FName FootLBoneName = FName("foot_l");
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FName FootRBoneName = FName("foot_r");

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FName HandLJointBoneName = FName("lowerarm_l");
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FName HandRJointBoneName = FName("lowerarm_r");
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FName FootLJointBoneName = FName("calf_l");
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FName FootRJointBoneName = FName("calf_r");
	
	// 坐骑 IK 目标骨骼
	FName MountHandLBoneName;
	FName MountHandRBoneName;
	FName MountFootLBoneName;
	FName MountFootRBoneName;

	bool bEnableHandIK = false;
	bool bEnableFootIK = false;

	void Reset()
	{
		bEnableHandIK = false;
		bEnableFootIK = false;
		MountHandLBoneName = NAME_None;
		MountHandRBoneName = NAME_None;
		MountFootLBoneName = NAME_None;
		MountFootRBoneName = NAME_None;
	}
};

USTRUCT(BlueprintType)
struct FIKConfig_Common
{
	GENERATED_BODY()
	// 眼皮 IK
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FName LEyeIKBoneName = FName("lf_downeyelid_root");
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FVector LEyeIkLoc = FVector(0, -0.1, 0);
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FName REyeIKBoneName = FName("rt_downeyelid_root");
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FVector REyeIkLoc = FVector(0, 0.1, 0);
	
	UPROPERTY(EditDefaultsOnly, Transient)
	FName HeadBoneName = "head";

	UPROPERTY(EditDefaultsOnly, Transient)
	FName Spine02BoneName = "spine_02";

	UPROPERTY(EditDefaultsOnly, Transient)
	FName Neck01BoneName = "neck_01";

	UPROPERTY(EditDefaultsOnly, Transient)
	FName LEyeBallBoneName = "lf_eyeBall";
	
	UPROPERTY(EditDefaultsOnly, Transient)
	FName REyeBallBoneName = "rt_eyeBall";
};

USTRUCT(BlueprintType)
struct FWheelInfo
{
	GENERATED_BODY()
	
	UPROPERTY(EditAnywhere)
	FBoneReference IKBone;

	UPROPERTY(EditAnywhere)
	float WheelRadius = 0;
	
	UPROPERTY(EditAnywhere)
	float SphereTraceRadius = 2;

	UPROPERTY(EditAnywhere)
	FVector Axis = FVector(0, 0, 1);
};

USTRUCT(BlueprintType)
struct FIKConfig_Mount
{
	GENERATED_BODY()
	// 自行车 IK 骨骼
	UPROPERTY(EditDefaultsOnly, Transient)
	FName Bike_Wheel_F = "Bike_Tire_01";
	UPROPERTY(EditDefaultsOnly, Transient)
	FName Bike_Wheel_B = "Bike_Tire_02";
	UPROPERTY(EditDefaultsOnly, Transient)
	FName Bike_Handle = "Bike_Handle";
	UPROPERTY(EditDefaultsOnly, Transient)
	FName Bike_Seat = "Bike_Seat";
	UPROPERTY(EditDefaultsOnly, Transient)
	FName Bike_Root = "root";
};

class FCommonHumanSkeletonBoneNames
{
public:
	inline static const FName  GetHead() {return FName("head");}
	inline static const FName  GetPelvis() {return FName("pelvis");}
	inline static const FName  GetSpine_01() {return FName("spine_01");}
	inline static const FName  GetSpine_02() {return FName("spine_02");}
	inline static const FName  GetSpine_03() {return FName("spine_03");}
	inline static const FName  GetLEyeBall() {return FName("lf_eyeBall");}
	inline static const FName  GetREyeBall() {return FName("rt_eyeBall");}
	inline static const FName  GetLEyeBall_01() {return FName("lf_eyeBall_01");}
	inline static const FName  GetREyeBall_01() {return FName("rt_eyeBall_01");}
	inline static const FName  GetFootL() {return FName("foot_l");}
	inline static const FName  GetFootR() {return FName("foot_r");}
	
	inline static const FName  GetIKFootL() {return FName("ik_foot_l");}
	inline static const FName  GetIKFootR() {return FName("ik_foot_r");}
	inline static const FName  GetVBIkFootLOffset() {return FName("VB ik_foot_l_Offset");}
	inline static const FName  GetVBIkFootROffset() {return FName("VB ik_foot_r_Offset");}
	inline static const FName  GetVBIkKneeTargetL() {return FName("VB ik_knee_target_l");}
	inline static const FName  GetVBIkKneeTargetR() {return FName("VB ik_knee_target_r");}
};

/** --------------------------------------- Gaze Start----------------------------------------------------- */
//凝视目标类型
UENUM(BlueprintType)
enum class EGazeTargetType : uint8
{
	//无
	None,
	//战斗
	// Fight,
	// //场景物体
	// SceneTarget,
	//摄像机(近景面中心点)
	Camera,
	//将屏幕坐标，投射到3D空间
	ScreenPos,
	//通过GazeCoord坐标自定义，（0，0）最左上角 （1，1）最右下角
	CustomGazeCoord,
	//固定世界坐标
	WorldPos,
	// 世界中Actor
	Character,
};

USTRUCT(BlueprintType)
struct FAnimGazeConfig
{
	GENERATED_BODY()

public:
	float LocationInterpSpeed = 1;
	
	//回正角度
	float HorClampAngle = 70;
	float VerClampAngle = 70;
	
	//眼部偏转速度
	float EyeRotateSpeed = 5.0f;
	//头部水平限制角度0:无限制
	FVector2D EyeClampHoriz = FVector2D(-30.f,30.f);
	//头部垂直限制角度0:无限制
	FVector2D EyeClampVert = FVector2D(-30.f, 30.f);
	
	//头部转向速度
	float HeadRotateSpeed = 1.0f;
	//头部水平限制角度0:无限制
	FVector2D HeadClampHoriz = FVector2D(-30.f,30.f);
	//头部垂直限制角度0:无限制
	FVector2D HeadClampVert = FVector2D(-30.f, 30.f);

	//头部转向速度
	float NeckRotateSpeed = 1.0f;
	float NeckRotateBlendRate = 0.3f;
	//脖子水平限制角度0:无限制
	FVector2D NeckClampHoriz = FVector2D(-30.f,30.f);
	//脖子垂直限制角度0:无限制
	FVector2D NeckClampVert = FVector2D(-30.f, 30.f);
	
	//腰部旋转速度
	float SpineRotateSpeed = 1.0f;
	float SpineRotateBlendRate = 0.1f;
	//腰部水平限制角度0:无限制
	FVector2D SpineClampHoriz = FVector2D(-10.f, 10.f);
	//腰部垂直限制角度0:无限制
	FVector2D SpineClampVert = FVector2D(-3.f, 3.f);
	
	//凝视位置偏移
	FVector GazePosOffset = FVector(0,0,0);

	//Coord模式下 最大角度
	FVector2D GazeCoordRange = FVector2D(0,0);

	//Coord模式下 眼睛聚焦的位置
	float GazeCoordDist = 100;

	//WorldPos模式下头部朝向的位置
	FVector GazeWorldPos = FVector(0, 0, 0);

	//Character模式下头部朝向的角色
	TWeakObjectPtr<AActor> GazeCharacter = nullptr;

	//Character模式下头部朝向的角色socket
	FString GazeCharacterSocket;

	//最大凝视距离
	float GazeMaxDistanceLimit = -1;
	FVector GazeCharacterSocketOffset;

	//是否瞬间执行 Gaze 转向
	bool bGazeInstant = false;
	
	//Alpha进入插值
	float GazeAlphaInSpeed = 2;

	//Alpha停止插值
	float GazeAlphaOutSpeed = 1.5;

	//Alpha缓入缓出类型
	EAlphaBlendOption GazeEasyInOutExp = EAlphaBlendOption::Linear;

	// Alpha 系数
	float EyeAlphaCoefficient = 1;
	float HeadAlphaCoefficient = 1;
	float NeckAlphaCoefficient = 1;
	float SpineAlphaCoefficient = 1;
};

USTRUCT(BlueprintType)
struct FAnimGazeBoneNames
{
	GENERATED_BODY()
public:
	UPROPERTY(BlueprintReadWrite, Transient)
	FName HeadBoneName = "head";

	UPROPERTY(BlueprintReadWrite, Transient)
	FName FaceBoneName = "face_root";

	UPROPERTY(BlueprintReadWrite, Transient)
	FName LEyeBoneName = "lf_eyeBall_01";

	UPROPERTY(BlueprintReadWrite, Transient)
	FName REyeBoneName = "rt_eyeBall_01";
	
	UPROPERTY(BlueprintReadWrite, Transient)
	FName RootBoneName = "root";
};


USTRUCT(BlueprintType)
struct FAnimGazeData
{
	GENERATED_BODY()
public:
	UPROPERTY(BlueprintReadWrite, Transient)
	float GazeAlpha = .0f;
	
	//眼部偏移(垂直)
	UPROPERTY(BlueprintReadWrite, Transient)
	float LEyeRotate_Vert = .0f;
	//眼部偏移(水平)
	UPROPERTY(BlueprintReadWrite, Transient)
	float LEyeRotate_Horiz = .0f;
	
	//眼部偏移(垂直)
	UPROPERTY(BlueprintReadWrite, Transient)
	float REyeRotate_Vert = .0f;
	//眼部偏移(水平)
	UPROPERTY(BlueprintReadWrite, Transient)
	float REyeRotate_Horiz = .0f;
	
	//头部偏移(垂直)
	UPROPERTY(BlueprintReadWrite, Transient)
	float HeadRotate_Horiz = .0f;
	//头部偏移(水平)
	UPROPERTY(BlueprintReadWrite, Transient)
	float HeadRotate_Vert = .0f;

	//颈部偏移(水平)
	UPROPERTY(BlueprintReadWrite, Transient)
	float NeckRotate_Horiz = .0f;
	//颈部偏移(垂直)
	UPROPERTY(BlueprintReadWrite, Transient)
	float NeckRotate_Vert = .0f;
	
	//腰部偏移(水平)
	UPROPERTY(BlueprintReadWrite, Transient)
	float SpineRotate_Horiz = .0f;
	//腰部偏移(垂直)
	UPROPERTY(BlueprintReadWrite, Transient)
	float SpineRotate_Vert = .0f;


	UPROPERTY(BlueprintReadWrite, Transient)
	FVector GazePos;

	UPROPERTY(BlueprintReadWrite, Transient)
	FVector2D GazeScreenPos;

	UPROPERTY(BlueprintReadWrite, Transient)
	FVector2D GazeCoord;
	
	UPROPERTY(BlueprintReadWrite, Transient)
	FVector CurrentTargetPos;

	UPROPERTY(BlueprintReadWrite, Transient)
	float bFirstUpdate = false;

	float AlphaBlendMin = 0.f;
	
	FVector HeadPos = FVector::ZeroVector;
	FRotator HeadRotator = FRotator::ZeroRotator;
	FVector HeadForward =FVector::ZeroVector;
	FVector HeadUp = FVector::ZeroVector;
	FVector HeadRight =FVector::ZeroVector;
	
	FVector ForwardDir = FVector::ZeroVector;
	FVector RightDir = FVector::ZeroVector;
	FVector UpDir = FVector::ZeroVector;
	FVector Eye_L_Pos = FVector::ZeroVector;
	FRotator Eye_L_Rot = FRotator::ZeroRotator;
	FVector Eye_R_Pos = FVector::ZeroVector;
	FRotator Eye_R_Rot = FRotator::ZeroRotator;
	
	float LEyeRotate_HorizTarget = .0f;
	float LEyeRotate_VertTarget = .0f;
	float REyeRotate_HorizTarget = .0f;
	float REyeRotate_VertTarget = .0f;
	float HeadRotate_HorizTarget = .0f;
	float HeadRotate_VertTarget = .0f;
	float SpineRotate_HorizTarget = .0f;
	float SpineRotate_VertTarget = .0f;
	float NeckRotate_HorizTarget = .0f;
	float NeckRotate_VertTarget = .0f;
	
	float CacheHeadRotate_Horiz; 
	float CacheHeadRotate_Vert;
	float CacheNeckRotate_Horiz; 
	float CacheNeckRotate_Vert;
	float CacheSpineRotate_Horiz;
	float CacheSpineRotate_Vert;
	float CacheLEyeRotate_Horiz; 
	float CacheLEyeRotate_Vert;
	float CacheREyeRotate_Horiz;
	float CacheREyeRotate_Vert;
};
/** --------------------------------------- Gaze End----------------------------------------------------- */

#pragma region ALS

UENUM(BlueprintType)
enum class EALS_OverLayState : uint8
{
	Default,
	Pistol_1H, // 单手手枪,这里和ALS原生有区别,ALS是全程单手,C7是移动单手,瞄准双手
};

#pragma endregion ALS
