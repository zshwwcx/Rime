#pragma once
#include "CoreMinimal.h"
#include "FaceAnim.generated.h"

//单帧口型信息
USTRUCT(BlueprintType)
struct FAudio2FaceFrameData
{
	GENERATED_BODY()
public:
	UPROPERTY(BlueprintReadWrite)
	TMap<FName, float> LibValues;
};

USTRUCT(BlueprintType)
struct FAnimAudioData
{
	GENERATED_BODY()
public:
	UPROPERTY(BlueprintReadWrite)
	FString AudioName;
};

USTRUCT(BlueprintType)
struct FFaceEmotionAnimData
{
	GENERATED_BODY()
public:
	UPROPERTY(BlueprintReadWrite)
	FString AnimName;

	UPROPERTY(BlueprintReadWrite)
	bool bRemainEndPose = false;

	UPROPERTY(BlueprintReadWrite)
	float BlendInTime = .25f;

	UPROPERTY(BlueprintReadWrite)
	float BlendOutTime = .25f;
};

USTRUCT(BlueprintType)
struct FFaceAnimFrameData 
{
	GENERATED_BODY()
public:
	UPROPERTY(BlueprintReadWrite)
	FAudio2FaceFrameData Lips;

	UPROPERTY(BlueprintReadWrite)
	FAnimAudioData AudioPlay;

	UPROPERTY(BlueprintReadWrite)
	FFaceEmotionAnimData FaceEmotion;
};

USTRUCT(BlueprintType)
struct FFaceAnimSeqData
{
	GENERATED_BODY()
public:
	UPROPERTY(BlueprintReadWrite)
	FString Name;

	UPROPERTY(BlueprintReadWrite)
	float FpsTime = 0.015f;
	
	UPROPERTY(BlueprintReadWrite)
	float FixTime = .0f;

	UPROPERTY(BlueprintReadWrite)
	TArray<FFaceAnimFrameData> FaceAnimFrames;

public:
	void Reset()
	{
		Name.Empty();
		FpsTime = 0.015f;
		FaceAnimFrames.Empty();
	}
};

USTRUCT(BlueprintType)
struct FFaceAnimState 
{
	GENERATED_BODY()
public:
	UPROPERTY(BlueprintReadWrite)
	bool bRunning = false;

	UPROPERTY(BlueprintReadWrite)
	float FixTime = .0f;

	UPROPERTY(BlueprintReadWrite)
	float CurFixTime = .0f;

	UPROPERTY(BlueprintReadWrite)
	float LipBlend = 1.0f;

	UPROPERTY(BlueprintReadWrite)
	float ElapsedTime = .0f;

	UPROPERTY(BlueprintReadWrite)
	int32 Frame = 0;

	UPROPERTY(BlueprintReadWrite)
	float EndFrame = 0;

	UPROPERTY(BlueprintReadWrite)
	float DeltaTime = 0.0166f;

	void Reset()
	{
		bRunning = false;
		ElapsedTime = .0f;
		Frame = 0;
		EndFrame = 0;
		DeltaTime = 0.015f;
	}
};

UENUM(BlueprintType)
enum class EFaceAnimModeType : uint8
{
	Tick = 0,
	Frame
};

//音频面部动画,Audio2Face的应用 @hujianglong @lichaofan
//https://docs.corp.kuaishou.com/k/home/VUWXkE7Tn2QE/fcACZcAaUjFF6MhDoXf5tW971
//https://docs.corp.kuaishou.com/d/home/fcABXorv-ckr8eVIWee2qZ-qJ#section=h.s9ix5u4mmimg
UCLASS(BlueprintType, Blueprintable)
class KGCHARACTER_API UFaceAnim : public UObject
{
	GENERATED_BODY()
public:
	UFaceAnim();

public:
	//初始化
	UFUNCTION(BlueprintCallable)
	void Init(class USkeletalMeshComponent* InMesh, UFaceAnimLayer* FaceLayerPtr, EFaceAnimModeType Type, const FString & faceAnimLayerTag);

	//更新
	UFUNCTION(BlueprintCallable)
	void Update(float DeltaTime);


	//帧更新
	UFUNCTION(BlueprintCallable)
	void UpdateFrame(float CurFrameTime);


	void SetLipBlend(float);
	void SetFaceFloatParam(const FName& key, float value);

public:
	//重置
	UFUNCTION(BlueprintCallable)
	void Reset();

	//播放
	UFUNCTION(BlueprintCallable)
	void Play(const FString& FaceAnimID, float FixTime = 0.0f, float LipBlend = 1.0f);

	//暂停
	UFUNCTION(BlueprintCallable)
	void Pause();

	//停止
	UFUNCTION(BlueprintCallable)
	void Stop();

public:
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable)
	void OnUpdate();

public:
	UFUNCTION(BlueprintCallable)
	void InnerPlay(FFaceAnimSeqData InFaceSeq);

	UFUNCTION(BlueprintCallable)
	FFaceAnimSeqData InnerLoadFaceFile(const FString& FaceAnimID);

	UFUNCTION(BlueprintCallable)
	TArray<FAudio2FaceFrameData> InnerLoadLipFile(const FString& FileName);

	UFUNCTION(BlueprintCallable)
	FString LoadTextFromFile(FString Path);

	UFUNCTION(BlueprintCallable)
	void UpdateLipsValue(float DeltaTime, float CurFrameTime);

public:
	UPROPERTY(BlueprintReadWrite, Transient)
	FFaceAnimSeqData CurPlayFaceSeqData;

	UPROPERTY(BlueprintReadWrite, Transient)
	FFaceAnimState RunState;

	UPROPERTY(BlueprintReadWrite, Transient)
	EFaceAnimModeType PlayType;

	UPROPERTY(BlueprintReadWrite, Transient)
	bool bPause = false;
	
	UPROPERTY(BlueprintReadWrite, Transient)
	TMap<FName,FFaceAnimSeqData> FFaceAnimSeqMap;

	UPROPERTY(BlueprintReadWrite,EditAnywhere)
	FString LipsPath;

public:
	UPROPERTY(BlueprintReadWrite, Transient)
	TMap<FName, float> BlendLipValues;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TMap<FName, float> LipBlendSpeed;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float Override_FpsTime = .0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float BlendStrength = 1.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint32 bDebugPrintAnimInfo : 1;

	UPROPERTY(Transient)
	TArray<FString> DebugAnimInfos;

protected:
	UPROPERTY(BlueprintReadWrite, Transient)
	TWeakObjectPtr<USkeletalMeshComponent> MeshCom = nullptr;
	
	UPROPERTY(BlueprintReadWrite, Transient)
	TWeakObjectPtr<UFaceAnimLayer> FaceLayer = nullptr;
	
	FString FaceAnimLayerTag = "FaceAnim";
};