// Fill out your copyright notice in the Description page of Project Settings.

#pragma once
#include "UObject/ObjectMacros.h"
#include "NiagaraSystem.h"
#include "AnimNotify_C7CommonStruct.generated.h"

class UNiagaraSystem;
USTRUCT(BlueprintType)
struct FNiagaraPack
{
	GENERATED_USTRUCT_BODY()
public:
	// Niagara名称
#pragma region Default
// The niagara system template to use when spawning the niagara component
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Default", meta = (DisplayName = "Niagara System", ToolTip = "The niagara system to spawn for the notify state"))
	TSoftObjectPtr<UNiagaraSystem> TemplatePath;

	// The socket within our mesh component to attach to when we spawn the Niagara component
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Default", meta = (ToolTip = "The socket or bone to attach the system to", AnimNotifyBoneName = "true"))
	FName SocketName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Default", meta = (ToolTip = "Default life seconds"))
	float TotalLifeSeconds;

#pragma endregion Default

#pragma region Transform
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", meta = (ToolTip = "Transform from the socket or bone to place the Niagara system"))
	FTransform Transform;

#pragma endregion Transform

#pragma region Flags
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Flags", meta = (ToolTip = "Attach to parent socket"))
	bool bNeedAttach;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Flags", meta = (ToolTip = "Use Absolute Rotation"))
	bool bAbsoluteRotation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Flags", meta = (ToolTip = "Use Absolute scale"))
	bool bAbsoluteScale;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Flags", meta = (ToolTip = "Need Check Ground (Use Default Param)"))
	bool bNeedCheckGround;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Flags", meta = (ToolTip = "Use RightSide Resource Path"))
	bool bIsRightSide;

#pragma endregion Flags
};

UENUM(BlueprintType)
enum class EAnimState : uint8
{
	Normal = 0		UMETA(DisplayName = "普通"),
	InWater			UMETA(DisplayName = "水中"),
	FootPrint		UMETA(DisplayName = "脚印"),
};

UENUM(BlueprintType)
enum class ENiagaraFlags : uint8
{
	NeedAttach = 0			UMETA(DisplayName = "是否挂接"),
	AbsoluteRotation		UMETA(DisplayName = "不跟随旋转"),
	AbsoluteScale			UMETA(DisplayName = "不跟随缩放"),
	CheckGround				UMETA(DisplayName = "贴地（或其他表面）"),
	IsRight					UMETA(DisplayName = "区分左右（不勾选默认选择_L资源）"),

	FLAG_MAX				UMETA(Hidden)
};

USTRUCT(BlueprintType)
struct FAnimNotifyOnSurface
{
	GENERATED_USTRUCT_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	EAnimState Key;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FNiagaraPack Value;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float CheckDepth;
};
