// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "AnimNotifyState_C7HurdleHandIK.generated.h"

/**
 * 
 */
UCLASS()
class KGCHARACTER_API UAnimNotifyState_C7HurdleHandIK : public UAnimNotifyState
{
	GENERATED_BODY()
public:
	virtual void NotifyBegin(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference) override;
	virtual void NotifyEnd(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) override;
	virtual void NotifyTick(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float FrameDeltaTime, const FAnimNotifyEventReference& EventReference) override;

public:
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FName EffectBone = NAME_None;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FName JointBone = NAME_None;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FVector JointTargetLocation = FVector::ZeroVector;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FVector DetectOffsetComponentSpace = FVector::ZeroVector;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FVector IKLocationOffsetComponentSpace = FVector::ZeroVector;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float DetectDepth = 50.f;
	
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float BlendInTime = 0.f;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float BlendOutTime = 0.f;
};
