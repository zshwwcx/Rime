#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Animation/AnimNodeBase.h"
#include "BoneControllers/AnimNode_SkeletalControlBase.h"
#include "Curves/CurveFloat.h"

#include "AnimNode_BoneChainPhysics.generated.h"


/**
 * 骨骼链自定义物理模拟动画节点
 */

USTRUCT()
struct KGCHARACTER_API FPhysicsConfig
{
	GENERATED_USTRUCT_BODY()

public:
	//半径(碰撞用)
	UPROPERTY(EditAnywhere)
	float Radius = 1.0f;
	//弹性恢复
	UPROPERTY(EditAnywhere, meta = (ClampMin = 0, ClampMax = 1))
	float Stiffness = .05f;
	//粘度
	UPROPERTY(EditAnywhere, meta = (ClampMin = 0, ClampMax = 1))
	float Drag = .1f;

	//旋转阻尼
	UPROPERTY(EditAnywhere, meta = (ClampMin = 0, ClampMax = 1))
	float RotationDamp = 0.3f;
	//旋转离心度
	UPROPERTY(EditAnywhere, meta = (ClampMin = 0, ClampMax = 4))
	float Centrifugal = .9f;

	//UPROPERTY(EditAnywhere)
	//FVector SpringForce = FVector::ZeroVector;

	//UPROPERTY(EditAnywhere)
	//FVector BoneAxis = FVector(-1.0f, 0.0f, 0.0f);
};

USTRUCT()
struct KGCHARACTER_API FBoneInfoConfig
{
	GENERATED_USTRUCT_BODY()

public:
	//骨骼点权重
	UPROPERTY(EditAnywhere, meta = (ClampMin = 0, ClampMax = 1))
	float Weight = 1.0f;
};

UENUM()
enum class EWindCoordinateSystem : uint8
{
	Component UMETA(DisplayName = "自身坐标系"),
	World UMETA(DisplayName = "世界坐标系"),
};

USTRUCT()
struct KGCHARACTER_API FPhysicsBoneData
{
	GENERATED_USTRUCT_BODY()

public:
	UPROPERTY(Transient)
	FVector LocPos = FVector::ZeroVector;
	UPROPERTY(Transient)
	FVector wPos = FVector::ZeroVector;
	UPROPERTY(Transient)
	FVector CurCalwPos = FVector::ZeroVector;
	UPROPERTY(Transient)
	FVector LastCalwPos = FVector::ZeroVector;

	UPROPERTY(Transient)
	FQuat LocRot = FQuat::Identity;
	UPROPERTY(Transient)
	FQuat wRot = FQuat::Identity;
	UPROPERTY(Transient)
	FVector BoneScale = FVector::ZeroVector;

	UPROPERTY(Transient)
	FVector CPos = FVector::ZeroVector;
	UPROPERTY(Transient)
	FQuat CRot = FQuat::Identity;

	UPROPERTY(Transient)
	FBoneReference Bone;

	UPROPERTY(Transient)
	FPhysicsConfig PhysicsConfig;

	UPROPERTY(Transient)
	FBoneInfoConfig BoneConfig;

	UPROPERTY(Transient)
	float SpringLen = .0f;
};


 USTRUCT(BlueprintType)
 struct KGCHARACTER_API FAnimNode_BoneChainPhysics : public FAnimNode_SkeletalControlBase
 {
	GENERATED_USTRUCT_BODY()

 public:
	//模拟链根节点
	UPROPERTY(EditAnywhere, Category="BoneChainPhysics")
	FBoneReference RootBone;

	//整体物理模拟配置
	UPROPERTY(EditAnywhere, Category = "BoneChainPhysics")
	FPhysicsConfig PhysicsConfig;

	//骨骼链配置
	UPROPERTY(EditAnywhere, Category="BoneChainPhysics")
	TMap< FName, FBoneInfoConfig> BoneChainConfig;

	//重力
	UPROPERTY(EditAnywhere, Category = "BoneChainPhysics")
	FVector Gravity = FVector(0,0,-10.0f);

	//开启风力
	UPROPERTY(EditAnywhere, Category = "BoneChainPhysics")
	bool EnableWind = true;

	//风力方向参考系
	UPROPERTY(EditAnywhere, meta = (EditCondition = "EnableWind", EditConditionHides), Category = "BoneChainPhysics")
	EWindCoordinateSystem Coordinate = EWindCoordinateSystem::Component;
	//风向
	UPROPERTY(EditAnywhere, meta = (EditCondition = "EnableWind", EditConditionHides, PinShownByDefault), Category = "BoneChainPhysics")
	FVector WindDir = FVector(-1, 0, 0);
	//风力
	UPROPERTY(EditAnywhere, meta = (EditCondition = "EnableWind", EditConditionHides, ClampMin = 0, ClampMax = 300, PinShownByDefault), Category = "BoneChainPhysics")
	float WindStrength = 1.0f;
	 
	//波动速度
	UPROPERTY(EditAnywhere, meta = (EditCondition = "EnableWind", EditConditionHides, ClampMin = 0, ClampMax = 400, PinShownByDefault), Category = "BoneChainPhysics")
	float WindWaveSpeed = 80.0f;

	//波动曲线
	UPROPERTY(EditAnywhere, meta = (EditCondition = "EnableWind", EditConditionHides), Category = "BoneChainPhysics")
	UCurveFloat* WindWaveCurve = nullptr;

 protected:
	
	UPROPERTY(Transient)
	TArray<FPhysicsBoneData> PhysicsBoneData;

	UPROPERTY(Transient)
	float DeltaTime = .0f;

	float LastDeltaTime = .0f;

	float WindWaveElapsedTime = .0f;

	UPROPERTY(Transient)
	FTransform LastCompTransform;

	UPROPERTY(Transient)
	FVector CurCompMoveVector = FVector::ZeroVector;
	UPROPERTY(Transient)
	FQuat CurCompRotation = FQuat::Identity;

	UPROPERTY(Transient)
	FVector CurGravity = FVector::ZeroVector;

 public:
	 FAnimNode_BoneChainPhysics()
	 {
	 	LODThreshold = 1;
	 }

 public:
	 // FAnimNode_Base interface
	 virtual void Initialize_AnyThread(const FAnimationInitializeContext& Context) override;
	 virtual bool NeedsDynamicReset() const override { return true; }
	 // End of FAnimNode_Base interface

 protected:
	 // use this function to update for skeletal control base
	 virtual void UpdateInternal(const FAnimationUpdateContext& Context);

	 // Evaluate the new component-space transforms for the affected bones.
	 virtual void EvaluateSkeletalControl_AnyThread(FComponentSpacePoseContext& Output, TArray<FBoneTransform>& OutBoneTransforms);
	 // return true if it is valid to Evaluate
	 virtual bool IsValidToEvaluate(const USkeleton* Skeleton, const FBoneContainer& RequiredBones);
	 // initialize any bone references you have
	 virtual void InitializeBoneReferences(const FBoneContainer& RequiredBones);

protected:
	 void InitChainBoneInfo(FComponentSpacePoseContext& Output, const FBoneContainer& RequiredBones);
	 void CompleteCalculate(FComponentSpacePoseContext& Output);
	 void ApplyCalculateResult(FComponentSpacePoseContext& Output, TArray<FBoneTransform>& OutBoneTransforms);


 public:
	void GetRootChildList(const FReferenceSkeleton& RefSkeleton, int32 ParentBoneIndex, TArray<int32>& ChildList);
 };