﻿#pragma once
#include "Animation/AnimNotifies/AnimNotifyState.h"

#include "AnimNotifyState_C7EnablePerfectDodge.generated.h"

// AnimNotifyState持续期间（包括第一帧和最后一帧）每帧生成一个等同于玩家胶囊体大小的碰撞盒用于完美闪避判定检测, 持续指定时间, 这里配置的帧数最后会转化为
// 时间, 默认按照每秒30帧进行转化
UCLASS(meta = (DisplayName = "C7EnablePerfectDodge", ToolTip="持续期间每帧生成一个等同于玩家胶囊体大小的碰撞盒用于完美闪避判定检测"))
class UAnimNotifyState_C7EnablePerfectDodge : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) override;

protected:

	void EndPerfectDodge(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation);
	
	UPROPERTY(EditAnywhere, Category="配置参数", meta=(DisplayName="碰撞框持续帧数", ToolTip="运行时按照每秒30帧转化为时间进行计算"))
	uint32 ActiveFrames = 3;

	// 开启完美闪避用settings开关判定, 关闭用是否开启来判定
	TSet<TWeakObjectPtr<USkeletalMeshComponent>> EnabledPerfectDodgeComps;
};