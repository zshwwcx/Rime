/**
 * Auth :   liubo
 * Date :   2026-02-07 15:21
 * Comment: 实验功能，有很多临时代码，不要正式使用
 */
 
#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimInstance.h"
#include "Animation/BlendSpace1D.h"
#include "Animation/AnimSequence.h"
#include "Animation/AnimInstanceProxy.h"
#include "3C/Animation/AnimInstanceStruct.h"
#include "3C/Animation/ALS/ALS_AnimInstanceStruct.h"
#include "3C/Animation/AnimCommon.h"
#include "LuaOverriderInterface.h"
#include "3C/RoleComposite/RoleCompositeManager.h"
#include "AnimLayer/BaseAnimLayer.h"
#include "AnimNode_KawaiiPhysicsAllInOne.h"
#include "3C/Animation/AnimLayer/FaceAnimLayer.h"
#include "3C/Animation/AnimationGraphNode/AnimNode_ThreeLayerPostureBlend.h"
#include "Misc/CommonDefines.h"
#include "Animation/AnimTypes.h"
#include "3C/Animation/BaseAnimInstance.h"

#include "AIFaceAnimInstance.generated.h"

// 一个lerp工具
class KGCHARACTER_API FLerpValue
{
public:
	void Tick(float DeltaTime);

	void Reset(float InV, float InTime);

	float Get() const
	{
		return V;
	}

	bool IsEnable() const
	{
		return bEnable;
	}
	void SetEnable(bool b)
	{
		bEnable = b;
	}

private:
	float V = 0;
	float PendingV = 0;
	float Time = 0;
	float TotalTime = 0;
	float Speed = 0;
	bool bEnable = false;
};

// ControlRig格式的面部动画
USTRUCT(BlueprintType, Blueprintable)
struct FAIFaceAnimData
{
	GENERATED_BODY();

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FVector2D CTRL_C_mouth = FVector2D(0,0);

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FVector2D CTRL_C_jaw = FVector2D(0,0);

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FVector2D CTRL_L_eye = FVector2D(0,0);

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_eye_blink = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FVector2D CTRL_R_eye = FVector2D(0,0);

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_eye_blink = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_brow_lateral = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_brow_lateral = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_brow_down = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_brow_down = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_brow_raiseOut = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_brow_raiseIn = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_brow_raiseIn = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_brow_raiseOut = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_eye_pupil = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_eye_pupil = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FVector2D CTRL_C_eye = FVector2D(0,0);

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_C_eye_parallelLook = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_eye_cheekRaise = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_eye_squintInner = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_eye_lidPress = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_nose_wrinkleUpper = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_nose_wrinkleUpper = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_eye_squintInner = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_eye_cheekRaise = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_eye_lidPress = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FVector2D CTRL_R_nose = FVector2D(0,0);

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FVector2D CTRL_L_nose = FVector2D(0,0);

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_upperLipRaise = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_sharpCornerPull = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_cornerPull = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_dimple = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_cornerDepress = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_stretch = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_lowerLipDepress = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_lowerLipDepress = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_stretch = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_towardsD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_lipsBlow = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_stickyInnerU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_jaw_chinCompress = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_funnelU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_neck_mastoidContract = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_C_neck_swallow = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_stickyOuterD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_C_mouth_stickyD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_lipsPressU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_towardsU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_stickyInnerD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_lipBiteD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_funnelD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_lookAtSwitch = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_stickyOuterU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_C_mouth_stickyU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_lipsTogetherU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_tightenD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_pressU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_tightenD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_stickyInnerU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_funnelD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_neck_stretch = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_suckBlow = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_tightenU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_tightenU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_pressD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_neck_digastricUpDown = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_lipsTogetherD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_funnelU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_towardsU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_stickyOuterD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_purseD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_lipBiteU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_pressD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_lipSticky = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_neck_stretch = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_pressU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_purseD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_jaw_clench = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_lipSticky = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_neck_throatExhaleInhale = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_lipBiteU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_suckBlow = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_jaw_ChinRaiseD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_purseU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_towardsD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_jaw_ChinRaiseU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_C_jaw_openExtreme = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_C_jaw_fwdBack = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_stickyInnerD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_lipBiteD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_jaw_clench = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_lipsTogetherU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_purseU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_lipsPressU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_jaw_ChinRaiseU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_stickyOuterU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_neck_mastoidContract = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_lipsBlow = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_jaw_chinCompress = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_jaw_ChinRaiseD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_lipsTogetherD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_neck_throatUpDown = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_ear_up = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_ear_up = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_cornerDepress = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_upperLipRaise = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_dimple = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_sharpCornerPull = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_cornerPull = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FVector2D CTRL_C_teethD = FVector2D(0,0);

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FVector2D CTRL_C_teethU = FVector2D(0,0);

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_C_teeth_fwdBackD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FVector2D CTRL_L_mouth_corner = FVector2D(0,0);

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FVector2D CTRL_R_mouth_corner = FVector2D(0,0);

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_C_teeth_fwdBackU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_eye_faceScrunch = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_pushPullU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_eyelashes_tweakerOut = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_thicknessU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_pushPullD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_thicknessU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_cornerSharpnessD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_C_mouth_lipShiftD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_lipsRollD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_eyelashes_tweakerOut = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_thicknessD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_cornerSharpnessU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_C_mouth_lipShiftU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_eyelashes_tweakerIn = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_lipsRollU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_eye_eyelidU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_lipsRollD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_cornerSharpnessD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_thicknessD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_eye_eyelidD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_lipsRollU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_cornerSharpnessU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_nose_nasolabialDeepen = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_eye_faceScrunch = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_pushPullU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_lipsTowardsTeethD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_lipsTowardsTeethD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_eye_eyelidU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_eyelashes_tweakerIn = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_nose_nasolabialDeepen = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_pushPullD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_lipsTowardsTeethU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_eye_eyelidD = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_lipsTowardsTeethU = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_R_mouth_stretchLipsClose = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	float CTRL_L_mouth_stretchLipsClose = 0;
};

UCLASS(BlueprintType, Blueprintable, Experimental)
class KGCHARACTER_API UAIFaceAnimInstance : public UBaseAnimInstance
{
	GENERATED_UCLASS_BODY()

protected:
	virtual void PreUpdateAnimation(float DeltaSeconds) override;

	UFUNCTION(BlueprintCallable)
	void NotifyBodyAnimAction(int N, bool bOnStart);
	
public:
	void SetEnableFaceAnim(bool b);
	void SetWebSequenceAsset(const FCustomAnimationData& InAnimationData, float StartTime);
public:
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FAIFaceAnimData FaceAnimAIData;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		int BodyAnimIdx = 1; // 废弃
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float FaceAnimWeight = 1;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		bool bFaceAnim = true;

	// 混合模式的身体动画
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		int BodyAnimBlend_Index = 0; // -1, 0, 1, 2...

	void BodyAnimBlendChange(TObjectPtr<UAnimSequence> NewAnim);

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float FaceAnimLerpTime = 0.2f;

private:
	FLerpValue PengingFaceAnimWeight;

protected:
	template<class T>
	TArray<T*> GetNodes()
	{
		TArray<T*> Ret;
		FAnimInstanceProxy& Proxy = GetProxyOnAnyThread<FAnimInstanceProxy>();

		if (!Proxy.GetAnimClassInterface())
		{
#if !UE_BUILD_SHIPPING
			UE_LOG(LogTemp, Warning, TEXT("UBaseAnimInstance::SetWebSequenceAsset  Invalid Animation Proxy"));
#endif
			return Ret;
		}
		const TArray<FStructProperty*>& AnimNodeProperties = Proxy.GetAnimClassInterface()->GetAnimNodeProperties();

		// FAnimNode_AIFacePlayer
		for (auto E : AnimNodeProperties)
		{
			FStructProperty* MachineInstanceProperty = E;
			if (!MachineInstanceProperty->Struct->IsChildOf(T::StaticStruct()))
			{
				continue;
			}
			T* Node = MachineInstanceProperty->ContainerPtrToValuePtr<T>(Proxy.GetAnimInstanceObject());
			if (Node)
			{
				Ret.Add(Node);
			}
		}
		return Ret;
	}
};
