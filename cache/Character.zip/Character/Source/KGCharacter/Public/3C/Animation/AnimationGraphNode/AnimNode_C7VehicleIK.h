// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "3C/Animation/AnimCommon.h"
#include "UObject/ObjectMacros.h"
#include "BonePose.h"
#include "BoneControllers/AnimNode_SkeletalControlBase.h"
#include "AnimNode_C7VehicleIK.generated.h"

class USkeletalMeshComponent;

UENUM(BlueprintType)
enum class EC7VehicleIKType : uint8
{
	None,
	// 四轮车姿态调整
	FourWheelPosture,
	// 轮胎贴地
	WheelOnGround,
	// 四个轮子决定Root的旋转、位置
	RootDependsOnWheel,
};

USTRUCT(BlueprintType)
struct FFourWheelCarIkParam
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere)
	FWheelInfo LeftFrontWheelInfo;
	
	UPROPERTY(EditAnywhere)
	FWheelInfo LeftRearWheelInfo;

	UPROPERTY(EditAnywhere)
	FWheelInfo RightFrontWheelInfo;

	UPROPERTY(EditAnywhere)
	FWheelInfo RightRearWheelInfo;
};

struct FWheelRuntimeInfo
{
	float Radius = 0;
	
	float TraceRadius = 2;
	
	float AppyRoll = 0.f;
	
	FTransform ComponentSpaceTransform;
	
	FTransform RelativeToRootTransform;
};

USTRUCT(BlueprintInternalUseOnly)
struct FAnimNode_C7VehicleIK : public FAnimNode_Base
{
	GENERATED_USTRUCT_BODY()

	// Input link
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Links)
	FPoseLink ComponentPose;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Performance, meta = (PinHiddenByDefault, DisplayName = "LOD Threshold"))
	int32 LODThreshold = 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Alpha, meta = (PinShownByDefault))
	float Alpha = 1.f;
	
	UPROPERTY(EditAnywhere, Category=IK)
	EC7VehicleIKType VehicleIKType = EC7VehicleIKType::None;

	// 姿态调整相关
	UPROPERTY(EditAnywhere, Category=IK, meta = (DisplayName = "四轮姿态调整参数", EditCondition="VehicleIKType == EC7VehicleIKType::FourWheelPosture", EditConditionHides))
	FFourWheelCarIkParam FourWheelCarIkParam;

	UPROPERTY(EditAnywhere, Category=IK, meta = (DisplayName = "ApplyModifyBone", EditCondition="VehicleIKType == EC7VehicleIKType::FourWheelPosture", EditConditionHides))
	FName ApplyModifyBone = "root";

	UPROPERTY(EditAnywhere, Category=IK, meta = (DisplayName = "Pitch插值半衰时间", EditCondition="VehicleIKType == EC7VehicleIKType::FourWheelPosture", EditConditionHides))
	float PitchHalfTime = 0.05f;
	
	UPROPERTY(EditAnywhere, Category=IK, meta = (DisplayName = "Roll插值半衰时间", EditCondition="VehicleIKType == EC7VehicleIKType::FourWheelPosture", EditConditionHides))
	float RollHalfTime = 0.05f;

	// 轮胎贴地相关
	UPROPERTY(EditAnywhere, Category=IK, meta = (DisplayName = "轮胎信息参数", EditCondition="VehicleIKType == EC7VehicleIKType::WheelOnGround", EditConditionHides))
	TArray<FWheelInfo> WheelArray;

	UPROPERTY(EditAnywhere, Category=IK, meta = (DisplayName = "轮胎调整范围", EditCondition="VehicleIKType == EC7VehicleIKType::WheelOnGround", EditConditionHides))
	FVector2D WheelUpDownRange = FVector2D(0, 0);

	UPROPERTY(EditAnywhere, Category=IK, meta = (DisplayName = "贴地插值半衰时间", EditCondition="VehicleIKType == EC7VehicleIKType::WheelOnGround", EditConditionHides))
	float WheelOnGroundHalfTime = 0.05f;
	
	// 轮子决定根骨骼的旋转+位置
	UPROPERTY(EditAnywhere, Category=IK, meta = (DisplayName = "轮胎信息参数", EditCondition="VehicleIKType == EC7VehicleIKType::RootDependsOnWheel", EditConditionHides))
	FFourWheelCarIkParam RootDependsOnWheelParams;

	UPROPERTY(EditAnywhere, Category=IK, meta = (DisplayName = "轮胎宽度", EditCondition="VehicleIKType == EC7VehicleIKType::RootDependsOnWheel", EditConditionHides))
	float WheelWidth = 20.f;
	
	UPROPERTY(EditAnywhere, Category=IK, meta = (DisplayName = "根骨骼", EditCondition="VehicleIKType == EC7VehicleIKType::RootDependsOnWheel", EditConditionHides))
	FName ApplyModifyRootBone = "root";

	UPROPERTY(EditAnywhere, Category=IK, meta = (DisplayName = "Pitch插值半衰时间", EditCondition="VehicleIKType == EC7VehicleIKType::RootDependsOnWheel", EditConditionHides))
	float RootPitchHalfTime = 0.05f;
	
	UPROPERTY(EditAnywhere, Category=IK, meta = (DisplayName = "Roll插值半衰时间", EditCondition="VehicleIKType == EC7VehicleIKType::RootDependsOnWheel", EditConditionHides))
	float RootRollHalfTime = 0.05f;
	
	UPROPERTY(EditAnywhere, Category=IK, meta = (DisplayName = "位置插值半衰时间", EditCondition="VehicleIKType == EC7VehicleIKType::RootDependsOnWheel", EditConditionHides))
	float RootLocationHalfTime = 0.05f;
	

	// 通用配置
	UPROPERTY(EditAnywhere, Category = IK)
	TEnumAsByte<ECollisionChannel> BlockChannel = ECollisionChannel::ECC_WorldStatic;

	UPROPERTY(EditAnywhere, Category = IK, meta = (DisplayName = "Display LineTracing", PinHiddenByDefault))
	bool DisplayLineTrace = true;

	UPROPERTY(EditAnywhere, Category=IK, meta = (DisplayName = "射线起点向上抬升距离", PinHiddenByDefault))
	float StartUpDis = 0;
	
	UPROPERTY(EditAnywhere, Category=IK, meta = (DisplayName = "向下检测距离", PinHiddenByDefault))
	float TraceLength = 300.f;
	
	
	KGCHARACTER_API FAnimNode_C7VehicleIK();

	KGCHARACTER_API virtual void UpdateInternal(const FAnimationUpdateContext& Context);
	
	// FAnimNode_Base interface
	KGCHARACTER_API virtual void Initialize_AnyThread(const FAnimationInitializeContext& Context) override;
	KGCHARACTER_API virtual void CacheBones_AnyThread(const FAnimationCacheBonesContext& Context)  override;
	
	// End of FAnimNode_Base interface

	// FAnimNode_SkeletalControlBase interface
	KGCHARACTER_API virtual void EvaluateSkeletalControl_AnyThread(FComponentSpacePoseContext& Output);
	KGCHARACTER_API virtual bool IsValidToEvaluate(const USkeleton* Skeleton, const FBoneContainer& RequiredBones);
	KGCHARACTER_API virtual void Update_AnyThread(const FAnimationUpdateContext& Context) override;
	KGCHARACTER_API virtual void Evaluate_AnyThread(FPoseContext& Output) override;
	virtual int32 GetLODThreshold() const override { return LODThreshold; }

private:
	// FAnimNode_SkeletalControlBase interface
	KGCHARACTER_API virtual void InitializeBoneReferences(const FAnimationCacheBonesContext& Context);
	// End of FAnimNode_SkeletalControlBase interface

	void InitFourWheelCarBoneReferences(const FAnimationCacheBonesContext& Context);
	void CalculateFourWheelCarIK(const FAnimationUpdateContext& Context);
	void ApplyFourWheelCarIK(FComponentSpacePoseContext& Output);

	void InitWheelOnGroundBoneReferences(const FAnimationCacheBonesContext& Context);
	void CalculateWheelOnGroundIK(const FAnimationUpdateContext& Context);
	void ApplyWheelOnGroundIK(FComponentSpacePoseContext& Output);

	
	void InitRootDependsOnWheelBoneReferences(const FAnimationCacheBonesContext& Context);
	void CalculateRootDependsOnWheelIK(const FAnimationUpdateContext& Context);
	void ApplyRootDependsOnWheelIK(FComponentSpacePoseContext& Output);
	FVector CalculateWheelGroundedPos(FTransform WheelTransformWS, float TraceRadius, float WheelRadius);
	float CalculateWheelRoll(const float CurrentRoll, float TranslationDelta, float WheelRadius);
	FTransform GetBoneComponentSpaceTransform(const FReferenceSkeleton& RefSkeleton, FName BoneName) const;
	
private:
	TArray<FBoneTransform> BoneTransforms;
	
	// 姿态调整相关
	TArray<FVector> TraceStartList = TArray<FVector>();
	TArray<FVector> TraceEndList = TArray<FVector>();
	TArray<float> TraceRadius;
	float DestPitch = 0.f;
	float DestRoll = 0.f;
	float ApplyPitch = 0.f;
	float ApplyRoll = 0.f;

	// 轮胎贴地相关
	TArray<float> WheelOnGroundAdjustArray;
	
	// 轮子决定根骨骼变换	
	TMap<FName, FWheelRuntimeInfo> RuntimeWheels;
	FTransform ApplyRootTransformCS = FTransform::Identity;
	FVector RootToWheelCenterOffset = FVector::ZeroVector;

	// 通用
	TArray<TEnumAsByte<EObjectTypeQuery>> TraceArr;
	
	UPROPERTY()
	TWeakObjectPtr<USkeletalMeshComponent> OwnerSkeletalMesh = nullptr;
};
