// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Misc/CommonDefines.h"
#include "3C/Animation/AnimNotify/AnimNotify_TerrainNiagara.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "AnimNotifyState_TerrainNiagara.generated.h"

/**
 * 
 */
UCLASS(DisplayName = "持续地形对应特效")
class KGCHARACTER_API UAnimNotifyState_TerrainNiagara : public UAnimNotifyState
{
	GENERATED_BODY()
	
public:
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) override;

public:
	/**
	 * Key对应[[TerrainMaterial_地表材质.xlsx]]的[[TerrainPhysicalMaterial]]页的[[Name]]列
	 */
	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "地表材质对应特效参数"))
	TMap<FString, FTerrainNiagaraParams> Terrain2Niagara;

private:
	TMap<KGObjectID, int32> ActorID2TerrainNiagaraID;
};
