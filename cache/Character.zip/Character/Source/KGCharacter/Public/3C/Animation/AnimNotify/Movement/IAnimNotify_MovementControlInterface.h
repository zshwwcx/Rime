#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "IAnimNotify_MovementControlInterface.generated.h"

UINTERFACE(MinimalAPI, Blueprintable)
class UAnimNotify_MovementControlInterface : public UInterface
{
	GENERATED_BODY()
};

// 注意: 不要给数据, 否则有可能会增加对象布局的内存(特别是菱形继承)
class IAnimNotify_MovementControlInterface
{
	GENERATED_BODY()

public:
	URoleMovementComponent * GetMovementAuthorityControlRMC(URoleMovementComponent* NotifyRMC);

};
