#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Animation/AnimNode_AssetPlayerBase.h"
#include "Animation/InputScaleBias.h"
#include "Animation/AnimSequenceBase.h"
#include "3C/Animation/AnimationGraphNode/CustomAnimNodeDefine.h"
#include "AnimNode_AssetIDSequencePlayer.generated.h"


USTRUCT(Blueprintable, BlueprintType)
struct KGCHARACTER_API FMapRangeStruct
{
	GENERATED_BODY()
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Setting", meta = (PinHiddenByDefault))
	FVector2f InRange = FVector2f(0.0F,1.0F);
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Setting", meta = (PinHiddenByDefault))
	FVector2f OutRange= FVector2f(0.0F,1.0F);
};

UENUM()
enum class EStartPositionType : uint8
{
	Default UMETA(DisplayName = "Default"),
	FootPosture UMETA(DisplayName = "FootPosture"),
	MapRange UMETA(DisplayName = "MapRange"),
	ExplicitTime UMETA(DisplayName="ExplicitTime")
};

USTRUCT(BlueprintType)
struct KGCHARACTER_API FAnimNode_AssetIDSequencePlayer : public FAnimNode_AssetPlayerBase
{
	GENERATED_USTRUCT_BODY()
public:
	//动画ID
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinHiddenByDefault))
	FAnimNodeAssetID AssetID;

	UPROPERTY(BlueprintReadOnly, VisibleAnywhere)
	FText Name;

	FName AnimLibID = NAME_None;

	// The animation sequence asset to play
	UPROPERTY(Transient, BlueprintReadWrite, Category = Settings, meta = (PinHiddenByDefault, DisallowedClasses = "AnimMontage"))
	UAnimSequenceBase* Sequence;
	 
	// The Basis in which the PlayRate is expressed in. This is used to rescale PlayRate inputs.
	// For example a Basis of 100 means that the PlayRate input will be divided by 100.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinHiddenByDefault))
	float PlayRateBasis;

	// The play rate multiplier. Can be negative, which will cause the animation to play in reverse.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinHiddenByDefault))
	float PlayRate;

	// Should the animation continue looping when it reaches the end?
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinHiddenByDefault))
	bool bLoopAnimation;

	// Additional scaling, offsetting and clamping of PlayRate input.
	// Performed after PlayRateBasis.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings)
	FInputScaleBiasClamp PlayRateScaleBiasClamp;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings)
	EStartPositionType StartPositionType = EStartPositionType::Default;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings)
	bool DynamicLoadFromBaseAnimInstance = false;

	// The start up position, it only applies when reinitialized
	// if you loop, it will still start from 0.f after finishing the round
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinHiddenByDefault, EditCondition = "StartPositionType == EStartPositionType::Default || StartPositionType == EStartPositionType::ExplicitTime", EditConditionHides))
	float StartPosition;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinHiddenByDefault, EditCondition = "StartPositionType == EStartPositionType::FootPosture", EditConditionHides))
	int FootPostureValue = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinHiddenByDefault, EditCondition = "StartPositionType == EStartPositionType::FootPosture", EditConditionHides))
	float FootPostureAnimLengthRatio = 0.5F;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinHiddenByDefault, EditCondition = "StartPositionType == EStartPositionType::MapRange", EditConditionHides))
	float MapRangeValue = 0.0F;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinHiddenByDefault, EditCondition = "StartPositionType == EStartPositionType::MapRange", EditConditionHides))
	FMapRangeStruct MapRangeStruct;

public:
	FAnimNode_AssetIDSequencePlayer()
		: Sequence(nullptr)
		, PlayRateBasis(1.0f)
		, PlayRate(1.0f)
		, bLoopAnimation(false)
		, StartPosition(0.f)
	{
	}

	// 从AnimNode_SequencePlayer参考copy过来
#if WITH_EDITORONLY_DATA
	// The group name that we synchronize with (NAME_None if it is not part of any group). 
	UPROPERTY(EditAnywhere, Category=Sync, meta=(FoldProperty))
	FName GroupName = NAME_None;

	// The role this node can assume within the group (ignored if GroupName is not set)
	UPROPERTY(EditAnywhere, Category=Sync, meta=(FoldProperty))
	TEnumAsByte<EAnimGroupRole::Type> GroupRole = EAnimGroupRole::CanBeLeader;

	// How this node will synchronize with other animations.
	UPROPERTY(EditAnywhere, Category=Sync, meta=(FoldProperty))
	EAnimSyncMethod Method = EAnimSyncMethod::DoNotSync;

	// If true, "Relevant anim" nodes that look for the highest weighted animation in a state will ignore this node
	UPROPERTY(EditAnywhere, Category=Relevancy, meta=(FoldProperty, PinHiddenByDefault))
	bool bIgnoreForRelevancyTest = false;
#endif

	// FAnimNode_AssetPlayerBase interface
	virtual float GetCurrentAssetTime() const override;
	virtual float GetCurrentAssetTimePlayRateAdjusted() const override;
	virtual float GetCurrentAssetLength() const override;
	virtual UAnimationAsset* GetAnimAsset() const override { return Sequence; }
	virtual FName GetGroupName() const override;
	virtual EAnimGroupRole::Type GetGroupRole() const override;
	virtual EAnimSyncMethod GetGroupMethod() const override;
	virtual bool GetIgnoreForRelevancyTest() const override;
	virtual bool SetGroupName(FName InGroupName) override;
	virtual bool SetGroupRole(EAnimGroupRole::Type InRole) override;
	virtual bool SetGroupMethod(EAnimSyncMethod InMethod) override;
	virtual bool SetIgnoreForRelevancyTest(bool bInIgnoreForRelevancyTest) override;
	// End of FAnimNode_AssetPlayerBase interface

	// FAnimNode_Base interface
	virtual void Initialize_AnyThread(const FAnimationInitializeContext& Context) override;
	virtual void CacheBones_AnyThread(const FAnimationCacheBonesContext& Context) override;
	virtual void UpdateAssetPlayer(const FAnimationUpdateContext& Context) override;
	virtual void Evaluate_AnyThread(FPoseContext& Output) override;
	virtual void OverrideAsset(UAnimationAsset* NewAsset) override;
	virtual void GatherDebugData(FNodeDebugData& DebugData) override;
	// End of FAnimNode_Base interface

	float GetTimeFromEnd(float CurrentNodeTime);
};
