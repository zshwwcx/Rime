// FKRetarget.h
// Forward Kinematics based motion retargeting for UE5
// Using UE5 FMatrix for rotation calculations
// Ported from Python implementation

#pragma once

#include "CoreMinimal.h"
#include "Json.h"
#include "JsonUtilities.h"


// UE5旋转转换工具类
class FUE5RotationUtils
{
public:
    // 欧拉角(度数)转旋转矩阵 (XYZ顺序)
    static FMatrix EulerToMatrix(const FVector& EulerDegrees);
    
    // 旋转矩阵转欧拉角(度数) (XYZ顺序)
    static FVector MatrixToEuler(const FMatrix& Matrix);
    
    // 角轴向量转旋转矩阵 (Rodrigues公式)
    static FMatrix RotVecToMatrix(const FVector& RotVec);
    
    // 旋转矩阵转角轴向量
    static FVector MatrixToRotVec(const FMatrix& Matrix);

    // 正交化旋转矩阵 (确保列向量正交单位)
    static FMatrix OrthonormalizeMatrix(const FMatrix& Matrix);
};

/**
 * 参考姿态信息结构
 */
struct FRetargetJointRefPose
{
    FString Name;
    FString Parent;
    FVector Rotation; // 欧拉角 (度数)

    FRetargetJointRefPose() : Rotation(FVector::ZeroVector) {}
};

/**
 * FK重定向器类 - 进行旋转计算
 */
class FFKRetarget
{
public:
    FFKRetarget();
    ~FFKRetarget();

    /**
     * 初始化重定向器，加载参考姿态
     * @param SourceRefPosePath 源骨骼参考姿态JSON路径
     * @param TargetRefPosePath 目标骨骼参考姿态JSON路径
     * @return 是否成功
     */
    bool Initialize(
        const FString& SourceRefPosePath,
        const FString& TargetRefPosePath
    );

    bool InitializeFromJson(
        const FString& SourceRefPoseJson,
        const FString& TargetRefPoseJson
    );


    /**
     * 执行动作重定向
     * @param InputPath 输入JSON文件路径
     * @param OutputPath 输出JSON文件路径
     * @return 是否成功
     */
    bool RetargetMotion(
        const FString& InputPath,
        const FString& OutputPath
    );

    bool RetargetMotionCore(
              const TArray<float>& PoseData,
              TArray<float>& OutPoseData,
              int32 NumFrames = 0,
              int32 NumPeople = -1,
              int32 SourceNumJoints = 0,
              int32 TargetNumJoints = 0
          );

    bool IsInitialized() const { return bIsInitialized; }
    void TestRotationFunctions();

private:
    // SMPL关节名称列表
    TArray<FString> SMPLJoints;
    
    // Skel关节名称列表
    TArray<FString> SkelJoints;
    
    // Skel到SMPL的映射
    TMap<FString, FString> SkelToSMPLMap;

    // 参考姿态数据（成员变量，避免重复加载）
    TMap<FString, FRetargetJointRefPose> SourceRefPose;
    TMap<FString, FRetargetJointRefPose> TargetRefPose;
    
    // 参考姿态旋转矩阵（预计算，提高性能）
    TMap<FString, FMatrix> SourceRefLocalRotMats;
    TMap<FString, FMatrix> TargetRefLocalRotMats;
    
    // 是否已初始化标志
    bool bIsInitialized;

    // 初始化关节名称和映射
    void InitializeJointNames();

    // 加载参考姿态
    bool LoadRefPose(const FString& JsonString, TMap<FString, FRetargetJointRefPose>& OutRefPose);

    // 加载姿态数据
    bool LoadPoseData(
        const FString& FilePath,
        TArray<float>& OutPoseData,
        int32& OutNumPeople,
        int32& OutNumFrames,
        TSharedPtr<FJsonObject>& OutOriginalJson
    );

    // 保存重定向后的姿态数据
    bool SaveRetargetedPose(
        const FString& FilePath,
        const TArray<float>& PoseData,
        int32 NumPeople,
        int32 NumFrames,
        int32 NumJoints,
        const TSharedPtr<FJsonObject>& OriginalJson
    );

    // 核心重定向算法 - 单帧
    void RetargetOneFrame(
        const TArray<FVector>& SourcePoseOneFrame,
        const TArray<FString>& SourceJointNames,
        const TArray<FString>& TargetJointNames,
        const TMap<FString, FString>& TargetToSourceNameMap,
        TArray<FVector>& OutTargetPoseOneFrame
    );

    // 递归获取源骨骼关节的世界旋转（）
    FMatrix GetSourceWorldRotation(
        const FString& JointName,
        TMap<FString, FMatrix>& SourceWorldRotMats,
        TMap<FString, FMatrix>& SourceLocalRotMats
    );

    // 递归获取目标骨骼关节的世界旋转（）
    FMatrix GetTargetWorldRotation(
        const FString& JointName,
        TMap<FString, FMatrix>& TargetWorldRotMats,
        TMap<FString, FMatrix>& TargetLocalRotMats,
        const TMap<FString, FString>& TargetToSourceNameMap,
        TMap<FString, FMatrix>& SourceWorldRotMats,
        TMap<FString, FMatrix>& SourceLocalRotMats
    );

    // 获取源骨骼关节的局部旋转（）
    FMatrix GetSourceLocalRotation(
        const FString& JointName,
        TMap<FString, FMatrix>& SourceLocalRotMats
    );

    // 计算目标骨骼关节的局部旋转 (重定向核心算法，)
    FMatrix GetTargetLocalRotation(
        const FString& JointName,
        const TMap<FString, FString>& TargetToSourceNameMap,
        TMap<FString, FMatrix>& TargetLocalRotMats,
        TMap<FString, FMatrix>& SourceWorldRotMats,
        TMap<FString, FMatrix>& SourceLocalRotMats,
        TMap<FString, FMatrix>& TargetWorldRotMats
    );

    // Base64编解码工具函数
    static void DecodeBase64ToFloatArray(const FString& Base64String, TArray<float>& FloatArray);
    static FString EncodeFloatArrayToBase64(const TArray<float>& FloatArray);
};
