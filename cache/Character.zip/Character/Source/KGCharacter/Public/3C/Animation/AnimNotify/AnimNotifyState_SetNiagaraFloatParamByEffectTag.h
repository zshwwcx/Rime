﻿#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"

#include "AnimNotifyState_SetNiagaraFloatParamByEffectTag.generated.h"

class UAnimSequenceBase;

UENUM(BlueprintType)
enum class EKGSetNiagaraFloatParamEffectTag : uint8
{
	Default = 0						UMETA(Hidden),
	SpiritualGlideHandEffect = 73  UMETA(DisplayName="灵性之跃手部悬浮特效"),
};

UCLASS(meta = (DisplayName = "SetNiagaraFloatParamByEffectTag"))
class KGCHARACTER_API UAnimNotifyState_SetNiagaraFloatParamByEffectTag : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference) override;
	void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) override;

public:
	// 特效Tag
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	EKGSetNiagaraFloatParamEffectTag EffectTag = EKGSetNiagaraFloatParamEffectTag::SpiritualGlideHandEffect;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, DisplayName="特效参数名称")
	FName NiagaraParamName;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, DisplayName="进入特效参数目标值")
	float EnterTargetVal = 0.0f;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, DisplayName="离开特效参数目标值")
	float LeaveTargetVal = 1.0f;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, DisplayName="参数变化Lerp时间")
	float Duration = 0.5f;
};
