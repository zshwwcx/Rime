#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Engine/DataTable.h"
#include "CustomAnimNodeDefine.generated.h"

//
USTRUCT(BlueprintType)
struct KGCHARACTER_API FAnimNodeAssetID
{
	GENERATED_BODY()
	FAnimNodeAssetID()
		:AssetID(""), AnimCategory(0)
	{};

	FAnimNodeAssetID(FString InID)
		:AssetID(InID), AnimCategory(0)
	{};

	FORCEINLINE bool operator==(const FAnimNodeAssetID& Other)
	{
		return Other.GetID() == AssetID;
	}

	friend inline bool operator==(const FAnimNodeAssetID& A, const FAnimNodeAssetID& B)
	{
		return A.AssetID == B.AssetID;
	}

	friend inline uint32 GetTypeHash(const FAnimNodeAssetID& Key)
	{
		uint32 Hash = 0;

		Hash = HashCombine(Hash, GetTypeHash(Key.AssetID));
		return Hash;
	}

public:
	FString GetID()const { return AssetID; }

	FName GetNameID() const { return FName(AssetID); }

public:
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FString AssetID;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	int32 AnimCategory;
};


// 单个骨骼的关键帧数据
USTRUCT(BlueprintType)
struct FBoneKeyframe
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float Time;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FVector Location;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FRotator Rotation;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FVector Scale;

    FBoneKeyframe()
    {
        Time = 0.0f;
        Location = FVector::ZeroVector;
        Rotation = FRotator::ZeroRotator;
        Scale = FVector::OneVector;
    }
};

// 单个骨骼的动画轨道
USTRUCT(BlueprintType)
struct FC7BoneAnimationTrack
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FString BoneName;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    TArray<FBoneKeyframe> Keyframes;
};

// 自定义动画数据
USTRUCT(BlueprintType)
struct FCustomAnimationData
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float Duration;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    bool bLooping;

	int32 RootBoneIndex;
	
    TArray<FC7BoneAnimationTrack> BoneTracks;

    FCustomAnimationData()
    {
        Duration = 1.0f;
        bLooping = true;
    }
};


// 视频生成数据
USTRUCT(BlueprintType)
struct FVideoGenData
{
    GENERATED_BODY()

	/// @brief 视频持续时间
	float Duration;

	/// @brief 视频播放速率
	float SampleRate;

	/// @brief 动画总帧数
	int32 FrameCount;
	
	/// @brief 人数
	int32 NumPeople;

	/// @brief 自定义动画数据，按性别分组 [SexType][PeopleIndex]
	/// 索引: 0=男, 1=女
	TArray<TArray<TSharedPtr<FCustomAnimationData>>> CustomAnimDataBySex;

	/// @brief 每个人动画首帧的位置，按性别分组 [SexType][PeopleIndex]
	/// 索引: 0=男, 1=女
	TArray<TArray<FVector>> PeopleInitPosBySex;

	/// @brief 相机移动
	TArray<FVector> CameraMove;

	/// @brief 相机旋转
	TArray<FRotator> CameraRotate;

	/// @brief 音频数据 pcm wav格式
	TArray<uint8> Audio;

	/// @brief 表情数组
	TArray<TArray<int32>> EmotionArray;
	
	/// @brief 表情置信度数组
	TArray<TArray<float>> EmotionConfArray;

	/// @brief 有效性掩码数组 [n,f,3] 表示每个人物每帧的身体/左手/右手数据是否有效
	TArray<TArray<int8>> ValidMask;

	/// @brief 动作融合权重数组 [n,f] 基于ValidMask生成，用于动作融合时的alpha值
	/// 范围 [0.0, 1.0]，在有效/无效帧边界处使用线性衰减
	TArray<TArray<float>> BlendArray;

	/// @brief 角色主导程度评分 (bbox_size, center_dist, motion等)
	TMap<FString, TArray<float>> DominantScore;

	/// @brief 人物排序数组（按主导程度降序排列的人物索引）
	TArray<int32> PeopleSort;

	/// @brief 视频帧形状 [height, width, channels]
	TArray<int32> FrameShape;

	FRotator FirstBaseRot;


};


/// @brief 网络动画初始化字符串数据 长的json
USTRUCT(BlueprintType)
struct FWebAnimationInitStrData : public FTableRowBase
{
	GENERATED_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString Content;
};
