﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "AnimNotify_C7PostProcess.generated.h"

/**
 * 
 */
UCLASS()
class KGCHARACTER_API UAnimNotify_C7PostProcess : public UAnimNotify
{
	GENERATED_BODY()

protected:
	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "后效ID"))
	int PostID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "渐入时间"))
	float AlphaInTime;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "渐出时间"))
	float AlphaOutTime;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "持续时长"))
	float Duration;
};
