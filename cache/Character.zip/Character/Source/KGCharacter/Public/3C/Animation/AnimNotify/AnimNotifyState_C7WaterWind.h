// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "AnimNotifyState_C7WaterWind.generated.h"

/**
 * 
 */
UCLASS(DisplayName = "3C水风场持续触发")
class KGCHARACTER_API UAnimNotifyState_C7WaterWind : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference) override;
	virtual void NotifyTick(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float FrameDeltaTime, const FAnimNotifyEventReference& EventReference) override;

private:
	void AddWaterMotor(USkeletalMeshComponent* MeshComp, double CurrentTime);
	void AddWindMotor(USkeletalMeshComponent* MeshComp, double CurrentTime);

public:
#pragma region Water
	/**
	 * 索引 WaterWind.xlsx - WaterWaveMotorTexture
	 */
	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "水波纹材质ID", Category = "Water"))
	int32 MotorTextureID = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "水场发射基准骨骼", Category = "Water"))
	FName WaterBaseSocket = "root";

	/**
	 * 相对于角色当前朝向
	 */
	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "水场发射相对朝向", Category = "Water"))
	float WaterDirAngle = 0.f;

	/**
	 * 基于基准骨骼
	 */
	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "水场位置偏移X", Category = "Water"))
	float WaterOffsetX = 0.f;

	/**
	 * 基于基准骨骼
	 */
	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "水场位置偏移Y", Category = "Water"))
	float WaterOffsetY = 0.f;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "水场波纹效果缩放X", Category = "Water"))
	float WaterScaleX = 0.f;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "水场波纹效果缩放Y", Category = "Water"))
	float WaterScaleY = 0.f;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "水波纹起伏最大高度", Category = "Water"))
	float WaveMaxHeight = 0.f;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "最小水深对应缩放比例", Category = "Water"))
	float MinWaveScalar = 1.f;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "水波纹泡面效果", Category = "Water"))
	float FoamScale = 0.f;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "水波纹触发间隔(单位:秒)", Category = "Water"))
	float WaterTimeGap = 0.f;

#pragma endregion Water

#pragma region Wind

	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "风场类型", Category = "Wind"))
	int32 WindType = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "风场发射基准骨骼", Category = "Wind"))
	FName WindBaseSocket = "root";
	
	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "风场发射相对朝向", Category = "Wind"))
	float WindDirAngle = 0.f;

	/**
	 * 基于基准骨骼
	 */
	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "风场位置偏移X", Category = "Wind"))
	float WindOffsetX = 0.f;

	/**
	 * 基于基准骨骼
	 */
	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "风场位置偏移Y", Category = "Wind"))
	float WindOffsetY = 0.f;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "风场波纹效果缩放X", Category = "Wind"))
	float WindScaleX = 0.f;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "风场波纹效果缩放Y", Category = "Wind"))
	float WindScaleY = 0.f;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "风场强度", Category = "Wind"))
	float WindStrength = 0.f;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "风场中心角度", Category = "Wind"))
	float FanCenterAngle = 0.f;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "风场触发间隔(单位:秒)", Category = "Wind"))
	float WindTimeGap = 0.f;
	
	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "风场渐入时长", Category = "Wind"))
	float WindBlendTime = 0.f;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "风场渐入过渡次数", Category = "Wind"))
	int32 WindBlendFreq = 0;

#pragma endregion Wind

private:
	double LastWaterTickTime = 0.f;
	double LastWindTickTime = 0.f;
};
