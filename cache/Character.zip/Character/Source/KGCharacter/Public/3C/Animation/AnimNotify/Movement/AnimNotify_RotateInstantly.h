// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once
#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "3C/Animation/AnimNotify/Movement/IAnimNotify_MovementControlInterface.h"
#include "AnimNotify_RotateInstantly.generated.h"

class UAnimSequenceBase;


UCLASS(meta = (DisplayName = "C7RotateInstantly"))
class KGCHARACTER_API UAnimNotify_RotateInstantly : public UAnimNotify, public IAnimNotify_MovementControlInterface
{
	GENERATED_BODY()

	UAnimNotify_RotateInstantly(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

public:
	void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;

};

