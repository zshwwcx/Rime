// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once
#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "AnimNotifyState_C7HideNiagara.generated.h"

class UAnimSequenceBase;

UENUM(BlueprintType)
enum class EANSHN_EffectTag : uint8
{
	ET_Default = 0                  UMETA(Hidden),
	ET_WaterWalk = 68               UMETA(DisplayName = "水面移动特效"),
};

UENUM(BlueprintType)
enum class EANSHN_HiddenReason : uint8
{
	HR_Default = 0					UMETA(Hidden),
	HR_WaterWalkJumpThird = 4       UMETA(DisplayName = "水面移动三段跳"),
};

UCLASS(meta = (DisplayName = "C7HideNiagara"))
class KGCHARACTER_API UAnimNotifyState_C7HideNiagara : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference) override;
	void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) override;

public:
	// 特效Tag
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	EANSHN_EffectTag EffectTag = EANSHN_EffectTag::ET_WaterWalk;

	// 特效隐藏的理由
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	EANSHN_HiddenReason HiddenReason = EANSHN_HiddenReason::HR_WaterWalkJumpThird;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bUseBlendTime = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName="出现过渡时间(秒)", EditCondition= "bUseBlendTime", EditConditionHides))
	float BlendInTimeSeconds = 0.2f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName="隐藏过渡时间(秒)", EditCondition= "bUseBlendTime", EditConditionHides))
	float BlendOutTimeSeconds = 0.2f;
};

