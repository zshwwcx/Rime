/**
 * Auth :   liubo
 * Date :   2026-02-07 15:21
 * Comment: 实验功能，有很多临时代码，不要正式使用
 */
 
#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Animation/AnimNodeBase.h"
#include "BoneContainer.h"
#include "BonePose.h"
#include "CommonAnimTypes.h"
#include "Animation/AnimInstanceProxy.h"
#include "Animation/AnimExecutionContext.h"
#include "Animation/AnimNode_SequencePlayer.h"
#include "AnimNode_AIBodyPlayer.generated.h"

USTRUCT(BlueprintInternalUseOnly)
struct KGCHARACTER_API FAnimNode_AIBodyPlayer : public FAnimNode_SequencePlayer
{
	GENERATED_USTRUCT_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinShownByDefault))
		FName Tag;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinShownByDefault))
		FName BodyPartName;
	
public:
	FAnimNode_AIBodyPlayer();

	// 注意，播放动画前，设置。播放过程中，修改是不合理的。
	void ChangeAnim(UAnimSequenceBase* NewAnim);
};