#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimInstance.h"
#include "Animation/BlendSpace1D.h"
#include "Animation/AnimSequence.h"
#include "Animation/AnimInstanceProxy.h"
#include "3C/Animation/AnimInstanceStruct.h"
#include "3C/Animation/ALS/ALS_AnimInstanceStruct.h"
#include "3C/Animation/AnimCommon.h"
#include "LuaOverriderInterface.h"
#include "3C/RoleComposite/RoleCompositeManager.h"
#include "3C/Animation/AnimLayer/BaseAnimLayer.h"
#include "AnimNode_KawaiiPhysicsAllInOne.h"
#include "3C/Animation/AnimLayer/FaceAnimLayer.h"
#include "3C/Animation/AnimationGraphNode/AnimNode_ThreeLayerPostureBlend.h"
#include "Misc/CommonDefines.h"
#include "Animation/AnimTypes.h"
#include "3C/Movement/MovementPipeline/MovementContext.h"
#include "Curves/CurveFloat.h"
#include "Curves/CurveVector.h"

#include "BaseAnimInstance.generated.h"

class URoleMovementComponent;

struct FALSAnimGraphFootIK
{
	float FootLock_L_Alpha = 0.0f;
	float FootLock_R_Alpha = 0.0f;
	float FootIKApplyExtraRatio = 1.0f;
	FVector FootLock_L_Location = FVector::ZeroVector;
	FVector TargetFootLock_R_Location = FVector::ZeroVector;
	FVector FootLock_R_Location = FVector::ZeroVector;
	FRotator TargetFootLock_L_Rotation = FRotator::ZeroRotator;
	FRotator FootLock_L_Rotation = FRotator::ZeroRotator;
	FRotator TargetFootLock_R_Rotation = FRotator::ZeroRotator;
	FRotator FootLock_R_Rotation = FRotator::ZeroRotator;
	FVector FootOffset_L_Location = FVector::ZeroVector;
	FVector FootOffset_R_Location = FVector::ZeroVector;
	FRotator FootOffset_L_Rotation = FRotator::ZeroRotator;
	FRotator FootOffset_R_Rotation = FRotator::ZeroRotator;
	FVector PelvisOffset = FVector::ZeroVector;
	float PelvisAlpha = 0.0f;

};

struct FALSAnimConfiguration
{
	float SmoothedAimingRotationInterpSpeed = 10.0f;
	float FootHeight = 13.5f;
	float IK_TraceDistanceAboveFoot = 50.0f;
	float IK_TraceDistanceBelowFoot = 45.0f;
	float IK_SlopeAngle = 60;
	float IK_LockAlphaThreshold = 0.99f;
	FVector IK_KneeTargetLOffset{20, 30, 0};
	FVector IK_KneeTargetROffset{-20, -30, 0};
	float IK_StartStretchRatio = 1.0f;
	float IK_MaxStretchScale = 1.1f;
	float IK_PelvisInterSpeed = 3.0f;
	float IK_FootOffsetMaxOffset = 20.0f;
	float IK_EnableAlphaTransitionTime = 0.2f;
	float IK_FootIKApplyRatioThreshold = 0.8f;
	float IK_Tolerate_Distance = 100.0f;
	float IK_Tolerate_Angle = 15.0f;
};

struct FBoneAutoRotateInfo
{
	float RotateSpeed = 0.0f;
	ETransformOperateMask RotateAxesMask = ETransformOperateMask::NONE;
};

DECLARE_DYNAMIC_DELEGATE(FOnAnimTrivialSignificanceChangedDelegate);

/**
 * 动画蓝图基类
 */
UCLASS(BlueprintType, Blueprintable)
class KGCHARACTER_API UBaseAnimInstance : public UAnimInstance
{
	GENERATED_UCLASS_BODY()

#pragma region ALS_C++
public:
	UPROPERTY(BlueprintReadOnly, Category = "ALS|Character Information")
	TObjectPtr<class ABaseCharacter> OwnerCharacter = nullptr;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Character Information")
	EALS_MovementState MovementState = EALS_MovementState::None;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Character Information")
	EALS_Stance Stance = EALS_Stance::Standing;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Character Information")
	EALS_ViewMode ViewMode = EALS_ViewMode::ThirdPerson;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Character Information")
	EALS_RotationMode ALS_RotationMode = EALS_RotationMode::VelocityDirection;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Anim Graph - Layer Blending", Meta = (ShowOnlyInnerProperties))
	FALS_AnimGraphLayerBlending LayerBlendingValues;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Anim Graph - Grounded")
	FALS_VelocityBlend VelocityBlend;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Anim Graph - Grounded")
	float DiagonalScaleAmount = 0.0f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "ALS|Configuration|Blend Curves")
	TObjectPtr<UCurveFloat> DiagonalScaleAmountCurve = nullptr;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Configuration|Blend Curves")
	TObjectPtr<UCurveFloat> StrideBlend_N_Walk = nullptr;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Configuration|Blend Curves")
	TObjectPtr<UCurveFloat> StrideBlend_N_Run = nullptr;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Configuration|Blend Curves")
	TObjectPtr<UCurveFloat> StrideBlend_C_Walk = nullptr;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Configuration|Blend Curves")
	TObjectPtr<UCurveVector> YawOffset_FB = nullptr;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Configuration|Blend Curves")
	TObjectPtr<UCurveVector> YawOffset_LR = nullptr;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Configuration|Dynamic Transition")
	TObjectPtr<UAnimSequenceBase> TransitionAnim_R = nullptr;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Configuration|Dynamic Transition")
	TObjectPtr<UAnimSequenceBase> TransitionAnim_L = nullptr;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Configuration|Dynamic Transition")
	TObjectPtr<UAnimSequenceBase> F_TransitionAnim_R = nullptr;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Configuration|Dynamic Transition")
	TObjectPtr<UAnimSequenceBase> F_TransitionAnim_L = nullptr;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Anim Graph - Grounded")
	FVector RelativeAccelerationAmount = FVector::ZeroVector;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Anim Graph - Grounded")
	FALS_LeanAmount LeanAmount;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Anim Graph - Grounded")
	float WalkRunBlend = 0.0f;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Anim Graph - Grounded")
	float StrideBlend = 0.0f;
	
	UPROPERTY(BlueprintReadOnly, Category = "ALS|Anim Graph - Grounded")
	float StandingPlayRate = 1.0f;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Anim Graph - Grounded")
	EALS_MovementDirection MovementDirection = EALS_MovementDirection::Forward;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Anim Graph - Grounded")
	bool IsForwardMovementDirection = true;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Anim Graph - Grounded")
	bool IsBackwardMovementDirection = false;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Anim Graph - Grounded")
	bool IsLeftMovementDirection = false;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Anim Graph - Grounded")
	bool IsRightMovementDirection = false;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Anim Graph - Grounded")
	float FYaw = 0.0f;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Anim Graph - Grounded")
	float BYaw = 0.0f;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Anim Graph - Grounded")
	float LYaw = 0.0f;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Anim Graph - Grounded")
	float RYaw = 0.0f;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Anim Graph - Grounded")
	bool bRotateL = false;

	UPROPERTY(BlueprintReadOnly, Category = "ALS|Anim Graph - Grounded")
	bool bRotateR = false;

	/** Turn In Place */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "ALS|Configuration|Turn In Place", Meta = (
		ShowOnlyInnerProperties))
	FALS_AnimTurnInPlace TurnInPlaceValues;

	/** Configuration */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "ALS|Configuration|Main Configuration", Meta = (ShowOnlyInnerProperties))
	FALS_AnimConfiguration Config;

	/** Rotate In Place */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "ALS|Configuration|Rotate In Place", Meta = (
		ShowOnlyInnerProperties))
	FALS_AnimRotateInPlace RotateInPlace;

public:
	virtual void NativeInitializeAnimation() override;
	void ALS_NativeUpdateAnimation(float DeltaSeconds);

#pragma region ALS
public:
	// 是否为ALS模式
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bIsALSMode = false;

	// ALS的LocoState名称到默认万向移动的LocoState名称映射
	TMap<FName, FName> ALSLocoNameToCommonLocoNameMap;

	// 0:Run; 1:Walk; 2:Sprint
	UPROPERTY(Transient, BlueprintReadOnly)
	int ALSMovePosture = 0;

	// 0:Forward; 1:Left; 2:Right; 3:Back
	UPROPERTY(Transient, BlueprintReadOnly)
	int ALSLocoDirection = 0;

	UPROPERTY(Transient, BlueprintReadOnly)
	bool bShouldMove = false;

	UPROPERTY(Transient, BlueprintReadWrite, Category = "ALS")
	EALS_OverLayState ALS_OverLayState = EALS_OverLayState::Default;

	UPROPERTY(Transient, BlueprintReadOnly)
	bool bIsLockingTarget = false;

	UPROPERTY(Transient, BlueprintReadOnly)
	FRotator AimingRotation{ 0, 0, 0 };

	UPROPERTY(Transient, BlueprintReadOnly)
	float AimYawRate = 0.0f;

	UPROPERTY(Transient, BlueprintReadOnly)
	float LookAnimPercent = 0.0f;

	UPROPERTY(Transient, BlueprintReadWrite)
	FRotator SmoothedAimingRotation;

	UPROPERTY(Transient, BlueprintReadWrite)
	FVector2D AimingAngle;

	UPROPERTY(Transient, BlueprintReadWrite)
	FVector2D SmoothedAimingAngle;

	UPROPERTY(Transient, BlueprintReadWrite)
	float AimSweepTime = 0.f;

	UPROPERTY(Transient, BlueprintReadWrite)
	FRotator SpineRotation;

	UPROPERTY(Transient, BlueprintReadWrite)
	float LeftYawTime = 0.f;

	UPROPERTY(Transient, BlueprintReadWrite)
	float RightYawTime = 0.f;

	UPROPERTY(Transient, BlueprintReadWrite)
	float ForwardYawTime = 0.f;

	UPROPERTY(Transient, BlueprintReadWrite)
	bool bIsInStopTransitionCoolDown = false;

public:
	void SetIsALSMode(bool InIsALSMode) { bIsALSMode = InIsALSMode; }

	void SetALSMovePosture(int Posture) { ALSMovePosture = Posture; }

	void SetALSLocoNameToCommonLocoNameMap(const TMap<FName, FName>& InMap) { ALSLocoNameToCommonLocoNameMap = InMap; }

	float TriggerALSDodge(const FName& StateName, const float& BlendDuration);

	UFUNCTION(BlueprintCallable, Category = "ALS")
	static float GetNormalizedAimingYaw(float PreviousYaw, float CurrentYaw);

	void SetALSAnimConfig(
		float SmoothedAimingRotationInterpSpeed = 10.0f, float FootHeight = 13.5f, float IK_TraceDistanceAboveFoot = 50.0f, float IK_TraceDistanceBelowFoot = 45.0f,
		float IK_SlopeAngle = 60, float IK_LockAlphaThreshold = 0.99f,
		const FVector & IK_KneeTargetLOffset=FVector{20, 30, 0}, const FVector & IK_KneeTargetROffset=FVector{-20, -30, 0},
		float IK_StartStretchRatio = 1.0f, float IK_MaxStretchScale = 1.1f, float IK_PelvisInterSpeed=3.0, float IK_FootOffsetMaxOffset=20, float IKAlphaTransitionTime=0.2f,
		float IK_TolerateDistance = 100.0f, float IK_Tolerate_Angle = 15.0f);

	void SetForbiddenALSFootIKDuration(float duration, bool ForbiddenImmediately, bool IsAddDuration);
	void ForbiddenALSFootIKShortlyAndImmediately(float ShortTime=0.2f);
	
protected:
	float PreviousAimYaw = 0.0f;
	bool EnableALSFootIK = false;
	float ForbiddenALSFootIKDuration = 0;
	float EnableFootIKAlpha = 0.0f;
	FALSAnimGraphFootIK FootIKValues;
	FALSAnimConfiguration ALSAnimConfig;
	void UpdateALSData(URoleMovementComponent& RoleMC, float TimeDelta);
	void SetFootLocking(
	float DeltaSeconds, float EnableFootIKAlpha, FName FootLockCurve, FName IKFootBone, float& CurFootLockAlpha,
	FVector& CurFootLockLoc, FRotator& CurFootLockRot);
	void SetFootLockOffsets(float DeltaSeconds, FVector& LocalLoc, FRotator& LocalRot);
	void SetPelvisIKOffset(float DeltaSeconds, FVector FootOffsetLTarget, FVector FootOffsetRTarget);
	void ResetIKOffsets();
	void SetFootOffsets(URoleMovementComponent & Character, float DeltaSeconds, float EnableFootIKAlpha, FName IKFootBone,FName RootBone, FVector& CurLocationTarget,
		FVector& CurLocationOffset, FRotator& CurRotationOffset);

private:
	FTimerHandle PlayDynamicTransitionTimer;
	bool bCanPlayDynamicTransition = true;

private:
	void ALS_CalculateAimingValues(float DeltaSeconds);
	void ALS_UpdateLayerValues();
	void ALS_UpdateFootIK(URoleMovementComponent& RoleMC, float DeltaSeconds);
	void ALS_UpdateMovementValues(float DeltaSeconds);
	void ALS_UpdateRotationValues();
	struct FALS_VelocityBlend ALS_CalculateVelocityBlend() const;
	float ALS_CalculateDiagonalScaleAmount() const;
	FVector ALS_CalculateRelativeAccelerationAmount() const;
	float ALS_CalculateStrideBlend() const;
	float ALS_CalculateWalkRunBlend() const;
	float ALS_CalculateStandingPlayRate() const;
	EALS_MovementDirection ALS_CalculateMovementDirection() const;
	bool ALS_CanRotateInPlace() const;
	void ALS_RotateInPlaceCheck();
	bool ALS_CanTurnInPlace() const;
	void ALS_TurnInPlaceCheck(float DeltaSeconds);
	void ALS_TurnInPlace(FRotator TargetRotation, float PlayRateScale, float StartTime, bool OverrideCurrent);
	bool ALS_CanDynamicTransition() const;
	void ALS_DynamicTransitionCheck();

	UFUNCTION(BlueprintCallable, Category = "ALS|Animation")
	void ALS_PlayDynamicTransition(float ReTriggerDelay, FALS_DynamicMontageParams Parameters);
	
	UFUNCTION(BlueprintCallable, Category = "ALS|Animation")
	void ALS_PlayTransition(const FALS_DynamicMontageParams& Parameters);

	UFUNCTION(BlueprintCallable, Category = "ALS|Animation")
	void ALS_PlayTransitionChecked(const FALS_DynamicMontageParams& Parameters);

	float GetAnimCurveClamped(const FName& Name, float Bias, float ClampMin, float ClampMax) const;
	void ALS_PlayDynamicTransitionDelay();
#pragma endregion ALS

#pragma region ALSTurn
public:
	// ALS 原地转身 
	UPROPERTY(Transient, BlueprintReadOnly)
	int AlsIdleIndex = 0;
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bAlsTurnLeft90IP = false;
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bAlsTurnRight90IP = false;
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bAlsTurnLeft180IP = false;
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bAlsTurnRight180IP = false;

protected:
#pragma endregion ALSTurn
#pragma endregion ALS_C++

protected:
	static TMap<FName, uint8> StateNameToStateTypeMap;
	static TMap<uint8, FName> StateTypeToStateNameMap;
	static TMap<FString, FName> ClothingToKawaiiMap;
	static TMap<FString, TArray<FName>> ClothingToKawaiiNodeMap;
	
	static bool bIsLocomotionStateTypeMapsInitialized;
	static bool bIsClothingToKawaiiMapInitialized;
	
	static const int UnusedSemanticTag = -1;

	static bool bAnimSkeletonCheck;
	static bool bAnimSkeletonSlotCheck;
public:
	static void EnableAnimSkeletonCheck(bool bEnable) { bAnimSkeletonCheck = bEnable; }
	static void EnableAnimSkeletonSlotCheck(bool bEnable) { bAnimSkeletonSlotCheck = bEnable; }
	static bool IsNeedAnimSkeletonCheck() { return bAnimSkeletonCheck; }
	static bool IsNeedAnimSkeletonSlotCheck() { return bAnimSkeletonSlotCheck; }

	// 动画蓝图变量初始化函数
	void InitBaseAnimInstanceParam();
	virtual void ResetToDefaultsForCache();
	
	FOnAnimTrivialSignificanceChangedDelegate  TrivialSignificanceChangedDelegate;

	static uint8 GetStateTypeByName(const FName& StateName)
	{
		if (!StateNameToStateTypeMap.Contains(StateName))
		{
			return 0;
		}
		return StateNameToStateTypeMap[StateName];
	}

	static FName GetStateNameByType(const uint8 StateType)
	{
		if (!StateTypeToStateNameMap.Contains(StateType))
		{
			return FName();
		}
		return StateTypeToStateNameMap[StateType];
	}

	UFUNCTION(BlueprintCallable)
	static void InitLocomotionStateTypeMaps(const TMap<FName, uint8>& NewStateNameToStateTypeMap, const TMap<uint8, FName>& NewStateTypeToStateNameMap);

	UFUNCTION(BlueprintCallable)
	static bool IsLocomotionStateTypeMapsInitialized();

	UFUNCTION(BlueprintCallable)
	static void InitClothingToKawaiiMap(const TMap<FString, FName>& InClothingToKawaiiMap);

	UFUNCTION(BlueprintCallable)
	static void InitClothingToKawaiiNodeMap(const FString InClothingToKawaiiKey, const TArray<FName>& KawaiiNodeMap);

	UFUNCTION(BlueprintCallable)
	static bool IsClothingToKawaiiMapInitialized();

public:
	UFUNCTION(BlueprintCallable, Category = "Montage")
	void Montage_SetBlendTime(UAnimMontage* InMontage, float BlendIn, float BlendOut, bool bEnableAutoBlendOut = true, float BlendOutTriggerTime = -1.0f);

	UFUNCTION(BlueprintCallable, Category = "Montage")
	void Montage_SetBlendOption(UAnimMontage* InMontage, FAlphaBlend BlendIn, FAlphaBlend BlendOut, bool bEnableAutoBlendOut = true);

	UFUNCTION(BlueprintCallable, meta=(DisplayName="StopAllMontages"), Category = "Montage")
	void StopAllMontagesBP(float BlendOut) { StopAllMontages(BlendOut);};

public:
	//追踪目标骨骼
	UFUNCTION(BlueprintCallable)
	void PushTrackTargetBone(FTrackTargetBone TrackTargetBone);


private:
	//更新追踪目标骨骼信息
	void UpdateTrackTargetBone(float DeltaTime);

protected:
	//当前插槽是否在播放
	UFUNCTION(BlueprintPure, Category = "Slot", meta = (BlueprintThreadSafe))
	bool IsSlotMontagePlaying(FName SlotNodeName) const;

public:
	//当前MorphTarget曲线值
	UFUNCTION(BlueprintPure, Category = "Animation")
	float GetMorphTargetCurveValue(FName CurveName) const;


	UFUNCTION(BlueprintCallable)
	float GetCacheAttributeCurveValue(FName CurveName);

	void ForceExecuteNotifyStateEnd(FString NotifyStateName);
	
	virtual void NativeUpdateAnimation(float DeltaSeconds) override;

	virtual void NativePostEvaluateAnimation() override;

	virtual void NativeUninitializeAnimation() override;

protected:
	void CalWanderingVelYawAndSpeedOrient(const FVector& ActorVelocity, float FaceYaw, FVector2D& InFaceVelDiffVec);

	
#if WITH_EDITOR
protected:
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

#endif


public:

	UFUNCTION(BlueprintCallable, BlueprintPure)
	float GetMontageCurrentPosition(UAnimMontage* CheckMontage);

	UFUNCTION(BlueprintCallable, BlueprintPure)
	UAnimMontage* GetSlotPlayingMontage(FName SlotName);

	UFUNCTION(BlueprintCallable)
	void GetAllActiveAnimationMessages(TArray<FString>& OutMessages, bool NeedSyncGroupAnims=false);
	
	UFUNCTION(BlueprintCallable)
	void SetIsSlaveAnimControl(bool isSlave);

	int GetLocoSequencePrioritysSize() const { return LocoSequencePrioritys.Num(); }

	UFUNCTION(BlueprintPure, meta = (BlueprintThreadSafe))
	UAnimSequenceBase* GetSequenceFromAssetID(const FAnimNodeAssetID& AssetID);

	bool GetAnimSequenceBaseCurrentPlayedTime(UAnimSequenceBase * TargetAnim, float & OutCurrentPlayedTime);
	
protected:
#pragma region AnimationLoadManagement
	FName AnimLibItemName = NAME_None;
	TArray<int> LocoSequencePrioritys;
	TArray<bool> LocoSequenceForbidden; // 禁用某一层的动画内容, 用于变身过程中重复进行服装动作替换带来的动作加卸载
	TArray<TMap<FName, TWeakObjectPtr<UAnimSequenceBase>>> LocoSequenceMappings;
	// ABP里面在用, 这里就要hold住生命周期
	UPROPERTY(Transient)
	TMap<FName, TObjectPtr<UAnimSequenceBase>> FinalLocoAnimAssets;

public:
	UFUNCTION(BlueprintCallable)
	void InitLocoSequenceContainerSize(uint8 size, FName animLibName);

	UFUNCTION(BlueprintCallable)
	bool ObtainLocoSequenceMappingWithPriorityIndex(uint8 priorityIndex, uint8 prioritySemanticTag, const TMap<FName, UAnimSequenceBase*>& seqMap);

	UFUNCTION(BlueprintCallable)
	bool ReleaseLocoSequenceMappingWithPriorityIndex(uint8 priorityIndex);

	UFUNCTION(BlueprintCallable)
	int GetLocoSequenceSemanticByPriorityIndex(uint8 priorityIndex);

	UFUNCTION(BlueprintCallable)
	void RefreshLocoAnimSequenceInABP();

	UFUNCTION(BlueprintCallable)
	bool UpdateAnimSequenceInLocoSequenceMapping(uint8 priorityIndex, const TMap<FName, UAnimSequenceBase*>& seqMap);

	bool SetLocoSequenceForbiddenByPriorityIndex(uint8 PriorityIndex, bool IsForbidden);
	
	void ReplaceSequenceInABP(TMap<FName, TObjectPtr<UAnimSequenceBase>> & seqMap);
	
	void ReplaceSequenceInABPLayer(TMap<FName, TObjectPtr<UAnimSequenceBase>>& seqMap);

	void SetAssetIDSequencePlayer(UAnimInstance* AnimInstance, FStructProperty* MachineInstanceProperty, TMap<FName, TObjectPtr<UAnimSequenceBase>>& seqMap);

	void SetBoneTrackActorInfo(FName BoneName, KGObjectID TargetActorID, float Speed, FVector LocketOffset, float InTrackDuration);

	void DelBoneTrackActorInfo(FName BoneName, bool bDelAll);
	
	void UpdateTrackActorBoneTransform(float deltaSeconds);

	void GetLocoAnimRootMotionInfo(FName LocoAnimName, float StartTime, float SampleTime, float & DurationOut, float & DistanceOut, float & YawDiffOut);
	FTransform GetLocoAnimRootMotion(FName LocoAnimName, float StartTime, float DeltaTime, bool AllowLoop);
	
	// 定制接口: 计算Loop混出End合适的时机
	float CalculateLoopToEndTimeWithDistance(FName LStartName, FName RStartName, FName LoopName, FName LEndName, FName REndName, float InLeftDistance, float MapInX, float MapInY, float MapOutX, float MapOutY,
		int LStartEnterLoopFrame, int RStartEnterLoopFrame, float& OutLoopMoveDuration, float& OutEndStartTime, float& OutTotalTime, float &OutStartDuration, FName &OutStartName, FName& OutEndAnimName);
	float CalculateLoopToEndOptimisationDistance(FName StartName, FName LoopName, FName LEndName, FName REndName, float TotalSplineLength, float MapInX, float MapInY, float MapOutX, float MapOutY, int EnterLoopFrame, 
		float& OutStartMoveDuration, float& OutLoopMoveDuration, float& OutEndStartTime, FName& OutEndAnimName, int& OutFrame, float& OutLoopStartTime);
	float CalculateOptimisationLeftDistance(FName StartName, FName LoopName, FName LEndName, FName REndName, float MapInX, float MapInY, float MapOutX, float MapOutY,
		int StartToLoopFrame, float AvgLoopSpeed, float LeftDistance, float EndDistance, FName& OutEndAnimName, float& OutEndStartTime, int& OutFrame, float& OutLoopLeftTime);
	
	void SetLocEnableBodyLean(bool bEnable);
	void SetLocEnableInputAxis(bool bEnable);
	void SetIsMaleSex(bool IsMale) {IsMaleSex = IsMale;}
#pragma endregion

#pragma region AnimationCurveData
public:
	// 业务相关数据
	UPROPERTY(Transient, BlueprintReadOnly)
	bool IsMaleSex = true;
	UPROPERTY(Transient, BlueprintReadOnly)
	int FootPosture = 0;
	UPROPERTY(Transient, BlueprintReadOnly)
	bool BooleanFootPosture = false;
	UPROPERTY(Transient, BlueprintReadOnly)
	float FootCurveRatioValue = 0.0f;

	// IK 开关数据
	UFUNCTION(BlueprintCallable)
	void SetIsEnableRideMountIK(bool EnableHandIK, FName LHandBoneName, FName RHandBoneName, bool EnableFootIK, FName LFootBoneName, FName RFootBoneName);
	UFUNCTION(BlueprintCallable)
	void EnableEyesIk(bool bEnable);

	// 曲线相关数据
	// 关闭Kawaii曲线数据值计算
	UPROPERTY(Transient, BlueprintReadOnly)
	float DisableKawaii = 0.0f;
	UPROPERTY(Transient, BlueprintReadOnly)
	float DisableKawaiiCloak = 0.0f;
	UPROPERTY(Transient, BlueprintReadOnly)
	float DisableKawaiiSkirt = 0.0f;
	UPROPERTY(Transient, BlueprintReadOnly)
	float DisableKawaiiAlpha = 0.0f;

	// BlendOutTime曲线数据
	UPROPERTY(Transient, BlueprintReadOnly)
	float BlendOutTimeCurveValue = 0.0f;
	
	UPROPERTY(Transient)
	TWeakObjectPtr<class USkeletalMeshComponent> MountMeshPtr = nullptr;

	void SetFootPostureCurveName(const FName& InName) { FootPostureCurveName = InName; }
protected:
	// 曲线名称相关配置
	// 左右脚曲线
	FName FootPostureCurveName = FName("FootCurve");
	
	UPROPERTY(Transient, BlueprintReadOnly)
	float EnableIK_FootL_CurveValue = 0.0f;
	UPROPERTY(Transient, BlueprintReadOnly)
	float EnableIK_FootR_CurveValue = 0.0f;
	
#pragma endregion animationCurveData


#pragma region AnimationIK
protected:
	bool UsingFootLock = false;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "AnimIK")
	FVector LockPosition_FootL{0, 0, 0};

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "AnimIK")
	FVector LockPosition_FootR{0, 0, 0};

	FName FootL_BoneName = FName("foot_l");
	FName FootR_BoneName = FName("foot_r");
public:

	// todo 先验证dialogue中的ik, 后续要改成我们自己的C7 ModifyBones的用法 @孙亚
	void UseFootLock(bool IsUse, FName LeftIKBoneName, FName RightIKBoneName) {UsingFootLock=IsUse; FootL_BoneName=LeftIKBoneName; FootR_BoneName=RightIKBoneName;}

#pragma endregion AnimationIK
protected:

	FName PrevSMStateName = NAME_None;
	FName CurSMStateName = NAME_None;
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "CharacterAnim Config")
	FThreeLayerPostureParam ThreeLayerPostureParam;

	UPROPERTY(Transient)
	bool bLowerLocoWorking = false;
	
	UPROPERTY(Transient)
	TMap<int, FName> ThreeLayerPerformBoneMap;

	// 骨骼追踪功能
	TMap<FString, FTrackTargetBone> TrackTargetBoneMap;
	TMap<FName, FVector> TargetBoneTranslationMap;
	TMap<FName, FRotator> TargetBoneRotMap;
	TMap<FName, FVector> TargetBoneScaleMap;
	TMap<FName, FBoneTrackActorInfo> BoneTrackActorMap;
	TMap<FName, FVector> BoneStartPosMap;
	
	// UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "RelInputAxis Config")
	// int DeltaAngleNum = 10;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "RelInputAxis Config")
	TArray<float> MovePostureRate = {1.f, 0.f, 1.f};
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "RelInputAxis Config")
	float EnableLeanMinAngle = 10.f;
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "RelInputAxis Config")
	float BodyLeanEasyInInterpHalfTime = 0.05f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "RelInputAxis Config")
	float BodyLeanEasyOutInterpHalfTime = 0.05f;
	
	// 无输入转向时 累计角度减小速度
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "RelInputAxis Config")
	float RelAngleAccumulateEasyOutHalfTime = 0.05f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "IK Bone Data")
	FIKConfig_HandFoot HandFootIKConfig;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "IK Bone Data")
	FIKConfig_Common CommonIKConfig;

#pragma region Mount
public:
	UFUNCTION(BlueprintCallable)
	void SetMountType(int Type) {
		MountType = Type; bIsBikeMountType = Type == (int)EMountType::Bike;
		bIsHorseMountType = Type == (int)EMountType::Horse; bIsCarMountType = Type == (int)EMountType::Car;
	}

	UFUNCTION(BlueprintCallable)
	void SetIsMountRider(bool IsMountRider) { bMountRider = IsMountRider; }

	// 坐骑类型
	UPROPERTY(BlueprintReadWrite, Transient)
	int MountType = 0;
	UPROPERTY(BlueprintReadWrite, Transient)
	bool bIsBikeMountType = true;
	UPROPERTY(BlueprintReadWrite, Transient)
	bool bIsHorseMountType = false;
	UPROPERTY(BlueprintReadWrite, Transient)
	bool bIsCarMountType = false;

	// 身份参数
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bMountRider = true;
#pragma endregion Mount

#pragma region Dialogue
public:
	void DialogueCrossfadeToStage(EDialogueStage DialogueStage, bool bCrossInstance = false);
	void DialogueUpdateStagePercent(EDialogueStage DialogueStage, float Percent);

	void UpdateSequenceStartTime(float StartTime, float StartToLoopTime, float LoopToEndTime);
	
	float GetSequenceStartToLoopStartTime() { return SequenceStartToLoopStartTimeCache; }
	float GetSequenceLoopToEndStartTime() { return SequenceLoopToEndStartTimeCache; }

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "DialogueConfig")
	float CrossTimeOfIdle = 0.f;
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "DialogueConfig")
	float CrossTimeOfStart = 0.1f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "DialogueConfig")
	float CrossTimeOfLoop = 0.1f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "DialogueConfig")
	float CrossTimeOfEnd = 0.2f;
	
protected:
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "DialogueConfig")
	bool bDebugDialogueLog = false;
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "DialogueConfig")
	float LoopToEndThreshold = 15.f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "DialogueConfig")
	FName DialogueMoveIdleState = "Idle";
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "DialogueConfig")
	FName DialogueMoveStartState = "DialogueWalkStart";

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "DialogueConfig")
	FName DialogueMoveLoopState = "DialogueWalkLoop";

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "DialogueConfig")
	FName DialogueMoveEndState = "DialogueWalkEnd";
		
	// 起步姿势
	UPROPERTY(BlueprintReadWrite)
	int SequenceStartFootPosture = 0;
	// Start 开始时间
	UPROPERTY(BlueprintReadWrite)
	float SequenceBeginStartTime = 0.f;
	// Loop 开始时间
	UPROPERTY(BlueprintReadWrite)
	float SequenceStartToLoopStartTime = 0.f;
	// 停步开始时间
	UPROPERTY(BlueprintReadWrite)
	float SequenceLoopToEndStartTime = 0.f;

private:
	EDialogueStage CurDialogueStage = EDialogueStage::None;
	float SequenceStartToLoopStartTimeCache = 0.f;
	float SequenceLoopToEndStartTimeCache = 0.f;
#pragma endregion Dialogue
	
#pragma region Body Posture
public:
	UFUNCTION(BlueprintCallable)
	void SetBodyLeanAxisDataSource(EBodyLeanAxisDataSource DataSource);

	UFUNCTION(BlueprintCallable)
	void AddModifyBoneParam(FName BoneName, EC7BoneModificationMode LocMode, EC7BoneModificationMode RotMode, EC7BoneModificationMode ScaleMode, EBoneControlSpace BoneControlSpace, float LocX, float LocY,
		float LocZ, float Pitch, float Yaw, float Roll, float ScaleX, float ScaleY, float ScaleZ, FName AlphaCurveName, float AlphaCurveDefaultValue, float BlendAlpha=1.0f);

	UFUNCTION(BlueprintCallable)
	void UpdateModifyBoneParam(FName BoneName, float LocX, float LocY, float LocZ, float Pitch, float Yaw, float Roll, float ScaleX, float ScaleY, float ScaleZ, float Alpha);
	void UpdateModifyBoneAlphaParam(FName BoneName, float Alpha);
	void UpdateModifyBoneAutoAdd(FName BoneName, EC7BoneModificationMode LocMode, EC7BoneModificationMode RotMode, EC7BoneModificationMode ScaleMode, EBoneControlSpace BoneControlSpace, float LocX, float LocY,
		float LocZ, float Pitch, float Yaw, float Roll, float ScaleX, float ScaleY, float ScaleZ, FName AlphaCurveName, float AlphaCurveDefaultValue, float Alpha);
	
	UFUNCTION(BlueprintCallable)
	void RemoveModifyBone(FName BoneName);

	UFUNCTION(BlueprintCallable)
	void RemoveModifyBones(TArray<FName> BoneNameArr);
	
	// Sequence 执行 LookAt 的专属接口
	void SequenceUpdateGazeBonesModify(FRotator Eye, FVector EyeScale, FRotator Head, FRotator Body, FRotator Spine_01, FRotator Spine_02, FRotator Spine_03);
	
	// 先给简单版本, 复杂版本后面按需扩展
	UFUNCTION(BlueprintCallable)
	void AddTwoBoneIKParamSimply(FName IKBoneName, FName JointBoneName, float EL_X, float EL_Y, float EL_Z, FName AlphaCurveName, float AlphaCurveDefaultValue);
	void AddAndResetTwoBoneIKParamSimply(FName IKBoneName, FName JointBoneName, float EL_X, float EL_Y, float EL_Z, FName AlphaCurveName, float AlphaCurveDefaultValue, const FVector& JointTargetLocation);
	UPROPERTY(EditAnywhere, Category=SkeletalControl)
	FBoneReference IKBone;

	void AddOrUpdateTwoBoneIKParam(
		FName IKBoneName,
		EBoneControlSpace EffectorLocationSpace,
		bool bTakeRotationFromEffectorSpace ,
		FName EffectorTargetBoneName,
		EC7TwoBoneIKModificationMode EffectorLocationMode=EC7TwoBoneIKModificationMode::TBMM_Replace,
		const FVector & EffectorLocation=FVector::Zero(),
		float StartStretchRatio = 1.0f,
		float MaxStretchScale = 1.2f,
		bool bAllowStretching = false,
		bool bMaintainEffectorRelRot = false,
		bool bAllowTwist = true,
		const FAxis & TwistAxis=FVector::ForwardVector,
		EBoneControlSpace JointBoneControlSpace = EBoneControlSpace::BCS_BoneSpace,
		FName JointTargetBoneName=NAME_None,
		const FVector & JointTargetLocation=FVector::Zero(),
		float BlendAlpha = 1.0f,
		FName AlphaCurveName = NAME_None,
		float AlphaDefaultValue = 0.0f
	);

	UFUNCTION(BlueprintCallable)
	bool HasTwoBoneIK(const FName& IKBoneName);
	
	void AddTwoBoneIKParamByAdditiveEffectorMode(FName IKBoneName, FName JointBoneName, float EL_X, float EL_Y, float EL_Z, FName AlphaCurveName, float AlphaCurveDefaultValue);
	
	UFUNCTION(BlueprintCallable)
	void UpdateTwoBoneIKParamSimply(FName IKBoneName, float EL_X, float EL_Y, float EL_Z, float Alpha);
	void UpdateTwoBoneIKParamSimply(FName IKBoneName, const FVector& TargetPos, float Alpha);
	void UpdateTwoBoneIKParamSimplyOnlyAlpha(FName IKBoneName, float Alpha);

	UFUNCTION(BlueprintCallable)
	void RemoveTwoBoneIKParam(FName IKBoneName);

	void UpdateRideMountIkInfo(URoleMovementComponent* RoleMCPtr, APawn* OwnerPtr);
	
	void AddBoneAutoRotate(FName BoneName, float RotateSpeed, ETransformOperateMask RotateAxesMask);

	void RemoveBoneAutoRotate(FName BoneName, bool bReset);

	void UpdateBoneAutoRotate(float DeltaTime);

	// 是否允许姿态倾斜（注意初始值和RoleMovementComp的BodyLeanSwitch保持一直）
	UPROPERTY(Transient, BlueprintReadWrite)
	bool BodyLeanSwitch = false;
	// 是否允许轴输入数据（注意初始值和RoleMovementComp的BodyLeanSwitch保持一直）
	UPROPERTY(Transient, BlueprintReadWrite)
	bool InputAxisSwitch = true;
	// 是否开启计算姿态倾斜
	UPROPERTY(Transient, BlueprintReadWrite)
	bool bEnableCalculateBodyLean = false;
	// 是否开启计算轴输入数据
	UPROPERTY(Transient, BlueprintReadWrite)
	bool bEnableCalculateInputAxis = false;

	// 轴输入映射值
	UPROPERTY(Transient, BlueprintReadOnly)
	float RelInputAxisToForward = 0;
	UPROPERTY(Transient, BlueprintReadOnly)
	float RelInputAxisToRight = 0;
	// 姿态倾斜系数
	UPROPERTY(Transient, BlueprintReadOnly)
	float BodyLeanAlpha = 0;

	UPROPERTY(Transient, BlueprintReadOnly)
	TMap<FName, FC7ModifyBones_Params> BonesModifyMap;
	
	UPROPERTY(Transient, BlueprintReadOnly)
	TMap<FName, FC7BatchTwoBoneIKB_Params> BatchTwoBoneIKParams;

	UPROPERTY(Transient, BlueprintReadWrite)
	float BatchIKAlpha = 0;

	UPROPERTY(Transient, BlueprintReadWrite)
	float ArmAdditiveAlpha = 0;

	void SetArmAdditiveAlpha(float Alpha, float DisableInterpSpeed) { LuaArmAdditiveAlpha = Alpha; DisableArmAdditiveInterpSpeed = DisableInterpSpeed;}

	void UpdateBatchIKAlpha();
	void UpdateBodyLeanAlpha(URoleMovementComponent* RoleMCPtr, float DeltaSeconds);
	void UpdateRelInputAxis(URoleMovementComponent* RoleMCPtr);

	float LuaArmAdditiveAlpha = 0.f;
	float CurveArmAdditiveAlpha = 1.f;
	float DisableArmAdditiveInterpSpeed = 0.f;
	
	float InputRelAngleAccumulate = 0.f;
	FRotator LastFrameAnimRotator = FRotator::ZeroRotator;

	// TArray<float> ArrayOfDeltaFrameAngle;

	EBodyLeanAxisDataSource BodyLeanAxisDataSource = EBodyLeanAxisDataSource::None;

private:
	TMap<FName, FBoneAutoRotateInfo> MapOfBoneAutoRotate;
	TMap<FName, FRotator> BoneAutoRotateAxesCacheMap;
#pragma endregion

#pragma region AnimationSignificance
protected:
	// 是否开启计算姿态倾斜
	bool bEnableTrivialAnimSignificanceOffset = false;
	float ConfigTrivialAnimSignificanceOffset = 0;
	float CurTrivialAnimSignificanceOffset = 0;

public:
	float GetCurTrivialAnimSignificanceOffset() {return CurTrivialAnimSignificanceOffset;}
	void EnableTrivialAnimSignificanceOffset(bool bEnable, float SigOffset) {bEnableTrivialAnimSignificanceOffset = bEnable; ConfigTrivialAnimSignificanceOffset = SigOffset;}
#pragma endregion

#pragma region Layers Management
public:
	inline static FString KawaiiAlphaPrefix = "KawaiiAlpha_";
	inline static bool UseKawaiiAllInOne = true;
	inline static bool EnableAttachMeshKawaiiOptimize = true;
	inline static bool EnableMainMeshKawaiiOptimize = true;
	
	// Sequence Face Slot的权重，默认 1, Sequence预览需要
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "FaceSlot")
	float SequenceFaceBlendWeight = 1.0F;
	
protected:
	UPROPERTY(Transient)
	TMap<FName, TWeakObjectPtr<UBaseAnimLayer>> FeatureAnimLayers;
	TWeakObjectPtr<UFaceAnimLayer> FaceAnimLayerWeakPtr;
	
	inline static FName KawaiiAllInOnePropName = "EnableAllInOne";
	inline static FName KawaiiEnableASkirtControlRigPropName = "EnableASkirtControlRig";
	inline static FName KawaiiEnableNodeNameMapPropName = "EnableNodeNameMap";

    UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Kawaii")
    float KawaiiTransitionTime = 0.2f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Kawaii")
	FName KawaiiAlphaName = "GlobalKawaiiAlpha";

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Kawaii")
    FName PresetTypeWindScalePropName = "PresetTypeWindScale";

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Kawaii")
    FName ApplyWindScaleChangedCountName = "ApplyWindScaleChangedCount";

	float StartTransitionKawaiiAlpha = 0.f;
    float CurKawaiiTransitionTime = 0.f;
    bool bIsKawaiiTransition = false;
    bool bEnableKawaii = false;
	
	bool EnableASkirtControlRig = false;
	TMap<int64,TSet<FName>> AttachMeshKawaiiAlphaDisableMap;//挂接类型的是有布料的情况关闭对应的Kawaii节点
	FKawaiiNodeEnableMapStruct EnableKawaiiNodeMap;

	TMap<FName, float> AttachMeshKawaiiWindScaleMap;
	
public:
	UFUNCTION(BlueprintCallable)
	UBaseAnimLayer* LinkFeatureAnimLayer(FName FeatureLayerTag, TSubclassOf<UAnimInstance> InClass);

	UFUNCTION(BlueprintCallable)
	bool UnlinkFeatureAnimLayer(FName FeatureLayerTag);

	UFUNCTION(BlueprintCallable)
	bool HasLinkFeatureAnimLayer(FName FeatureLayerTag);
	
	UFUNCTION(BlueprintCallable)
	bool SetFeatureAnimLayerBoolProperty(FName AnimLayerTag, FName PropName, bool bValue);
	
	UFUNCTION(BlueprintCallable)
	bool SetFeatureAnimLayerFloatProperty(FName AnimLayerTag, FName PropName, float value);

	UFUNCTION(BlueprintCallable)
	bool SetFeatureAnimLayerFloatPropertys(FName AnimLayerTag, const TMap<FName, float> & FloatContainer);

	UFUNCTION(BlueprintCallable)
	void EnableAnimFeatureLayer(FName AnimLayerTag);

	UFUNCTION(BlueprintCallable)
	void DisableAnimFeatureLayer(FName AnimLayerTag);
	
	UFUNCTION(BlueprintCallable)
	UBaseAnimLayer* GetFeatureAnimLayer(const FName & FeatureLayerTag);

	UFUNCTION(BlueprintCallable)
	void LinkFaceAnimFeatureAnimLayer(FName FeatureLayerTag, TSubclassOf<UAnimInstance> InClass);

	UFUNCTION(BlueprintCallable)
	bool UnLinkFaceAnimFeatureAnimLayer(FName FeatureLayerTag);
	
	UFUNCTION(BlueprintCallable)
	void SetAnimLayerAnimAsset(FName AnimLayerTag, const TMap<FName, UAnimSequenceBase*>& InAnimMap);

	UFUNCTION(BlueprintCallable)
	void SetDefaultPerformMode(int mode);
	
	UFUNCTION(BlueprintCallable)
	void SetHighPriorityPerformMode(int mode);

	UFUNCTION(BlueprintCallable)
	void UpdateChaosClothAndKawaii(bool bChaosClothPermit, bool ForceRecreateCloth, bool bKawaiiPermit, const FName& AnimLayerTag,  bool HasKwaii, const FString& InClass);
	
	UFUNCTION(BlueprintCallable)
	void DisableChaosClothAndKawaii(const FName& AnimLayerTag);

	UFUNCTION(BlueprintCallable)
	void UpdateIsEnableChaosClothByTag(const FName& ComponentTag, bool bEnable);

	UFUNCTION(BlueprintCallable)
	void UpdateIsVisibleClothByTag(const FName& ComponentTag, bool bVisible);
	
	static void SetEnableKawaiiAllInOne(bool bEnable){
		UseKawaiiAllInOne = bEnable;
	}

	static void SetEnableAttachMeshKawaiiOptimize(bool bEnable){
		EnableAttachMeshKawaiiOptimize = bEnable;
	}
	
	static void SetEnableMainMeshKawaiiOptimize(bool bEnable){
		EnableMainMeshKawaiiOptimize = bEnable;
	}
	
	void SetEnableASkirtControlRig(bool bEnable){
		EnableASkirtControlRig = bEnable;
	}
	
	bool SetMainMeshKawaiiAlphaFloatPropertys(UBaseAnimLayer* AnimLayer);
	
	void SetAttachMeshKawaiiAlphaKeys(const int64& MeshComID, const TArray<FName>& KawaiiAlphaEnableArray, bool Enable, float WindScale);
    bool SetAttachMeshKawaiiAlphaFloatPropertys(UAnimInstance* AnimInstance, const int64& MeshComID, bool Enable);

    bool SetMainMeshKawaiiWindScalePropertys(UBaseAnimLayer* AnimLayer);

	bool SetAttachMeshKawaiiWindScalePropertys(UAnimInstance* AnimInstance);

	UFUNCTION(BlueprintCallable)
	void SetSequenceFaceBlendWeight(float Weight) {SequenceFaceBlendWeight = Weight;}
	
#pragma endregion
public:
	UFUNCTION(BlueprintCallable)
	void SetSyncSeerAnimParamToProfessionalComponent(bool bSyncAnim);
	
	UFUNCTION(BlueprintCallable)
	void SetUseIdleFightABPVar(bool UseIdleFightABPVar);

	UFUNCTION(BlueprintCallable)
	void SetIsEnableIdleToFightIdle(bool EnableIdleToFightIdle) { bEnableIdleToFightIdle = EnableIdleToFightIdle; }

	UFUNCTION(BlueprintCallable)
	void SetIsComplexMove(bool IsComplexMove);

	UFUNCTION(BlueprintCallable)
	void SetCommonLogicIndex(int LogicIndex);
	
	FVector ExpectedVelocity = FVector::ZeroVector;
	FVector LastExpectVelocityInAir = FVector::ZeroVector;
	FTransform ViewActorTransform = FTransform::Identity;
	
	UPROPERTY(Transient, BlueprintReadOnly)
	bool IsSlaveAnimControl = false;

	UPROPERTY(Transient, BlueprintReadWrite)
	uint32 bEnableCacheAttributeCurve : 1;

	UPROPERTY(Transient, BlueprintReadWrite)
	TMap<FName, float> CacheAttributeCurveMap;

	UPROPERTY(Transient, BlueprintReadWrite)
	TSet<TSubclassOf<UAnimInstance>> LastLinkedAnimClass;

	UPROPERTY(Transient, BlueprintReadOnly)
	bool IsLocoStart = false;

	// 主端计算和从端实际使用的LocoState内部分支Index
	UPROPERTY(Transient, BlueprintReadWrite)
	int LocoStateInnerIndex = 0;

	// 移动组件的LocomotionMask同步过来的LocoState内部分支Index
	UPROPERTY(Transient, BlueprintReadOnly)
	int LocoStateInnerIndexFromMask = 0;

	UPROPERTY(Transient, BlueprintReadWrite)
	int ThreeLayerOutputMode = 0;

	UPROPERTY(Transient, BlueprintReadWrite)
	float ActionScriptBlendTime = 0.f;

	UPROPERTY(Transient, BlueprintReadWrite)
	float PerformAdditiveScriptBlendTime = 0.f;

	UPROPERTY(Transient, BlueprintReadWrite)
	float ThreeLayerScriptBlendTime = 0.f;

	UPROPERTY(Transient, BlueprintReadOnly)
	int ABPLod = 0;

	UPROPERTY(Transient, BlueprintReadOnly)
	bool IsGrounded = true;

	// ToDelete待删除，不要新增使用
	UPROPERTY(Transient, BlueprintReadOnly)
	float AbsFaceAndDriveDiffRadian = 0.0f;
	// 面向与输入的夹角，转身条件判断请用bAllowMoveTurn180或bEnableMoveTurn90
	UPROPERTY(Transient, BlueprintReadOnly)
	float FaceAndDriveDiffRadian = 0.0f;
	// 是否有MoveTurn禁用
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bDisableMoveTurn = false;
	// 是否处于倒车流程
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bIsBackCar = false;
	// 是否允许180度的转身
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bAllowMoveTurn180 = false;

	UPROPERTY(Transient, BlueprintReadOnly)
	bool bAllowSprintMoveTurn180NotInBattle = false;

	UPROPERTY(Transient, BlueprintReadOnly)
	bool bAllowMoveTurn180SprintNotInBattleOrRunPosture = false;
	
	// 是否允许90度的左转身
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bAllowMoveTurn90L = false;
	// 是否允许90度的右转身
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bAllowMoveTurn90R = false;

	// LocoGroup大状态，LocoGroup判断请用bIsXXXLocoGrouup系列bool
	UPROPERTY(Transient, BlueprintReadOnly)
	int LocoGroup = 1;
	// 是否是NormalWalking的LocoGroup
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bIsNormalWalkingLocoGroup = true;
	// 是否是Ride的LocoGroup
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bIsRideLocoGroup = false;
	// 是否是WaterWalk的LocoGroup
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bIsWaterWalkLocoGroup = false;
	// 是否是DizzinessWalk的LocoGroup
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bIsDizzinessWalkLocoGroup = false;
	// 是否是CameraDirMove的LocoGroup
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bIsCameraDirMoveLocoGroup = false;
	// 是否是Climb的LocoGroup
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bIsClimbLocoGroup = false;
	// 是否是Swim的LocoGroup
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bIsSwimLocoGroup = false;

#pragma region RagDoll
	
private:
	void UpdateRagdollValues();
	
public:
	// 是否处于RagDoll状态
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bIsRagDoll = false;

	/** Anim Graph - Ragdoll */
	UPROPERTY(VisibleDefaultsOnly, BlueprintReadOnly, Category = "Read Only Data|Anim Graph - Ragdoll")
	float MassFlailRate = 0.0f;

#pragma endregion RagDoll

	// ToDelete待删除，不要新增使用,是否需要LocoGroup的BlendIn状态
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bNeedLocoGroupBlendInLocoState = false;

	// 0:Run; 1:Walk; 2:Sprint
	UPROPERTY(Transient, BlueprintReadOnly)
	int AnimMovePosture = 0;
	// 是否是Walk的MovePosture
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bIsWalkAnimMovePosture = false;
	// 是否是Run的MovePosture
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bIsRunAnimMovePosture = true;
	// 是否是Sprint的MovePosture
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bIsSprintAnimMovePosture = false;

	UPROPERTY(Transient, BlueprintReadOnly)
	float MoveAnimPlayRate = 1.0;

	// 0:Normal; 1:Battle; 2:Patrol
	UPROPERTY(Transient, BlueprintReadOnly)
	int AnimBasePosture = 0;
	// 是否是Normal的AnimBasePosture
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bIsNormalAnimBasePosture = true;
	// 是否是Battle的AnimBasePosture
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bIsBattleAnimBasePosture = false;
	// 是否是Patrol的AnimBasePosture
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bIsPatrolAnimBasePosture = false;
	// 是否使用战斗IDLE
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bUseIdleFightABPVar = false;
	// 是否使用复杂移动
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bComplexMove = false;
	// 是否开启Idle过度
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bEnableIdleToFightIdle = false;
	
	// 捏脸节点控制参数
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bEnableBodyControl = true;

	UPROPERTY(Transient, BlueprintReadOnly)
	bool bEnableHeadControl = true;
	
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bEnableAvatarCreator = false;
	
	UPROPERTY(Transient, BlueprintReadOnly)
	float MaxTranslationValueToIgnored = 0.01;

	UPROPERTY(Transient, BlueprintReadOnly)
	float MaxRotationValueToIgnored = 0.5;

	UPROPERTY(Transient, BlueprintReadOnly)
	float MaxScaleValueToIgnored = 0.005;

	UPROPERTY(Transient, BlueprintReadOnly)
	int CommonLogicIndex = 0;
	
	// 是否同步占卜家专属动画数据
	bool bSyncSeerParam = false;
	
#pragma region DelayedAnimMovePosture
	// 背景：
	// ServerForceControl状态下，服务器先后接连下发LocoStart为false和新的速度
	// 预期这时动画状态机马上到RunEnd，然后再改了速度触发了MovePosture变化。
	// 但实际动画状态机在另一个线程要晚点才能拿到移动组件的LocoStart变化，导致进入RunEnd时，MovePosture已经改过来了
	// 因此这里对AnimMovePosture和MoveAnimPlayRate特殊处理，增加延迟AnimMovePosture功能

	// DelayedAnimMovePostureCacheTime时间前的AnimMovePosture
	UPROPERTY(Transient, BlueprintReadOnly)
	int DelayedAnimMovePosture = 0;
	// 是否是Walk的DelayedAnimMovePosture
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bIsWalkDelayedAnimMovePosture = false;
	// 是否是Run的DelayedAnimMovePosture
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bIsRunDelayedAnimMovePosture = true;
	// 是否是Sprint的DelayedAnimMovePosture
	UPROPERTY(Transient, BlueprintReadOnly)
	bool bIsSprintDelayedAnimMovePosture = false;

	// DelayedAnimMovePostureCacheTime时间前的AnimMovePosture
	UPROPERTY(Transient, BlueprintReadOnly)
	float  DelayedMoveAnimPlayRate = 1.0;
	// DelayedAnimMovePosture的延迟时间，大于0时机制生效
	UPROPERTY(Transient, BlueprintReadWrite)
	float DelayedAnimMovePostureCacheTime = -1.0f;
	// 当前剩余的Cache时间
	float RemainAnimMovePostureCacheTime = -1.0f;
#pragma endregion DelayedAnimMovePosture

#pragma region PlayWebSequence
	
	// 是否播放自定义动画（AI生成）
	UPROPERTY(Transient, BlueprintReadWrite)
	bool bPlayWebSequenceEnable = false;

	// 是否播放自定义动画（AI生成）
	UPROPERTY(Transient, BlueprintReadWrite)
	bool bPlayWebSequencePause = false;
	
	// 动画时间偏移
	UPROPERTY(Transient, BlueprintReadWrite)
	float PlayWebSequencePlayRate = 1;

	// 在 UBaseAnimInstance.h 中添加
	UFUNCTION(BlueprintCallable, Category = "WebSequence")
	void SetWebSequenceAsset(const FString& WebAnimSequenceName, int32 PeopleIndex, int32 Sex, float StartTime = 0.0f);
	
	UFUNCTION(BlueprintCallable, Category = "WebSequence")
	void SetWebSequencePlayControl(bool bPlaying, bool bPause, float playRate);

	UFUNCTION(BlueprintCallable, Category = "WebSequence")
	bool IsWebSequencePlaying() const;

#pragma endregion PlayWebSequence

#pragma region ThreeBattlePostureBlend

	UFUNCTION(BlueprintCallable)
	void SetIsAlwaysUpdateLocoPose(bool bAlwaysUpdateLocoPos) { ThreeLayerPostureParam.bAlwaysUpdateLocoPose = bAlwaysUpdateLocoPos; };
	
	UFUNCTION(BlueprintCallable)
	void StartActionPostureWork(float blendDuration, EActionBlendRule blendRule);

	UFUNCTION(BlueprintCallable)
	void StopActionPostureWork(float blendDuration);

	UFUNCTION(BlueprintCallable)
	void StartLowerLocoPostureWork();

	UFUNCTION(BlueprintCallable)
	void StopLowerLocoPostureWork();

	UFUNCTION(BlueprintCallable)
	void EnableActionMeshSpaceBlend(bool bEnable);

	UFUNCTION(BlueprintCallable)
	void SetActionPostureBoneFilter(FName boneName, int boneDepth);

	UFUNCTION(BlueprintCallable)
	void SetPerformBoneData(TMap<int, FName>& BoneData);
	
	UFUNCTION(BlueprintCallable)
	void StartPerformPostureWork(float blendDuration, EActionBlendRule blendRule);

	UFUNCTION(BlueprintCallable)
	void StartPerformPostureWorkUpdateBone(float blendDuration, int boneEnum, int boneDepth, EActionBlendRule blendRule);

	UFUNCTION(BlueprintCallable)
	void StopPerformPostureWork(float blendDuration);

	UFUNCTION(BlueprintCallable)
	void SetPosturePostureBoneFilter(FName boneName, int boneDepth);

#pragma endregion ThreeBattlePostureBlend

	// ToDelete待删除，不要新增使用
	UPROPERTY(Transient, BlueprintReadWrite)
	int CachedFootPosture = 0;

	UPROPERTY(Transient, BlueprintReadOnly)
	FVector MovementVelocity = FVector::ZeroVector;

	UPROPERTY(Transient, BlueprintReadOnly)
	FVector MovementAcceleration = FVector::ZeroVector;

	UPROPERTY(Transient, BlueprintReadOnly)
	FRotator LastActorRotation{0, 0, 0};

	FTransform LastViewActorTransform;

	UPROPERTY(Transient, BlueprintReadOnly)
	FVector LocoInputVec = FVector::ZeroVector;
	
	UPROPERTY(Transient, BlueprintReadOnly)
	float VelocityZ = 0.f;

	UPROPERTY(Transient, BlueprintReadOnly)
	float VelocityXY = 0.f;
	
	UPROPERTY(Transient, BlueprintReadOnly)
	float VelocityValue = -1.f;

	UPROPERTY(Transient, BlueprintReadOnly)
	float MovementMaxAcceleration = 2000;

	UPROPERTY(Transient, BlueprintReadOnly)
	float MovementMaxDeceleration = 2000;

	UPROPERTY(Transient, BlueprintReadOnly)
    int AnimMoveMode = 0;

	UPROPERTY(Transient, BlueprintReadOnly)
	FVector2D FaceAndVelDiffVec2D = {0, 0};

	UPROPERTY(Transient, BlueprintReadOnly)
	bool IsHighJumpEnd{false};
	
	// 挂接物同步需要的信息
	UPROPERTY(Transient, BlueprintReadWrite)
	FAISAttachmentInfo AttachmentInfo;
	
public:
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "CharacterAnim Config")
	float LocoCrossFadeTime = 0.1f;
public:
	UFUNCTION(BlueprintCallable)
	void SetLocoGroupInfo(int InLocoGroup, bool InNeedLocoGroupBlendIn) { LocoGroup = InLocoGroup; bNeedLocoGroupBlendInLocoState = InNeedLocoGroupBlendIn; UpdateLocoGroup(); }

	UFUNCTION(BlueprintCallable)
	void SetAnimBasePosture(int InAnimBasePosture) { AnimBasePosture = InAnimBasePosture; UpdateAnimBasePosture(); }

	UFUNCTION(BlueprintCallable)
	void SetAnimMovePostureAndPlayRate(int NewPosture, float NewPlayRate);
	
	UFUNCTION(BlueprintCallable)
	void SetIsEnableBodyControl(bool bEnable) { bEnableBodyControl = bEnable; }
	
	UFUNCTION(BlueprintCallable)
	bool GetIsEnableBodyControl() { return bEnableBodyControl; }
	
	UFUNCTION(BlueprintCallable)
	void SetIsEnableHeadControl(bool bEnable) { bEnableHeadControl = bEnable; }
	
	UFUNCTION(BlueprintCallable)
	bool GetIsEnableHeadControl() { return bEnableHeadControl; }

	UFUNCTION(BlueprintCallable)
	void SetIsEnableAvatarCreator(bool bEnable) { bEnableAvatarCreator = bEnable; }
	
	UFUNCTION(BlueprintCallable)
	float GetMaxTranslationValueToIgnored() { return MaxTranslationValueToIgnored; }

	UFUNCTION(BlueprintCallable)
	void SetMaxTranslationValueToIgnored(float Value) { MaxTranslationValueToIgnored = Value; }

	UFUNCTION(BlueprintCallable)
	float GetMaxRotationValueToIgnored() { return MaxRotationValueToIgnored; }

	UFUNCTION(BlueprintCallable)
	void SetMaxRotationValueToIgnored(float Value) { MaxRotationValueToIgnored = Value; }

	UFUNCTION(BlueprintCallable)
	float GetMaxScaleValueToIgnored() { return MaxScaleValueToIgnored; }

	UFUNCTION(BlueprintCallable)
	void SetMaxScaleValueToIgnored(float Value) { MaxScaleValueToIgnored = Value; }

	UFUNCTION(BlueprintCallable)
	void SetAnimMoveMode(int NewMoveMode) { if (NewMoveMode != AnimMoveMode) AnimMoveMode = NewMoveMode; } 

	UFUNCTION(BlueprintImplementableEvent)
	void OnAnimNotify_C7ChangeHair(bool bTakeOff);
	
	UFUNCTION(BlueprintCallable)
	void SetHighJumpEndVelocityZThreshold(float velZ) { HighJumpEndVelocityZThreshold = velZ; };

	UFUNCTION(BlueprintCallable)
	void SetLocoCrossFadeTime(float time) { LocoCrossFadeTime = time; }
	 
	void ConsumeRootMotionFromAnimation(FRootMotionMovementParams& ExtractedRootMotion);
	
	virtual void PullLocomotionControlDataFromRoleMovement(URoleMovementComponent& rmc, float DeltaTime);
	virtual void CalculateAnimationControl(float DeltaTime);

	virtual void DoSlaveControl(float deltaTime);
	void UpdateAnimationToFreeze(float DeltaSeconds);
	void UpdateSeerAnimationSync(float DeltaSeconds);

	UFUNCTION(BlueprintCallable)
	void SetUsingLocoCrossfadeSynchronizeToLogicChilds(bool isUsing) { UsingLocoCrossfadeSynchronizeToLogicChilds = isUsing; };

protected:
	bool UsingLocoCrossfadeSynchronizeToLogicChilds = false;

private:
	FVector LastFramePos = FVector::ZeroVector;
	
	double LastLayerBlendTargetTimestamp = -1;

	float HighJumpEndVelocityZThreshold{-2000};

	FName LocomotionStatemachineName{ "Locomotion" };

	// 由父对象同步动画状态机到自身时,通过 ParentToChildStateReplace 映射关系切换到自身理想的状态机节点(按需添加映射关系)
	TMap<FName, FName> ParentToChildAnimStateReplace;

	TMap<FName, FProperty*> PropertyContainerPtrCacheMap;

	template<typename PropertyType>
	PropertyType* GetPropertyPtr(FName PropertyName);

public:
	UFUNCTION(BlueprintCallable)
	void UpdateParentToChildStateMap(const TMap<FName, FName>& StateMachineReplace);

	UFUNCTION(BlueprintCallable)
	void ClearParentToChildStateMap();

	const FName& GetParentToChildStateMachine(const FName& MachineName);
	
	UFUNCTION(BlueprintCallable)
	void SetLocomotionStatemachineName(FName SMName) {
		LocomotionStatemachineName = SMName;

		// 需要刷一遍
		SetIsSlaveAnimControl(IsSlaveAnimControl);
	}
	
	UFUNCTION(BlueprintCallable, Category = "Animation|Montage")
	float Montage_PlayWithBasicParams(UAnimMontage* MontageToPlay, float blendInTime=0.1f, bool isLoop=false, float InPlayRate = 1.f, float InTimeToStartMontageAt = 0.f, bool bStopAllMontages = true, EMontagePlayReturnType ReturnValueType = EMontagePlayReturnType::MontageLength);
	float Montage_PlayWithBasicParams(UAnimMontage* MontageToPlay, float blendInTime=0.1f, EAlphaBlendOption blendOption = EAlphaBlendOption::Linear, bool isLoop=false, float InPlayRate = 1.f, float InTimeToStartMontageAt = 0.f, bool bStopAllMontages = true, EMontagePlayReturnType ReturnValueType = EMontagePlayReturnType::MontageLength);

	UFUNCTION(BlueprintCallable, Category = "Animation|Montage")
	float Montage_PlayWithBasicParamsOnLayer(const FName& LayerName, UAnimMontage* MontageToPlay, float blendInTime=0.1f, bool isLoop=false, float InPlayRate = 1.f, float InTimeToStartMontageAt = 0.f, bool bStopAllMontages = true, EMontagePlayReturnType ReturnValueType = EMontagePlayReturnType::MontageLength);
	float Montage_PlayWithBasicParamsOnLayer(const FName& LayerName, UAnimMontage* MontageToPlay, float blendInTime=0.1f, EAlphaBlendOption blendOption = EAlphaBlendOption::Linear, bool isLoop=false, float InPlayRate = 1.f, float InTimeToStartMontageAt = 0.f, bool bStopAllMontages = true, EMontagePlayReturnType ReturnValueType = EMontagePlayReturnType::MontageLength);

	UFUNCTION(BlueprintCallable, Category = "Animation|Montage")
	void Montage_StopOnLayer(const FName& LayerName, float BlendOutTime, UAnimMontage* MontageToStop);

	UFUNCTION(BlueprintCallable)
	void LocomotionCrossfadeInFixedTime(int stateType, float transitionTime);

	void DoNotifyAnyStateChangedFromStateMachine(const FName& PrevStateNameOut, const FName& CurStateNameOut) override;

	bool SetAllSequencePlayerProgressInStateNode(const uint8 InLocoState, float InPercent);

	void SetUint8EnumProperty(const FName& PropName, uint8 Value);

	uint8 GetUint8EnumPropertyValue(const FName& PropName, uint8 DefaultValueWhenFail);

	void SetBoolProperty(const FName& PropName, bool bValue);

	template<typename InTCppType>
	void SetNumericValueProperty(const FName& PropName, InTCppType Value);

	template<typename InTCppType>
	InTCppType GetNumericPropertyValue(const FName& PropName, InTCppType DefaultValueWhenFail);

	bool GetBoolPropertyValue(const FName& PropName);

#pragma region FreezeAnimation
public:
	void SetAnimationFreeze(UAnimMontage* FreezeMontage, float RowPlayRate, float FreezePlayRate = 1.f, float FreezeInTime = 0.f, float FreezeOutTime = 0.f, float FreezeFixUpPlayRate = 1.f);
	void ClearAnimationFreeze(UAnimMontage* FreezeMontageToStop, float RowPlayRate);
	bool HasAnimationFreeze() const { return AnimationToFreeze.IsValid(); }

private:
	float AnimationFreezeInTime = 0.f;
	float AnimationFreezeRowPlayRate = 0.f;
	float AnimationFreezeOutTime = 0.f;
	float AnimationFreezeFixUpSpeed = 1.f;
	float AnimationFreezeSpeed = 1.f;
	float AnimationFreezePassedTime = 0.f;
	TWeakObjectPtr<UAnimMontage> AnimationToFreeze = nullptr;

#pragma endregion FreezeAnimation
	
#if UE_BUILD_DEVELOPMENT
public:
	virtual void AppendDebugInfo(FString& TempInfoOut);

protected:
	FVector OnGroundExpectedVelocity = FVector::ZeroVector;
#endif

	
#pragma region PropertyUpdate
protected:
	void UpdateAllowMoveTurn();
	void UpdateLocoGroup();
	void UpdateAnimMovePosture();
	void UpdateAnimBasePosture();
	void UpdateDelayedAnimMovePosture();
    void UpdateCurveControl(float DeltaTime);
    void UpdateKawaiiCurveValue(float DeltaTime);
#pragma endregion PropertyUpdate


#pragma region LookAt

public:
	void TickGaze(float DeltaSeconds);
	void UpdateLayerContext(float DeltaSeconds);
	void ApplyGaze(UAnimLayerContext& InOutSharedLayerContext);
	void BlendGazeAlpha(float& HCurrentValue, float HStartValue, float HTargetValue, float& VCurrentValue, float VStartValue, float VTargetValue, float DeltaTime, float Speed);
	bool CollectBoneTransform(UAnimLayerContext& InOutSharedLayerContext);
	bool GetTargetBonePos(UAnimLayerContext& InOutSharedLayerContext, FVector& OutTargetPos);
	void CalculateGaze(UAnimLayerContext & InOutSharedLayerContext);

public:
	FName GazeDirectionBoneName = NAME_None;

	// 限制夹角容差 解决动作呼吸时骨骼朝向变更
	float DeltaClampAngle = 2.f;
	
	bool bDebugDraw = false;
	
	EGazeTargetType CurrentGazeType = EGazeTargetType::None;
	
	FAnimGazeData CurrentGazeData;
	FAnimGazeConfig GazeConfig;
	FAnimGazeBoneNames AnimGazeBoneNames;
	bool bPauseGaze;

	UFUNCTION(BlueprintCallable)
	void UpdateGazeCoord(float GazeLocX, float GazeLocY);

	UFUNCTION(BlueprintCallable)
	void InitBasicGazeConfig(float HorClampAngle, float VerClampAngle, float LocationInterpSpeed, float AlphaIn, float AlphaOut, float EyeRotateSpeed, float EyeClampHorizX, float EyeClampHorizY, float EyeClampVertX, float EyeClampVertY, float HeadRotateSpeed,
		float HeadClampHorizX, float HeadClampHorizY, float HeadClampVertX, float HeadClampVertY, float SpineRotateSpeed, float SpineRotateBlendRate, float SpineClampHorizX, float SpineClampHorizY, float SpineClampVertX, float SpineClampVertY, float NeckRotateSpeed,
		float NeckRotateBlendRate, float NeckClampHorizX, float NeckClampHorizY, float NeckClampVertX, float NeckClampVertY, bool bGazeInstant, int EasyInOutExp, FName GazeDirBoneName);

	UFUNCTION(BlueprintCallable)
	void SetGazePartBlendAlpha(float EyeAlphaCoefficient, float HeadAlphaCoefficient, float SpineAlphaCoefficient, float NeckAlphaCoefficient);

	UFUNCTION(BlueprintCallable)
	void SetGazeTargetLocation(const FVector& WorldLocation, float DistanceLimit);

	UFUNCTION(BlueprintCallable)
	void SetGazeTargetCharacter(AActor* TargetActor, FString TargetSocket, FVector Offset, float DistanceLimit);
	
	UFUNCTION(BlueprintCallable)
	void SetGazeCurrentCamera();
	
	UFUNCTION(BlueprintCallable)
	void SetGazeByCoord(float GazeCoordRangeX, float GazeCoordRangeY, float GazeCoordDist);

	UFUNCTION(BlueprintCallable)
	void SetUnGaze(bool bImmediate);

	UFUNCTION(BlueprintCallable)
	void PauseGaze(bool bPause);
	
	UFUNCTION(BlueprintCallable)
	void SetGazeBlendAlpha(float AlphaIn, float AlphaOut);
	
	UFUNCTION(BlueprintCallable)
	void SetGazeRotateConfig(float HorClampAngle, float VerClampAngle, float LocationInterpSpeed);

	UFUNCTION(BlueprintCallable)
	void SetGazeEyeRotateConfig(float EyeRotateSpeed, float EyeClampHorizX, float EyeClampHorizY, float EyeClampVertX, float EyeClampVertY);

	UFUNCTION(BlueprintCallable)
	void SetGazeHeadRotateConfig(float HeadRotateSpeed, float HeadClampHorizX, float HeadClampHorizY, float HeadClampVertX, float HeadClampVertY);

	UFUNCTION(BlueprintCallable)
	void SetGazeSpineRotateConfig(float SpineRotateSpeed, float SpineRotateBlendRate, float SpineClampHorizX, float SpineClampHorizY, float SpineClampVertX, float SpineClampVertY);

	UFUNCTION(BlueprintCallable)
	void SetGazeNeckRotateConfig(float NeckRotateSpeed, float NeckRotateBlendRate, float NeckClampHorizX, float NeckClampHorizY, float NeckClampVertX, float NeckClampVertY);

	UFUNCTION(BlueprintCallable)
	void EnableGazeDebugDraw(bool bEnable);
	
	void SetGazeInstant(bool bGazeInstant);
	void UpdateGazeScreenLoc(const FVector2D& GazeLoc);
	void CacheGazeParam();
	void SetDisableLookAtInterpSpeed(float Speed) { DisableLookAtInterpSpeed = Speed; }
protected:
	UPROPERTY(Transient)
	TObjectPtr<UAnimLayerContext> GazeAnimLayerContext;

private:
	bool CurCalculateGaze = true;
	FAlphaBlend GazeBlendAlpha;

	float BlendTimeTotal = 0.0f;
	float DisableLookAtInterpSpeed = 5.f;
	float CurveControlLookAtAlpha = 1.0f;
	
#pragma endregion LookAt
	
};

template <typename InTCppType>
void UBaseAnimInstance::SetNumericValueProperty(const FName& PropName, InTCppType Value)
{
	if(TProperty_Numeric<InTCppType>* TargetPropertyPtr = GetPropertyPtr<TProperty_Numeric<InTCppType>>(PropName))
	{
		void* PropertyValuePtr = TargetPropertyPtr->template ContainerPtrToValuePtr<void>(this);
		TargetPropertyPtr->SetPropertyValue(PropertyValuePtr, Value);
	}
}

template <typename InTCppType>
InTCppType UBaseAnimInstance::GetNumericPropertyValue(const FName& PropName, InTCppType DefaultValueWhenFail)
{
	if(TProperty_Numeric<InTCppType>* TargetPropertyPtr = GetPropertyPtr<TProperty_Numeric<InTCppType>>(PropName))
	{
		void* PropertyValuePtr = TargetPropertyPtr->template ContainerPtrToValuePtr<void>(this);
		return TargetPropertyPtr->GetPropertyValue(PropertyValuePtr);
	}

	return DefaultValueWhenFail;
}

template<typename PropertyType>
PropertyType* UBaseAnimInstance::GetPropertyPtr(FName PropertyName)
{
	if(FProperty** CachedProperty = PropertyContainerPtrCacheMap.Find(PropertyName))
	{
		if(PropertyType* TypedProperty = CastField<PropertyType>(*CachedProperty))
		{
			return TypedProperty;
		}
		PropertyContainerPtrCacheMap.Remove(PropertyName);
	}

	for (TFieldIterator<FProperty> It(this->GetClass(), EFieldIteratorFlags::IncludeSuper); It; ++It)
	{
		if (PropertyType* Property = CastField<PropertyType>(*It))
		{
			if (Property->GetFName() == PropertyName)
			{
				PropertyContainerPtrCacheMap.Add(PropertyName, CastField<FProperty>(Property));
				return Property;
			}
		}
	}

	return nullptr;
}
