// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "AnimNotify_CustomCallback.generated.h"

/**
 * 
 */
 // 定制，用于创角的专用task
UCLASS(Blueprintable, meta = (DisplayName = "C7 - CustomCallback"))
class KGCHARACTER_API UAnimNotify_CustomCallback : public UAnimNotify
{
	GENERATED_BODY()

public:
	
	DECLARE_DYNAMIC_DELEGATE_ThreeParams(FOnAnimNotifyDelegate, const FString&, InNotifyName, USkeletalMeshComponent*, InMeshComp, UAnimSequenceBase*, Animation);

	UPROPERTY()
	FOnAnimNotifyDelegate OnAnimNotifyDelegate;
	
	UPROPERTY(EditAnywhere)
	FString NotifyName;
	
protected:
	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;

};
