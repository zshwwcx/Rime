// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once
#include "Components/SkeletalMeshComponent.h"
#include "UObject/ObjectMacros.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "NiagaraFunctionLibrary.h"
#include "3C/Animation/AnimNotify/AnimNotify_C7CommonStruct.h"
#include "NiagaraComponent.h"
#include "3C/Effect/KGEffectManager.h"
#include "Engine.h"
#include "Manager/KGObjectActorManager.h"
#include "AnimNotifyState_C7TimedNiagaraEffect.generated.h"

UENUM(Blueprintable, BlueprintType)
enum class EC7AnimNotifyStateNiagaraReleaseMode : uint8
{
	AutoReleaseOnFixedTime = 0,
	AutoReleaseOnNiagaraFinished = 1,
	AutoReleaseOnNotifyStateEnd = 2
};
 
// Timed Niagara Effect Notify
// Allows a looping Niagara effect to be played in an animation that will activate
// at the beginning of the notify and deactivate at the end.
UCLASS(Blueprintable, meta = (DisplayName = "C7 Timed Niagara Effect"), MinimalAPI)
class UAnimNotifyState_C7TimedNiagaraEffect : public UAnimNotifyState
{
	GENERATED_UCLASS_BODY()

#pragma region Default
	// The niagara system template to use when spawning the niagara component
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Default", meta = (DisplayName = "Niagara System", ToolTip = "The niagara system to spawn for the notify state"))
	TSoftObjectPtr<UNiagaraSystem> TemplatePath;

	// The socket within our mesh component to attach to when we spawn the Niagara component
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Default", meta = (ToolTip = "The socket or bone to attach the system to", AnimNotifyBoneName = "true"))
	FName SocketName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Default", meta = (ToolTip = "Play Rate"))
	float PlayRate;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Default", meta = (ToolTip = "Release Mode"))
	EC7AnimNotifyStateNiagaraReleaseMode ReleaseMode = EC7AnimNotifyStateNiagaraReleaseMode::AutoReleaseOnFixedTime;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Default", meta = (EditCondition="ReleaseMode==EC7AnimNotifyStateNiagaraReleaseMode::AutoReleaseOnFixedTime", ToolTip = "Default life seconds"))
	float TotalLifeSeconds;

#pragma endregion Default

#pragma region Transform
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", meta = (ToolTip = "Transform from the socket or bone to place the Niagara system"))
	FTransform Transform;

#pragma endregion Transform

#pragma region Flags
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Flags", meta = (ToolTip = "Attach to parent socket"))
	bool bNeedAttach;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Flags", meta = (ToolTip = "Use Absolute Rotation"))
	bool bAbsoluteRotation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Flags", meta = (ToolTip = "Use Absolute scale"))
	bool bAbsoluteScale;

#pragma endregion Flags

#if WITH_EDITOR
	virtual void ValidateAssociatedAssets() override;
#endif

	virtual void NotifyBegin(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, float TotalDuration) override;
	virtual void NotifyEnd(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation) override;

	// Overridden from UAnimNotifyState to provide custom notify name.
	FString GetNotifyName_Implementation() const override;

	UNiagaraComponent* GetSpawnedEffect(USkeletalMeshComponent* MeshComp);

protected:
	void SpawnEffect(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation);
	bool ValidateParameters(USkeletalMeshComponent* MeshComp) const;
	FORCEINLINE FName GetSpawnedComponentTag()const { return GetFName(); }

private:
	TMap<TWeakObjectPtr<USkeletalMeshComponent>, int32> Mapping;
	TMap<TWeakObjectPtr<USkeletalMeshComponent>, TWeakObjectPtr<UNiagaraComponent>> MappingEditor;
};

