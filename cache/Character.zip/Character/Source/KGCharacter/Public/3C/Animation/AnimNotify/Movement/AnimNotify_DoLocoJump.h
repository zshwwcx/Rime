// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once
#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "3C/Animation/AnimNotify/Movement/IAnimNotify_MovementControlInterface.h"
#include "AnimNotify_DoLocoJump.generated.h"

class UAnimSequenceBase;


UCLASS(meta = (DisplayName = "C7DoLocoJump"))
class KGCHARACTER_API UAnimNotify_DoLocoJump : public UAnimNotify, public IAnimNotify_MovementControlInterface
{
	GENERATED_BODY()

	UAnimNotify_DoLocoJump(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

public:
	void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;
#if WITH_EDITOR
	void OnAnimNotifyCreatedInEditor(FAnimNotifyEvent& ContainingAnimNotifyEvent) override;
#endif
public:
	// 是否使用默认的跳跃速度
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bUseDefaultJumpZVelocity = true;

	// 使用新的跳跃速度
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (EditCondition = "!bUseDefaultJumpZVelocity", EditConditionHides))
	float OverrideJumpZVelocity = 2000.0f;
};

