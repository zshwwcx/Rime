﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "UObject/GCObject.h"
#include "Containers/LruCache.h"
#include "Animation/AnimMontage.h"

/**
 * 
 */
class FCachedAnimMontage : public FGCObject
{
public:
	FCachedAnimMontage();
	FCachedAnimMontage(SIZE_T InMainPlayerCapacity, SIZE_T InDefaultCapacity);

	virtual ~FCachedAnimMontage() override;
	
	virtual void AddReferencedObjects(FReferenceCollector& Collector) override;
	virtual FString GetReferencerName() const override { return TEXT("BaseAnimInstanceCachedAnimMontage"); }

public:
	// LUR功能函数
	void AddMontageCache(int CachePoolType, const FString& Key, UAnimMontage* Value);

	UAnimMontage* CreateAndAddMontageCache(int CachePoolType, const FString& Key, UAnimSequenceBase* Value, const FName& AnimSlotName, float BlendInTime = 0.1f, float BlendOutTime = 0.1f, int LoopCount = 1, bool bAddCache = true);

	UAnimMontage* GetMontageCache(int CachePoolType, const FString& Key, const FName& AnimSlotName);

	void EmptyMontageCache(int CachePoolType);
	void EmptyMontageCacheAll();

	// 一下操作会清空缓存，不清缓存的方法底层没有暴露
	void ChangeMainPlayerMontageCacheCapacity(int NewCapacity);
	void ChangeDefaultMontageCacheCapacity(int NewCapacity);
	void ChangeMontageCachesCapacity(int NewCapacity);

	float GetMainCacheHitRate() const;
	float GetDefaultCacheHitRate() const;

	int MainCacheHitCnt() const { return MainHitCnt; }
	int MainCacheMissCnt() const { return MainMissCnt; }
	int MainCacheQueryCnt() const { return MainHitCnt + MainMissCnt; }

	int DefaultCacheHitCnt() const { return DefaultHitCnt; }
	int DefaultCacheMissCnt() const { return DefaultMissCnt; }
	int DefaultCacheQueryCnt() const { return DefaultHitCnt + DefaultMissCnt; }

private:
	SIZE_T MainPlayerMontageCacheCapacity;
	SIZE_T DefaultMontageCacheCapacity;

	TMap<FName, TLruCache<FString, TWeakObjectPtr<UAnimMontage>>> MainPlayerMontageCachesMap;
	TMap<FName, TLruCache<FString, TWeakObjectPtr<UAnimMontage>>> DefaultMontageCachesMap;

	const FName DefaultSlotName{"DefaultSlot"};

	int MainHitCnt = 0;
	int MainMissCnt = 0;
	int DefaultHitCnt = 0;
	int DefaultMissCnt = 0;
};
