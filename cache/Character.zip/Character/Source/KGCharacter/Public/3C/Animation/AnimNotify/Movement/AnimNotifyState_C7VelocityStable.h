// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once
#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "3C/Animation/AnimNotify/Movement/IAnimNotify_MovementControlInterface.h"
#include "AnimNotifyState_C7VelocityStable.generated.h"

class UAnimSequenceBase;

/** AnimNotifyState used to define a motion warping window in the animation */
UCLASS(meta = (DisplayName = "C7 VelocityStable"))
class KGCHARACTER_API UAnimNotifyState_C7VelocityStable : public UAnimNotifyState, public IAnimNotify_MovementControlInterface
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite,  meta = (ToolTip = "速度均值模式, 用于磨平速度上/下突然峰值; 推进器淡入模式, 用于例如RootMotion混出使用推进器时的推进器速度混入, 避免直接叠加超过上限"))
	EVelocityStableMode VelocityStableMode = EVelocityStableMode::AvgSpeedMode;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite,  meta = (ClampMin=0.0f, ClampMax=1000.0f, ToolTip = "速度奇异值容忍度, (当前速度-上一帧速度)/上帧速度 > TolerateRate时, 使用上一帧速度替代当前速度",  EditCondition = "VelocityStableMode == EVelocityStableMode::AvgSpeedMode", EditConditionHides))
	float VelocityDiffRatioTolerateRate = 0.2;

	UPROPERTY(EditAnywhere, BlueprintReadWrite,  meta = (ToolTip = "使用历史速度的均速作为进行运动输出", EditCondition = "VelocityStableMode == EVelocityStableMode::AvgSpeedMode", EditConditionHides))
	bool UseVelHistoryAvg = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite,  meta = (ToolTip = "Task结束后持续生效时长", EditCondition = "VelocityStableMode == EVelocityStableMode::AvgSpeedMode", EditConditionHides))
	float DelayEffectTime = 0.f;
	
    void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference) override;
	void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) override;
};

