// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include  "3C/Movement/RoleMovementComponent.h"
#include "AnimNotify_C7CommonEvent.generated.h"


/**
 * 
 */
UCLASS(meta = (DisplayName = "C7 Common Event"))
class KGCHARACTER_API UAnimNotify_C7CommonEvent : public UAnimNotify
{
	GENERATED_BODY()


protected:
	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	EAnimCommonEventType EventType;
};
