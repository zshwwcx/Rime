#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Animation/AnimNodeBase.h"
#include "Animation/InputScaleBias.h"
#include "Animation/AnimSequenceBase.h"
#include "3C/Animation/AnimationGraphNode/CustomAnimNodeDefine.h"
#include "BoneContainer.h"
#include "BonePose.h"
#include "CommonAnimTypes.h"
#include "Animation/AnimInstanceProxy.h"
#include "Animation/AnimExecutionContext.h"
#include "AnimNode_WebSequencePlayer.generated.h"


USTRUCT(BlueprintInternalUseOnly)
struct KGCHARACTER_API FAnimNode_WebSequencePlayer : public FAnimNode_Base
{
	GENERATED_USTRUCT_BODY()

public:
	// 输入姿态
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Links)
	FPoseLink BasePose;

	// 自定义动画数据
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinShownByDefault))
	FCustomAnimationData AnimationData;

	TMap<FString, FVector> BoneLocationData;

	// 动作融合权重数组 [frame] 范围[0.0, 1.0]
	// 基于ValidMask生成，在有效/无效帧边界处使用线性衰减
	TArray<float> BlendArray;

	// 当前人物索引（用于多人动画）
	int32 PeopleIndex;

	// 帧率（用于计算当前帧索引）
	float SampleRate;

	// 播放时间
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinShownByDefault))
	float PlayTime;

	// 是否播放
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinShownByDefault))
	bool IsPlaying;

	// 是否暂停
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinShownByDefault))
	bool IsPaused;

	// 是否循环播放
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinShownByDefault))
	bool Loop;

	// 播放速度倍率 (0-10)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinShownByDefault, ClampMin = "0.0", ClampMax = "10.0"))
	float PlaybackSpeed;

	// Blend权重: 0=完全使用BasePose, 1=完全使用Web动画
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinShownByDefault, ClampMin = "0.0", ClampMax = "1.0"))
	float BlendAlpha;

public:
	FAnimNode_WebSequencePlayer();

	// FAnimNode_Base interface (UE5版本)
	virtual void Initialize_AnyThread(const FAnimationInitializeContext& Context) override;
	virtual void CacheBones_AnyThread(const FAnimationCacheBonesContext& Context) override;
	virtual void Update_AnyThread(const FAnimationUpdateContext& Context) override;
	virtual void Evaluate_AnyThread(FPoseContext& Output) override;
	virtual void GatherDebugData(FNodeDebugData& DebugData) override;
	virtual bool HasPreUpdate() const override { return true; }
private:
	// 缓存的骨骼引用
	TArray<FBoneReference> BoneReferences;

	FString AnimationName;

	// 获取指定时间的骨骼变换
	FTransform GetBoneTransformAtTime(const FC7BoneAnimationTrack& Track, float Time) const;

	// 插值计算 (UE5使用更精确的插值)
	FVector InterpolateVector(const FVector& A, const FVector& B, float Alpha) const;
	FQuat InterpolateRotation(const FQuat& A, const FQuat& B, float Alpha) const;
};