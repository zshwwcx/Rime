// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once
#include "Components/SkeletalMeshComponent.h"
#include "UObject/ObjectMacros.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "NiagaraFunctionLibrary.h"
#include "3C/Animation/AnimNotify/AnimNotify_C7CommonStruct.h"
#include "NiagaraComponent.h"
#include "3C/Effect/KGEffectManager.h"
#include "Engine.h"
#include "3C/Character/BaseCharacter.h"
#include "AnimNotifyState_C7AnimNotifyOnSurface.generated.h"

class USkeletalMeshComponent;

// 定制，用于处理水面/雪地等脚步特效的专用task
UCLASS(Blueprintable, meta = (DisplayName = "C7 - EffectOnSurface"), MinimalAPI)
class UAnimNotifyState_C7AnimNotifyOnSurface : public UAnimNotifyState
{
	GENERATED_UCLASS_BODY()

#pragma region Default
	// The niagara system template to use when spawning the niagara component
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Default", meta = (DisplayName = "Niagara System", ToolTip = "The niagara system to spawn for the notify state"))
	TArray<FAnimNotifyOnSurface> NiagaraSystemList;

#pragma endregion Default

	virtual void NotifyBegin(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, float TotalDuration) override;
	virtual void NotifyEnd(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation) override;

	// Overridden from UAnimNotifyState to provide custom notify name.
	FString GetNotifyName_Implementation() const override;

protected:
	void SpawnEffect(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation);
	bool ValidateParameters(USkeletalMeshComponent* MeshComp) const;
	FORCEINLINE FName GetSpawnedComponentTag()const { return GetFName(); }
	void AddToMappingEditor(USkeletalMeshComponent* MeshComp, UNiagaraComponent* FXComponent);

private:
	TMap<TWeakObjectPtr<USkeletalMeshComponent>, TArray<int32>> Mapping;
	TMap<TWeakObjectPtr<USkeletalMeshComponent>, TArray<TWeakObjectPtr<UNiagaraComponent>>> MappingEditor;

};

