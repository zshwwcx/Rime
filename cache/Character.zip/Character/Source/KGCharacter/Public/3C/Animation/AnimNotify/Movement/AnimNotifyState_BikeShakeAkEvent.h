// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "AnimNotifyState_BikeShakeAkEvent.generated.h"

class UAkAudioEvent;

/**
 * 自行车抖动时播放声音的专属NotifyState
 */
UCLASS(meta = (DisplayName = "BikeShakeAkEvent"))
class KGCHARACTER_API UAnimNotifyState_BikeShakeAkEvent : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference) override;
	void NotifyTick(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float FrameDeltaTime, const FAnimNotifyEventReference& EventReference);
	void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) override;

public:
	// 自行车震荡时播放的音效
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	UAkAudioEvent* BikeShakeAkEvent;

	// 触发音效时的Pitch角度变化速率，单位：°/s
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (ClampMin = "0.0"))
	float TriggerEventDeltaPitchSpeed = 150.0f;

	// 触发音效的冷却时间，单位：s
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (ClampMin = "0.0"))
	float TriggerEventCoolDown = 0.5f;

	// 是否只有主角触发(目前暂时只允许主角触发)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (EditCondition = "false"))
	bool bMainPlayerOnly = true;

//private:
//	float LastPitchValue = 0.0f;
//	float CurTriggerEventCoolDown = 0.0f;
//	TArray<float> HistoryDeltaPitchList;
//
//	bool bIsMainPlayer = false;
};
