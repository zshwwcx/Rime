// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "BonePose.h"
#include "3C/Animation/AnimCommon.h"
#include "AnimNode_C7ModifyBones.generated.h"

class USkeletalMeshComponent;

/**
 *	Simple controller that replaces or adds to the translation/rotation of a single bone.
 */
USTRUCT(BlueprintInternalUseOnly)
struct FAnimNode_C7ModifyBones : public FAnimNode_Base
{
	GENERATED_USTRUCT_BODY()

	// Input link
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Links)
	FPoseLink ComponentPose;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Performance, meta = (PinHiddenByDefault, DisplayName = "LOD Threshold"))
	int32 LODThreshold = 1;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Alpha, meta = (PinShownByDefault))
	float Alpha = 0.0f;

	// Modify Bone的批量参数
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Translation, meta=(PinShownByDefault))
	TMap<FName, FC7ModifyBones_Params> BonesParam;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Translation, meta=(PinShownByDefault))
	TMap<FName, FC7BatchTwoBoneIKB_Params> BatchTwoBoneIKParams;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Links)
	FPoseLink ArmAdditive;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Alpha, meta=(PinShownByDefault))
	float ArmAdditiveAlpha;

	KGCHARACTER_API FAnimNode_C7ModifyBones();

	// FAnimNode_Base interface
	KGCHARACTER_API virtual void GatherDebugData(FNodeDebugData& DebugData) override;
	// End of FAnimNode_Base interface
	virtual int32 GetLODThreshold() const override { return LODThreshold; } 
	KGCHARACTER_API virtual void Initialize_AnyThread(const FAnimationInitializeContext& Context) override;
	KGCHARACTER_API virtual void CacheBones_AnyThread(const FAnimationCacheBonesContext& Context)  override;
	KGCHARACTER_API virtual void Update_AnyThread(const FAnimationUpdateContext& Context) override;
	KGCHARACTER_API virtual void Evaluate_AnyThread(FPoseContext& Output) override;


	static KGCHARACTER_API FTransform GetTargetTransform(const FTransform& InComponentTransform, FCSPose<FCompactPose>& MeshBases, FBoneSocketTarget& InTarget, EBoneControlSpace Space, const FVector& InOffset);
	
private:
	bool EvaluateBatchModifyBoneIK_AnyThread(FComponentSpacePoseContext& Output,	TMap<FName, float>& CurveValueMap) ;
	bool EvaluateBatchTwoBoneIK_AnyThread(FComponentSpacePoseContext& Output, TMap<FName, float>& CurveValueMap) ;

	// Resused bone transform array to avoid reallocating in skeletal controls
	TArray<FBoneTransform> BoneTransforms;
	TMap<FName, float> AlphaCurveValues;
	TMap<int32, float> BoneAlphas;
};
