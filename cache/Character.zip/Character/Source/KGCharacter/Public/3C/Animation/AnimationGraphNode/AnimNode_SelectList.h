// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "AnimNodes/AnimNode_BlendListBase.h"
#include "AnimNode_SelectList.generated.h"

//Select list node; has many children
USTRUCT(BlueprintInternalUseOnly)
struct FAnimNode_SelectList : public FAnimNode_Base
{
	GENERATED_BODY()

protected:
	UPROPERTY(EditAnywhere, EditFixedSize, Category = Links)
	TArray<FPoseLink> SelectPose = { FPoseLink(), FPoseLink(), FPoseLink(), FPoseLink() };

public:
#if WITH_EDITORONLY_DATA
	UPROPERTY(EditAnywhere, Category = Runtime, meta = (FoldProperty, ClampMin = 0, ClampMax = 8))
	int32 IntIndexRange1 = 1;

	UPROPERTY(EditAnywhere, Category = Runtime, meta = (FoldProperty, EditCondition = "IntIndexRange1 > 0", EditConditionHides))
	bool bAllowBlendForIntChildIndex1 = false;

	UPROPERTY(EditAnywhere, Category = Runtime, meta = (PinShownByDefault, FoldProperty, EditCondition = "false", EditConditionHides))
	int32 ActiveIntChildIndex1 = 0;


	UPROPERTY(EditAnywhere, Category = Runtime, meta = (FoldProperty, ClampMin = 0, ClampMax = 8))
	int32 IntIndexRange2 = 0;

	UPROPERTY(EditAnywhere, Category = Runtime, meta = (FoldProperty, EditCondition = "IntIndexRange2 > 0", EditConditionHides))
	bool bAllowBlendForIntChildIndex2 = false;

	UPROPERTY(EditAnywhere, Category = Runtime, meta = (PinShownByDefault, FoldProperty, EditCondition = "false", EditConditionHides))
	int32 ActiveIntChildIndex2 = 0;


	UPROPERTY(EditAnywhere, Category = Runtime, meta = (FoldProperty, ClampMin = 0, ClampMax = 8))
	int32 IntIndexRange3 = 0;

	UPROPERTY(EditAnywhere, Category = Runtime, meta = (FoldProperty, EditCondition = "IntIndexRange3 > 0", EditConditionHides))
	bool bAllowBlendForIntChildIndex3 = false;

	UPROPERTY(EditAnywhere, Category = Runtime, meta = (PinShownByDefault, FoldProperty, EditCondition = "false", EditConditionHides))
	int32 ActiveIntChildIndex3 = 0;


	UPROPERTY(EditAnywhere, Category = Runtime, meta = (FoldProperty, ClampMin = 0, ClampMax = 1))
	int32 BoolIndexRange1 = 1;

	UPROPERTY(EditAnywhere, Category = Runtime, meta = (FoldProperty, EditCondition = "BoolIndexRange1 > 0", EditConditionHides))
	bool bAllowBlendForBoolChildIndex1 = false;

	UPROPERTY(EditAnywhere, Category = Runtime, meta = (PinShownByDefault, AlwaysAsPin, FoldProperty, EditCondition = "false", EditConditionHides))
	bool ActiveBoolChildIndex1 = 0;


	UPROPERTY(EditAnywhere, Category = Runtime, meta = (FoldProperty, ClampMin = 0, ClampMax = 1))
	int32 BoolIndexRange2 = 0;

	UPROPERTY(EditAnywhere, Category = Runtime, meta = (FoldProperty, EditCondition = "BoolIndexRange2 > 0", EditConditionHides))
	bool bAllowBlendForBoolChildIndex2 = false;

	UPROPERTY(EditAnywhere, Category = Runtime, meta = (PinShownByDefault, FoldProperty, EditCondition = "false", EditConditionHides))
	bool ActiveBoolChildIndex2 = 0;


	UPROPERTY(EditAnywhere, Category = Runtime, meta = (FoldProperty, ClampMin = 0, ClampMax = 1))
	int32 BoolIndexRange3 = 0;

	UPROPERTY(EditAnywhere, Category = Runtime, meta = (FoldProperty, EditCondition = "BoolIndexRange3 > 0", EditConditionHides))
	bool bAllowBlendForBoolChildIndex3 = false;

	UPROPERTY(EditAnywhere, Category = Runtime, meta = (PinShownByDefault, FoldProperty, EditCondition = "false", EditConditionHides))
	bool ActiveBoolChildIndex3 = 0;


	UPROPERTY(EditAnywhere, Category = Runtime, meta = (FoldProperty))
	float BlendTimeIfAllowBlend = 0.1f;
#endif
	
public:
	FAnimNode_SelectList() = default;

	// FAnimNode_Base interface
	KGCHARACTER_API virtual void Initialize_AnyThread(const FAnimationInitializeContext& Context) override;
	KGCHARACTER_API virtual void CacheBones_AnyThread(const FAnimationCacheBonesContext& Context) override;
	KGCHARACTER_API virtual void Update_AnyThread(const FAnimationUpdateContext& Context) override;
	KGCHARACTER_API virtual void Evaluate_AnyThread(FPoseContext& Output) override;
	KGCHARACTER_API virtual void GatherDebugData(FNodeDebugData& DebugData) override;
	// End of FAnimNode_Base interface
	
protected:
	int32 LastActiveChildIndex = 0;

	virtual FString GetNodeName(FNodeDebugData& DebugData) { return DebugData.GetNodeName(this); }

	int32 GetChildIndexNodeDate(int32 Index);
	void InitializeNodeStaticData();
	int32 GetActiveChildIndex();
	void UpdateForceUpdatePoseIndexList();
	int32 GetNonBlendIndex();

private:
	// 每个节点的Range范围
	TArray<int32> RangeValueList = { 0,0,0,0,0,0 };
	// 记录每个节点是否可以使用Index缓存值
	TArray<bool> IfUseCacheNodeValueList = { false, false, false, false, false, false };
	// 记录每个节点的缓存Index值
	TArray<int32> CachedNodeValueList = { 0, 0, 0, 0, 0, 0 };
	// 记录每个节点是否允许Blend
	TArray<bool> IfAllowBlendList = { false, false, false, false, false, false };
	// Blend时间
	float FinalBlendTimeIfAllowBlend = 0.0f;

	// 记录所有节点的Blend参数
	TArray<FAlphaBlend> BlendDataList;
	// 可能会被更新到，强制需要Update的PoseIndex队列，由配置需要Blend的节点计算得到
	TArray<int32> ForceUpdatePoseIndexList;

#if WITH_EDITOR
public:
	virtual void ResizePose(int32 ResizeNumber)
	{
		SelectPose.SetNum(ResizeNumber);
	}
#endif
};
