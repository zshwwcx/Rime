/**
 * Auth :   liubo
 * Date :   2026-02-07 15:21
 * Comment: 实验功能，有很多临时代码，不要正式使用
 */
 
#pragma once

#include "CoreMinimal.h"
#include "AnimEncoding.h"
#include "UObject/ObjectMacros.h"
#include "Animation/AnimNodeBase.h"
#include "Animation/InputScaleBias.h"
#include "Animation/AnimSequenceBase.h"
#include "CustomAnimNodeDefine.h"
#include "BoneContainer.h"
#include "BonePose.h"
#include "CommonAnimTypes.h"
#include "Animation/AnimInstanceProxy.h"
#include "Animation/AnimExecutionContext.h"
#include "Animation/Skeleton.h"
#include "AnimNode_AIFacePlayer.generated.h"

struct FGetBonePoseScratchAreaC7
{
	BoneTrackArray RotationScalePairs;
	BoneTrackArray TranslationPairs;
	BoneTrackArray AnimScaleRetargetingPairs;
	BoneTrackArray AnimRelativeRetargetingPairs;
	BoneTrackArray OrientAndScaleRetargetingPairs;

	// A bit set that specifies whether a compact bone index has its rotation animated by the sequence or not
	TBitArray<> AnimatedCompactRotations;
};

struct FC7RetargetInfo
{
	bool bDirty = false;
	FName RetargetSource;
	FGetBonePoseScratchAreaC7 BoneInfo;
	TMap<int, float> CachedScaleTranslationMap;
	TMap<int, FTransform> CachedRelativeTransformMap; // mesh到骨骼的
	TMap<int, FTransform> CachedRelativeTransformMap2; // 骨骼到骨骼的
	TWeakObjectPtr<USkeleton> SourceSkeleton = nullptr;
	TWeakObjectPtr<USkeleton> TargetSkeleton = nullptr;
	TArray<int> CompactPoseIndexToOrientAndScaleIndex;
	const TArray<FTransform>& GetRetargetTransforms();
	const TArray<FTransform>& GetRetargetTransformsOrigin();
};
struct FOneFrameBoneData
{
	FString BoneName;
	FTransform Transform;
	FTransform FbxTransform;
	float PosDelta = 0;
	float RotDelta = 0;
};
struct FOneFrameData
{
	int FrameId = -1;
	TArray<FOneFrameBoneData> BoneDataList;	
};

USTRUCT(BlueprintInternalUseOnly)
struct KGCHARACTER_API FAnimNode_AIFacePlayer : public FAnimNode_Base
{
	GENERATED_USTRUCT_BODY()

public:
	// 输入姿态
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Links)
	FPoseLink BasePose;

	// 自定义动画数据
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinShownByDefault))
	FCustomAnimationData AnimationData;

	// 播放时间
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinShownByDefault))
	float PlayTime = 0;

	// 是否播放
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinShownByDefault))
	bool IsPlaying = false;
	
	// 是否暂停
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinShownByDefault))
	bool IsPaused = false;
	
	// 是否循环播放
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinShownByDefault))
	bool Loop = false;
	
	// 是否循环播放
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Settings, meta = (PinShownByDefault))
	bool bDebugDisableRetarget = false;

public:
	FAnimNode_AIFacePlayer();

	// FAnimNode_Base interface (UE5版本)
	virtual void Initialize_AnyThread(const FAnimationInitializeContext& Context) override;
	virtual void CacheBones_AnyThread(const FAnimationCacheBonesContext& Context) override;
	virtual void Update_AnyThread(const FAnimationUpdateContext& Context) override;
	virtual void Evaluate_AnyThread(FPoseContext& Output) override;	
	virtual void GatherDebugData(FNodeDebugData& DebugData) override;
	virtual bool HasPreUpdate() const override { return true; }
protected:
	void CachedRetargetInfo_AnyThread(const FPoseContext& Output);
	void Evaluate_AnyThread_LogicV2(FPoseContext& Output);
	void Evaluate_AnyThread_LogicV3(FPoseContext& Output);
public:
	void SetData();
private:
	TMap<FString, FVector> BoneLocationData;
	
	// 缓存的骨骼引用
	TArray<FBoneReference> BoneReferences;

	FString AnimationName;
	FName RetargetSourceName;

	// 获取指定时间的骨骼变换
	FTransform GetBoneTransformAtTime(const FC7BoneAnimationTrack& Track, float Time) const;

	// 插值计算 (UE5使用更精确的插值)
	FVector InterpolateVector(const FVector& A, const FVector& B, float Alpha) const;
	FQuat InterpolateRotation(const FQuat& A, const FQuat& B, float Alpha) const;

	// Lerp值
	FTransform LerpTransform(const FTransform& Src, const FTransform& Dst, float Weight);
	
	TSharedPtr<TArray<FOneFrameData>> DebugAnimDataPtr;

	FC7RetargetInfo CachedRetargetInfo; // 在anythread中读写
	bool bErrorPos = false;
	bool bErrorRot = false;
	bool bErrorScale = false;
	float BlendToEndWeight = 1;
};