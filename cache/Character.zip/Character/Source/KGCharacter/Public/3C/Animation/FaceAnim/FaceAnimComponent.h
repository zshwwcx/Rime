#pragma once
#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "3C/Animation/FaceAnim/FaceAnimLipSync.h"
#include "FaceAnimComponent.generated.h"

UENUM(BlueprintType)
enum class EFaceAnimSexType : uint8
{
	Male = 0,
	Female,
	None //未标记
};

//音频面部动画,Audio2Face的应用 @hujianglong @lichaofan
//https://docs.corp.kuaishou.com/k/home/VUWXkE7Tn2QE/fcACZcAaUjFF6MhDoXf5tW971
//https://docs.corp.kuaishou.com/d/home/fcABXorv-ckr8eVIWee2qZ-qJ#section=h.s9ix5u4mmimg

UCLASS(Blueprintable, BlueprintType, ClassGroup = (Anim), meta = (BlueprintSpawnableComponent))
class KGCHARACTER_API UFaceAnimComponent : public UActorComponent
{
	GENERATED_UCLASS_BODY()

public:
	virtual void InitializeComponent() override;

	virtual void BeginPlay() override;

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	
	UFUNCTION(BlueprintCallable)
	void InitFaceAnim();
	
	UFUNCTION(BlueprintCallable)
	UFaceAnimLayer* InitFaceAnimLayer(USkeletalMeshComponent* CachedMeshComp, EFaceAnimSexType Sex);
	
public:
	UFUNCTION(BlueprintCallable)
	void PlayLipFaceAnim(class USkeletalMeshComponent* CachedMeshComp, const FString& FaceAnimID, float FixTime, EFaceAnimSexType Sex = EFaceAnimSexType::None);
	
	UFUNCTION(BlueprintCallable)
	void SetLipBlend(float lipBlend);

	UFUNCTION(BlueprintCallable)
	void SetFaceFloatParam(const FName & key, float value);

	UFUNCTION(BlueprintCallable)
	void SetLipFaceAnimFrame(class USkeletalMeshComponent* CachedMeshComp, const FString& FaceAnimID, float FixTime, float LipBlend, EFaceAnimSexType Sex = EFaceAnimSexType::None);

	UFUNCTION(BlueprintCallable)
	void SetLipFaceAnimCurFrameTime(float CurTime);

#pragma region LipSync
public:
	UFUNCTION()
	void OnCharacterAkEvent(class ABaseCharacter* Character, const FString& in_EventName);
	
protected:
	//口型初始化
	void LipSyncInit();
	//口型更新
	void LipSyncUpdate(float DeltaTime);
	
public:
	//口型处理类
	UPROPERTY(EditDefaultsOnly, Category="Config|LipSync")
	TSubclassOf<UFaceAnimLipSync> FaceLipSyncClass;

	//口型资源配置
	UPROPERTY(EditDefaultsOnly, Category="Config|LipSync")
	FLipSyncAssetInfo VisemeAssetInfo;
	
protected:
	UPROPERTY(BlueprintReadOnly, Transient, Category="LipSync")
	UFaceAnimLipSync* FaceLipSync = nullptr;

#pragma endregion LipSync

#pragma region EyeControl
protected:
	//眼球控制初始化
	void EyeControlInit();
	//眼球控制更新
	void EyeControlUpdate(float DeltaTime);
#pragma endregion EyeControl

protected:
	
	UPROPERTY(EditDefaultsOnly, Category = "Config|LipSync")
	TSubclassOf<class UFaceAnim> FaceAnimClass;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	TSubclassOf<class UAnimInstance> FaceAnimLayerClass;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	TSubclassOf<class UAnimInstance> ManFaceAnimLayerClass;

	UPROPERTY(Transient, BlueprintReadWrite)
	TSubclassOf<class UAnimInstance> CurFaceAnimLayerClass;
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FString FaceAnimLayerTag = "FaceAnim";

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FString SexName_Male = "_Male";

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FString SexName_Female = "_Female";

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	uint32 bAutoLoadFaceAnimLayer : 1;

	UPROPERTY(Transient)
	uint32 bLoadedFaceAnimLayer : 1;
public:
	UPROPERTY(BlueprintReadOnly, Transient, Category = "FaceAnim")
	class UFaceAnim* FaceAnim = nullptr;

protected:
	UPROPERTY(Transient, BlueprintReadOnly)
	TWeakObjectPtr<class ABaseCharacter> Character = nullptr;
};