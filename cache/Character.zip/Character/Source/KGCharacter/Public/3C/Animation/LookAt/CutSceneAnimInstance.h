#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimInstance.h"

#include "CutSceneAnimInstance.generated.h"

/**
 * 剧情动画蓝图基类
 */
UCLASS(BlueprintType, Blueprintable)
class KGCHARACTER_API UCutSceneAnimInstance : public UAnimInstance
{
	GENERATED_UCLASS_BODY()
public:

	UFUNCTION(BlueprintCallable)
	FRotator GetEye() const
	{
		//UE_LOG(LogTemp, Warning, TEXT("GetEye =>Eye:%f %f %f %x"), Eye.Pitch, Eye.Yaw, Eye.Roll, &Eye);
		return Eye;
	}

	UFUNCTION(BlueprintCallable)
	FVector GetEyeScale() const
	{
		//UE_LOG(LogTemp, Warning, TEXT("GetEyeScale =>GetEyeScale:%f %f %f %x"), EyeScale.X, EyeScale.Y, EyeScale.Z, &EyeScale);
		return EyeScale;
	}

	UFUNCTION(BlueprintCallable)
	FRotator GetHead() const
	{
		//UE_LOG(LogTemp, Warning, TEXT("GetHead =>Head:%f %f %f"), Head.Pitch, Head.Yaw, Head.Roll);
		return Head;
	}

	UFUNCTION(BlueprintCallable)
	FRotator GetBody() const
	{
		//UE_LOG(LogTemp, Warning, TEXT("GetBody =>Body:%f %f %f"), Body.Pitch, Body.Yaw, Body.Roll);
		return Body;
	}

	UFUNCTION(BlueprintCallable)
	FRotator GetSpine_01() const
	{
		//UE_LOG(LogTemp, Warning, TEXT("GetBody =>Body:%f %f %f"), Body.Pitch, Body.Yaw, Body.Roll);
		return Spine_01;
	}

	UFUNCTION(BlueprintCallable)
	FRotator GetSpine_02() const
	{
		//UE_LOG(LogTemp, Warning, TEXT("GetBody =>Body:%f %f %f"), Body.Pitch, Body.Yaw, Body.Roll);
		return Spine_02;
	}

	UFUNCTION(BlueprintCallable)
	FRotator GetSpine_03() const
	{
		//UE_LOG(LogTemp, Warning, TEXT("GetBody =>Body:%f %f %f"), Body.Pitch, Body.Yaw, Body.Roll);
		return Spine_03;
	}
public:

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Transform, meta = (AllowPrivateAccess = "true", UIMin = "0.0", UIMax = "359.999"))*/
	FRotator Eye;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Transform, meta = (AllowPrivateAccess = "true", UIMin = "0.0", UIMax = "359.999"))*/
	FVector EyeScale;

	/** Rotation of the component relative to its parent */
	/*UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Transform, meta = (AllowPrivateAccess = "true", UIMin = "0.0", UIMax = "359.999"))*/
	FRotator Head;

	/**
	*	Non-uniform scaling of the component relative to its parent.
	*	Note that scaling is always applied in local space (no shearing etc)
	*/
	/*UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Transform, meta = (AllowPrivateAccess = "true", UIMin = "0.0", UIMax = "359.999"))*/
	FRotator Body;

	/**
	*	Non-uniform scaling of the component relative to its parent.
	*	Note that scaling is always applied in local space (no shearing etc)
	*/
	/*UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Transform, meta = (AllowPrivateAccess = "true", UIMin = "0.0", UIMax = "359.999"))*/
	FRotator Spine_01;

	/**
	*	Non-uniform scaling of the component relative to its parent.
	*	Note that scaling is always applied in local space (no shearing etc)
	*/
	/*UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Transform, meta = (AllowPrivateAccess = "true", UIMin = "0.0", UIMax = "359.999"))*/
	FRotator Spine_02;

	/**
	*	Non-uniform scaling of the component relative to its parent.
	*	Note that scaling is always applied in local space (no shearing etc)
	*/
	/*UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Transform, meta = (AllowPrivateAccess = "true", UIMin = "0.0", UIMax = "359.999"))*/
	FRotator Spine_03;
};