﻿#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "3C/Material/KGMaterialCommon.h"
#include "Runtime/AvatarBodyPartType.h"

#include "AnimNotifyState_C7ChangeMaterial.generated.h"

class UMeshComponent;
class UMaterialInterface;

UENUM(BlueprintType)
enum class EKGChangeMaterialLifeTimeMode : uint8
{
	BindState = 0 UMETA(DisplayName = "BindState"),
	FixedTime = 1 UMETA(DisplayName = "FixedTime"),
};


UCLASS(meta = (DisplayName = "C7ChangeMaterial(修改材质)", ToolTip="修改材质, 不支持预览"))
class UAnimNotifyState_C7ChangeMaterial : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) override;
	
private:
	
	UPROPERTY(EditAnywhere, meta=(DisplayName="生命周期类型", Category="LifeTime"))
	EKGChangeMaterialLifeTimeMode LifeTimeMode = EKGChangeMaterialLifeTimeMode::BindState;

	UPROPERTY(EditAnywhere, Category = "LifeTime", meta = (DisplayName = "Duration(秒)", EditCondition="LifeTimeMode==EKGChangeMaterialLifeTimeMode::FixedTime", EditConditionHides))
	float Duration = 1.0f;
	
	UPROPERTY(EditAnywhere, meta=(DisplayName="材质路径", Category="Basic"))
	TSoftObjectPtr<UMaterialInterface> MaterialPath;

	UPROPERTY(EditAnywhere, meta=(DisplayName="查找Mesh类型", Category="Basic"))
	EKGSearchMeshType SearchMeshType = EKGSearchMeshType::SearchSelfMeshes;

	UPROPERTY(EditAnywhere, Category = "Basic", meta = (DisplayName = "MeshTag", EditCondition="SearchMeshType==EKGSearchMeshType::SearchMeshByName", EditConditionHides))
	EAvatarBodyPartType ComponentTag = EAvatarBodyPartType::Head;
	
	UPROPERTY(EditAnywhere, meta=(DisplayName="查找Material类型", Category="Basic"))
	EKGSearchMaterialType SearchMaterialType = EKGSearchMaterialType::SearchAllNormalMaterial;
	
	UPROPERTY(EditAnywhere, Category = "Basic", meta = (DisplayName = "材质插槽名称", EditCondition="SearchMaterialType==EKGSearchMaterialType::SearchMaterialBySlots", EditConditionHides))
	TArray<FName> MaterialSlotNames;

	UPROPERTY(EditAnywhere, meta=(DisplayName="优先级", Category="Basic"))
	uint32 Priority = static_cast<uint32>(EKGMaterialPriority::Default); 

	TMap<TWeakObjectPtr<UMeshComponent>, uint32> ReqIDsMapping;
};
