#pragma once
#include "CoreMinimal.h"
#include "3C/Animation/AnimCommon.h"
#include "FaceAnimLipSync.generated.h"

/**
 * 实时音频转口型动画功能
 * 这一坨代码不用管，没有什么用！ @hujianglong
 */

//单帧口型信息
USTRUCT(BlueprintType)
struct FVisemeFrameData 
{
	GENERATED_BODY()
public:
	//单帧口型值(名称, 值)
	UPROPERTY(BlueprintReadWrite)
	TMap<FString, float> FrameViseme;
};

//单次触发表情信息
USTRUCT(BlueprintType)
struct FTiggerFaceFrameData
{
	GENERATED_BODY()
public:
	//触发时间(ms)
	UPROPERTY(BlueprintReadWrite)
	float TiggerTime = .0f;

	//单帧口型值(名称, 值)
	UPROPERTY(BlueprintReadWrite)
	TMap<FString, float> FrameViseme;
};

class UDataTable;

//角色口型
UCLASS(BlueprintType, Blueprintable, ClassGroup = (ActionAnim))
class KGCHARACTER_API UFaceAnimLipSync : public UObject
{
	GENERATED_BODY()

public:
	UFaceAnimLipSync();

	//初始化
	UFUNCTION(BlueprintCallable)
	void InitLipSync(FLipSyncAssetInfo InSyncAssetInfo, class USkeletalMeshComponent* InMesh);

	//更新
	UFUNCTION(BlueprintCallable)
	void Update(float DeltaTime);

public:
	//重置
	UFUNCTION(BlueprintCallable)
	void Reset();

	//播放
	UFUNCTION(BlueprintCallable)
	void Play(const FString& VisemeFileName);

	//暂停
	UFUNCTION(BlueprintCallable)
	void Pause();

	//停止
	UFUNCTION(BlueprintCallable)
	void Stop();

protected:

	UFUNCTION(BlueprintImplementableEvent)
	void OnReset();

	UFUNCTION(BlueprintImplementableEvent)
	void OnPlay(const FString & VisemeFileName);

	UFUNCTION(BlueprintImplementableEvent)
	void OnPause();

	UFUNCTION(BlueprintImplementableEvent)
	void OnStop();

	UFUNCTION(BlueprintImplementableEvent)
	void OnUpdate(float DeltaTime);
	
protected:
	//读取文件夹下的所有口型资源
	void LoadAllAssetPath();

	//加载对应路径下口型资源
	UFUNCTION(BlueprintCallable)
	void LoadVisemeDataTable(const FString& FilePath);

	UFUNCTION(BlueprintImplementableEvent)
	void InternalParseDataTable(UDataTable* RawData, const TArray<FName>& Names);

protected:
	//表情
	//加载对应路径下触发表情资源
	UFUNCTION(BlueprintCallable)
	void LoadTriggerFaceDataTable(const FString& FilePath);

	UFUNCTION(BlueprintImplementableEvent)
	bool InternalTriggerFaceParseDataTable(UDataTable* RawData, const TArray<FName>& Names);

protected:
	//目标Sk
	UPROPERTY(BlueprintReadOnly, Transient)
	TWeakObjectPtr<class USkeletalMeshComponent> Mesh = nullptr;

protected:
	//当前口型
	UPROPERTY(BlueprintReadWrite,Transient)
	TMap<FString, float> CurVisemePlayMap;

	//当前使用资源口型信息
	UPROPERTY(BlueprintReadWrite, Transient)
	TMap<int32, FVisemeFrameData> CurVisemeAssetDataMap;

	//当前使用触发表情(行数, 数据)
	UPROPERTY(BlueprintReadWrite, Transient)
	TMap<int32, FTiggerFaceFrameData> CurTriggerFaceDataMap;

	//使用的口型配置
	UPROPERTY(BlueprintReadWrite, Transient)
	FLipSyncAssetInfo VisemeAssetInfo;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	UStruct* VisemeStruct = nullptr;

	//各音频对应口型资源文件(名称, 路径)
	UPROPERTY(BlueprintReadWrite, Transient)
	TMap<FString, FString> VisemeAssetPathMap;

	//各触发表情对应的资源文件(名称, 路径)
	UPROPERTY(BlueprintReadWrite, Transient)
	TMap<FString, FString> TriggerFacePathMap;
};