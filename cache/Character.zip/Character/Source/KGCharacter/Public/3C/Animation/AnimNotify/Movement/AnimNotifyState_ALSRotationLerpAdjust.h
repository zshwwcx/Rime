// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once
#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "3C/Animation/AnimNotify/Movement/AnimNotify_RotateInstantly.h"
#include "AnimNotifyState_ALSRotationLerpAdjust.generated.h"

class UAnimSequenceBase;

UCLASS(meta = (DisplayName = "ALSRotationLerpAdjust"))
class KGCHARACTER_API UAnimNotifyState_ALSRotationLerpAdjust : public UAnimNotifyState, public IAnimNotify_MovementControlInterface
{
	GENERATED_BODY()

public:
	void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference) override;
	void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) override;

public:
	// ALS_RotationMode为VelocityDirection时的朝向插值速度，大于0生效
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Config")
	float OverrideLerpSpeedForVelocityDirection = -1.0f;
};

