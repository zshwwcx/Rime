// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "3C/Animation/BaseAnimInstance.h"
#include "WeaponAnimInstance.generated.h"

/**
 * 
 */
UCLASS()
class KGCHARACTER_API UWeaponAnimInstance : public UBaseAnimInstance
{
	GENERATED_BODY()

#if WITH_EDITOR
protected:
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;
#endif
	
public:
#if WITH_EDITORONLY_DATA
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "WeaponAnimation")
	USkeleton* WeaponSkeleton = nullptr;
#endif
	
	UPROPERTY(EditDefaultsOnly, Category = "WeaponAnimation")
	TMap<FString, TSoftObjectPtr<UAnimMontage>> WeaponMontageMap;

	FString GetWeaponAnimPathByID(const FString& AnimID);
};
