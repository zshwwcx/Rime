#pragma once
#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "3C/Animation/FaceAnim/FaceAnimLipSync.h"
#include "LookAtComponent.generated.h"

UCLASS(Blueprintable, BlueprintType, ClassGroup = (Anim), meta = (BlueprintSpawnableComponent))
class KGCHARACTER_API ULookAtComponent : public UActorComponent
{
	GENERATED_UCLASS_BODY()

public:
	
	virtual void InitializeComponent() override;

	virtual void BeginPlay() override;

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	void UpdateProperty();
	/**
	 * Gets the property name for Eye.
	 *
	 * This exists so subclasses don't need to have direct access to the Eye property so it
	 * can be made private later.
	 */
	static const FName GetRelativeEyePropertyName()
	{
		return GET_MEMBER_NAME_CHECKED(ULookAtComponent, Eye);
	}


	/**
	 * Gets the property name for EyeScale.
	 *
	 * This exists so subclasses don't need to have direct access to the EyeScale property so it
	 * can be made private later.
	 */
	static const FName GetRelativeEyeScalePropertyName()
	{
		return GET_MEMBER_NAME_CHECKED(ULookAtComponent, EyeScale);
	}


	/**
	 * Gets the property name for Head.
	 *
	 * This exists so subclasses don't need to have direct access to the Head property so it
	 * can be made private later.
	 */
	static const FName GetRelativeHeadPropertyName()
	{
		return GET_MEMBER_NAME_CHECKED(ULookAtComponent, Head);
	}

	/**
	 * Gets the property name for Body.
	 *
	 * This exists so subclasses don't need to have direct access to the Body property so it
	 * can be made private later.
	 */
	static const FName GetRelativeBodyPropertyName()
	{
		return GET_MEMBER_NAME_CHECKED(ULookAtComponent, Body);
	}

	/**
	 * Gets the property name for Spine_01.
	 *
	 * This exists so subclasses don't need to have direct access to the Spine_01 property so it
	 * can be made private later.
	 */
	static const FName GetRelativeSpine_01PropertyName()
	{
		return GET_MEMBER_NAME_CHECKED(ULookAtComponent, Spine_01);
	}

	/**
	 * Gets the property name for Spine_02.
	 *
	 * This exists so subclasses don't need to have direct access to the Spine_02 property so it
	 * can be made private later.
	 */
	static const FName GetRelativeSpine_02PropertyName()
	{
		return GET_MEMBER_NAME_CHECKED(ULookAtComponent, Spine_02);
	}

	/**
	 * Gets the property name for Spine_03.
	 *
	 * This exists so subclasses don't need to have direct access to the Spine_03 property so it
	 * can be made private later.
	 */
	static const FName GetRelativeSpine_03PropertyName()
	{
		return GET_MEMBER_NAME_CHECKED(ULookAtComponent, Spine_03);
	}

	FRotator GetEye() const
	{
		return Eye;
	};

	FVector GetEyeScale() const
	{
		//UE_LOG(LogTemp, Warning, TEXT("ULookAtComponent GetEyeScale => Eye:%f %f %f "), EyeScale.X, EyeScale.Y, EyeScale.Z);
		return EyeScale;
	};
	FRotator GetHead() const
	{
		return Head;
	};
	FRotator GetBody() const
	{
		return Body;
	};

	FRotator GetSpine_01() const
	{
		return Spine_01;
	};

	FRotator GetSpine_02() const
	{
		return Spine_02;
	};

	FRotator GetSpine_03() const
	{
		return Spine_03;
	};

	void SetEye(FRotator InEye)
	{
		Eye = InEye;
	};

	void SetEyeScale(FVector InScale)
	{
		//UE_LOG(LogTemp, Warning, TEXT("ULookAtComponent SetEyeScale => Eye:%f %f %f "), InScale.X, InScale.Y, InScale.Z);
		EyeScale = InScale;
	};

	void SetHead(FRotator InHead)
	{
		Head = InHead;
	};
	void SetBody(FRotator InBody)
	{
		Body = InBody;
	};

	void SetSpine_01(FRotator InSpine_01)
	{
		Spine_01 = InSpine_01;
	};

	void SetSpine_02(FRotator InSpine_02)
	{
		Spine_02 = InSpine_02;
	};

	void SetSpine_03(FRotator InSpine_03)
	{
		Spine_03 = InSpine_03;
	};

protected:
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	TSubclassOf<class UAnimInstance> AnimLayerClass;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	uint32 bAutoLoadAnimLayer : 1;

	UPROPERTY(Transient)
	uint32 bLoadedAnimLayer : 1;

protected:
	UPROPERTY(Transient, BlueprintReadOnly)
	TWeakObjectPtr<class ABaseCharacter> Character = nullptr;

private:
	/** Rotation of the Eye relative to its parent */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = LookAt, meta = (AllowPrivateAccess = "true", UIMin = "-359.999", UIMax = "359.999"))
	FRotator Eye;

	/** Scale of the Eye relative to its parent */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = LookAt, meta = (AllowPrivateAccess = "true", UIMin = "0.0", UIMax = "359.999"))
	FVector EyeScale = FVector(1.0,1.0,1.0);

	/** Rotation of the Head relative to its parent */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = LookAt, meta = (AllowPrivateAccess = "true", UIMin = "-359.999", UIMax = "359.999"))
	FRotator Head;

	/** Rotation of the Body relative to its parent */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = LookAt, meta = (AllowPrivateAccess = "true", UIMin = "-359.999", UIMax = "359.999"))
	FRotator Body;

	/** Rotation of the spine_01 relative to its parent */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = LookAt, meta = (AllowPrivateAccess = "true", UIMin = "-359.999", UIMax = "359.999"))
	FRotator Spine_01;

	/** Rotation of the spine_02 relative to its parent */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = LookAt, meta = (AllowPrivateAccess = "true", UIMin = "-359.999", UIMax = "359.999"))
	FRotator Spine_02;

	/** Rotation of the spine_03 relative to its parent */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = LookAt, meta = (AllowPrivateAccess = "true", UIMin = "-359.999", UIMax = "359.999"))
	FRotator Spine_03;
};