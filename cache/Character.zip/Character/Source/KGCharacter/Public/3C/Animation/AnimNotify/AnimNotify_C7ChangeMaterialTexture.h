// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "Effect/KGEffectCommon.h"
#include "Runtime/AvatarBodyPartType.h"

#include "AnimNotify_C7ChangeMaterialTexture.generated.h"

class UTexture;
class UAnimSequenceBase;

UENUM()
enum class EKGFacialMaterialParamType
{
	ScalarConst = 0 UMETA(DisplayName="固定值"),
	Curve = 1 UMETA(DisplayName="曲线值"),
};

USTRUCT(Blueprintable)
struct KGCHARACTER_API FKGFacialMaterialParamCurveInfo
{
	GENERATED_BODY()
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	EKGFacialMaterialParamType ParamType = EKGFacialMaterialParamType::Curve;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition="ParamType==EKGFacialMaterialParamType::ScalarConst", EditConditionHides))
	float ScalarConst = 0.f;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition="ParamType==EKGFacialMaterialParamType::Curve", EditConditionHides))
	FRuntimeFloatCurve RuntimeFloatCurve;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition="ParamType==EKGFacialMaterialParamType::Curve", EditConditionHides))
	bool bLoop = true;
};

UCLASS(meta = (DisplayName = "C7 Change Material Texture(改变表情材质)"))
class KGCHARACTER_API UAnimNotify_C7ChangeMaterialTexture : public UAnimNotifyState
{
	GENERATED_BODY()
public:

	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float InTotalDuration, const FAnimNotifyEventReference& EventReference) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) override;
	
#if WITH_EDITOR
	// 仅编辑器预览用
	virtual void NotifyTick(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float FrameDeltaTime, const FAnimNotifyEventReference& EventReference) override;
	void HandleNotifyBeginEditorPreview(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float InTotalDuration, const FAnimNotifyEventReference& EventReference);
	void HandleNotifyEndEditorPreview(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation);
#endif
	
	UFUNCTION(BlueprintCallable)
	void SetChangeMaterialTextureParams(UTexture* InNewTextureA, UTexture* InNewTextureB,
		bool bInFindWithOutTag = true,
		EAvatarBodyPartType InComponentTag = EAvatarBodyPartType::Head,
		const FName& InSlotName = NAME_None,
		const FName& InTextureParameterNameA = NAME_None, const FName& InTextureParameterNameB = NAME_None, 
		const FName& InScalarParameterName = NAME_None,
		float InAlpha = 1.f, float InFadeInTime = 0.f, float InFadeOutTime = 0.f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotify", meta = (DisplayName = "无视Mesh Tag寻找合适Slot替换", AllowPrivateAccess = true))
	bool bFindWithOutTag = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotify", meta = (DisplayName = "SkeletalMeshComponent Tag", AllowPrivateAccess = true, EditCondition="bFindWithOutTag == false", EditConditionHides))
	EAvatarBodyPartType ComponentTag = EAvatarBodyPartType::Head;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotify", meta = (DisplayName = "Material Slot Name", AllowPrivateAccess = true))
	FName SlotName = NAME_None;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotify", meta = (DisplayName = "Texture Parameter Name A", AllowPrivateAccess = true))
	FName TextureParameterNameA = NAME_None;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotify", meta = (DisplayName = "Material Texture A", AllowPrivateAccess = true))
	TSoftObjectPtr<class UTexture> NewTextureA;

	// 用这个来替换AnimSequence上本身配置的材质参数曲线, 用于
	// 1, 可以精准确定材质参数作用的材质(UE自身的Material AnimCurve默认作用于全身所有Mesh上的所有Material)
	// 2, 动画优化导致Tick不执行, 材质参数更新还是会正常执行
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotify", meta = (DisplayName = "Scalar Material Params", AllowPrivateAccess = true))
	TMap<FName, FKGFacialMaterialParamCurveInfo> FacialMaterialParams;
	
#if WITH_EDITORONLY_DATA
	// 以下状态信息仅用于动画编辑器预览, 不可用于游戏运行时, 否则多个单位播放相同动画实例会出现状态冲突
	TMap<TWeakObjectPtr<AActor>, TArray<TWeakObjectPtr<class UMaterialInstanceDynamic>>> OverrideMaterialInstances;
#endif

	TMap<TWeakObjectPtr<USkeletalMeshComponent>, uint32> ChangeMaterialReqIds;
};
