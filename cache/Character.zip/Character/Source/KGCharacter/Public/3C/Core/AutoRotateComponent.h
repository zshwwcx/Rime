﻿#pragma once
#include "Components/SceneComponent.h"
#include "Engine/HitResult.h"
#include "AutoRotateComponent.generated.h"


UCLASS(meta=(BlueprintSpawnableComponent), hideCategories=(Mobility))
class KGCHARACTER_API UAutoRotateComponent : public USceneComponent
{
	GENERATED_BODY()

public:
	UAutoRotateComponent();
	
	virtual void TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UFUNCTION(BlueprintCallable)
	void SetRotateSpeed(float speed){ RotateSpeed = speed; }

	UFUNCTION(BlueprintCallable)
	void SetRotateSwitch(bool bOpen){ SetComponentTickEnabled(bOpen);}

	UPROPERTY()
	FRotator SocketRot = FRotator::ZeroRotator;
	
	UPROPERTY()
	FVector SocketLoc = FVector::ZeroVector;

private:
	float RotateSpeed = 60.0;

	bool NeedRotating = false;
	
	static const FName SocketName;


	
	virtual bool HasAnySockets() const override;
    virtual FTransform GetSocketTransform(FName InSocketName, ERelativeTransformSpace TransformSpace = RTS_World) const override;
	virtual void QuerySupportedSockets(TArray<FComponentSocketDescription>& OutSockets) const override;

	FHitResult SweepHitResult;
};
