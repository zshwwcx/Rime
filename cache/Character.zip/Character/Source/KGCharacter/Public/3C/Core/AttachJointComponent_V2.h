#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Engine/EngineTypes.h"
#include "Components/SceneComponent.h"
#include "Engine/HitResult.h"
#include "AttachJointComponent_V2.generated.h"



UENUM(BlueprintType)
enum class ERotationUpdateMode : uint8
{
	UseDesiredRot = 0,
	FaceToMoveDir,
	AutoRotate,
	UseOwnerRot,
	// KeepWorld,
};

UENUM(BlueprintType)
enum class ELocationUpdateMode : uint8
{
	None = 0,
	Interp,
	Bezier,
	Bezier_WithInCircleLag,
	FloatUpDown
};


USTRUCT(Blueprintable, BlueprintType)
struct  FAttachSocketData
{
	GENERATED_BODY()
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Attach")
	int64 SocketID = -1;

	UPROPERTY(BlueprintReadWrite, Category= "Data")
	FName AttachSocket = "";

	UPROPERTY(BlueprintReadWrite, Category= "Data")
	FName CompTag = "";
	
	UPROPERTY(BlueprintReadWrite, Category= "Data")
	bool bPauseOnNoAttached = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Attach")
	FVector AttachPointOffset = FVector::ZeroVector;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Attach")
	FRotator AttachPointRotation = FRotator::ZeroRotator;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Attach")
	FVector SocketRelativeOffset = FVector::ZeroVector;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Attach")
	FRotator SocketRelativeRotation = FRotator::ZeroRotator;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Attach|Collision")
	uint32 bDoCollisionTest:1 = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Attach|Collision", meta=(editcondition="bDoCollisionTest"))
	float ProbeSize = 30;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Attach|Collision", meta=(editcondition="bDoCollisionTest"))
	TArray<TEnumAsByte<EObjectTypeQuery>> CollisionChannels;
	
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Lagging|Interp", meta=( ClampMin="0.0", ClampMax="1000.0", UIMin = "0.0", UIMax = "1000.0"))
	float InCircleLagSpeed = 1;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite,  Category= "Lagging|Interp", meta=(ClampMin="0.0", UIMin = "0.0"))
	float InCircleLagTolerance = 50;

	
	UPROPERTY(EditAnywhere, BlueprintReadWrite,  Category= "Stabilize")
	bool bEnableStabilize = false;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite,  Category= "Stabilize", meta=(ClampMin="0.0", UIMin = "0.0"))
	float StabilizeTolerance = 50;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite,  Category= "Stabilize", meta=(ClampMin="0.0", UIMin = "0.0"))
	float StabilizeInterpSpeed = 1;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite,  Category= "Stabilize", meta=(ClampMin="0.0", UIMin = "0.0"))
	float StabilizeInterpOutSpeed = 5;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite,  Category= "Stabilize")
	FName StabilizePointBoneName = "";
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite,  Category= "Stabilize")
	FVector StabilizePointOffset = FVector::ZeroVector; 
	
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Lagging")
	ELocationUpdateMode LocationLagMode = ELocationUpdateMode::None ;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Lagging|Interp", meta=(editcondition="LocationLagMode == ELocationUpdateMode::Interp", ClampMin="0.0", ClampMax="1000.0", UIMin = "0.0", UIMax = "1000.0"))
	float AttachLagSpeed = 1;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite,  Category= "Lagging|Interp", meta=(editcondition="LocationLagMode == ELocationUpdateMode::Interp", ClampMin="0.0", UIMin = "0.0"))
	float AttachLagMaxDistance = 1000;
	
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Lagging|Bezier", meta=(editcondition="LocationLagMode == ELocationUpdateMode::Bezier"))
	float BezierStep = 0.1;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Lagging|Bezier", meta=(editcondition="LocationLagMode == ELocationUpdateMode::Bezier"))
	float BezierStepMaxDist = 100.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Lagging|Bezier", meta=(editcondition="LocationLagMode == ELocationUpdateMode::Bezier"))
	float BezierSpeedAlpha = 150.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Lagging|Bezier", meta=(editcondition="LocationLagMode == ELocationUpdateMode::Bezier"))
	float BezierLagSpeed = 2;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Lagging|Bezier", meta=(editcondition="LocationLagMode == ELocationUpdateMode::Bezier"))
	float BezierDirectionMultiplier = 0.5;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Lagging|floatEffect",meta=(editcondition="LocationLagMode == ELocationUpdateMode::FloatUpDown"))
	float FloatTime = 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Lagging|floatEffect",meta=(editcondition="LocationLagMode == ELocationUpdateMode::FloatUpDown"))
	float FloatMaxHeight = 20;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Lagging|floatEffect",meta=(editcondition="LocationLagMode == ELocationUpdateMode::FloatUpDown"))
	float FloatMinHeight = -20;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Lagging|floatEffect",meta=(editcondition="LocationLagMode == ELocationUpdateMode::FloatUpDown"))
	float FloatEaseExp = 3;

	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Lagging|Roation")
	uint32 bEnableAttachRotationLag : 1 = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite,  Category= "Lagging|Roation", meta=(editcondition="bEnableAttachRotationLag", ClampMin="0.0", ClampMax="1000.0", UIMin = "0.0", UIMax = "1000.0"))
	float AttachRotationLagSpeed = 20;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Lagging|Roation", meta=(editcondition="bEnableAttachRotationLag"))
	bool bClampPitch = false;
    	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Lagging|Roation", meta=(editcondition="bEnableAttachRotationLag"))
	FVector2D PitchClampAngle = FVector2D(0,0);
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Lagging|Rotation")
	ERotationUpdateMode RotationUpdateMode = ERotationUpdateMode::UseDesiredRot;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Lagging|Rotation", meta=(editcondition="bEnableAttachRotationLag && RotationUpdateMode == ERotationUpdateMode::FaceToMoveDir"))
	float FaceToMoveDirectionTolerance = 1;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= "Lagging|Rotation", meta=(editcondition="bEnableAttachRotationLag && RotationUpdateMode == ERotationUpdateMode::AutoRotate"))
	float RotateRoundTime = 10;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lagging|Rotation", meta = (editcondition = "bEnableAttachRotationLag && RotationUpdateMode == ERotationUpdateMode::AutoRotate"))
	bool bAbsoluteRotate = false;
};

USTRUCT(Blueprintable, BlueprintType)
struct  FAttachSocketRunningData
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, Category= "Data")
	TWeakObjectPtr<USceneComponent> CachedComp = nullptr;
	
	UPROPERTY(BlueprintReadWrite, Category= "Data")
	FVector DesiredLocation = FVector::ZeroVector;
	
	UPROPERTY(BlueprintReadWrite, Category= "Data")
	FRotator DesiredRotation = FRotator::ZeroRotator;
	
	UPROPERTY(BlueprintReadWrite, Category= "Data")
	FVector PreviousDesiredLoc = FVector::ZeroVector;

	UPROPERTY(BlueprintReadWrite, Category= "Data")
	FVector PreviousInterpLoc = FVector::ZeroVector;

	UPROPERTY(BlueprintReadWrite, Category= "Data")
	FRotator PreviousDesiredRot = FRotator::ZeroRotator;

	UPROPERTY(BlueprintReadWrite, Category= "Data")
	FVector PreviousStabilizeLoc = FVector::ZeroVector;

	UPROPERTY(BlueprintReadWrite, Category= "Data")
	float PreviousStabilizeBlendAlpha = 1;
	
	UPROPERTY(BlueprintReadWrite, Category= "Data")
	FVector PreviouseInCircleLoc = FVector::ZeroVector;
	
	UPROPERTY(BlueprintReadWrite, Category= "Data")
	FVector Velocity = FVector::ZeroVector;

	UPROPERTY(BlueprintReadWrite, Category= "Data")
	float Speed = 0;
	
	UPROPERTY(BlueprintReadWrite, Category= "Data")
	FVector SourceLocation = FVector::ZeroVector;

	UPROPERTY(BlueprintReadWrite, Category= "Data")
	FTransform FinalWorldTrans = FTransform::Identity;

	UPROPERTY(BlueprintReadWrite, Category= "Data|Float")
	bool bCurIsUpward = false;

	UPROPERTY(BlueprintReadWrite, Category= "Data|Float")
	bool bFirstUpdate = true;
};


USTRUCT(Blueprintable, BlueprintType)
struct  FAttachChildData
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite)
	int64 UniqueID = 0;

	UPROPERTY(BlueprintReadWrite)
	bool bMarkRemove = false;
	
	UPROPERTY(BlueprintReadWrite)
	FTransform AttachTransform = FTransform::Identity;

	UPROPERTY(BlueprintReadWrite)
	int64 SocketID = 0;
	
	UPROPERTY(BlueprintReadWrite)
	TWeakObjectPtr<USceneComponent> Comp;
};

UCLASS(meta=(BlueprintSpawnableComponent), hideCategories=(Mobility))
class KGCHARACTER_API UAttachJointComponent_V2 : public UActorComponent
{
	GENERATED_UCLASS_BODY()
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TMap<int64,FAttachSocketData> SocketData;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TMap<int64,FAttachSocketRunningData> SocketRunningData;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TMap<int64,FAttachChildData> AttachChildren;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float SharedCurrentTime = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint32 bEnableDebugDraw : 1 = false;

	UFUNCTION(BlueprintCallable)
	void RemoveAttachment(int64 AttachID);
	
	UFUNCTION(BlueprintCallable)
	int64 AddAttachActor(AActor* AttachActor,int64 SocketID,const FTransform& Trans);
	
	UFUNCTION(BlueprintCallable)
	int64 AddAttachComponent(USceneComponent* AttachComp,int64 SocketID,const FTransform& Trans);

	UFUNCTION(BlueprintCallable)
	int64 AddAttachSocket(FName AttachBoneSocket,FName CompTag,const FVector& BindOffset,
		const FRotator& BindRotation,const FVector& SocketOffset,const FRotator& Rotation);

	UFUNCTION(BlueprintCallable)
	bool ForceSocketUpdate(int64 SocketID,bool bEnableForceUpdate);

	UFUNCTION(BlueprintCallable)
	bool GetVirtualSocketLocation(int64 SocketID, FVector& OutLocation);

	UFUNCTION(BlueprintCallable)
	bool AddAttachSocketByID(int64 SocketID,FName AttachBoneSocket,FName CompTag,
		const FVector& BindOffset,const FRotator& BindRotation,const FVector& SocketOffset,const FRotator& Rotation, bool bAbsoluteRotate);
	
	UFUNCTION(BlueprintCallable)
	bool RemoveAttachSocket(int64 SocketID);

	UFUNCTION(BlueprintCallable)
	bool ModifyAttachSocket(int64 SocketID,FName AttachBoneSocket,FName CompTag,const FVector& BindOffset,
		const FRotator& BindRotation,const FVector& SocketOffset,const FRotator& Rotation);

	UFUNCTION(BlueprintCallable)
	bool EnableAttachSocketCollisionTest(int64 SocketID, float ProbeSize, const TArray<int>& CollisionChannels);

	UFUNCTION(BlueprintCallable)
	bool DisableAttachSocketCollisionTest(int64 SocketID);
	
	UFUNCTION(BlueprintCallable)
	bool EnableLocationStabilize(int64 SocketID, float StabilizeTolerance,float StabilizeInterpSpeed,float StabilizeInterpOutSpeed,
		const FName& StabilizePointBoneName,const FVector& StabilizePointOffset);

	UFUNCTION(BlueprintCallable)
	bool DisableLocationStabilize(int64 SocketID);

	UFUNCTION(BlueprintCallable)
	bool EnableAttachSocketLocationLagByFloat(int64 SocketID, float FloatTime,float  FloatMaxHeight, float FloatMinHeight, float FloatEaseExp);
	
	UFUNCTION(BlueprintCallable)
	bool EnableAttachSocketLocationLagByInterp(int64 SocketID,float  AttachLagSpeed,float AttachLagMaxDistance);
	
	UFUNCTION(BlueprintCallable)
	bool EnableAttachSocketLocationLagByBezier(int64 SocketID, float BezierStep,float BezierStepMaxDist, float BezierSpeedAlpha,float BezierLagSpeed,float BezierDirectionMultiplier);

	UFUNCTION(BlueprintCallable)
	bool EnableAttachSocketLocationLagByBezierWithInCircleLag(int64 SocketID, float BezierStep,float BezierStepMaxDist, float BezierSpeedAlpha,float BezierLagSpeed,float BezierDirectionMultiplier,
	float InCircleLagSpeed, float  InCircleLagTolerance);
	
	UFUNCTION(BlueprintCallable)
	bool DisableAttachSocketLocationLag(int64 SocketID);
	
	UFUNCTION(BlueprintCallable)
	bool EnableAttachSocketAttachRotationLag(int64 SocketID, float AttachRotationLagSpeed, bool bClampPitch, float PitchClampAngleMin, float PitchClampAngleMax, ERotationUpdateMode
	                                         RotationUpdateMode, float FaceToMoveDirectionTolerance, float RotateRoundTime);

	UFUNCTION(BlueprintCallable)
	bool DisableAttachSocketAttachRotationLag(int64 SocketID);

	UFUNCTION(BlueprintCallable)
	void SetIsEnableDebugDraw(const bool& bEnable) {bEnableDebugDraw = bEnable;}

	void UpdateAttachSocketRelLocation(int64 SocketID, FVector RelLoc);

	void UpdateIsLodEnableCollision(bool bEnableCollision);

	virtual void ResetToDefaultsForCache() override;

private:
	// Lod 是否允许开启碰撞检测
	bool bLodEnableCollision = true;
	
	float Shared_YawRotationDelta = 0;
	
	FHitResult HitResultCache;

	TSet<int64> ActiveSockets;
	
	TArray<int64> PendingRemoveIdx;
	// UActorComponent interface
	virtual void OnRegister() override;
	virtual void TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	virtual void PostLoad() override;
	virtual void ApplyWorldOffset(const FVector& InOffset, bool bWorldShift) override;
	// End of UActorComponent interface
	
	void UpdateAttachSockets( const float& DeltaTime);
	
	void PreUpdateLocationAndRotation(const FAttachSocketData& InData, FAttachSocketRunningData& OutRunningData, const float& DeltaTime);
	
	void UpdateLocationAndRotation(const FAttachSocketData& InData, FAttachSocketRunningData& OutRunningData, const float& DeltaTime);
	
};

