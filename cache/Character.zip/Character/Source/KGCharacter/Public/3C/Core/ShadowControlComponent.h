#pragma once
#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "ShadowControlComponent.generated.h"

USTRUCT(BlueprintType)
struct FInsetShadowDisConf 
{
	GENERATED_BODY()
public:
	UPROPERTY(EditAnywhere)
	float Distance = 0;
	
	UPROPERTY(EditAnywhere)
	FVector BoundingLocation = FVector::ZeroVector;
	
	UPROPERTY(EditAnywhere)
	FVector BoundingScale = FVector::ZeroVector;
};

/**
 * Per-Object Shadow技术, 局部高分辨率阴影的场景（如角色面部细节),有性能开销
 * TODO 这块代码看着非常临时，也不适用与目前角色拼装的逻辑，目前功能并没有实装 hujianglong@kuaishou.com
 */
UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class KGCHARACTER_API UShadowControlComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	
	UShadowControlComponent();

	UPROPERTY(BlueprintReadWrite,VisibleAnywhere)
	bool bEnableInsetShadow = false;

	UPROPERTY(EditAnywhere)
	bool bEnableDebugDraw = false;

	FVector LastActorLocation;
	FRotator LastActorRotation;

	UPROPERTY(EditAnywhere)
	bool bEnableBoundConfig = true;
	
	UPROPERTY(EditAnywhere)
	TArray<FInsetShadowDisConf> BoundingConfig;

	UFUNCTION(BlueprintCallable)
	void EnableInsetShadow(bool bEnable);
	
	UFUNCTION(BlueprintCallable)
	void RemoveComponent();
	
protected:
	virtual void BeginPlay() override;
	
	UPROPERTY(BlueprintReadOnly,VisibleAnywhere)
	int CurrentBoundIdx = -1;
	
public:	
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	
};
