#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "Templates/SubclassOf.h"
#include "LuaHelper.generated.h"

UCLASS()
class KGCHARACTER_API ULuaHelper : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	/** 
	 * 生成Object并动态绑定Lua
	 * Outer 拥有者
	 * LuaPath Lua脚本项目资源Script下相对路径
	 * Name Obj名称
	 */
	UFUNCTION(BlueprintCallable, Category = "Lua Helper")
	static UObject* NewObjectWithBindLua(UClass* Class, UObject* Outer, const FString& LuaPath, FName Name = NAME_None);

	UFUNCTION(BlueprintCallable, Category = "Lua Helper")
	static AActor* GetActorByID(int32 UniqueID);

	UFUNCTION(BlueprintCallable)
	static FString GetNewEntityGUID();

	//获取地面高度
	UFUNCTION(BlueprintCallable)
	static bool GetFloorPos(FVector StartPos, FVector EndPos, FVector& OutPos, const UObject* WorldContextObject);

	UFUNCTION(BlueprintCallable)
	static bool GetFloorPosByCapsule(FVector StartPos, FVector EndPos, float Radius, TArray<AActor*>& IgnoreActors, FVector& OutPos, const UObject* WorldContextObject);

	UFUNCTION(BlueprintCallable)
	static void SetRootComponent(AActor* InActor, USceneComponent* RootCom);

	static void ExPropertyDes(FProperty* Prop, const void* AddRess, TArray<FString>& InProps);
	static void ExStructValueStr(UScriptStruct* Struct, const void* AddRess, TArray<FString>& InProps);
	static void ExUObjectValueStr(UObject* InObj, TArray<FString>& InProps);

	UFUNCTION(BlueprintCallable)
	static FString GetUObjectValueStr(UObject* Object);

	UFUNCTION(BlueprintCallable)
	static void RegisterComponent(UActorComponent* InCom);

	UFUNCTION(BlueprintCallable)
	static void UnregisterComponent(UActorComponent* InCom);

	UFUNCTION(BlueprintCallable)
	static void MarkMeshRenderStateDirty(class UMeshComponent* InCom);


	UFUNCTION(BlueprintCallable)
	static void SetActorComponentTickEnabled(AActor* InActor, TSubclassOf<UActorComponent> Class, bool bEnable);

	UFUNCTION(BlueprintCallable)
	static void DestoryChildComponent(USceneComponent* InParentCom, TSubclassOf<USceneComponent> FilterClass);

	UFUNCTION(BlueprintCallable)
	static void ActorTagsAddUnique(AActor* InActor, FName InTag);

	UFUNCTION(BlueprintCallable)
	static void ActorTagsRemoveItem(AActor* InActor, FName InTag);


	UFUNCTION(BlueprintCallable)
	static void SetMeshPositiveBoundsExtension(USkeletalMesh* Mesh, FVector NewPositiveBoundsExtension);
	
	UFUNCTION(BlueprintCallable)
	static void SetMeshNegativeBoundsExtension(USkeletalMesh* InMesh, FVector NewPositiveBoundsExtension);

	UFUNCTION(BlueprintCallable)
	static FString GetObjectUClassName(UObject* Object);


	UFUNCTION(BlueprintCallable)
	static void SetSceneComponentVisibleFlag(USceneComponent* InCom, bool bVisible);


	//Debug
	UFUNCTION(BlueprintCallable)
	static void SetPlayerControllerClass(UGameInstance* InGI, TSubclassOf<class APlayerController> InClass, TSubclassOf<class APawn> InPawn);
};