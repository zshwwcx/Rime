﻿#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "ResizeBoundsScaleComponent.generated.h"


UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class KGCHARACTER_API UResizeBoundsScaleComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	// Sets default values for this component's properties
	UResizeBoundsScaleComponent();

protected:
	// Called when the game starts
	virtual void BeginPlay() override;

	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	
	void InitializeWithSkeletalMeshActor();

	void GetDefaultBoneName();

public:
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UFUNCTION(BlueprintCallable)
	void InitializeParameters(FName InBoneName, float InThreshold);

	void Initialize();

	void Deinitialize();

private:
	UPROPERTY(Transient)
	TWeakObjectPtr<USkeletalMeshComponent> LeaderMeshComponent;

	UPROPERTY(Transient)
	TArray<TWeakObjectPtr<USkeletalMeshComponent>> MeshComponents;

	float OriginalBoundsScale;
	FVector OriginalBoundsExtent;

	FName BoneName;
	float Threshold = 1.0f;
	bool bNeedResetScale = false;
};
