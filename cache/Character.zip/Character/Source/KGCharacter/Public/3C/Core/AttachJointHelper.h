#pragma once

#include "CoreMinimal.h"
#include "3C/Core/AttachJointComponent_V2.h"


/**
 * AttachJointComponent 辅助函数，用于拆分位置计算逻辑
 */

class KGCHARACTER_API AttachJointHelper
{
public:
	//计算旋转位置
	static void DoAutoRotate(const float& RotateRoundTime,const float& CurrenTime,FRotator& OutRotation);
	
	//正常Interp计算位置，当距离大于AttachLagMaxDistance会限制最远距离
	static void DoInterpLag(const FVector& DesiredLocation,const FVector& PreviousInterpLoc,
	const float& DeltaTime ,const float& AttachLagSpeed,const float& AttachLagMaxDistance,FVector& OutInterpLoc,FVector& OutDesiredLocation);
	
	//通过贝塞尔曲线插值计算
	static void DoBezierLag(const FVector& DesiredLocation,const FVector& PreviousDesiredLoc,const FRotator& PreviousDesiredRot, const float& DeltaTime ,const float& BezierStep,
	const float& BezierStepMaxDist,const float & BezierSpeedAlpha,const float& BezierLagSpeed, const float& BezierDirectionMultiplier,const float& LastSpeed ,const FVector LastVelocity,
	const bool& bDoDebugDraw, const UWorld* DebugDrawWorld,	FVector& OutDesiredLocation);

	//限制在圆形范围内进行插值，圆形范围内正常插值，超出范围则限制在圆形边缘
	static void DoRangeInterpLag(const FVector& DesiredLocation,const FVector& CenterLocation, const FVector& LastLagLocation,const float& DeltaTime,
	const float& InCircleLagSpeed,const float& InCircleLagTolerance,
	const bool& bDoDebugDraw, const UWorld* DebugDrawWorld,
	FVector& OutDesiredLocation);
	
	//上下漂浮位移
	static void DoFloat(const FVector& DesiredLocation,  const float& CurrentTime,const float& FloatTime,const float& FloatMinHeight,const float& FloatMaxHeight, const float& FloatEaseExp,
		FVector& OutDesiredLocation);
	
	//正常Interp计算Rotation
	static void DoRotationLag(const FRotator& DesiredRotation, const FRotator& PreviousDesiredRot, const float& DeltaTime, const float& AttachRotationLagSpeed,
	const bool& bClampPitch,const float& PitchClampAngleMin, const float& PitchClampAngleMax, FRotator& OutDesiredRotation);

	//面朝速度方向并且Interp插值
	static void DoFaceToMoveDirRotationLag(const FRotator& DesiredRotation, const FRotator& PreviousDesiredRot,const float& LastSpeed,const FVector& LastVelocity,const float& DeltaTime,
	const float& AttachRotationLagSpeed,const float& FaceToMoveDirectionTolerance,const bool& bClampPitch,const float& PitchClampAngleMin, const float& PitchClampAngleMax, FRotator& OutDesiredRotation);

	
};
