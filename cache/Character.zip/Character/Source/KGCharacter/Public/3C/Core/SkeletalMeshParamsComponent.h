// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/SkeletalMeshComponent.h"

#include "SkeletalMeshParamsComponent.generated.h"

/**
 * 
 */
UCLASS(BlueprintType, Blueprintable, ClassGroup=(Rendering, Common),
	HideCategories=(Object, Variable, Mesh, Physics, Collision, Clothing, Replication,
	Animation, AnimationRig, Deformer, HLOD, Navigation, KExtra, ComponentReplication,
	VirtualTexture, Tags, Activation, Cooking, ComponentTick, Optimization, TextureStreaming,
	Mobile, RayTracing, AssetUserData, LeaderPoseComponent, SkeletalMesh, MaterialParameters,
	LOD, Base, General),
	ShowCategories = (Rendering, Lighting),
	config=Engine, editinlinenew, meta=(BlueprintSpawnableComponent))

class KGCHARACTER_API USkeletalMeshParamsComponent : public USkeletalMeshComponent
{
	GENERATED_BODY()
	
public:
	
	USkeletalMeshParamsComponent(const FObjectInitializer& ObjectInitializer);

	virtual void BeginPlay() override;

	UPROPERTY(BlueprintReadWrite)
	TSet<FString> ModifiedProperties;
	
// #if WITH_EDITOR
// public:
// 	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
// #endif
	
};
