#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Components/CapsuleComponent.h"
#include "LuaOverriderInterface.h"
#include "KGCore/Public/Scene/Components/C7ShapeCollisionComponent.h"
#include "KGCore/Public/Misc/CommonDefines.h"
#include "InteractiveTriggerComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_FourParams(FInteractiveTriggerDetectEnterTrigger, int64, OhterIntUID, const FVector&, Pos, float, TriggerYaw, const FName&, CollisionTag);

DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FInteractiveTriggerDetectLeaveTrigger, int64, OhterIntUID, const FVector&, Pos, const FName&, CollisionTag);

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FInteractiveTriggerDetectIndoorTrigger, bool, bIndoor);

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FInteractiveTriggerDetectPlayerDistanceChanged, int64, OhterIntUID, float, Distance);

struct FDistanceMonitorInfo
{
	
public:
	FDistanceMonitorInfo(float InMaxDistance, AActor* InTargetActor) :
		CurDistance(-1),
		MaxDistance(InMaxDistance),
		bEverOutRange(false),
		TargetActor(InTargetActor)
	{};
	
	float CurDistance = -1.f;
	
	float MaxDistance = 0.f;

	bool bEverOutRange = false;
	
	TWeakObjectPtr<AActor> TargetActor = nullptr; 
};

// 角色在新空气墙玩法中的状态
UENUM(BlueprintType)
enum class ENewAirWallAreaState : uint8
{
	ENAWAS_None = 0					UMETA(DisplayName = "未进入空气墙"),
	ENAWAS_InSoftAirWall			UMETA(DisplayName = "处于软空气墙中"),
	ENAWAS_InForceLeaveArea			UMETA(DisplayName = "处于强制撤离区域"),
	ENAWAS_ForceLeaving				UMETA(DisplayName = "强制寻路离开中"),
	// ENAWAS_HardAirWall			UMETA(DisplayName = "硬空气墙，不可能进来"),
};

// 室内检测盒子的标签
UENUM(BlueprintType)
enum class EIndoorVolumeDetectTag : uint8
{
	Enter = 0,            
	Exit = 1
};

// 室内检测盒子自定义AssetUserData
UCLASS(Blueprintable)
class KGCHARACTER_API UIndoorDetectAssetUserData : public UAssetUserData
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Asset Tags")
	EIndoorVolumeDetectTag AssetTag;  // 用于存储进出门标签
};

USTRUCT(Blueprintable)
struct FInteractiveInDoorDetectParams
{
	GENERATED_USTRUCT_BODY()
	
public:
	UPROPERTY(BlueprintReadWrite)
	bool bEnableIndoorFieldDetect = false;
	
	UPROPERTY(BlueprintReadWrite)
	FName InDoorObjectRootTag;
	
	UPROPERTY(BlueprintReadWrite)
	float IndoorMaxTraceDistance = 0.f; // cm

	UPROPERTY(BlueprintReadWrite)
	bool bIndoor = false;
	
	EObjectTypeQuery IndoorObjectType;
	
	EObjectTypeQuery IndoorTraceObjectType;
};

UENUM(BlueprintType)
enum class ECustomInteractableTransformType : uint8
{
	ActorSpace = 0,
	WorldSpace = 1,
};

USTRUCT(Blueprintable)
struct FCustomInteractableElement
{
	GENERATED_USTRUCT_BODY()
public:
	
	UPROPERTY(BlueprintReadWrite)
	FVector Location;
	
	UPROPERTY(BlueprintReadWrite)
	FQuat Rotation;

	UPROPERTY(BlueprintReadWrite)
	EC7ShapeCollisionType ShapeType = EC7ShapeCollisionType::Box;
	
	UPROPERTY(BlueprintReadWrite)
	FVector ShapeParam; // Box 就是BoxExtent, Sphere 就是X为Radius
	
	UPROPERTY(BlueprintReadWrite)
	int64 BindEntityID = 0;
	
	UPROPERTY(BlueprintReadWrite)
	int32 Token;
	
	UPROPERTY(BlueprintReadWrite)
	bool bEnableInteract = true;
	
	UPROPERTY(BlueprintReadWrite)
	ECustomInteractableTransformType TransformType = ECustomInteractableTransformType::ActorSpace;
};


//碰撞交互触发处理组件
UCLASS(Blueprintable, BlueprintType, ClassGroup = (RoleLogic), meta = (BlueprintSpawnableComponent))
class KGCHARACTER_API UInteractiveTriggerComponent : public UCapsuleComponent
{
	GENERATED_UCLASS_BODY()
	
protected:
	virtual void BeginPlay() override;

	virtual void TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction *ThisTickFunction) override;

	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason)override;

public:
	virtual void ResetToDefaultsForCache() override;

protected:
	//初始自动附加
	void AutoAttachRoot();

	//获取本地摄像机信息
	FORCEINLINE bool GetLocViewInfo(FVector& OutPos);

public:
	//设置Owner的Int UID
	UFUNCTION(BlueprintCallable)
	void SetOwnerIntUID(int64 InOwnerUID);
	
	//调整大小
	UFUNCTION(BlueprintCallable)
	void ResetTriggerSize(float TriggerHalfHeight, float TriggerRadius);

	//添加监听角色最大距离(距离内开启监听并发送距离变动消息)
	UFUNCTION(BlueprintCallable)
	void AddPlayerDistanceMonitor(bool bEnable, float MaxDis = 2000.0f, bool bWithTickCheck=true);

protected:

	UPROPERTY(BlueprintReadOnly)
	float TriggerHalfHeight = 200.0f;

	UPROPERTY(BlueprintReadOnly)
	float TriggerRadius = 500.0f;

	UPROPERTY(BlueprintReadOnly)
	float PlayerDistanceMax = -1.0f;

	UPROPERTY(BlueprintReadOnly)
	TWeakObjectPtr<AActor> OwnerActor = nullptr;

	UPROPERTY(BlueprintReadWrite)
	float OwnerCapsuleHalfHeight = 180.0f;
	UPROPERTY(BlueprintReadWrite)
	float OwnerCapsuleRadius = 30.0f;

	UPROPERTY(BlueprintReadOnly)
	int64 OwnerIntUID = 0;

	// sweep检测的开关
	UPROPERTY(BlueprintReadWrite)
	bool bEnableSweepDetect = false;

	UPROPERTY(BlueprintReadWrite)
	FVector LastDetectLocation;
	
	UPROPERTY(BlueprintReadWrite)
	bool bLastDetectLocationSet;
	
	UPROPERTY(BlueprintReadWrite)
	float MaxSpeedPerSeconds = 1200.0f; // cm/s

	UPROPERTY(BlueprintReadWrite)
	FInteractiveInDoorDetectParams IndoorDetectParams;

protected:
	TMap<int64, TWeakObjectPtr<AActor>> OverLapActorMap;
	TMap<int64, TWeakObjectPtr<AActor>> EnterScopeActorMap;
public:
	// 设置为主动探测者
	UFUNCTION(BlueprintCallable)
	void InitAsDetect(int64 InOwnerUID,
		float TickInterval,
		TArray<int32> InDetectObjectTypes,
		TArray<int32> InLineTraceObjectTypes
		);

	// 开启、激活探测
	UFUNCTION(BlueprintCallable)
	void EnableInterActiveForDetect(bool bEnable);
	
	// 监听探测距离变化
	UFUNCTION(BlueprintCallable)
	void RegisterDetectDistanceMonitor(int64 InOwnerUID, float MaxDistance);

	// 取消监听探测距离变化
	UFUNCTION(BlueprintCallable)
	void UnRegisterDetectDistanceMonitor(int64 InOwnerUID);

	// 查询entity是否在触发圈内
	UFUNCTION(BlueprintCallable)
	bool IsEntityEnteredScope(int64 InUID);
	
	// 开启sweep监测
	UFUNCTION(BlueprintCallable)
	void EnableSweepDetect(bool bInEnable, float InMaxSpeedPerSeconds);
	
	UFUNCTION(BlueprintCallable)
	void ClearDetectState();

	// 室内探测
	UFUNCTION(BlueprintCallable)
	void EnableIndoorFiledDetect(bool bInEnable, EObjectTypeQuery InIndoorQueryObjectType, EObjectTypeQuery InIndoorTraceObjectType, FName InInDoorObjectRootTag, float InIndoorMaxTraceDistance);
	
	UPROPERTY(BlueprintAssignable)
	FInteractiveTriggerDetectEnterTrigger DetectEnterTrigger_MD;

	UPROPERTY(BlueprintAssignable)
	FInteractiveTriggerDetectLeaveTrigger DetectLeaveTrigger_MD;
	
	UPROPERTY(BlueprintAssignable)
	FInteractiveTriggerDetectPlayerDistanceChanged DetectPlayerDistanceChanged_MD;

	UPROPERTY(BlueprintAssignable)
	FInteractiveTriggerDetectIndoorTrigger DetectIndoorChanged_MD;

protected:
	void CheckDetectDistanceMonitor();
	
	void CheckDetectInteractable();

	void CheckDetectIndoorFiled();

	void DoInteractableComponentsDetection(const float& DeltaTime);
	
	bool CheckEnterCustomScope(AActor* Actor, UPrimitiveComponent* InteractableComponent);

	bool IsBlockedAlongLineForDetect(AActor* Other, const FVector& StartPos, const FVector& EndPos);
	
	bool IsIndoorFieldEntry(UActorComponent* InComponent, EIndoorVolumeDetectTag& OutDetectTag) const;

	bool IsIndoorFieldObject(UPrimitiveComponent* InComponent) const;

	bool GetLastIndoorFiledLocation(const TArray<FHitResult>& HitResults, FVector& ImpactLocation);

	bool DetermineIndoorFieldByLineTrace();

private:
	TMap<KGEntityID, FDistanceMonitorInfo> DetectDistanceMonitors;
	
	TArray<TEnumAsByte<EObjectTypeQuery>> DetectObjectTypes;
	
	TArray<TEnumAsByte<EObjectTypeQuery>> LineTraceObjectTypes;

	TArray<FHitResult> DetectedInteractableHitResults;

	FVector DetectedInteractablePos = FVector::ZeroVector;

	bool bCurFrameUseSweepDetect = false;

#pragma region TickControl
public:
	void UpdateComponentTickEnabled() { SetComponentTickEnabled(bEnableInterActiveForDetect || bAllowNewAirWallLogic || bPlayerDistanceMonitorWithTickCheck || !DetectDistanceMonitors.IsEmpty()); }
private:
	// InterActiveForDetect是否开启
	bool bEnableInterActiveForDetect = false;
	// 新空气墙逻辑是否生效
	bool bAllowNewAirWallLogic = false;
	// PlayerDistanceMonitor是否开启Tick
	bool bPlayerDistanceMonitorWithTickCheck = false;
#pragma endregion TickControl

#pragma region CustomInteractive
	
public:
	void CheckDetectCustomInteractable();

	bool CheckElementIntersect(class UKGUEActorManager* ActorManager, const FCustomInteractableElement& Element, const FVector& DetectPos, bool& OutElementValid) const;

	void RegisterSingleInteractableElement(const FCustomInteractableElement& Element);

	void RegisterSphereInteractableElement(float X, float Y, float Z, float Radius, int64 EntityID, int32 Token, ECustomInteractableTransformType TransformType);

	void RegisterBoxInteractableElement(float X, float Y, float Z, float Yaw, float BoxExtentX, float BoxExtentY, float BoxExtentZ, int64 EntityID, int32 Token, ECustomInteractableTransformType TransformType);
	
	void UnRegisterSingleInteractableElement(int32 ElementToken);

	void EnableInteractiveForElement(int32 ElementToken, bool bEnable);
	
	void NotifyInteractableElementEnterOrLeave(const int32& Token, bool bEnter);

#if UE_BUILD_DEVELOPMENT
public:
	void SetDebugDrawCustomInteractable(bool bInDraw) { bDebugDrawCustomInteractable = bInDraw; }
private:
	bool bDebugDrawCustomInteractable = false;
#endif
	
private:
	
	// 自定义探测元素
	TMap<int32, FCustomInteractableElement> CustomElementsByToken;

	// 当前在范围里的自定义探测元素
	TSet<int32> InRangeElementsByToken;
	
#pragma endregion CustomInteractive


#pragma region NewAirWall
public:
	void SetAllowNewAirWallLogic(bool InAllow);
	void SetNewAirWallInfos(const FName& InSoftAirWallTag, const FName& InForceLeaveAreaTag, const FName& InHardAirWallTag, const FName& InForceLeaveSplineTag,
		const float& InSoftAirWallMaxDuration, const float& InForceLeaveAreaMaxDuration, const FString& InScreenNiagaraPath, 
		const float& InNiagaraBlendInDuration, const float& InNiagaraBlendOutDuration, const FName& InScreenNiagaraAlphaParamName)
	{
		SoftAirWallTag = InSoftAirWallTag; ForceLeaveAreaTag = InForceLeaveAreaTag; HardAirWallTag = InHardAirWallTag; ForceLeaveSplineTag = InForceLeaveSplineTag;
		SoftAirWallMaxDuration = InSoftAirWallMaxDuration; ForceLeaveAreaMaxDuration = InForceLeaveAreaMaxDuration;
		NewAirWallScreenNiagaraPath = InScreenNiagaraPath; ScreenNiagaraBlendInDuration = FMath::Max(InNiagaraBlendInDuration, 0.01f);
		ScreenNiagaraBlendOutDuration = FMath::Max(InNiagaraBlendOutDuration, 0.01f); ScreenNiagaraAlphaParamName = InScreenNiagaraAlphaParamName;
	}

	void StartForceLeaving();
	void StopForceLeaving();

	bool GetHasValidLeavingAreaTargetLoc() { return bHasValidLeavingAreaTargetLoc; }
	FVector GetLeavingAreaTargetLoc() { return LeavingAreaTargetLoc; }

	bool FindNearestNavLoc(const FVector& InLoc, const FVector& InExtent, FVector& OutLoc) const;
private:
	void UpdateNewAirWallData(const float& InDeltaTime);

	void CheckDetectedInteractableHitResultsForAirWall(bool InNeedCalculateLeavingAreaTargetLoc, bool& OutbInSoftAirWall, bool& OutbInForceLeaveArea);

	void SetCurAirWallAreaState(ENewAirWallAreaState InNewAirWallAreaState);
	void ActivateScreenNiagara(float InBlendDuration);
	void DeActivateScreenNiagara();
	void SetTargetScreenNiagaraBlendTime(float InTime, float InBlendDuration);
	void StopScreenNiagaraBlend();

	void SetTimerToDeActivateScreenNiagara();

	bool CalculateLeavingAreaTargetLocBySpline(const FHitResult& InHitRes);
	void CalculateLeavingAreaTargetLocInForceLeaveArea(const FHitResult& InHitRes);
	void CalculateLeavingAreaTargetLocInSoftAirWall(const FHitResult& InHitRes);
	bool InnerCalculateLeavingAreaTargetLocInSoftAirWall(const FHitResult& InHitRes, const FVector& InWallVerticleNormal2D, const FVector& InSoftWallCenterWithActorHeight, const float& InDetectLength);
	bool SetOnGroundLeavingAreaTargetLoc(const FVector& InLeavingAreaTargetLoc);
private:
	// 软空气墙的Tag
	FName SoftAirWallTag = TEXT("SoftAirWall");
	// 强制撤离区域的Tag
	FName ForceLeaveAreaTag = TEXT("ForceLeaveArea");
	// 硬空气墙的Tag
	FName HardAirWallTag = TEXT("HardAirWall");
	// 撤离点曲线的Tag
	FName ForceLeaveSplineTag = TEXT("EvacuateLine");

	// 允许在软空气墙内的最多时间（超出该时间后触发寻路离开）
	float SoftAirWallMaxDuration = 5.0f;
	// 允许在强制撤离区域内的最多时间（超出该时间后触发寻路离开）
	float ForceLeaveAreaMaxDuration = 1.0f;
	
	// 进入软硬空气墙的特效路径
	FString NewAirWallScreenNiagaraPath = TEXT("");
	FName ScreenNiagaraAlphaParamName = TEXT("");
	int32 ScreenNiagaraID = -1;
	
	// 清除ScreenNiagara的Timer
	FTimerHandle ScreenNiagaraDeleteTimeHandle;

	// 特效Alpha过渡时间
	float ScreenNiagaraBlendInDuration = 1.0f;	// 不在用了，待删除
	float ScreenNiagaraBlendOutDuration = 1.0f;

	// 当前的空气墙状态
	ENewAirWallAreaState CurAirWallAreaState = ENewAirWallAreaState::ENAWAS_None;
	// 强制寻路离开的计时
	float SoftAirWallForceLeaveCountDuration = 0.0f;
	float ForceLeaveAreaForceLeaveCountDuration = 0.0f;

	// 是否已有有效的撤离目标点
	bool bHasValidLeavingAreaTargetLoc = false;
	// 强制撤离区域的撤离目标（临时使用）
	FVector LeavingAreaTargetLoc = FVector::ZeroVector;

#if UE_BUILD_DEVELOPMENT
private:
	bool bNeedShowNewAirWallDebugInfo = false;
public:
	void SetNeedShowNewAirWallDebugInfo(bool bInNeed) { bNeedShowNewAirWallDebugInfo = bInNeed; }
#endif

#pragma endregion NewAirWall
};
