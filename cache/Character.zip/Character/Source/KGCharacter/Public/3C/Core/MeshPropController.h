#pragma once

#include "CoreMinimal.h"
#include "Misc/CommonDefines.h"
#include "UObject/WeakInterfacePtr.h"
#include "Engine/TimerHandle.h"

/**
 * 一些mesh属性可能就会同时被多块业务修改, 需要一个冲突控制结构来统一处理这些mesh属性的修改请求
 * 对于角色来说, 可能存在mesh component新增、删除和asset切换的情况, 而对于外部使用者来说, 基本都是修改当前角色身上所有mesh的属性,
 * 这里希望能够在内部处理掉mesh变化时, mesh属性继承的问题
 * 当前由于cpp层也需要修改mesh属性, 因此相关逻辑全部在cpp层处理掉
 */

class ICppEntityInterface;
class UMeshComponent;
class AActor;

#define KG_INVALID_CUSTOM_DEPTH_PRIORITY_TYPE (-1)

struct FKGCustomDepthInfo
{
	FKGCustomDepthInfo(bool bInRenderCustomDepth, int32 InCustomDepthStencilValue, bool bInNiagaraRenderCustomDepth)
		: bRenderCustomDepth(bInRenderCustomDepth), CustomDepthStencilValue(InCustomDepthStencilValue), bNiagaraRenderCustomDepth(bInNiagaraRenderCustomDepth) {}
	
	bool bRenderCustomDepth = false;
	int32 CustomDepthStencilValue = 0;
	bool bNiagaraRenderCustomDepth = true;
};

struct FKGCustomDepthPriorityItem
{
	FKGCustomDepthPriorityItem(
		bool bInRenderCustomDepth, int32 InCustomDepthStencilValue, bool bInNiagaraRenderCustomDepth, int32 InLogicType, int32 InPriority, int32 InSequenceID,
		bool bInAutoRevert, float InAutoRevertTimeSeconds, bool bInInherited)
		: CustomDepthInfo(bInRenderCustomDepth, InCustomDepthStencilValue, bInNiagaraRenderCustomDepth),
			LogicType(InLogicType), Priority(InPriority), SequenceID(InSequenceID), bAutoRevert(bInAutoRevert),
			AutoRevertTimeSeconds(InAutoRevertTimeSeconds), bInherited(bInInherited) {}
	
	FKGCustomDepthInfo CustomDepthInfo;
	int32 LogicType = KG_INVALID_CUSTOM_DEPTH_PRIORITY_TYPE;
	int32 Priority = 0;
	uint32 SequenceID = 0;
	bool bAutoRevert = false;
	float AutoRevertTimeSeconds = 0.0f;
	bool bInherited = false;

	bool operator==(const FKGCustomDepthPriorityItem& Other) const
	{
		return LogicType == Other.LogicType;
	}
	
	bool operator<(const FKGCustomDepthPriorityItem& Other) const
	{
		return Priority == Other.Priority ?
			SequenceID > Other.SequenceID :
			Priority > Other.Priority;
	}
};

struct FKGCustomDepthPriorityQueue
{
	void BindActor(AActor* InActor, ICppEntityInterface* InBindEntity);
	void UnBindActor();
	
	void SetCustomDepthInfo(
		int32 LogicType, int32 Priority, bool bRenderCustomDepth, int32 CustomDepthStencilValue, bool bNiagaraRenderCustomDepth,
		bool bAutoRevert, float AutoRevertTimeSeconds, bool bInherited = false);
	void RemoveCustomDepthInfo(int32 LogicType);
	int32 GetActiveLogicType() { return Items.Num() > 0 ? Items[0].LogicType : KG_INVALID_CUSTOM_DEPTH_PRIORITY_TYPE; }

	void SyncCustomDepthInfo(const FKGCustomDepthPriorityQueue& OtherCustomDepthPriorityQueue);
	void RefreshAttachEntityCustomDepthInfo();
	
	void RefreshMeshCustomDepthInfo(const FKGCustomDepthInfo& CustomDepthInfo);
	void RefreshMeshOriginalCustomDepthInfo();
	void RevertMeshCustomDepthInfo();
	void RefreshOnMeshComponentChanged();
	
	void AddAutoRevertTimer(int32 LogicType, float AutoRevertTimeSeconds);
	void ClearAutoRevertTimer(int32 LogicType);
	void OnAutoRevertTimeExpired(int32 LogicType);
	
	TArray<FKGCustomDepthPriorityItem> Items;
	TMap<TWeakObjectPtr<UMeshComponent>, FKGCustomDepthInfo> OriginalCustomDepthInfo;
	TWeakObjectPtr<AActor> Actor;
	KGActorID ActorID = KG_INVALID_ACTOR_ID;
	
	// 这里用bind world的问题在于, 当前如果说entity关联的actor被销毁且未走脚本的控制逻辑(比如通过UKGUEActorManager::OnActorDestoryByUE返回)
	// 此时新增的timer就不会被清理, 会导致崩溃问题
	TWeakObjectPtr<UWorld> BindWorld;
	TWeakInterfacePtr<ICppEntityInterface> BindEntity;
	TMap<int32, FTimerHandle> AutoRevertTimerHandles;
};

struct KGCHARACTER_API FKGMeshPropController
{
	void OverrideCustomDepth(
		int32 LogicType, int32 Priority, bool bRenderCustomDepth, int32 CustomDepthStencilValue, bool bNiagaraRenderCustomDepth,
		bool bAutoRevert, float AutoRevertTimeSeconds);
	void RevertCustomDepth(int32 LogicType);
	bool GetCurrentActiveCustomDepthInfo(bool& bOutRenderCustomDepth, int32& OutCustomDepthStencilValue, bool& bOutNiagaraRenderCustomDepth);
	void SyncCustomDepthInfo(const FKGMeshPropController& OtherController);

	void BindActor(AActor* InActor, ICppEntityInterface* InBindEntity);
	void UnBindActor();
	void OnMeshComponentChanged();

	// custom depth
	FKGCustomDepthPriorityQueue CustomDepthPriorityQueue;
};

