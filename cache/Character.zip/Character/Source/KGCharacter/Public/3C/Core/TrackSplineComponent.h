// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "LuaOverriderInterface.h"
#include "Components/SplineComponent.h"
#include "TrackSplineComponent.generated.h"


UCLASS(BlueprintType, Blueprintable, meta = (BlueprintSpawnableComponent))
class KGCHARACTER_API UTrackSplineComponent : public USplineComponent
		, public ILuaOverriderInterface
{
	GENERATED_BODY()

public:
	virtual FString GetLuaFilePath_Implementation() const override { return TEXT("Gameplay.3C.Core.TrackSplineComponent"); };
	
	// UActorComponent interface
	virtual void OnRegister() override;

	virtual void OnComponentDestroyed(bool bDestroyingHierarchy) override;

protected:
	// 开启/禁止轨迹
	UFUNCTION(BlueprintCallable)
	virtual void SetTrackEnabled(bool bEnabled);

	// 以路径点更新轨迹接口
	UFUNCTION(BlueprintCallable)
	void UpdateTrackByPath(TArray<FVector> &Points, bool bForceUpdate=false);
	
	bool IsSameStartAndEnd(const FVector &StartPos, const FVector &EndPos);
	
	// Called when the game starts
	virtual void BeginPlay() override;

private:
	// 刷新激活态
	void RefreshTrackEnable();

	// 实际更新路径的实现
	void DoUpdateTrack(TArray<FVector> &Points);

	// 尝试限制路径长度 
	void TryCutPath(TArray<FVector> &Points, TArray<FVector> &CutPoints);

	// 判断路径是否和当前缓存路径相同
	bool IsSameTrackFromCached(TArray<FVector> &Points);

	// 更新缓存的路径
	void CacheCurPath(TArray<FVector> &Path);
	
public:
	// 粒子路径
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Design")
	FString NiagaraFilePath;
	
	// 最大追踪距离
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Design")
	int LostTrackDistance = 100;
	
	// 距离误差
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Design")
	float PosOffsetErrorSquared = 25.0f;
	
	// 最大显示长度
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Design")
	float PathMaxLength = 12000.0;

	// 路径是否激活
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	bool bIsTrackEnabled = false;

private:
	// 当前路径点缓存
	TArray<FVector> CachedTrackPath;
		
};
