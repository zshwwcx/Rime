#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Engine/EngineTypes.h"
#include "Components/SceneComponent.h"
#include "AttachFloatComponent.generated.h"

/**
 * 相机摇臂
 * 对USpringArmComponent改造 部分逻辑后续改造成Lua
 */

UCLASS(meta=(BlueprintSpawnableComponent), hideCategories=(Mobility))
class KGCHARACTER_API UAttachFloatComponent : public USceneComponent
{
	GENERATED_UCLASS_BODY()
	
	// UActorComponent interface
	virtual void OnRegister() override;
	virtual void TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	virtual void PostLoad() override;
	// End of UActorComponent interface

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector OriginLoc = FVector::ZeroVector;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float MaxDeltaHeight = 200;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float FloatTime = 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float EaseExp = 3;

	UPROPERTY(Transient)
	float CurTime = 1;
	
	UPROPERTY(Transient)
	float CurrentDelta = 1;

	UPROPERTY(Transient)
	float CurDir = 1;

	UPROPERTY(Transient)
	bool bCurIsUpward = 1;


};
