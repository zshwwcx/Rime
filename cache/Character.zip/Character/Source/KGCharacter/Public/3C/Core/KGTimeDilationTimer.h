﻿#pragma once
#include "TimerManager.h"

#include "KGTimeDilationTimer.generated.h"

/*
 * 对于一些单位的生命周期计时, 通常使用UE自身的计时器系统(FTimerManager)
 * 当触发完美闪避时停效果时, 一些单位的播放速率可能需要频繁修改变化, 这会影响UE计时器的运行
 * 完美闪避目前投放的应用场景比较少, 出于性能考虑, 正常情况下还是使用UE计时器系统, 等到完美闪避触发时, 支持相应的计时
 * 考虑单位自身的CustomTimeDilation(改为Tick计时)
 * 这里封装一个统一的数据结构方便不同业务模块共用, 提供了两种模式
 * 1, 使用UE计时器系统, 这种模式下不受时间膨胀影响, 性能更好
 * 2, 使用Tick计时, 这种模式下会受时间膨胀影响, 仅在特定场景下使用(例如完美闪避)
 */

enum class EKGTimeDilationTimerState : uint8
{
	UnInit = 0,
	UseTimerManager = 1,
	UseTimeDilationTick = 2,
};

USTRUCT()
struct FKGTimeDilationTimer
{
	GENERATED_BODY()

	void SetOwnerActor(TWeakObjectPtr<AActor> InOwnerActor);
	
	void InitOnceTimer(float InRateSeconds, const FTimerDelegate& InTimerDelegate, bool bUseTimerManager);
	void ClearTimer();

	void ChangeTimerMode(bool bUseTimeDilation);
	void UpdateTickTimer(float DeltaTimeSeconds);

	EKGTimeDilationTimerState TimerState = EKGTimeDilationTimerState::UnInit;
	
	float AccumulatedTimeSeconds = 0.0f;
	float TimerDelayTime = 0.0f;
	double TimerInitTimeSeconds = 0.0;
	FTimerDelegate TimerDelegate;
	FTimerHandle TimerHandle;

	TWeakObjectPtr<UWorld> OwnerWorld;
	TWeakObjectPtr<AActor> OwnerActor;
};
