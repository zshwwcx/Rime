#pragma once

#include "CoreMinimal.h"
#include "Engine/HitResult.h"
#include "3CCommon.generated.h"

//速度阶段
UENUM(BlueprintType, Blueprintable)
enum class ESpeedStage : uint8
{
	Idle UMETA(DisplayName = "Idle"),
	Walk UMETA(DisplayName = "Walk"),
	Run UMETA(DisplayName = "Run"),
	Sprint UMETA(DisplayName = "Sprint"),
};


//角色ID配置标签
USTRUCT(BlueprintType)
struct KGCHARACTER_API FRoleConfigID
{
	GENERATED_BODY()

public:
	FRoleConfigID()
		:Count(1)
	{};

	FRoleConfigID(FString InID)
		:ConfigID(InID),
		Count(1)
	{};

	FORCEINLINE bool operator==(const FRoleConfigID& Other)
	{
		return Other.GetID() == ConfigID;
	}

	friend inline bool operator==(const FRoleConfigID& A, const FRoleConfigID& B)
	{
		return A.ConfigID == B.ConfigID;
	}

	friend inline uint32 GetTypeHash(const FRoleConfigID& Key)
	{
		uint32 Hash = 0;

		Hash = HashCombine(Hash, GetTypeHash(Key.ConfigID));
		return Hash;
	}

public:
	FString GetID()const { return ConfigID; }

	FName GetNameID() const { return FName(ConfigID); }

public:
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "GPNoneExport", meta=(IgnoreExport))
	FString RoleType;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FString ConfigID;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "GPNoneExport", meta=(IgnoreExport))
	FString ConfigIDDes;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	int Count;
};

USTRUCT(BlueprintType)
struct KGCHARACTER_API FC7HitResult
{
	GENERATED_BODY()

	UPROPERTY()
	bool bResult = false;

	UPROPERTY()
	FHitResult HitResult;

	UPROPERTY()
	int64 PhysMaterialId = 0;
	UPROPERTY()
	int64 HitObjectId = 0;
	UPROPERTY()
	int64 ComponentId = 0;
};

USTRUCT(BlueprintType)
struct KGCHARACTER_API FC7HitResults
{
	GENERATED_BODY()

	UPROPERTY()
	bool bResult = false;

	UPROPERTY()
	TArray<FHitResult> HitResults;
	
	UPROPERTY()
	TArray<FC7HitResult> C7HitResults;
};

USTRUCT(BlueprintType)
struct KGCHARACTER_API FC7Vectors
{
	GENERATED_BODY()

	UPROPERTY()
	TArray<FVector> Vectors;
};

USTRUCT(BlueprintType)
struct KGCHARACTER_API FCardScroll_KeyTransform
{
	GENERATED_BODY()

	UPROPERTY()
	float CurveValue = 0;

	UPROPERTY()
	FTransform Transform;
};

// 技能释放方式
UENUM(BlueprintType)
enum class EBSASkillReleaseType : uint8
{
	SRT_Normal               = 0               UMETA(DisplayName = "普通"),
	SRT_Loop                                   UMETA(DisplayName = "循环"),
	SRT_Charge                                 UMETA(DisplayName = "蓄力"),
	SRT_Aim                                    UMETA(DisplayName = "瞄准"),

	SRT_BackUp01							   UMETA(Hidden),
	SRT_BackUp02							   UMETA(Hidden),
	SRT_BackUp03                               UMETA(Hidden),
	SRT_BackUp04                               UMETA(Hidden),
	SRT_BackUp05                               UMETA(Hidden),
	SRT_BackUp06                               UMETA(Hidden),
	SRT_BackUp07                               UMETA(Hidden),
	SRT_BackUp08                               UMETA(Hidden),
	SRT_BackUp09                               UMETA(Hidden),
	SRT_BackUp10                               UMETA(Hidden),
	SRT_BackUp11                               UMETA(Hidden),

	SRT_TMax                                   UMETA(Hidden)
};

// 技能瞄准方式
UENUM(BlueprintType)
enum class EBSASkillAimType : uint8
{
	SAT_Location               = 0               UMETA(DisplayName = "瞄准地点"),
	SAT_Direction                                UMETA(DisplayName = "瞄准方向"),

	SAT_BackUp01								 UMETA(Hidden),
	SAT_BackUp02								 UMETA(Hidden),
	SAT_BackUp03                                 UMETA(Hidden),
	SAT_BackUp04                                 UMETA(Hidden),
	SAT_BackUp05                                 UMETA(Hidden),
	SAT_BackUp06                                 UMETA(Hidden),
	SAT_BackUp07                                 UMETA(Hidden),
	SAT_BackUp08                                 UMETA(Hidden),
	SAT_BackUp09                                 UMETA(Hidden),
	SAT_BackUp10                                 UMETA(Hidden),
	SAT_BackUp11                                 UMETA(Hidden),
	SAT_BackUp12                                 UMETA(Hidden),
	SAT_BackUp13                                 UMETA(Hidden),

	SAT_TMax                                     UMETA(DisplayName = "无效选项")
};

// 技能预警形状
UENUM(BlueprintType)
enum class EBSASkillForewarned : uint8
{
	SF_Circle               = 0               UMETA(DisplayName = "圆形"),
	SF_Rectangle                              UMETA(DisplayName = "矩形1"),
	SF_Fan                                    UMETA(DisplayName = "扇形"),
	SF_Rectangle2                             UMETA(DisplayName = "矩形2"),
	SF_IsometricCircle							      UMETA(DisplayName = "指定距离的圆形"),
	
	SF_BackUp01                                UMETA(Hidden),
	SF_BackUp02                                UMETA(Hidden),
	SF_BackUp03                                UMETA(Hidden),
	SF_BackUp04                                UMETA(Hidden),
	SF_BackUp05                                UMETA(Hidden),
	SF_BackUp06                                UMETA(Hidden),
	SF_BackUp07                                UMETA(Hidden),
	SF_BackUp08                                UMETA(Hidden),
	SF_BackUp09                                UMETA(Hidden),
	SF_BackUp10                                UMETA(Hidden),

	SF_TMax                                   UMETA(DisplayName = "无效选项")
};