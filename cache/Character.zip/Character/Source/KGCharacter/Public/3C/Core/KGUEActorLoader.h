#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Templates/SharedPointer.h"
#include "Engine/World.h"
#include "Engine/StreamableManager.h"
#include "KGCore/Public/Misc/CommonDefines.h"

#include "KGUEActorLoader.generated.h"

using KGActorBuildID = int64;

struct UEActorLoadData
{
	FTransform Transform;
	TWeakPtr<FStreamableHandle> LoadHandle;
	KGActorBuildID BuildTaskID = 0;
	KGEntityID EntityID = 0;
	KGActorClassType ClassType = 0;
	// 生成优先级
	int32 Priority = 0;
	// 直接添加到缓存池中
	bool bAddToActorPool = false;
	// 是否强制同步加载
	bool bSyncLoad = false;
	bool bFree = false;
};

UCLASS()
class UKGUEActorLoader : public UObject
{
    GENERATED_BODY()
public:
    UKGUEActorLoader();

    void Init(class UKGUEActorManager* InManager);
	void AddLoadTask(KGEntityID EntID, const FString& ClassPath, const FTransform& Transform, bool Preload,
		bool SyncLoad);

    void CancelLoadTask(KGEntityID EntID);
	
    void Tick(float DeltaTime);
	
	void ProcessClassLoadingQueue(float DeltaTime);

	void ProcessActorSpawningQueue(float DeltaTime);

    void SetSpawnActorWorld(UWorld* InWorld) { OverrideWorld = InWorld; };

    void ClearClassMap();
	
	void EnableFrameLimit(bool Enable) { bEnableFrameLimit = Enable;};

	bool IsEnableFrameLimit() const { return bEnableFrameLimit;};

	void SetFrameLimitParam(float LoadTimeBudget, float SpawnTimeBudget, int32 MaxActorsToSpawn, int32 MinActorsToSpawn)
	{
		ClassLoadTimeBudgetPerFrame = LoadTimeBudget;
		SpawnTimeBudgetPerFrame = SpawnTimeBudget;
		MaxActorsToSpawnPerFrame = MaxActorsToSpawn;
		MinActorsToSpawnPerFrame = MinActorsToSpawn;
	};

#pragma region BuildActorTask
private:
	KGActorClassType GetClassType(const FString& ClassPath);
	const FString* GetClassPath(KGActorClassType ClassType);
	UClass* GetClassFromType(KGActorClassType ClassType);

    void RemoveBuildTask(KGActorBuildID BuildTaskID);
	UEActorLoadData& GetFreeBuildTaskData();
	//void ReleaseBuildTaskData(KGActorBuildID BuildTaskID);
	const UEActorLoadData* GetBuildTaskData(KGActorBuildID BuildTaskID);

	TMap<FString, KGActorClassType> ClassTypeMap;
	TMap<KGActorClassType, FString> ClassPathMap;

	TMap<KGActorBuildID, UEActorLoadData> ActorLoadDataMap;
	TArray<KGActorBuildID> ActorBuildFreeIDs;
	TArray<KGActorBuildID> ActorLoadClassQueue;
	TArray<KGActorBuildID> ActorSpawnQueue;
	TArray<KGActorBuildID> CurActorSpawnQueue;
#pragma endregion BuildActorTask

#pragma region Spawn

	void LoadClassAsset(UEActorLoadData& BuildData);
	void OnClassAssetLoaded(FSoftObjectPath ClassObjPath, KGActorBuildID BuildTaskID);
	void AddSpawnQueue(KGActorBuildID BuildTaskID);
	void SpawnActor(KGActorBuildID BuildTaskID);
#pragma endregion Spawn

protected:
	UPROPERTY(BlueprintReadWrite, Transient)
	TMap<int32, UClass*> ClassMap;

private:
	friend UKGUEActorManager;
    TWeakObjectPtr<class UWorld> OverrideWorld;
    UWorld* GetSpawnActorWorld();
    TWeakObjectPtr<class UKGUEActorManager> ActorManager = nullptr;

private:
	bool bEnableFrameLimit = false;
	float ClassLoadTimeBudgetPerFrame = 0.005f; // 5ms default
	float SpawnTimeBudgetPerFrame = 0.01f; // 10ms default
	int32 MaxActorsToSpawnPerFrame = 20;
	int32 MinActorsToSpawnPerFrame = 3;
};