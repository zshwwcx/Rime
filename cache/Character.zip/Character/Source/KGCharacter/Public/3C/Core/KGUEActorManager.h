#pragma once

#include "CoreMinimal.h"
#include "Tickable.h"
#include "LuaOverriderInterface.h"
#include "Manager/KGBasicManager.h"
#include "GameFramework/Actor.h"

#include "Engine/World.h"
#include "Misc/CommonDefines.h"
#include "3C/Core/KGUEActorLoader.h"
#include "slua.h"
#include "ICppEntity.h"
#include "Containers/LruCache.h"

#include "KGUEActorManager.generated.h"

DECLARE_MULTICAST_DELEGATE_TwoParams(FKGOnActorLoaded, KGEntityID, AActor*);

#define CPP_ENTITY_POOL_INIT_SIZE 512

class ABaseCharacter;

UCLASS(Blueprintable, BlueprintType)
class KGCHARACTER_API UKGUEActorManager : public UKGBasicManager
{
	GENERATED_BODY()

public:
	UKGUEActorManager() {}

	static UKGUEActorManager* GetInstance(UObject* InContext);

	// Begin UKGBasicManager Interface.
	virtual void NativeInit() override;
	virtual void NativeUninit() override;
	virtual EManagerType GetManagerType() { return EManagerType::EMT_UEActorManager; }
	// End UKGBasicManager Interface.
	
	virtual void Tick(float DeltaTime) override;
	virtual void OnPostLoadMapWithWorld(UWorld* World) override;

	UFUNCTION(BlueprintCallable)
	void NativeTick(float DeltaTime) { Tick(DeltaTime); }

	void EnableFrameLimit(bool Enable);

	void SetFrameLimitParam(float LoadTimeBudget, float SpawnTimeBudget, int32 MaxActorsToSpawn, int32 MinActorsToSpawn);

public:
	UWorld* GetSpawnActorWorld();
	void OnActorLoaded(KGEntityID EntID, AActor* InActor, bool CachedUEActor = false);
	UFUNCTION()
	void OnActorDestoryByUE(AActor* DestroyedActor);
	
	/** LevelSpawnedActor在销毁和解绑之前, 可能需要在Lua中先进行清理 */
	UFUNCTION()
	void NotifyLevelSpawnedActorDestroyedByUE(AActor* Actor);

	bool IsLuaEntityExist(KGEntityID InEntID);
	ICppEntityInterface* GetLuaEntity(KGEntityID InEntID);
	ICppEntityInterface* GetLuaEntityByActorID(KGActorID ActorID);
	KGEntityID GetLuaEntityIDByActorID(KGActorID ActorID);
	static ICppEntityInterface* GetLuaEntity(UObject* InContext, KGEntityID InEntID);
	static ICppEntityInterface* GetLuaEntityByActor(AActor* Actor);
	static KGEntityID GetLuaEntityIDByActor(AActor* Actor);
	
	void ClearLoaderClassMap();
	const FActorSpawnParameters& GetActorSpawnParameters() const { return SpawnActorParameters; }

	FKGOnActorLoaded& GetOnActorLoadedDelegate() { return OnActorLoadedDelegate; }

	KGActorID GetActorIDByEntityID(KGEntityID InEntID);
	AActor* GetActorByEntityID(KGEntityID InActorID);
#pragma region LuaApi
public:
	int CreateActorAndCppEntity(lua_State* L);
	int DestroyActorAndCppEntity(lua_State* L);

	int CreateCppEntityForBindActorLater(lua_State* L);

	int CreateActorBindedToExistedCppEntity(lua_State* L);
	int UnbindAndDestroyActor(lua_State* L);

	int BindLevelSpawnedActorWithCppEntity(lua_State* L);
	int CreateCppEntityAndBindLevelSpawnedActor(lua_State* L);
	int UnbindLevelSpawnedActorAndDestroyCppEntity(lua_State* L);
	int UnbindLevelSpawnedActor(lua_State* L);
	
	int CreateActorWithBPClassAndBindToExistedCppEntity(lua_State* L);
	int CreateActorWithBPClassIDAndBindToExistedCppEntity(lua_State* L);

	int SpawnActorAndCppEntity(lua_State* L);

	void SetCppEntityPoolSize(int32 InSize);

	KGObjectID KAPI_GetClassObjectIDByClassPath(const FString& ClassPath, bool bCacheClass);
	void KAPI_UnCacheClass(KGObjectID InClassObjectID);
	void KAPI_UnCacheAllClass();

	void SetMainPlayerEntityID(const KGEntityID InEntID) { MainPlayerEntityID = InEntID; }
	KGEntityID GetMainPlayerEntityID() const { return MainPlayerEntityID; }	
	void SetMainPlayerControlledEntityID(const KGEntityID InEntID) { MainPlayerControlledEntityID = InEntID; }
	KGEntityID GetMainPlayerControlledEntityID() const { return MainPlayerControlledEntityID; }

	/** 手动添加 Actor OnDestroyed 绑定, 确保一些没有自动绑定OnDestroyed的Entity能够和Actor保持声明周期一致. */
	bool ManuallyRegisterActorOnDestroyed(KGObjectID InActor);
#pragma endregion LuaApi


#pragma region UEActorCache
	void SetEnableUEActorCache(bool Enable, bool EnableMainPlayer, bool EnableAOIPlayer, bool EnableNPCPlayer, bool EnableGhostClone, float InAvatarPlayerLruCacheTime = 30.0F, float InTickActorCacheIntervalTime = 3.0F);
	void ClearUEActorCache(int AvatarPlayerCacheCapacity);
	bool TryUseUEActorCache(KGEntityID EntID, const FTransform& Transform);
	bool TryPushUEActorCache(KGEntityID EntID, AActor* Actor);
	bool HandlePushCachedUEActor(AActor* UEActor, bool SetPos = true);
	bool HandlePopCachedUEActor(AActor* UEActor, const FTransform& Transform);
	void ResetCachedUEActor(ABaseCharacter* TargetCharacter, bool Visible);
	void ResetUEActorCacheCapacity(int Capacity);
	void UpdateAvatarPlayerLruCache();
	void AddAvatarPlayerCache(KGEntityID EntityID, AActor* AvatarPlayerActor);
	AActor* TryGetCachedAvatarPlayer(KGEntityID EntityID,int32 AppearanceChangeCount);
#pragma endregion

private:
	void LoadActor(KGEntityID EntID, const FString& ClassPath, float X, float Y, float Z, float Pitch, float Yaw,
		float Roll, bool Preload, bool SyncLoad);
	void DestoryActorByEntityID(KGEntityID EntID);
	void InnerRemoveActor(AActor* Actor);
	KGActorID GetIDByActor(AActor* InActor);

	bool BindActorToEntity(KGEntityID InEntID, AActor* InActor, bool IsOwnSpawned);
	void UnbindActorFromEntity(KGEntityID InEntID);
	void BeforeUnbindActorFromEntity(KGEntityID InEntID);
	
	bool CreateEntity(lua_State* L, KGEntityID EntityID, float X, float Y, float Z, float Pitch, float Yaw, float Roll);
	void DestroyEntity(lua_State* L, KGEntityID InEntID);
	void DestroyUEActor(AActor* Actor);

	// C++ ENTITY OBJECT POOL
	UObject* GetOrCreateCppEntityObject();
	void ReleaseCppEntityObject(UObject* InObject);

protected:
	UPROPERTY()
	class UKGUEActorLoader* ActorLoader;

#if WITH_EDITOR
	UFUNCTION(BlueprintCallable)
	void SetSpawnActorWorld(UWorld* InWorld) { OverrideWorld = InWorld; };
	TWeakObjectPtr<class UWorld> OverrideWorld;
#endif
	FActorSpawnParameters SpawnActorParameters;

private:
	bool bMgrInit = false;

	KGEntityID MainPlayerEntityID = KG_INVALID_ENTITY_ID;
	KGEntityID MainPlayerControlledEntityID = KG_INVALID_ENTITY_ID;

	UPROPERTY(Transient)
	TMap<int64, AActor*> ActorMap;

	TMap<KGActorID, KGEntityID> Actor2Entity;
	TMap<KGEntityID, KGActorID> Entity2Actor;

	UPROPERTY(Transient)
	TMap<int64, UObject*> LuaEntityMap;

	UPROPERTY(Transient)
	TArray<UObject*> CppEntityPool;
	int32 CppEntityPoolSize = 0;

	//提供给gameplay使用的C++类或BP类
	UPROPERTY(Transient)
	TArray<UClass*> ClassList;

	FKGOnActorLoaded OnActorLoadedDelegate;


#pragma region UEActorCache
	bool EnableUEActorCache = false;
	bool EnableUEActorMainPlayerCache = false;
	bool EnableUEActorAOIPlayerCache = false;
	bool EnableUEActorNPCCache = false;
	bool EnableUEActorGhostCloneCache = false;
	
	UPROPERTY(Transient)
	TObjectPtr<AActor> MainPlayerCache;

	UPROPERTY(Transient)
	TMap<int64, TObjectPtr<AActor>> AvatarPlayerCacheMap;
	// For AvatarPlayerCacheMap LRU
	TLruCache<int64, double> EntityIDToAvatarPlayerLruCache;
	float AvatarPlayerLruCacheTime = 30.0F;
	float TickActorCacheTime = 0.0F;
	float TickActorCacheIntervalTime = 3.0F;
	int AvatarPlayerCacheHitCount = 0;
	int AvatarPlayerCacheMissCount = 0;
	
#pragma endregion
};