// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "3C/Animation/AnimCommon.h"
#include "3C/Character/BaseCharacter.h"
#include "Components/MeshComponent.h"
#include "AddMeshComponent.generated.h"

class USphereComponent;

USTRUCT()
struct FDynamicMeshContext
{
	GENERATED_BODY()
	
	int64 UniqueID = 0;										    // 唯一ID
	int64 InLoadID = 0;
	bool bHidden = false;										// 是否隐藏
	bool bPropagateToChildren = false;							// 是否传播到子物体
	bool bUnit = false;										    // 是否是LUnitEntity,LUnitNEntity
	bool bAttachToCamera = false;							    // 是否挂接到摄像机
	bool bNeedAttach = false;									// 是否需要挂接	
	FName AttachSocket = NAME_None;								// 挂接点	
	float AttachTime = 0.0f;									// 挂接时间
	float DestroyTime = 0.0f;									// 销毁时间
	bool bStickGround = false;									// 是否贴地	
	FTransform Transform = FTransform();						// 初始位置
	bool bSMorSK = false;										// StaticMesh或SkeletalMesh	
	bool bCopyCurFrameAnim = false;								// 是否复制当前帧动画
	bool UseLOD0 = false;										// 是否使用LOD0
	int64 InstigatorID = 0;										// 触发者ID
	bool bLookAtInputPos = false;								// 看向inputPos
	FVector InputPos = FVector();								// 看向inputPos的偏移
	FName MeshName = NAME_None;									// 资源名称
	bool bBPAnim = false;										// 是否是蓝图动画
	bool bNeedLoop = false;										// 是否循环
	bool bInherit = false;										// 是否继承材质效果(非相机虚化)
	bool bFollowActorScale = false;								// 非Attach下。是否跟随Actor缩放
	bool bEnableCameraDither = false;							// 是否启用相机虚化&继承相机虚化效果
	FName AddMeshCollisionProfileName = NAME_None;				// 用于相机虚化的AddMesh碰撞preset
	bool bUseSelfPosForCameraDither = true;						// 是否使用自身Mesh位置来计算相机虚化
	bool EnableLight  = false;									// 是否开启补光
	bool bCatchUpAnimProgress = false;							// 是否追赶动画进度
	float CreateTimeStamp = 0.0f;								// 追赶动画进度时创建的时间戳

	UPROPERTY(Transient)
	USphereComponent* AddMeshCollisionComponent = nullptr;		// 用于相机虚化的碰撞组件
	
	UPROPERTY(Transient)
	TObjectPtr<UMeshComponent> MeshComponent = nullptr;			// 动态网格组件
	KGAnimPlayReqID AnimPlayReqID = 0;
	TArray<int64> NiagaraEffectIDs;								// 对应的NiagaraEffectID
};

UCLASS(meta = (BlueprintSpawnableComponent))
class KGCHARACTER_API UAddMeshComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UAddMeshComponent();
	virtual void EndPlay(EEndPlayReason::Type EndPlayReason) override;
	virtual void ResetToDefaultsForCache() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	
	bool CreateDynamicMesh(int64 UniqueID, bool bHidden, bool bPropagateToChildren, bool bUnit, bool bSMorSK,
										 const FName& MeshName, const FString& MeshPath, bool bNeedAttach,bool bAttachToCamera, const FName& AttachSocket,
										 float AttachTime, float DestroyTime, float TranslationX, float TranslationY, float TranslationZ,
										 float ScaleX, float ScaleY, float ScaleZ, float Pitch, float Yaw,
										 float Roll, bool bStickGround, bool bNeedLoop, const FString& AnimPath, const FString& BPAnimPath, 
										 bool UseLOD0, bool bCopyCurFrameAnim, KGEntityID InstigatorID, bool bLookAtInputPos, float InputPosX, 
										 float InputPosY, bool bInherit, bool bFollowActorScale, bool bEnableCameraDither, const FName& AddMeshCollisionProfileName, 
										 bool bUseSelfPosForCameraDither, bool bUseRootCompWhenSocketNone,  bool bEnableLight, bool bCatchUpAnimProgress);
	void RemoveDynamicMesh(int64 UniqueID);
	void SetHiddenInGame(int64 UniqueID, bool bHidden, bool bPropagateToChildren);
	void PlayAnimationOnMesh(int64 UniqueID, const FString& AnimPath, bool bLoop, float BlendInTime, float BlendOutTime);
	void StopAnimation(int64 UniqueID, float BlendOutTime);
	void CacheNiagaraParamBefore(int64 EffectID, const FName& ComponentName, bool bWant2Add);
	void UnCacheNiagaraParamBefore(const FName& ComponentName);

	void HideMainMeshAndChildMesh(bool bHidden);

private:	
	void CreateMeshAfterLoad(int InLoadID, const TArray<UObject*>& Assets, int64 UniqueID, bool bUseRootCompWhenSocketNone);
	void InternalRemoveDynamicMesh(int64 UniqueID);
	int64 GetDynamicMeshByMeshName(const FName& MeshName);
	
	UPROPERTY(Transient)
	TMap<int32, FDynamicMeshContext> DynamicMeshComponentMap;

	TMap<FName, TArray<int64>> WantToAddMeshCtxs;
};
