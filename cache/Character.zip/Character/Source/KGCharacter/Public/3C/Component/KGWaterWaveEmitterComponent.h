#pragma once

#include "Components/SceneComponent.h"
#include "KGWaterWaveEmitterComponent.generated.h"

UCLASS(ClassGroup=(Environment), meta=(BlueprintSpawnableComponent))
class KGCHARACTER_API UKGWaterWaveEmitterComponent : public USceneComponent
{
	GENERATED_BODY()

public:
	UKGWaterWaveEmitterComponent();

	virtual void BeginPlay() override;

	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
#endif

protected:
	UFUNCTION()
	void OnPlayerEnter(AActor* Player, const FVector& Loc);

	UFUNCTION()
	void OnPlayerLeave(AActor* Player, const FVector& Loc);

public:
	/**
	 * 开启: 进入划定范围才会触发水波纹
	 * 关闭: 只要Actor存在,就持续触发水波纹
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Bound", meta = (DisplayName="是否启用范围检测"))
	bool bEnableBound = false;

	/**
	 * 值没有具体含义,默认看不到,点一下就会刷新
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Bound", meta = (DisplayName="刷新包围盒显示", EditCondition="bEnableBound", EditConditionHides))
	bool RefreshCollisionDisplay = false;

	/**
	 * 注意不要调整缩放,不然范围会对不上
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Bound", meta = (DisplayName="包围盒大小", EditCondition="bEnableBound", EditConditionHides))
	FVector BoxExtent = FVector(1000.f, 1000.f, 1000.f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Bound", meta = (DisplayName="样条线粗细", EditCondition="bEnableBound", EditConditionHides))
	float BoxLineThickness = 10.f;

	UPROPERTY(BlueprintReadOnly, Category="WaterWave")
	int32 MotorTextureId = 0;

	UPROPERTY(BlueprintReadOnly, Category="WaterWave")
	FVector2f Scale = FVector2f(500.0F, 500.0F);

	UPROPERTY(BlueprintReadOnly, Category="WaterWave")
	float MaxHeight = 50.0F;

	UPROPERTY(BlueprintReadOnly, Category="WaterWave")
	float FoamScale = 0.0F;

	UPROPERTY(BlueprintReadOnly, Category="WaterWave", meta = (ClampMin = "0.2", UIMin = "0.2"))
	float TimeGap = 0.5F;

	UPROPERTY(BlueprintReadOnly, Category="WaterWave")
	int MoveDirAngleOffset = 0;


	void RefreshWaterWaveInManager();

	UFUNCTION(BlueprintCallable, Category="WaterWave")
	void SetMotorTextureId(int32 Value);

	UFUNCTION(BlueprintCallable, Category="WaterWave")
	void SetScale(FVector2f Value);

	UFUNCTION(BlueprintCallable, Category="WaterWave")
	void SetMaxHeight(float Value);

	UFUNCTION(BlueprintCallable, Category="WaterWave")
	void SetFoamScale(float Value);

	UFUNCTION(BlueprintCallable, Category="WaterWave")
	void SetTimeGap(float Value);

	UFUNCTION(BlueprintCallable, Category="WaterWave")
	void SetMoveDirAngleOffset(int Value);

private:
	UPROPERTY()
	class UC7ShapeCollisionComponent* ShapeCollision;

	int WaterWaveRequestID;
	bool bPlayerInside = true;
};
