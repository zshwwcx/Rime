// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "3C/Character/BaseCharacter.h"
#include "TickActionComponent.generated.h"

struct FModelScaleUpdateContext
{
	//渐入时间
	float FadeIn = 0.f;
	//渐出时间
	float FadeOut = 0.f;
	//持续时间
	float Duration = 0.f;
	//渐入曲线
	//TWeakObjectPtr<UCurveFloat> FadeInCurve;
	//渐出曲线
	//TWeakObjectPtr<UCurveFloat> FadeOutCurve;
	//缩放目标尺寸
	FVector TargetScale = FVector::OneVector;
	//原来Scale
	FVector OriginScale = FVector::OneVector;
	//模型缩放开始经过时间
	float OverTime = 0.f;

};

UCLASS(meta = (BlueprintSpawnableComponent))
class KGCHARACTER_API UTickActionComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UTickActionComponent();

	virtual void BeginPlay() override;

	virtual void TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	
	virtual void ResetToDefaultsForCache();

	int32 StartModelScale(float TargetHeightScaleRate, float TargetRadiusScaleRate, float InDuration, float InFadeIn, float InFadeOut);
	void StopModelScale(int32 InModelScaleId, bool bNotRevert);
	void ModelScaleTick(float DeltaTime, int32 ModelScaleId);
private:
	static int32 GenerateModelScaleId();

protected:
	TMap<int32, FModelScaleUpdateContext> ModelScaleUpdateContexts;
	FVector SourceScale3D = FVector::OneVector;
	bool bHasSourceScale3D = false;
};
