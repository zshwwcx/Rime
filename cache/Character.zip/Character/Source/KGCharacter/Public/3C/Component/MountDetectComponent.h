// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "3C/Character/BaseCharacter.h"
#include "MountDetectComponent.generated.h"


UCLASS(meta=(BlueprintSpawnableComponent) )
class KGCHARACTER_API UMountDetectComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UMountDetectComponent();

protected:
	virtual void BeginPlay() override;

public:
	UFUNCTION(BlueprintCallable)
	void StartDetectObjectsInBoxTrace(
		float StartX, float StartY, float StartZ,
		float EndX, float EndY, float EndZ,
		float BoxHalfSizeX, float BoxHalfSizeY, float BoxHalfSizeZ,
		TArray<int32> InDetectObjectTypes, bool OnlyDetectCrowdNPC);

	UFUNCTION(BlueprintCallable)
	void StopDetectObjects();
public:	
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

protected:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bEnableDetect = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bOnlyDetectCrowdNPC = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector DetectStartPos;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector DetectEndPos;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector DetectBoxHalfSize;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<TEnumAsByte<EObjectTypeQuery>> DetectObjectTypes;

	UPROPERTY()
	TSet<TWeakObjectPtr<ABaseCharacter>> LastFrameActors;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TEnumAsByte<EDrawDebugTrace::Type> DebugDrawType = EDrawDebugTrace::None;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<float> ImpulseConfig;

	void HandleActorEnter(ABaseCharacter* Char, const FHitResult& Hit);

	void HandleActorLeave(ABaseCharacter* Char);
	
public:
	void SetDetectActorsInFanParams(float Radius, float Angle, float VelocityFactor, const float VelocityThreshold, const float FacingAngle);
	void SetGTAParams(const float ImpulseStrength,const int TraceChannel,bool UseComponentGTATag,const float LifeSpan,const FName ProfileName, const TArray<float>& InImpulseConfig);
	
protected:
	/** 扇形检测半径 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float FanDetectRadius = 0;
	
	/** 扇形检测角度 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float FanDetectAngle = 0;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float MountVelocityFactor = 0;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float MountVelocityThreshold = 0;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float CharacterFacingAngle = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TEnumAsByte<ETraceTypeQuery> GTATraceChannel;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float StreetLampImpulseStrength = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bUseComponentGTATag = false;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float SpawnActorLifeSpan = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName CollisionProfileName;;
	/** 扇形内的角色 */
	TSet<TWeakObjectPtr<ABaseCharacter>> ActorsInFan1;
	TSet<TWeakObjectPtr<ABaseCharacter>> ActorsInFan2;
	bool bLastFanFlag = true;
	
	void TickFanDetectReact();

	void ProcessGTAHitResult(const FHitResult& HitResult) const;
	
	/** 触发CrowdNpc进入React */
	void HandleActorEnterFan(ABaseCharacter* Character, const FVector& Dir) const;
	
	/** 扇形范围是否包含某点 */
	static bool IsPointInSector(const FVector& Point, const FVector& Center, const FVector& Dir, float FanDetectAngle);
};
