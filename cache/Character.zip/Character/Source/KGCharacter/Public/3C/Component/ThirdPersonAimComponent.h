// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Misc/CommonDefines.h"
#include "Components/ActorComponent.h"
#include "ThirdPersonAimComponent.generated.h"


UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class KGCHARACTER_API UThirdPersonAimComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	// Sets default values for this component's properties
	UThirdPersonAimComponent();
	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	/**
	 * 开启不带辅助瞄准的检测
	 * @param InObjectTypes 
	 */
	void StartAim(const TArray<int32>& InObjectTypes);

	/**
	 * 停止瞄准,不管是辅助瞄准还是非辅助瞄准
	 */
	void StopAim();

private:
	// 每帧检测
	void DetectAimTarget();

private:
	// 碰撞检测类型(后续支持以回调名为Key做不同区分)
	TArray<TEnumAsByte<EObjectTypeQuery>> ObjectTypes;

	// 上次选中的EntityID,避免重复回调
	int64 LastDetectedEntityID = 0;

public:
	/**
	 * 开启辅助瞄准
	 * @param InObjectTypes 碰撞检测类型
	 * @param InTargetActors 目标Entity列表
	 * @param InSupportAimRadius 辅助瞄准检测范围(像素)
	 * @param InFirstTimeSupportAimRadius 初次辅助瞄准检测范围(像素)
	 * @param InEscapeProtectTime 逃逸保护时间
	 */
	void StartAimWithSupport(const TArray<int32>& InObjectTypes, const TMap<TWeakObjectPtr<AActor>, FString>& InTargetActors, int32 InSupportAimRadius, int32 InFirstTimeSupportAimRadius, double InEscapeProtectTime);

	/**
	 * 增量更新目标列表
	 * @param InActor
	 * @param BoneName
	 */
	void AddTargetActor(AActor* InActor, const FString& BoneName = TEXT(""));

private:
	void DetectAimTargetWithSupport();

private:
	// 辅助瞄准开关
	bool bEnableAimSupport = false;
	
	// 目标Entity列表
	TMap<TWeakObjectPtr<AActor>, FString> TargetActors;

	// 辅助瞄准检测半径
	int32 SupportAimRadius = 0;

	// 初次检测半径
	int32 FirstTimeSupportAimRadius = 0;

	// 逃逸保护时间
	double EscapeProtectTime = 0.f;

	// 逃逸保护清空时间
	double NextSupportAimTime = -1.f;

	// 当前辅助瞄准吸附目标
	KGObjectID SupportAimTargetEntityID = 0;

	// 初次检测标记
	bool bFirstDetect = false;
};
