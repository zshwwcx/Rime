﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Components/SceneCaptureComponent2D.h"
#include "Components/SceneComponent.h"
#include "3C/Character/BaseCharacter.h"
#include "MovePlatformComponent.generated.h"

/**
 * 
 */
UCLASS(meta=(BlueprintSpawnableComponent))
class KGCHARACTER_API UMovePlatformComponent : public UActorComponent
{
	GENERATED_BODY()
public:
	UMovePlatformComponent();
	

	virtual void BeginPlay() override;
	
	virtual void TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	void StartPositionCorrectionWithinInnerSafeArea(
		float TimeToCorrection, float XPlatformExtent, float YPlatformExtent, float ZPlatformExtent,
		float XExtent, float YExtent, float ZExtent,
		float SafeXOffset, float SafeYOffset, float SafeZOffset,
		TArray<int32> InDetectObjectTypes);
	void StopPositionCorrectionWithinInnerSafeArea();

	void StartSafeAreaPush(float DetectTickTime, float PushSpeed, float CenterX, float CenterY, float CenterZ, float XExtent, float YExtent, float ZExtent, TArray<int32> InDetectObjectTypes);
	void SetPushContinueTime(float ContinueTime){PushContinueTime = ContinueTime;}
	void StopSafeAreaPush();
	
protected:
	TMap<TWeakObjectPtr<ABaseCharacter>, float> CharactersPushedToSafeArea;

	bool IsUsingPositionCorrectionWithinInnerSafeArea = false;
	float TimeForCorrectToSafePosition = 0.5f;
	float DurationForCorrectToSafePosition;
	FVector InnerSafeCenter{0, 0, 0};
	FVector InnerSafeDetectBox{32, 32, 32};
	FVector MovePlatformExtendBox{32, 32, 32};
	TArray<TEnumAsByte<EObjectTypeQuery>> PositionCorrectionDetectObjectTypes;

	bool IsUsingSafeAreaPush = false;
	FVector PlatformPushCenter{0, 0, 0};
	FVector PlatformPushAreaBox{32, 32, 32};
	float PushSpeed = 500;
	float PushContinueTime = 0.1;
	float DetectTickTime = 0.1;
	float DetectDuration = 0.0;
	TArray<TEnumAsByte<EObjectTypeQuery>> PushDetectObjectTypes;
};
