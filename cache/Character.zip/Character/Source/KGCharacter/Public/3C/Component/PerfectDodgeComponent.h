#pragma once
#include "Misc/CommonDefines.h"
#include "Components/ActorComponent.h"

#include "PerfectDodgeComponent.generated.h"

class UKGMaterialManager;
class UKGUEActorManager;
class UKGCombatSettingsManager;
class UKGEffectManager;
class UCurveFloat;
class UCapsuleComponent;

USTRUCT()
struct FKGPerfectDodgeCapsuleCollisionInfo
{
	GENERATED_BODY()

	UPROPERTY(Transient)
	UCapsuleComponent* CapsuleComponent = nullptr;
	
	FTimerHandle TimeOutTimerHandle;
};

USTRUCT()
struct FKGPerfectDodgeGhostInfo
{
	GENERATED_BODY()
	
	UPROPERTY(Transient)
	class ABSAGhostActor* GhostActor;
	
	FTimerHandle GhostActorLifeTimeHandle;
};

// 处理完美闪避相关逻辑, 包括完美闪避的攻击方判定, 受击方collision component管理, 时停效果等
// 触发逻辑时lazy挂载组件
UCLASS()
class UPerfectDodgeComponent : public UActorComponent
{
	GENERATED_BODY()
	
public:
	UPerfectDodgeComponent(const FObjectInitializer& ObjectInitializer);

	virtual void TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	
	bool EnablePerfectDodge(float ActiveTime);
	bool DisablePerfectDodge();
	bool CanTriggerPerfectDodge() const { return PerfectDodgeCollisionInfos.Num() > 0; }

	void TriggerPerfectDodge(bool bIsAttacker, bool bPropagateToChildUnits = true);
	bool IsPerfectDodgeActive() const { return PerfectDodgeTimeDilationCurve != nullptr; }
	void AddChildUnitsEnableTimeDilation(AActor* InActor);
	
protected:
	bool ShouldComponentTick() const;
	void UpdateComponentTickState();
	bool UpdateAndCacheManagers();

	void CreatePerfectDodgeCollisionComponent();
	void RemovePerfectDodgeCollision(uint64 FrameKey);
	void RemoveAllPerfectDodgeCollisions();
	void OnPerfectDodgeCollisionTimeOut(uint64 FrameKey);
	void DrawDebugPerfectDodgeCollisionInfos();

	void StartChildUnitsPerfectDodge();
	void UpdateActorCustomTickDilation();
	void DoSetCustomTimeDilation(AActor* InActor, float InTimeDilation);
	void DoSkillSlomo(float ClampedElapsedTime);
	
	void SpawnGhost();
	void DestroyGhosts();
	void DestroyGhost(FKGPerfectDodgeGhostInfo& GhostInfo);
	void OnGhostTimeOut(KGObjectID GhostActorID);
	
	bool bPerfectDodgeEnabled = false;
	float CurrentPerfectDodgeActiveTime = 0.0f;

	double PerfectDodgeStartTimeSeconds = 0.0;
	// 客户端技能采用分段固定slomo速度, 减少回lua的开销
	int32 CurrentSkillSlomoSegmentIndex = -1;
	bool bEnableSkillSlomo = false;
	UPROPERTY(Transient)
	UCurveFloat* PerfectDodgeTimeDilationCurve = nullptr;
	TSet<TWeakObjectPtr<AActor>> ChildUnitsEnableTimeDilation;
	
	// 完美闪避启用期间, 角色每帧在当帧位置处生成一个胶囊体大小的碰撞盒用于完美闪避判定检测
	// 完美闪避碰撞盒由anim notify state创建, 在anim notify state持续期间内(包含开始帧), 每帧都会创建新的碰撞盒
	// 由于anim notify的触发可能从pre physics到post physics任意阶段, 因此这里用帧号做key, 确保第一帧不会重复创建
	UPROPERTY(Transient)
	TMap<uint64, FKGPerfectDodgeCapsuleCollisionInfo> PerfectDodgeCollisionInfos;

	UPROPERTY(Transient)
	TMap<uint64, FKGPerfectDodgeGhostInfo> GhostInfos;
	
	TWeakObjectPtr<UKGEffectManager> EffectManager;
	TWeakObjectPtr<UKGCombatSettingsManager> CombatSettingsManager;
	TWeakObjectPtr<UKGUEActorManager> ActorManager;
	TWeakObjectPtr<UKGMaterialManager> MaterialManager;
};
