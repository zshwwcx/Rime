// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "3C/Core/AttachJointComponent_V2.h"
#include "Components/ActorComponent.h"
#include "Misc/CommonDefines.h"
#include "TypeDefines/CacheDataTypes.h"
#include "WeaponManagerComponent.generated.h"

class ASeerAttachActor;

UENUM()
enum class EWeaponVisibleRule : uint32
{
	AutoHide = 1, // 自动隐藏(激活时显示、非激活时隐藏)
	NeverHideWithWeaponVisible = 2, // 不隐藏(只在整体武器显示时生效,武器整体隐藏式依旧会隐藏)
	ActiveAndHoldShow = 3, // 激活且持握时才可见
};

UENUM()
enum class EWeaponAttachRule : uint32
{
	AutoAttach = 1, // 自动切换挂点(持武时切换到手上)
	ForceHoldSocket = 2, // 强制持武
	ForceUnholdSocket = 3, // 强制不持武
};

struct FUnrealAttachInfo
{
public:
	FName AttachSocket = NAME_None;
	FVector RelLocation = FVector::ZeroVector;
	FRotator RelRotation = FRotator::ZeroRotator;

	FVector RelLocationAdd = FVector::ZeroVector;
	
	EAttachmentRule LocRule = EAttachmentRule::SnapToTarget;
	EAttachmentRule RotRule = EAttachmentRule::SnapToTarget;
	EAttachmentRule ScaleRule = EAttachmentRule::SnapToTarget;
};

struct FWeaponAttachInfo
{
public:
	bool bUnrealAttach = true;

	// 公共配置信息
	FUnrealAttachInfo UnrealAttachInfo;
	
	// 虚拟挂接配置信息
	FVirtualAttachInfo VirtualAttachInfo;
};

enum EWeaponAttachType
{
	WaitAttach,
	HoldAttach,
	UnHoldAttach,
};

USTRUCT()
struct FWeaponInfo
{
	GENERATED_BODY()

public:
	UPROPERTY()
	ASeerAttachActor* WeaponActor = nullptr;

	int WeaponGroup = 1;		// 武器分组
	// 武器表常驻数据
	FWeaponInfoData InfoData;
	// 持武配置信息
	FWeaponAttachInfo HoldWeaponInfo;
	// 非持武配置信息
	FWeaponAttachInfo UnHoldWeaponInfo;
	// 显隐规则控制
	EWeaponVisibleRule WeaponVisibleRule = EWeaponVisibleRule::AutoHide;
	// 挂接规则控制
	EWeaponAttachRule WeaponAttachRule = EWeaponAttachRule::AutoAttach;

	// 缓存数据
	FString ActorClass;
	FString FightToIdleAnimPath;
	int64 WeaponPlayAnimID = 0;
	EWeaponAttachType AttachType = EWeaponAttachType::WaitAttach;
};

typedef int Type_WeaponType;	// 武器类型
typedef int Type_WeaponGroup;	// 武器创建原因(职业自带武器、变身创建武器、技能中临时创建的武器 等等)
typedef int ID_WeaponID;		// 武器

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class KGCHARACTER_API UWeaponManagerComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UWeaponManagerComponent();

	// 通用配置初始化
	void InitWeaponManagerConfig(bool bEnableFightToIdle);
	void UpdateIsEnablePlayUnHoldWeaponAnim(bool bEnableFightToIdle);
	
	// 初始化武器
	void CreateWeapon(FString ActorClass, int WeaponID, int WeaponGroup, FString FightToIdleAnimPath, EWeaponVisibleRule WeaponVisibleRule, EWeaponAttachRule WeaponAttachRule, bool bMainWeapon);

	//引擎挂接参数
	void SetUnrealAttachParam(int WeaponID, bool IsHoldWeaponParam, FName SocketName, EAttachmentRule LocRule, EAttachmentRule RotRule, EAttachmentRule ScaleRule,
		float RelLocX, float RelLocY, float RelLocZ, float RelPitch, float RelYaw, float RelRoll);

	// 虚拟挂接接口
	void SetUseVirtualAttach(int WeaponID, bool IsHoldWeaponParam, int VirtualAttachID);

	// 设置全部武器显示/隐藏(实际上只需要设置当前生效的武器)
	void SetWeaponVisibility(bool bVisibility);
	// 设置武器溶解效果
	void SetWeaponDissolveEffectWithDefaultID(bool bVisible);
	void SetWeaponDissolveEffect(bool bVisible, int DissolveID);
	bool GetIsWeaponEnableShow();
	bool GetIsWeaponEnableHold();

	/**
	 * 更新且使用当前配置数据
	 * @param WeaponGroup 武器分组,必定要传有效值
	 * @param WeaponType 武器类型,可以传正确类型也可以传 -1 (表示此分组内无需要显示的武器)
	 * @param MainWeaponID 武器ID,可以传正确ID也可以传 -1 (表示此分组内无需要显示的武器)
	 */
	void ActiveWeaponGroupWithTypeAndID(int WeaponGroup, int WeaponType, int MainWeaponID);
	
	/**
	 * 更新武器 组内 对应武器类型的激活ID
	 * @param WeaponGroup 武器分组,必定要传有效值
	 * @param WeaponType  武器类型,可以传正确类型也可以传 -1 (表示此分组内无需要显示的武器)
	 * @param MainWeaponID 武器ID,可以传正确ID也可以传 -1 (表示此分组内无需要显示的武器)
	 */
	void UpdateWeaponInfo(int WeaponGroup, int WeaponType, int MainWeaponID);
	
	/**
	 * 激活武器分组 & 组内激活类型
	 * @param WeaponGroup 武器分组
	 * @param WeaponType 武器类型
	 */
	void ActiveWeaponGroupWithType(int WeaponGroup, int WeaponType);

	/**
	 * 激活指定武器分组下武器类型
	 * @param WeaponGroup 
	 * @param WeaponType 
	 */
	void ActiveWeaponTypeByGroup(int WeaponGroup, int WeaponType);

	/**
	 * 激活当前武器分组下 武器类型
	 * @param WeaponType 
	 */
	void ActiveCurrentWeaponType(int WeaponType);
	int GetCurActiveWeaponGroup();

	/**
	 * 移除武器分组
	 * @param WeaponGroup 
	 * @return 返回最新激活的主武器ID
	 */
	int RemoveWeaponGroup(int WeaponGroup);
	void UpdateAllWeaponByRule(bool bSkipActiveWeaponVisible = false);
	
	/**
	 * 切换武器持武状态
	 * @param IsHoldWeapon 设置当前是否持有武器
	 */
	void UpdateHoldWeaponState(bool IsHoldWeapon, bool bSkipActiveWeaponVisible = false);
	void UpdateWeaponAttachState(FWeaponInfo& WeaponInfo, EWeaponAttachType AttachType);
	void ExecuteWeaponAttach(FWeaponInfo& WeaponInfo, bool bUseHoldWeaponSocket);

	/**
	 * 获取当前激活的主武器CharacterID
	 * @return 
	 */
	KGObjectID GetCurActiveMainWeaponCharacterID();

	/**
	 * 获取指定插槽部位的武器ID
	 * @param WeaponSlot 
	 * @return 
	 */
	KGObjectID GetActiveWeaponCharacterIDBySlot(int WeaponSlot);
	
	/**
	 * 获取当前激活的主武器MeshID
	 * @return 当前激活的武器MeshID
	 */
	KGObjectID GetCurActiveMainWeaponSkeletalMeshID();

	/**
	 * 根据武器槽位 获取当前激活的武器MeshID
	 * @param WeaponSlot 武器槽位 
	 * @return 指定插槽对应的武器 MeshID
	 */
	KGObjectID GetActiveWeaponSkeletalMeshIDBySlot(int WeaponSlot);

	/**
	 * 移动打断持武状态
	 */
	UFUNCTION()
	void OnLocoMoveStart();
	void PlayDissolveEffect(bool bVisible);
	FWeaponTypeData* GetWeaponTypeData(int WeaponType);

	/**
	 * 技能开始后 几秒开始隐藏武器 (附带溶解效果)
	 * @param DelayHideWeaponTime 延迟武器隐藏时间 单位 秒
	 */
	void OnSkillStartHoldWeapon(float DelayHideWeaponTime);
	void DelayDissolveWeapon(bool bVisible);
	void OnFightToIdleDelayFadeOutWeapon(float DelayShowTime);

	/**
	 * 技能期间强制显示武器: 时装隐藏武器的时候技能开始时需要把武器显示出来,但是技能结束收刀时才需要隐藏武器,这里做特殊处理 在技能期间打个标记
	 */
	void ForceSkillShowWeapon();
	void SetForceHoldWeapon(bool bForce);

	/**
	 * 技能结束
	 * @param bMoveStop 是否是移动打断
	 * @param bHold 是否依旧持武
	 * @param bWeaponNeedFadeIn 武器是否需要渐入
	 * @param bEndToCommonIdle  收刀是是否回到普通Idle
	 * @param DelayShowWeaponTime 延迟显示武器时间 单位秒
	 */
	void OnSkillEndUpdateWeapon(bool bMoveStop, bool bHold, bool bWeaponNeedFadeIn, bool bEndToCommonIdle, float DelayShowWeaponTime);
	void DelayPlayUnHoldWeaponAnim();
	void StopFightToIdleAnim();
	void StopTimerOfDelayDissolveWeapon();

	/**
	 * 
	 * @param WeaponID 更新武器相对偏移
	 * @param RelX 
	 * @param RelY 
	 * @param RelZ 
	 * @param RelPitch 
	 * @param RelYaw 
	 * @param RelRoll 
	 */
	void UpdateWeaponUnHoldOffset(int WeaponID, float RelX, float RelY, float RelZ);
	
	void GetWeaponActors(TArray<AActor*>& OutAttachActors);
	const FWeaponInfo* GetWeaponInfoByID(int WeaponID) const { return MapOfCreatedWeapon.Find(WeaponID); }
	// 获取当前激活的武器分组下 激活的武器类型的所有武器ID
	TArray<int> GetCurActiveWeaponList();
	void PlayWeaponAnimationByID(const FString& AnimID, const FName& AnimSlotName, float BlendInTime,float BlendOutTime);
	void StopWeaponAnimation(float BlendOutTime);
	virtual void ResetToDefaultsForCache() override;
protected:
	// Called when the game starts
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

	class UAttachJointComponent_V2* GetAttachJointComponent();
	void OnWeaponActorClassLoaded(int InLoadID, UObject* LoadedAsset, int WeaponID);
	void DeleteWeaponByID(int WeaponID);
	// 获取指定的武器分组下 激活的武器类型的所有武器ID
	TArray<int> GetSpecialWeaponList(int WeaponGroup);
	// 获得指定的武器分组下所有武器ID
	TArray<int> GetWeaponGroupWeaponList(int WeaponGroup);
public:	
	virtual void AppendDebugInfo(FString& infoOut);
	
private:
	int INVALID_ID = -1;
	TArray<Type_WeaponGroup> ActiveWeaponGroupArray;	// 当前激活的武器组
	TMap<Type_WeaponGroup, Type_WeaponType> MapOfGroupToType;	// 当前激活的武器类型(同一时间只能激活一个武器类型，比如战士的双刀算是一个武器类型)
	TMap<Type_WeaponGroup, TMap<Type_WeaponType, ID_WeaponID>> MapOfWeaponGroupToTypeToID;	// 武器类型对应的当前激活 主武器ID 映射

	UPROPERTY()
	TMap<int, FWeaponInfo> MapOfCreatedWeapon;	// 当前创建且依旧持有武器数据缓存(int = ID_WeaponID)
	
	bool bShowWeapon = true;	// 武器是否显示
	bool bHoldWeapon = false;	// 是否处于持武状态
	bool bForceHoldWeapon = false; // 是否强制持武
	bool bEnablePlayUnHoldWeaponAnim = false; // 是否可以播放收刀武器动画
	bool bForceSkillShowWeapon = false; // 特定环节强制显示武器(目前只有技能使用这个数据)

	int64 PlayerFightToIdleAnimID = 0;
	
	// 定时器相关
	FTimerHandle TimerHandleOfDelayDissolveWeapon;

	TMap<ID_WeaponID, int> AssetLoadMap;
};
