#pragma once
#include "Misc/CommonDefines.h"
#include "Components/ActorComponent.h"
#include "Containers/Union.h"
#include "TypeDefines/LuaTypes.h"
#include "UObject/WeakInterfacePtr.h"

#include "AttackCollisionComponent.generated.h"

class ICppEntityInterface;
class UKGDataCacheManager;
class UKGCombatSettingsManager;
class UKGUEActorManager;
struct FModelHitBoxData;

// 这里要跟lua中的 EAbilityUnitType 保持一致
enum class EKGClientAttackSourceType : uint8
{
	Skill = 0,
	SpellField = 1,
	Bullet = 2
};

enum class EKGPhysicsQueryShapeType : uint8
{
	Capsule = 0,
	Box = 1,
	Sphere = 2,
};

struct FKGPhysicsQueryCollisionSphereShapeParams
{
	float Radius = 100.0f;
};

struct FKGPhysicsQueryCollisionCapsuleShapeParams
{
	float Radius = 100.0f;
	float HalfHeight = 100.0f;
};

struct FKGPhysicsQueryCollisionBoxShapeParams
{
	FVector BoxExtent = FVector(100.0f, 100.0f, 100.0f);
};

struct FKGPhysicsQueryCollisionInfo
{
	FKGPhysicsQueryCollisionInfo()
	{
		ShapeParams.SetSubtype<FKGPhysicsQueryCollisionSphereShapeParams>();
	}
	
	EKGPhysicsQueryShapeType ShapeType = EKGPhysicsQueryShapeType::Sphere;
	TUnion<FKGPhysicsQueryCollisionCapsuleShapeParams, FKGPhysicsQueryCollisionBoxShapeParams, FKGPhysicsQueryCollisionSphereShapeParams> ShapeParams;
	FName AttachSocketName;
	TWeakObjectPtr<USceneComponent> AttachComponent;
	FTransform RelativeTransform = FTransform::Identity;
	TArray<TEnumAsByte<EObjectTypeQuery>> ObjectTypesToQuery;
	bool bTriggerPerfectDodge = true;
	EKGClientAttackSourceType SourceType = EKGClientAttackSourceType::Skill;
	uint64 UnitInstID = 0;
	uint32 SourceAbilityID = 0;
	uint32 AttackSkillID = 0;
	float MinHitIntervalSeconds = -1.0f;
};

struct FKGPhysicsQueryContext
{
	FKGPhysicsQueryCollisionInfo CollisionInfo;
	
	FTransform LastFrameTrans = FTransform::Identity;
	TMap<TWeakObjectPtr<AActor>, double> TargetNextValidHitTimeInfo;
	TArray<TWeakObjectPtr<const AActor>> IgnoredActors;
};

struct FKGClientRangeAttackContext
{
	// search params
	uint32 SkillOrSpellFieldID = 0;
	KGEntityID TargetEntityID = KG_INVALID_ENTITY_ID;
	TOptional<FVector> InputPos;
	TOptional<float> InputYaw;

	// hit params
	bool bTriggerPerfectDodge = true;
	uint32 SourceSkillID = 0;
	uint32 AttackSkillID = 0;
	float MinHitIntervalSeconds = -1.0f;
	EKGClientAttackSourceType SourceType = EKGClientAttackSourceType::Skill;
	uint64 UnitInstID = 0; // 服务器同步用
	KGEntityID UnitEntityID = KG_INVALID_ENTITY_ID; // 这里是target select的base entity
	
	float AccumulatedTimeSeconds = 0.0f;
	int32 CurrentTimeWindowIndex = 0;
	TMap<KGEntityID, double> TargetHitRecords;
	
	ICppEntityInterface* GetBaseEntity(UKGUEActorManager* ActorManager);
	ICppEntityInterface* GetTargetEntity(UKGUEActorManager* ActorManager);
	TWeakInterfacePtr<ICppEntityInterface> BaseEntity;
	TWeakInterfacePtr<ICppEntityInterface> TargetEntity;
};

UCLASS()
class KGCHARACTER_API UAttackCollisionComponent : public UActorComponent
{
	GENERATED_BODY()
	
public:
	UAttackCollisionComponent(const FObjectInitializer& ObjectInitializer);

	virtual void TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
		
	// todo 武器cpp化完成后移除
	void EnablePhysicsQueryCollision(
		KGActorID HitBoxOwnerActorID, const FName& ModelName, const FName& ShapeName, const TArray<int32>& ObjectTypesToQuery,
		uint32 SourceAbilityID, uint32 AttackSkillID, bool bTriggerPerfectDodge,float MinHitIntervalSeconds);
	void EnablePhysicsQueryCollisionNew(
		bool bCheckWeapon, const FName& CharacterModelName, const FName& ShapeName, const TArray<int32>& ObjectTypesToQuery,
		uint32 SourceAbilityID, uint32 AttackSkillID, bool bTriggerPerfectDodge,float MinHitIntervalSeconds);
	void DisablePhysicsQueryCollision(const FName& ShapeName);

	uint32 AddPhysicsQueryCollision(const FKGPhysicsQueryCollisionInfo& CollisionInfo);
	void RemovePhysicsQueryCollision(uint32 CollisionID);

	uint32 EnableRangeAttack(
		// search params
		uint32 SkillOrSpellFieldID, KGEntityID TargetEntityID, bool bUseInputPos, float InputPosX, float InputPosY, float InputPosZ,
		bool bUseInputYaw, float InputYaw,
		// hit params
		bool bTriggerPerfectDodge, uint32 SourceSkillID, uint32 AttackSkillID, float MinHitIntervalSeconds, 
		EKGClientAttackSourceType SourceType, uint64 UnitInstID, KGEntityID UnitEntityID);
	void DisableRangeAttack(uint32 AttackID);
	
protected:
	void InternalEnablePhysicsQueryCollision(
		AActor* CollisionOwnerActor, const FModelHitBoxData& ModelHitBoxData, const FName& ShapeName, const TArray<int32>& ObjectTypesToQuery,
		uint32 SourceAbilityID, uint32 AttackSkillID, bool bTriggerPerfectDodge,float MinHitIntervalSeconds);
	
	void PerformPhysicsQuery();
	bool UpdateAndCacheManagers();
	void UpdatePhysicsQueryTickState();
	void HitActorCommon(
		AActor* HitActor, EKGClientAttackSourceType SourceType, uint32 SourceAbilityID, uint64 UnitInstID,
		uint32 AttackSkillID, bool bTriggerPerfectDodge);

	bool CanRangeAttack(FKGClientRangeAttackContext& InOutContext, float DeltaTime);
	void PerformRangeAttack(FKGClientRangeAttackContext& InOutContext);
	void HitEntityByRangeCheck(
		KGEntityID HitEntityID, EKGClientAttackSourceType SourceType, uint32 SourceAbilityID,
		uint64 UnitInstID, uint32 AttackSkillID, bool bTriggerPerfectDodge);
	
	uint32 GenerateCollisionID();
	
	// 精确物理查询相关碰撞信息
	TMap<FName, uint32> CollisionShapeNameToID;
	TMap<uint32, FKGPhysicsQueryContext> PhysicsQueryCollisionContexts;
	uint32 CurCollisionID = 0;
	
	TMap<uint32, FKGClientRangeAttackContext> ClientAttackParams;
	
	TWeakObjectPtr<UKGUEActorManager> UEActorManager;
	TWeakObjectPtr<UKGCombatSettingsManager> CombatSettingsManager;
	TWeakObjectPtr<UKGDataCacheManager> DataCacheManager;
};