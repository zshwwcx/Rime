// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Misc/CommonDefines.h"
#include "Components/ActorComponent.h"
#include "AvatarFaceAnimComponent.generated.h"


UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class KGCHARACTER_API UAvatarFaceAnimComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UAvatarFaceAnimComponent();
	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	virtual void ResetToDefaultsForCache() override;

public:
	UFUNCTION(BlueprintCallable)
	UFaceAnimLayer* GetFaceAnimLayer();

	UFUNCTION(BlueprintCallable)
	void EnableFaceAnimLayer(bool Enable);

	UFUNCTION(BlueprintCallable)
	void SetNeedBlink(bool InNeedBlink) { NeedBlink = InNeedBlink;}

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FString FaceAnimLayerTag = "FaceAnim";

	UPROPERTY(Transient)
	bool NeedBlink = false;
	
	UPROPERTY(Transient)
	bool IsEnableBlink = false;

public:
	static inline float AvatarFaceAnimDistance = 260;

protected:
	UPROPERTY(Transient, BlueprintReadOnly)
	TWeakObjectPtr<class ABaseCharacter> Character = nullptr;
};
