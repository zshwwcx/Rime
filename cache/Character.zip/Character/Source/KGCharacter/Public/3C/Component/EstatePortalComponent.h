﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Components/SceneCaptureComponent2D.h"
#include "Components/SceneComponent.h"
#include "EstatePortalComponent.generated.h"

/**
 * 
 */
UCLASS(meta=(BlueprintSpawnableComponent))
class KGCHARACTER_API UEstatePortalComponent : public USceneComponent
{
	GENERATED_BODY()
public:
	UEstatePortalComponent();
	
	TWeakObjectPtr<USceneCaptureComponent2D> SceneCaptureComponent;
	
	TWeakObjectPtr<UEstatePortalComponent> TargetPortal;

	virtual void BeginPlay() override;
	
	virtual void TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	
	FVector GetMirrorLocation(const FVector& SourceLocation);
	
	FRotator GetMirrorRotation(const FRotator& SourceRotation);
};
