// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Misc/LowLevelFunctions.h"
#include "Components/ActorComponent.h"
#include "Components/StaticMeshComponent.h"
#include "ProfessionalismComponent.generated.h"

class ASeerAttachActor;

UENUM(BlueprintType)
enum class EProfessionalType : uint8
{
	None,
	Seer,	// 占卜家
};

USTRUCT()
struct FSeerInitParam
{
	GENERATED_BODY()
	
	FString ActorClass;
	FName AttachSocket;
	FVector SocketIdleRelLoc;
	FVector SocketRunRelLoc;
	FVector SocketSprintRelLoc;
	FRotator SocketRelRot;
	bool bDoCollision;
	float ProbeSize;
	TArray<int> CollisionChannels;
	float BezierStep;
	float BezierStepMaxDist;
	float BezierSpeedAlpha;
	float BezierLagSpeed;
	float BezierDirectionMultiplier;
	float AttachRotationLagSpeed;
	bool bClampPitch;
	float PitchAngleMin;
	float PitchAngleMax;
	float FaceToDirTolerance;
	float RotateRoundTime;
};

USTRUCT()
struct FSeerStaticMeshComponent
{
	GENERATED_BODY()
	
	void ResetMeshComponent()
	{
		if (StaticMeshComponent)
		{
			StaticMeshComponent->SetStaticMesh(nullptr);
			bInitMeshAsset = false;
		}
	}
	
	UPROPERTY()
	UStaticMeshComponent* StaticMeshComponent = nullptr;

	bool bInitMeshAsset = false;
};

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class KGCHARACTER_API UProfessionalismComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UProfessionalismComponent();
	~UProfessionalismComponent();

	virtual void ResetToDefaultsForCache() override;
	void SetComponentSignificance(float Significance, bool bNeverSkip = false, bool bTickEvenIfNotRendered = false, bool bAllowReducedWork = true, bool bForceInterpolate = false);
protected:
	// Called when the game starts
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	
#pragma region Seer
	UFUNCTION(BlueprintCallable)
	void InitSeerFrontActor(FString FActorClass, FName FAttachSocket, float RelLocX, float IdleRelLocY, float RunRelLocY, float SprintRelLocY, float IdleRelLocZ, float RunRelLocZ, float SprintRelLocZ,
		FRotator FSocketRelRot, bool bFDoCollision, float FProbeSize, const TArray<int>& CollisionChannels, float FBezierStep, float FBezierStepMaxDist, float FBezierSpeedAlpha, float FBezierLagSpeed,
		float FBezierDirectionMultiplier, float FAttachRotationLagSpeed, bool bFClampPitch, float FPitchAngleMin, float FPitchAngleMax, float FFaceToDirTolerance, float FRotateRoundTime);
	
	UFUNCTION(BlueprintCallable)
	void InitSeerBackActor(FString BActorClass, FName BAttachSocket, FVector BSocketRelLoc, FRotator BSocketRelRot, bool bBDoCollision, float BProbeSize, const TArray<int>& CollisionChannels, float BBezierStep, float BBezierStepMaxDist,
		float BBezierSpeedAlpha, float BBezierLagSpeed, float BBezierDirectionMultiplier, float BAttachRotationLagSpeed, bool bBClampPitch, float BPitchAngleMin, float BPitchAngleMax, float BFaceToDirTolerance, float BRotateRoundTime);

	UFUNCTION(BlueprintType)
	void InitSeerCardParam(const TArray<FName>& HideBoneNameList, const TArray<FName>& OneCardNameList, const TArray<FName>& TwoCardNameList, const TArray<FName>& ThreeCardNameList, const TArray<FName>& FourCardNameList,
		const TArray<FName>& FiveCardNameList, FString FrontCardAnimPath);

	UFUNCTION(BlueprintType)
	void RegisterSeerMeshIDWithPath(int IDOne, FString PathOne, int IDTwo, FString PathTwo);
	
	UFUNCTION(BlueprintCallable)
	void RemoveBackCardAndAddFrontCard(int MeshID, int Index);

	UFUNCTION(BlueprintCallable)
	void RemoveBackCardAndAddFrontCardList(const TArray<int>& CardIDList);

	UFUNCTION(BlueprintCallable)
	void RecoverySeerFrontOneCard(int Index);
	
	UFUNCTION(BlueprintCallable)
	void RecoverySeerCard();

	// 武器溶解目前效果比较特殊, 目前是为剧情定制的接口, 需要传入 bWeaponDissolve=true
	// 对于溶入来说, 前方卡牌直接出现, 后面卡牌播放溶入特效+材质效果
	// 对于溶出来说, 前方卡牌直接消失, 后面卡牌直接消失+溶解特效
	UFUNCTION(BlueprintCallable)
	void UpdateSeerProfessionalActorVisibility(bool bVisible, int DissolveID, bool bWeaponDissolve=false);

	UFUNCTION(BlueprintType)
	void SyncSeerAnimParam(class UBaseAnimInstance* ParentAnimIns, float DeltaSeconds);

	UFUNCTION(BlueprintType)
	void SeerBackActorCrossfadeAnim(FName StateMachine, FName LocoStateName, float TranslationTime);

	void SeerUpdateFrontCardView();
	void OnSeerFrontActorClassLoaded(int InLoadID, UObject* LoadedAsset);
	void OnSeerBackActorClassLoaded(int InLoadID, UObject* LoadedAsset);
	void OnSeerFrontCardExpandAnimLoaded(int InLoadID, UObject* LoadedAsset);
	void OnSeerCardStaticMeshLoaded(int InLoadID, UObject* LoadedAsset, TWeakObjectPtr<UStaticMeshComponent> StaticMeshComponent);
	
	void GetSeerAttachActors(TArray<AActor*>& OutAttachActors);
	
private:
	UPROPERTY()
	ASeerAttachActor* SeerForwardActor = nullptr;
	FSeerInitParam SeerForwardInitParam;
	bool bSeerFrontInit = false;
	
	UPROPERTY()
	ASeerAttachActor* SeerBackActor = nullptr;
	FSeerInitParam SeerBackInitParam;
	bool bSeerBackInit = false;

	// 背部骨骼隐藏顺序列表
	TArray<FName> SeerHideBoneNameList;
	// 前面骨骼名称列表
	TMap<int, TArray<FName>> SeerCardBoneNameListMap;
	// 前面显示的卡牌静态模型列表
	TArray<int> SeerFrontCardPathList;
	// ID 槽位对应 Mesh 路径
	TMap<int, FString> SeerMapOfMeshPath;

	UPROPERTY(Transient)
	int FrontCardListOneID;
	UPROPERTY(Transient)
	TArray<FSeerStaticMeshComponent> SeerFrontCardListOne;

	UPROPERTY(Transient)
	int FrontCardListTwoID;
	UPROPERTY(Transient)
	TArray<FSeerStaticMeshComponent> SeerFrontCardListTwo;

	UPROPERTY(Transient)
	TObjectPtr<class UAnimSequenceBase> SeerFrontCardExpandAnim = nullptr;
	
	int SeerCurBackHideIndex = -1;
	bool bLogicVisibility = true;
	int DissolveEffectID = -1;
	TArray<int> SeerFrontCardPathListCache;
	
#pragma endregion 
	
private:
	// 职业类型
	EProfessionalType ProfessionalType = EProfessionalType::None;
	
	int64 FrontCardUniqueID = -1;
	FVector FrontCardRelLocation = FVector::ZeroVector;
	TArray<int> AssetLoadIDList;
};
