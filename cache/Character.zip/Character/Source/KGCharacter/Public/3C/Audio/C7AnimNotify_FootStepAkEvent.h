﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "C7AnimNotify_FootStepAkEvent.generated.h"

/**
 * 
 */
UCLASS()
class KGCHARACTER_API UC7AnimNotify_FootStepAkEvent : public UAnimNotify
{
	GENERATED_BODY()

protected:
	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) override;

public:
#pragma region FootStepAudio
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (Category = "脚步音效"))
	class UAkAudioEvent* AkEvent = nullptr;

	/**
	 * 是否需要进行脚步路径拼接,如果不勾选,则只播放配置的Event
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "是否进行路径拼接", Category = "脚步音效"))
	bool bNeedSplice = true;

#pragma endregion FootStepAudio

#pragma region ActionAudio
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (Category = "动作音效"))
	class UAkAudioEvent* ActionAkEvent = nullptr;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "是否仅P1播放", Category = "动作音效"))
	bool bMainPlayerOnly = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "是否区分时装材质", Category = "动作音效"))
	bool bSplitFashion = false;

#pragma endregion ActionAudio

#pragma region Effect
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "特效偏移", Category = "特效"))
	FTransform NiagaraTransform;

	/**
	 * 位置偏移基于Socket当前位置,朝向偏移基于当前角色实际朝向
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "特效播放基准骨骼", Category = "特效"))
	FName NiagaraBaseSocket;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "特效是否挂接", Category = "特效"))
	bool bNiagaraAttach;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "挂接时是否使用绝对朝向", Category = "特效"))
	bool bNiagaraUseAbsoluteRotation = true;

	/**
	 * 挂接时不生效
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "特效是否贴地", Category = "特效"))
	bool bNiagaraStickGround;

#pragma endregion Effect

public:
	static FString GetNiagaraTerrainName(AActor* InActor);

private:
	void TriggerFootStepAudio(USkeletalMeshComponent* MeshComp);
	void TriggerActionAudio(USkeletalMeshComponent* MeshComp);
	void TriggerNiagara(USkeletalMeshComponent* MeshComp);
	void TriggerFootprint(const USkeletalMeshComponent* MeshComp, const class URoleMovementComponent* RoleMovementComp, const FString& CurrentTerrainName, const FName& FootprintSocket);
};
