#pragma once
#include "CoreMinimal.h"

DECLARE_LOG_CATEGORY_EXTERN(LogAudioNotify, Log, All);

enum ENotifyAkEventPostType
{
	Forbid,
	EditorPreview, // 打开SK资产时进行预览
	PureSkeletal, // LA中的纯SkeletalMeshActor
	LuaEntity,
};

class FKGAudioNotifyHelper
{
public:
	static ENotifyAkEventPostType GetPostType(class USkeletalMeshComponent* SkComp);
	static bool IsMajorUnit(class ICppEntityInterface* LuaEntity);
	static FString GetTerrainName(class UKGAkAudioManager* AudioMgr, class ICppEntityInterface* LuaEntity);
	static const FString MainPlayerSuffix;;
};
