// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "AkAudioInputComponent.h"
#include "Misc/CommonDefines.h"
#include "KGAudioInputComponent.generated.h"


UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class KGCHARACTER_API UKGAudioInputComponent : public UAkAudioInputComponent
{
	GENERATED_BODY()

public:
	int32 PlayAudioInputEvent(const TArray<uint8>& WavData);
	void PauseAudioInputEvent(bool InPause);
	void StopAudioInputEvent();

protected:
	virtual bool FillSamplesBuffer(uint32 NumChannels, uint32 NumSamples, float** BufferToFill) override;
	virtual void GetChannelConfig(AkAudioFormat& AudioFormat) override;

private:
	TArray<TArray<float>> NonInterleavedData;
	uint32 FileOffset = 0;
	bool bPlaying = false;
	uint32 SrcSampleRate = 0;
	int32 SrcNumChannels = 0;
	uint32 SrcNumSamples = 0;
	bool bPause = false;
};
