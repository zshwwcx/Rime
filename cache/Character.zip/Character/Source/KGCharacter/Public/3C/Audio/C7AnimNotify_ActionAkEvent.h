﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "C7AnimNotify_ActionAkEvent.generated.h"

/**
 * 有外部直接调Actor的Trick使用,所以单独封装一层
 */
UCLASS()
class KGCHARACTER_API UC7AnimNotify_ActionAkEvent : public UAnimNotify
{
	GENERATED_BODY()

public:
	static void RealPostActionAkEvent(USkeletalMeshComponent* MeshComp, class UAkAudioEvent* AkEvent, bool bMainPlayerOnly, bool bSplitFashion = false);

protected:
	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) override;

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	class UAkAudioEvent* AkEvent = nullptr;

	/**
	 * 是否仅1P播放
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bMainPlayerOnly = false;

	/**
	 * 是否区分时装材质
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bSplitFashion = false;
};
