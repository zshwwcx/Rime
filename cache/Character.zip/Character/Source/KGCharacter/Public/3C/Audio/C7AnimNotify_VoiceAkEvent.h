﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "C7AnimNotify_VoiceAkEvent.generated.h"


/**
 * 
 */
UCLASS()
class KGCHARACTER_API UC7AnimNotify_VoiceAkEvent : public UAnimNotify
{
	GENERATED_BODY()

protected:
	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) override;

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	class UAkAudioEvent* AkEvent = nullptr;

	/**
	 * 如果仅主角播放,则不会拼接_1P后缀
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "是否仅主角播放"))
	bool bMainPlayerOnly = false;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "是否拼接类型后缀"))
	bool bNeedSplice = true;
};
