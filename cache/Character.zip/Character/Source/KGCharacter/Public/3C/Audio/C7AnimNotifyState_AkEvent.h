// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "C7AnimNotifyState_AkEvent.generated.h"

class UAkAudioEvent;

/**
 * 区间型音频Notify,支持在区间开始和结束时播放音频 
 */
UCLASS()
class KGCHARACTER_API UC7AnimNotifyState_AkEvent : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference) override;
	virtual void NotifyTick(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float FrameDeltaTime, const FAnimNotifyEventReference& EventReference) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) override;

private:
	void PostNotifyStateEventOnLuaEntity(USkeletalMeshComponent* MeshComp, const FString& EventName, bool bFromTick);

public:
	/**
	 * 是否检测地表材质
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="是否检测地表材质"))
	bool bDetectTerrain = false;
	
	/**
	 * 进入State时触发的事件
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	UAkAudioEvent* BeginAkEvent;

	/**
	 * 离开State时触发的事件
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition="!bStopOnEnd", EditConditionHides))
	UAkAudioEvent* EndAkEvent;

	/**
	 * 是否NotifyState结束时直接停止音频
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="是否在NotifyState结束时直接停止音频"))
	bool bStopOnEnd;

	/**
	 * 淡出时间(秒)
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="淡出时间(秒)", EditCondition="bStopOnEnd", EditConditionHides))
	double StopBlend = 0.5f;

private:
	int32 PlayingID = 0;
	FString CurTerrainName;
	double LastTickTime = 0.f;
};
