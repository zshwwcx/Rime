local DialogueLoadBaseTask = kg_require("Gameplay.DialogueV2.AssetLoader.DialogueLoadBaseTask").DialogueLoadBaseTask
---@class DialogueAssetLoadTask : DialogueLoadBaseTask
---@field private handlerLoad number
---@field private arrayPreloadRes string[] @ 需要加载的资源路径
DialogueAssetLoadTask = DefineClass("DialogueAssetLoadTask", DialogueLoadBaseTask)

---@param dialogueID number
---@param dialogueConfig DialogueTable
---@param priority number
---@param arrayPreloadRes string[] @ 需要加载的资源路径
function DialogueAssetLoadTask:ctor(dialogueID, dialogueConfig, priority, arrayPreloadRes)
    self.handlerLoad = nil
    self.arrayPreloadRes = arrayPreloadRes
end

function DialogueAssetLoadTask:dtor()
    if self.handlerLoad then
        Game.AssetManager:RemoveAssetReferenceByLoadID(self.handlerLoad)
        Game.AssetManager:CancelLoadAsset(self.handlerLoad)
        self.handlerLoad = nil
    end
end

function DialogueAssetLoadTask:Load()
    local arrayPreloadRes = self.arrayPreloadRes
    if table.isNilOrEmpty(arrayPreloadRes) then
        return
    end

    self.startTimestamp = Game.GameTimeMS
    self.totalTime = 0
    self.handlerLoad = Game.AssetManager:AsyncLoadAssetListKeepReferenceID(arrayPreloadRes, self,
        "OnAsyncLoadCompleted", self.priority)
    Log.InfoFormat("[DialogueV2][DialogueAssetMgr][DialogueAssetLoadTask]%s Start loading dialogueID:%s at time:%s", 
        self.instanceInfo, self.dialogueID, self.startTimestamp)
    self.state = self.STATE_RUNNING
end 

function DialogueAssetLoadTask:Cancel()
    if not self:IsLoading() then
        Log.WarningFormat("[DialogueV2][DialogueAssetMgr][DialogueAssetLoadTask]Cancel task, but task is not loading, dialogueID:%s",
            self.dialogueID)
        return
    end
    
    Log.InfoFormat("[DialogueV2][DialogueAssetMgr][DialogueAssetLoadTask]Cancel load task:%s dialogueID:%s",
        self.instanceInfo, self.dialogueID)
    self.state = self.STATE_CANCELED
    self.OnCanceled:Broadcast()
    
    if self.handlerLoad then
        Game.AssetManager:RemoveAssetReferenceByLoadID(self.handlerLoad)
        Game.AssetManager:CancelLoadAsset(self.handlerLoad)
        self.handlerLoad = nil
    end
end

function DialogueAssetLoadTask:Unload()
    if self:IsCompleted() then
        Log.InfoFormat("[DialogueV2][DialogueAssetMgr][DialogueAssetLoadTask]Unload task:%s dialogueID:%s",
            self.instanceInfo, self.dialogueID)
        
        if self.handlerLoad then
            Game.AssetManager:RemoveAssetReferenceByLoadID(self.handlerLoad)
            Game.AssetManager:CancelLoadAsset(self.handlerLoad)
            self.handlerLoad = nil
        end
    elseif self:IsLoading() then
        self:Cancel()
    else
        Log.WarningFormat("[DialogueV2][DialogueAssetMgr][DialogueAssetLoadTask]Unload task, but task is not completed, dialogueID:%s",
            self.dialogueID)
    end
end

function DialogueAssetLoadTask:OnAsyncLoadCompleted(loadID, loadObjects)
    local time = Game.GameTimeMS
    self.totalTime = (time - self.startTimestamp) * 0.001
    Log.InfoFormat("[DialogueV2][DialogueAssetMgr][DialogueAssetLoadTask]Finished loading dialogueID:%s at time:%s, totalTime:%s seconds", 
        self.dialogueID, time, self.totalTime)
    self.state = self.STATE_COMPLETED
    self.OnCompleted:Broadcast(self, self.dialogueID)
end