local DialogueLoadBaseTask = kg_require("Gameplay.DialogueV2.AssetLoader.DialogueLoadBaseTask").DialogueLoadBaseTask
---@class DialogueSequenceLoadTask : DialogueLoadBaseTask
---@field private sequenceID number
DialogueSequenceLoadTask = DefineClass("DialogueSequenceLoadTask", DialogueLoadBaseTask)

---@param dialogueID number
---@param dialogueConfig DialogueTable
---@param priority  number
---@param sequenceID number
function DialogueSequenceLoadTask:ctor(dialogueID, dialogueConfig, priority, sequenceID)
    self.sequenceID = sequenceID
end

function DialogueSequenceLoadTask:dtor(dialogueID, dialogueConfig, priority)
    if self.sequenceHandle ~= nil then
        Game.SequenceManager:Terminate(self.sequenceHandle)
        self.sequenceHandle = nil
    end
end

function DialogueSequenceLoadTask:Load()
    local params = {
        ["CinematicType"] = Enum.CinematicType.DialogueSequence,
        ["AssetID"] = self.sequenceID,
        ["PreLoadType"] = Enum.SequencePreLoadType.PreLoadAssetAndActor,
        ["OnPreLoadFinished"] = function ()
            self:OnSequenceLoaded()
        end
    }

    self.startTimestamp = Game.GameTimeMS
    self.totalTime = 0
    self.sequenceHandle = Game.SequenceManager:PreLoadSequence(params)
    Log.InfoFormat("[DialogueV2][DialogueAssetMgr][DialogueSequenceLoadTask]%s Start loading sequence:%s at time:%s", 
        self.instanceInfo, self.sequenceID, self.startTimestamp)
end

function DialogueSequenceLoadTask:Cancel()
    if not self:IsLoading() then
        Log.WarningFormat("[DialogueV2][DialogueAssetMgr][DialogueAssetLoadTask]%s Cancel loading, but task is not loading, dialogueID:%s",
            self.instanceInfo, self.dialogueID)
        return
    end
    
    Log.InfoFormat("[DialogueV2][DialogueAssetMgr][DialogueSequenceLoadTask]%s Cancel loading sequence:%s",
        self.instanceInfo, self.sequenceID)
    
    if self.sequenceHandle ~= nil then
        Game.SequenceManager:Terminate(self.sequenceHandle)
        self.sequenceHandle = nil
    end
    self.state = self.STATE_CANCELED
end

function DialogueSequenceLoadTask:Unload()
    
end

function DialogueSequenceLoadTask:OnSequenceLoaded()
    local time = Game.GameTimeMS
    self.totalTime = (time - self.startTimestamp) * 0.001
    Log.InfoFormat("[DialogueV2][DialogueAssetMgr][DialogueSequenceLoadTask]Finished loading sequence:%s at time:%s, total time:%s seconds",
    self.sequenceID, time, self.totalTime)
    self.state = self.STATE_COMPLETED
    self.OnCompleted:Broadcast(self, self.dialogueID)
end

function DialogueSequenceLoadTask:IsTimeout()
    if self:IsLoading() then
        local sequenceHandle = self.sequenceHandle
        if sequenceHandle and Game.SequenceManager:GetPlayTaskByLoadID(sequenceHandle) == nil then
            -- 当SequenceManager里面将sequenceHandle清理掉了，直接返回超时
            Log.DebugFormat("[DialogueV2][DialogueAssetMgr][DialogueSequenceLoadTask]IsTimeout: sequenceHandle is nil. sequence:%s", self.sequenceID)
            return true
        end
        
        return Game.GameTimeMS - self.startTimestamp > self.thresholdTimeout
    end

    return false
end