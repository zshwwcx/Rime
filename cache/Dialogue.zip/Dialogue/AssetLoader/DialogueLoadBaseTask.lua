---@class DialogueLoadBaseTask : LuaClass
---@field protected instanceInfo string
---@field protected dialogueID number
---@field protected dialogueConfig DialogueTable
---@field public OnCompleted LuaMulticastDelegate
---@field public OnCanceled LuaMulticastDelegate
---@field protected priority number
---@field protected state number @ 状态， 0:未开始 1:执行中 2:完成 3:取消
---@field protected startTimestamp number @ 开始加载的时间戳，使用Game.GameTimeMS，单位：毫秒
---@field protected totalTime number @ 加载所用时间，单位：秒
---@field protected thresholdTimeout number @ 超时时间, 单位：秒
DialogueLoadBaseTask = DefineClass("DialogueLoadBaseTask")

function DialogueLoadBaseTask:ctor(dialogueID, dialogueConfig, priority)
    self.instanceInfo = tostring(self)
    self.dialogueID = dialogueID
    self.dialogueConfig = dialogueConfig

    self.thresholdTimeout = 60
    self.STATE_NONE = 0
    self.STATE_RUNNING = 1
    self.STATE_COMPLETED = 2
    self.STATE_CANCELED = 3

    self.priority = priority
    self.OnCompleted = LuaMulticastDelegate.new()
    self.OnCanceled = LuaMulticastDelegate.new()

    self.state = self.STATE_NONE
    self.startTimestamp = 0
end 

function DialogueLoadBaseTask:dtor()
    self.OnCompleted:delete()
    self.OnCompleted = nil

    self.OnCanceled:delete()
    self.OnCanceled = nil
    self.dialogueConfig = nil
    self.state = self.STATE_NONE
    self.startTimestamp = nil
    self.totalTime = 0
end

function DialogueLoadBaseTask:Load()
    
end

function DialogueLoadBaseTask:Cancel()

end

function DialogueLoadBaseTask:Unload()

end

function DialogueLoadBaseTask:IsCompleted()
    return self.state == self.STATE_COMPLETED
end

function DialogueLoadBaseTask:IsCanceled()
    return self.state == self.STATE_CANCELED
end

function DialogueLoadBaseTask:IsLoading()
    return self.state == self.STATE_RUNNING
end

---@return boolean
function DialogueLoadBaseTask:IsTimeout()
    if self:IsLoading() then
        return Game.GameTimeMS - self.startTimestamp > self.thresholdTimeout
    end
    
    return false
end

---@return number?
function DialogueLoadBaseTask:GetStartTimestamp()
    return self.startTimestamp
end

---@return number?
function DialogueLoadBaseTask:GetFinishedTimestamp()
    if self:IsCompleted() then
        return self.startTimestamp + self.totalTime * 1000
    end
    
    return nil
end