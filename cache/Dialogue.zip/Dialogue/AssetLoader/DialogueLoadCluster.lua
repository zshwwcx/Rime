local DialogueLoadBaseTask = kg_require("Gameplay.DialogueV2.AssetLoader.DialogueLoadBaseTask").DialogueLoadBaseTask

---@class DialogueLoadCluster : DialogueLoadBaseTask
---@field protected dialogueID number
---@field protected dialogueConfig DialogueTable
---@field public OnCompleted LuaMulticastDelegate
---@field public OnCanceled LuaMulticastDelegate
---@field protected priority number
---@field protected tasks DialogueLoadBaseTask[]
---@field protected timeCache number @ 缓存最大时间，单位秒
---@field protected cachedTimestamp number
DialogueLoadCluster = DefineClass("DialogueLoadCluster", DialogueLoadBaseTask)

local DialogueAssetLoadTask = kg_require("Gameplay.DialogueV2.AssetLoader.DialogueAssetLoadTask").DialogueAssetLoadTask
local DialogueSequenceLoadTask = kg_require("Gameplay.DialogueV2.AssetLoader.DialogueSequenceLoadTask").DialogueSequenceLoadTask
local DialogueAnimLoadTask = kg_require("Gameplay.DialogueV2.AssetLoader.DialogueAnimLoadTask").DialogueAnimLoadTask

function DialogueLoadCluster:ctor(dialogueID, dialogueConfig, priority)
    self.tasks = {}
    self.lookupTasksDone = setmetatable({}, { __mode = "k" })
    self.timeCache = 60
    self.cachedTimestamp = 0

    --TODO: limunan,这个是临时处理，等0205版本结束后需要移除
    ---@type number[] @ 可以使用预加载动画的资产列表
    self.whitePreloadAnimsAssetIDs = { 10040707, 10040647, 10040648, 10040681, 10040682 }
end

function DialogueLoadCluster:dtor()
    for _, task in ipairs(self.tasks) do
        task:delete()
    end
    table.clear(self.tasks)
    table.clear(self.lookupTasksDone)
end

function DialogueLoadCluster:Load()
    local dialogueConfig = self.dialogueConfig
    if not dialogueConfig then
        Log.DebugWarningFormat("[DialogueV2][]")
        return nil
    end

    local insert = table.insert
    local arrayPreloadAssets = {}
    local arraySequences = {}

    -- TODO：limunan, 兼容老数据PreLoadArray，后续需要移除，
    for _, path in ksbcipairs(dialogueConfig.PreLoadArray) do
        insert(arrayPreloadAssets, path)
    end

    local preloadRes = dialogueConfig.PreloadRes
    if preloadRes then
        ---@param res FDialoguePreloadItem
        for _, res in ksbcipairs(dialogueConfig.PreloadRes) do
            if res.Type == DialogueConst.PRELOAD_RES_TYPE.Asset then
                insert(arrayPreloadAssets, res.PathName)
            elseif res.Type == DialogueConst.PRELOAD_RES_TYPE.Sequence then
                insert(arraySequences, tonumber(res.PathName))
            else
                Log.DebugWarningFormat(
                    "[DialogueV2][DialogueAssetMgr][DialogueAssetLoadTask]OnExecute, Unknown res type:%s %s", res.type,
                    res.PathName)
            end
        end
    end

    local countPreloadAssets = #arrayPreloadAssets
    if countPreloadAssets > 0 then
        ---@type DialogueAssetLoadTask
        local task = self:doTask(DialogueAssetLoadTask, arrayPreloadAssets)
        if task and task:IsCompleted() then
            self:onTaskCompleted(task, self.dialogueID)
        end

        Log.DebugFormat("[DialogueV2][DialogueAssetMgr][DialogueAssetLoadTask]Execute asset load task: %s, dialogueID:%s",
            task.instanceInfo, self.dialogueID)
    end

    local countSequences = #arraySequences
    if countSequences > 0 then
        for _, seqID in ipairs(arraySequences) do
            ---@type DialogueSequenceLoadTask
            local task = self:doTask(DialogueSequenceLoadTask, seqID)
            if task and task:IsCompleted() then
                self:OnTaskCompleted(task, self.dialogueID)
            end
            Log.DebugFormat(
                "[DialogueV2][DialogueAssetMgr][DialogueSequenceLoadTask]Execute sequence load task: %s, dialogueID:%s",
                task.instanceInfo, self.dialogueID)
        end
    end

    local bHasAnimLoadTasks = self:preloadAnims(dialogueConfig.PreloadAnims)

    if countPreloadAssets > 0 or countSequences > 0 or bHasAnimLoadTasks then
        self.state = self.STATE_RUNNING
        self.startTimestamp = Game.GameTimeMS
        Log.DebugFormat("[DialogueV2][DialogueAssetMgr][DialogueLoadCluster]Start loading dialogue[%s] at time:%s",
            self.dialogueID, self.startTimestamp)
    else
        self.OnCompleted:Broadcast(self, self.dialogueID)
        self.state = self.STATE_COMPLETED
        Log.DebugFormat("[DialogueV2][DialogueAssetMgr][DialogueLoadCluster]dialogue[%s] has no resource needed to load",
            self.dialogueID)
    end
end

function DialogueLoadCluster:Cancel()
    if not self:IsLoading() then
        return
    end

    for _, task in ipairs(self.tasks) do
        task:Cancel()
    end

    self.state = self.STATE_CANCELED
    self:refreshCacheTimestamp()
end

function DialogueLoadCluster:Unload()
    for _, task in ipairs(self.tasks) do
        task:Unload()
    end
end

---@param task DialogueLoadBaseTask
---@param dialogueID number
function DialogueLoadCluster:OnTaskCompleted(task, dialogueID)
    Log.DebugFormat("[DialogueV2][DialogueAssetMgr][DialogueLoadCluster]OnTaskCompleted, task:%s", task.instanceInfo)
    local isDone = self.lookupTasksDone[task]
    if isDone ~= nil then
        self.lookupTasksDone[task] = true

        if self:areAllTasksDone() then
            self:refreshCacheTimestamp()
            local time = Game.GameTimeMS
            self.totalTime = (time - self.startTimestamp) * 0.001
            Log.DebugFormat(
                "[DialogueV2][DialogueAssetMgr][DialogueLoadCluster]Finished loading dialogue[%s] at time:%s, using time:%s seconds",
                dialogueID, time, self.totalTime)
            self.OnCompleted:Broadcast(self, self.dialogueID)
            self.state = self.STATE_COMPLETED
        end
    end
end

---@protected
---@param taskClass DialogueLoadBaseTask
---@param dialogueID number
---@param dialogueConfig DialogueTable
---@param priority  number
---@return DialogueLoadBaseTask
function DialogueLoadCluster:instanceTask(taskClass, dialogueID, dialogueConfig, priority, ...)
    assert(taskClass, "taskClass is nil")

    ---@type DialogueSequenceLoadTask
    local task = taskClass.new(dialogueID, dialogueConfig, priority, ...)
    task.OnCompleted:Add(self, "OnTaskCompleted")
    task.OnCanceled:Add(self, "OnTaskCanceled")
    return task
end

---@protected
---@param taskClass DialogueLoadBaseTask
---@return DialogueLoadBaseTask?
function DialogueLoadCluster:doTask(taskClass, ...)
    local task = self:instanceTask(taskClass, self.dialogueID, self.dialogueConfig, self.priority, ...)
    if task then
        task:Load()
        self.tasks[#self.tasks + 1] = task
        self.lookupTasksDone[task] = false
    end

    return task
end

---@protected
---@return boolean
function DialogueLoadCluster:areAllTasksDone()
    for _, task in ipairs(self.tasks) do
        if not self.lookupTasksDone[task] then
            return false
        end
    end

    return true
end

---@protected
function DialogueLoadCluster:refreshCacheTimestamp()
    self.cachedTimestamp = Game.GameTimeMS
end

---@return boolean
function DialogueLoadCluster:IsCacheTimeout()
    if self:IsCompleted() or self:IsCanceled() then
        return Game.GameTimeMS - self.cachedTimestamp > self.timeCache
    end

    return false
end

---@public
---@param whiteDialogueIDs number|number[] @ 白名单对话ID
function DialogueLoadCluster:PurgeTimeout(whiteDialogueIDs)
    if type(whiteDialogueIDs) == 'number' and self.dialogueID == whiteDialogueIDs then
        self:refreshCacheTimestamp()
        return
    elseif type(whiteDialogueIDs) == 'table' and table.contains(whiteDialogueIDs, self.dialogueID) then
        self:refreshCacheTimestamp()
        return
    end

    if self:IsCacheTimeout() then
        -- 卸载缓存超时的对话资源
        Log.DebugWarningFormat(
            "[DialogueV2][DialogueAssetMgr][DialogueLoadCluster]cache is timeout and unload all resource, dialogueID:%s",
            self.dialogueID)
        self:Unload()
        return
    elseif self:IsTimeout() then
        -- 超时取消所有任务
        Log.DebugWarningFormat(
            "[DialogueV2][DialogueAssetMgr][DialogueLoadCluster]Timeout and cancel/unload all loading tasks, dialogueID:%s",
            self.dialogueID)
        self:Cancel()
        self:Unload()
        return
    end

    ---@param task DialogueLoadBaseTask
    for _, task in pairs(self.tasks) do
        if task and task:IsTimeout() then
            task:Cancel()
        end
    end
end

---@param preloadAnimList string[] @ 预加载动画列表
---@return boolean
function DialogueLoadCluster:preloadAnims(preloadAnimList)
    if not preloadAnimList then
        return false
    end

    local typeInfo = type(preloadAnimList)
    if typeInfo == 'table' and #preloadAnimList <= 0 then
        return false
    end

    -- TODO:limunan，0205版本后移除这个白名单功能
    if not table.contains(self.whitePreloadAnimsAssetIDs, self.dialogueID) then
        Log.DebugWarningFormat(
            "[DialogueV2][DialogueAssetMgr][DialogueLoadCluster]dialogueID:%s is not in white list, can't preload anims",
            self.dialogueID)
        return false
    end
    
    local isValidAnimPaths = self.isValidAnimPaths
    local bHasTasks = false
    for _, animPaths in ksbcipairs(preloadAnimList) do
        if isValidAnimPaths(animPaths) then
            self:doTask(DialogueAnimLoadTask, animPaths)
            bHasTasks = true
        end
    end

    return bHasTasks
end

---@param animPaths table|userdata
---@return boolean
function DialogueLoadCluster.isValidAnimPaths(animPaths)
    local typePaths = type(animPaths)
    if typePaths == 'userdata' then
        return animPaths ~= nil
    elseif typePaths == 'table' then
        return not table.isNilOrEmpty(animPaths)
    end

    return false
end
