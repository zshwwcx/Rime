local DialogueLoadBaseTask = kg_require("Gameplay.DialogueV2.AssetLoader.DialogueLoadBaseTask").DialogueLoadBaseTask
---@class DialogueAnimLoadTask : DialogueLoadBaseTask
---@field private sequenceID number
DialogueAnimLoadTask = DefineClass("DialogueAnimLoadTask", DialogueLoadBaseTask)

local AnimLibHelper = kg_require("GamePlay.3C.RoleComposite.AnimLibHelper").AnimLibHelper

---@param dialogueID number
---@param dialogueConfig DialogueTable
---@param priority  number
---@param animPaths BP_PreloadAnimItem_C
---@param bIsPlayer boolean
function DialogueAnimLoadTask:ctor(dialogueID, dialogueConfig, priority, animPaths)
    self.animPaths = animPaths
    self.animPathList = {}
    self.bIsPlayer = animPaths.bIsPlayer
    self.performerName = animPaths.PerformerName
    self:buildAnimPathList()
end

function DialogueAnimLoadTask:dtor(dialogueID, dialogueConfig, priority)
    if self.loadHandle ~= nil then
        Game.WorldManager.AnimationManager:CancelPreload(self.loadHandle)
        self.loadHandle = nil
    end
end

function DialogueAnimLoadTask:Load()
    self.startTimestamp = Game.GameTimeMS
    self.totalTime = 0

    local animPaths = self.animPathList

    if table.isNilOrEmpty(animPaths) then
        Log.InfoFormat(
            "[DialogueV2][DialogueAssetMgr][DialogueAnimLoadTask]start loading: No anims to load, performer:%s",
            self.performerName)
        self:OnAnimsLoaded()
        return
    end

    self.loadHandle = Game.WorldManager.AnimationManager:RequestPreloadAnims(false,
        animPaths, self, "OnAnimsLoaded")

    Log.InfoFormat(
        "[DialogueV2][DialogueAssetMgr][DialogueAnimLoadTask]%s Start loading anims at time:%s, performer:%s load handle:%s \n\t%s",
        self.instanceInfo, self.startTimestamp, self.performerName, self.loadHandle, table.concat(animPaths, "\n\t"))
end

function DialogueAnimLoadTask:Cancel()
    if not self:IsLoading() then
        return
    end

    Log.InfoFormat("[DialogueV2][DialogueAssetMgr][DialogueAnimLoadTask]%s Cancel loading anims, performer:%s load handle:%s",
        self.instanceInfo, self.performerName, self.loadHandle)
    if self.loadHandle ~= nil then
        Game.WorldManager.AnimationManager:CancelPreload(self.loadHandle)
        self.loadHandle = nil
    end
    self.state = self.STATE_CANCELED
end

function DialogueAnimLoadTask:Unload()

end

function DialogueAnimLoadTask:OnAnimsLoaded()
    local time = Game.GameTimeMS
    self.totalTime = (time - self.startTimestamp) * 0.001
    Log.InfoFormat(
        "[DialogueV2][DialogueAssetMgr][DialogueAnimLoadTask]Finished loading anims:%s at time:%s, total time:%s seconds, performer:%s",
        self.loadHandle, time, self.totalTime, self.performerName)
    self.state = self.STATE_COMPLETED
    self.OnCompleted:Broadcast(self, self.dialogueID)
end

function DialogueAnimLoadTask:buildAnimPathList()
    local animPaths = self.animPaths
    if not animPaths or not animPaths.AnimPaths then
        return
    end

    local insert = table.insert
    if not self.bIsPlayer then
        for _, path in ksbcpairs(animPaths.AnimPaths) do
            insert(self.animPathList, path)
        end
        return
    end

    local me = Game.me
    if me then
        local animID = me:GetAnimDataID()
        if animID then
            local playerAnimPaths = self.animPathList
            local GetAnimFeatureNeedAnims = AnimLibHelper.GetAnimFeatureNeedAnims
            local contains = table.contains
            for _, animFeature in ksbcpairs(animPaths.AnimPaths) do
                local paths = GetAnimFeatureNeedAnims(animID, animFeature)
                if paths and #paths > 0 then
                    for _, p in pairs(paths) do
                        if not contains(playerAnimPaths, p) then
                            insert(playerAnimPaths, p)
                        end
                    end
                end
            end
        end
    end
end
