---@class DialogueSequenceManager
DialogueSequenceManager = DefineClass("DialogueSequenceManager")
local PostProcessConst = kg_require("Gameplay.Effect.PostProcessConst")
local PP_SOURCE_TYPE = PostProcessConst.PP_SOURCE_TYPE

function DialogueSequenceManager:ctor()
	self.CurrentLevelID = 0
	self.currentTaskHandle = 0
	self.CurrentSequenceCameraID = -1
	self.currentStartPlayTime = 0
end

function DialogueSequenceManager:dtor()
	self.CurrentLevelID = 0
	self.currentTaskHandle = 0
	self.CurrentSequenceCameraID = -1
	self.currentStartPlayTime = 0
end

function DialogueSequenceManager:Init()
	self:RegisterEvent()
end

function DialogueSequenceManager:RegisterEvent()
	Game.GlobalEventSystem:AddListener(EEventTypesV2.LEVEL_ON_LEVEL_LOAD_START, "OnLevelLoadStart", self)
end

function DialogueSequenceManager:UnInit()
	self:UnRegisterEvent()
end

function DialogueSequenceManager:UnRegisterEvent()
	Game.GlobalEventSystem:RemoveListener(EEventTypesV2.LEVEL_ON_LEVEL_LOAD_START, "OnLevelLoadStart", self)
end

function DialogueSequenceManager:OnLevelLoadStart()
	local levelSequenceTasks = Game.SequenceManager:GetPlayTasksByCinematicType(Enum.CinematicType.DialogueSequence)
	for _, task in pairs(levelSequenceTasks) do
		if task then
			task:Terminate()
		end
	end

	self.CurrentLevelID = self.CurrentLevelID + 1
end

function DialogueSequenceManager:PlayDialogueSequence(Params, bResetPlay)
	local SequenceData = Game.TableData.GetDilaogueSeuqenceDataRow(Params.AssetID)
	if not SequenceData then
		Log.DebugWarningFormat("[Enter] no LevelSequenceData for %s", Params.AssetID)
		if Params.OnCinematicFinished then
			Params.OnCinematicFinished()
		end
		return
	end

	Params.levelID = self.CurrentLevelID
	--Params.bPauseAtEnd = true
	Params.bAutoPlay = false
	Params.CinematicType = Enum.CinematicType.DialogueSequence
	Params.bDisableCharacterLight = SequenceData.DisableCharacterLight
	if Params.bLoop == nil then
		Params.bLoop = SequenceData.bLoop
	end
	Params.OnSequencePlayCallBack = function(task)
		self:OnPlayerPlayCallback(task)
	end
	Params.OnSequencePauseCallBack = function(loadHandleID)
		self:OnPlayerPauseCallback(loadHandleID)
	end
	Params.OnSequenceResumeCallBack = function(loadHandleID)
		self:OnPlayerResumeCallback(loadHandleID)
	end
	Params.OnSequenceFinishedCallBack = function(task)
		self:OnPlayerFinishedCallback(task)
	end
	Params.OnStartPlayInternalCallBack = function(loadHandleID)
		self:StartPlayInternal(loadHandleID)
	end
	
	Params.OnSequenceCameraCutUpdate = function(task, cameraID)
		self:OnSequenceCameraCut(task, cameraID)
	end

	Params.OnLogicStopCallBack = function(loadHandleID)
		self:OnPlayerStopCallback(loadHandleID)
	end
	Params.OnLogicFinished = function(loadHandleID)
		self:OnLogicFinished(loadHandleID)
	end
	if not bResetPlay then
		self.currentTaskHandle = Game.SequenceManager:PlaySequence(Params)
	else
		local cacheTask = Game.SequenceManager:FindPlayTaskByTypeAndAssetID(Enum.CinematicType.DialogueSequence, Params.AssetID)
		if cacheTask then
			self.currentTaskHandle = cacheTask:GetLoadHandleID()
			Game.SequenceManager:RePlay(self.currentTaskHandle, Params)
		end
	end
	return self.currentTaskHandle
end

function DialogueSequenceManager:StopLevelSequence(loadHandleID)
	local StopTask = Game.SequenceManager:GetPlayTaskByLoadID(loadHandleID)
	if StopTask then
		Game.SequenceManager:Terminate(StopTask:GetLoadHandleID())
		
		local bInEditor = Game.BSManager and Game.BSManager.bIsInEditor
		if not bInEditor  then
			Game.CameraManager:EnableCutSceneCamera(false)
		end
		self.CurrentSequenceCameraID = -1
	end
end

function DialogueSequenceManager:OnPlayerPlayCallback(Task)
	Log.Debug("DialogueSequenceManager OnPlayerPlayCallback")
	if Task then
		local playParams = Task:GetPlayParams()
		if playParams and playParams.OnCinematicPlay then
			playParams.OnCinematicPlay()
		end
		self.currentStartPlayTime =  Game.GameTimeMS
		Log.DebugFormat("[DialogueSequenceManager] DialogueSequence OnPlayerPlayCallback GameTimeMS: %s loadHandleID: %s", Game.GameTimeMS, self.currentTaskHandle)
	end
end


--- sequence绑定暂停回调
function DialogueSequenceManager:OnPlayerPauseCallback(loadHandleID)
	local currenTask = Game.SequenceManager:GetPlayTaskByLoadID(loadHandleID)
	if not currenTask then
		Log.DebugWarning("[DialogueSequenceManager] OnPlayerPauseCallback Failed Task Is nil")
		return
	end
	--- DialogueSequenceManager LevelSequence层的回调
	local playParams = currenTask:GetPlayParams()
	if playParams then
		if playParams.OnCinematicPause then
			playParams.OnCinematicPause()
		end
	end
end

function DialogueSequenceManager:OnPlayerResumeCallback(loadHandleID)
	local currenTask = Game.SequenceManager:GetPlayTaskByLoadID(loadHandleID)
	if not currenTask then
		Log.DebugWarning("[DialogueSequenceManager] OnPlayerResumeCallback Failed Task Is nil")
		return
	end
	--- CutScene LevelSequence层的回调
	local playParams = currenTask:GetPlayParams()
	if playParams then
		if playParams.OnCinematicResume then
			playParams.OnCinematicResume()
		end
	end
end

function DialogueSequenceManager:OnPlayerFinishedCallback(Task, LoadID)
	Log.Debug("DialogueSequenceManager OnPlayerFinishedCallback")
	if Task then
		local playParams = Task:GetPlayParams()
		if playParams and playParams.OnCinematicFinished then
			playParams.OnCinematicFinished()
		end
		local bInEditor = Game.BSManager and Game.BSManager.bIsInEditor
		if not bInEditor  then
			Game.CameraManager:EnableCutSceneCamera(false)
		end
		self:OnPlayBreakOrFinished(Task:GetLoadHandleID())
		if self.currentStartPlayTime ~= 0 then
			Log.DebugFormat("[DialogueSequenceManager] DialogueSequence GameTimeMS: %s TotalPlayTime: %s loadHandleID: %s", Game.GameTimeMS, (Game.GameTimeMS - self.currentStartPlayTime)/1000, self.currentTaskHandle)
			self.currentStartPlayTime =  0
		end
	end
	self.currentTaskHandle = 0
end

function DialogueSequenceManager:StartPlayInternal(loadHandleID)
	Log.Debug("DialogueSequenceManager OnPlayerStopCallback loadHandleID: ", loadHandleID)
	local task = Game.SequenceManager:GetPlayTaskByLoadID(loadHandleID)
	if not task then
		Log.DebugWarning("DialogueSequenceManager OnPlayerStopCallback Invalid Task loadHandleID: ", loadHandleID)
		return
	end
	self:UpdateLevelSequenceActorPostion()
	self:ChangeSequenceTransformOriginActor()
	self:DisalbePPStatus(true)
	Game.NewUIManager:OpenPanel(UIPanelConfig.SequencePanel, loadHandleID, true)
	local PlayParams = task:GetPlayParams()
	local bInEditor = Game.BSManager and Game.BSManager.bIsInEditor
	if not bInEditor  then
		Game.CameraManager:EnableCutSceneCamera(true, task:GetDirector(), false, PlayParams.bDisableCharacterLight, false)
		--if PlayParams.AssetID == 10000042 then
		--	Game.CameraManager:EnableCutSceneCamera(true, task:GetDirector(), false, PlayParams.bDisableCharacterLight, true)
		--else
		--	Game.CameraManager:EnableCutSceneCamera(true, task:GetDirector(), false, PlayParams.bDisableCharacterLight)
		--end
	end

	Game.AkAudioManager:SetGroupState(Enum.EAudioConstNew.CUTSCENE_GROUP, Enum.EAudioConstNew.IN_CUTSCENE_STATE)
end


function DialogueSequenceManager:DisalbePPStatus(bDisable)
	Game.NewPostProcessManager:DisablePPBySourceType(PP_SOURCE_TYPE.GAME, bDisable)
	Game.NewPostProcessManager:DisablePPBySourceType(PP_SOURCE_TYPE.CUTSCENE, bDisable)
end

function DialogueSequenceManager:UpdateLevelSequenceActorPostion(LoadID)
	local Task = Game.SequenceManager:GetPlayTaskByLoadID(LoadID)
	if not Task then
		return
	end
	local PlayParams = Task:GetPlayParams()
	local Transform = PlayParams and PlayParams.Transform
	local Position = Transform and Transform.Position
	local Rotator = Transform and Transform.Rotator
	if not Position then
		Position = FVector()
	end
	if not Rotator then
		Rotator = FRotator()
	end
	LuaScriptAPI.KAPI_Actor_SetLocation(Task:GetDirector(), Position)
	LuaScriptAPI.KAPI_Actor_SetRotation(Task:GetDirector(), Rotator)
end

function DialogueSequenceManager:ChangeSequenceTransformOriginActor(LoadID)
	local Task = Game.SequenceManager:GetPlayTaskByLoadID(LoadID)
	if not Task then
		return
	end
	local PlayParams = Task:GetPlayParams()
	if PlayParams.bUseTransformOriginActor == true then
		Game.SequenceManager:KAPI_ChangeSequenceTransformOriginActor(LoadID, Task:GetDirector())
	end
end

function DialogueSequenceManager:OnSequenceCameraCut(Task, CameraID)
	if not Task then
		return
	end
	local playParams = Task:GetPlayParams()
	if playParams.OnCameraCut then
		playParams.OnCameraCut(CameraID)
	end
	if Game.BSManager and Game.BSManager.bIsInEditor then
		if CameraID then
			if  self.CurrentSequenceCameraID ~= CameraID then
				Game.CameraManager:KAPI_Camera_SetViewTargetWithBlendByCameraComponentID(CameraID, 0, 0, 0, false)
				self.CurrentSequenceCameraID = CameraID
			end
		end
	end
end

function DialogueSequenceManager:OnPlayerStopCallback(loadHandleID)
	self:OnPlayBreakOrFinished(loadHandleID)
end

function DialogueSequenceManager:OnLogicFinished(loadHandleID)
	self:OnPlayBreakOrFinished(loadHandleID)
end

function DialogueSequenceManager:OnPlayBreakOrFinished(loadHandleID)
	local CurrentTask = Game.SequenceManager:GetPlayTaskByLoadID(loadHandleID)
	if not CurrentTask then
		Log.DebugWarning("[DialogueSequenceManager] OnPlayBreakOrFinished Failed loadHandleID: ", loadHandleID)
		return
	end
	self:DisalbePPStatus(false)
	Game.NewUIManager:ClosePanel("CutscenePlayVideoPanel")
	Game.NewUIManager:ClosePanel(UIPanelConfig.SequencePanel, true)
	-- 音乐Stop
	Game.AkAudioManager:PostEvent2D(Enum.EAudioConstNew.MUS_GLOBAL_CUTSCENE_NONE)

	Game.NewUIManager:ClosePanel("CutscenePlayVideoPanel") -- 确保这个Panel关闭了.
	
	-- Group设置
	Game.AkAudioManager:ResetGroupState(Enum.EAudioConstNew.CUTSCENE_GROUP)
	Log.DebugFormat("[DialogueSequenceManager] SequenceFrame OnPlayBreakOrFinished CurrentFrame: %s ",  import("KismetSystemLibrary").GetFrameCount())
end

function DialogueSequenceManager:SetFrameRange(startTime, duration)
	local Task = Game.SequenceManager:GetPlayTaskByLoadID(self.currentTaskHandle)
	if not Task then
		Log.DebugWarningFormat("[DialogueSequenceManager] SetFrameRange Failed loadHandleID: %s", self.currentTaskHandle)
		return
	end
	Game.SequenceManager:KAPI_LevelSequenceSetFrameRange(self.currentTaskHandle, startTime, duration)
end

function DialogueSequenceManager:FindPlayTaskByAssetID(AssetID)
	return Game.SequenceManager:FindPlayTaskByTypeAndAssetID(Enum.CinematicType.DialogueSequence, AssetID)
end

function DialogueSequenceManager:FindTaskLoadHandleIDByAssetID(AssetID)
	local Task = self:FindPlayTaskByAssetID(AssetID)
	if Task then
		return Task:GetLoadHandleID()
	end
	return nil
end

function DialogueSequenceManager:IsPlaying()
	if not self.currentTaskHandle then
		return false
	end
	return Game.SequenceManager:IsPlaying(self.currentTaskHandle)
end

function DialogueSequenceManager:JumptoFrame(ToFrame)
	if not self.currentTaskHandle then
		return false
	end
	Game.SequenceManager:KAPI_LevelSequenceJumpToFrame(self.currentTaskHandle, ToFrame)
end
