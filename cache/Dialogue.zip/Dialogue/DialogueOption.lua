---@class DialogueOption : LuaClass
---@field EpisodeID number @ 点击选项跳转到的目标小段ID
---@field DialogueLineIdx number @ 点击选项跳转到的目标小段的台本ID
---@field OptionID number @ 选项ID
---@field Order  number @ 选项顺序
---@field OptionText string @ 经过处理（如：人名替换、锁定文本替换）后的选项文本
---@field OptionTextCfg string @ 配置表中的选项文本
---@field LockVisible number @ 锁定提示显示方式
---@field LockText string @ 锁定提示文本
---@field bClose boolean @ 是否关闭对话
---@field SelectHide number @ 选项选择收是否隐藏
---@field HasBeenSelected boolean @ 选项是否已选
---@field LastOptionState DialogueOptionState
---@field OptionState DialogueOptionState
---@field DiceRollID number 骰子检定ID
---@field Icon string @ 选项图标路径
DialogueOption = DefineClass("DialogueOption")
kg_require("Gameplay.DialogueV2.DialogueOptionActions")

function DialogueOption:ctor()
	-- 静态数据
	self.OptionTextID = ""
	self.OptionText = "OptionString Unset"
    self.OptionTextCfg = ""
	self.LockVisible = 0
	self.LockText = ""
	self.bClose = false
	self.SelectHide = 0
	self.DiceRollID = 0
	self.ExtraAction = {}
	self.ReportServer = false
	self.Icon = nil
	self.OptionState = nil
	self.LastOptionState = nil
	
	-- 运行时需要的数据
    self.EpisodeID = 0
	self.Index = 0
	---@type DialogueEpisode
	self.episodeInstance = nil
	self.OptionID = nil
	self.OptionLineIdx = nil
	-- 是否已经选过
	self.HasBeenSelected = false
    -- 解锁动画是否已播放
    self.bUnlockAnimPlayed = false 

	---@type function[]
	self.OptionConditionChecker = {
		Pre = self.CheckOptionConditionPreOption,
		CompleteTask = self.CheckOptionConditionCompleteTask,
		Item = self.CheckOptionConditionItem,
		Qte = self.CheckOptionConditionQte,
		Dice = self.CheckOptionConditionDice,
		Mood = self.CheckOptionConditionMood,
		Price = self.CheckOptionConditionPrice,
		PlayerDistance = self.CheckOptionConditionPlayerDistance,
		MoodLevel = self.CheckMoodLevel,
		BargainStart = self.CheckBargainStart,
		TaskMark = self.CheckTaskMarkDefine,
	}
	
end

---@param episode DialogueEpisode
---@param OptionData FDialogueOption
---@param Index number
function DialogueOption:InitData(episode, OptionData, Index)
	if not OptionData then
		Log.Error("[DialogueV2]DialogueOption Init Data: OptionData is nil.")
	end
	
	self.episodeInstance = episode
	---@type _DialogueOptionTextRow
	local OptionConfigData = Game.TableData.GetDialogueOptionTextRow(OptionData.DialogueID)
	self.OptionID = OptionData.DialogueID
	self.OptionLineIdx = OptionData.DialogueLineIndex
	-- 有些DialogueID == 0，属于自动执行的option选项，无需走初始化逻辑，直接在runtime去执行它的condition了
	if OptionConfigData then
		self.OptionText = OptionConfigData.Text
		self.OptionTextCfg = OptionConfigData.Text
		self.LockVisible = OptionConfigData.LockVisible
		self.LockText = OptionConfigData.LockText
		self.SelectHide = OptionConfigData.SelectHide
		self.bClose = OptionConfigData.bClose
		self.ExtraAction = OptionConfigData.ExtraAction
		self.ReportServer = OptionConfigData.ReportServer
		self.DiceRollID = OptionConfigData.DiceRollID
    else
        Log.WarningFormat("[DialogueV2][DialogueOption]Option:%s has no config data in DialogueOptionText.lua", self.OptionID)    
	end

    local Item = OptionData.Item
    if Item and Item.Icon then
        self.Icon = self:composeOptionIconAssetPath(Item.Icon.Path)
    end
    
    self.Index = Index
	
	local snapshotOptionStates = episode.dialogueInstance:GetBlackBoardValue(DialogueConst.BlackBoardKey.OPTION_STATES)
	if snapshotOptionStates then
		local states = snapshotOptionStates[episode.episodeIdx]
        if states and states[Index] and states[Index].LastOptionState ~= nil then
            self.LastOptionState = states[Index].LastOptionState
        else
            self.LastOptionState = nil
        end
	else
        local bLocked = not self:IsConditionNull(OptionData.Condition)
        self.LastOptionState = bLocked and DialogueConst.OptionState.Locked or DialogueConst.OptionState.UnLocked
    end

	self.OptionState = self.LastOptionState
end

---@public
---@param state number @ DialogueConst.OptionState
function DialogueOption:SetOptionState(state)
    if state == self.OptionState then
        return
    end
    
	self.LastOptionState = self.OptionState
	self.OptionState = state
	self:updateSnapshot()
end

---@public
---@return boolean @ 是否刚刚解锁
function DialogueOption:IsJustUnlock()
    return self.LastOptionState == DialogueConst.OptionState.Locked
        and self.OptionState == DialogueConst.OptionState.UnLocked
end

---@public
---@return boolean @ 是否已解锁
function DialogueOption:IsUnlock()
    return self.OptionState == DialogueConst.OptionState.UnLocked
end

---@public
---@return boolean @ 是否为锁定状态
function DialogueOption:IsLock()
	return self.OptionState == DialogueConst.OptionState.Locked
end

---@public
---@return boolean @ 是否已选
function DialogueOption:IsPassed()
	return self.OptionState == DialogueConst.OptionState.Passed
end

---@return boolean
function DialogueOption:HideWhenPassed()
    return self.SelectHide == DialogueConst.OptionVisibility.HideWhenPassed
        or self.SelectHide == DialogueConst.OptionVisibility.HideWhenPassedInPhase
end

---@return boolean
function DialogueOption:IsUnlockAnimPlayed()
    return self.bUnlockAnimPlayed
end

---@param bPlayed boolean
function DialogueOption:SetUnlockAnimPlayed(bPlayed)
    self.bUnlockAnimPlayed = bPlayed
end

---------------------------------------------- Option条件判断 -------------------------------------------------------
-- 检查选项的条件是否满足
---@param conditionStr string
---@return DialogueOptionState
function DialogueOption:CheckOptionConditionValid(conditionStr)
	-- 已经看过
	if Game.DialogueManagerV2.DialogueHistory:HasSelectedOption(self.OptionID) then
		return DialogueConst.OptionState.Passed
	end

	-- 空配置
	if self:IsConditionNull(conditionStr) then
		return DialogueConst.OptionState.UnLocked
	end

	local andOperatorNum = string.find(conditionStr, "&")
	local orOperatorNum = string.find(conditionStr, "|")

	-- 区分与或条件(只能全与或者全或,不支持组合)
	if (andOperatorNum ~= nil) and (orOperatorNum ~= nil) then
		Log.WarningFormat("[DialogueV2][CheckOptionConditionValid] illegal condition config: %s, using |& same time", conditionStr)
		return DialogueConst.OptionState.Locked
	end

	-- 与或都为空，则默认按照单个条件
	if orOperatorNum == nil then
		andOperatorNum = andOperatorNum or 1
	end

	local bPass, conditions
	if andOperatorNum then
		bPass = true
		conditions = string.split(conditionStr, "&")
	else
		bPass = false
		conditions = string.split(conditionStr, "|")
	end

	for _, condition in ipairs(conditions) do
		-- 配0直接pass
		if condition == "0" then
			goto continue
		end

		local conditionConf = string.split(condition, ":")
		if #conditionConf ~= 2 then
			Log.WarningFormat("[DialogueV2][CheckOptionConditionValid] illegal condition config: %s, wrong param", conditionStr)
			bPass = false
			break
		end

		local conditionName = conditionConf[1]
		local conditionValue = conditionConf[2]
		local conditionFunc = self.OptionConditionChecker[conditionName]
		if not conditionFunc then
			Log.WarningFormat("[DialogueV2][CheckOptionConditionValid] illegal condition config: %s, non-exist condition func", conditionStr)
			bPass = false
			break
		end
		
		local bSingleResult = conditionFunc(self, conditionValue)
		if andOperatorNum then
			if not bSingleResult then
				bPass = false
				break
			end
		else
			if bSingleResult then
				bPass = true
				break
			end
		end

		:: continue ::
	end

	return bPass and DialogueConst.OptionState.UnLocked or DialogueConst.OptionState.Locked
end

-- 前置option condition
function DialogueOption:CheckOptionConditionPreOption(ConditionValue)
	local ConditionIDs = string.split(ConditionValue, ",")
	if #ConditionIDs ~= 0 then
		for _, ConditionID in ipairs(ConditionIDs) do
			if Game.DialogueManagerV2.DialogueHistory:HasSelectedOption(tonumber(ConditionID)) == false then
				--前置Option还没点过
				Log.DebugFormat("[DialogueV2]CheckOptionConditionPreOption failed ! %s hasnt been select yet !", ConditionID)
				return false
			end
		end
		Log.DebugFormat("[DialogueV2]CheckOptionConditionPreOption pass ! %s ", ConditionValue)
		return true
	else
		Log.WarningFormat("[DialogueV2]dialogue option format is illegal! Pre should Set Option! ")
		return false
	end
end

function DialogueOption:CheckOptionConditionQte(ConditionValue)
	local QTESuccess = self.episodeInstance.dialogueInstance:GetBlackBoardValue(DialogueConst.BlackBoardKey.QTE_RESULT) or false
	if ConditionValue == "1" then
		if QTESuccess then
			return true
		end
		return false
	elseif ConditionValue == "0" then
		if QTESuccess then
			return false
		end
		return true
	end
end

function DialogueOption:CheckOptionConditionItem(ConditionValue)
	--if Game.DialogueManagerV2.EditorManager then
	--	--编辑器状态下，判断通过
	--	Log.DebugFormat("CheckOptionConditionItem Editor Check Pass %s", ConditionValue)
	--	return true
	--end
	local ConditionIDs = string.split(ConditionValue, ",")
	if #ConditionIDs ~= 0 then
		for _, ConditionID in ipairs(ConditionIDs) do
			local haveNum = Game.BagSystem:GetItemCount(tonumber(ConditionID))
			if haveNum <= 0 then
				--未拥有道具
				Log.DebugFormat("[DialogueV2]CheckOptionConditionItem failed ! bag has no item %s !", ConditionID)
				return false
			end
		end
		Log.DebugFormat("[DialogueV2]CheckOptionConditionItem pass %s !", ConditionValue)
		return true
	else
		Log.WarningFormat("[DialogueV2]dialogue option format is illegal ! Item Should Set ItemID")
		return false
	end
end

function DialogueOption:CheckOptionConditionCompleteTask(ConditionValue)
	--if Game.DialogueManagerV2.EditorManager then
	--	--编辑器状态下，判断通过
	--	Log.DebugFormat("CheckOptionConditionCompleteTask Editor Check Pass %s", ConditionValue)
	--	return true
	--end
	local ConditionIDs = string.split(ConditionValue, ",")
	if #ConditionIDs ~= 0 then
		for _, ConditionID in ipairs(ConditionIDs) do
			if Game.QuestSystem:IsQuestFinished(tonumber(ConditionID)) == false then
				--未拥有道具
				Log.DebugFormat("[DialogueV2]CheckOptionConditionCompleteTask failed ! task  %s not finish !", ConditionID)
				return false
			end
		end
		Log.DebugFormat("[DialogueV2]CheckOptionConditionCompleteTask pass %s !", ConditionValue)
		return true
	else
		Log.WarningFormat("[DialogueV2]dialogue option format is illegal ! Item Should Set TaskID")
		return false
	end
end

function DialogueOption:CheckOptionConditionDice(conditionValue)
	local v = tonumber(conditionValue)
	if v == Enum.DiceResult.Success then
		return (self.diceResult == Enum.DiceResult.Success) or (self.diceResult == Enum.DiceResult.BigSuccess)
	elseif v == Enum.DiceResult.Failure then
		return (self.diceResult == Enum.DiceResult.Failure) or (self.diceResult == Enum.DiceResult.BigFailure)
	else
		Log.WarningFormat("[DialogueV2][CheckOptionConditionDice] invalid condition value: %s", conditionValue)
		return false
	end
end

function DialogueOption:CheckOptionConditionMood(conditionValue)
	local npcEnt
	local Params = self.episodeInstance.dialogueInstance
	if Params.ActorEntityID then
		npcEnt = Game.EntityManager:getEntity(Params.ActorEntityID)
	end

	if not npcEnt then
		Log.Warning("[DialogueV2][CheckOptionConditionMood] no npc")
		return false
	end

	local targetMood = tonumber(conditionValue)
	if targetMood > 0 then
		return npcEnt.MoodValue >= targetMood
	elseif targetMood < 0 then
		return npcEnt.MoodValue <= (-1 * targetMood)
	else
		Log.WarningFormat("[DialogueV2][CheckOptionConditionMood] invalid condition value: %s", conditionValue)
		return false
	end
end

function DialogueOption:CheckOptionConditionPrice(_)
	-- 根据有无最终成交价判断玩法是否结束
	local finalPrice = self.episodeInstance.dialogueInstance:GetBlackBoardValue("finalPrice")
	return (finalPrice ~= nil)
end

--判断玩家距离
function DialogueOption:CheckOptionConditionPlayerDistance(conditionValue)
	if _G.StoryEditor then
		--编辑器下直接判断通过
		return true
	end

	if not self.episodeInstance.dialogueInstance or not conditionValue then
		return false
	end

	local FirstGameEntity = self.episodeInstance.dialogueInstance:FindDialoguePerformerFirstGameEntity()
	if not FirstGameEntity then
		return
	end

	local ActorDistance
	if Game.me then
        ActorDistance = KismetMathLibrary.Vector_Distance(FirstGameEntity:GetPosition(), Game.me:GetPosition())
    else
        Log.Warning("[DialogueV2][DialogueOption]CheckOptionConditionPlayerDistance: Game.me is nil, actor disatance will set to 0")
        ActorDistance = 0
    end

	local Distance = tonumber(conditionValue)
	if ActorDistance > Distance then
		return false
	end

	return true
end

function DialogueOption:CheckMoodLevel(conditionLevel)
	local npcEnt
	local Params = self.episodeInstance.dialogueInstance.Params
	if Params.ActorEntityID then
		npcEnt = Game.EntityManager:getEntity(Params.ActorEntityID)
	end

	if not npcEnt then
		Log.Warning("[DialogueV2][CheckOptionConditionMood] no npc")
		return false
	end
	local moodLevel = Game.NPCMoodSystem:GetMoodLevel(npcEnt.MoodValue)

	local targetLevel = tonumber(conditionLevel)
	if targetLevel > 0 then
		return moodLevel >= targetLevel
	elseif targetLevel < 0 then
		return npcEnt.MoodValue <= (-1 * targetLevel)
	else
		Log.WarningFormat("[DialogueV2][CheckOptionConditionMood] invalid condition value: %s", targetLevel)
		return false
	end

end

function DialogueOption:CheckBargainStart(bStart)
	local bargainStart = self.episodeInstance.dialogueInstance:GetBlackBoardValue("bargainStart")
	return (bargainStart == bStart)
end

function DialogueOption:CheckTaskMarkDefine(taskMarkDefine)
	local tokens = string.split(taskMarkDefine, ",")
	if #tokens <= 1 then
		Log.WarningFormat("[DialogueV2][CheckTaskMarkDefine] invalid taskMarkDefine: %s.Valid taskmark must be 'taskMarkName,value'.", taskMarkDefine)
		return false
	end

	local taskMarkName = tokens[1]
	local value = tokens[2]
	local taskMarkValue = Game.QuestSystem:GetTaskMarkDefine(taskMarkName)
	if not taskMarkValue then
		Log.WarningFormat("[DialogueV2][CheckTaskMarkDefine] can not find task mark: %s.", taskMarkName)
		return false
	end

	return string.lower(tostring(taskMarkValue)) == string.lower(value)
end
---------------------------------------------- Option条件判断 -------------------------------------------------------

function DialogueOption:UnInit()
	Game.GlobalEventSystem:RemoveTargetAllListeners(self)
	self:delete()
end

function DialogueOption:dtor()
	self.OptionTextID = nil
	self.OptionText = nil
	self.LockVisible = nil
	self.LockText = nil
	self.bClose = nil
	self.SelectHide = nil
	self.ExtraAction = {}
	self.ReportServer = nil
	self.Icon = nil
	self.OptionState = nil
	self.LastOptionState = nil

	self.Index = 0
	self.episodeInstance = nil
end

function DialogueOption:updateSnapshot()
	local episodeInstance = self.episodeInstance
	local dialogueInstance = self.episodeInstance.dialogueInstance
	if not dialogueInstance then
		return
	end

    local snapshotOptions = dialogueInstance:GetBlackBoardValue(DialogueConst.BlackBoardKey.OPTION_STATES)
    if not snapshotOptions then
        snapshotOptions = {}
        dialogueInstance:SetBlackBoardValue(DialogueConst.BlackBoardKey.OPTION_STATES, snapshotOptions)
    end

    local temp = snapshotOptions[episodeInstance.episodeIdx]
    if not temp then
        temp = {}
        snapshotOptions[episodeInstance.episodeIdx] = temp
    end

	temp[self.Index] =
    {
        LastOptionState = self.LastOptionState,
        OptionState = self.OptionState
    }
    Log.DebugFormat("[DialogueV2]DialogueOption:updateSnapshot:%s %s state:%s", self.OptionText, self.Index, self.OptionState)
end


---@private
---@param consitionStr string
---@return boolean
function DialogueOption:IsConditionNull(consitionStr)
    return consitionStr == nil or consitionStr == "" or consitionStr == "0"
end

function DialogueOption:GetTargetEpisodeID()
    return self.EpisodeID
end 


--region private
function DialogueOption:composeOptionIconAssetPath(iconPath)
    local packageName = iconPath.AssetPath.PackageName
    local assetName = iconPath.AssetPath.AssetName
    if not packageName or packageName == "None" or packageName == ""
        or not assetName or assetName == "None" or assetName == "" then
        return nil
    end

    local t = {
        packageName,
        ".",
        assetName
    }

    return table.concat(t)
end
--endregion