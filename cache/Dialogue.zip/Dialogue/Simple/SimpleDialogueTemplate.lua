---
--- 简易对话功能的模板, 如果剧编数据格式有调整, 需要同步到这边, 需要动态传入的字段需要标记
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/1/16 16:51
---

local SimpleDialogueTemplate = {}

-- 外围的Table不重新构造,将动态数据
---@public
function SimpleDialogueTemplate.GetEmptyDialogueTemplate()
    SimpleDialogueTemplate.ClearTemplateData()
    return SimpleDialogueTemplate.DialogueTemplate
end

function SimpleDialogueTemplate.ClearTemplateData()
    if SimpleDialogueTemplate.DialogueTemplate.AllEntities then
        SimpleDialogueTemplate.DialogueTemplate.AllEntities = nil
    end

    SimpleDialogueTemplate.DialogueTemplate.ObjectName = ""

    SimpleDialogueTemplate.DialogueTemplate.AnchorType = 0
    SimpleDialogueTemplate.DialogueTemplate.AnchorNpc = ""
    SimpleDialogueTemplate.DialogueTemplate.AnchorID = ""

    SimpleDialogueTemplate.DialogueTemplate.ActorInfos[1].AppearanceID = 0
    SimpleDialogueTemplate.DialogueTemplate.ActorInfos[2].AppearanceID = 0

    SimpleDialogueTemplate.DialogueTemplate.Episodes = {}
    SimpleDialogueTemplate.DialogueTemplate.PerformerList = {}
end

---@public
function SimpleDialogueTemplate.NewEpisode()
    return SimpleDialogueTemplate.duplicateTemplate(SimpleDialogueTemplate.EpisodeTemplate)
end

---@public
function SimpleDialogueTemplate.NewStateControlSection()
    return SimpleDialogueTemplate.duplicateTemplate(SimpleDialogueTemplate.StateControlSectionTemplate)
end

---@public
function SimpleDialogueTemplate.NewDialogueSection()
    return SimpleDialogueTemplate.duplicateTemplate(SimpleDialogueTemplate.DialogueSectionTemplate)
end

function SimpleDialogueTemplate.NewLookAtSection()
    return SimpleDialogueTemplate.duplicateTemplate(SimpleDialogueTemplate.LookAtSectionTemplate)
end

---@public
function SimpleDialogueTemplate.NewOption()
    return SimpleDialogueTemplate.duplicateTemplate(SimpleDialogueTemplate.OptionTemplate)
end

---@public
function SimpleDialogueTemplate.NewPerformer()
    return SimpleDialogueTemplate.duplicateTemplate(SimpleDialogueTemplate.PerformerTemplate)
end

-- 复制table
---@private
function SimpleDialogueTemplate.duplicateTemplate(template)
    local newT = {}
    for k, v in pairs(template) do
        if type(v) == "table" then
            newT[k] = SimpleDialogueTemplate.duplicateTemplate(v)
        else
            newT[k] = v
        end
    end
    return newT
end

-- 外围模板
SimpleDialogueTemplate.DialogueTemplate = {
    -- 简易对话标识
    ["bSimpleDialogue"] = true,

    -- 演员信息, Npc使用场景Actor, 玩家使用假玩家
    ["ActorInfos"] = {
        [1] = {
            ["AppearanceID"] = 0,
            ["IdleAnimation"] = {
                ["AssetID"] = "",
                ["StateName"] = "",
            },
            ["InsID"] = "",
            ["PerformerName"] = "Actor1",
            ["UseSceneActor"] = false,
            ["bIsPlayer"] = true,
        },
        [2] = {
            ["AppearanceID"] = 0,
            ["IdleAnimation"] = {
                ["AssetID"] = "",
                ["StateName"] = "",
            },
            ["InsID"] = "",
            ["PerformerName"] = "Actor2",
            ["UseSceneActor"] = true,
            ["bIsPlayer"] = false,
        },
    },

    -- 以Actor2作为锚点
    ["AnchorID"] = "",
    ["AnchorNpc"] = "",
    ["AnchorType"] = 0,
    ["AutoPlayType"] = 0,
    ["BlendInCamera"] = false,
    ["BlendOutCamera"] = false,

    -- 没有相机
    ["CameraList"] = {},
    ["EnableDOF"] = false,

    ["ExportToServer"] = false,
    ["HideAtmosphereNpc"] = true,
    ["HideNpcRange"] = 0,
    ["HideNpcType"] = 0, -- 默认不隐藏Npc
    ["NativeClass"] = "/Game/Blueprint/DialogueSystem/BP_DialogueAsset.BP_DialogueAsset_C",
    ["NeedFadeIn"] = false,
    ["NeedFadeOut"] = false,
    ["NewEntityList"] = {
    },
    ["Note"] = "",
    ["ObjectClass"] = "/Game/Blueprint/DialogueSystem/BP_DialogueAsset.BP_DialogueAsset_C",
    ["ObjectName"] = "",

    ["PreLoadArray"] = {
        [1] = "/Game/Blueprint/3C/Actor/BP_DialogueActor.BP_DialogueActor_C",
    },
    ["PreLoadBanks"] = {},
    ["RoutePointList"] = {},
    ["Unique"] = true,
    ["UseTemplateCamera"] = false,

    -- 小段,需要动态填充
    ["Episodes"] = {},
    -- 演员占位信息, 需要动态传入
    ["PerformerList"] = {},
}

-- 小段模板
SimpleDialogueTemplate.EpisodeTemplate = {
    ["Duration"] = 0,
    ["EpisodeID"] = 0,
    ["LoopTimes"] = 0,
    ["OptionType"] = 0,
    ["Options"] = {},
    ["TimeLimit"] = 0,
    ["TimeOutDefaultChoice"] = 0,
    ["TrackGroups"] = {},
    ["TrackList"] = {
        [1] = {
            ["Actions"] = {},
            ["Childs"] = {},
            ["DialogueEntity"] = "Actor1",
            ["TrackName"] = "Actor1",
        },
        [2] = {
            ["Actions"] = {},
            ["Childs"] = {},
            ["DialogueEntity"] = "Actor2",
            ["TrackName"] = "Actor2",
        },
        -- StateControl
        [3] = {
            ["ActionSections"] = {},
            ["Actions"] = {},
            ["Childs"] = {},
            ["ObjectClass"] = "/Script/KGStoryLine.DialogueStateControlAction",
            ["ObjectName"] = "DialogueStateControlAction_0",
            ["Priority"] = 0,
            ["SectionType"] = "/Game/Blueprint/DialogueSystem/Section/BPS_StateControl.BPS_StateControl_C",
            ["TrackName"] = "StateControl",
        },
        -- Dialogue
        [4] = {
            ["ActionSections"] = {},
            ["Actions"] = {},
            ["Childs"] = {},
            ["ObjectClass"] = "/Script/KGStoryLine.DialogueDialogueAction",
            ["ObjectName"] = "DialogueDialogueAction_0",
            ["Priority"] = 0,
            ["SectionType"] = "/Game/Blueprint/DialogueSystem/Section/BPS_Dialogue.BPS_Dialogue_C",
            ["TrackName"] = "Dialogue",
        },
        -- LookAt
        [5] = {
            ["ActionSections"] = {},
            ["Actions"] = {},
            ["Childs"] = {},
            ["ObjectClass"] = "/Game/Blueprint/DialogueSystem/Track/BP_DialogueTrackLookAt.BP_DialogueTrackLookAt_C",
            ["ObjectName"] = "BP_DialogueTrackLookAt_C_0",
            ["Priority"] = 0,
            ["SectionType"] = "/Game/Blueprint/DialogueSystem/Section/BPS_LookAt.BPS_LookAt_C",
            ["TrackName"] = "LookAt",
        },
        -- CameraMode,这个类是虚构的,因为不想暴露给外部
        [6] = {
            ["ActionSections"] = {
                [1] = {
                    ["Duration"] = 0,
                    ["Enable"] = true,
                    ["FromLineIndex"] = -1,
                    ["ObjectClass"] = "/Game/Blueprint/DialogueSystem/Section/BPS_SimpleCameraMode.BPS_SimpleCameraMode_C",
                    ["ObjectName"] = "BPS_SimpleCameraMode_C_0",
                    ["OwnedEpisodeID"] = 0,
                    ["SectionName"] = "Section",
                    ["StartTime"] = 0,
                    ["bExitOnEnd"] = false,
                    ["PrimaryActor"] = "Actor1",
                    ["SecondaryActor"] = "Actor2",
                }
            },
            ["Actions"] = {},
            ["Childs"] = {},
            ["ObjectClass"] = "/Game/Blueprint/DialogueSystem/Track/BP_SimpleCameraModeTrack.BP_SimpleCameraModeTrack_C",
            ["ObjectName"] = "BP_SimpleCameraModeTrack_C_0",
            ["Priority"] = 0,
            ["SectionType"] = "/Game/Blueprint/DialogueSystem/Section/BPS_SimpleCameraMode.BPS_SimpleCameraMode_C",
            ["TrackName"] = "SimpleCameraMode",
        }
    },
}

-- 状态控制Section模板
SimpleDialogueTemplate.StateControlSectionTemplate = {
    ["Duration"] = 0.1,
    ["DynamicFlag"] = "",
    ["Enable"] = true,
    ["FromLineIndex"] = 0,
    ["ObjectClass"] = "/Game/Blueprint/DialogueSystem/Section/BPS_StateControl.BPS_StateControl_C",
    ["ObjectName"] = "BPS_StateControl_C_0",
    ["OwnedEpisodeID"] = 0,
    ["SectionName"] = "Section",
    ["StartTime"] = 0,
}

-- 台本Section模板
SimpleDialogueTemplate.DialogueSectionTemplate = {
    ["CanSkip"] = false,
    ["ContentIndex"] = 0,
    ["ContentUI"] = 0,
    ["Duration"] = 0,
    ["DynamicFlag"] = "",
    ["Enable"] = true,
    ["EpisodeID"] = 0,
    ["FromLineIndex"] = 0,
    ["ObjectClass"] = "/Game/Blueprint/DialogueSystem/Section/BPS_Dialogue.BPS_Dialogue_C",
    ["ObjectName"] = "BPS_Dialogue_C_0",
    ["OwnedEpisodeID"] = 0,
    ["PrinterSpeed"] = 0,
    ["SectionName"] = "",
    ["SendOther"] = false,
    ["Small"] = "",
    ["SmallPos"] = "",
    ["StartTime"] = 0,
    ["SubTitle"] = "",
    ["Talker"] = "",
    ["TalkerName"] = "",
    ["bSimpleDialogue"] = true, -- 简易对话专用变量,BP中没有
}

-- LookAtSection模板
SimpleDialogueTemplate.LookAtSectionTemplate = {
    ["Duration"] = 0,
    ["Enable"] = true,
    ["FromLineIndex"] = -1,
    ["LookAtInfo"] = {
        [1] = {
            ["Delay"] = 0,
            ["Enable"] = true,
            ["Looker"] = "Actor1",
            ["Target"] = "Actor2",
        },
        [2] = {
            ["Delay"] = 0,
            ["Enable"] = true,
            ["Looker"] = "Actor2",
            ["Target"] = "Actor1",
        },
    },
    ["LookAtTalker"] = false,
    ["ObjectClass"] = "/Game/Blueprint/DialogueSystem/Section/BPS_LookAt.BPS_LookAt_C",
    ["ObjectName"] = "BPS_LookAt_C_0",
    ["OwnedEpisodeID"] = 0,
    ["SectionName"] = "Section",
    ["StartTime"] = 0,
    ["TalkerLookAtTarget"] = "",
}

-- 选项模板
SimpleDialogueTemplate.OptionTemplate = {
    ["Condition"] = "",
    ["CustomContent"] = "",
    ["DialogueID"] = 0,
    ["DialogueLineIndex"] = 0,
    ["DialogueText"] = "",
    ["EpisodeID"] = 0,
    ["Item"] = {
        ["AssetName"] = "",
        ["ExtraAction"] = {},
        ["ID"] = 0,
        ["LockText"] = "",
        ["LockVisible"] = false,
        ["ReportServer"] = false,
        ["SelectHide"] = false,
        ["Text"] = "",
        ["bClose"] = false,
    }
}

-- 演员信息模板
SimpleDialogueTemplate.PerformerTemplate = {
    ["ActorClass"] = "/Game/Blueprint/3C/Actor/BP_DialogueActor.BP_DialogueActor_C",
    ["AppearanceID"] = 0,
    ["DefaultFaceAnim"] = 4,
    ["FollowParentSocket"] = "",
    ["HasDefaultFaceAnim"] = false,
    ["IdleAnimLibAssetID"] = {
        ["AssetID"] = "",
        ["StateName"] = "",
    },
    ["InsID"] = "",
    ["ObjectClass"] = "/Game/Blueprint/DialogueSystem/Entity/BP_DialogueActor.BP_DialogueActor_C",
    ["ObjectName"] = "BP_DialogueActor_C_0",
    ["Parent"] = "",
    ["SpawnTransform"] = {
        ["Rotation"] = {
            ["W"] = 1,
            ["X"] = 0,
            ["Y"] = 0,
            ["Z"] = 0,
        },
        ["Scale3D"] = {
            ["X"] = 1,
            ["Y"] = 1,
            ["Z"] = 1,
        },
        ["Translation"] = {
            ["X"] = 0,
            ["Y"] = 0,
            ["Z"] = 88,
        },
    },
    ["TrackName"] = "",
    ["UseLookAtFunction"] = true,
    ["UseSceneActor"] = false,
    ["bDefaultVisible"] = true,
    ["bIsPlayer"] = false,
}

return SimpleDialogueTemplate
