---@class DialogueAssetMgr
---@field private loadHandlers table<number, number> @ 加载句柄
---@field private preloadQueue DialogueLoadCluster[] @ 预加载队列
---@field private mapDialogueID2PreloadCluster table<number, DialogueLoadCluster> @ 对话ID -> 预加载任务
---@field private maxConcurrentPreloads number @ 最大预加载数量
---@field private curPreloads number @ 当前预加载对话数量
DialogueAssetMgr = DefineClass("DialogueAssetMgr")

local DialogueLoadCluster = kg_require("Gameplay.DialogueV2.AssetLoader.DialogueLoadCluster").DialogueLoadCluster

function DialogueAssetMgr:ctor()
    self.loadHandlers = {}
    self.preloadQueue = {}
    self.pendingPreloadQueue = {}
    self.mapDialogueID2PreloadCluster = {}
    self.maxConcurrentPreloads = 3
    self.curPreloads = 0
end

function DialogueAssetMgr:Init()
    
end

function DialogueAssetMgr:UnInit()
    self:Clear()
end

function DialogueAssetMgr:Clear()
    Log.Debug("[DialogueV2][DialogueAssetMgr]Clear")
    for _, preloadTask in pairs(self.mapDialogueID2PreloadCluster) do
        preloadTask:delete()
    end

    table.clear(self.pendingPreloadQueue)
    table.clear(self.preloadQueue)
    table.clear(self.mapDialogueID2PreloadCluster)
    self.curPreloads = 0

    self:ReleaseAllHandlers()
end

---@param dialogueID number
---@param dialogueConfig DialogueTable
---@param priority number
---@param requester any
---@param onCompleteCallbackName string
---@param onCancelCallbackName string
---@return DialogueLoadCluster
function DialogueAssetMgr:PreloadDialogue(dialogueID, dialogueConfig, priority, requester, onCompleteCallbackName, 
                                          onCancelCallbackName)
    self:PurgeTimeout()

    ---@type DialogueLoadCluster
    local cluster = self.mapDialogueID2PreloadCluster[dialogueID]
    if cluster then
        if cluster:IsCompleted() then
            Log.DebugFormat("[DialogueV2][DialogueAssetMgr]PreloadDialogue: dialogueID[%s] is loaded", dialogueID)
            if requester and onCompleteCallbackName then
                local func = requester[onCompleteCallbackName]
                if func then
                    xpcall(func, _G.CallBackError, requester, cluster, dialogueID)
                end
            end
        elseif cluster:IsLoading() then
            Log.DebugFormat("[DialogueV2][DialogueAssetMgr]PreloadDialogue: dialogueID[%s] is already preloading", dialogueID)
            if requester and onCompleteCallbackName then
                cluster.OnCompleted:Add(requester, onCompleteCallbackName)
            end

            if requester and onCancelCallbackName then
                cluster.OnCanceled:Add(requester, onCancelCallbackName)
            end
        end
        
        return cluster
    end

    if self.curPreloads >= self.maxConcurrentPreloads then
        if self.pendingPreloadQueue[dialogueID] then
            Log.DebugWarningFormat("[DialogueV2][DialogueAssetMgr]PreloadDialogue: dialogueID[%s] is already in pending preload queue", dialogueID)
        else
            Log.DebugWarningFormat("[DialogueV2][DialogueAssetMgr]PreloadDialogue: preload queue is full, add dialogue[%s] to pending preload queue",
                dialogueID)
            self.pendingPreloadQueue[dialogueID] = table.pack(dialogueID, dialogueConfig, priority, requester, onCompleteCallbackName, onCancelCallbackName)
        end
        
        return nil
    end
    
    cluster = DialogueLoadCluster.new(dialogueID, dialogueConfig, priority)
    if cluster then
        Log.InfoFormat("[DialogueV2][DialogueAssetMgr]PreloadDialogue: dialogueID[%s]", dialogueID)
        cluster.OnCompleted:Add(self, "OnLoadTaskCompleted")

        if requester and onCompleteCallbackName then
            cluster.OnCompleted:Add(requester, onCompleteCallbackName)
        end

        if requester and onCancelCallbackName then
            cluster.OnCanceled:Add(requester, onCancelCallbackName)
        end

        self.curPreloads = self.curPreloads + 1
        self.mapDialogueID2PreloadCluster[dialogueID] = cluster
        self:addToQueue(cluster)
        cluster:Load()
    else
        Log.DebugWarningFormat("[DialogueV2][DialogueAssetMgr]PreloadDialogue failed: load cluster create failed, dialogueID[%s]", 
            dialogueID)
    end
    
    return cluster
end

---@param dialogueID number
function DialogueAssetMgr:CancelPreload(dialogueID)
    self:PurgeTimeout()
    
    if not dialogueID or type(dialogueID) ~= 'number' then
        Log.DebugWarningFormat("[DialogueV2][DialogueAssetMgr]CancelPreload failed: dialogueID[%s] is invalid", dialogueID)
        return
    end
    
    self.pendingPreloadQueue[dialogueID] = nil

    Log.InfoFormat("[DialogueV2][DialogueAssetMgr]CancelPreload: dialogueID[%s]", dialogueID)
    local cluster = self.mapDialogueID2PreloadCluster[dialogueID]
    if cluster then
        cluster:Cancel()
        cluster:Unload()
        cluster:delete()
        
        self:removeFromQueue(cluster)
        self.mapDialogueID2PreloadCluster[dialogueID] = nil
    end
end

---@param dialogueID number
function DialogueAssetMgr:UnloadDialogue(dialogueID)
    local cluster = self.mapDialogueID2PreloadCluster[dialogueID]
    if cluster then
        cluster:Unload()
    end
end

---@param assets string[]
---@param obj any
---@param callbackName string
function DialogueAssetMgr:AsyncLoadAssetListAndKeepRef(assets, obj, callbackName)
    if not assets or #assets == 0 then
        return
    end

    local handler = Game.AssetManager:AsyncLoadAssetListKeepReferenceID(assets, obj, callbackName)
    if handler then
        self.loadHandlers[handler] = handler
        Log.DebugFormat("[DialogueV2]DialogueAssetMgr:AsyncLoadAssetListAndKeepRef: %s", handler)
    end

    return handler
end

---@param asset string
---@param obj any
---@param callbackName string
function DialogueAssetMgr:AsyncLoadAssetAndKeepRef(asset, obj, callbackName)
    if not asset then
        return
    end

    local handler = Game.AssetManager:AsyncLoadAssetKeepReferenceID(asset, obj, callbackName)
    if handler then
        self.loadHandlers[handler] = handler
        Log.DebugFormat("[DialogueV2]DialogueAssetMgr:AsyncLoadAssetAndKeepRef: %s", handler)
    end
    
    return handler
end

---@param handler number
function DialogueAssetMgr:ReleaseHandler(handler)
    Game.AssetManager:RemoveAssetReferenceByLoadID(handler)
    Game.AssetManager:CancelLoadAsset(handler)
    self.loadHandlers[handler] = nil
    Log.DebugFormat("[DialogueV2]DialogueAssetMgr:ReleaseHandler: %s", handler)
end

function DialogueAssetMgr:ReleaseAllHandlers()
    for handler, _ in pairs(self.loadHandlers) do
        Game.AssetManager:RemoveAssetReferenceByLoadID(handler)
        Game.AssetManager:CancelLoadAsset(handler)
        self.loadHandlers[handler] = nil
        Log.DebugFormat("[DialogueV2]DialogueAssetMgr:ReleaseAllHandlers: %s", handler)
    end
end

---@param cluster DialogueLoadCluster
---@param dialogueID number
function DialogueAssetMgr:OnLoadTaskCompleted(cluster, dialogueID)
    if self.mapDialogueID2PreloadCluster[dialogueID] and cluster then
        Log.InfoFormat("[DialogueV2][DialogueAssetMgr]OnLoadTaskCompleted: dialogueID[%s]", dialogueID)
        self:removeFromQueue(cluster)

        local nextDialogueID, info = next(self.pendingPreloadQueue)
        if info then
            Log.DebugFormat("[DialogueV2][DialogueAssetMgr]Pop pending load dialogue[%s] from pending preload queue",
                nextDialogueID)
            self:PreloadDialogue(table.unpack(info))
            self.pendingPreloadQueue[nextDialogueID] = nil
        end
    end
end

---@param whiteDialogueIDs table<number>|number @ 白名单
function DialogueAssetMgr:PurgeTimeout(whiteDialogueIDs)
    for dialogueID, cluster in pairs(self.mapDialogueID2PreloadCluster) do
        if cluster:IsTimeout() or cluster:IsCacheTimeout() then
            cluster:PurgeTimeout(whiteDialogueIDs)
            self.mapDialogueID2PreloadCluster[dialogueID] = nil

            self:removeFromQueue(cluster)
            Log.InfoFormat("[DialogueV2][DialogueAssetMgr]PurgeTimeout: dialogueID[%s]", dialogueID)
        end
    end
end

---@private
---@param cluster DialogueLoadCluster
function DialogueAssetMgr:addToQueue(cluster)
    table.insert(self.preloadQueue, cluster)
    self.curPreloads = #self.preloadQueue
end

---@private
---@param cluster DialogueLoadCluster
function DialogueAssetMgr:removeFromQueue(cluster)
    table.removeItem(self.preloadQueue, cluster)
    self.curPreloads = #self.preloadQueue
end