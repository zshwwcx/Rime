---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/7 14:31
---

---@enum DialogueEpisodeStateID
---@field public EP_STATE_INIT DialogueEpisodeStateID
---@field public EP_STATE_TICKTRACKS DialogueEpisodeStateID
---@field public EP_STATE_PAUSE DialogueEpisodeStateID
---@field public EP_STATE_FINISH DialogueEpisodeStateID
---@field public EP_STATE_PAUSE_SUB_FREEZING DialogueEpisodeStateID
---@field public EP_STATE_PAUSE_SUB_ACCEPTING_QUEST DialogueEpisodeStateID
---@field public EP_STATE_PAUSE_SUB_SUBMITINT_ITEM DialogueEpisodeStateID
---@field public EP_STATE_PAUSE_SUB_OPTIONS DialogueEpisodeStateID
---@field public EP_STATE_WAIT_CLOSE_UI DialogueEpisodeStateID



---@class DialogueConst
---@field public EPISODE_STATE DialogueEpisodeStateID
---@field public EPISODE_STATE_NAME table<DialogueEpisodeStateID, string>
DialogueConst = DefineClass("DialogueConst")

-- 对话资产公共路径
DialogueConst.DIALOGUE_ASSET_PATH_PREFIX = "Data.Config.Dialogue."

DialogueConst.HEAD_SOCKET_NAME = "head"
DialogueConst.ANCHOR_TRACK_NAME = "锚点" -- luacheck:ignore

-- 长按时长
DialogueConst.LONG_PRESS_TIME = 1.5

-- 最小帧间隔时间，单位秒
DialogueConst.MIN_FRAME_TIME = 0.002

-- 对话点击间隔时间，单位毫秒
DialogueConst.INTERVAL_CLICK = 100

-- 分镜轨道名字
DialogueConst.TRACK_NAME_CAMERA_CUT = "CameraCut"

---语音播放结束后延迟的时间
DialogueConst.VOICE_DELAY_TIME = 1

-- 对话类型
DialogueConst.DIALOGUE_TYPE = {
    LIST = 1, -- 连播
    SIMPLE = 2, -- 简易对话
    NO_CAMERA = 3, -- 无镜对话
    NORMAL = 4, -- 普通独占对话
}

---@class PlayDialogueErrorCode
---@type PlayDialogueErrorCode
DialogueConst.PlayDialogueErrorCode = {
    SUCCESS = 0,
    INVALID_DIALOGUE_ID = 1,
    STATE_CONFLICTED = 2,
    IS_PLAYING_EXCLUSIVE_DIALOGUE = 3,
    ASYNC_LOAD_DIALOGUE = 4,
    HAS_NO_ASSET_DATA = 5,
    HAS_NO_TALK_DATA = 6,
    HAS_NO_DIALOGUE_ASSET = 7,
    INVALID_DIALOGUE_TYPE = 8,
    HAS_NO_DIALOGUE_CLASS = 9,
    DIALOGUE_INIT_FAILED = 10,
    HAS_NO_EPISODE_CONFIG = 11,
}

---对话流程状态,每个子类Instance按需注册
DialogueConst.STAGE = {
    CAMERA_FADE_IN_1ST_HALF = 1, -- 黑屏淡入到全黑
    PRELOAD_RESOURCE = 2, -- 资源预加载
    SPAWN_PARTICIPANT = 3, -- 创建参与者
    OPEN_DIALOGUE_PANEL = 4, -- 打开面板
    BEGIN_PLAY = 5, -- 开始表演,处理参与者,服务器Entity,UI等显隐,以及事件抛出,状态抛出
    CAMERA_FADE_IN_2ND_HALF = 6, -- 黑屏淡入到全亮
    TICKING = 7, -- Tick阶段
    CAMERA_FADE_OUT_1ST_HALF = 8, -- 黑屏淡出到全黑
    END_PLAY = 9, -- 结束表演,处理参与者,服务器Entity,UI等显隐,以及事件抛出,状态抛出
    CAMERA_FADE_OUT_2ND_HALF = 10, -- 黑屏淡出到全亮
    FINISH = 11,
}

-- 反向映射
DialogueConst.STAGE_NAME = {}
for k, v in pairs(DialogueConst.STAGE) do
    DialogueConst.STAGE_NAME[v] = k
end

--- 对话终止原因
---@class DialogueEndReason
---@type DialogueEndReason
DialogueConst.END_REASON = {
    NORMAL = "NORMAL", -- 正常终止
    TERMINATE = "TERMINATE", -- 未知异常导致对话终止
    TERMINATE_ON_DIALOGUE_SYSTEM_DESTROY = "TERMINATE_ON_DIALOGUE_SYSTEM_DESTROY", -- 对话系统销毁导致的对话终止 
    TERMINATE_ON_LEVEL_SWITCHED = "TERMINATE_ON_LEVEL_SWITCHED", -- 切换关卡导致的对话异常终止
    TERMINATE_ON_EDITOR_SHUTDOWN = "TERMINATE_ON_EDITOR_SHUTDOWN", -- 编辑器关闭导致的对话终止
    TERMINATE_ON_LOGIC_REQUEST = "TERMINATE_ON_LOGIC_REQUEST", -- 业务逻辑需要强制终止对话
    TERMINATE_ON_BACK_TO_SELECT_ROLE = "TERMINATE_ON_BACK_TO_SELECT_ROLE", -- 返回选角导致的对话终止
    TERMINATE_ON_BACK_TO_LOGIN = "TERMINATE_ON_BACK_TO_LOGIN", -- 返回登录导致的对话终止
    TERMINATE_ON_NEW_PLAY_REQUEST = "TERMINATE_ON_NEW_PLAY_REQUEST", -- 播放新对话导致的对话终止
    TERMINATE_ON_STATE_CONFLICT = "TERMINATE_ON_STATE_CONFLICT", -- 状态冲突打断对话导致的对话终止
    TERMINATE_ON_NET_DISCONNECTED = "TERMINATE_ON_NET_DISCONNECTED", -- 网络连接断开导致的对话终止
}

--- 跳过按钮隐藏原因
---@class DialogueSkipBtnHideReason
---@type DialogueSkipBtnHideReason
DialogueConst.SKIP_BTN_HIDE_REASON = {
    NORMAL = "NORMAL",
    MYSTERY = "MYSTERY", -- 推理玩法
}

--- 自动播放隐藏原因
---@class DialogueAutoPlayHideReason
---@type DialogueAutoPlayHideReason
DialogueConst.AUTO_PLAY_HIDE_REASON = {
    NORMAL = "NORMAL",
    MYSTERY = "MESTERY", -- 推理玩法
}

--- 回顾按钮隐藏原因
---@class DialogueReviewBtnHideReason
---@type DialogueReviewBtnHideReason
DialogueConst.REVIEW_BTN_HIDE_REASON = {
    NORMAL = "NORMAL",
    MYSTERY = "MESTERY", -- 推理玩法
}

DialogueConst.BLACK_SCREEN_TYPE = {
    DEFAULT = 0, -- 普通黑屏白字
    MIME_WHITE = 1, -- 白色底图默剧
}

---@type IDialogueStateID
DialogueConst.EPISODE_STATE = {
    EP_STATE_INIT = 0,
    EP_STATE_TICKTRACKS = 1,
    EP_STATE_PAUSE = 2,
    EP_STATE_FINISH = 3,
    EP_STATE_PAUSE_SUB_OPTIONS = 4,
    EP_STATE_PAUSE_SUB_ACCEPTING_QUEST = 5,
    EP_STATE_PAUSE_SUB_SUBMITTING_ITEM = 6,
    EP_STATE_WAIT_CLOSE_UI = 7,
}

DialogueConst.EPISODE_STATE_NAME = {}
for k, v in pairs(DialogueConst.EPISODE_STATE) do
    DialogueConst.EPISODE_STATE_NAME[v] = k
end

---@type IDialogueStateID
DialogueConst.INSTANCE_STATE = {
    DI_STATE_PREPARE = 0,
    DI_STATE_PLAY = 1,
    DI_STATE_PAUSE = 2,
    DI_STATE_FINISHED = 3,
}

---@class DialogueFadeInType
---@type DialogueFadeInType
DialogueConst.FADE_IN_TYPE = {
    NONE = 0, -- 无黑屏
    BLACKSCREEN_AND_FADE_IN = 1, -- 有黑屏且有淡入效果
    BLACKSCREEN_AND_NO_FADE_IN = 2, -- 有黑屏无淡入效果
}

---@class DialogueFadeOutType
---@type DialogueFadeOutType
DialogueConst.FADE_OUT_TYPE = {
    NONE = 0, -- 无黑屏
    BLACKSCREEN_AND_FADE_OUT = 1, -- 有黑屏且有淡出效果
}

---附近Npc隐藏策略, 对应 /Game/Blueprint/DialogueSystem/Enum/DialogueHideNpcType.DialogueHideNpcType
DialogueConst.NPC_HIDE_TYPE = {
    NONE = 0,
    ALL = 1, -- 全部
    RANGE = 2, -- 范围内所有Npc
    SAME_CONFIG = 3, -- 和对话中npc演员ID一致的Npc
}

-- 台本UI样式枚举
DialogueConst.DIALOGUE_CONTENT_UI_TYPE = {
    Default = 0, -- 默认
    Aside = 1, -- 旁白
    Printer = 2, -- 印刷机
    Caption = 3, -- 字幕
}

---@class DialogueCameraSwitchType 
---@type DialogueCameraSwitchType
DialogueConst.DialogueCameraSwitchType = {
	Instant  = 0,
	Smooth = 1,
	EaseIn = 2,
	EaseOut = 3,
	EaseInOut = 4,
}

-- 跟C++定义的枚举EDialoguePreloadItemType保持一致
DialogueConst.PRELOAD_RES_TYPE = {
    Asset = 0, -- UAsset资产
    Sequence = 1, -- Sequence资产
}

-- 移动模式
DialogueConst.MoveMode3C = {
    StartAndEndStop = 0, -- 启停步
    StepForward = 1, -- 步进
    StepBackward = 2, -- 步退
    CalculateSpeed = 3, -- 根据距离时间计算速度
}

-- 对话类型对应的类
DialogueConst.INSTANCE_TYPE_TO_CLASS = {
    [DialogueConst.DIALOGUE_TYPE.LIST] = kg_require("Gameplay.DialogueV2.Instance.ListDialogueInstance").ListDialogueInstance,
    [DialogueConst.DIALOGUE_TYPE.SIMPLE] = kg_require("Gameplay.DialogueV2.Instance.SimpleDialogueInstance").SimpleDialogueInstance,
    [DialogueConst.DIALOGUE_TYPE.NO_CAMERA] = kg_require("Gameplay.DialogueV2.Instance.NoCameraDialogueInstance").NoCameraDialogueInstance,
    [DialogueConst.DIALOGUE_TYPE.NORMAL] = kg_require("Gameplay.DialogueV2.Instance.NormalDialogueInstance").NormalDialogueInstance,
}

-- 对话参与者类型
DialogueConst.PARTICIPANT_TYPE = {
    PERFORMER = "/Game/Blueprint/3C/Actor/BP_DialogueActor.BP_DialogueActor_C", -- 演员
    CAMERA = "/Game/Blueprint/DialogueSystem/SceneActor/BP_DialogueCameraActor.BP_DialogueCameraActor_C", -- 相机
    ROUTE_POINT = "/Game/Blueprint/DialogueSystem/SceneActor/BP_RoutePointActor.BP_RoutePointActor_C", -- 路点
    NIAGARA = "/Game/Blueprint/DialogueSystem/SceneActor/BP_DialogueSceneActorEffect.BP_DialogueSceneActorEffect_C", -- 摆放特效
    MODEL = "/Game/Blueprint/DialogueSystem/SceneActor/BP_DialogueSceneActorModel.BP_DialogueSceneActorModel_C", -- 摆放模型
    LIGHT = "/Game/Blueprint/DialogueSystem/SceneActor/BP_DialogueSceneActorLight.BP_DialogueSceneActorLight_C", -- 灯光
}

-- 参与者类型对应的LocalEntity类型
DialogueConst.PARTICIPANT_TYPE_TO_CLASS = {
    [DialogueConst.PARTICIPANT_TYPE.PERFORMER] = "DialoguePerformer",
    [DialogueConst.PARTICIPANT_TYPE.CAMERA] = "DialogueCamera",
    [DialogueConst.PARTICIPANT_TYPE.ROUTE_POINT] = "DialogueRoutePoint",
    [DialogueConst.PARTICIPANT_TYPE.NIAGARA] = "DialogueNiagara",
    [DialogueConst.PARTICIPANT_TYPE.MODEL] = "DialogueModel",
    [DialogueConst.PARTICIPANT_TYPE.LIGHT] = "DialogueLight",
}

-- 锚点类型,对应蓝图 /Game/Blueprint/DialogueSystem/Enum/DialogueAnchorType.DialogueAnchorType
DialogueConst.ANCHOR_TYPE = {
    ABSOLUTE = 0, -- 绝对坐标
    PLAYER = 1, -- 玩家坐标
    NPC_SPAWNER = 2, -- NPC坐标
    TRIGGER = 3, -- Trigger坐标
    INTERACTOR = 4, -- 场景物坐标
}

---@class DialogueSectionRunningState
---@type DialogueSectionRunningState
DialogueConst.SECTION_RUNNING_STATE = {
    INITED = "INITED",
    RUNNING = "RUNNING",
    FINISHED = "FINISHED",    
}

---@class DialogueSectionFinishReason 
-- Section停止原因
---@type DialogueSectionFinishReason
DialogueConst.SECTION_FINISH_REASON = {
    LIFE_END = "LineEnd", -- 生命周期自然结束
    SKIP = "Skip", -- 跳过
    TERMINATE = "Terminate", -- 强制中断
}

-- 轨道类型
DialogueConst.DIALOGUE_TRACK_TYPE = {
    DIALOGUE = "/Script/KGStoryLineEditor.DialogueDialogueTrack",
}


--region UI


---说话人类型,可以决定UI样式
DialogueConst.TALKER_TYPE = {
    NPC = 0,
    PLAYER = 1,
    ASIDE = 2,
}

---说话人名字类型,可以决定UI样式
DialogueConst.TALKER_NAME_TYPE = {
    OVERRIDE = 0, -- 使用对话配置名字覆盖
    SELF = 1, -- 使用自身配置名字
}

-- 台本UI风格
DialogueConst.CONTENT_UI_TYPE = {
    CSSTYLE = -1,
    DEFAULT = 0, -- 默认
    ASIDE = 1, -- 旁白
    PRINTER = 2, -- 打字机/印刷机
    CAPTION = 3, -- 字幕
}

-- 台本UI风格对应的WBP资源
DialogueConst.DIALOGUE_CONTENT_UI_CELL = {
    [DialogueConst.CONTENT_UI_TYPE.CSSTYLE] = "DialogueUITypeCSStyle",
    [DialogueConst.CONTENT_UI_TYPE.DEFAULT] = nil,
    [DialogueConst.CONTENT_UI_TYPE.ASIDE] = "DialogueUITypeAside",
    [DialogueConst.CONTENT_UI_TYPE.PRINTER] = nil,
    [DialogueConst.CONTENT_UI_TYPE.CAPTION] = "DialogueUITypeCaption",
}

---不响应UI点击事件的原因
DialogueConst.DISABLE_PANEL_CLICK_REASON = {
    IN_MYSTERY = 1, -- 推理玩法中
    IN_QTE = 2,
    IN_SKIP_CONFIRM = 3, -- 跳过对话确认面板打开时
    IN_CUT_PRICE = 4, -- 砍价玩法中
}


--endregion UI

-- 动画混合方式
DialogueConst.ANIMATION_BLEND_TYPE = {
    DIALOGUE = 0, -- 剧编混合
    ANIM_LIB = 1, -- 动作库混合
}

---屏障类型
DialogueConst.BARRIER_TYPE = {
    SKIP_VOICE = 1, -- 跳过台本语音
    SKIP_MOVIE = 2, -- 跳过视频
    WAIT_SELECT_OPTION = 3, -- 等待选项
    QTE = 4,
	SUBMIT_ITEM = 5, -- 提交道具
	SEQUENCE = 6,	-- Sequence
    ACCEPT_QUEST = 7, -- 领取任务
}

---对话Tick屏障类型
DialogueConst.BARRIER_CLASS = {
    [DialogueConst.BARRIER_TYPE.SKIP_VOICE] = kg_require("Gameplay.DialogueV2.TickBarrier.DB_SkipVoice").DB_SkipVoice,
    [DialogueConst.BARRIER_TYPE.SKIP_MOVIE] = kg_require("Gameplay.DialogueV2.TickBarrier.DB_SkipMovie").DB_SkipMovie,
    [DialogueConst.BARRIER_TYPE.WAIT_SELECT_OPTION] = kg_require("Gameplay.DialogueV2.TickBarrier.DB_WaitSelectOption").DB_WaitSelectOption,
    [DialogueConst.BARRIER_TYPE.QTE] = kg_require("Gameplay.DialogueV2.TickBarrier.DB_QTE").DB_QTE,
	[DialogueConst.BARRIER_TYPE.SUBMIT_ITEM] = kg_require("Gameplay.DialogueV2.TickBarrier.DB_SubmitItem").DB_SubmitItem,
    [DialogueConst.BARRIER_TYPE.ACCEPT_QUEST] = kg_require("Gameplay.DialogueV2.TickBarrier.DB_AcceptQuest").DB_AcceptQuest,
	[DialogueConst.BARRIER_TYPE.SEQUENCE] = kg_require("Gameplay.DialogueV2.TickBarrier.DB_Sequence").DB_Sequence
}

DialogueConst.TalkerType = {
    ASIDE = "Asider", -- 旁白
    COMMON_NPC = "CommonNpc", -- 通用NPC
    PLAYER = "player", -- 主要是用来处理主角没有表演但仍然需要玩家说话的情况
}

---相机切换类型
DialogueConst.CameraSwitchType = {
    INSTANT = 0, -- 顺切
    SMOOTH = 1, -- 平滑
}

-- 相机呼吸类型
DialogueConst.CameraBreathType = {
    NONE = 0,
    LEFT = 1,
    RIGHT = 2,
    TOP = 3,
    BOTTOM = 4,
    FRONT = 5,
    BACK = 6,
    ROTATE_LEFT = 7,
    ROTATE_RIGHT = 8,
    ROTATE_TOP = 9,
    ROTATE_BOTTOM = 10
}

-- 默认动画淡出时长
DialogueConst.AnimDefaultBlendOut = 0.2

-- 相机过渡曲线
DialogueConst.CameraFadeCurve = "/Game/Blueprint/DialogueSystem/FadeCurve.FadeCurve"

---@class DialogueOptionState
-- 选项状态
---@type DialogueOptionState
DialogueConst.OptionState = {
    Locked = 0, --选项条件不满足，锁定状态
    UnLocked = 1, --选项条件满足，尚未观看，待观看状态
    Passed = 2, --已观看状态
}

DialogueConst.OptionVisibility = {
    Visible = 0,
    HideWhenPassed = 1, -- 在本次对话中，选择后隐藏
    HideWhenPassedInPhase = 2, -- 在本次对话位面中，选择后隐藏
    GrayedOutWhenPassed = 3, -- 在本次对话中，选择后变灰
}

---@class DialogueBlackboardKey
---黑板key枚举,便于维护，使用短字符串（长度小于40）作为key，方便日志直接输出
---@type DialogueBlackboardKey
DialogueConst.BlackBoardKey = {
    FLOWCHART_MSG = "FLOWCHART_MSG",
    DICE_RESULT = "DICE_RESULT",
    NEED_RESET_FOG = "NEED_RESET_FOG",
    POST_PROCESS_ID_LIST = "POST_PROCESS_ID_LIST",
    PP_EXCLUDE_PERFORMERS = "PP_EXCLUDE_PERFORMERS",
    NEED_EXIT_SIMPLE_CAMERA_MODE = "NEED_EXIT_SIMPLE_CAMERA_MODE",
    QTE_RESULT = "QTE_RESULT",
    NEED_CLOSE_SCREEN_TEXT = "NEED_CLOSE_SCREEN_TEXT",
    OPTION_STATES = "OPTION_STATES",
    SEQUENCE_PLAY_ID = "SEQUENCE_PLAY_ID",
    POV_INFO = "POV_INFO",
    CAMERA_HANDHELD_TOKEN = "CAMERA_HANDHELD_TOKEN",
    DIALOGUE_JUMP_SKIP = "DIALOGUE_JUMP_SKIP",
    PENDING_HIDE_LINE = "PENDING_HIDE_LINE",
    ASPECT_RATIO_CROSS_EPISODES = "ASPECT_RATIO_CROSS_EPISODES", -- 存在跨小段的画幅比
}

---界面方法定义
DialogueConst.PanelFunction = {
    TryFlushContentPrinter = "", -- 刷新打字机
    SetContentUIStyle = "", -- 设置UI风格
    HideContent = "", -- 隐藏台本
    ShowContentSkipArrow = "", -- 显示台本下面小箭头
}

for funcName, _ in pairs(DialogueConst.PanelFunction) do
    DialogueConst.PanelFunction[funcName] = funcName
end

--- 阿罗德斯颜文字表情贴图映射，这里的index是跟蓝图枚举ENUM_ArrodesSubEmoji匹配
DialogueConst.ArrodesSubEmojiTextures = {
    [0] = "", -- 无
    [1] = "/Game/Arts/Effects/FX_Character/Arrodes_FX/Textures/T_Arrodes_01.T_Arrodes_01",
    [2] = "/Game/Arts/Effects/FX_Character/Arrodes_FX/Textures/T_Arrodes_02.T_Arrodes_02",
    [3] = "/Game/Arts/Effects/FX_Character/Arrodes_FX/Textures/T_Arrodes_03.T_Arrodes_03",
    [4] = "/Game/Arts/Effects/FX_Character/Arrodes_FX/Textures/T_Arrodes_04.T_Arrodes_04",
    [5] = "/Game/Arts/Effects/FX_Character/Arrodes_FX/Textures/T_Arrodes_05.T_Arrodes_05",
    [6] = "/Game/Arts/Effects/FX_Character/Arrodes_FX/Textures/T_Arrodes_06.T_Arrodes_06",
    [7] = "/Game/Arts/Effects/FX_Character/Arrodes_FX/Textures/T_Arrodes_07.T_Arrodes_07",
    [8] = "/Game/Arts/Effects/FX_Character/Arrodes_FX/Textures/T_Arrodes_08.T_Arrodes_08",
    [9] = "/Game/Arts/Effects/FX_Character/Arrodes_FX/Textures/T_Arrodes_09.T_Arrodes_09",
    [10] = "/Game/Arts/Effects/FX_Character/Arrodes_FX/Textures/T_Arrodes_011.T_Arrodes_011",
}

---@type EAlphaBlendOption
local EAlphaBlendOp = import("EAlphaBlendOption") -- luacheck:ignore
DialogueConst.LOOKAT_CURVE_TO_ALPHA_BLEND_OP = {
    [0] = EAlphaBlendOp.HermiteCubic, -- 慢速转动
    [1] = EAlphaBlendOp.CubicInOut, -- 快速转动
}

-- 对话闲话气泡类型
DialogueConst.GossipBubbleType = {
    ASIDE = 1, -- 画外音
    BUBBLE = 2, -- 气泡
    ASIDE_CUR_CHAT_CHANNEL = 3, -- 画外音 + 当前频道
    BUBBLE_CUR_CHAT_CHANNEL = 4, -- 气泡 + 当前频道
    BOTTOM_BUBBLE = 5, -- 底部气泡
    BOTTOM_BUBBLE_CUR_CHAT_CHANNEL = 6, -- 底部气泡 + 当前频道
}

---@class DialogueHistoryItemType
---@type DialogueHistoryItemType
DialogueConst.HISTORY_ITEM_TYPE = {
    SCRIPT = 0, -- 台本
    OPTION = 1, -- 选项
    SCREEN_TEXT = 2, -- 黑屏白字
}

---@class DialogueParticipantHideSource
---@type DialogueParticipantHideSource
DialogueConst.PARTICIPANT_HIDE_SOURCE = {
    DIALOGUE_LOGIC = "DIALOGUE_LOGIC", -- 对话逻辑
    DIALOGUE_SEQUENCE = "DIALOGUE_SEQUENCE", -- DialogueSequence
}

--region Section: 必须放在最下面,因为部分Section依赖枚举


DialogueConst.DIALOGUE_SECTION_TYPE = {
    -- 对话流程控制类
    DIALOGUE_CONTENT = "/Game/Blueprint/DialogueSystem/Section/BPS_Dialogue.BPS_Dialogue_C", -- 台本
    STATE_CONTROL = "/Game/Blueprint/DialogueSystem/Section/BPS_StateControl.BPS_StateControl_C", -- 状态控制(暂停)
    EPISODE_DURATION_FLAG = "/Game/Blueprint/DialogueSystem/Section/BPS_EpisodeDuration.BPS_EpisodeDuration_C", -- 无镜对话时长占位

    -- 相机类
    DIALOGUE_SHOT = "/Game/Blueprint/DialogueSystem/Section/BPS_DialogueShot.BPS_DialogueShot_C", -- 普通分镜
    DIALOGUE_SHOT_OLD = "/Game/Blueprint/DialogueSystem/Section/BPS_CameraCut.BPS_CameraCut_C", -- 旧的普通分镜
    DIALOGUE_AUTO_SHOT = "/Game/Blueprint/DialogueSystem/Section/BPS_DialogueAutoShot.BPS_DialogueAutoShot_C", -- 自动相机
    DIALOGUE_AUTO_SHOT_OLD = "/Game/Blueprint/DialogueSystem/Section/BPS_AutoCameraCut.BPS_AutoCameraCut_C", -- 自动相机旧
    CAMERA_DOF = "/Game/Blueprint/DialogueSystem/Section/BPS_CameraDOF.BPS_CameraDOF_C", -- dof插值
    CAMERA_FOV = "/Game/Blueprint/DialogueSystem/Section/BPS_CameraFov.BPS_CameraFov_C", -- fov设置
    SIMPLE_CAMERA_MODE = "/Game/Blueprint/DialogueSystem/Section/BPS_SimpleCameraMode.BPS_SimpleCameraMode_C", -- 简易相机模式

    -- performer
    PERFORMER_PLAY_ANIMATION = "/Game/Blueprint/DialogueSystem/Section/BPS_PlayAnimation.BPS_PlayAnimation_C", -- 演员播放动作
    PERFORMER_LOOT_AT = "/Game/Blueprint/DialogueSystem/Section/BPS_ActorLookAt.BPS_ActorLookAt_C", -- 单个演员的LookAt
    PERFORMER_MOVE_3C = "/Game/Blueprint/DialogueSystem/Section/BPS_NewActorMovement.BPS_NewActorMovement_C", -- 3C移动
    PERFORMER_ROTATE_3C = "/Game/Blueprint/DialogueSystem/Section/BPS_ActorDirection.BPS_ActorDirection_C", -- 3C旋转
    PERFORMER_STILL = "/Game/Blueprint/DialogueSystem/Section/BPS_ActorStill.BPS_ActorStill_C", -- 动作静止
    PERFORMER_TRANSPARENT = "/Game/Blueprint/DialogueSystem/Section/BPS_ActorTransparence.BPS_ActorTransparence_C", -- 半透(固定材质)
    PERFORMER_ATTACH_MESH = "/Game/Blueprint/DialogueSystem/Section/BPS_AttachMesh.BPS_AttachMesh_C", -- 演员挂接模型
    PERFORMER_ATTACH_NIAGARA = "/Game/Blueprint/DialogueSystem/Section/BPS_NewAttachNiagara.BPS_NewAttachNiagara_C", -- 演员挂接模型
    PERFORMER_DISSOLVE = "/Game/Blueprint/DialogueSystem/Section/BPS_Dissolve.BPS_Dissolve_C", -- 演员溶解
    PERFORMER_FACE_ANIMATION = "/Game/Blueprint/DialogueSystem/Section/BPS_FaceAnim.BPS_FaceAnim_C", -- 演员表情
    PERFORMER_AUDIO_2_FACE = "/Game/Blueprint/DialogueSystem/Section/BPS_Auido2Face.BPS_Auido2Face_C", -- 演员口型

    -- niagara
    NIAGARA_ACTIVATE = "/Game/Blueprint/DialogueSystem/Section/BPS_ParticleActive.BPS_ParticleActive_C", -- 特效激活
    NIAGARA_ATTACH_INTERP = "/Game/Blueprint/DialogueSystem/Section/BPS_ParticleAttachment.BPS_ParticleAttachment_C", -- 特效插值挂接

    -- participant
    PARTICIPANT_VISIBLE = "/Game/Blueprint/DialogueSystem/Section/BPS_ActorVisible.BPS_ActorVisible_C", -- 参与者可见性
    PARTICIPANT_MOVE_INTERP = "/Game/Blueprint/DialogueSystem/Section/BPS_Transform.BPS_Transform_C", -- 参与者插值位移

    -- 局内表现效果类
    PLAY_AUDIO = "/Game/Blueprint/DialogueSystem/Section/BPS_Sound.BPS_Sound_C", -- 播放音频
    GLOBAL_LOOK_AT = "/Game/Blueprint/DialogueSystem/Section/BPS_LookAt.BPS_LookAt_C", -- 全局LookAt控制
    SEND_FLOWCHART_MSG = "/Game/Blueprint/DialogueSystem/Section/BPS_SendFlowchartMsg.BPS_SendFlowchartMsg_C", -- 给flowchart发送消息
    DICE_CHECK = "/Game/Blueprint/DialogueSystem/Section/BPS_DiceCheck.BPS_DiceCheck_C", -- 骰子检查
    FOG = "/Game/Blueprint/DialogueSystem/Section/BPS_Fog.BPS_Fog_C", -- 雾效
    POST_PROCESS = "/Game/Blueprint/DialogueSystem/Section/BPS_PostProcess.BPS_PostProcess_C", -- 后效
    DIALOGUE_SEQUENCE_CUT = "/Game/Blueprint/DialogueSystem/Section/BPS_DialogueSequenceCut.BPS_DialogueSequenceCut_C", -- sequence

    -- UI类
    ASPECT_RATIO = "/Game/Blueprint/DialogueSystem/Section/BPS_FrameRadio.BPS_FrameRadio_C", -- 修改画幅
    TAROT_CARD = "/Game/Blueprint/DialogueSystem/Section/BPS_TarotCard.BPS_TarotCard_C", -- 塔罗牌
    PURE_COLOR_FADE = "/Game/Blueprint/DialogueSystem/Section/BPS_FadeInOutPureColor.BPS_FadeInOutPureColor_C", -- 纯色淡入淡出
    PLAY_MOVIE = "/Game/Blueprint/DialogueSystem/Section/BPS_PlayMovie.BPS_PlayMovie_C", -- 播放视频
    PERFORMER_DESCRIPTION = "/Game/Blueprint/DialogueSystem/Section/BPS_ActorDescription.BPS_ActorDescription_C", -- 演员展示
    SCREEN_TEXT = "/Game/Blueprint/DialogueSystem/Section/BPS_BlackScreenText.BPS_BlackScreenText_C", -- 黑屏白字/白屏黑字
    QTE = "/Game/Blueprint/DialogueSystem/Section/BPS_QTE.BPS_QTE_C", -- 黑屏白字/白屏黑字
    HalfAnimation = "/Game/Blueprint/DialogueSystem/Section/BPS_HalfAnimation.BPS_HalfAnimation_C", -- 半身动作

    -- 外部系统关联Section
    MYSTERY = "/Game/Blueprint/DialogueSystem/Section/BPS_Mystery.BPS_Mystery_C", -- 推理系统
    ARRODES_EMOJI = "/Game/Blueprint/DialogueSystem/Section/BPS_ArrodesEmoji.BPS_ArrodesEmoji_C", -- 阿罗德斯表情
    COMMON_MEMORY = "/Game/Blueprint/DialogueSystem/Section/BPS_CommonMemory.BPS_CommonMemory_C", -- 通用闪回
    GOSSIP_BUBBLE = "/Game/Blueprint/DialogueSystem/Section/BPS_GossipBubble.BPS_GossipBubble_C", -- 闲话气泡
}

-- Section类型到实例映射
DialogueConst.DIALOGUE_SECTION_TYPE_TO_CLASS = {
    -- 对话流程控制类
    [DialogueConst.DIALOGUE_SECTION_TYPE.DIALOGUE_CONTENT] = kg_require("Gameplay.DialogueV2.Section.DS_DialogueContent").DS_DialogueContent,
    [DialogueConst.DIALOGUE_SECTION_TYPE.STATE_CONTROL] = kg_require("Gameplay.DialogueV2.Section.DS_StateControl").DS_StateControl,
    [DialogueConst.DIALOGUE_SECTION_TYPE.EPISODE_DURATION_FLAG] = kg_require("Gameplay.DialogueV2.Section.DS_EpisodeDurationFlag").DS_EpisodeDurationFlag,

    -- 相机类
    [DialogueConst.DIALOGUE_SECTION_TYPE.DIALOGUE_SHOT] = kg_require("Gameplay.DialogueV2.Section.DS_DialogueShot").DS_DialogueShot,
    [DialogueConst.DIALOGUE_SECTION_TYPE.DIALOGUE_SHOT_OLD] = kg_require("Gameplay.DialogueV2.Section.DS_DialogueShotOld").DS_DialogueShotOld,
    [DialogueConst.DIALOGUE_SECTION_TYPE.DIALOGUE_AUTO_SHOT] = kg_require("Gameplay.DialogueV2.Section.DS_DialogueAutoShot").DS_DialogueAutoShot,
    [DialogueConst.DIALOGUE_SECTION_TYPE.DIALOGUE_AUTO_SHOT_OLD] = kg_require("Gameplay.DialogueV2.Section.DS_DialogueAutoShotOld").DS_DialogueAutoShotOld,
    [DialogueConst.DIALOGUE_SECTION_TYPE.CAMERA_DOF] = kg_require("Gameplay.DialogueV2.Section.DS_CameraDof").DS_CameraDof,
    [DialogueConst.DIALOGUE_SECTION_TYPE.CAMERA_FOV] = kg_require("Gameplay.DialogueV2.Section.DS_CameraFov").DS_CameraFov,
    [DialogueConst.DIALOGUE_SECTION_TYPE.SIMPLE_CAMERA_MODE] = kg_require("Gameplay.DialogueV2.Section.DS_SimpleCameraMode").DS_SimpleCameraMode,

    -- performer
    [DialogueConst.DIALOGUE_SECTION_TYPE.PERFORMER_PLAY_ANIMATION] = kg_require("Gameplay.DialogueV2.Section.DS_PerformerPlayAnimation").DS_PerformerPlayAnimation,
    [DialogueConst.DIALOGUE_SECTION_TYPE.PERFORMER_LOOT_AT] = kg_require("Gameplay.DialogueV2.Section.DS_PerformerLookAt").DS_PerformerLookAt,
    [DialogueConst.DIALOGUE_SECTION_TYPE.PERFORMER_MOVE_3C] = kg_require("Gameplay.DialogueV2.Section.DS_PerformerMove3C").DS_PerformerMove3C,
    [DialogueConst.DIALOGUE_SECTION_TYPE.PERFORMER_ROTATE_3C] = kg_require("Gameplay.DialogueV2.Section.DS_PerformerRotate3C").DS_PerformerRotate3C,
    [DialogueConst.DIALOGUE_SECTION_TYPE.PERFORMER_STILL] = kg_require("Gameplay.DialogueV2.Section.DS_PerformerStill").DS_PerformerStill,
    [DialogueConst.DIALOGUE_SECTION_TYPE.PERFORMER_TRANSPARENT] = kg_require("Gameplay.DialogueV2.Section.DS_PerformerTransparent").DS_PerformerTransparent,
    [DialogueConst.DIALOGUE_SECTION_TYPE.PERFORMER_ATTACH_MESH] = kg_require("Gameplay.DialogueV2.Section.DS_PerformerAttachMesh").DS_PerformerAttachMesh,
    [DialogueConst.DIALOGUE_SECTION_TYPE.PERFORMER_ATTACH_NIAGARA] = kg_require("Gameplay.DialogueV2.Section.DS_PerformerAttachNiagara").DS_PerformerAttachNiagara,
    [DialogueConst.DIALOGUE_SECTION_TYPE.PERFORMER_DISSOLVE] = kg_require("Gameplay.DialogueV2.Section.DS_PerformerDissolve").DS_PerformerDissolve,
    [DialogueConst.DIALOGUE_SECTION_TYPE.PERFORMER_FACE_ANIMATION] = kg_require("Gameplay.DialogueV2.Section.DS_PerformerFaceAnimation").DS_PerformerFaceAnimation,
    [DialogueConst.DIALOGUE_SECTION_TYPE.PERFORMER_AUDIO_2_FACE] = kg_require("Gameplay.DialogueV2.Section.DS_PerformerAudio2Face").DS_PerformerAudio2Face,

    -- niagara
    [DialogueConst.DIALOGUE_SECTION_TYPE.NIAGARA_ACTIVATE] = kg_require("Gameplay.DialogueV2.Section.DS_NiagaraActivate").DS_NiagaraActivate,
    [DialogueConst.DIALOGUE_SECTION_TYPE.NIAGARA_ATTACH_INTERP] = kg_require("Gameplay.DialogueV2.Section.DS_NiagaraAttachInterp").DS_NiagaraAttachInterp,

    -- participant
    [DialogueConst.DIALOGUE_SECTION_TYPE.PARTICIPANT_VISIBLE] = kg_require("Gameplay.DialogueV2.Section.DS_ParticipantVisible").DS_ParticipantVisible,
    [DialogueConst.DIALOGUE_SECTION_TYPE.PARTICIPANT_MOVE_INTERP] = kg_require("Gameplay.DialogueV2.Section.DS_ParticipantMoveInterp").DS_ParticipantMoveInterp,

    -- 局内表现效果类
    [DialogueConst.DIALOGUE_SECTION_TYPE.PLAY_AUDIO] = kg_require("Gameplay.DialogueV2.Section.DS_PlayAudio").DS_PlayAudio,
    [DialogueConst.DIALOGUE_SECTION_TYPE.GLOBAL_LOOK_AT] = kg_require("Gameplay.DialogueV2.Section.DS_GlobalLookAt").DS_GlobalLookAt,
    [DialogueConst.DIALOGUE_SECTION_TYPE.SEND_FLOWCHART_MSG] = kg_require("Gameplay.DialogueV2.Section.DS_SendFlowchartMsg").DS_SendFlowchartMsg,
    [DialogueConst.DIALOGUE_SECTION_TYPE.DICE_CHECK] = kg_require("Gameplay.DialogueV2.Section.DS_DiceCheck").DS_DiceCheck,
    [DialogueConst.DIALOGUE_SECTION_TYPE.FOG] = kg_require("Gameplay.DialogueV2.Section.DS_Fog").DS_Fog,
    [DialogueConst.DIALOGUE_SECTION_TYPE.POST_PROCESS] = kg_require("Gameplay.DialogueV2.Section.DS_PostProcess").DS_PostProcess,
    [DialogueConst.DIALOGUE_SECTION_TYPE.DIALOGUE_SEQUENCE_CUT] = kg_require("Gameplay.DialogueV2.Section.DS_DialogueSequenceCut").DS_DialogueSequenceCut,

    -- UI类
    [DialogueConst.DIALOGUE_SECTION_TYPE.ASPECT_RATIO] = kg_require("Gameplay.DialogueV2.Section.DS_AspectRatio").DS_AspectRatio,
    [DialogueConst.DIALOGUE_SECTION_TYPE.TAROT_CARD] = kg_require("Gameplay.DialogueV2.Section.DS_TarotCard").DS_TarotCard,
    [DialogueConst.DIALOGUE_SECTION_TYPE.PURE_COLOR_FADE] = kg_require("Gameplay.DialogueV2.Section.DS_PureColorFade").DS_PureColorFade,
    [DialogueConst.DIALOGUE_SECTION_TYPE.PLAY_MOVIE] = kg_require("Gameplay.DialogueV2.Section.DS_PlayMovie").DS_PlayMovie,
    [DialogueConst.DIALOGUE_SECTION_TYPE.PERFORMER_DESCRIPTION] = kg_require("Gameplay.DialogueV2.Section.DS_PerformerDescription").DS_PerformerDescription,
    [DialogueConst.DIALOGUE_SECTION_TYPE.SCREEN_TEXT] = kg_require("Gameplay.DialogueV2.Section.DS_ScreenText").DS_ScreenText,
    [DialogueConst.DIALOGUE_SECTION_TYPE.QTE] = kg_require("Gameplay.DialogueV2.Section.DS_QTE").DS_QTE,
    [DialogueConst.DIALOGUE_SECTION_TYPE.HalfAnimation] = kg_require("Gameplay.DialogueV2.Section.DS_HalfAnimation").DS_HalfAnimation,

    -- 外部系统关联Section
    [DialogueConst.DIALOGUE_SECTION_TYPE.MYSTERY] = kg_require("Gameplay.DialogueV2.Section.DS_Mystery").DS_Mystery,
    [DialogueConst.DIALOGUE_SECTION_TYPE.ARRODES_EMOJI] = kg_require("Gameplay.DialogueV2.Section.DS_ArrodesEmoji").DS_ArrodesEmoji,
    [DialogueConst.DIALOGUE_SECTION_TYPE.COMMON_MEMORY] = kg_require("Gameplay.DialogueV2.Section.DS_CommonMemory").DS_CommonMemory,
    [DialogueConst.DIALOGUE_SECTION_TYPE.GOSSIP_BUBBLE] = kg_require("Gameplay.DialogueV2.Section.DS_GossipBubble").DS_GossipBubble,
}

-- 独占Section,无镜不能用
DialogueConst.EXCLUSIVE_SECTION = {
    [DialogueConst.DIALOGUE_SECTION_TYPE.DIALOGUE_CONTENT] = 1,

    -- 相机类
    [DialogueConst.DIALOGUE_SECTION_TYPE.DIALOGUE_SHOT] = 1,
    [DialogueConst.DIALOGUE_SECTION_TYPE.DIALOGUE_SHOT_OLD] = 1,
    [DialogueConst.DIALOGUE_SECTION_TYPE.DIALOGUE_AUTO_SHOT] = 1,
    [DialogueConst.DIALOGUE_SECTION_TYPE.DIALOGUE_AUTO_SHOT_OLD] = 1,
    [DialogueConst.DIALOGUE_SECTION_TYPE.CAMERA_DOF] = 1,
    [DialogueConst.DIALOGUE_SECTION_TYPE.CAMERA_FOV] = 1,
    [DialogueConst.DIALOGUE_SECTION_TYPE.SIMPLE_CAMERA_MODE] = 1,

    -- 局内表现效果类
    [DialogueConst.DIALOGUE_SECTION_TYPE.DICE_CHECK] = 1,
    [DialogueConst.DIALOGUE_SECTION_TYPE.FOG] = 1,
    [DialogueConst.DIALOGUE_SECTION_TYPE.POST_PROCESS] = 1,
    [DialogueConst.DIALOGUE_SECTION_TYPE.DIALOGUE_SEQUENCE_CUT] = 1,

    -- UI类
    [DialogueConst.DIALOGUE_SECTION_TYPE.ASPECT_RATIO] = 1,
    [DialogueConst.DIALOGUE_SECTION_TYPE.TAROT_CARD] = 1,
    [DialogueConst.DIALOGUE_SECTION_TYPE.PURE_COLOR_FADE] = 1,
    [DialogueConst.DIALOGUE_SECTION_TYPE.PLAY_MOVIE] = 1,
    [DialogueConst.DIALOGUE_SECTION_TYPE.PERFORMER_DESCRIPTION] = 1,
    [DialogueConst.DIALOGUE_SECTION_TYPE.SCREEN_TEXT] = 1,
    [DialogueConst.DIALOGUE_SECTION_TYPE.QTE] = 1,
    [DialogueConst.DIALOGUE_SECTION_TYPE.HalfAnimation] = 1,

    -- 外部系统关联Section
    [DialogueConst.DIALOGUE_SECTION_TYPE.MYSTERY] = 1,
}

-- 暂停时仍然需要Tick的Section
DialogueConst.IGNORE_PAUSE_SECTION = {
    [DialogueConst.DIALOGUE_SECTION_TYPE.DIALOGUE_SHOT] = 1,
    [DialogueConst.DIALOGUE_SECTION_TYPE.DIALOGUE_SHOT_OLD] = 1,
    [DialogueConst.DIALOGUE_SECTION_TYPE.DIALOGUE_AUTO_SHOT] = 1,
    [DialogueConst.DIALOGUE_SECTION_TYPE.DIALOGUE_AUTO_SHOT_OLD] = 1,
    -- [DialogueConst.DIALOGUE_SECTION_TYPE.ARRODES_EMOJI] = 1,
}

-- 点击跳过，需要停住的section
DialogueConst.CANNOT_SKIP_SECTION = {
	[DialogueConst.DIALOGUE_SECTION_TYPE.QTE] = 1,
	[DialogueConst.DIALOGUE_SECTION_TYPE.MYSTERY] = 1,
	[DialogueConst.DIALOGUE_SECTION_TYPE.DICE_CHECK] = 1,
}


--endregion Section: 必须放在最下面,因为部分Section依赖枚举
