---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/23 16:31
---
---@class DialoguePanelInterface 接口类
DialoguePanelInterface = DefineClass("DialoguePanelInterface")

function DialoguePanelInterface:ctor(dialoguePanel)
    ---@type Dialogue_Panel
    self.dialoguePanel = dialoguePanel
end

function DialoguePanelInterface:dtor()
    Log.Debug("[DialogueV2]destroy DialoguePanelInterface.")
    self.dialoguePanel = nil
end

---@public
---@param funcName string
---@return any
function DialoguePanelInterface:InnerCallPanelFunction(funcName, ...)
    if not self.dialoguePanel then
        Log.Warning("[DialogueV2][InnerCallPanelFunction] dialogue panel has been destroyed")
        return
    end

    if DialogueConst.PanelFunction[funcName] == nil then
        Log.WarningFormat("[DialogueV2][InnerCallPanelFunction] %s not a registered function", funcName)
        return
    end

    local func = self.dialoguePanel[funcName]
    if (func == nil) or (type(func) ~= "function") then
        Log.WarningFormat("[DialogueV2][InnerCallPanelFunction] %s not a function", funcName)
        return
    end

    return func(self.dialoguePanel, ...)
end

function DialoguePanelInterface:SetPrintSpeed(speed)
    self.dialoguePanel:SetPrintSpeed(speed)
end

function DialoguePanelInterface:FlushPrint()
    self.dialoguePanel:FlushPrint()
end

function DialoguePanelInterface:ShowContent(title, talkerName, content, talkerType, subtitle, small, smallPos, bShowTalkerNameInCSStyle, sectionConfig, subTitleType)
    self.dialoguePanel:ShowContent(title, talkerName, content, talkerType, subtitle, small, smallPos, bShowTalkerNameInCSStyle, sectionConfig, subTitleType)
end

---@param options DialogueOption[]
---@param optionType number
---@param bTimeLimit boolean
---@param timeLimited number
---@param bChoice boolean
function DialoguePanelInterface:ShowOptions(options, optionType, bTimeLimit, timeLimited, bChoice)
    self.dialoguePanel:ShowOptions(options, optionType, bTimeLimit, timeLimited, bChoice)
end

function DialoguePanelInterface:HideOptionComp()
	self.dialoguePanel:HideOptionComp()
end

function DialoguePanelInterface:SetReviewButtonVisible(bVisible)
    self.dialoguePanel:SetReviewButtonVisible(bVisible)
end

function DialoguePanelInterface:SetSkipButtonVisible(bVisible)
    self.dialoguePanel:SetSkipButtonVisible(bVisible)
end

function DialoguePanelInterface:SetAutoPlayButtonVisible(bVisible)
    self.dialoguePanel:SetAutoPlayButtonVisible(bVisible)
end

function DialoguePanelInterface:PlayMovie(movieName, endCallback)
    self.dialoguePanel:PlayMovie(movieName, endCallback)
end

function DialoguePanelInterface:StopMovie()
    self.dialoguePanel:StopMovie()
end

function DialoguePanelInterface:ShowContentSkipArrow()
    self.dialoguePanel:ShowContentSkipArrow()
end

---@return number
function DialoguePanelInterface:GetCurrentMovieDuration()
    return self.dialoguePanel:GetCurrentMovieDuration()
end

function DialoguePanelInterface:TryFlushContentPrinter()
    self.dialoguePanel:TryFlushContentPrinter()
end

function DialoguePanelInterface:SetDialogueContentUIType(InType)
	self.dialoguePanel:SetDialogueContentUIType(InType)
end

---@param timeCur number @ 单位：秒
---@param duration number @ 单位：秒
function DialoguePanelInterface:UpdateDialogueProgress(timeCur, duration)
    self.dialoguePanel:UpdateDialogueProgress(timeCur, duration)
end

---@param color number
---@param fadeInTime number @ 单位：秒
---@param fadeOutTime number @ 单位：秒
---@param duration number @ 单位：秒
function DialoguePanelInterface:ShowDialogueMask(color, fadeInTime, fadeOutTime, duration)
    Log.DebugFormat("[DialogueV2]ShowDialogueMask fadeInTime=%s fadeOutTime=%s duration=%s", fadeInTime, fadeOutTime, duration)
    self.dialoguePanel:ShowDialogueMask(color, fadeInTime, fadeOutTime, duration)
end

function DialoguePanelInterface:HideDialogueMask()
    Log.DebugFormat("[DialogueV2]HideDialogueMask")
    self.dialoguePanel:HideDialogueMask()
end

function DialoguePanelInterface:SetDialogueControlPanelVisibilityByReason(bVisible, reason)
    Log.DebugFormat("[DialogueV2]SetDialogueControlPanelVisibilityByReason bVisible=%s reason=%s", bVisible, reason)
	self.dialoguePanel:SetDialogueControlPanelVisibilityByReason(bVisible, reason)
end
