---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/23 18:10
---
---@class DialogueBarrierBase : LuaClass
---@field dialogueInstance DialogueInstanceBase
DialogueBarrierBase = DefineClass("DialogueBarrierBase")

local LuaMulticastDelegate = kg_require("Framework.KGFramework.KGCore.Delegates.LuaMulticastDelegate").LuaMulticastDelegate
function DialogueBarrierBase:ctor(dialogueInstance, duration, ...)
    ---@type DialogueInstanceBase
    self.dialogueInstance = dialogueInstance
    ---@type number
    self.runningTime = 0
    ---@type number
    self.duration = duration
    ---@type LuaMulticastDelegate
    self.OnFinishDelegate  = LuaMulticastDelegate.new()
end

function DialogueBarrierBase:dtor()
    self.dialogueInstance = nil
    self.OnFinishDelegate:Clear()
end

function DialogueBarrierBase:NeedFinish()
    if not self.duration then
        return false
    end

    return self.runningTime >= self.duration
end

function DialogueBarrierBase:StartBarrier()
    Log.InfoFormat("[DialogueV2]StartBarrier %s", self.__cname)
    self.dialogueInstance:PausePlay(true)
    self:OnStart()
end

function DialogueBarrierBase:TickBarrier(deltaTime)
    self.runningTime = self.runningTime + deltaTime
    self:OnTick()
end

function DialogueBarrierBase:FinishBarrier()
    self:OnFinish()
    self.OnFinishDelegate:Broadcast(self)
    Log.InfoFormat("[DialogueV2]FinishBarrier %s", self.__cname)
    self.dialogueInstance:ResumePlay()
    self:delete()
end

---子类可重写
---@public
---@return boolean
function DialogueBarrierBase:CanSkip()
    return true
end

---@protected
function DialogueBarrierBase:OnStart()

end

---@protected
function DialogueBarrierBase:OnTick()

end

---@protected
function DialogueBarrierBase:OnFinish()

end
