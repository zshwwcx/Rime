---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/29 20:55
---
local DialogueBarrierBase = kg_require("Gameplay.DialogueV2.TickBarrier.DialogueBarrierBase").DialogueBarrierBase

---@class DB_SkipMovie : DialogueBarrierBase
DB_SkipMovie = DefineClass("DB_SkipMovie", DialogueBarrierBase)

function DB_SkipMovie:ctor(_, _, bCanSkip)
    self.bCanSkip = bCanSkip
end

---@overload
---@return boolean
function DB_SkipMovie:CanSkip()
    return self.bCanSkip
end

function DB_SkipMovie:OnFinish()
    Game.DialogueManagerV2.UIProcessor:StopMovie()
end
