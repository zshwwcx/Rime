local DialogueBarrierBase = kg_require("Gameplay.DialogueV2.TickBarrier.DialogueBarrierBase").DialogueBarrierBase

---@class DB_Sequence : DialogueBarrierBase
DB_Sequence = DefineClass("DB_Sequence", DialogueBarrierBase)

function DB_Sequence:ctor(_, _, sectionConfig)
	self.sectionConfig = sectionConfig
end

function DB_Sequence:CanSkip()
	return false
end

function DB_Sequence:OnStart()
	self.dialogueInstance.currentEpisode:SetStopPoint(true)
end

function DB_Sequence:OnFinish()
	if self.dialogueInstance.currentEpisode then
		self.dialogueInstance.currentEpisode:SetStopPoint(false)
	end
end

function DB_Sequence:OnTick()
    local bSuccess, x, y, z, pitch, yaw, roll, fov, aspectRatio, bConstraintAspectRatio = import("UIFunctionLibrary").GetSequenceCameraPovInfo(Game.WorldContext)
    if bSuccess and self.dialogueInstance and not self.dialogueInstance.isDestroyed then
        local blackboardPOV = self.dialogueInstance:GetBlackBoardValue(DialogueConst.BlackBoardKey.POV_INFO)
        if not blackboardPOV then
            self.dialogueInstance:SetBlackBoardValue(DialogueConst.BlackBoardKey.POV_INFO, {
                x = x,
                y = y,
                z = z,
                pitch = pitch,
                yaw = yaw,
                roll = roll,
                fov = fov,
                aspectRatio = aspectRatio,
                bConstraintAspectRatio = bConstraintAspectRatio
            })
        else
            blackboardPOV.x = x
            blackboardPOV.y = y
            blackboardPOV.z = z
            blackboardPOV.pitch = pitch
            blackboardPOV.yaw = yaw
            blackboardPOV.roll = roll
            blackboardPOV.fov = fov
            blackboardPOV.aspectRatio = aspectRatio
            blackboardPOV.bConstraintAspectRatio = bConstraintAspectRatio
        end
    end
end
