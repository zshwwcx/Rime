local DialogueBarrierBase = kg_require("Gameplay.DialogueV2.TickBarrier.DialogueBarrierBase").DialogueBarrierBase

---@class DB_AcceptQuest : DialogueBarrierBase
DB_AcceptQuest = DefineClass("DB_AcceptQuest", DialogueBarrierBase)

function DB_AcceptQuest:ctor(_, _)
    ---@type string
	self.waitCloseUI = nil
    self.state = 0
end

function DB_AcceptQuest:dtor()
    Game.GlobalEventSystem:RemoveListener(EEventTypesV2.ON_UI_CLOSE, "OnCloseUI", self)
end

function DB_AcceptQuest:CanSkip()
	return false
end

function DB_AcceptQuest:OnStart()
	self.waitCloseUI = UIPanelConfig.TaskAcceptPanel
    Game.GlobalEventSystem:AddListener(EEventTypesV2.ON_UI_CLOSE, "OnCloseUI", self)
    
    local dialogueInstance = self.dialogueInstance
    local receiveRingID = dialogueInstance.PlayParams.ReceiveRingID
    local npcCfgID = dialogueInstance.PlayParams.NPCID
    Game.NewUIManager:OpenPanel(self.waitCloseUI, receiveRingID, npcCfgID or 0, dialogueInstance.DialogueID)

	self.dialogueInstance.currentEpisode:SetStopPoint(true)

    self.state = 1
    Log.InfoFormat("[DialogueV2]DB_AcceptQuest open %s RingID is %d in dialogue %s",
        self.waitCloseUI, receiveRingID, dialogueInstance.DialogueID)
end

function DB_AcceptQuest:NeedFinish()
    return self.waitCloseUI == nil and self.state == 2
end

function DB_AcceptQuest:OnFinish()
	if self.dialogueInstance.currentEpisode then
		self.dialogueInstance.currentEpisode:SetStopPoint(false)
	end
	Game.GlobalEventSystem:RemoveListener(EEventTypesV2.ON_UI_CLOSE, "OnCloseUI", self)
end

function DB_AcceptQuest:OnCloseUI(uid)
    if uid == self.waitCloseUI then
        self.waitCloseUI = nil
        self.state = 2
    end
end
