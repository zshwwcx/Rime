---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/6/3 21:25
---
local DialogueBarrierBase = kg_require("Gameplay.DialogueV2.TickBarrier.DialogueBarrierBase").DialogueBarrierBase

---@class DB_WaitSelectOption : DialogueBarrierBase
DB_WaitSelectOption = DefineClass("DB_WaitSelectOption", DialogueBarrierBase)

function DB_WaitSelectOption:CanSkip()
    return false
end
