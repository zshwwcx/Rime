local DialogueBarrierBase = kg_require("Gameplay.DialogueV2.TickBarrier.DialogueBarrierBase").DialogueBarrierBase

---@class DB_QTE : DialogueBarrierBase
---@field private sectionConfig BPS_QTE_C
---@field private objQTE QTE_Button
DB_QTE = DefineClass("DB_QTE", DialogueBarrierBase)
function DB_QTE:ctor(_, _, sectionConfig)
    self.sectionConfig = sectionConfig
    ---@type number[]
    self.clickTimeList = {}
    ---@type number
    self.frameCounter = 0
end

---@overload
---@return boolean
function DB_QTE:CanSkip()
    return false
end

function DB_QTE:OnStart()
    local qteConf =  self.sectionConfig
    self.QTEObjID = Game.BSQTEManager:AddNewQTE(qteConf.QTEType, qteConf.QTELifeTime,  qteConf)
    if self.QTEObjID then
        Game.UniqEventSystemMgr:AddListener(self.QTEObjID, EEventTypesV2.ON_QTE_SUCESSED, 'OnQTESuccess', self)
        Game.UniqEventSystemMgr:AddListener(self.QTEObjID, EEventTypesV2.ON_QTE_FAILED, 'OnQTEFailed', self)
        Game.UniqEventSystemMgr:AddListener(self.QTEObjID, EEventTypesV2.ON_QTE_CLICKED_SUCESSED, 'OnQTEClicked', self)
        Game.UniqEventSystemMgr:AddListener(self.QTEObjID, EEventTypesV2.ON_QTE_END, 'OnQTEEnd', self)
    end
	
	self.dialogueInstance.currentEpisode:SetStopPoint(true)

    -- todo@wangxu31:PP设置标准接口
end

function DB_QTE:OnTick(deltaTime)
    -- 先注释掉，看新的通用QTE需要什么逻辑处理
    -- -- 这里通过将duration设置为0来触发下一帧tick时,结束barrier,比较trick
    -- if self.runningTime >= self.sectionConfig.QTELifeTime then
    --     Log.DebugFormat("[DialogueV2][DB_QTE][OnTick] timeout, QTE failed")
    --     self.duration = 0
    --     self:checkQTEResult()
    --     return
    -- end

    -- self.frameCounter = self.frameCounter + 1
    -- if self.frameCounter >= 3 then
    --     self.frameCounter = 0
    --     self:checkQTEResult()
    -- end
end

function DB_QTE:OnFinish()
    if self.QTEObjID then
        Game.BSQTEManager:RemoveQTE(self.QTEObjID)
        self.QTEObjID = nil
    end

	if self.dialogueInstance.currentEpisode then
		self.dialogueInstance.currentEpisode:SetStopPoint(false)
	end
end

function DB_QTE:OnQTESuccess()
    Log.InfoFormat("[DialogueV2][DB_QTE] QTE success")
    self.duration = 0
    self.dialogueInstance:SetBlackBoardValue(DialogueConst.BlackBoardKey.QTE_RESULT, true)
end

function DB_QTE:OnQTEFailed()
    Log.InfoFormat("[DialogueV2][DB_QTE] QTE failed")
end

function DB_QTE:OnQTEEnd()
    Log.DebugFormat("[DialogueV2][DB_QTE] QTE End")
    Game.UniqEventSystemMgr:RemoveListener(self.QTEObjID, EEventTypesV2.ON_QTE_SUCESSED, 'OnQTESuccess', self)
    Game.UniqEventSystemMgr:RemoveListener(self.QTEObjID, EEventTypesV2.ON_QTE_FAILED, 'OnQTEFailed', self)
    Game.UniqEventSystemMgr:RemoveListener(self.QTEObjID, EEventTypesV2.ON_QTE_CLICKED_SUCESSED, 'OnQTEClicked', self)
    Game.UniqEventSystemMgr:RemoveListener(self.QTEObjID, EEventTypesV2.ON_QTE_END, 'OnQTEEnd', self)
end

function DB_QTE:OnQTEClicked(index)
    table.insert(self.clickTimeList, Game.GameTimeMS)
    self:tryShakeCamera()
end

---------------------------------------------------------------------------------------------------
--- private
---------------------------------------------------------------------------------------------------
function DB_QTE:tryShakeCamera()
    local currentTime = Game.GameTimeMS
    local clickTimeList = self.clickTimeList

    local cnt = 0
    for idx = #clickTimeList, 1, -1 do
        if currentTime - clickTimeList[idx] < 1000 then
            cnt = cnt + 1
        else
            break
        end
    end

    local cameraShakeIndex = 0
    if cnt >= 6 then
        cameraShakeIndex = 3
    elseif cnt >= 3 then
        cameraShakeIndex = 2
    elseif cnt >= 1 then
        cameraShakeIndex = 1
    end

    local cameraShakeClass = self.sectionConfig.CameraShake[cameraShakeIndex]
    if cameraShakeClass then
        -- todo@zhaojunjie:连续调会不会有问题?
        Game.CameraManager:StartCameraShakeByAssetPath(cameraShakeClass, 1.0, 0)
    end
end

function DB_QTE:checkQTEResult()
    -- local bSuccessed = #self.clickTimeList >= self.sectionConfig.PressTimes

    -- -- 达标,抛出事件并关闭
    -- if bSuccessed then
    --     self.duration = 0
    --     self.dialogueInstance:SetBlackBoardValue(DialogueConst.BlackBoardKey.QTE_RESULT, bSuccessed)
    -- end
end
