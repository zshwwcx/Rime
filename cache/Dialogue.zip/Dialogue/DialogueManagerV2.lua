---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/7 11:13
---
kg_require("Gameplay.DialogueV2.Entity.DialogueLight")
kg_require("Gameplay.DialogueV2.Entity.DialogueModel")
kg_require("Gameplay.DialogueV2.Entity.DialogueModelBP")
kg_require("Gameplay.DialogueV2.Entity.DialogueNiagara")
kg_require("Gameplay.DialogueV2.Entity.DialogueRoutePoint")
kg_require("Gameplay.DialogueV2.Entity.DialogueCamera")
kg_require("Gameplay.DialogueV2.Entity.DialoguePerformer")

local DialogueUIProcessor = kg_require("Gameplay.DialogueV2.DialogueUIProcessor").DialogueUIProcessor
local DialogueHistory = kg_require("Gameplay.DialogueV2.DialogueHistory").DialogueHistory
local DialogueSequenceManager = kg_require("Gameplay.DialogueV2.DialogueSequenceManager").DialogueSequenceManager
local DialogueLoader = kg_require("Gameplay.DialogueV2.DialogueLoader").DialogueLoader
local DialogueInputProcessor = kg_require("Gameplay.DialogueV2.DialogueInputProcessor").DialogueInputProcessor
local DialogueFrameSmoother = kg_require("Gameplay.DialogueV2.DialogueFrameSmoother").DialogueFrameSmoother
local DialogueAssetMgr = kg_require("Gameplay.DialogueV2.DialogueAssetMgr").DialogueAssetMgr

local BoolPropDefs = kg_require("Shared.BoolPropDefs")
local TimerBase = kg_require("Framework.KGFramework.KGCore.TimerManager.TimerBase").TimerBase
local C7FunctionLibrary = import("C7FunctionLibrary")

---@class DialoguePlayParams
---@field AssetID number|number[]
---@field NPCID number
---@field ActorEntityID number
---@field QuestID number
---@field TaskRingID number
---@field SubmitItemID number
---@field NewSubmitCfg table
---@field CondIdx number
---@field ReceiveRingID number
---@field SpawnTransform table
---@field StartEpisodeIndex  number @ 编辑器态可以选择从制定小段开始播放
---@field StartEpisodeLineIdx number(editor) 编辑态可以选择从指定小段的第几句台本开始播放
---@field StartTime number(editor) 编辑态可以通过拖动游标让对话从某个时刻开始播放



---@return boolean
function _G.IsValidObjectName(name)
    if type(name) ~= "string" then
        return false
    end

    if (name == nil) or (name == "") or (name == "None") then
        return false
    end

    return true
end

---@class DialogueManagerV2 : TimerBase
---@field public AssetMgr DialogueAssetMgr
---@field public InputProcessor DialogueInputProcessor
---@field public curExclusiveInstance NormalDialogueInstance|ListDialogueInstance
---@field public DialogueHistory DialogueHistory
---@field public UIProcessor DialogueUIProcessor
---@field public SequenceManager DialogueSequenceManager
DialogueManagerV2 = DefineClass("DialogueManagerV2", TimerBase)

function DialogueManagerV2:Init()
    ---@type DialogueLoader
    self.loader = DialogueLoader.new()
    self.loader:Init()

    self.AssetMgr = DialogueAssetMgr.new()
    self.AssetMgr:Init()

    ---@type DialogueFrameSmoother
    self.frameSmoother = DialogueFrameSmoother.new(50)
    ---@type number
    self.avgFrameTime = 0.0

    ---@type DialogueInstanceBase
    self.curExclusiveInstance = nil

    ---@type table<number, DialogueInstanceBase>
    self.activateNoCameraInstances = {}

    ---@tyep { OptionID : number, OptionIndex : number}
    self.LastOption = { OptionID = nil, OptionIndex = nil }
	
    ---@type DialogueUIProcessor
    self.UIProcessor = DialogueUIProcessor.new()
    self.UIProcessor:Init()

    ---@type DialogueInputProcessor
    self.InputProcessor = DialogueInputProcessor.new()
    self.InputProcessor:Init()

    ---@type DialogueHistory
	self.DialogueHistory = DialogueHistory.new()

    ---@type DialogueSequenceManager
    self.SequenceManager = DialogueSequenceManager.new()

    ---@type boolean @ 是否自动播放，主要与记录玩家设置的自动播放状态
    self.bPlayerAutoPlaySetting = nil

    self.minFrameTime = DialogueConst.MIN_FRAME_TIME * 1000
    ---@type DialogueEndReason
    self.lastDialogueEndReason = nil
    
    Game.GlobalEventSystem:AddListener(EEventTypesV2.GAME_ENTER_STAGE_SHOW_UI_END, "OnGameEnterStageShowUIEnd", self)
end

function DialogueManagerV2:UnInit()
    self:TerminateAllDialogue(DialogueConst.END_REASON.TERMINATE_ON_DIALOGUE_SYSTEM_DESTROY)

    self.AssetMgr:UnInit()

    if self.tickTimer then
        self:DelTimer(self.tickTimer)
        self.tickTimer = nil
    end

    self.UIProcessor:UnInit()
    self.InputProcessor:UnInit()
    Game.GlobalEventSystem:RemoveTargetAllListeners(self)
end

---@public
---@param params DialoguePlayParams
---@return PlayDialogueErrorCode
function DialogueManagerV2:Enter(params)
    if not self.bNetValid then
        Log.Warning("[DialogueV2]Enter failed:network is invalid")
        return -1
    end
    
    local ErrorCode = DialogueConst.PlayDialogueErrorCode
    local dialogueID = params.AssetID
    if not self:isValidDialogueID(dialogueID) then
        Log.WarningFormat("[DialogueV2]Enter failed: dialogueID(%s) is invalid", dialogueID)
        return ErrorCode.INVALID_DIALOGUE_ID
    end

	C7FunctionLibrary.UpdateCrashReportValue("PlayDialogue", tostring(dialogueID))  -- CrashSight
	
    -- 按类型创建不同的Instance
    local dialogueType = self:getDialogueType(dialogueID)
    if not dialogueType then
        Log.ErrorFormat("[DialogueV2]Enter failed: get dialogue type failed for %s", dialogueID)
        return ErrorCode.INVALID_DIALOGUE_TYPE
    end
    
    if not self:CanPlayDialogue(dialogueID, dialogueType) then
        Log.WarningFormat("[DialogueV2]Enter failed: CanPlayDialogue is false on playing %s", dialogueID)
        return ErrorCode.STATE_CONFLICTED
    end

    if self:IsPlayingExclusiveDialogue() and dialogueType ~= DialogueConst.DIALOGUE_TYPE.NO_CAMERA then
        -- 如果需要播的，跟正在播的是同一个，直接return(首次dialogue异步加载，此时存在交互物选项没有消失，点击交互物选项，会触发相同dialogue二次播放)
        if dialogueID == self.curExclusiveInstance.DialogueID then
            Log.WarningFormat("[DialogueV2]Enter dialogue %s failed: another dialogue is being playing.", params.AssetID)
            return ErrorCode.ASYNC_LOAD_DIALOGUE
        end
        
        local tempDialogueID = self.curExclusiveInstance.DialogueID
        self.curExclusiveInstance:Terminate(DialogueConst.END_REASON.TERMINATE_ON_NEW_PLAY_REQUEST)
        self.curExclusiveInstance = nil

        self:SwitchDialogueStateConflict(false, tempDialogueID)
    end

    ---- 如果有相同ID的无镜对话,也尝试停止
    --local activateNoCameraInstance = self.activateNoCameraInstances[dialogueID]
    --if activateNoCameraInstance then
    --    activateNoCameraInstance:Terminate()
    --end

    local dialogueInstanceClass = DialogueConst.INSTANCE_TYPE_TO_CLASS[dialogueType]
    if not dialogueInstanceClass then
        Log.ErrorFormat("[DialogueV2]Enter failed: get dialogue instance class failed for %s", dialogueID)
        return ErrorCode.HAS_NO_DIALOGUE_CLASS
    end

    ---@type DialogueInstanceBase
    local newDialogueInstance = dialogueInstanceClass.new(params, dialogueType)
    newDialogueInstance:RegisterStage()
    if not newDialogueInstance:Init() then
        Log.WarningFormat("[DialogueV2]Dialogue instance failed to be inited for %s and will be destroyed soon. ", dialogueID)
        newDialogueInstance:UnInit()
        return ErrorCode.DIALOGUE_INIT_FAILED
    end
    
    if dialogueType == DialogueConst.DIALOGUE_TYPE.NO_CAMERA then
        self.activateNoCameraInstances[dialogueID] = newDialogueInstance
        Log.InfoFormat("[DialogueV2]Enter new [NO_CAMERA] dialogue: %s instance:%s", dialogueID, newDialogueInstance:ToString())
    else
        self.curExclusiveInstance = newDialogueInstance
        Log.InfoFormat("[DialogueV2]Enter new dialogue %s instance:%s", dialogueID, newDialogueInstance:ToString())
    end

    if not self.tickTimer then
        self.tickTimer = self:AddTickTimer(-1, "Tick")
        self.lastTickTime = Game:GetGameTimeMS()
    end

    newDialogueInstance:Activate()
    
    if dialogueType ~= DialogueConst.DIALOGUE_TYPE.NO_CAMERA then
        self:SwitchDialogueStateConflict(true, dialogueID)
    end
    
    return ErrorCode.SUCCESS
end

-- 中断单个对话
---@public
---@param dialogueID number
---@param endReason DialogueEndReason
function DialogueManagerV2:TerminateDialogue(dialogueID, endReason)
	C7FunctionLibrary.UpdateCrashReportValue("PlayDialogue", "0")  -- CrashSight
    -- 不传ID就默认停当前正在进行的独占
    if not dialogueID then
        Log.InfoFormat("[DialogueV2]TerminateDialogue without ID, will terminate curExclusiveDialogue")
        self:terminateCurExclusiveDialogue(endReason)
        return
    end

    Log.InfoFormat("[DialogueV2]TerminateDialogue %s endReason:%s", dialogueID, endReason)
    local curExclusiveInstance = self.curExclusiveInstance
    if curExclusiveInstance ~= nil and curExclusiveInstance.DialogueID == dialogueID then
        self:terminateCurExclusiveDialogue(endReason)
    end

    local noCameraDialogueInstance = self.activateNoCameraInstances[dialogueID]
    if noCameraDialogueInstance then
        self.activateNoCameraInstances[dialogueID] = nil
        noCameraDialogueInstance:Terminate(endReason)
    end
end

-- 中断所有对话
---@public
---@param endReason DialogueEndReason
function DialogueManagerV2:TerminateAllDialogue(endReason)
    Log.InfoFormat("[DialogueV2]TerminateAllDialogue at date:%s, reason:%s", os.date("%Y-%m-%d %H:%M:%S"), endReason)
	C7FunctionLibrary.UpdateCrashReportValue("PlayDialogue", "0")  -- CrashSight
    
    local curExclusiveInstance = self.curExclusiveInstance
    if curExclusiveInstance then
        local tempDialogueID = curExclusiveInstance.DialogueID
        curExclusiveInstance:Terminate(endReason)
        curExclusiveInstance:delete()
        self.curExclusiveInstance = nil

        self.UIProcessor:Clear()
        self:SwitchDialogueStateConflict(false, tempDialogueID)
    end

    for _, noCameraDialogueInstance in pairs(self.activateNoCameraInstances) do
        noCameraDialogueInstance:Terminate(endReason)
        noCameraDialogueInstance:delete()
    end

    table.clear(self.activateNoCameraInstances)
end

-- 对话寿终正寝
---@public
---@param dialogueID number
function DialogueManagerV2:OnDialogueFinished(dialogueID)
	C7FunctionLibrary.UpdateCrashReportValue("PlayDialogue", "0")  -- CrashSight
    if dialogueID == nil then
        return
    end
    Game.SequenceManager:OnDialoguePlayFinish(dialogueID)
    Log.InfoFormat("[DialogueV2]OnDialogueFinished: finish dialogue %s", dialogueID)
    local curExclusiveInstance = self.curExclusiveInstance
    if (curExclusiveInstance ~= nil) and (curExclusiveInstance.DialogueID == dialogueID) then
        curExclusiveInstance:UnInit()
        curExclusiveInstance:delete()
        self.curExclusiveInstance = nil
        self.UIProcessor:Clear()
       self:SwitchDialogueStateConflict(false, dialogueID)
        
        Log.InfoFormat("[DialogueV2]OnDialogueFinished: destroy exclusive dialogue %d done", dialogueID)
    end

    local noCameraDialogueInstance = self.activateNoCameraInstances[dialogueID]
    if noCameraDialogueInstance then
        self.activateNoCameraInstances[dialogueID] = nil
        noCameraDialogueInstance:UnInit()
        noCameraDialogueInstance:delete()
        Log.InfoFormat("[[DialogueV2]OnDialogueFinished: destroy NO_CAMERA dialogue %d done", dialogueID)
    end
    
    self.AssetMgr:UnloadDialogue(dialogueID)

    if self.tickTimer and self.curExclusiveInstance == nil and next(self.activateNoCameraInstances) == nil then
        self:DelTimer(self.tickTimer)
        self.tickTimer = nil
    end
end

---@public
---@param dialogueID number|table
---@param dialogueType number
---@return boolean
function DialogueManagerV2:CanPlayDialogue(dialogueID, dialogueType)
    local me = Game.me
    if me then
        if dialogueType ~= DialogueConst.DIALOGUE_TYPE.NO_CAMERA then
            -- 非无镜对话需要检查状态冲突
            if not me:SCCanExecute(Enum.EStateConflictAction.DialogControl, false) then
                Log.WarningFormat("[DialogueV2]CanPlayDialogue failed: state conflicted, pending play dialogueID:%s", dialogueID)
                return false
            end
        end
    end
    
    return true
end

---@public
---@return boolean
function DialogueManagerV2:IsPlayingSpecificDialogue(dialogueID)
    if self.curExclusiveInstance and self.curExclusiveInstance.DialogueID == dialogueID then
        return true
    end

    local dialogue = self.activateNoCameraInstances[dialogueID]
    if dialogue then
        return true
    end
    
    return false
end

---@public
---@return boolean
function DialogueManagerV2:IsPlayingDialogue()
    return (self.curExclusiveInstance ~= nil) or (next(self.activateNoCameraInstances) ~= nil)
end

---@public
---@return boolean
function DialogueManagerV2:IsPlayingExclusiveDialogue()
    return (self.curExclusiveInstance ~= nil)
end

---@public
---@return boolean
function DialogueManagerV2:IsPlayingSharedDialogue()
    return (next(self.activateNoCameraInstances) ~= nil)
end

DialogueManagerV2.CurTrackingInstance = nil
function DialogueManagerV2.ErrorHandler(e)
    if DialogueManagerV2.CurTrackingInstance then
        e = string.format("%s in dialogue instance: %s", e, tostring(DialogueManagerV2.CurTrackingInstance.DialogueID))
    end

    _G.CallBackError(e)
end

---@param f function
---@param dialogueInstance DialogueInstanceBase
function DialogueManagerV2.xpcall(f, dialogueInstance, ...)
    DialogueManagerV2.CurTrackingInstance = dialogueInstance
    return xpcall(f, DialogueManagerV2.ErrorHandler, ...)
end

---@public
---@param inDeltaTime number
function DialogueManagerV2:Tick(inDeltaTime)
    -- TODO：limunan，待SDK Timer修复后删除
    -- 运行时Timer因SDK闭源无法调试，出现未知原因的每帧执行一次的timer变成了每帧
    -- 执行两次，等待SDK Timer修复，这里先自行判断一下执行间隔，防止每帧执行两次
    local time = Game.GameTimeMS
    if time - self.lastTickTime < self.minFrameTime then
        return
    end

    -- 对话内所有deltaTime统一用秒为单位
    local deltaTime = (time - self.lastTickTime) * 0.001
    self.lastTickTime = time
    -- deltaTime = self.frameSmoother:Smooth(deltaTime)
    self.avgFrameTime = deltaTime

    local xpcall = DialogueManagerV2.xpcall
    local curExclusiveInstance = self.curExclusiveInstance
    if curExclusiveInstance then
        xpcall(curExclusiveInstance.Tick,  curExclusiveInstance, curExclusiveInstance, deltaTime)
    end

    for _, activateNoCameraInstance in pairs(self.activateNoCameraInstances) do
        xpcall(activateNoCameraInstance.Tick, activateNoCameraInstance, activateNoCameraInstance, deltaTime)
    end
end

-- 获取对话类型以根据类型创建Instance
---@protected
---@return number|nil
function DialogueManagerV2:getDialogueType(dialogueID)
    if type(dialogueID) == "table" then
        return DialogueConst.DIALOGUE_TYPE.LIST
    end

    local dialogueData = Game.TableData.GetDialogueAssetDataRow(dialogueID)
    if not dialogueData then
        Log.ErrorFormat("[DialogueV2]getDialogueType failed: has no dialogue asset data for %s", dialogueID)
        return
    end

    if dialogueData.bSimpleDialogue then
        return DialogueConst.DIALOGUE_TYPE.SIMPLE
    end

    local dialogueConfig = self:GetDialogueConfig(dialogueID)
    if dialogueConfig then
        return dialogueConfig.Unique and DialogueConst.DIALOGUE_TYPE.NORMAL or DialogueConst.DIALOGUE_TYPE.NO_CAMERA
    else
        Log.ErrorFormat("[DialogueV2]getDialogueType failed: has no dialogue asset for %s", dialogueID)
    end
end

---@public
---@param dialogueID number|number[]
---@param bReload boolean 是否reload
---@return table
function DialogueManagerV2:GetDialogueConfig(dialogueID, bReload)
    assert(dialogueID ~= nil and type(dialogueID) == 'number', "dialogueID is nil or not number")
    return self.loader:Load(dialogueID, bReload)
end

---@public
---@return boolean
function DialogueManagerV2:IsAutoPlay()
    local curExclusiveInstance = self.curExclusiveInstance
    if curExclusiveInstance then
        return curExclusiveInstance:IsAutoPlay()
    end
    
    return self:GetPlayerAutoPlaySetting()
end
---@public
---@param bAutoPlay boolean
function DialogueManagerV2:SetAutoPlay(bAutoPlay)
    if self.curExclusiveInstance then
        self.curExclusiveInstance:OnAutoPlayStateChange(bAutoPlay)
    end
end

---@public
---@return boolean
function DialogueManagerV2:GetPlayerAutoPlaySetting()
    if self.bPlayerAutoPlaySetting == nil then
        if Game and Game.me then
            self.bPlayerAutoPlaySetting = Game.me:getBoolProp(BoolPropDefs.IS_DIALOGUE_AUTO_PLAY) or false
        end
    end

    return self.bPlayerAutoPlaySetting
end

---@public
---@param bAutoPlay boolean
---@param bReportToServer boolean
function DialogueManagerV2:SetPlayerAutoPlaySetting(bAutoPlay, bReportToServer)
    if self.bPlayerAutoPlaySetting == bAutoPlay then
        return
    end

    self.bPlayerAutoPlaySetting = bAutoPlay
    if bReportToServer and  Game and Game.me then
        Game.me:clientSetBoolProp(BoolPropDefs.IS_DIALOGUE_AUTO_PLAY, bAutoPlay)
    end
end

---@public
function DialogueManagerV2:SetDialogueContentUI(ContentUIType)
	self.UIProcessor:SetDialogueContentUIType(ContentUIType)
end

---@public
function DialogueManagerV2:PauseExclusiveDialogue()
    if self.curExclusiveInstance then
        self.curExclusiveInstance:PausePlay()
    end
end

---@public
function DialogueManagerV2:ResumeExclusiveDialogue()
    if self.curExclusiveInstance then
        self.curExclusiveInstance:ResumePlay()
    end
end

---@public
function DialogueManagerV2:EnableMysteryMode()
    self.UIProcessor:EnableMysteryMode()
end

---@public
function DialogueManagerV2:DisableMysteryMode()
    self.UIProcessor:DisableMysteryMode()
end

---@public
---@return boolean @ 是否成功启动预加载
function DialogueManagerV2:PreloadDialogue(dialogueID, priority, requester, onCompletedCallbackName, onCancelCallbackName)
    if not dialogueID or type(dialogueID) ~= 'number' then
        Log.WarningFormat("[DialogueV2]PreloadDialogue failed: dialogueID[%s] is invalid", dialogueID)
        return nil
    end

    local dialogueConfig = self:GetDialogueConfig(dialogueID)
    if not dialogueConfig then
        Log.WarningFormat("[DialogueV2]PreloadDialogue failed: dialogueConfig of dialogue[%s] is nil", dialogueID)
        return nil
    end

    local task = self.AssetMgr:PreloadDialogue(dialogueID, dialogueConfig, priority, requester, 
        onCompletedCallbackName, onCancelCallbackName)
    return task ~= nil
end

function DialogueManagerV2:CancelPreloadDialogue(dialogueID)
    self.AssetMgr:CancelPreload(dialogueID)
end

function DialogueManagerV2:isValidDialogueID(dialogueID)
    if dialogueID == nil then
        return false
    end
    
    local type = type(dialogueID)
    if type == 'number' then
        return true
    elseif type == 'table' then
        return #dialogueID > 0
    end
    
    return false
end

---@public
---@param optionId number @ 选项ID
---@param optionIndex number @ 选项序号
function DialogueManagerV2:SetLastOptionSelected(optionId, optionIndex)
    self.LastOption.OptionID = optionId
    self.LastOption.OptionIndex = optionIndex
end

---@return {OptionID : number, OptionIndex : number}
function DialogueManagerV2:GetLastOptionSelected()
    return self.LastOption
end

function DialogueManagerV2:OnBackToSelectRole()
    Log.InfoFormat("[DialogueV2]OnBackToSelectRole, terminate all dialogue")
    self:TerminateAllDialogue(DialogueConst.END_REASON.TERMINATE_ON_BACK_TO_SELECT_ROLE)
    self.AssetMgr:Clear()
end

function DialogueManagerV2:OnBackToLogin()
    Log.InfoFormat("[DialogueV2]OnBackToLogin, terminate all dialogue")
    self:TerminateAllDialogue(DialogueConst.END_REASON.TERMINATE_ON_BACK_TO_LOGIN)
    self.AssetMgr:Clear()
end

function DialogueManagerV2:GetLastDialogueEndReason()
    return self.lastDialogueEndReason
end

---@param endReason DialogueEndReason
function DialogueManagerV2:SetLastDialogueEndReason(endReason)
    self.lastDialogueEndReason = endReason
end

function DialogueManagerV2:SwitchDialogueStateConflict(bEnter, dialogueID)
    local me = Game.me
    if not me then
        return
    end

    if bEnter then
        Log.InfoFormat("[DialogueV2]SCExecute state conflict:DialogControl in %s", dialogueID)
        me:SCExecute(Enum.EStateConflictState.DialogControl, true)
    else
        Log.InfoFormat("[DialogueV2]SCRemove state conflict:DialogControl in %s", dialogueID)
        me:SCRemove(Enum.EStateConflictAction.DialogControl)
    end
end

function DialogueManagerV2:OnGameEnterStageShowUIEnd()
    Log.DebugFormat("[DialogueV2]OnGameEnterStageShowUIEnd")
    Game.NewUIManager:WarmPanel(UIPanelConfig.BlackScreenPanel)
    Game.NewUIManager:WarmPanel(UIPanelConfig.Dialogue_Panel)
end 

function DialogueManagerV2:OnNetDisconnected()
    Log.Info("[DialogueV2]OnNetDisconnected")
    self.bNetValid = false
    self:TerminateAllDialogue(DialogueConst.END_REASON.TERMINATE_ON_NET_DISCONNECTED)
end 

function DialogueManagerV2:OnNetConnected()
    Log.Info("[DialogueV2]OnNetConnected")
    self.bNetValid = true
end

---@private
---@param endReason DialogueEndReason
function DialogueManagerV2:terminateCurExclusiveDialogue(endReason)
    local curExclusiveInstance = self.curExclusiveInstance
    if not curExclusiveInstance then
        return
    end
    
    -- 先设置为nil，防止其他业务监听到相关事件再次走到Terminate逻辑里面
    self.curExclusiveInstance = nil

    local tempDialogueID = curExclusiveInstance.DialogueID
    curExclusiveInstance:Terminate(endReason)

    self.UIProcessor:Clear()
    self:SwitchDialogueStateConflict(false, tempDialogueID)
end