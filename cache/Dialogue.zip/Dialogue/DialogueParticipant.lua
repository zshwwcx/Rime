---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/7 14:25
---
local EMoveDriveMode = import("EMoveDriveMode")
local WEAK_FORCE_CONTROL_REASON_TAGS = kg_require("Shared.Const.ParallelBehaviorControlConst").WEAK_FORCE_CONTROL_REASON_TAGS
local EntityUtils = kg_require("Gameplay.NetEntities.EntityUtils")

---@class DialogueParticipant : LuaClass
---@field private ptpConfig UDialogueActor|UDialogueCamera|UDialogueEntity
DialogueParticipant = DefineClass("DialogueParticipant", TimerBase)

function DialogueParticipant:ctor(participantManager, ptpConfig)
    assert(ptpConfig, "participant config is nil")
    ---DialogueConst.PARTICIPANT_TYPE
    self.PtpType = nil
    self.TrackName = ptpConfig.TrackName

    ---@type number
    self.dialogueEntityID = 0

    self.bReady = false
    ---@type DialogueParticipantManager
    self.ptpManager = participantManager
    self.ptpConfig = ptpConfig

    -- 记录位置
    self.spawnTransform = nil
    -- 是否需要恢复位置
    self.bRecoverControl = true
    -- 缓存获取控制权之前的位置
    self.positionCache = nil
    self.rotationCache = nil

    self.bSimpleDialogue = false
end

-- 创建纯剧编内部的参与者
---@public
function DialogueParticipant:SpawnDialogueEntity(spawnTransform)
    self.spawnTransform = spawnTransform
    self.bRecoverControl = false
    self.PtpType = self.ptpConfig.ActorClass
    local participantEntityClass = DialogueConst.PARTICIPANT_TYPE_TO_CLASS[self.PtpType]
    if not participantEntityClass then
        Log.ErrorFormat("[DialogueV2][SpawnDialogueEntity] %s get participant entity class failed", self.ptpConfig.TrackName)
        self:CompleteReady()
        return
    end

    local bEnableDof
    if self.PtpType == DialogueConst.PARTICIPANT_TYPE.CAMERA then
        bEnableDof = self.ptpManager.dialogueConfig.EnableDOF
    end

    -- 处理Scale3D
	local Scale3D = self.spawnTransform:GetScale3D()
    local ScaleProp = {1, 1, 1}
    ScaleProp = {Scale3D.X, Scale3D.Y, Scale3D.Z}

    local spawnParams = {
        Position = self.spawnTransform:GetTranslation(),
        Rotation = self.spawnTransform:GetRotation():Rotator(),
        Scale3D = ScaleProp,
        OwnerParticipant = self,
        ptpConfig = self.ptpConfig,
        isAvatar = self.ptpConfig.bIsPlayer,
        bEnableDof = bEnableDof, -- 只有相机有
        TrackName = self.TrackName,
    }

    local dialogueID = self.ptpManager.dialogueInstance.DialogueID
    local dialogueAssetData = Game.TableData.GetDialogueAssetDataRow(dialogueID)
    if dialogueAssetData then
        spawnParams.bCloseBodyControl = dialogueAssetData.bCloseBodyControl
    end

    -- 主角演员,需要继承外观和捏脸等数据
    local dialogueEntity
    if self.ptpConfig.bIsPlayer then
		-- 添加Game.me判空抛日志，看看什么情况下会走到这里，并且Game.me是nil (https://gamecloud-redmine.corp.kuaishou.com/1007/projects/c7/issues/172555)
		if not Game.me then
			Log.ErrorFormat("[DialogueV2][DialogueParticipant:SpawnDialogueEntity] Game.me is nil, please check.")
			return
		end 
        dialogueEntity = EntityUtils.CreateLocalAvatarEntityByAvatarEntityID(participantEntityClass, spawnParams, Game.me:uid())
    else
        dialogueEntity = Game.EntityManager:CreateLocalEntity(participantEntityClass, spawnParams)
    end

    self.dialogueEntityID = dialogueEntity and dialogueEntity:uid() or 0
	
	Log.DebugFormat("[DialogueV2][DialogueParticipant:SpawnDialogueEntity] entity:%s trackName:%s", dialogueEntity, self.TrackName)
end

-- 绑定已有的Entity到对话中
---@public
function DialogueParticipant:BindDialogueEntity(spawnTransform, bSimpleDialogue)
    self.spawnTransform = spawnTransform
    self.bRecoverControl = not bSimpleDialogue
    self.PtpType = self.ptpConfig.ActorClass
    if not self.PtpType then
        Log.ErrorFormat("[DialogueV2][BindDialogueEntity] %s get participant type failed", self.ptpConfig.TrackName)
        self:CompleteReady()
        return
    end

    local dialogueID = self.ptpManager.dialogueInstance.DialogueID
    local dialogueEntity
    if self.ptpConfig.bIsPlayer then
        dialogueEntity = Game.me
        local dialogueAssetData = Game.TableData.GetDialogueAssetDataRow(dialogueID)
        if dialogueAssetData and dialogueAssetData.bCloseBodyControl then
            dialogueEntity.CppEntity:KAPI_Animation_SetIsEnableBodyControl(false)
        end
    elseif string.isEmpty(self.ptpConfig.InsID) then
        Log.ErrorFormat("[DialogueV2][BindDialogueEntity] %s cannot bind to any entity because InsID is empty.DialogueID:%s", 
            self.ptpConfig.TrackName, dialogueID)
        
        self:CompleteReady()
        return
    else
        local npcEntityID = Game.WorldManager:GetNpcByInstance(self.ptpConfig.InsID)
        local npcEntity = Game.EntityManager:GetEntityByIntID(npcEntityID)
        if not npcEntity then
            Log.ErrorFormat("[DialogueV2]BindDialogueEntity failed: %s cannot bind to npc %s InsID:%s entityID:%s in dialogue:%s",
                self.ptpConfig.TrackName, npcEntityID, self.ptpConfig.InsID, npcEntityID, dialogueID)
            self:CompleteReady()
            return
        end

        dialogueEntity = npcEntity
    end

    self.dialogueEntityID = 0
    if dialogueEntity then
        self.dialogueEntityID = dialogueEntity:uid()

        if dialogueEntity.bInWorld == true then
            self:takeBoundEntityControl()
            return
        end
    end 

    Game.UniqEventSystemMgr:AddListener(self.dialogueEntityID, EEventTypesV2.ROLE_ON_BORN, "OnBoundEntityEnterWorld", self)
end

---销毁动态创建的参与者Entity
---@public
function DialogueParticipant:DestroyDialogueEntity()
    local dialogueEntity = Game.EntityManager:GetEntityByIntID(self.dialogueEntityID)
    if not dialogueEntity then
        return
    end

	-- 如果在隐藏duration结束之前，entity就已经被销毁，直接清理掉隐藏的回调timer
	if self._delayCleanTimer then
		self:DelTimer(self._delayCleanTimer)
	end

    self.dialogueEntityID = 0
    dialogueEntity:destroy()
end

---与服务器Entity解绑
---@public
function DialogueParticipant:UnbindDialogueEntity()
    self:recoverBoundEntityControl()
end

-- 完成参与者的准备
---@public
function DialogueParticipant:CompleteReady()
    self.bReady = true
	-- 这里有点奇怪，在NoCameraDialogueInstance 1009038中，可能会存在self.ptpManager有实例，但是self.ptpManager.OnParticipantReady函数为nil的情况，不阻断表现。临时修复
	if self.ptpManager and self.ptpManager.OnParticipantReady then
		self.ptpManager:OnParticipantReady(self, self.TrackName)
	end
end

---@public
---@return boolean
function DialogueParticipant:IsReady()
    return self.bReady
end

---@public
---@return number
function DialogueParticipant:GetSex()
    local dialogueEntity = Game.EntityManager:GetEntityByIntID(self.dialogueEntityID)
    if not dialogueEntity then
        return
    end

    return dialogueEntity and dialogueEntity.Sex or nil
end

---@public
---@return string
function DialogueParticipant:GetTrackName()
    return self.ptpConfig and self.ptpConfig.TrackName or ""
end

---@public
---@return DialoguePerformer|DialogueCamera|DialogueModel|DialogueNiagara|DialogueLight|nil
function DialogueParticipant:GetDialogueLocalEntity()
    return Game.EntityManager:GetEntityByIntID(self.dialogueEntityID)
end

---@public
---@return boolean
function DialogueParticipant:IsPlayer()
    return self.ptpConfig.bIsPlayer
end

function DialogueParticipant:IsAnchor()
    return self.TrackName == DialogueConst.ANCHOR_TRACK_NAME
end

function DialogueParticipant:IsPerformer()
    return self.PtpType == DialogueConst.PARTICIPANT_TYPE.PERFORMER
end

function DialogueParticipant:OnBoundEntityEnterWorld()
    Game.UniqEventSystemMgr:RemoveListener(self.dialogueEntityID, EEventTypesV2.ROLE_ON_BORN, "OnBoundEntityEnterWorld", self)
    self:takeBoundEntityControl()
end

---@public
function DialogueParticipant:SetDefaultVisibility()
    if self.ptpConfig.bDefaultVisible then
        self:Show(DialogueConst.PARTICIPANT_HIDE_SOURCE.DIALOGUE_LOGIC)
    else
        self:Hide(DialogueConst.PARTICIPANT_HIDE_SOURCE.DIALOGUE_LOGIC)
    end
end

-- 控制绑定entity行为(如脱离服务器同步,重置位置等)
---@private
function DialogueParticipant:takeBoundEntityControl()
    local dialogueEntity = Game.EntityManager:GetEntityByIntID(self.dialogueEntityID)
    if not dialogueEntity then
        return
    end

    if self.bRecoverControl then
        self.positionCache = dialogueEntity:GetPosition()
        self.rotationCache = dialogueEntity:GetRotation()

        dialogueEntity:SetPosition(self.spawnTransform:GetTranslation())
        dialogueEntity:SetRotation(self.spawnTransform:GetRotation():Rotator())

        dialogueEntity:SetMoveDriveModeForceValue(EMoveDriveMode.DriveLocally, WEAK_FORCE_CONTROL_REASON_TAGS.DialogueBinded)
    end

    -- 音频侧标记单位在对话中
    dialogueEntity:AkSetRtpcValue(Enum.EAudioConstNew.RTPC_NAME_ACTOR_ACTING, Enum.EAudioConstNew.RTPC_VALUE_ACTOR_ACTING)

    self:CompleteReady()
end

-- 恢复绑定entity控制权
---@private
function DialogueParticipant:recoverBoundEntityControl()
    local dialogueEntity = Game.EntityManager:GetEntityByIntID(self.dialogueEntityID)
    if not dialogueEntity then
        return
    end

    if self.bRecoverControl then
        dialogueEntity:SetPosition(self.positionCache)
        dialogueEntity:SetRotation(self.rotationCache)

        dialogueEntity:ClearMoveDriveModeForceValue(WEAK_FORCE_CONTROL_REASON_TAGS.DialogueBinded)

        dialogueEntity:StopAnimLibMontage()
    end

    if self.ptpConfig.bIsPlayer then
        dialogueEntity.CppEntity:KAPI_Animation_SetIsEnableBodyControl(true)
    end

    -- 音频侧移除单位在对话中的标记
    dialogueEntity:AkResetRtpcValue(Enum.EAudioConstNew.RTPC_NAME_ACTOR_ACTING)

	-- #170332 [流程图&Action]播放无镜Dialog的功能调整需求（客户端） https://gamecloud-redmine.corp.kuaishou.com/1007/projects/c7/issues/170332
	if self.ptpManager.dialogueInstance.hideCharacterList and self.ptpManager.dialogueInstance.hideCharacterList[dialogueEntity.eid] then
		-- 剧情对话结束，隐藏掉entity，然后直接return，等待销毁
		dialogueEntity:ForceToInvisibleByDialogue()
		self._delayCleanTimer = self:AddTimer(self.ptpManager.dialogueInstance.hideDuration, 1, "TryCleanVisibilityAndScaleFromFlowChart")
		return
	end

    -- 不论如何都要清理显隐控制
    dialogueEntity:CleanForceVisibleControlByDialogue()
    -- 不论如何都需要恢复
    dialogueEntity:SetGlobalAnimRateScale(1)
end

function DialogueParticipant:TryCleanVisibilityAndScaleFromFlowChart()
	local dialogueEntity = Game.EntityManager:GetEntityByIntID(self.dialogueEntityID)
	if dialogueEntity then
		dialogueEntity:CleanForceVisibleControlByDialogue()
		dialogueEntity:SetGlobalAnimRateScale(1)
	else
		Log.WarningFormat("[DialogueV2][HideDialogueEntityByFlowChart] Cannot find dialogueEntity:%s, which maybe destroyed by flowchart.", 
            self.dialogueEntityID)
	end
end

---@param tag DialogueParticipantHideSource
function DialogueParticipant:Show(tag)
    if string.isEmpty(tag) then
        return
    end

    Log.DebugFormat("[DialogueV2]Show participant: %s[%s] reason: %s", self.TrackName, self.dialogueEntityID, tag)
    local entity = self:GetDialogueLocalEntity()
    if entity then
        if entity.DialogueShow then
            entity:DialogueShow(tag)
        else
            entity:ForceToVisibleByDialogue()
        end
    end
end

---@param tag DialogueParticipantHideSource
function DialogueParticipant:Hide(tag)
    if string.isEmpty(tag) then
        return
    end
    
    Log.DebugFormat("[DialogueV2]Hide participant: %s[%s] reason: %s", self.TrackName, self.dialogueEntityID, tag)
    local entity = self:GetDialogueLocalEntity()
    if entity then
        if entity.DialogueHide then
            entity:DialogueHide(tag)
        else
            entity:ForceToInvisibleByDialogue()
        end
    end
end
