---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/7 20:09
---
DialogueUtilV2 = DefineClass("DialogueUtilV2")

local __UnitTransform__ = FTransform() -- luacheck: ignore

---@return PTransform
function DialogueUtilV2.DialogueTransformToUETransform(dialogueTransform)
    if not dialogueTransform then
        return __UnitTransform__
    end

    local translation = dialogueTransform.Translation
    local rotation = dialogueTransform.Rotation
    local scale3D =  dialogueTransform.Scale3D
    return FTransform(
            FQuat(rotation.X, rotation.Y, rotation.Z, rotation.W),
            FVector(translation.X, translation.Y, translation.Z),
            FVector(scale3D.X, scale3D.Y, scale3D.Z)
    )
end

function DialogueUtilV2.UnpackDialogueTransform(dialogueTransform)
    local l = dialogueTransform.Translation
    local r = dialogueTransform.Rotation
    local s = dialogueTransform.Scale3D
    return l.X, l.Y, l.Z, r.X, r.Y, r.Z, r.W, s.X, s.Y, s.Z
end

function DialogueUtilV2.TableToFTransform(Transform)
    if Transform == nil then
        return FTransform()
    end
    local Translation = Transform.Translation
    local Rotation = Transform.Rotation
    local Scale3D = Transform.Scale3D
    return FTransform(FQuat(Rotation.X, Rotation.Y, Rotation.Z, Rotation.W),
        DialogueUtilV2.TableToFVector(Translation), DialogueUtilV2.TableToScale(Scale3D))
end

---@return FVector
function DialogueUtilV2.TableToFVector(Vector)
    if Vector == nil then
        return FVector(0, 0, 0)
    end
    return FVector(Vector.X, Vector.Y, Vector.Z)
end

---@return FVector
function DialogueUtilV2.TableToScale(Vector)
    if Vector == nil then
        return FVector(1, 1, 1)
    end
    return FVector(Vector.X, Vector.Y, Vector.Z)
end

---@return FRotator
function DialogueUtilV2.TableToFRotator(Vector)
    if Vector == nil then
        return FRotator(0, 0, 0)
    end
    return FRotator(Vector.Pitch, Vector.Yaw, Vector.Roll)
end

---@param dialogueID number
---@return string[]
function DialogueUtilV2.GetNpcIDListInDialogue(dialogueID)
    local npcIDList = {}

    local dialogueConfig = Game.DialogueManagerV2:GetDialogueConfig(dialogueID)
    if not dialogueConfig then
        return npcIDList
    end

    for _, performerConfig in ksbcpairs(dialogueConfig.PerformerList) do
        if (performerConfig.bIsPlayer == false) and (performerConfig.UseSceneActor == true) and (string.isEmpty(performerConfig.InsID) == false) then
            table.insert(npcIDList, performerConfig.InsID)
        end
    end

    return npcIDList
end

---判断一个entity是否是对话内的主角
---@public
---@param entity LocalEntityBase
---@return boolean
function DialogueUtilV2.IsEntityDialoguePlayer(entity)
    if (entity == nil) or (entity.bInWorld == false) then
        return false
    end

    if entity.__cname == "DialogueLocalEntity" then
        return entity.DialogueEntityTable.bIsPlayer
    elseif entity.__cname == "DialoguePerformer" then
        return entity.ptpConfig.bIsPlayer
    end

    return false
end

function DialogueUtilV2.CalculateDialogueLineDuration(origDuration, lineText)
    if origDuration and origDuration ~= 0 then
        return origDuration
    end

    -- 时长计算规则：
    -- 按1秒5个字计算，且时长不小于3秒，不大于8秒（5字及以内按2秒计算）
    local MinTime, MaxTime = 3, 8
    local CharPerSecond = 5

    local CharCount = utf8.len(lineText)
    local TextTime = CharCount / CharPerSecond

    local Time = 2
    if TextTime > 1 then
        Time = math.clamp(TextTime, MinTime, MaxTime)
    end

    
    return Time
end



function DialogueUtilV2.GetSectionLuaClass(sectionConfig)
    if not sectionConfig then
        return nil
    end

    local objectClass = sectionConfig.ObjectClass
    local sectionClass = DialogueConst.DIALOGUE_SECTION_TYPE_TO_CLASS[objectClass]
    if sectionClass then
        return sectionClass
    else
        Log.WarningFormat("[DialogueV2]GetSectionLuaClass failed: %s has no section lua class.", objectClass)
    end

    return nil
end

---@param dialogueTable DialogueTable
---@param episodeID number
---@return FDialogueEpisode|nil
function DialogueUtilV2.GetEpisodeByID(dialogueTable, episodeID)
    if not dialogueTable or not episodeID then
        return nil
    end

    for i = 1, #dialogueTable.Episodes do
        local EpisodeRef = dialogueTable.Episodes[i]
        if (EpisodeRef.EpisodeID == episodeID) then
            return EpisodeRef
        end
    end

    return nil
end

--- 实现TArray<UDialogueTrackBase*> FDialogueEpisode::GetAllTracks()
---@param episode FDialogueEpisode @ lua资产数据里面的FDialogueEpisode的lua表示，本质就是个table
---@param bIncludeActions boolean @ 是否包含Action类型的Track
---@return UDialogueTrackBase[]
function DialogueUtilV2.GetAllEpisodeTracksByRef(episode, bIncludeActions)
    local insert = table.insert
    local OutTrackList = {}
    local Queue = {}
    for k, v in ksbcipairs(episode.TrackList) do
        insert(Queue, v)
    end
    
    local remove = table.remove
    local tblToString = table.tostring
    while (#Queue ~= 0) do
        local QueueTrack = Queue[1]
        remove(Queue, 1)
        insert(OutTrackList, QueueTrack)
        if QueueTrack.TrackName == nil then
            Log.DebugFormat("[DialogueV2]GetAllEpisodeTracksByRef Track %s", tblToString(QueueTrack))
        end
        
        for k, v in ksbcipairs(QueueTrack.Childs) do
            insert(Queue, v)
        end
        
        if bIncludeActions then
            for k, v in ksbcipairs(QueueTrack.Actions) do
                insert(Queue, v)
            end
        end
    end
    
    return OutTrackList
end


--region 动态数据填充

--向DialogueTable里面填入动态数据
---@param dialogueTable DialogueTable @ 对话资产lua表
---@param episodeID number @ 当前剧集ID，可以为nil，为空则当做是当前剧集
---@param dynamicData table @ 动态Section数据
---@param dynamicOptionData table @ 动态选项数据，如果没有，可以为nil
function DialogueUtilV2.FillDialogueData(dialogueTable, episodeID, dynamicData, dynamicOptionData)
    Log.DebugFormat("[DialogueV2]FillDialogueData episodeID:%s", episodeID)
    if not dialogueTable then
        Log.DebugWarningFormat("[DialogueV2]FillDialogueData failed: dialogueTable is nil")
        return
    end

    if not episodeID then
        episodeID = dialogueTable.Episodes[1].EpisodeID
    end

    local EpisodeTable = DialogueUtilV2.GetEpisodeByID(dialogueTable, episodeID)
    if not EpisodeTable then
        Log.DebugWarningFormat("[DialogueV2]FillDialogueData failed: episodeID:%s is not exist", episodeID)
        return
    end

    if dynamicData then
        local AllTracks = DialogueUtilV2.GetAllEpisodeTracksByRef(EpisodeTable, true)
        for _, TrackInfo in ipairs(AllTracks) do
            if TrackInfo.ActionSections then
                for SectionIndex, SectionData in ipairs(TrackInfo.ActionSections) do
                    if SectionData.DynamicFlag and SectionData.DynamicFlag ~= "" then
                        local SectionDynamicData = dynamicData[SectionData.DynamicFlag] or {}
                        local SectionClass = DialogueUtilV2.GetSectionLuaClass(SectionData)
                        if SectionClass and SectionClass.CopyDynamicData then
                            SectionClass.CopyDynamicData(SectionData, SectionDynamicData)
                        else
                            Log.DebugWarningFormat("[DialogueV2]Cant not find Section %s CopyDynamicData Func", SectionData.ObjectClass)
                        end
                    end
                end
            end
        end
    end

    if dynamicOptionData then
        EpisodeTable.Options = dynamicOptionData.Values or {}
        EpisodeTable.OptionType = dynamicOptionData.Type or 0
    end
    Log.DebugFormat("[DialogueV2]FillDialogueOptionData success")
end
--endregion


DialogueUtilV2.EnvSafeCall = nil
function DialogueUtilV2.CallbackOnError(e)
    local scope = DialogueUtilV2.EnvSafeCall
    local type = type(scope)
    if type == 'string' then
        Log.ErrorFormat("%s : %s", scope, e)
    elseif type == 'table' then
        local s
        if scope.ToString then
            s = scope:ToString()
        else
            s = tostring(scope)
        end
        Log.ErrorFormat("%s : %s", s, e)
    else
        Log.ErrorFormat("%s", e)
    end
end

---@param scope string | table @ 调用的作用域
---@param func fun(...):any
---@return any
function DialogueUtilV2.SafeCall(scope, func, ...)
    if type(func) == "function" then
        DialogueUtilV2.EnvSafeCall = scope
        local bSuccess, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10 = xpcall(func, DialogueUtilV2.CallbackOnError, ...)
        DialogueUtilV2.EnvSafeCall = nil
        return bSuccess, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10
    end
end

