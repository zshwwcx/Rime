---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/7 14:21
---


---@class DialogueTrack : LuaClass
---@field private trackClass string
---@field private trackConfig UDialogueTrackBase
---@field private dialogueInstance DialogueInstanceBase
DialogueTrack = DefineClass("DialogueTrack")

function DialogueTrack:ctor(dialogueInstance, trackConfig)
    -- 暂停标记
    self.bPause = false
    ---@type number @ 运行时长
    self.runningTime = 0

    ---@type number @ 对话实例运行时长
    self.instanceRunningTime = 0

    ---@type number @ 真实世界播放时长
    self.realWorldTime = 0
    
    self.trackConfig = trackConfig
    self.trackClass = trackConfig.ObjectClass

    ---@type DialogueInstanceBase
    self.dialogueInstance = dialogueInstance

    ---@type DialogueSectionBase[]
    self.sections = {}
	
	self.allSections = {}

    ---@type DialogueSectionBase[]
    self.runningSections = {}
end

---@public
function DialogueTrack:Init()
    local ptpManager = self.dialogueInstance.ptpManager
    local trackPtp = ptpManager:GetParticipantByName(self.trackConfig.TrackName)
    local trackPtpEntity = ptpManager:GetParticipantEntityByName(self.trackConfig.TrackName)

    for sectionIndex, sectionConfig in ksbcipairs(self.trackConfig.ActionSections or {}) do
        if sectionConfig.Enable then
            self:createSection(sectionConfig, trackPtp, trackPtpEntity, sectionIndex)
        end
    end

    for _, actionConfig in ksbcipairs(self.trackConfig.Actions or {}) do
        for sectionIndex, sectionConfig in ksbcipairs(actionConfig.ActionSections) do
            if sectionConfig.Enable then
                self:createSection(sectionConfig, trackPtp, trackPtpEntity, sectionIndex)
            end
        end
    end
    
    -- luacheck: push ignore
    table.sort(self.sections, function(sectionA, sectionB)
        return sectionA.sectionConfig.StartTime < sectionB.sectionConfig.StartTime
    end)
    -- luacheck: pop
end

---@public
function DialogueTrack:UnInit()
    for _, section in ipairs(self.sections) do
        section:delete()
    end
    table.clear(self.sections)

    for _, section in ipairs(self.runningSections) do
        section:delete()
    end
    
    table.clear(self.runningSections)
	table.clear(self.allSections)
end

---@public
function DialogueTrack:PauseTrack()
    local trackPtpEntity = self.dialogueInstance.ptpManager:GetParticipantEntityByName(self.trackConfig.TrackName)
    self.bPause = true
    for _, section in ipairs(self.sections) do
        section.trackPtpEntity = trackPtpEntity
        section:PauseSection()
    end

    for _, section in ipairs(self.runningSections) do
        section.trackPtpEntity = trackPtpEntity
        section:PauseSection()
    end
end

---@public
function DialogueTrack:ResumeTrack()
    local trackPtpEntity = self.dialogueInstance.ptpManager:GetParticipantEntityByName(self.trackConfig.TrackName)
    self.bPause = false
    for _, section in ipairs(self.sections) do
        section.trackPtpEntity = trackPtpEntity
        section:ResumeSection()
    end

    for _, section in ipairs(self.runningSections) do
        section.trackPtpEntity = trackPtpEntity
        section:ResumeSection()
    end
end

function DialogueTrack:SetTime(runningTime, instanceRunningTime, realWorldTime)
    self.runningTime = runningTime
    self.instanceRunningTime = instanceRunningTime
    self.realWorldTime = realWorldTime
end

---@type number[]
DialogueTrack.__TempSectionIdxList__ = {}
---@type number[] @ 启动Section时临时记录section是新启动未完成或者新启动已完成的索引列表，新启动已完成的section索引为负数
DialogueTrack.__TempSectionStartOrDelete__ = {}

-- todo:关注性能
---@public
---@param bSkip boolean 跳过时传入该参数
function DialogueTrack:TickRunningSections(deltaTime, bSkip)
    table.clear(self.__TempSectionIdxList__)

    for idx, section in ipairs(self.runningSections) do
        if section:IsRunning() then
            section:TickSection(deltaTime, bSkip)
        end

        if section:NeedFinish(bSkip) then
            section:FinishSection(bSkip and DialogueConst.SECTION_FINISH_REASON.SKIP or DialogueConst.SECTION_FINISH_REASON.LIFE_END)
            Log.DebugFormat("[DialogueV2][FinishSection]%s on track %s finish at %s", section:ToString(), self.trackConfig.TrackName, self.runningTime)
            table.insert(self.__TempSectionIdxList__, idx)
        end
    end
    
    local sectionIdx
    -- 反向迭代,销毁已结束的Section
    for idx = #self.__TempSectionIdxList__, 1, -1 do
        sectionIdx = self.__TempSectionIdxList__[idx]
        local section = self.runningSections[sectionIdx]
        if section then
            section:delete()
        end
        table.remove(self.runningSections, sectionIdx)
    end
end

---@param bSkip boolean @ 跳过时传入该参数
function DialogueTrack:StartSections(bSkip)
    local runningTime = self.runningTime
    local trackPtpEntity = self.dialogueInstance.ptpManager:GetParticipantEntityByName(self.trackConfig.TrackName)
    
    local insert = table.insert
    table.clear(self.__TempSectionStartOrDelete__)
    
    local bNewlyStart = false
    for idx, section in ipairs(self.sections) do
        section.trackPtpEntity = trackPtpEntity
        bNewlyStart = false
        -- 非暂停情况下,启动需要开启的Section
        if (self.bPause == false) and (section:NeedStart(runningTime) == true) then
            Log.DebugFormat("[DialogueV2][StartSection] %s on track %s start at %s", section:ToString(), self.trackConfig.TrackName, self.runningTime)
            section:InitSection()
            section:StartSection(runningTime, bSkip)
            bNewlyStart = true
        end

        if section:IsRunning() then
            -- 由于runningTime已经叠加过deltaTime时间了，这里不能将deltaTime传入section:TickSection()中
            section:TickSection(0, bSkip)
        end

        -- 关闭应当结束的Section并记录Idx
        if section:NeedFinish() then
            section:FinishSection(bSkip and DialogueConst.SECTION_FINISH_REASON.SKIP or DialogueConst.SECTION_FINISH_REASON.LIFE_END)
            Log.DebugFormat("[DialogueV2][FinishSection]%s on track %s finish at %s", section.__cname, self.trackConfig.TrackName, self.runningTime)
            insert(self.__TempSectionStartOrDelete__, -idx)
        else
            if bNewlyStart then
                insert(self.runningSections, section)
                insert(self.__TempSectionStartOrDelete__, idx)
            end
        end
    end

    local remove = table.remove
    local sectionIdx, section
    
    for idx = #self.__TempSectionStartOrDelete__, 1, -1 do
        sectionIdx = self.__TempSectionStartOrDelete__[idx]
        if sectionIdx < 0 then
            -- 销毁已结束的Section
            sectionIdx = -sectionIdx
            section = self.sections[sectionIdx]
            if section then
                section:delete()
            end
            remove(self.sections, sectionIdx)
        elseif sectionIdx > 0 then
            -- 将已经开始的section从self.sections里面移除，注意这里不能进行销毁因为section只是
            -- 从self.sections里面转移到self.runningSections里面，后续还需要对section进行tick
            remove(self.sections, sectionIdx)
        end
    end
end

function DialogueTrack:createSection(sectionConfig, trackPtp, trackPtpEntity, sectionIndex)
    local bNoCameraDialogue = self.dialogueInstance.DialogueType == DialogueConst.DIALOGUE_TYPE.NO_CAMERA
    -- 无镜对话,部分不允许
    if (DialogueConst.EXCLUSIVE_SECTION[sectionConfig.ObjectClass] ~= nil) and (bNoCameraDialogue == true) then
        return
    end

    local sectionCls = DialogueConst.DIALOGUE_SECTION_TYPE_TO_CLASS[sectionConfig.ObjectClass]
    if not sectionCls then
        Log.ErrorFormat("[DialogueV2][createSection] cannot find class for %s", sectionConfig.ObjectClass)
        return
    end

    local newSection = sectionCls.new(self.dialogueInstance, self, sectionConfig, trackPtp, trackPtpEntity, sectionIndex)
    table.insert(self.sections, newSection)
	table.insert(self.allSections, newSection)
end

function DialogueTrack:JumpToSpecificTime(specificTime)
	-- 首先specificTime前的最后一个section(只处理最后一个，其他都不处理，直接将bJumped标记位置为true)
	local SectionTypeIndexMap= {}
	-- 这里的self.sections可能不止一种类型的sections，所以得找到每种类型的section的最后一个。
	for sectionIndex, section in ipairs(self.allSections) do
		if section.sectionConfig.StartTime <= specificTime then
			SectionTypeIndexMap[section.__cname] = sectionIndex
		end
	end
	
	-- 把SectionList中所有的sectionIndex取出来，改成一个table
	local NeedDealSectionList = {}
	for _, value in pairs(SectionTypeIndexMap) do
		NeedDealSectionList[value] = true
	end
	
	local SectionList = {}

	if next(NeedDealSectionList) then
		for sectionIndex, section in ipairs(self.allSections) do
			if not section.isDestroyed then
				if NeedDealSectionList[sectionIndex] then
					--section:JumpToSpecificTime(specificTime)
					table.insert(SectionList, section)
				elseif section:IsRunning() then
					-- 当前正在running的section，也需要塞入到PendingList里面去处理
					table.insert(SectionList, section)
				else
					section:SetJumped(true)
				end
			end
		end
	end
	
	return SectionList
end

function DialogueTrack:TerminateDialogueTrackByJump()
	for _, section in ipairs(self.sections) do
		section:SetJumped(true)
	end
	for index, section in ipairs(self.runningSections) do
		section:FinishSection(DialogueConst.SECTION_FINISH_REASON.TERMINATE)
	end
end

function DialogueTrack:IsDone()
    if table.isNilOrEmpty(self.sections) and table.isNilOrEmpty(self.runningSections) then
        return true
    end
    
    return false
end

function DialogueTrack:Finish(finishReason)
    local trackPtpEntity = self.dialogueInstance.ptpManager:GetParticipantEntityByName(self.trackConfig.TrackName)
    for _, section in ipairs(self.sections) do
        section.trackPtpEntity = trackPtpEntity
        if section:IsRunning() then
            section:FinishSection(finishReason)
        end
    end
    
    for _, section in ipairs(self.runningSections) do
        section.trackPtpEntity = trackPtpEntity
        if section:IsRunning() then
            section:FinishSection(finishReason)
        end
    end
end 