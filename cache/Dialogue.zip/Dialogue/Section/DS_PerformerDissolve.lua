---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/27 16:28
---
local Utils = kg_require("Shared.Utils")
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_PerformerDissolve : DialogueSectionBase
---@field sectionConfig BPS_Dissolve_C
DS_PerformerDissolve = DefineClass("DS_PerformerDissolve", DialogueSectionBase)

DS_PerformerDissolve.__DissolveConfigID__ = 5009010

function DS_PerformerDissolve:OnStart()
    if not self.trackPtpEntity then
        return
    end

    local dissolveEffectId = self.sectionConfig.DissolveEffectId or self.__DissolveConfigID__

    local dissolveEffectData = Game.TableData.GetDissolveEffectDataRow(dissolveEffectId)
    if not dissolveEffectData then
        Log.DebugFormat("DS_PerformerDissolve:OnStart dissolveEffectData is nil, dissolveEffectId:%s", dissolveEffectId)
        return
    end

    local tempDissolveParam
    if type(dissolveEffectData) == 'userdata' then
        tempDissolveParam = Utils.deepCopyTable(dissolveEffectData)
    else
        tempDissolveParam = dissolveEffectData
    end
    
    tempDissolveParam.DissolveTime = self.sectionConfig.Duration
    local bHideOnDissolveFinished = self.sectionConfig.bHideOnDissolveFinished
    if bHideOnDissolveFinished == nil then
        bHideOnDissolveFinished = true
    end

    if bHideOnDissolveFinished then
        self.trackPtpEntity:DialogueHide("DS_PerformerDissolve", tempDissolveParam)
    else
        self.trackPtpEntity:DialogueShow("DS_PerformerDissolve", tempDissolveParam)
    end
end

function DS_PerformerDissolve:OnFinish(finishReason)
    -- todo@wanglei31:直接跳到结束的功能需要开发
end
