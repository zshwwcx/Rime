---
--- Created by shijingzhe@kuaishou,com
--- DateTime: 2025/5/22 19:24
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_PlayAudio : DialogueSectionBase
DS_PlayAudio = DefineClass("DS_PlayAudio", DialogueSectionBase)

function DS_PlayAudio:OnInit()
    self.playingID = 0
end

function DS_PlayAudio:OnStart()
    if string.isEmpty(self.sectionConfig.Sound) then
		Log.WarningFormat("[DialogueV2][DS_PlayAudio] Sound config is empty in dialogue %s", self.DialogueID)
        return
    end

    local arr = string.split(self.sectionConfig.Sound, ".")
    local eventName = arr[#arr]
    self.playingID = Game.AkAudioManager:PostEvent2D(eventName)
	if self.playingID == 0 then
		Log.WarningFormat("[DialogueV2][DS_PlayAudio] Failed to post audio event: %s in dialogue %s", eventName, self.DialogueID)
	end
end

function DS_PlayAudio:OnFinish(finishReason)
    if self.playingID == 0 then
        return
    end

    if not self.sectionConfig.bNoStop then
        local arr = string.split(self.sectionConfig.Sound, ".")
        local eventName = arr[#arr]

        -- todo@shijingzhe:音频导出类型后,这里用类型判断
        if string.startsWith(eventName, "Set_MUS_") then
            Game.AkAudioManager:PostEvent2D(Enum.EAudioConstNew.MUS_GLOBAL_EMOTIONAL_NONE)
        else
            Game.AkAudioManager:StopEvent(self.playingID)
            self.playingID = 0
        end

        return
    end

    Log.DebugFormat("[DialogueV2][DS_PlayAudio] %s will not stop", self.sectionConfig.Sound)
end
