---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/27 18:07
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_DiceCheck : DialogueSectionBase
DS_DiceCheck = DefineClass("DS_DiceCheck", DialogueSectionBase)

function DS_DiceCheck:OnInit()

end

function DS_DiceCheck:OnStart()
    if not Game.me then
        Log.ErrorFormat("[OnStart] main player not exist")
        return
    end

    Log.DebugFormat("[OnStart] DiceID=%s", self.sectionConfig.DiceID)
    self.dialogueInstance:PausePlay()

    --Game.DiceSystem:RequestDice(self.sectionConfig.DiceID)
end

function DS_DiceCheck:OnDiceCheckFinished(params, resultType)
    if params.DiceID ~= self.sectionConfig.DiceID then
        return
    end

    Log.DebugFormat("[OnDiceCheckFinished] DiceID=%s, result=%s", params.DiceID, resultType)
    self.dialogueInstance:SetBlackBoardValue(DialogueConst.BlackBoardKey.DICE_RESULT, resultType)

    self.dialogueInstance:ResumePlay()
end
