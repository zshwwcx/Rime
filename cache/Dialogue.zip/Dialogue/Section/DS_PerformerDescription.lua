---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/6/4 12:45
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_PerformerDescription : DialogueSectionBase
---@field private sectionConfig BPS_ActorDescription_C
DS_PerformerDescription = DefineClass("DS_PerformerDescription", DialogueSectionBase)

function DS_PerformerDescription:OnStart()
    local offsetX = self.sectionConfig.OffsetX or 0
    local offsetY = self.sectionConfig.OffsetY or 0
    local introductionID = self.sectionConfig.ActorDescriptionID
    Game.CharacterIntroductionSystem:ShowNpcIntroduction(introductionID, offsetX, offsetY)
    self.bNeedClose = true
    local durationFadeOut = Game.CharacterIntroductionSystem:GetFadeOutDuration(introductionID)
    if durationFadeOut and durationFadeOut > 0 then
        self.timeCloseIntroduction = self.sectionConfig.Duration - durationFadeOut
    end
end

function DS_PerformerDescription:OnTick(deltaTime)
    local timeCloseIntroduction = self.timeCloseIntroduction
    if timeCloseIntroduction and timeCloseIntroduction > 0 and self.bNeedClose then
        local last = timeCloseIntroduction
        
        timeCloseIntroduction = timeCloseIntroduction - deltaTime
        self.timeCloseIntroduction = timeCloseIntroduction
        
        if last > 0 and timeCloseIntroduction <= 0 then
            Game.CharacterIntroductionSystem:CloseNpcIntroduction()
            self.bNeedClose = false
        end
    end
end

function DS_PerformerDescription:OnFinish(finishReason)
    if self.bNeedClose or self.bJumped then
        Game.CharacterIntroductionSystem:CloseNpcIntroduction()
        self.bNeedClose = false
    end
end
