

local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_CommonMemory : DialogueSectionBase
---@field sectionConfig BPS_CommonMemory_C
DS_CommonMemory = DefineClass("DS_CommonMemory", DialogueSectionBase)
function DS_CommonMemory:OnStart()
    local sectionConfig = self.sectionConfig
    Game.NewUIManager:OpenPanelWithTargetUI(UIPanelConfig.CommonMemory_Panel, UIPanelConfig.Dialogue_Panel,
        sectionConfig.BackgroundTexture,
        sectionConfig.StartScale, sectionConfig.EndScale, sectionConfig.ScaleTime)
end

function DS_CommonMemory:OnFinish(finishReason)
    Game.NewUIManager:ClosePanel(UIPanelConfig.CommonMemory_Panel)
    Game.GlobalEventSystem:RemoveTargetAllListeners(self)
end

function DS_CommonMemory:OnPause()
    local CommonMemoryPanel = Game.NewUIManager:PeekUI(UIPanelConfig.CommonMemory_Panel)
    if CommonMemoryPanel then
        CommonMemoryPanel:SetPause(true)
    elseif self.bInRunning then
        Game.GlobalEventSystem:AddListener(EEventTypesV2.ON_UI_OPEN, "OnUIOpened", self)
    end
end

function DS_CommonMemory:OnResume(uid)
    local CommonMemoryPanel = Game.NewUIManager:PeekUI(UIPanelConfig.CommonMemory_Panel)
    if CommonMemoryPanel then
        CommonMemoryPanel:SetPause(false)
    elseif self.bInRunning then
        Game.GlobalEventSystem:AddListener(EEventTypesV2.ON_UI_OPEN, "OnUIOpened", self)
    end
end

function DS_CommonMemory:OnUIOpened(uid)
    if uid == UIPanelConfig.CommonMemory_Panel then
        local CommonMemoryPanel = Game.NewUIManager:PeekUI(UIPanelConfig.CommonMemory_Panel)
        if CommonMemoryPanel then
            CommonMemoryPanel:SetPause(self.bPause)
        end
        Game.GlobalEventSystem:RemoveListener(EEventTypesV2.ON_UI_OPEN, "OnUIOpened", self)
    end
end
