---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/26 20:52
---
local KML = import("KismetMathLibrary")
local ERelativeTransformSpace = import("ERelativeTransformSpace")
local EAttachmentRule = import("EAttachmentRule")
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_NiagaraAttachInterp : DialogueSectionBase
DS_NiagaraAttachInterp = DefineClass("DS_NiagaraAttachInterp", DialogueSectionBase)

function DS_NiagaraAttachInterp:OnInit()
    self.startTrans = nil
    self.targetTrans = nil
end

function DS_NiagaraAttachInterp:OnStart()
    if (self.trackPtpEntity == nil) or (self.trackPtpEntity.isDestroyed == true) then
        return
    end

    local targetPtpEntity = self.ptpManager:GetParticipantEntityByName(self.sectionConfig.AttachActor)
    if (targetPtpEntity == nil) or (targetPtpEntity.isDestroyed == true) then
        return
    end

    local mainMeshCompID = targetPtpEntity.CppEntity:KAPI_Actor_GetMainSkeletalMeshComponent()


    if self.sectionConfig.Immediate then
        if mainMeshCompID == 0 then
            mainMeshCompID = targetPtpEntity.CppEntity:KAPI_Actor_GetRootComponent()
        end

        local attachRule = EAttachmentRule.SnapToTarget
        self.trackPtpEntity.CppEntity:KAPI_Actor_AttachToComponent(mainMeshCompID, self.sectionConfig.SocketName, attachRule, attachRule, attachRule, true)
        return
    end

    self.startTrans = self.trackPtpEntity.CppEntity:KAPI_Actor_GetTransform()
    self.targetTrans = self:getSocketTransform(targetPtpEntity, mainMeshCompID, self.sectionConfig.SocketName)
end

function DS_NiagaraAttachInterp:OnTick(deltaTime)
    if self.sectionConfig.Immediate then
        return
    end

    if not self.targetTrans then
        Log.WarningFormat("[OnFinish] no target trans")
        return
    end

    if (self.trackPtpEntity == nil) or (self.trackPtpEntity.isDestroyed == true) then
        return
    end

    local alpha = self.runningTime / self.sectionConfig.Duration
    self.trackPtpEntity.CppEntity:KAPI_SetActorTransform(KML.TLerp(self.startTrans, self.targetTrans, alpha, 0), false, false)
end

function DS_NiagaraAttachInterp:OnFinish(finishReason)
    if self.sectionConfig.Immediate then
        return
    end

    if not self.targetTrans then
        Log.WarningFormat("[OnFinish] no target trans")
        return
    end

    if (self.trackPtpEntity == nil) or (self.trackPtpEntity.isDestroyed == true) then
        return
    end

    if finishReason ~= DialogueConst.SECTION_FINISH_REASON.LIFE_END then
        self.trackPtpEntity.CppEntity:KAPI_SetActorTransform(self.targetTrans, false, false)
    end

    local targetPtpEntity = self.ptpManager:GetParticipantEntityByName(self.sectionConfig.AttachActor)
    if (targetPtpEntity == nil) or (targetPtpEntity.isDestroyed == true) then
        return
    end

    local mainMeshCompID = targetPtpEntity.CppEntity:KAPI_Actor_GetMainSkeletalMeshComponent()
    if mainMeshCompID == 0 then
        return
    end

    -- 无论如何,最后都补一个attach
    local attachRule = EAttachmentRule.SnapToTarget
    self.trackPtpEntity.CppEntity:KAPI_Actor_AttachToComponent(mainMeshCompID, self.sectionConfig.SocketName, attachRule, attachRule, attachRule, true)
end

---@private
---@param entity table
---@param mainMeshCompId number
---@param socketName string
---@return FTransform
function DS_NiagaraAttachInterp:getSocketTransform(entity, mainMeshCompId, socketName)
    if string.isEmpty(socketName) or mainMeshCompId == 0 then
        return entity.CppEntity:KAPI_Actor_GetTransform()
    end

    if socketName == "root" then
        return entity.CppEntity:KAPI_Actor_GetTransform()
    elseif entity.CppEntity:KAPI_SkeletalMeshID_HasSocket(mainMeshCompId, socketName) then
        return entity.CppEntity:KAPI_SceneID_GetSocketTransform(mainMeshCompId, socketName, ERelativeTransformSpace.RTS_Actor)
    else
        return entity.CppEntity:KAPI_Actor_GetTransform()
    end
end
