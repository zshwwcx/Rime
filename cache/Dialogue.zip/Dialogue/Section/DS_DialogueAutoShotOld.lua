---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/28 20:21
---
local ECameraViewBlendFunction = import("ECameraViewBlendFunction")
local ECameraEaseFunction = import("ECameraEaseFunction")
local KismetMathLibrary = import("KismetMathLibrary")
local VectorConst = kg_require("Gameplay.CommonDefines.VectorConst")
local Utils = kg_require("Shared.Utils")
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_DialogueAutoShotOld : DialogueSectionBase
DS_DialogueAutoShotOld = DefineClass("DS_DialogueAutoShotOld", DialogueSectionBase)

local CONST_VEC_UP = VectorConst.UP_VECTOR
local CONST_VEC_DOWN = VectorConst.DOWN_VECTOR

---@param breathOffsetDis number
---@param sectionData table
---@param deltaTime number
function DS_DialogueAutoShotOld:_InternalMove(direction, sectionData, deltaTime)
    local cameraLocation = self.targetCameraEntity:GetPosition()

    local NewLocation = cameraLocation + direction * sectionData.BreathSpeed * deltaTime
    self.targetCameraEntity:SetPosition(NewLocation)
end

---@param breathFocusDistance number
---@param breathSpeed number
---@param axis PVector3
---@param deltaTime number
function DS_DialogueAutoShotOld:_InternalRotate(breathFocusDistance, breathSpeed, axis, deltaTime)
    local actorRotation = self.targetCameraEntity:GetRotation()
    local forwardVector = KismetMathLibrary.GetForwardVector(actorRotation)

    local KismetMath = KismetMathLibrary
    local NewDirection = KismetMath.RotateAngleAxis(forwardVector, breathSpeed * deltaTime, axis)
    local NewLocation = self.RotateTargetPos - NewDirection * breathFocusDistance
    local NewRotation = KismetMath.FindLookAtRotation(NewLocation, self.RotateTargetPos)
    self.targetCameraEntity:SetPosition(NewLocation)
    self.targetCameraEntity:SetRotation(NewRotation)
end

function DS_DialogueAutoShotOld:MoveLeft(sectionData, deltaTime)
    if self.RightVector then
        self:_InternalMove(self.RightVector * -1, sectionData, deltaTime)
    end
end

function DS_DialogueAutoShotOld:MoveRight(sectionData, deltaTime)
    if self.RightVector then
        self:_InternalMove(self.RightVector, sectionData, deltaTime)
    end
end

function DS_DialogueAutoShotOld:MoveTop(sectionData, deltaTime)
    self:_InternalMove(CONST_VEC_UP, sectionData, deltaTime)
end

function DS_DialogueAutoShotOld:MoveBottom(sectionData, deltaTime)
    self:_InternalMove(CONST_VEC_DOWN, sectionData, deltaTime)
end

function DS_DialogueAutoShotOld:MoveForward(sectionData, deltaTime)
    if self.ForwardVector then
        self:_InternalMove(self.ForwardVector, sectionData, deltaTime)
    end
end

function DS_DialogueAutoShotOld:MoveBackward(sectionData, deltaTime)
    if self.ForwardVector then
        self:_InternalMove(self.ForwardVector * -1, sectionData, deltaTime)
    end
end

function DS_DialogueAutoShotOld:RotateLeft(sectionData, deltaTime)
    self:_InternalRotate(sectionData.BreathFocusDistance, sectionData.BreathSpeed, self.UpVector,
            deltaTime)
end

function DS_DialogueAutoShotOld:RotateRight(sectionData, deltaTime)
    self:_InternalRotate(sectionData.BreathFocusDistance, sectionData.BreathSpeed * -1, self
            .UpVector, deltaTime)
end

function DS_DialogueAutoShotOld:RotateTop(sectionData, deltaTime)
    self:_InternalRotate(sectionData.BreathFocusDistance, sectionData.BreathSpeed, self.RightVector,
            deltaTime)
end

function DS_DialogueAutoShotOld:RotateBottom(sectionData, deltaTime)
    self:_InternalRotate(sectionData.BreathFocusDistance, sectionData.BreathSpeed * -1,
            self.RightVector, deltaTime)
end

--- camera break processor
---@type table<CameraBreathType, fun(autoCameraCut:DS_DialogueAutoShotOld, sectionData:table, deltaTime:number):void>
DS_DialogueAutoShotOld._transformer = {
    [DialogueConst.CameraBreathType.LEFT] = DS_DialogueAutoShotOld.MoveLeft,
    [DialogueConst.CameraBreathType.RIGHT] = DS_DialogueAutoShotOld.MoveRight,
    [DialogueConst.CameraBreathType.TOP] = DS_DialogueAutoShotOld.MoveTop,
    [DialogueConst.CameraBreathType.BOTTOM] = DS_DialogueAutoShotOld.MoveBottom,
    [DialogueConst.CameraBreathType.FRONT] = DS_DialogueAutoShotOld.MoveForward,
    [DialogueConst.CameraBreathType.BACK] = DS_DialogueAutoShotOld.MoveBackward,
    [DialogueConst.CameraBreathType.ROTATE_LEFT] = DS_DialogueAutoShotOld.RotateLeft,
    [DialogueConst.CameraBreathType.ROTATE_RIGHT] = DS_DialogueAutoShotOld.RotateRight,
    [DialogueConst.CameraBreathType.ROTATE_TOP] = DS_DialogueAutoShotOld.RotateTop,
    [DialogueConst.CameraBreathType.ROTATE_BOTTOM] = DS_DialogueAutoShotOld.RotateBottom,
}

---@param cameraBreathType CameraBreathType
---@return fun(autoCameraCut:DS_DialogueAutoShotOld, sectionData:table, deltaTime:number):void
function DS_DialogueAutoShotOld:GetTransformer(cameraBreathType)
    return self._transformer[cameraBreathType]
end

function DS_DialogueAutoShotOld:OnInit()
    self.DrawNpcCenter = nil
    self.DrawActorCenter = nil
    self.FocusActorDisatance = nil
    self.CurrentCameraComponent = nil
    self.targetCameraEntity = nil

    -- todo:AutoCameraManager里面有修改Section数据的需求,这里需要DeepCopy一下数据
    if type(self.sectionConfig) == 'userdata' then
        self.SectionData = Utils.deepCopyTable(self.sectionConfig)
    else
        self.SectionData = self.sectionConfig
    end
end

function DS_DialogueAutoShotOld:OnStart()
    local SectionData = self.SectionData

    self.targetCameraEntity = self.ptpManager:GetParticipantEntityByName(SectionData.CameraName)
    if not self.targetCameraEntity then
        Log.DebugWarningFormat("has no valid camera %s", SectionData.CameraName)
        return
    end

    --需要在自动相机设置前记录一下之前的相机参数 否则自动相机设置的TargetCamera可能跟CurrentCamera是同一个

    local targetCameraID = self.targetCameraEntity.CharacterID
    local easeType = ECameraEaseFunction.Linear
    local blendType = ECameraViewBlendFunction.Polar

    if not self.SectionData.ImmediateCut then
        Game.CameraManager:SetDialogueCameraWithCustomBlend(targetCameraID, self.SectionData.Duration, easeType, blendType)
    else
        Game.CameraManager:SetDialogueCameraWithCustomBlend(targetCameraID, 0, easeType, blendType)
    end

    --自动相机的位置计算到TargetCamera
    --self:HandleDefaultActor()
    self.dialogueInstance.AutoCameraManager:CalculateCameraParams(self, self.targetCameraEntity, SectionData)

    self:HandleCameraParam()

    --预处理呼吸的一些参数
    self:PreDealBreath()
end

function DS_DialogueAutoShotOld:HandleCameraParam()
    local targetCameraID = self.targetCameraEntity.CharacterID
    local bOpenDOF = self.SectionData.bOpenDOF
    Game.CameraManager:KAPI_Camera_DialogueCamera_SetCameraDOFOverride(targetCameraID, bOpenDOF, bOpenDOF, bOpenDOF)

    if self.SectionData.ImmediateCut then
        if bOpenDOF then
            local DepthOfFieldFocalDistance
            if self.FocusActorDisatance then
                DepthOfFieldFocalDistance = self.FocusActorDisatance
            else
                DepthOfFieldFocalDistance = self.SectionData.DepthOfFieldFocalDistance
            end
            local DepthOfFieldSensorWidth = self.SectionData.DepthOfFieldSensorWidth
            local DepthOfFieldFstop = self.SectionData.DepthOfFieldFStop
            Game.CameraManager:KAPI_Camera_DialogueCamera_SetCameraDOFParams(targetCameraID, DepthOfFieldFocalDistance, DepthOfFieldSensorWidth, DepthOfFieldFstop)
        end
    else
        if bOpenDOF then
            self.TargetDepthOfFieldSensorWidth = self.SectionData.DepthOfFieldSensorWidth
            self.TargetDepthOfFieldFStop = self.SectionData.DepthOfFieldFStop
            if self.SectionData.DepthOfFieldFocalDistance > 0 then
                self.TargetDepthOfFieldFocalDistance = self.SectionData.DepthOfFieldFocalDistance
            else
                self.TargetDepthOfFieldFocalDistance = self.FocusActorDisatance
            end
        else
            local ppSettings = Game.CameraManager:KAPI_Camera_GetPPSetting(targetCameraID)
            self.TargetDepthOfFieldFocalDistance = ppSettings.DepthOfFieldFocalDistance
            self.TargetDepthOfFieldSensorWidth = ppSettings.DepthOfFieldSensorWidth
            self.TargetDepthOfFieldFStop = ppSettings.DepthOfFieldFstop
        end
    end
end

function DS_DialogueAutoShotOld:OnTick(DeltaTime)
    local AutoCameraManager = self.dialogueInstance.AutoCameraManager
    -- 如果开启了自动相机追踪需要实时计算TargetCamera位置
    if self.SectionData.AutoFocus or (not AutoCameraManager.bHaveFinishCal) then
        AutoCameraManager:CalculateCameraParams(self, self.targetCameraEntity, self.SectionData)
        self:HandleCameraParam()
    end

    local CamBreathType = DialogueConst.CameraBreathType
    local sectionData = self.SectionData
    local sectionCameraBreakType = sectionData.CameraBreathType
    if sectionCameraBreakType ~= CamBreathType.NONE then
        if self.runningTime > sectionData.BreathDelay then
            --可以开始呼吸效果
            if (sectionData.Duration - self.runningTime) > 0 and
                    (sectionData.Duration - self.runningTime) < sectionData.BreathAttenuation
            then
                --呼吸效果需要衰减
                DeltaTime = DeltaTime * (sectionData.Duration - self.runningTime) /
                        sectionData.BreathAttenuation
            end

            local func = self:GetTransformer(sectionCameraBreakType)
            if func then
                func(self, sectionData, DeltaTime)
            else
                Log.DebugWarning(
                        "DS_DialogueAutoShotOld:Tick transform camera failed: wrong camera breath type ",
                        sectionCameraBreakType)
            end
        end
    end

    local Ratio = self.runningTime / self.SectionData.Duration
    if (Ratio > 1) then
        Ratio = 1
    end
end

function DS_DialogueAutoShotOld:PreDealBreath()
    local CamBreathType = DialogueConst.CameraBreathType
    local sectionData = self.SectionData
    if sectionData.CameraBreathType ~= CamBreathType.NONE then
        local actorRotation = self.targetCameraEntity:GetRotation()
        local forwardVector = KismetMathLibrary.GetForwardVector(actorRotation)

        if sectionData.CameraBreathType == CamBreathType.ROTATE_LEFT
                or sectionData.CameraBreathType == CamBreathType.ROTATE_RIGHT
                or sectionData.CameraBreathType == CamBreathType.ROTATE_TOP
                or sectionData.CameraBreathType == CamBreathType.ROTATE_BOTTOM
        then
            local actorLocation = self.targetCameraEntity:GetPosition()
            self.RotateTargetPos = actorLocation + forwardVector * self.SectionData.BreathFocusDistance
        end

        self.UpVector = FVector(0, 0, 1)
        self.RightVector = KismetMathLibrary.GetRightVector(actorRotation)
        self.ForwardVector = forwardVector
    end
end

function DS_DialogueAutoShotOld:OnActionNoticeToSectionInstance(Param, InObject)
    if InObject then
        self.SectionData = InObject
    end

    local AutoCameraManager = Game.DialogueManagerV2.AutoCameraManager
    if Param == Enum.EAutoCameraNoticeLuaEvent.UpdateAutoCamera then
        AutoCameraManager:CalculateCameraParams(self, self.targetCameraEntity, self.SectionData)
        self:HandleCameraParam()
    elseif Param == Enum.EAutoCameraNoticeLuaEvent.UpdateSectionParams then
        AutoCameraManager:TransformToOneActor(self, self.targetCameraEntity)
    elseif Param == Enum.EAutoCameraNoticeLuaEvent.UpdateTableParams then
        if self.SectionData.AutoCameraType == Enum.EAutoCameraType.OneActor then
            self:OnUseTemplateOnePerson(AutoCameraManager)
        elseif self.SectionData.AutoCameraType == Enum.EAutoCameraType.TwoActorTypeOne then
            self:OnUseTemplateTwoPersonTypeOne(AutoCameraManager)
        elseif self.SectionData.AutoCameraType == Enum.EAutoCameraType.TwoActorTypeTwo then
            self:OnUseTemplateTwoPersonTypeTwo(AutoCameraManager)
        end
    elseif Param == Enum.EAutoCameraNoticeLuaEvent.UpdateDoF then
        AutoCameraManager:SetFocusActorPostion(self.SectionData.DepthOfFieldFocusActor, self.targetCameraEntity)
        self:HandleCameraParam()
    end
end

function DS_DialogueAutoShotOld:OnUseTemplateOnePerson(AutoCameraManager)
    local Data = Game.TableData.GetDialogueAutoCameraOnePDataRow(
            self.SectionData.OnePersonTemplate + Enum.EAutoCameraTypeStartIndex.OneActor)

    local sectionData = self.SectionData
    sectionData.ActorFocusH = Data.H
    sectionData.ActorFocusV = Data.V
    sectionData.CameraFovX = Data.HFov
    sectionData.ActorFocusDist = Data.Dist
    sectionData.CameraYaw = Data.theta
    sectionData.CameraPitch = Data.Pitch

    AutoCameraManager:CalculateCameraParams(self, self.targetCameraEntity, sectionData)
    sectionData.SectionName = Data.AutoCameraCutDesc
    self:HandleCameraParam()
end

function DS_DialogueAutoShotOld:OnUseTemplateTwoPersonTypeOne(AutoCameraManager)
    local Data = Game.TableData.GetDialogueAutoCameraTwoPTypeOneDataRow(
            self.SectionData.TwoPersonTypeOneTemplate + Enum.EAutoCameraTypeStartIndex.TwoActorTypeOne)

    local sectionData = self.SectionData
    sectionData.ActorFocusH = Data.H1
    sectionData.ActorFocusV = Data.V1
    sectionData.ActorBackendH = Data.H2
    sectionData.ActorBackendV = Data.V2
    sectionData.CameraFovX = Data.HFov
    sectionData.CameraYaw = Data.theta
    sectionData.SectionName = Data.AutoCameraCutDesc

    AutoCameraManager:CalculateCameraParams(self, self.targetCameraEntity, sectionData)
    self:HandleCameraParam()
end

function DS_DialogueAutoShotOld:OnUseTemplateTwoPersonTypeTwo(AutoCameraManager)
    local Data = Game.TableData.GetDialogueAutoCameraTwoPTypeTwoDataRow(
            self.SectionData.TwoPersonTypeTwoTemplate + Enum.EAutoCameraTypeStartIndex.TwoActorTypeTwo)

    local sectionData = self.SectionData
    sectionData.ActorFocusH = Data.H1
    sectionData.ActorFocusV = Data.V1
    sectionData.ActorBackendH = Data.H2
    sectionData.CameraFovX = Data.HFov
    sectionData.CameraYaw = Data.theta
    sectionData.CameraPitch = Data.Pitch
    sectionData.SectionName = Data.AutoCameraCutDesc

    AutoCameraManager:CalculateCameraParams(self, self.targetCameraEntity, sectionData)
    self:HandleCameraParam()
end
