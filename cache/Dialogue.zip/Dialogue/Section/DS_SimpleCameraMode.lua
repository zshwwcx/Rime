---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/28 17:04
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_SimpleCameraMode : DialogueSectionBase
DS_SimpleCameraMode = DefineClass("DS_SimpleCameraMode", DialogueSectionBase)

function DS_SimpleCameraMode:OnStart()
	if not self.sectionConfig then
		Log.ErrorFormat("[DialogueV2][DS_SimpleCameraMode] sectionConfig is nil in dialogue: %s", self.DialogueID)
		return false
	end
	if not self.ptpManager then
		Log.ErrorFormat("[DialogueV2][DS_SimpleCameraMode] ptpManager is nil in dialogue: %s", self.DialogueID)
		return false
	end
    local primaryPtpEntity = self.ptpManager:GetParticipantEntityByName(self.sectionConfig.PrimaryActor)
    local secondaryPtpEntity = self.ptpManager:GetParticipantEntityByName(self.sectionConfig.SecondaryActor)
    Game.CameraManager:EnableSimpleDialogueCamera(true, primaryPtpEntity, secondaryPtpEntity)
end

function DS_SimpleCameraMode:OnFinish(finishReason)
	if not self.sectionConfig then
		Log.ErrorFormat("[DialogueV2][DS_SimpleCameraMode] sectionConfig is nil in dialogue: %s", self.DialogueID)
		return false
	end
    if self.sectionConfig.bExitOnEnd then
        Game.CameraManager:EnableSimpleDialogueCamera(false)  
        return
    end

    self.dialogueInstance:SetBlackBoardValue(DialogueConst.BlackBoardKey.NEED_EXIT_SIMPLE_CAMERA_MODE, true)
end
