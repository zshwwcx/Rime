---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/6/4 20:08
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_QTE : DialogueSectionBase
DS_QTE = DefineClass("DS_QTE", DialogueSectionBase)

function DS_QTE:OnStart()
    self.dialogueInstance:AddDialogueBarrier(DialogueConst.BARRIER_TYPE.QTE, nil, self.sectionConfig)
end
