---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/28 16:59
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_CameraFov : DialogueSectionBase
DS_CameraFov = DefineClass("DS_CameraFov", DialogueSectionBase)

function DS_CameraFov:OnStart()
    if self.trackPtpEntity then
        Game.CameraManager:KAPI_Camera_DialogueCamera_SetCameraFOV(self.trackPtpEntity.CharacterID, self.sectionConfig.Fov)
    end
end
