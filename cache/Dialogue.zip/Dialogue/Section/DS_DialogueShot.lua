---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/13 15:17
---
local KSL = import("KismetSystemLibrary")
local EViewTargetBlendFunction = import("EViewTargetBlendFunction")


local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_DialogueShot : DialogueSectionBase
---@field private sectionConfig BPS_DialogueShot_C
DS_DialogueShot = DefineClass("DS_DialogueShot", DialogueSectionBase)

function DS_DialogueShot:OnInit()
    self.DrawCenter = nil
    -- Component缓存
    self.CurrentCameraComponent = nil
    -- Actor缓存
    self.TargetCamera = nil
    self.IgnorePause = true
    self.TargetActorDistance = nil
    self.timeCounter = 0
    self.rotateTargetLoc = nil

	self.__HeadSocketName__ = "head"
	self.__BipHeadSocketName__ = "Bip001-Head"


    local DialogueCameraSwitchType = DialogueConst.DialogueCameraSwitchType
    self.easeFunc = {
        [DialogueCameraSwitchType.Smooth] = EViewTargetBlendFunction.VTBlend_Linear,
        [DialogueCameraSwitchType.EaseIn] = EViewTargetBlendFunction.VTBlend_EaseIn,
        [DialogueCameraSwitchType.EaseOut] = EViewTargetBlendFunction.VTBlend_EaseOut,
        [DialogueCameraSwitchType.EaseInOut] = EViewTargetBlendFunction.VTBlend_EaseInOut,
    }
end

function DS_DialogueShot:OnStart(bSkip)
	if not self.sectionConfig then
		Log.WarningFormat("[DialogueV2][DS_DialogueShot] sectionConfig is nil in dialogue: %s", self.DialogueID)
		return false
	end
	if not self.ptpManager then
		Log.WarningFormat("[DialogueV2][DS_DialogueShot] ptpManager is nil in dialogue: %s", self.DialogueID)
		return false
	end
    local targetCameraEntity = self.ptpManager:GetParticipantEntityByName(self.sectionConfig.TargetCamera)
    if not targetCameraEntity then
        Log.WarningFormat("[DialogueV2][DS_DialogueShot] get target camera entity %s failed", self.sectionConfig.TargetCamera)
        return false
    end

    if self.sectionConfig.KeepPreShotTransform then
        local pov = self.dialogueInstance:GetBlackBoardValue(DialogueConst.BlackBoardKey.POV_INFO)
        if pov then
            targetCameraEntity:SetPosition_P(pov.x, pov.y, pov.z)
            targetCameraEntity:SetRotation_P(pov.pitch, pov.yaw, pov.roll)
            local characterID = targetCameraEntity.CharacterID
            Game.CameraManager:KAPI_Camera_DialogueCamera_SetCameraFOV(characterID, pov.fov)
            Game.CameraManager:KAPI_Camera_DialogueCamera_SetAspectRatio(characterID, pov.aspectRatio)
            Game.CameraManager:KAPI_Camera_DialogueCamera_SetConstraintAspectRatio(characterID, pov.bConstrainAspectRatio)
        end
    else
        self:tryResetCameraTransform(targetCameraEntity)
    end
    self.TargetActorDistance = self:tryGetFocusActorDistance(targetCameraEntity)

    -- 对话本身有Blend时,第一个Section的逻辑: --需要BlendIn，则忽略第一个机位
	if self.dialogueInstance.DialogueConfig.BlendInCamera and self.dialogueInstance.currentEpisode.episodeIdx == 1 and self.sectionIndex == 1 then
		Game.CameraManager:SetDialogueCameraWithCustomBlend(targetCameraEntity.CharacterID, 1)
	else
		Game.CameraManager:SetDialogueCameraWithCustomBlend(targetCameraEntity.CharacterID, 0)
	end

    -- 没有呼吸镜头效果，则直接开始处理下一个镜头的平滑过渡逻辑
    if self.sectionConfig.CameraBreathType == DialogueConst.CameraBreathType.NONE then
        local nextSectionConfig = self:getNextShotConfig()
        if nextSectionConfig ~= nil and nextSectionConfig.SwitchType then
            local blendType = self:getViewTargetBlendFunction(nextSectionConfig.SwitchType)
            local nextCameraEntity = self.ptpManager:GetParticipantEntityByName(nextSectionConfig.TargetCamera)
            if nextCameraEntity and blendType then
                -- 目标相机可能不在锁头的位置上，在平滑过渡开启前对目标相机先做一次锁头操作
                self:tryResetCameraTransform(nextCameraEntity)
                local blendTime = nextSectionConfig.StartTime - self.sectionConfig.StartTime
                Game.CameraManager:SetDialogueCameraWithBlend(nextCameraEntity.CharacterID, blendTime, blendType)
            end
        end
    else
        local nextSectionConfig = self:getNextShotConfig()
        if nextSectionConfig ~= nil and nextSectionConfig.SwitchType then
            local blendType = self:getViewTargetBlendFunction(nextSectionConfig.SwitchType)
            local nextCameraEntity = self.ptpManager:GetParticipantEntityByName(nextSectionConfig.TargetCamera)
            if nextCameraEntity and blendType then
                local blendTime = nextSectionConfig.StartTime - self.sectionConfig.StartTime - self.sectionConfig.Duration
                local characterID = nextCameraEntity.CharacterID
                self.pendingAction = function()
                    -- 目标相机可能不在锁头的位置上，在平滑过渡开启前对目标相机先做一次锁头操作
                    self:tryResetCameraTransform(nextCameraEntity)
                    Game.CameraManager:SetDialogueCameraWithBlend(characterID, blendTime, blendType)
                end
            end
        end
    end

    if self.TargetActorDistance then
        Game.CameraManager:KAPI_Camera_DialogueCamera_SetCameraDOFDistance(targetCameraEntity.CharacterID, self.TargetActorDistance)
    end

    if self.sectionConfig.CameraBreathType ~= DialogueConst.CameraBreathType.NONE then
        self:preDealBreath(targetCameraEntity)
    end

    local blackboardKey = DialogueConst.BlackBoardKey.CAMERA_HANDHELD_TOKEN
    local curCameraHandheldToken = self.dialogueInstance:GetBlackBoardValue(blackboardKey)
    if curCameraHandheldToken then
        Game.CameraManager:StopCameraShakeByToken(curCameraHandheldToken)
        self.dialogueInstance:SetBlackBoardValue(blackboardKey, nil)
        Log.DebugFormat("[SimHandheldCamera] stop shake:%s", curCameraHandheldToken)
    end

    if self.sectionConfig.bSimHandheldCamera then
        local shakeTokenHandheld = Game.CameraManager:StartCameraShakeByAssetPath(self.sectionConfig.CameraShakeAsset,
            self.sectionConfig.ShakeAmplitudeMultiplier or 1, -1)
        self.dialogueInstance:SetBlackBoardValue(blackboardKey, shakeTokenHandheld)
        self.shakeTokenHandheld = shakeTokenHandheld
        Log.DebugFormat("[SimHandheldCamera] apply shake:%s", shakeTokenHandheld)
    end

	Log.InfoFormat("[DialogueV2][DS_DialogueShot] OnStart success for camera %s in dialogue: %s",
		self.sectionConfig.TargetCamera, self.DialogueID)
end

function DS_DialogueShot:OnFinish(finishReason)
	if not self.sectionConfig then
		Log.WarningFormat("[DialogueV2][DS_DialogueShot] sectionConfig is nil in dialogue: %s", self.DialogueID)
		return false
	end

    if self.pendingAction then
        self.pendingAction()
        self.pendingAction = nil
    end
    
    --if self.sectionConfig.bSimHandheldCamera and self.shakeTokenHandheld then
    --    Game.CameraManager:StopCameraShakeByToken(self.shakeTokenHandheld)
    --    self.shakeTokenHandheld = nil
    --end
end

DS_DialogueShot.__UpVector__ = FVector(0, 0, 1)
DS_DialogueShot.__DownVector__ = FVector(0, 0, -1)

function DS_DialogueShot:OnTick(deltaTime, bSkip)
	if not self.sectionConfig then
		Log.WarningFormat("[DialogueV2][DS_DialogueShot] sectionConfig is nil in dialogue: %s", self.DialogueID)
		return false
	end
    -- TODO: limunan,IGNORE_PAUSE_TICK的section生命周期跟普通section的生命周期不一致，需要重新梳理与处理
    local lastTime = self.timeCounter
    if not self.bPause then
        self.timeCounter = self.timeCounter + deltaTime
    end

    local duration = self.sectionConfig.Duration
    if lastTime < duration and self.timeCounter >= duration then
        if self.pendingAction then
            self.pendingAction()
            self.pendingAction = nil
        end
    end

    local targetCameraEntity = self.ptpManager:GetParticipantEntityByName(self.sectionConfig.TargetCamera)
    if not targetCameraEntity then
		Log.WarningFormat("[DialogueV2][DS_DialogueShot] get target camera entity %s failed in dialogue: %s", self.sectionConfig.TargetCamera, self.DialogueID)
		return false
    end

	if bSkip then
		return
	end

    if self.sectionConfig.CameraBreathType == DialogueConst.CameraBreathType.NONE then
        return
    end

    if self.totalRunningTime < self.sectionConfig.BreathDelay then
        return
    end

    -- Section实际运行时长大于duration,不再执行
    if self.totalRunningTime > duration then
        return
    end

    --local rootCompID = targetCameraEntity.CppEntity:KAPI_Actor_GetRootComponent()
    --local rightVector = targetCameraEntity.CppEntity:KAPI_SceneID_GetRightVector(rootCompID)
    --local forwardVector = targetCameraEntity.CppEntity:KAPI_SceneID_GetForwardVector(rootCompID)

    -- 振幅计算缩放比例
    local ratio = deltaTime

    -- 配置了衰减,从BreathAttenuation开始衰减
    if self.sectionConfig.BreathAttenuation > 0 then
        local leftTime = duration - self.totalRunningTime
        leftTime = leftTime > 0 and leftTime or 0
        if leftTime < self.sectionConfig.BreathAttenuation then
            ratio = ratio * (leftTime / self.sectionConfig.BreathAttenuation)
        end
    end

    local rotateTargetLoc = self.rotateTargetLoc
    local rotateTargetX = rotateTargetLoc and rotateTargetLoc.X or 0
    local rotateTargetY = rotateTargetLoc and rotateTargetLoc.Y or 0
    local rotateTargetZ = rotateTargetLoc and rotateTargetLoc.Z or 0

    targetCameraEntity.CppEntity:KAPI_Dialogue_CameraBreath(
            ratio,
            self.sectionConfig.BreathSpeed,
            self.sectionConfig.BreathFocusDistance,
            self.sectionConfig.CameraBreathType,
            rotateTargetX, rotateTargetY, rotateTargetZ)
end

---分镜开始时,尝试根据当前对话状态(主要是演员的位置)重新设置
---@private
---@param targetCameraEntity DialogueCamera
function DS_DialogueShot:tryResetCameraTransform(targetCameraEntity)
    local cameraConfig = targetCameraEntity.ptpConfig
    if not cameraConfig then
        Log.WarningFormat("[DialogueV2][DS_DialogueShot]tryResetCameraTransform failed: camera config is nil in dialogue: %s", self.DialogueID)
        return false
    end
    
    local curViewTarget = Game.CameraManager.PlayerController:GetViewTarget()
    local curViewTargetID = Game.ObjectActorManager:GetIDByObject(curViewTarget)
    if curViewTargetID == targetCameraEntity.CharacterID then
        Log.DebugFormat("[DialogueV2][DS_DialogueShot]tryResetCameraTransform %s: same view target, will not reset", cameraConfig.TrackName)
        return
    end

    local parentEntity = self.ptpManager:GetParticipantEntityByName(cameraConfig.Parent)
    if not parentEntity then
        Log.WarningFormat("[DialogueV2][DS_DialogueShot]tryResetCameraTransform failed, get %s parent entity %s failed in dialogue: %s", 
            cameraConfig.TrackName, cameraConfig.Parent, self.DialogueID)
        return false
    end

    local bSuccess = targetCameraEntity:AdjustTransformForCameraConfig()
    if not bSuccess then
        Log.WarningFormat("[DialogueV2][DS_DialogueShot]tryResetCameraTransform %s failed: get transform failed in dialogue: %s", 
            cameraConfig.TrackName, self.DialogueID)
        return false
    end

    return true
end

---获取相机到注视目标的距离
---@private
---@return number|nil
function DS_DialogueShot:tryGetFocusActorDistance(targetCameraEntity)
	local focusPtpName = targetCameraEntity.ptpConfig.DepthOfFieldFocusActor
	if string.isEmpty(focusPtpName) then
		return targetCameraEntity.ptpConfig.DepthOfFieldFocalDistance
	end

	local focusEntity = self.ptpManager:GetParticipantEntityByName(focusPtpName)
	if not focusEntity then
		Log.DebugFormat("[DialogueV2][DS_DialogueShot][tryGetFocusActorDistance] get focus actor %s failed, use config DepthOfFieldFocalDistance in dialogue: %s", focusPtpName, self.DialogueID)
		return targetCameraEntity.ptpConfig.DepthOfFieldFocalDistance
	end

	return targetCameraEntity:GetFocusActorDistance(focusEntity)
end

DS_DialogueShot.__DrawDebugColor__ = FLinearColor(255, 0, 0)

---预处理镜头呼吸相关
---@private
function DS_DialogueShot:preDealBreath(targetCameraEntity)
	if not self.sectionConfig then
		Log.WarningFormat("[DialogueV2][DS_DialogueShot] sectionConfig is nil in dialogue: %s", self.DialogueID)
		return false
	end
    local breathType = self.sectionConfig.CameraBreathType
    if (breathType == DialogueConst.CameraBreathType.ROTATE_LEFT) or
            (breathType == DialogueConst.CameraBreathType.ROTATE_RIGHT) or
            (breathType == DialogueConst.CameraBreathType.ROTATE_TOP) or
            (breathType == DialogueConst.CameraBreathType.ROTATE_BOTTOM)
    then
        local rootCompID = targetCameraEntity.CppEntity:KAPI_Actor_GetRootComponent()
        local forwardVector = targetCameraEntity.CppEntity:KAPI_SceneID_GetForwardVector(rootCompID)

        self.rotateTargetLoc = targetCameraEntity:GetPosition() + forwardVector * self.sectionConfig.BreathFocusDistance

        -- 编辑态绘制
        if _G.StoryEditor then
            KSL.DrawDebugSphere(Game.WorldContext, self.rotateTargetLoc, 0.01, 1, self.__DrawDebugColor__, self.sectionConfig.Duration, 1)
        end
    end
end

-- todo@wujianxiong:编辑态将下个分镜数据写到当前Section中
---@private
---@return table|nil
function DS_DialogueShot:getNextShotConfig()
	if not self.ownerTrack then
		Log.WarningFormat("[DialogueV2][DS_DialogueShot] ownerTrack is nil in dialogue: %s", self.DialogueID)
		return false
	end
    local sectionConfigs = self.ownerTrack.trackConfig.ActionSections
    local curSectionIndex = nil
    for idx, sectionConfig in ksbcipairs(sectionConfigs) do
        if sectionConfig == self.sectionConfig then
            curSectionIndex = idx
            break
        end
    end

    if (curSectionIndex ~= nil) and (curSectionIndex < #sectionConfigs) then
        return sectionConfigs[curSectionIndex + 1]
    end
end

--- 根据切换类型获取切换相机的插值函数
---@private
---@param switchType DialogueCameraSwitchType
---@return EViewTargetBlendFunction
function DS_DialogueShot:getViewTargetBlendFunction(switchType)
    local t = self.easeFunc[switchType]
    if t then
        return t
    end

    return nil
end

function DS_DialogueShot:NeedFinish(bSkip)
    if self:IsInRunningState(DialogueConst.SECTION_RUNNING_STATE.FINISHED) then
        return false
    end
    
    if self.bInRunning == true and
        self.sectionConfig.CameraBreathType == DialogueConst.CameraBreathType.NONE then
        return true
    end

    return (self.bInRunning == true) and (self.runningTime - self.sectionConfig.Duration > -0.00001)
end
