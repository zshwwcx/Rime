---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/29 17:34
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_TarotCard : DialogueSectionBase
DS_TarotCard = DefineClass("DS_TarotCard", DialogueSectionBase)

function DS_TarotCard:OnStart()
    -- todo:没有ResourceObject这个字段
    --local frameImagePath
    --if IsValidObjectName(self.sectionConfig.Frame.ResourceObject) then
    --    frameImagePath = self.sectionConfig.Frame.ResourceObject
    --end
	if not self.sectionConfig then
		Log.ErrorFormat("[DialogueV2][DS_TarotCard] sectionConfig is nil in dialogue: %s", self.DialogueID)
		return false
	end
    Game.NewUIManager:OpenPanelWithTargetUI(UIPanelConfig.DialogueTarotCard_Panel, UIPanelConfig.Dialogue_Panel, self.sectionConfig.bHasBlackBg, self.sectionConfig.Image)
end

function DS_TarotCard:OnFinish(finishReason)
    Game.GlobalEventSystem:Publish(EEventTypesV2.CLOSE_DIALOGUE_TAROT_CARD_PANEL)
    if finishReason ~= DialogueConst.SECTION_FINISH_REASON.LINE_END then
        Game.NewUIManager:ClosePanel(UIPanelConfig.DialogueTarotCard_Panel)
    end
end
