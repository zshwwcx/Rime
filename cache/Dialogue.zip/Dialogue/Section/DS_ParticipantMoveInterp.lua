---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/26 17:43
---
local KML = import("KismetMathLibrary")
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_ParticipantMoveInterp : DialogueSectionBase
DS_ParticipantMoveInterp = DefineClass("DS_ParticipantMoveInterp", DialogueSectionBase)

DS_ParticipantMoveInterp.__RunAnimID__ = "Run_Loop"
DS_ParticipantMoveInterp.__WalkAnimID__ = "Walk_Loop"

function DS_ParticipantMoveInterp:OnInit()
    self.startLoc = nil
    self.targetLoc = nil
    self.animPlayID = 0
end

function DS_ParticipantMoveInterp:OnStart()
    if not self.trackPtpEntity then
        return
    end

    local targetPtpName
    if IsValidObjectName(self.sectionConfig.MoveTarget) then
        targetPtpName = self.sectionConfig.MoveTarget
    else
        targetPtpName = self.sectionConfig.TargetActor
    end

    local targetPtpEntity = self.ptpManager:GetParticipantEntityByName(targetPtpName)
    if not targetPtpEntity then
        return
    end

    self.startLoc = self.trackPtpEntity:GetPosition()
    self.targetLoc = targetPtpEntity:GetPosition()

    -- 瞬移过去，直接修改朝向到目标朝向
	if self.sectionConfig.Immediate then
		self:DealWithTeleportRotation(targetPtpEntity)
        Log.DebugFormat("[DialogueV2][DS_ParticipantMoveInterp]OnStart, DealWithTeleportRotation on entity:%s to target:%s in dialogue[%s]", 
            self.trackPtp.TrackName, targetPtpName, self.DialogueID)
		return
	end
	
	-- 非瞬移，修改朝向
	self:DealWithKeepMovingRotation()

    -- 禁用rootMotion中的根位移累加量
    if self.trackPtp.PtpType == DialogueConst.PARTICIPANT_TYPE.PERFORMER then
        self.trackPtpEntity:SetMoveByThrusterWithoutAnimRM()

        local animAssetID
        local specificAnim = self.sectionConfig.SpecificAnim
        if specificAnim ~= nil and not string.isEmpty(specificAnim.AssetID) then
            animAssetID = specificAnim.AssetID
        elseif self.sectionConfig.Run then
            animAssetID = self.__RunAnimID__
        else
            animAssetID = self.__WalkAnimID__
        end

        self.animPlayID = self.trackPtpEntity:PlayAnimLibMontage(animAssetID, nil, true)
        Log.DebugFormat("[DialogueV2][DS_ParticipantMoveInterp]OnStart, move entity:%s in dialogue[%s]",
            self.trackPtp.TrackName, targetPtpName, self.DialogueID)
    end
end

function DS_ParticipantMoveInterp:DealWithTeleportRotation(targetPtpEntity)
	local targetRot = targetPtpEntity:GetRotation()
	if not self.sectionConfig.bFixedRotation then
		self.trackPtpEntity:SetRotation(targetRot)
	end

	self.trackPtpEntity:SetPosition(self.targetLoc)
	if self.sectionConfig.StickGround then
		self.trackPtpEntity.CppEntity:KAPI_Character_SimpleSetActorStickGround()
	end
end

function DS_ParticipantMoveInterp:DealWithKeepMovingRotation()
	if not self.sectionConfig.bFixedRotation then
		local newRotation = KML.FindLookAtRotation(self.startLoc, self.targetLoc)
		local TargetRot = FRotator(0.0, newRotation.Yaw, 0.0)
		self.trackPtpEntity:SetRotation(TargetRot)
	end
end

function DS_ParticipantMoveInterp:OnTick(deltaTime)
    if self.sectionConfig.Immediate then
        return
    end

    if not self.trackPtpEntity then
        return
    end

    if (self.startLoc == nil) or (self.targetLoc == nil) then
        return
    end

    local alpha = self.runningTime / self.sectionConfig.Duration
    if alpha > 1 then
        alpha = 1
    end

    local interpLoc = KML.VLerp(self.startLoc, self.targetLoc, alpha)

    -- 每帧贴地
    if self.sectionConfig.StickGround then
        self.trackPtpEntity.CppEntity:KAPI_Character_SimpleSetActorStickGround()
        local locAfterStickGround = self.trackPtpEntity:GetPosition()
        interpLoc.Z = locAfterStickGround.Z
    end

    Log.DebugFormat("[DS_ParticipantMoveInterp]SetActorNewLocation: %s", interpLoc:ToString())
    self.trackPtpEntity:SetPosition(interpLoc)
end

function DS_ParticipantMoveInterp:OnFinish(finishReason)
    if self.sectionConfig.Immediate then
        return
    end

    if (self.trackPtpEntity == nil) or (self.trackPtpEntity.isDestroyed == true) then
        return
    end

    if self.trackPtp.PtpType == DialogueConst.PARTICIPANT_TYPE.PERFORMER then
        self.trackPtpEntity:CancelSetLocoSourceModeToAnimRootMotion()
        self.trackPtpEntity:StopAnimLibMontage(self.animPlayID)
        self.animPlayID = 0
    end

    if finishReason ~= DialogueConst.SECTION_FINISH_REASON.LIFE_END then
        self.trackPtpEntity:SetPosition(self.targetLoc)
        if self.sectionConfig.StickGround then
            self.trackPtpEntity.CppEntity:KAPI_Character_SimpleSetActorStickGround()
        end
    end
end
