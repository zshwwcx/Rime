---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/29 10:50
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase
local TimerBase = kg_require("Framework.KGFramework.KGCore.TimerManager.TimerBase").TimerBase


---@class DS_DialogueSequenceCut : DialogueSectionBase
DS_DialogueSequenceCut = DefineClass("DS_DialogueSequenceCut", DialogueSectionBase, TimerBase)

function DS_DialogueSequenceCut:OnInit()
    self.loadID = 0
	self.bHaveFinished = false
	self.currentStartPlayTime = 0
end

function DS_DialogueSequenceCut:dtor()
	if self.loadID and self.loadID ~= 0 then
		Game.DialogueManagerV2.SequenceManager:StopLevelSequence(self.loadID)
		Log.DebugFormat("[DS_DialogueSequenceCut] DialogueSequence dtor FrameCount: %s GameTime: %s loadHandleID: %s", import("KismetSystemLibrary").GetFrameCount(), Game.GameTimeMS, self.loadID)
	end
	self.loadID = 0
end

function DS_DialogueSequenceCut:OnStart()
    local sequenceID = self.sectionConfig.SequenceAssetID
    self.nextCameraID, self.nextCameraName, self.bKeepTransform = self.dialogueInstance:GetNextCamera(self.sectionConfig
        .StartTime + self.sectionConfig.Duration)
    if self.nextCameraID then
        Game.CameraManager:SetDialogueCameraWithCustomBlend(self.nextCameraID, 0)
    else
        Game.CameraManager:EnableSimpleDialogueCamera(false)
        Game.CameraManager:EnableDialogueCamera(false)
    end
    local sequenceData = Game.TableData.GetDilaogueSeuqenceDataRow(sequenceID)
    if not sequenceData then
        return
    end
	local params = {["CinematicType"] = Enum.CinematicType.DialogueSequence, ["AssetID"] = sequenceID}
	local havePreLoad = Game.SequenceManager:CheckHavePreLoad(params)
    --Game.CameraManager:EnableDialogueCamera(false)
	self.dialogueInstance:SetAllParticipantsVisibility(false, DialogueConst.PARTICIPANT_HIDE_SOURCE.DIALOGUE_SEQUENCE)
    local playParams = { AssetID = sequenceID, bBindCamera = self.sectionConfig.UseSequenceCamera,
                         OnCinematicFinished = function()
                             if not self.isDestroyed then
                                 self:OnSequenceFinish()
                             end
                         end,
                         OnCinematicPlay = function()
                             self:OnSeqStartPlay()
                         end,
						 OnCameraCut = function(cameraCompID)
							 self:OnCameraCutCallBack(cameraCompID)
						 end,
	}
	local cacheTask = Game.SequenceManager:FindPlayTaskByTypeAndAssetID(Enum.CinematicType.DialogueSequence, sequenceID)
	if cacheTask and cacheTask:GetTaskStatus() == Enum.SequencePlayTaskStatus.ResetToReplay and cacheTask:IsDialogueSequenceNeedDestroyAfterDialogueFinish() then
		self.loadID = Game.DialogueManagerV2.SequenceManager:PlayDialogueSequence(playParams, true)
	else
		self.loadID = Game.DialogueManagerV2.SequenceManager:PlayDialogueSequence(playParams)
	end

    self.dialogueInstance:SetBlackBoardValue(DialogueConst.BlackBoardKey.SEQUENCE_PLAY_ID, self.loadID)
    self.currentStartPlayTime = Game.GameTimeMS
    Log.DebugFormat("[DS_DialogueSequenceCut] DialogueSequence OnStart StartFrameCount: %s GameTime: %s loadHandleID: %s havePreLoad: %s AssetID: %s", import("KismetSystemLibrary").GetFrameCount(), Game.GameTimeMS, self.loadID, havePreLoad, sequenceID)
end

function DS_DialogueSequenceCut:OnCameraCutCallBack(CameraCompID)
	Log.DebugFormat("[DS_DialogueSequenceCut] DialogueSequence OnCameraCutCallBack FrameCount: %s CameraCompID: %s", import("KismetSystemLibrary").GetFrameCount(),  CameraCompID)
	--self.CameraCutTimer = self:AddTimer(0.2, 1, "OnDelayGetCameraInfo", CameraCompID)
end


function DS_DialogueSequenceCut:OnSequenceFinish()
	self.bHaveFinished = true
	self.dialogueInstance:RemoveDialogueBarrier(self.sequenceBarrier)
	self.sequenceBarrier = nil
	Log.InfoFormat("[DialogueV2][DS_DialogueSequenceCut] DialogueSequence OnSequenceFinish FrameCount: %s GameTime: %s loadHandleID: %s", import("KismetSystemLibrary").GetFrameCount(),  Game.GameTimeMS, self.loadID)
    local nextCameraID = self.nextCameraID
    if nextCameraID then
        -- 设置相机是为了防止sequence切对话相机穿帮
        if self.bKeepTransform then
            local pov = self.dialogueInstance:GetBlackBoardValue(DialogueConst.BlackBoardKey.POV_INFO)
            LuaScriptAPI.KAPI_Actor_SetLocation_P(nextCameraID, pov.x, pov.y, pov.z)
            LuaScriptAPI.KAPI_Actor_SetRotation_P(nextCameraID, pov.pitch, pov.yaw, pov.roll)
            Game.CameraManager:KAPI_Camera_DialogueCamera_SetCameraFOV(nextCameraID, pov.fov)
            Game.CameraManager:KAPI_Camera_DialogueCamera_SetAspectRatio(nextCameraID, pov.aspectRatio)
            Game.CameraManager:KAPI_Camera_DialogueCamera_SetConstraintAspectRatio(nextCameraID, pov.bConstrainAspectRatio)
        end
        Game.CameraManager:SetDialogueCameraWithCustomBlend(self.nextCameraID, 0.01)
        Log.DebugFormat("[DialogueV2][DS_DialogueSequenceCut] DialogueSequence SetDialogueCameraWithCustomBlend  nextCameraID: %s", self.nextCameraID)
    end
    
    -- 因为对话的Tick时机是早于sequence的，当sequence Finish回调回来的时候对话已经完成了Tick，只
    -- 能等到下一帧处理，这就造成了穿帮，所以这里尝试结束，保证sequence结束的时候能在同一帧结束对话
    self.dialogueInstance:TryFinishOnSequenceFinished()
	Game.DialogueManagerV2.UIProcessor:onShowReviewBtn()
end

function DS_DialogueSequenceCut:OnSeqStartPlay()
    Log.DebugFormat("[DS_DialogueSequenceCut] DialogueSequence OnSequenceStartPlay FrameCount: %s GameTime: %s loadHandleID: %s",
        import("KismetSystemLibrary").GetFrameCount(), Game.GameTimeMS, self.loadID)
	Game.DialogueManagerV2.UIProcessor:onHideReviewBtn()
end


function DS_DialogueSequenceCut:OnDelayGetCameraInfo(CameraCompID)
	local bSuccess, x, y, z, pitch, yaw, roll, fov = import("UIFunctionLibrary").GetSequenceCameraPovInfo(Game.WorldContext)
	if bSuccess then
		self.dialogueInstance:SetBlackBoardValue(DialogueConst.BlackBoardKey.POV_INFO, {
			x = x,
			y = y,
			z = z,
			pitch = pitch,
			yaw = yaw,
			roll = roll,
			fov = fov,
			aspectRatio = aspectRatio,
			bConstraintAspectRatio = bConstraintAspectRatio
		})
	end
	Log.DebugFormat("[DS_DialogueSequenceCut] DialogueSequence OnCameraCutCallBack x: %s, y: %s z: %s pitch: %s yaw: %s roll: %s fov: %s", x, y, z, pitch, yaw, roll, fov)
	self:StopDelayCameraTimer()
end

function DS_DialogueSequenceCut:StopDelayCameraTimer()
	if self.CameraCutTimer then
		self:DelTimer(self.CameraCutTimer)
	end
	self.CameraCutTimer = nil
end


---@param finishReason DialogueSectionFinishReason
function DS_DialogueSequenceCut:OnFinish(finishReason)
	if finishReason == DialogueConst.SECTION_FINISH_REASON.SKIP or finishReason == DialogueConst.SECTION_FINISH_REASON.TERMINATE then
		Game.DialogueManagerV2.SequenceManager:StopLevelSequence(self.loadID)
		Log.Debug("[DialogueV2][DS_DialogueSequenceCut]stop level sequence by skip")
		self.loadID = 0
	elseif finishReason == DialogueConst.SECTION_FINISH_REASON.LIFE_END then
		if self.sectionConfig.bUseSectionDuration then
			Game.DialogueManagerV2.SequenceManager:StopLevelSequence(self.loadID)
			Log.Debug("[DialogueV2][DS_DialogueSequenceCut]stop level sequence by line end")
			self.loadID = 0
		end
	end

    if self.currentStartPlayTime ~= 0 then
        Log.DebugFormat("[DialogueV2][DS_DialogueSequenceCut] DialogueSequence TotalPlayTime FrameCount: %s GameTime: %s Section Start To Finish Time: %s loadHandleID: %s",
            import("KismetSystemLibrary").GetFrameCount(), Game.GameTimeMS, (Game.GameTimeMS - self.currentStartPlayTime) / 1000, self.loadID)
        self.currentStartPlayTime = 0
    end
	self.dialogueInstance:SetAllParticipantsVisibility(true, DialogueConst.PARTICIPANT_HIDE_SOURCE.DIALOGUE_SEQUENCE)
end

---@param bSkip boolean
function DS_DialogueSequenceCut:NeedFinish(bSkip)
	local isDone = DialogueSectionBase.NeedFinish(self)
    if bSkip and isDone then
        return true
    end
	if self.sectionConfig.bUseSectionDuration then
		if isDone then
			Game.DialogueManagerV2.SequenceManager:StopLevelSequence(self.loadID)
			self.loadID = 0
		end
		return isDone
	end
	if isDone and not self.bHaveFinished and not self.sequenceBarrier then
            Log.DebugFormat("[DialogueV2][DS_DialogueSequenceCut] DialogueSequence NeedFinish running time:%s", self.runningTime)
		self.sequenceBarrier = self.dialogueInstance:AddDialogueBarrier(DialogueConst.BARRIER_TYPE.SEQUENCE, nil, self.sectionConfig)
	end
    
	return self.bHaveFinished
end

function DS_DialogueSequenceCut:OnTick(deltaTime)
    local bSuccess, x, y, z, pitch, yaw, roll, fov, aspectRatio, bConstraintAspectRatio = import("UIFunctionLibrary").GetSequenceCameraPovInfo(Game.WorldContext)
    if bSuccess then
        local blackboardPOV = self.dialogueInstance:GetBlackBoardValue(DialogueConst.BlackBoardKey.POV_INFO)
        if not blackboardPOV then
            self.dialogueInstance:SetBlackBoardValue(DialogueConst.BlackBoardKey.POV_INFO, {
                x = x,
                y = y,
                z = z,
                pitch = pitch,
                yaw = yaw,
                roll = roll,
                fov = fov,
                aspectRatio = aspectRatio,
                bConstrainAspectRatio = bConstraintAspectRatio
            })
        else
            blackboardPOV.x = x
            blackboardPOV.y = y
            blackboardPOV.z = z
            blackboardPOV.pitch = pitch
            blackboardPOV.yaw = yaw
            blackboardPOV.roll = roll
            blackboardPOV.fov = fov
            blackboardPOV.aspectRatio = aspectRatio
            blackboardPOV.bConstrainAspectRatio = bConstraintAspectRatio
        end
    end
end
