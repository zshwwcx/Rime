---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/29 16:18
---
local WLL = import("WidgetLayoutLibrary")
local Utils = kg_require("Shared.Utils")
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_AspectRatio : DialogueSectionBase
---@field private sectionConfig BPS_FrameRadio_C
DS_AspectRatio = DefineClass("DS_AspectRatio", DialogueSectionBase)

function DS_AspectRatio:OnInit()
    self.screenX = 0
    self.screenY = 0
    self.bVerticalOrHorizontal = nil
end

function DS_AspectRatio:OnStart()
    local viewportSize = WLL.GetViewportSize(Game.WorldContext)
    self.screenX = viewportSize.X
    self.screenY = viewportSize.Y

    local width = self.screenX
    local height = self.screenY
    local newWidth = self.sectionConfig.Width
    local newHeight = self.sectionConfig.Height
    local scaleX = width / newWidth
    local scaleY = height / newHeight

    local bTransition = self.sectionConfig.Btransition
    local color
    if type(self.sectionConfig.Color) == 'userdata' then
        -- ksbc下二进制数据无法直接传给UFUNCTION
        color = Utils.deepCopyTable(self.sectionConfig.Color)
    else
        color = self.sectionConfig.Color
    end

    local blackboardKey = DialogueConst.BlackBoardKey.ASPECT_RATIO_CROSS_EPISODES
    local kind = self.sectionConfig.Kind
    local aspectRatioCrossEpisodes = self.dialogueInstance:GetBlackBoardValue(blackboardKey)
    if aspectRatioCrossEpisodes then
        if aspectRatioCrossEpisodes.Kind == kind then
            -- 相同类型的画幅比，取消入场动画
            bTransition = false
        else
            Game.NewUIManager:ClosePanel(aspectRatioCrossEpisodes.UINameOpened)
            self.dialogueInstance:SetBlackBoardValue(blackboardKey, nil)
        end
    end

    
    if kind == Enum.EMovieFrameRadio.CIRCLE then
        self.UINameOpened = UIPanelConfig.DialogueCircleBg_Panel
        Game.NewUIManager:OpenPanelWithTargetUI(UIPanelConfig.DialogueCircleBg_Panel, UIPanelConfig.Dialogue_Panel, kind, bTransition, color, width, height, self.sectionConfig.Scale)
    else
        local panelName
        if scaleX > scaleY then
            panelName = UIPanelConfig.DialogueVerticalBg_Panel
            self.bVerticalOrHorizontal = true
        else
            panelName = UIPanelConfig.DialogueHorizontalBg_Panel
            self.bVerticalOrHorizontal = false
        end

        self.UINameOpened =panelName
        Game.NewUIManager:OpenPanelWithTargetUI(panelName, UIPanelConfig.Dialogue_Panel, kind, bTransition, color, newWidth, newHeight)
    end
    
    self.bClearAtEnd = true
    if self.sectionConfig.bClearAtEnd ~= nil then
        self.bClearAtEnd = self.sectionConfig.bClearAtEnd
    end

    if not self.bClearAtEnd then
        -- 跨小段的画幅比section，需要记录到黑板上，在下一个非跨小段的画幅比section上清除，或在对话结束时清楚
        local aspectRatio = {
            Kind = self.sectionConfig.Kind,
            bTransition = self.sectionConfig.Btransition,
            Color = color,
            Width = width,
            Height = height,
            Scale = self.sectionConfig.Scale,
            bClearAtEnd = self.bClearAtEnd,
            UINameOpened = self.UINameOpened
        }
        
        self.dialogueInstance:SetBlackBoardValue(blackboardKey, aspectRatio)
    end
end

function DS_AspectRatio:OnFinish(finishReason)
    if not self.bClearAtEnd then
        return
    end
    
    local blackboardKey = DialogueConst.BlackBoardKey.ASPECT_RATIO_CROSS_EPISODES
    local aspectRatioCrossEpisodes = self.dialogueInstance:GetBlackBoardValue(blackboardKey)
    if aspectRatioCrossEpisodes then
        self.dialogueInstance:SetBlackBoardValue(blackboardKey, nil)
    end
    
    Game.GlobalEventSystem:Publish(EEventTypesV2.CLOSE_DIALOGUE_BG_PANEL)
    if self.UINameOpened then
        Game.NewUIManager:ClosePanel(self.UINameOpened)
    end
    self:unConstrainCurrentCamera()
end

---@private
function DS_AspectRatio:constrainCurrentCamera()
    -- todo@zhaojunjie:设置参数,获取ViewTarget
end

---@private
function DS_AspectRatio:unConstrainCurrentCamera()
    -- todo@zhaojunjie:设置参数,获取ViewTarget
end
