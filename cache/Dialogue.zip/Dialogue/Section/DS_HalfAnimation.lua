local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_HalfAnimation : DialogueSectionBase
---@field private sectionConfig BPS_HalfAnimation_C
---@field private AnimUniqueID number
---@field private BlendTypeEnum table
DS_HalfAnimation = DefineClass("DS_HalfAnimation", DialogueSectionBase)

local ViewAnimConst = kg_require("Gameplay.CommonDefines.ViewAnimConst")

function DS_HalfAnimation:OnInit()
    self.BlendTypeEnum = {
        [0] = ViewAnimConst.EUpperAnimationBlendType.UpperBodyBlend,
        [1] = ViewAnimConst.EUpperAnimationBlendType.UpperLimbBodyBlend,
        [2] = ViewAnimConst.EUpperAnimationBlendType.HeadBlend
    }
    self.AnimUniqueID = nil
end

function DS_HalfAnimation:OnStart()
	if not self.sectionConfig then
		Log.WarningFormat("[DialogueV2][DS_HalfAnimation] sectionConfig is nil in dialogue: %s", self.DialogueID)
		return false
	end
    local sectionData = self.sectionConfig
    local animLibAssetID = sectionData.AnimLibItem.AssetID
    local stateName = sectionData.AnimLibItem.StateName or ""

    Log.DebugFormat("[DialogueV2][DS_HalfAnimation] Start anim :%s  state:%s ",  animLibAssetID, stateName)

    if not animLibAssetID or animLibAssetID == "" then
		Log.WarningFormat("[DialogueV2][DS_HalfAnimation] half animation section has no animation setting in dialogue: %s!", self.DialogueID)
		return false
    end

    local blendInTime = sectionData.BlendTime or 0.8
    local blendOutTime = sectionData.BlendOutTime or DialogueConst.AnimDefaultBlendOut

    local bActionMeshSpaceBlend = true
    if sectionData.bRotateAffectedByDownBody then
        bActionMeshSpaceBlend = false
    end

    local blendType = self.BlendTypeEnum[sectionData.BlendType] or
            ViewAnimConst.EUpperAnimationBlendType.UpperBodyBlend

    local entity = self.trackPtpEntity
    if entity and not entity.isDestroyed then
        self.AnimUniqueID = entity:PlayAnimLibMontageForUpper(animLibAssetID, stateName, nil,
            blendInTime, blendOutTime, blendType, bActionMeshSpaceBlend, true)
        Log.DebugFormat("[DialogueV2][DS_HalfAnimation] Start anim :%s  state:%s  uniqueID:%s", animLibAssetID, stateName,
            self.AnimUniqueID)
	else
		Log.WarningFormat("[DialogueV2][DS_HalfAnimation] trackPtpEntity is nil or destroyed in dialogue: %s", self.DialogueID)
	end
end

function DS_HalfAnimation:OnFinish(finishReason)
    local entity = self.trackPtpEntity
    local animUniqueID = self.AnimUniqueID
    if animUniqueID and entity and not entity.isDestroyed then
        entity:StopAnimLibMontageForUpper(animUniqueID, DialogueConst.AnimDefaultBlendOut)
		Log.DebugFormat("[DialogueV2][DS_HalfAnimation] Stop anim with uniqueID:%s in dialogue: %s",
			animUniqueID, self.DialogueID)
    end
end
