---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/28 16:07
---
local KSL = import("KismetSystemLibrary")
local ECameraViewBlendFunction = import("ECameraViewBlendFunction")
local ECameraEaseFunction = import("ECameraEaseFunction")
local DialogueUtilV2 = kg_require("Gameplay.DialogueV2.DialogueUtilV2").DialogueUtilV2

local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase
local M3D = kg_require("Framework.Library.Math3D")

---@class DS_DialogueShotOld : DialogueSectionBase
---@field private sectionConfig BPS_CameraCut_C
DS_DialogueShotOld = DefineClass("DS_DialogueShotOld", DialogueSectionBase)

function DS_DialogueShotOld:OnInit()
    self.rotateTargetLoc = nil

	self.__HeadSocketName__ = "head"
	self.__BipHeadSocketName__ = "Bip001-Head"
end

function DS_DialogueShotOld:OnStart()
	if not self.sectionConfig then
		Log.DebugWarningFormat("[DialogueV2][DS_DialogueShotOld] sectionConfig is nil in dialogue: %s", self.DialogueID)
		return false
	end
	if not self.ptpManager then
		Log.DebugWarningFormat("[DialogueV2][DS_DialogueShotOld] ptpManager is nil in dialogue: %s", self.DialogueID)
		return false
	end
    local targetCameraEntity = self.ptpManager:GetParticipantEntityByName(self.sectionConfig.TargetCamera)
    if not targetCameraEntity then
		Log.DebugWarningFormat("[DialogueV2][DS_DialogueShotOld] get target camera entity %s failed in dialogue: %s", self.sectionConfig.TargetCamera, self.DialogueID)
		return false
    end

    self:tryResetCameraTransform(targetCameraEntity)
    local targetActorDistance = self:tryGetFocusActorDistance(targetCameraEntity)

    -- todo:对话本身有Blend时,第一个Section的逻辑

    local targetCameraID = targetCameraEntity.CharacterID
    local easeType = ECameraEaseFunction.Linear
    local blendType = ECameraViewBlendFunction.Linear

    if not self.sectionConfig.ImmediateCut then
        Game.CameraManager:SetDialogueCameraWithCustomBlend(targetCameraID, self.sectionConfig.Duration, easeType, blendType)
    else
        Game.CameraManager:SetDialogueCameraWithCustomBlend(targetCameraID, 0, easeType, blendType)
    end

    if targetActorDistance then
        Game.CameraManager:KAPI_Camera_DialogueCamera_SetCameraDOFDistance(targetCameraEntity.CharacterID, targetActorDistance)
    end

    if self.sectionConfig.CameraBreathType ~= DialogueConst.CameraBreathType.NONE then
        self:preDealBreath(targetCameraEntity)
    end
	Log.DebugFormat("[DialogueV2][DS_DialogueShotOld] OnStart success for camera %s in dialogue: %s",
		self.sectionConfig.TargetCamera, self.DialogueID)
end

--DS_DialogueShotOld.__UpVector__ = FVector(0, 0, 1)
--DS_DialogueShotOld.__DownVector__ = FVector(0, 0, -1)

function DS_DialogueShotOld:OnTick(deltaTime, bSkip)
	if not self.sectionConfig then
		Log.DebugWarningFormat("[DialogueV2][DS_DialogueShotOld] sectionConfig is nil in dialogue: %s", self.DialogueID)
		return false
	end
	if not self.ptpManager then
		Log.DebugWarningFormat("[DialogueV2][DS_DialogueShotOld] ptpManager is nil in dialogue: %s", self.DialogueID)
		return false
	end
    local targetCameraEntity = self.ptpManager:GetParticipantEntityByName(self.sectionConfig.TargetCamera)
    if not targetCameraEntity then
		Log.DebugWarningFormat("[DialogueV2][DS_DialogueShotOld] get target camera entity %s failed in dialogue: %s", self.sectionConfig.TargetCamera, self.DialogueID)
		return false
    end

    if self.sectionConfig.CameraBreathType == DialogueConst.CameraBreathType.NONE then
        return
    end

    if self.totalRunningTime < self.sectionConfig.BreathDelay then
        return
    end

    local duration = self.sectionConfig.Duration

    -- Section实际运行时长大于duration,不再执行
    if self.totalRunningTime > duration then
        return
    end

    --local rootCompID = targetCameraEntity.CppEntity:KAPI_Actor_GetRootComponent()
    --local rightVector = targetCameraEntity.CppEntity:KAPI_SceneID_GetRightVector(rootCompID)
    --local forwardVector = targetCameraEntity.CppEntity:KAPI_SceneID_GetForwardVector(rootCompID)

    -- 振幅计算缩放比例
    local ratio = deltaTime

    -- 配置了衰减,从BreathAttenuation开始衰减
    if self.sectionConfig.BreathAttenuation > 0 then
        local leftTime = duration - self.totalRunningTime
        leftTime = leftTime > 0 and leftTime or 0
        if leftTime < self.sectionConfig.BreathAttenuation then
            ratio = ratio * (leftTime / self.sectionConfig.BreathAttenuation)
        end
    end

    local rotateTargetLoc = self.rotateTargetLoc
    local rotateTargetX = rotateTargetLoc and rotateTargetLoc.X or 0
    local rotateTargetY = rotateTargetLoc and rotateTargetLoc.Y or 0
    local rotateTargetZ = rotateTargetLoc and rotateTargetLoc.Z or 0

    targetCameraEntity.CppEntity:KAPI_Dialogue_CameraBreath(
            ratio,
            self.sectionConfig.BreathSpeed,
            self.sectionConfig.BreathFocusDistance,
            self.sectionConfig.CameraBreathType,
            rotateTargetX, rotateTargetY, rotateTargetZ)

    --local EBreathType = DialogueConst.CameraBreathType
    --local breathSpeed = self.sectionConfig.BreathSpeed
    --local breathType = self.sectionConfig.CameraBreathType
    --if (EBreathType.LEFT <= breathType) and (breathType <= EBreathType.BACK) then
    --    local moveVector = nil
    --    if breathType == EBreathType.LEFT then
    --        moveVector = rightVector * -1
    --    elseif breathType == EBreathType.RIGHT then
    --        moveVector = rightVector
    --    elseif breathType == EBreathType.TOP then
    --        moveVector = self.__UpVector__
    --    elseif breathType == EBreathType.BOTTOM then
    --        moveVector = self.__DownVector__
    --    elseif breathType == EBreathType.FRONT then
    --        moveVector = forwardVector
    --    elseif breathType == EBreathType.BACK then
    --        moveVector = forwardVector * -1
    --    end
    --
    --    local newLoc = targetCameraEntity:GetPosition() + moveVector * breathSpeed * ratio
    --    targetCameraEntity:SetPosition(newLoc)
    --
    --elseif (breathType == EBreathType.ROTATE_LEFT) or (breathType == EBreathType.ROTATE_RIGHT) then
    --    breathSpeed = breathType == EBreathType.ROTATE_LEFT and breathSpeed or (breathSpeed * -1)
    --    local newDir = KML.RotateAngleAxis(forwardVector, breathSpeed * ratio, self.__UpVector__)
    --    local newLoc = self.rotateTargetLoc - newDir * self.sectionConfig.BreathFocusDistance
    --    local newRot = KML.FindLookAtRotation(newLoc, self.rotateTargetLoc)
    --    targetCameraEntity:SetPosition(newLoc)
    --    targetCameraEntity:SetRotation(newRot)
    --
    --elseif (breathType == EBreathType.ROTATE_TOP) or (breathType == EBreathType.ROTATE_BOTTOM) then
    --    breathSpeed = breathType == EBreathType.ROTATE_TOP and breathSpeed or (breathSpeed * -1)
    --    local newDir = KML.RotateAngleAxis(forwardVector, breathSpeed * ratio, rightVector)
    --    local newLoc = self.rotateTargetLoc - newDir * self.sectionConfig.BreathFocusDistance
    --    local newRot = KML.FindLookAtRotation(newLoc, self.rotateTargetLoc)
    --    targetCameraEntity:SetPosition(newLoc)
    --    targetCameraEntity:SetRotation(newRot)
    --end
end

---分镜开始时,尝试根据当前对话状态(主要是演员的位置)重新设置
---@private
function DS_DialogueShotOld:tryResetCameraTransform(targetCameraEntity)
	if not self.sectionConfig then
		Log.DebugWarningFormat("[DialogueV2][DS_DialogueShotOld] sectionConfig is nil in dialogue: %s", self.DialogueID)
		return false
	end
	
    local cameraConfig = targetCameraEntity.ptpConfig

    local curViewTarget = Game.CameraManager.PlayerController:GetViewTarget()
    local curViewTargetID = Game.ObjectActorManager:GetIDByObject(curViewTarget)
    if curViewTargetID == targetCameraEntity.CharacterID then
		Log.Debug("[DialogueV2][DS_DialogueShotOld][tryResetCameraTransform] same view target, will not reset")
		return
    end

    local parentEntity = self.ptpManager:GetParticipantEntityByName(cameraConfig.Parent)
    if not parentEntity then
		Log.DebugWarningFormat("[DialogueV2][DS_DialogueShotOld] get %s parent entity %s failed in dialogue: %s", self.sectionConfig.TargetCamera, cameraConfig.Parent, self.DialogueID)
		return false
    end

    local parent_x, parent_y, parent_z, parent_rx, parent_ry, parent_rz, parent_rw, parent_sx, parent_sy, parent_sz = parentEntity:GetTransform_P()
    local spawn_x, spawn_y, spawn_z, spawn_rx, spawn_ry, spawn_rz, spawn_rw, spawn_sx, spawn_sy, spawn_sz = DialogueUtilV2.UnpackDialogueTransform(cameraConfig.SpawnTransform)
    local x, y, z, pitch, yaw, roll, sx, sy, sz = M3D.MultiplyTransform_P_EulerAngle(
            spawn_x, spawn_y, spawn_z, parent_rx, parent_ry, parent_rz, parent_rw, spawn_sx, spawn_sy, spawn_sz,
            parent_x, parent_y, parent_z, spawn_rx, spawn_ry, spawn_rz, spawn_rw, parent_sx, parent_sy, parent_sz
    )

    if cameraConfig.bEnableLookAt then
        local targetEntity = self.ptpManager:GetParticipantEntityByName(cameraConfig.LookAtTarget)
        if targetEntity then
            local mainMeshID = targetEntity.CppEntity:KAPI_Actor_GetMainMesh()
            local boneIndex = targetEntity.CppEntity:KAPI_SkeletalMeshID_GetBoneIndex(mainMeshID, cameraConfig.BoneName)
            if boneIndex ~= -1 then
                local boneLoc = targetEntity.CppEntity:KAPI_SkeletalMeshID_GetBoneLocation(mainMeshID, cameraConfig.BoneName, 0)
                z = boneLoc.Z + cameraConfig.OffsetZ
            end
        end
    end

    targetCameraEntity:SetTransform_P_EulerAngle(x, y, z, pitch, yaw, roll, sx, sy, sz)
    Log.DebugFormat("[DialogueV2][DS_DialogueShotOld][tryResetCameraTransform] %s transform reset in dialogue: %s, X:%s,Y:%s,Z:%s,Pitch:%s,Yaw:%s,Roll:%s,ScaleX:%s,ScaleY:%s,ScaleZ:%s",
            self.sectionConfig.TargetCamera, self.DialogueID, x, y, z, pitch, yaw, roll, sx, sy, sz)
end

---获取相机到注视目标的距离
---@private
---@return number|nil
---@param targetCameraEntity DialogueCamera
function DS_DialogueShotOld:tryGetFocusActorDistance(targetCameraEntity)
    local focusPtpName = targetCameraEntity.ptpConfig.DepthOfFieldFocusActor
    if string.isEmpty(focusPtpName) then
        return targetCameraEntity.ptpConfig.DepthOfFieldFocalDistance
    end

    local focusEntity = self.ptpManager:GetParticipantEntityByName(focusPtpName)
    if not focusEntity then
		Log.DebugWarningFormat("[DialogueV2][DS_DialogueShotOld] get focus actor %s failed in dialogue: %s", focusPtpName, self.DialogueID)
		return false
    end
	
	return targetCameraEntity:GetFocusActorDistance(focusEntity)
end

DS_DialogueShotOld.__DrawDebugColor__ = FLinearColor(255, 0, 0)

---预处理镜头呼吸相关
---@private
function DS_DialogueShotOld:preDealBreath(targetCameraEntity)
	if not self.sectionConfig then
		Log.DebugWarningFormat("[DialogueV2][DS_DialogueShotOld] sectionConfig is nil in dialogue: %s", self.DialogueID)
		return false
	end
    local breathType = self.sectionConfig.CameraBreathType
    if (breathType == DialogueConst.CameraBreathType.ROTATE_LEFT) or
            (breathType == DialogueConst.CameraBreathType.ROTATE_RIGHT) or
            (breathType == DialogueConst.CameraBreathType.ROTATE_TOP) or
            (breathType == DialogueConst.CameraBreathType.ROTATE_BOTTOM)
    then
        local rootCompID = targetCameraEntity.CppEntity:KAPI_Actor_GetRootComponent()
        local forwardVector = targetCameraEntity.CppEntity:KAPI_SceneID_GetForwardVector(rootCompID)
        self.rotateTargetLoc = targetCameraEntity:GetPosition() + forwardVector * self.sectionConfig.BreathFocusDistance

        -- 编辑态绘制
        if _G.StoryEditor then
            KSL.DrawDebugSphere(Game.WorldContext, self.rotateTargetLoc, 0.01, 1, self.__DrawDebugColor__, self.sectionConfig.Duration, 1)
        end
    end
end
