---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/27 18:30
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase
local PostProcessConst = kg_require("Gameplay.Effect.PostProcessConst")

local PP_SOURCE_TYPE = PostProcessConst.PP_SOURCE_TYPE
local POST_PROCESS_PRIORITY = PostProcessConst.POST_PROCESS_PRIORITY

local TempFogColorParams = {} -- luacheck: ignore

---@class DS_Fog : DialogueSectionBase
---@field private sectionConfig BPS_Fog_C
DS_Fog = DefineClass("DS_Fog", DialogueSectionBase)

function DS_Fog:OnStart()
	if not self.sectionConfig then
		Log.WarningFormat("[DialogueV2][DS_Fog] sectionConfig is nil in dialogue: %s", self.DialogueID)
		return
	end
	local SectionData = self.sectionConfig

	-- 文案需要一种没有中心点的雾效，也就是说FogCenter可以为空或者“None”，
	-- 找不到Entity以及Participant，默认将CharacterID设为0
	local characterID = 0

	local centerPtpEntity = self.ptpManager:GetParticipantEntityByName(SectionData.FogCenter)
	if centerPtpEntity ~= nil and centerPtpEntity.CharacterID ~= nil then
		characterID = centerPtpEntity.CharacterID
	end
	
	-- 配置的单位是cm，雾效距离参数单位是m，因此这里做个转换
	local realFogDistance = SectionData.Distance / 100

	-- 只设置中心
	if SectionData.UseSceneFogParameter then
		Game.NewPostProcessManager:UpdateFogTargetActor(characterID, PP_SOURCE_TYPE.DIALOGUE)
		return
	end

	-- 检查并处理雾效颜色参数
	local FogColor = SectionData.FogColor
	TempFogColorParams.R = ((FogColor.R + 256) % 256) / 256
	TempFogColorParams.G = ((FogColor.G + 256) % 256) / 256
	TempFogColorParams.B = ((FogColor.B + 256) % 256) / 256
	TempFogColorParams.A = ((FogColor.A + 256) % 256) / 256

	Game.NewPostProcessManager:StartOrUpdateFogParam(
		POST_PROCESS_PRIORITY.DIALOGUE, true, nil, nil,
		not SectionData.OverlayClimate, SectionData.AlphaIn, SectionData.Density,
		realFogDistance, TempFogColorParams, SectionData.SmoothDist ~= nil and SectionData.SmoothDist / 100 or 2,
		PP_SOURCE_TYPE.DIALOGUE)
	
	Game.NewPostProcessManager:UpdateFogTargetActor(characterID, PP_SOURCE_TYPE.DIALOGUE)

	-- 处理后处理屏蔽
	if SectionData.bDisableGamePostProcess then
		self.dialogueInstance:DisableGamePostProcess()
	end
	Log.InfoFormat("[DialogueV2][DS_Fog] Start fog effect with center %s, distance %s, density %s in dialogue: %s",
		SectionData.FogCenter, realFogDistance, SectionData.Density, self.DialogueID)
end

function DS_Fog:OnFinish(finishReason)
	if not self.sectionConfig then
		Log.WarningFormat("[DialogueV2][DS_Fog] sectionConfig is nil in dialogue: %s", self.DialogueID)
		return false
	end
	if not self.sectionConfig.bClearAtEnd then
		self:recordInfoToBlackBoard()
		return
	end
	
	Game.NewPostProcessManager:RemoveFog(self.sectionConfig.AlphaOut, PP_SOURCE_TYPE.DIALOGUE)

	-- 取消后处理屏蔽
	if self.sectionConfig.bDisableGamePostProcess then
		self.dialogueInstance:EnableGamePostProcess()
	end
end

function DS_Fog:recordInfoToBlackBoard()
	if not self.dialogueInstance then
		Log.DebugWarningFormat("[DialogueV2][DS_Fog] dialogueInstance is nil in dialogue: %s", self.DialogueID)
		return false
	end
	self.dialogueInstance:SetBlackBoardValue(DialogueConst.BlackBoardKey.NEED_RESET_FOG, true)
	Log.DebugFormat("[DialogueV2][DS_Fog] recordInfoToBlackBoard in dialogue: %s", self.DialogueID)
end
