---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/27 10:39
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_GlobalLookAt : DialogueSectionBase
---@field private sectionConfig BPS_LookAt_C
DS_GlobalLookAt = DefineClass("DS_GlobalLookAt", DialogueSectionBase)

function DS_GlobalLookAt:OnStart()
	if not self.sectionConfig then
		Log.WarningFormat("[DialogueV2][DS_GlobalLookAt] sectionConfig is nil in dialogue: %s", self.DialogueID)
		return false
	end
	if not self.ptpManager then
		Log.WarningFormat("[DialogueV2][DS_GlobalLookAt] ptpManager is nil in dialogue: %s", self.DialogueID)
		return false
	end
    -- 说话人看向目标
    self.ptpManager:SetEnableTalkerLookAtTarget(self.sectionConfig.TalkerLookAtTarget)

    -- 单独处理每一个LookAt
    local participantMgr = self.ptpManager
    for _, lookAtInfo in ksbcpairs(self.sectionConfig.LookAtInfo) do
        if lookAtInfo.Enable then
            participantMgr:LookAt(lookAtInfo.Looker, lookAtInfo.Target,
                lookAtInfo.Delay, DialogueConst.HEAD_SOCKET_NAME, false)
        end
    end
    
    -- 设置全局的LookAt开关
    self.ptpManager:SetEnableAllPtpLookAtTalker(self.sectionConfig.LookAtTalker)
	Log.DebugFormat("[DialogueV2][DS_GlobalLookAt] OnStart success in dialogue: %s", self.DialogueID)
end
