---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/22 15:56
---
local EMovementMode = import("EMovementMode")
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_PerformerRotate : DialogueSectionBase
DS_PerformerRotate3C = DefineClass("DS_PerformerRotate", DialogueSectionBase)

local DialogueUtilV2 = kg_require("Gameplay.DialogueV2.DialogueUtilV2").DialogueUtilV2
local ShareConst = kg_require("Shared.Const")

local ERotateType = ShareConst.ERotateType
function DS_PerformerRotate3C:OnStart()
    self.duration = self.sectionConfig.Duration
    if self.trackPtpEntity == nil or (self.trackPtpEntity.isDestroyed == true) then
        return
    end
    
    local targetPtpEntity = self.ptpManager:GetParticipantEntityByName(self.sectionConfig.Target)
    if not targetPtpEntity then
        Log.WarningFormat("[DialogueV2][DS_PerformerRotate3C]OnStart failed: cannot find target:%s", self.sectionConfig.Target)
        return
    end
    
    local SafeCall = DialogueUtilV2.SafeCall
    local trackPtpEntity = self.trackPtpEntity
    local trackPtpCppEntity = trackPtpEntity.CppEntity
    -- 不贴地的演员,为了防止坠落修改MovementMode
    if not self.trackPtpEntity:NeedBornStickGround() then
        SafeCall(self, trackPtpCppEntity.KAPI_Movement_SetMovementMode, trackPtpCppEntity, EMovementMode.MOVE_Falling, 0)
    end

    local bUseAnim = true
    if self.sectionConfig.bUseAnim ~= nil then
        bUseAnim = self.sectionConfig.bUseAnim
    end
    
    if bUseAnim then
        local bSuccess, duration = SafeCall(self, trackPtpEntity.GetRotateAnimLength, trackPtpEntity, 
            ERotateType.RotateToEntity, targetPtpEntity:uid())
        if bSuccess and duration then
            self.duration = math.min(duration, self.duration)
        end
    end
    -- todo@chengdong:目前3C移动接3C转身会触发ensure
    if SafeCall(self, trackPtpEntity.EnterRotateToEntity, trackPtpEntity, targetPtpEntity:uid(), self.duration, bUseAnim) then
        Log.DebugFormat(
            "[DialogueV2][DS_PerformerRotate3C]OnStart, use animation rotate entity:%s to target:%s duration:%s bUseAnim:%s in dialogue[%s]",
            self.trackPtp.TrackName, self.sectionConfig.Target, self.duration, bUseAnim, self.DialogueID)
    end
end

function DS_PerformerRotate3C:NeedFinish()
    if self:IsInRunningState(DialogueConst.SECTION_RUNNING_STATE.FINISHED) then
        return false
    end
    
    return (self.bInRunning == true) and (self.runningTime >= self.duration)
end

function DS_PerformerRotate3C:OnFinish(finishReason)
    if finishReason == DialogueConst.SECTION_FINISH_REASON.LIFE_END then
        return
    end

    if self.trackPtpEntity == nil or (self.trackPtpEntity.isDestroyed == true) then
        return
    end

    self.trackPtpEntity:StopAllViewControlRotate(true)
end
