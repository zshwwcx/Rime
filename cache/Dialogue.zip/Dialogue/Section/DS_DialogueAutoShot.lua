---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/28 19:37
---
local ECameraViewBlendFunction = import("ECameraViewBlendFunction")
local ECameraEaseFunction = import("ECameraEaseFunction")
local Utils = kg_require("Shared.Utils")
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_DialogueAutoShot : DialogueSectionBase
DS_DialogueAutoShot = DefineClass("DS_DialogueAutoShot", DialogueSectionBase)

DS_DialogueAutoShot.__UpVector__ = FVector(0, 0, 0)

function DS_DialogueAutoShot:OnInit()
    -- todo:AutoCameraManager里面有修改Section数据的需求,这里需要DeepCopy一下数据
    if type(self.sectionConfig) == 'userdata' then
        self.SectionData = Utils.deepCopyTable(self.sectionConfig)
    else
        self.SectionData = self.sectionConfig
    end

    -- todo:造了一个假的Section
    self.fakeSection = {
        SectionData = self.SectionData,
        FocusActorDisatance = nil,
        DrawActorCenter = nil,
        DrawNpcCenter = nil,
    }
end

function DS_DialogueAutoShot:OnStart()
    local targetCameraEntity = self.ptpManager:GetParticipantEntityByName(self.SectionData.CameraName)
    if not targetCameraEntity then
        return
    end

    self.targetCameraID = self.targetCameraEntity.CharacterID
    local easeType = ECameraEaseFunction.Linear
    local blendType = ECameraViewBlendFunction.Linear

    if not self.SectionData.ImmediateCut then
        Game.CameraManager:SetDialogueCameraWithCustomBlend(self.targetCameraID, self.SectionData.Duration, easeType, blendType)
    else
        Game.CameraManager:SetDialogueCameraWithCustomBlend(self.targetCameraID, 0, easeType, blendType)
    end

    self.dialogueInstance.AutoCameraManager:CalculateCameraParams(self.fakeSection, targetCameraEntity, self.fakeSection.SectionData)

    self:handleCameraParam()
end

function DS_DialogueAutoShot:handleCameraParam()
    local bOpenDOF = self.SectionData.bOpenDOF
    Game.CameraManager:KAPI_Camera_DialogueCamera_SetCameraDOFOverride(self.targetCameraID, bOpenDOF, bOpenDOF, bOpenDOF)

    if self.SectionData.ImmediateCut then
        if bOpenDOF then
            local DepthOfFieldFocalDistance = self.SectionData.DepthOfFieldFocalDistance
            local DepthOfFieldFstop = self.SectionData.DepthOfFieldFStop
            local DepthOfFieldSensorWidth = self.SectionData.DepthOfFieldSensorWidth
            Game.CameraManager:KAPI_Camera_DialogueCamera_SetCameraDOFParams(self.targetCameraID, DepthOfFieldFocalDistance, DepthOfFieldSensorWidth, DepthOfFieldFstop)
        end
    else
        if bOpenDOF then
            self.fakeSection.TargetDepthOfFieldSensorWidth = self.SectionData.DepthOfFieldSensorWidth
            self.fakeSection.TargetDepthOfFieldFStop = self.SectionData.DepthOfFieldFStop
            if self.SectionData.DepthOfFieldFocalDistance > 0 then
                self.fakeSection.TargetDepthOfFieldFocalDistance = self.SectionData.DepthOfFieldFocalDistance
            else
                self.fakeSection.TargetDepthOfFieldFocalDistance = self.fakeSection.FocusActorDisatance
            end
        else
            local ppSettings = Game.CameraManager:KAPI_Camera_GetPPSetting(self.targetCameraID)
            self.fakeSection.TargetDepthOfFieldFocalDistance = ppSettings.DepthOfFieldFocalDistance
            self.fakeSection.TargetDepthOfFieldSensorWidth = ppSettings.DepthOfFieldSensorWidth
            self.fakeSection.TargetDepthOfFieldFStop = ppSettings.DepthOfFieldFstop
        end
    end
end
