---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/27 17:18
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---该Section已废弃,如有疑问请咨询@shijingzhe
---@class DS_PerformerAudio2Face : DialogueSectionBase
DS_PerformerAudio2Face = DefineClass("DS_PerformerAudio2Face", DialogueSectionBase)

function DS_PerformerAudio2Face:OnInit()

end

function DS_PerformerAudio2Face:OnStart()

end

function DS_PerformerAudio2Face:OnTick(deltaTime)

end

function DS_PerformerAudio2Face:OnFinish(finishReason)

end
