---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/22 16:40
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_PerformerStill : DialogueSectionBase
DS_PerformerStill = DefineClass("DS_PerformerStill", DialogueSectionBase)

function DS_PerformerStill:OnStart()
    if self.trackPtpEntity == nil or (self.trackPtpEntity.isDestroyed == true) then
        return
    end

    self.trackPtpEntity:SetGlobalAnimRateScale(self.sectionConfig.Still and 0 or 1)
end
