---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/24 14:41
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_StateControl : DialogueSectionBase
DS_StateControl = DefineClass("DS_StateControl", DialogueSectionBase)

function DS_StateControl:OnStart(bSkip)
	if bSkip then
		return
	end

    -- 自动播放期间不生效
    if Game.DialogueManagerV2:IsAutoPlay() then
        return
    end

	if not self.dialogueInstance then
		Log.ErrorFormat("[DialogueV2][DS_StateControl] dialogueInstance is nil in dialogue: %s", self.DialogueID)
		return false
	end
    self.dialogueInstance:PausePlay()
    Game.DialogueManagerV2.UIProcessor:CallPanelFunction(DialogueConst.PanelFunction.ShowContentSkipArrow)
end

function DS_StateControl:JumpToSpecificTime(specificTime)
	-- 流程控制节点在跳过过程中不需要起效
	self:SetJumped(true)
	return
end
