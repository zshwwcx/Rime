---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/27 16:08
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase
local NiagaraEffectConst = kg_require("Gameplay.Effect.NiagaraEffectConst")
local NIAGARA_ATTACH_COMPONENT_TYPE = NiagaraEffectConst.NIAGARA_ATTACH_COMPONENT_TYPE

---@class DS_PerformerAttachNiagara : DialogueSectionBase
DS_PerformerAttachNiagara = DefineClass("DS_PerformerAttachNiagara", DialogueSectionBase)

function DS_PerformerAttachNiagara:OnInit()
    self.niagaraID = 0
end

function DS_PerformerAttachNiagara:OnStart()
    if not self.trackPtpEntity then
        return
    end

    local sectionData = self.sectionConfig
    local pos = sectionData.Translation
    local rot = sectionData.Rotator
    local scale = sectionData.Scale

    local effectParam = NiagaraEffectParamTemplate.AllocFromPool()
    effectParam.bFollowHidden = sectionData.bFollowHidden
    effectParam.NiagaraEffectPath = sectionData.Niagara
    effectParam.bNeedAttach = true
    effectParam.AttachPointName = sectionData.AttachPoint or ""
    effectParam.NiagaraAttachComponentType = NIAGARA_ATTACH_COMPONENT_TYPE.FIND_ATTACH_COMPONENT_BY_SOCKET_NAME
    effectParam.bAbsoluteRotation = false
    effectParam.bAbsoluteScale = false
    effectParam:FillTransformByRotator(pos, rot, scale)

    self.niagaraID = self.trackPtpEntity:PlayNiagaraEffect(effectParam)

    if sectionData.Audio then
        local arr = string.split(sectionData.Audio, ".")
        self.trackPtpEntity:SetEffectAudio(self.niagaraID, arr[#arr])
    end
end

function DS_PerformerAttachNiagara:OnFinish(finishReason)
    if not self.trackPtpEntity then
        return
    end

    if self.niagaraID ~= 0 then
        self.trackPtpEntity:DestroyNiagaraSystem(self.niagaraID)
        self.niagaraID = 0
    end
end
