---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/8 17:39
---

local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_DialogueContent : DialogueSectionBase
DS_DialogueContent = DefineClass("DS_DialogueContent", DialogueSectionBase)

function DS_DialogueContent:dtor()
    Log.DebugFormat("[DialogueV2]DS_DialogueContent:dtor %s", self)
end

function DS_DialogueContent:OnInit()
    self.voiceEventName = ""
end

function DS_DialogueContent:OnStart(bSkip)
    Log.Debug("[[DialogueV2]DS_DialogueContent:OnStart].")
    Game.GlobalEventSystem:AddListener(EEventTypesV2.ON_DIALOGUE_SKIP_CONTENT, "OnDialogueSkipContent", self)

    ---@type DialogueUIProcessor
    local uiProcessor = Game.DialogueManagerV2.UIProcessor

    local dialogueInstance = self.dialogueInstance

    local sectionConfig = self.sectionConfig
    local dialogueTalkData = Game.TableData.GetDialogueTalkDataRow(tostring(self.DialogueID))
    if not dialogueTalkData then
        Log.WarningFormat("[DialogueV2][DS_DialogueContent:OnStart] get %s dialogue talk data failed", self.DialogueID)
        return
    end

    local episodeTalkData = dialogueTalkData[sectionConfig.EpisodeID]
    if not episodeTalkData then
        Log.WarningFormat("[DialogueV2][DS_DialogueContent:OnStart] %s get episode %s failed", self.DialogueID, sectionConfig.EpisodeID)
        return
    end

    -- 表格中配置的本句台本
    local lineTalkData = episodeTalkData[sectionConfig.ContentIndex]
    if not lineTalkData then
        Log.WarningFormat("[DialogueV2][DS_DialogueContent:OnStart] %s get %s data failed", self.DialogueID, self:GetContentDesc())
        return
    end

    local contentUI = dialogueInstance.bUseCSStyle and DialogueConst.CONTENT_UI_TYPE.CSSTYLE or sectionConfig.ContentUI
    uiProcessor:SetDialogueContentUIType(contentUI)

    -- 获取下一个Talker
    if sectionConfig.ContentIndex == 1 then
        local NextLineTalkData = episodeTalkData[sectionConfig.ContentIndex + 1]
        if NextLineTalkData then
            self.ptpManager:SetCurDialogueNextTalker(NextLineTalkData.Talker)
        else
            -- 可能存在只有一句台本，没有第二句台本的情况，所以这里用DebugFormat
            Log.DebugFormat("[DialogueV2][DS_DialogueContent:OnStart] can not get next line talk data.")
        end
    else
        self.ptpManager:SetCurDialogueNextTalker(nil)
    end

    local talkerPtp = self.ptpManager:GetParticipantByName(lineTalkData.Talker)
    self.ptpManager:SetCurDialogueTalker(lineTalkData.Talker)

    local bIsPlayer = talkerPtp and talkerPtp.ptpConfig.bIsPlayer or false
    local talkerAppearanceID = self.ptpManager:GetPerformerAppearanceID(lineTalkData.Talker)
    local talkerPtpEntity = talkerPtp and talkerPtp:GetDialogueLocalEntity() or nil
    self.ptpManager:SetTalkerEntityID(talkerPtpEntity and talkerPtpEntity:uid() or 0)
    local bSimpleDialogue = dialogueInstance.bSimpleDialogue

    if not self.bJumped then
        self:playContentVoice(talkerPtpEntity)
    end

    if lineTalkData.Talker == "None" then
        Log.WarningFormat("[DialogueV2]nobody is speaking ! can not find Talker %s Asset %s Episode %d Index %d!", talkerPtpEntity, self.DialogueID, sectionConfig.EpisodeID, sectionConfig.ContentIndex)
        return
    end

    if not lineTalkData.bDisableFaceLip then
        self:playVoiceFaceAnim(talkerPtpEntity)
    end

    local bSuccess = uiProcessor:ShowContent(talkerPtpEntity, talkerAppearanceID, bIsPlayer, lineTalkData, 
        bSimpleDialogue, self.sectionConfig, self.voiceEventName, dialogueInstance.bShowTalkerNameInCSStyle)
    if bSuccess then
        -- 取消之前设定的延迟隐藏台本
        local token = dialogueInstance:GetBlackBoardValue(DialogueConst.BlackBoardKey.PENDING_HIDE_LINE)
        if token then
            uiProcessor:CancelDeferCall(token)
            dialogueInstance:SetBlackBoardValue(DialogueConst.BlackBoardKey.PENDING_HIDE_LINE, nil)
        end
    end
end

function DS_DialogueContent:OnFinish(finishReason)
    Log.DebugFormat("[DialogueV2][DS_DialogueContent:OnFinish] finishReason: %s", finishReason)
    Game.GlobalEventSystem:RemoveTargetAllListeners(self)
    if finishReason ~= DialogueConst.SECTION_FINISH_REASON.LIFE_END or self.bJumped then
        -- 非自然结束,掐断音频
        self.ptpManager:StopVoice()
        self.ptpManager:StopVoiceFaceAnim()

        local dialogueInstance = self.dialogueInstance
        if dialogueInstance:CheckAcceptQuest() or dialogueInstance.currentEpisode:GetEpisodeOptions() then
            -- 领取任务或者有选项时需要显示最后一句台本
            self:DeferHideContentUI(0.15)
        else
            -- 非自然结束，直接隐藏UI
            Game.DialogueManagerV2.UIProcessor:CallPanelFunction(DialogueConst.PanelFunction.HideContent)
        end

    else
        self:DeferHideContentUI()
    end

    Log.Debug("[DialogueV2][DS_DialogueContent:OnFinish].")
end

function DS_DialogueContent:OnDialogueSkipContent()
    if self.isDestroyed then
        Log.DebugFormat("[DialogueV2][DS_DialogueContent:OnDialogueSkipContent] DS_DialogueContent is destroyed:%s", self)
        return
    end

    if not self.sectionConfig.CanSkip then
        Log.DebugFormat("[DialogueV2][DS_DialogueContent:OnDialogueSkipContent] Dialogue Content can not skip due to sectionConfig.")
        return
    end

    Log.DebugFormat("[DialogueV2][DS_DialogueContent]OnDialogueSkipContent, do skip dialogue content on section:%s",
        self:ToString())
    local leftTime = self.sectionConfig.Duration - self.runningTime + 0.1
    self.dialogueInstance:SkipPeriodDialogue(leftTime)
end

---获取当前台本描述,哪个对话第几小段第几句
---@public
---@return string
function DS_DialogueContent:GetContentDesc()
    return string.format("%s_%s_%s", self.DialogueID, self.sectionConfig.EpisodeID, self.sectionConfig.ContentIndex)
end

---播放台本语音
---@private
function DS_DialogueContent:playContentVoice(talkerPtpEntity)
    self.voiceEventName = Game.AkAudioManager.cppMgr:GetDialogueVoiceEventName(self.DialogueID or 0, self.sectionConfig.EpisodeID or 0, self.sectionConfig.ContentIndex or 0)
    self.ptpManager:PlayContentVoice(self.DialogueID, self.sectionConfig.EpisodeID, self.sectionConfig.ContentIndex, talkerPtpEntity)
end

-- todo@shijingzhe: 目前方案是直接读取美术生成的口型数据,后续会探索自动方案
---播放口型动画
---@private
---@param talkerEntity DialoguePerformer
function DS_DialogueContent:playVoiceFaceAnim(talkerEntity)
    self.ptpManager:playVoiceFaceAnim(self.DialogueID, self.sectionConfig.EpisodeID, self.sectionConfig.ContentIndex, talkerEntity)
end

function DS_DialogueContent:DeferHideContentUI(delayTime)
    if not delayTime then
        delayTime = 0.1
    end

    Log.DebugFormat("[DialogueV2][DS_DialogueContent]DeferHideContentUI, delayTime:%s on %s", delayTime, self:ToString())
    -- 延迟隐藏台本
    local token = Game.DialogueManagerV2.UIProcessor:DeferCallPanelFunction(delayTime, DialogueConst.PanelFunction.HideContent)
    if token then
        self.dialogueInstance:SetBlackBoardValue(DialogueConst.BlackBoardKey.PENDING_HIDE_LINE, token)
    end
end