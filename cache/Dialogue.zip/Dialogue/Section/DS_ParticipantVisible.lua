---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/22 16:49
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_ParticipantVisible : DialogueSectionBase
---@field sectionConfig BPS_ActorVisible_C
DS_ParticipantVisible = DefineClass("DS_ParticipantVisible", DialogueSectionBase)

function DS_ParticipantVisible:OnStart()
    if not self.trackPtpEntity then
		Log.WarningFormat("[DialogueV2][DS_ParticipantVisible:OnStart] trackPtpEntity %s is nil.", self.trackPtpEntityID)
        return
    end
	
	Log.InfoFormat("[DialogueV2]%s OnStart ptpEntity:%s %s, bVisible:%s", 
        self:ToString(), self.trackPtpEntity.ptpConfig.TrackName, self.trackPtpEntity, self.sectionConfig.Visible)

    if self.sectionConfig.Visible then
        self.trackPtpEntity:DialogueShow(DialogueConst.PARTICIPANT_HIDE_SOURCE.DIALOGUE_LOGIC)
    else
        self.trackPtpEntity:DialogueHide(DialogueConst.PARTICIPANT_HIDE_SOURCE.DIALOGUE_LOGIC)
    end
end
