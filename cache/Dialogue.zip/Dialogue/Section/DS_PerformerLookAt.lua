---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/20 11:36
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_PerformerLookAt : DialogueSectionBase
---@field private sectionConfig BPS_ActorLookAt_C
DS_PerformerLookAt = DefineClass("DS_PerformerLookAt", DialogueSectionBase)

---@type EAlphaBlendOption
local EAlphaBlendOp = import("EAlphaBlendOption")

function DS_PerformerLookAt:OnStart()
    if (self.trackPtpEntity == nil) or (self.trackPtpEntity.isDestroyed == true) then
        Log.DebugWarningFormat("[DialogueV2][DS_PerformerLookAt]OnStart Failed:track participant entity is nil or section is destroyed")
        return
    end

    local targetPtpEntity = self.ptpManager:GetParticipantEntityByName(self.sectionConfig.Target)
    local lookAtSocket = self.sectionConfig.LookAtSocket or DialogueConst.HEAD_SOCKET_NAME
    
    local bRotateUpperBody = true
    if self.sectionConfig.bRotateUpperBody ~= nil then
        bRotateUpperBody = self.sectionConfig.bRotateUpperBody
    end

    local sectionConfig = self.sectionConfig
    local bGazeInstance = false
    if sectionConfig.bImmediately ~= nil then
        bGazeInstance = sectionConfig.bImmediately
    end

    local gazeAlphaBlendOp = EAlphaBlendOp.HermiteCubic
    local lookAtCurve = sectionConfig.LookAtCurve
    if lookAtCurve ~= nil then
        local op = DialogueConst.LOOKAT_CURVE_TO_ALPHA_BLEND_OP[lookAtCurve]
        if op then
            gazeAlphaBlendOp = op
        end
    end

    self.ptpManager:LookAtEntity(self.trackPtpEntity, targetPtpEntity, 0, lookAtSocket, 
        false, bRotateUpperBody, bGazeInstance, gazeAlphaBlendOp)
end
