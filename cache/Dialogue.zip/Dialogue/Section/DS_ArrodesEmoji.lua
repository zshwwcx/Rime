local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_ArrodesEmoji : DialogueSectionBase
---@field public sectionConfig BPS_ArrodesEmoji_C
---@field public texturePathSubEmoji string
DS_ArrodesEmoji = DefineClass("DS_ArrodesEmoji", DialogueSectionBase)


local EMIDCreationFlags = import("EMIDCreationFlags")
local NiagaraEffectConst = kg_require("Gameplay.Effect.NiagaraEffectConst")
local NIAGARA_ATTACH_COMPONENT_TYPE = NiagaraEffectConst.NIAGARA_ATTACH_COMPONENT_TYPE

-- 转换阶段
DS_ArrodesEmoji.ETransitionStage = {
    UnInit = -1,
    None = 0,
    TransitionIn = 1,
    TransitionOut = 3,
}

function DS_ArrodesEmoji:OnInit()
    self.ArrodesMaterialSlotName = "FACE"
    self.ArrodesEmojiAlphaParamName = "Alpha"
    self.ArrodesEmoji0ParamName = "EmotionIndex0"
    self.ArrodesEmoji1ParamName = "EmotionIndex1"
    self.ArrodesEmojiShakeParamName = "ShakeIntensity"

    self.ArrodesEyeMaterialSlotNames = { "Mirror_eye", "Mirror_Eyeball" }
    self.ArrodesEysVisibleParamName = "_DitherAlpha"

    self.CurrentStage = DS_ArrodesEmoji.ETransitionStage.UnInit
    self.DynamicMaterialCache = {}
end

---@param animLibAssetId string
---@param bAutoStop boolean
---@param bStopLasted boolean
---@return number
function DS_ArrodesEmoji:PlayAnim(animLibAssetId, bAutoStop, bStopLasted)
    if not animLibAssetId then
        Log.DebugFormat("DS_ArrodesEmoji:PlayAnim failed: No AnimLibAssetID")
        return
    end

    local trackEntity = self.trackPtpEntity
    if trackEntity == nil or (trackEntity.isDestroyed == true) then
        return
    end

    Log.DebugFormat("DS_ArrodesEmoji:PlayAnim animLibAssetID:%s", animLibAssetId)

    if bStopLasted then
        trackEntity:StopAnimLibMontage()
    end

    -- local _, duration = trackEntity:GetAnimPathAndLenFromAnimFeatureForSingleAnimation(animLibAssetId)
    local _, duration = trackEntity:PlayAnimLibMontage(animLibAssetId, "", nil, 0, DialogueConst.AnimDefaultBlendOut, bAutoStop)
    if duration then
        duration = duration
    end

    return duration or 0.1
end

function DS_ArrodesEmoji:PlayEmoji()
    self:setTransitionStage(DS_ArrodesEmoji.ETransitionStage.TransitionIn)
    self:attachSubEmoji()
    Log.DebugFormat("DS_ArrodesEmoji:PlayEmoji")
end

function DS_ArrodesEmoji:OnStart()
    self.texturePathSubEmoji = DialogueConst.ArrodesSubEmojiTextures[self.sectionConfig.SubEmojiTextureIndex]
    Log.DebugFormat("DS_ArrodesEmoji:OnInit sub emoji texture:%s", self.texturePathSubEmoji)
    if self.sectionConfig.UseCloseEyesAnim then
        self.pendingStartEmoji = self:PlayAnim("Mirror_CloseEyes", false)
        self.durationCloseEyes = self.pendingStartEmoji
    else
        self:PlayEmoji()
        self.durationCloseEyes = 0
    end
end

function DS_ArrodesEmoji:TickStartPlayEmoji(deltaTime)
    local lastTime = self.pendingStartEmoji
    local timeToStartEmoji = lastTime - deltaTime
    self.pendingStartEmoji = timeToStartEmoji
    if lastTime > 0 and timeToStartEmoji <= 0 then
        self:PlayEmoji()
    end
end

function DS_ArrodesEmoji:OnTick(deltaTime)
    if self.pendingStartEmoji and self.pendingStartEmoji > 0 then
        self:TickStartPlayEmoji(deltaTime)
        return
    end

    local sectionCfg = self.sectionConfig
    local curEmojiTime = self.totalRunningTime - self.durationCloseEyes
    local ETransitionStage = self.ETransitionStage
    if sectionCfg.Duration - curEmojiTime < sectionCfg.OutTime then
        if self.CurrentStage ~= ETransitionStage.TransitionOut then
            self:setTransitionStage(ETransitionStage.TransitionOut)
        end

        if sectionCfg.UseOpenEyesAnim then
            local last = self.timeToPlayOpenEyes
            local time = self.timeToPlayOpenEyes - deltaTime
            if last > 0 and time <= 0 then
                self:PlayAnim("Mirror_OpenEyes", true, true)
            end
            self.timeToPlayOpenEyes = time
        end

        if sectionCfg.OutTime > 0 then
            self:updateAlpha(1 - math.min((sectionCfg.Duration - curEmojiTime) / sectionCfg.OutTime, 1))
        else
            self:updateAlpha(1)
        end
    elseif curEmojiTime < sectionCfg.InTime then
        if self.CurrentStage ~= ETransitionStage.TransitionIn then
            self:setTransitionStage(ETransitionStage.TransitionIn)
        end

        if sectionCfg.InTime > 0 then
            self:updateAlpha(math.min(curEmojiTime / sectionCfg.InTime, 1))
        else
            self:updateAlpha(1)
        end
    else
        if self.CurrentStage ~= ETransitionStage.None then
            self:setTransitionStage(ETransitionStage.None)
            self:updateAlpha(1)
        end
    end
end

function DS_ArrodesEmoji:OnFinish(finishReason)
    local dynamicMaterial = self:getMaterial(self.ArrodesMaterialSlotName)
    if dynamicMaterial ~= 0 then
        if self.CurrentStage ~= self.ETransitionStage.TransitionOut then
            self:setTransitionStage(self.ETransitionStage.TransitionOut)
        end
        self:updateAlpha(1)
    end

    local trackEntity = self.trackPtpEntity
    if self.effectIdSubEmoji then
        if trackEntity then
            trackEntity:DestroyNiagaraSystem(self.effectIdSubEmoji)
        end
        
        self.effectIdSubEmoji = nil
    end

    if self.effectIdSubOutEmoji then
        if trackEntity then
            trackEntity:DestroyNiagaraSystem(self.effectIdSubOutEmoji)
        end
        self.effectIdSubOutEmoji = nil
    end
end

---@private
function DS_ArrodesEmoji:updateAlpha(alpha)
    local dynamicMaterial = self:getMaterial(self.ArrodesMaterialSlotName)
    if dynamicMaterial then
        LuaScriptAPI.SetDynamicMaterialScalarParameterValue(dynamicMaterial,
            self.ArrodesEmojiAlphaParamName, alpha)
    end
end

---@private
---@param stage DS_ArrodesEmoji.ETransitionStage
function DS_ArrodesEmoji:setTransitionStage(stage)
    self.CurrentStage = stage

    local sectionCfg = self.sectionConfig
    if stage == self.ETransitionStage.TransitionIn then
        self:enterTransitionStage(0, sectionCfg.InEmoji, sectionCfg.MainEmoji, sectionCfg.bInShake and 1 or 0, true, sectionCfg.InTime, 0, 1)
    elseif stage == self.ETransitionStage.TransitionOut then
        self:enterTransitionStage(0, sectionCfg.MainEmoji, sectionCfg.OutEmoji, 0, true, sectionCfg.OutTime, 1, 0)

        if self.effectIdSubEmoji then
            if self.trackPtpEntity then
                self.trackPtpEntity:DeactivateNiagaraSystem(self.effectIdSubEmoji, true, 0.01)
            end
        end
        self:attachSubOutEmoji()
        self.timeToPlayOpenEyes = sectionCfg.OutTime * 0.6
    else
        self:enterTransitionStage(0, sectionCfg.MainEmoji, sectionCfg.MainEmoji, 0, false)
    end
end

---@param emojiAlpha number
---@param emojiParam0 number
---@param emojiParam1 number
---@param emojiShake number @ 1 or 0
---@param hasTransition boolean
---@param transitionTime number
function DS_ArrodesEmoji:enterTransitionStage(emojiAlpha, emojiParam0, emojiParam1, emojiShake, hasTransition, transitionTime, startEyeAlpha, endEyeAlpha)
    if not self.trackPtpEntity then
        return
    end

    local dynamicMaterial = self:getMaterial(self.ArrodesMaterialSlotName)

    local SetScalarParameterValue = LuaScriptAPI.SetDynamicMaterialScalarParameterValue
    local materialMgr = Game.MaterialManager

    if dynamicMaterial ~= 0 then 
        SetScalarParameterValue(dynamicMaterial, self.ArrodesEmojiAlphaParamName, emojiAlpha)
        SetScalarParameterValue(dynamicMaterial, self.ArrodesEmoji0ParamName, emojiParam0)
        SetScalarParameterValue(dynamicMaterial, self.ArrodesEmoji1ParamName, emojiParam1)
        SetScalarParameterValue(dynamicMaterial, self.ArrodesEmojiShakeParamName, emojiShake)
    end

    if hasTransition then
        local transTime = 0.033
        if transitionTime and transitionTime > 0 then
            transTime = transitionTime
        end

        for _, slotName in pairs(self.ArrodesEyeMaterialSlotNames) do
            dynamicMaterial = self:getMaterial(slotName)
            materialMgr:AddLinearSampleParamByDynamicMaterialInstanceID(self.ArrodesEysVisibleParamName, dynamicMaterial, startEyeAlpha, endEyeAlpha, transTime)
        end 
    end
end

---@privte
---@param materialSlot string
---@return number
function DS_ArrodesEmoji:getMaterial(materialSlot)
    if self.DynamicMaterialCache[materialSlot] then
        return self.DynamicMaterialCache[materialSlot]
    end

    local trackEntity = self.trackPtpEntity
    if not trackEntity then
        return nil
    end

    local skeletalMesh = trackEntity.CppEntity:KAPI_Actor_GetMainSkeletalMeshComponent()
    if not skeletalMesh or skeletalMesh == 0 then
        return nil
    end

    self.cacheSkeletalMesh = skeletalMesh

    
    local materialIndex = trackEntity.CppEntity:KAPI_PrimitiveID_GetMaterialIndex(skeletalMesh, materialSlot)
    local materialId = trackEntity.CppEntity:KAPI_PrimitiveID_GetMaterial(skeletalMesh, materialIndex)

    if materialId ~= 0 and not LuaScriptAPI.IsATypeOf(materialId, "MaterialInstanceDynamic") then
        materialId = LuaScriptAPI.CreateDynamicMaterialInstance(skeletalMesh, materialId, "",
            EMIDCreationFlags.Transient)
        if materialId ~= 0 then
            trackEntity.CppEntity:KAPI_PrimitiveID_SetMaterial(skeletalMesh, materialIndex, materialId)
        end
        self.DynamicMaterialCache[materialSlot] = materialId
    end

    return materialId
end

---@private
function DS_ArrodesEmoji:attachSubEmoji()
    local sectionConfig = self.sectionConfig
    if string.isEmpty(sectionConfig.SubEmoji) or string.isEmpty(self.texturePathSubEmoji) then
        return
    end

    local trackEntity = self.trackPtpEntity
    self.effectIdSubEmoji = trackEntity:PlayNiagaraEffectAttached(
            sectionConfig.SubEmoji, "pelvis", sectionConfig.SubOffset, sectionConfig.SubRotation, 
            {X = 1, Y = 1, Z = 1}, NIAGARA_ATTACH_COMPONENT_TYPE.USE_MAIN_MESH_OR_ROOT_COMPONENT,
            false, false, sectionConfig.Duration)
    trackEntity:UpdateNiagaraTextureParam(self.effectIdSubEmoji, "Tex", self.texturePathSubEmoji)
    trackEntity:UpdateNiagaraVec2Param(self.effectIdSubEmoji, "Size", self.sectionConfig.SubScale.X,
        self.sectionConfig.SubScale.Y)
end

---@private
function DS_ArrodesEmoji:attachSubOutEmoji()
    local sectionConfig = self.sectionConfig
    if string.isEmpty(sectionConfig.SubOutEmoji) or string.isEmpty(self.texturePathSubEmoji) then
        return
    end

    local trackEntity = self.trackPtpEntity
    self.effectIdSubOutEmoji = trackEntity:PlayNiagaraEffectAttached(
        sectionConfig.SubOutEmoji, "pelvis", sectionConfig.SubOffset, sectionConfig.SubRotation,
        { X = 1, Y = 1, Z = 1 }, NIAGARA_ATTACH_COMPONENT_TYPE.USE_MAIN_MESH_OR_ROOT_COMPONENT,
        false, false, sectionConfig.Duration)
    trackEntity:UpdateNiagaraTextureParam(self.effectIdSubOutEmoji, "Tex", self.texturePathSubEmoji)
    trackEntity:UpdateNiagaraVec2Param(self.effectIdSubOutEmoji, "Size", self.sectionConfig.SubScale.X,
        self.sectionConfig.SubScale.Y)
end
