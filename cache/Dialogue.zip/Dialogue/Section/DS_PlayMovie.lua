---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/29 20:37
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_PlayMovie : DialogueSectionBase
DS_PlayMovie = DefineClass("DS_PlayMovie", DialogueSectionBase)

function DS_PlayMovie:OnStart()
	if string.isEmpty(self.sectionConfig.MoviePath) then
		Log.WarningFormat("[DialogueV2][DS_PlayMovie] MoviePath is empty in dialogue %s", self.DialogueID)
		return
	end
    Game.DialogueManagerV2.UIProcessor:PlayMovie(self.sectionConfig.MoviePath)
    local duration = Game.DialogueManagerV2.UIProcessor:GetCurrentMovieDuration()
    self.dialogueInstance:AddDialogueBarrier(DialogueConst.BARRIER_TYPE.SKIP_MOVIE, duration, self.sectionConfig.CanSkip)
end
