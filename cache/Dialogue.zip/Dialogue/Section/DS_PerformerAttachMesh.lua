---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/27 11:53
---
local UStaticMeshComponent = import("StaticMeshComponent")
local USkeletalMeshComponent = import("SkeletalMeshComponent")
local EARKeepRelative = import("EAttachmentRule").KeepRelative
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_PerformerAttachMesh : DialogueSectionBase
DS_PerformerAttachMesh = DefineClass("DS_PerformerAttachMesh", DialogueSectionBase)

-- Mesh类型
DS_PerformerAttachMesh.EMeshType = {
    SKELETON_MESH = 0,
    STATIC_MESH = 1,
}

function DS_PerformerAttachMesh:OnInit()
    self.meshCompID = 0
    self.loadID = 0
    self.assetID = 0
end

function DS_PerformerAttachMesh:OnStart()
    if not self.trackPtpEntity then
        return
    end

    local assetPath
    if self.sectionConfig.MeshType == self.EMeshType.STATIC_MESH then
        assetPath = self.sectionConfig.StaticMesh
    elseif self.sectionConfig.MeshType == self.EMeshType.SKELETON_MESH then
        assetPath = self.sectionConfig.SkeletonMesh
    end

    if not assetPath then
        Log.WarningFormat("[Start] invalid config %s", self.sectionConfig.MeshType)
        return
    end

    self.loadID = Game.AssetManager:AsyncLoadAssetID(assetPath, self, "OnMeshAssetLoaded")
end

function DS_PerformerAttachMesh:OnFinish(finishReason)
    if self.trackPtpEntity then
        self.trackPtpEntity.CppEntity:KAPI_Actor_DestroyComponent(self.meshCompID)
    end

    if self.loadID ~= 0 then
        Game.AssetManager:CancelLoadAsset(self.loadID)
        Game.AssetManager:RemoveAssetReferenceByLoadID(self.loadID)
    end
end

function DS_PerformerAttachMesh:OnMeshAssetLoaded(_, assetID)
    if assetID == 0 then
        Log.ErrorFormat("[OnMeshAssetLoaded] load asset %s or %s failed", self.sectionConfig.StaticMesh, self.sectionConfig.SkeletonMesh)
        return
    end

    self.assetID = assetID

    if not self.trackPtpEntity then
        return
    end

    if self.sectionConfig.MeshType == self.EMeshType.STATIC_MESH then
        local smCompClassID = Game.ObjectActorManager:GetIDByClass(UStaticMeshComponent)
        self.meshCompID = self.trackPtpEntity.CppEntity:KAPI_Actor_AddComponentByClassID(smCompClassID)
        if self.meshCompID ~= 0 then
            self.trackPtpEntity.CppEntity:KAPI_StaticMeshID_SetStaticMesh(self.meshCompID, assetID)
        end
    elseif self.sectionConfig.MeshType == self.EMeshType.SKELETON_MESH then
        local skCompClassID = Game.ObjectActorManager:GetIDByClass(USkeletalMeshComponent)
        self.meshCompID = self.trackPtpEntity.CppEntity:KAPI_Actor_AddComponentByClassID(skCompClassID)
        if self.meshCompID ~= 0 then
            self.trackPtpEntity.CppEntity:KAPI_SkeletalMeshID_SetSkeletalMeshAsset(self.meshCompID, assetID)
        end
    end

    if self.meshCompID ~= 0 then
        local pos = self.sectionConfig.Translation
        local rot = self.sectionConfig.Rotator
        local scale = self.sectionConfig.Scale
        self.trackPtpEntity.CppEntity:KAPI_SceneID_SetRelativeLocation(self.meshCompID, pos.X, pos.Y, pos.Z)
        self.trackPtpEntity.CppEntity:KAPI_SceneID_SetRelativeRotation(self.meshCompID, rot.Pitch, rot.Roll, rot.Yaw)
        self.trackPtpEntity.CppEntity:KAPI_SceneID_SetRelativeScale(self.meshCompID, scale.X, scale.Y, scale.Z)

        local targetCompID = self.trackPtpEntity.CppEntity:KAPI_Actor_FxGetComponentBySocket(self.sectionConfig.SocketName)
        if targetCompID ~= 0 then
            self.trackPtpEntity.CppEntity:KAPI_SceneID_AttachToComponent(self.meshCompID, targetCompID, self.sectionConfig.SocketName, EARKeepRelative, EARKeepRelative, EARKeepRelative, true)
        end
    end
end
