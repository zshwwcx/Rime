---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/27 17:36
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_SendFlowchartMsg : DialogueSectionBase
---@field private sectionConfig BPS_SendFlowchartMsg_C
DS_SendFlowchartMsg = DefineClass("DS_SendFlowchartMsg", DialogueSectionBase)

function DS_SendFlowchartMsg:OnStart()
	if not self.sectionConfig then
		Log.ErrorFormat("[DialogueV2][DS_SendFlowchartMsg] sectionConfig is nil in dialogue: %s", self.DialogueID)
		return false
	end
	if not self.dialogueInstance then
		Log.ErrorFormat("[DialogueV2][DS_SendFlowchartMsg] dialogueInstance is nil in dialogue: %s", self.DialogueID)
		return false
	end
    if self.sectionConfig.bSendAtFinish then
        local blackBoardValue = self.dialogueInstance:GetBlackBoardValue(DialogueConst.BlackBoardKey.FLOWCHART_MSG)
        if not blackBoardValue then
            blackBoardValue = {}
        end

        Log.InfoFormat("[DialogueV2][DS_SendFlowchartMsg] cache flowchart msg:%s, in dialogue:%s", self.sectionConfig.Msg, self.DialogueID)
        table.insert(blackBoardValue, self.sectionConfig.Msg)
        self.dialogueInstance:SetBlackBoardValue(DialogueConst.BlackBoardKey.FLOWCHART_MSG, blackBoardValue)
    else
        Log.InfoFormat("[DialogueV2][DS_SendFlowchartMsg] send flowchart msg:%s, in dialogue:%s", self.sectionConfig.Msg, self.DialogueID)
        if Game.me then
            Game.me:ReqClientAIMessage(self.sectionConfig.Msg)
        else
            Log.Warning("[DialogueV2][DS_SendFlowchartMsg] send flowchart msg failed: no main player, Game.me is nil")
        end
    end
end
