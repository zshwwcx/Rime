local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_GossipBubble : DialogueSectionBase
---@field private sectionConfig BPS_GossipBubble_C
DS_GossipBubble = DefineClass("DS_GossipBubble", DialogueSectionBase)

function DS_GossipBubble:OnInit()
    local BubbleType = DialogueConst.GossipBubbleType
    self.funcShowBubble = {
        [BubbleType.ASIDE] = self.ShowAside,
        [BubbleType.BUBBLE] = self.ShowBubble,
        [BubbleType.ASIDE_CUR_CHAT_CHANNEL] = self.ShowAsideCurChannel,
        [BubbleType.BUBBLE_CUR_CHAT_CHANNEL] = self.ShowBubbleCurChannel,
        [BubbleType.BOTTOM_BUBBLE] = self.ShowBottomBubble,
        [BubbleType.BOTTOM_BUBBLE_CUR_CHAT_CHANNEL] = self.ShowBottomBubbleCurChannel,
    
    }
end

function DS_GossipBubble:OnStart()
    local sectionConfig = self.sectionConfig
    local gossipBubbleID = sectionConfig.GossipBubbleID
    Log.DebugFormat("DS_GossipBubble:OnStart() %s", gossipBubbleID)

    local gossipBubbleData = Game.TableData.GetNoCameraDialogueGossipDataRow(gossipBubbleID)
    if not gossipBubbleData then
        Log.WarningFormat("[DialogueV2]DS_GossipBubble:OnStart() gossipBubbleData is nil, gossip bubble id = %s", gossipBubbleID)
        return
    end

    local entity = self.trackPtpEntity
    if not entity then
        Log.DebugFormat("DS_GossipBubble:OnStart() cannot find entity. gossip bubbleID:%s", gossipBubbleID)
        return
    end

    self:Show(entity, gossipBubbleData, sectionConfig.Duration)
end

function DS_GossipBubble:OnFinish(finishReason)
    local entity = self.trackPtpEntity
    if entity then
        Game.GossipSystem:HideBubbleByUid(entity:uid())
    end
end

function DS_GossipBubble:Show(entity, gossipBubbleData, duration)
    local func = self.funcShowBubble[gossipBubbleData.Type]
    if func then
        func(self, entity, gossipBubbleData, duration)
    else
        Log.WarningFormat("[DialogueV2]DS_GossipBubble:Show() unknown gossip bubble type. gossip bubble id = %s type = %s", gossipBubbleData.ID, gossipBubbleData.Type)
    end
end

function DS_GossipBubble:ShowAside(entity, gossipBubbleData, duration)
    
end


function DS_GossipBubble:ShowBubble(entity, gossipBubbleData, duration)
    local entityUid = entity:uid()
    Game.NewHeadInfoSystem:OnHeadInfoShowFlagChange(entityUid, true, 1)
    Game.NewHeadInfoSystem:SetWorldWidgetNoDepth(entityUid, true)

    local text = gossipBubbleData.Text
    text = Game.NPCManager.GetFormatTalkText(text) or text
    Game.GossipSystem:PlayBubbleByEidOrUid(entityUid, text, gossipBubbleData.Sound, nil, 
            duration * 1000, false, "", 0 --[[HeadInfoBubble.EBubbleType.Normal]])
end

function DS_GossipBubble:ShowAsideCurChannel(entity, gossipBubbleData, duration)
    
end

function DS_GossipBubble:ShowBubbleCurChannel(entity, gossipBubbleData, duration)

end

function DS_GossipBubble:ShowBottomBubble(entity, gossipBubbleData, duration)

end

function DS_GossipBubble:ShowBottomBubbleCurChannel(entity, gossipBubbleData, duration)

end
