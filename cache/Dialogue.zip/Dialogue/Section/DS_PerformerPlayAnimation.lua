---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/20 10:55
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_PerformerPlayAnimation : DialogueSectionBase
---@field private sectionConfig BPS_PlayAnimation_C
DS_PerformerPlayAnimation = DefineClass("DS_PerformerPlayAnimation", DialogueSectionBase)
local DialogueUtilV2 = kg_require("Gameplay.DialogueV2.DialogueUtilV2").DialogueUtilV2

function DS_PerformerPlayAnimation:OnInit()
    self.animPlayID = 0
end

function DS_PerformerPlayAnimation:OnStart()
    local sectionConfig = self.sectionConfig
    local animAssetID = sectionConfig.AnimLibItem.AssetID
    
    if string.isEmpty(animAssetID) then
        Log.WarningFormat("[DialougeV2]DS_PerformerPlayAnimation Start faield: empty anim config in dialogue %s", self.DialogueID)
        return
    end

    if self.trackPtpEntity == nil or (self.trackPtpEntity.isDestroyed == true) then
        Log.WarningFormat("[DialougeV2]DS_PerformerPlayAnimation Start faield: track entity is not exist in dialogue %s", self.DialogueID)
        return
    end

    local stateName = sectionConfig.AnimLibItem.StateName
    -- 该变量为从上一个动作BlendOut到本动作的时间,所以其实是本动作的BlendIn
    local blendIn = sectionConfig.PreAnimationBlendOutTime
    local blendOut = DialogueConst.AnimDefaultBlendOut
    
    local bSuccess
    if sectionConfig.BlendType == DialogueConst.ANIMATION_BLEND_TYPE.ANIM_LIB then
        blendIn = sectionConfig.AnimLibBlendInDuration
        blendOut = sectionConfig.AnimLibBlendOutDuration
        bSuccess, self.animPlayID = DialogueUtilV2.SafeCall(self, self.trackPtpEntity.PlayAnimLibMontageCustomBlend, self.trackPtpEntity, animAssetID, stateName, nil, blendIn, blendOut,
            sectionConfig.bCustomBlendIn, sectionConfig.HeadCullingDuration, sectionConfig.AnimLibBlendInAlphaBlendOp,
            sectionConfig.bCustomBlendOut, nil, sectionConfig.AnimLibBlendOutAlphaBlendOp, true)
    else
        bSuccess, self.animPlayID = DialogueUtilV2.SafeCall(self, self.trackPtpEntity.PlayAnimLibMontage, self.trackPtpEntity, animAssetID, stateName, nil, blendIn, blendOut, true)
    end

    if bSuccess then
        Log.DebugFormat("[DialogueV2][DS_PerformerPlayAnimation]OnStart, play animation: %s state:%s blendType:%s on %s in dialogue[%s], animPlayID:%s",
            animAssetID, stateName, sectionConfig.BlendType, self.trackPtp.TrackName, self.DialogueID, self.animPlayID)
    else
        Log.WarningFormat("[DialogueV2][DS_PerformerPlayAnimation]OnStart, play animation failed: %s state:%s blendType:%s on %s in dialogue[%s]",
            animAssetID, stateName, sectionConfig.BlendType, self.trackPtp.TrackName, self.DialogueID)
    end
end

function DS_PerformerPlayAnimation:OnFinish(finishReason)
    --if (finishReason == DialogueConst.SECTION_FINISH_REASON.TERMINATE) and (self.trackPtpEntity ~= nil) then
    --    self.trackPtpEntity:StopAnimLibMontage(self.animPlayID)
    --end
	--
    --self.animPlayID = 0
end
