---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/27 11:14
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_EpisodeDurationFlag : DialogueSectionBase
DS_EpisodeDurationFlag = DefineClass("DS_EpisodeDurationFlag", DialogueSectionBase)
