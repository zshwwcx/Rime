---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/27 19:19
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase
local PostProcessConst = kg_require("Gameplay.Effect.PostProcessConst")

local PP_SOURCE_TYPE = PostProcessConst.PP_SOURCE_TYPE
local POST_PROCESS_PRIORITY = PostProcessConst.POST_PROCESS_PRIORITY

---@class DS_PostProcess : DialogueSectionBase
DS_PostProcess = DefineClass("DS_PostProcess", DialogueSectionBase)

-- todo:应该直接用表格生成Enum
DS_PostProcess.__PostProcessType__ = {
    Memory = 1,
    Film = 2,
    Drunk = 3,
    Glitch = 4,
    Gray = 5,
    Scale = 6,
    DarkEdge = 7,
    QTE = 8,
}

-- todo:理论上应该直接走配表,不应该在没有维护的情况下给策划提供二级枚举
DS_PostProcess.__PostProcessType2ID__ = {
    [DS_PostProcess.__PostProcessType__.Memory] = 4000021,
    [DS_PostProcess.__PostProcessType__.Film] = 4000022,
    [DS_PostProcess.__PostProcessType__.Drunk] = 4000023,
    [DS_PostProcess.__PostProcessType__.Glitch] = 4000024,
    [DS_PostProcess.__PostProcessType__.Gray] = 4000025,
    [DS_PostProcess.__PostProcessType__.Scale] = 4000026,
    [DS_PostProcess.__PostProcessType__.DarkEdge] = 4000027,
    [DS_PostProcess.__PostProcessType__.QTE] = 4000029,
}

function DS_PostProcess:OnInit()
    self.ppID = 0
end

function DS_PostProcess:OnStart()
    -- 走自己的
    local postProcessConfigID
    if self.sectionConfig.PostProcessID ~= 0 then
        postProcessConfigID = self.sectionConfig.PostProcessID
    else
        postProcessConfigID = self.__PostProcessType2ID__[self.sectionConfig.Type]
    end

    if not postProcessConfigID then
        Log.WarningFormat("[DialogueV2][DS_PostProcess] invalid post process type %s in dialogue", self.sectionConfig.Type, self.DialogueID)
        return
    end

    self.ppID = Game.NewPostProcessManager:StartPostProcessByPPEffectID(
            postProcessConfigID, -1, self.sectionConfig.FadeInTime, self.sectionConfig.FadeOutTime, 
            POST_PROCESS_PRIORITY.DIALOGUE, nil, nil, PP_SOURCE_TYPE.DIALOGUE)

	if self.ppID == 0 then
		Log.WarningFormat("[DialogueV2][DS_PostProcess] Failed to start post process with config ID: %s in dialogue %s", postProcessConfigID, self.DialogueID)
	end
	
    for _, ptpName in ksbcpairs(self.sectionConfig.ExcludeActors) do
        self.ptpManager:SetPtpExcludeFromPostProcess(ptpName, true)
    end

	-- 处理后处理屏蔽
	if self.sectionConfig.bDisableGamePostProcess then
		self.dialogueInstance:DisableGamePostProcess()
	end
end

function DS_PostProcess:OnFinish(finishReason)
    if not self.sectionConfig.bClearAtEnd then
        self:recordInfoToBlackBoard()
        return
    end
	
	if self.ppID == 0 then
		Log.WarningFormat("[DialogueV2][DS_PostProcess] Trying to stop invalid post process ID in dialogue %s", self.DialogueID)
	end
	Game.NewPostProcessManager:StopPostProcessByPPToken(self.ppID)
	
    for _, ptpName in ksbcpairs(self.sectionConfig.ExcludeActors) do
        self.ptpManager:SetPtpExcludeFromPostProcess(ptpName, false)
    end

	-- 取消后处理屏蔽
	if self.sectionConfig.bDisableGamePostProcess then
		self.dialogueInstance:EnableGamePostProcess()
	end
end

---@private
function DS_PostProcess:recordInfoToBlackBoard()
    -- ppID
    local ppIDList = self.dialogueInstance:GetBlackBoardValue(DialogueConst.BlackBoardKey.POST_PROCESS_ID_LIST)
    if not ppIDList then
        ppIDList = {}
    end

    table.insert(ppIDList, self.ppID)
    self.dialogueInstance:SetBlackBoardValue(DialogueConst.BlackBoardKey.POST_PROCESS_ID_LIST, ppIDList)

    -- ExcludeActors
    local excludePerformerList = self.dialogueInstance:GetBlackBoardValue(DialogueConst.BlackBoardKey.PP_EXCLUDE_PERFORMERS)
    if not excludePerformerList then
        excludePerformerList = {}
    end

    for _, ptpName in ksbcpairs(self.sectionConfig.ExcludeActors) do
        excludePerformerList[ptpName] = true
    end
    self.dialogueInstance:SetBlackBoardValue(DialogueConst.BlackBoardKey.PP_EXCLUDE_PERFORMERS, excludePerformerList)
end
