---
--- Created by shijingzhe@kuaishou,com
--- DateTime: 2025/5/22 17:02
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_PerformerTransparent : DialogueSectionBase
DS_PerformerTransparent = DefineClass("DS_PerformerTransparent", DialogueSectionBase)

DS_PerformerTransparent.__MaterialPath__ = "/Game/Arts/Cinematics/Materials/M_CharacterDither.M_CharacterDither"

function DS_PerformerTransparent:OnStart()
    if self.trackPtpEntity == nil or (self.trackPtpEntity.isDestroyed == true) then
        return
    end

    if self.sectionConfig.EnableTransparent then
        self.trackPtpEntity.MaterialChangeReqID = self.trackPtpEntity:ChangeMaterialSimple(self.__MaterialPath__)
    else
        self.trackPtpEntity:RevertMaterial(self.trackPtpEntity.MaterialChangeReqID)
    end
end
