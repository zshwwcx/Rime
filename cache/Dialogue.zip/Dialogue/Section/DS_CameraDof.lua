---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/28 16:29
---
local KML = import("KismetMathLibrary")
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_CameraDof : DialogueSectionBase
DS_CameraDof = DefineClass("DS_CameraDof", DialogueSectionBase)

function DS_CameraDof:OnInit()
    self.sourceDof = 0
    self.targetDof = 0
end

function DS_CameraDof:OnStart()
    if not self.trackPtpEntity then
        return
    end

    self.sourceDof = Game.CameraManager:KAPI_Camera_DialogueCamera_GetCameraDOFDistance(self.trackPtpEntity.CharacterID)
    self.targetDof = self.sectionConfig.DOF
end

function DS_CameraDof:OnTick(deltaTime)
    if (self.sourceDof == 0) and (self.targetDof == 0) then
        return
    end

    if not self.trackPtpEntity then
        return
    end

    local alpha = self.runningTime / self.sectionConfig.Duration
    if alpha > 1 then
        alpha = 1
    end

    local newDof = KML.Lerp(self.sourceDof, self.targetDof, alpha)
    Game.CameraManager:KAPI_Camera_DialogueCamera_SetCameraDOFDistance(self.trackPtpEntity.CharacterID, newDof)
end

function DS_CameraDof:OnFinish(finishReason)
    if not self.trackPtpEntity then
        return
    end

    Game.CameraManager:KAPI_Camera_DialogueCamera_SetCameraDOFDistance(self.trackPtpEntity.CharacterID, self.targetDof)
end
