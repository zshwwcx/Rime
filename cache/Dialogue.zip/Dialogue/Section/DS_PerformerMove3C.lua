---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/22 14:39
---
local KML = import("KismetMathLibrary")
local EPropertyClass = import("EPropertyClass")
local EDrawDebugTrace = import("EDrawDebugTrace")
local CollisionConst = kg_require("Shared.Const.CollisionConst")
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_PerformerMove3C : DialogueSectionBase
---@field sectionConfig BPS_NewActorMovement_C
DS_PerformerMove3C = DefineClass("DS_PerformerMove3C", DialogueSectionBase)

function DS_PerformerMove3C:OnInit()
    self.targetLoc = nil
    self.targetRot = nil
end

function DS_PerformerMove3C:OnStart()
    if not self.trackPtpEntity then
        return
    end

    local targetPtpEntity = self.ptpManager:GetParticipantEntityByName(self.sectionConfig.Target)
    if not targetPtpEntity then
        return
    end

    local trackPtpEntityLoc = self.trackPtpEntity:GetPosition()
    self.targetLoc = self:traceGroundCapsuleLocation(targetPtpEntity)
    self.targetRot = KML.FindLookAtRotation(trackPtpEntityLoc, self.targetLoc)

    local mode = self.sectionConfig.Mode or DialogueConst.MoveMode3C.CalculateSpeed
    if mode == DialogueConst.MoveMode3C.StartAndEndStop then
		self.trackPtpEntity:DialogueCycleMotionSplineMove(self.targetLoc.X, self.targetLoc.Y, self.targetLoc.Z, self.sectionConfig.MovePosture)
        Log.InfoFormat("[DialogueV2][DS_PerformerMove3C]%s CycleMotionSplineMove to target:%s(%s, %s, %s) move posture:%s",
            self.trackPtp.TrackName, self.sectionConfig.Target, self.targetLoc.X, self.targetLoc.Y, self.targetLoc.Z, self.sectionConfig.MovePosture)
        return
    elseif mode == DialogueConst.MoveMode3C.StepForward then
        self.duration = self.sectionConfig.Duration
    elseif mode == DialogueConst.MoveMode3C.StepBackward then
        self.duration = self.sectionConfig.Duration
    else
        self.duration = self.sectionConfig.Duration
        local distance = math.sqrt((trackPtpEntityLoc.X - self.targetLoc.X) ^ 2 +
            (trackPtpEntityLoc.Y - self.targetLoc.Y) ^ 2)
        local timeCost = self.sectionConfig.Duration
        local maxVelocity = distance / timeCost

        -- 直接使用maxVelocity无法将起停步时间包含在Section内,所以需要根据3C接口计算出不含起停时间的速度
        local startTime, stopTime = self.trackPtpEntity:GetComplexMoveTimeOfStartAndEnd(maxVelocity)
        local realVelocity = distance / (timeCost - startTime - stopTime)

        -- 设置DriveMode并且不恢复
        if self.trackPtpEntity.bDialoguePerformer then
            if self.trackPtpEntity:CheckDoInUpperControlLogicIDValid(Enum.LocoControlUpperControlLogic.DialogueActorMove) then
                self.trackPtpEntity:DoUpperControlLogic(Enum.LocoControlUpperControlLogic.DialogueActorMove)
                self.bNeedUndoUpperControlLogic = true
            end           
        end

        self.trackPtpEntity:MoveToPointWithCurve(self.targetLoc.X, self.targetLoc.Y, self.targetLoc.Z, realVelocity)
        Log.InfoFormat("[DialogueV2][DS_PerformerMove3C]%s MoveToPointWithCurve to target:%s(%s, %s, %s) realVelocity:%s duration:%s",
            self.trackPtp.TrackName, self.sectionConfig.Target, self.targetLoc.X, self.targetLoc.Y, self.targetLoc.Z, realVelocity, self.duration)
    end    
end

function DS_PerformerMove3C:OnFinish(finishReason)
    if finishReason == DialogueConst.SECTION_FINISH_REASON.LIFE_END then
        return
    end

    if (self.targetLoc == nil) or (self.targetRot == nil) then
        return
    end

    if not self.trackPtpEntity then
        return
    end

    -- 跳过时,跳到目标位置
    local entity = self.trackPtpEntity
    entity:StopSplineMove()
    entity:SetPosition(self.targetLoc)
    entity:SetRotation(self.targetRot)
    if entity.bDialoguePerformer and self.bNeedUndoUpperControlLogic then
        if entity:CheckUnDoInUpperContolLogicIDValid(Enum.LocoControlUpperControlLogic.DialogueActorMove) then
            entity:UnDoUpperControlLogic(Enum.LocoControlUpperControlLogic.DialogueActorMove)
        end
    end
    Log.InfoFormat("[DialogueV2][DS_PerformerMove3C]%s finished moving to %s", self.trackPtp.TrackName, self.sectionConfig.Target)
end

DS_PerformerMove3C.__UpDelta__ = FVector(0, 0, 50)
DS_PerformerMove3C.__DownDelta__ = FVector(0, 0, -200)
DS_PerformerMove3C.__DefaultColor__ = FLinearColor(0, 0, 0)
DS_PerformerMove3C.__IgnoreActorIDList__ = slua.Array(EPropertyClass.Int64)

---因为停步有平滑插值阶段所以要保证终点的位置是合理的站立高度
---@private
---@param targetEntity LocalEntityBase
function DS_PerformerMove3C:traceGroundCapsuleLocation(targetEntity)
    local targetEntityLoc = targetEntity:GetPosition()
    local startLoc = targetEntityLoc + self.__UpDelta__
    local endLoc = targetEntityLoc + self.__DownDelta__
    local hitResult = LuaScriptAPI.KismetSystem_LineTraceSingle(
            targetEntity.CharacterID,
            startLoc,
            endLoc,
            CollisionConst.COLLISION_TRACE_TYPE_BY_NAME.Visibility,
            false,
            self.__IgnoreActorIDList__,
            EDrawDebugTrace.None,
            true,
            self.__DefaultColor__,
            self.__DefaultColor__,
            0)

    -- 射线检测失败,返回目标点原始位置
    if not hitResult.bResult then
        Log.WarningFormat("[DialogueV2][traceGroundCapsuleLocation] trace %s failed", targetEntity:uid())
        return targetEntityLoc
    end

    local traceLoc = hitResult.HitResult.Location
    local halfHeight = self.trackPtpEntity.CppEntity:KAPI_Actor_GetScaledCapsuleHalfHeight()
    traceLoc.Z = traceLoc.Z + halfHeight
    return FVector(traceLoc.X, traceLoc.Y, traceLoc.Z)
end
