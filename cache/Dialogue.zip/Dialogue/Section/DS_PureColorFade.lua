---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/29 19:40
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_PureColorFade : DialogueSectionBase
DS_PureColorFade = DefineClass("DS_PureColorFade", DialogueSectionBase)

function DS_PureColorFade:OnStart()
	if not self.sectionConfig then
		Log.ErrorFormat("[DialogueV2][DS_PureColorFade] sectionConfig is nil in dialogue: %s", self.DialogueID)
		return false
	end
    Game.DialogueManagerV2.UIProcessor:ShowDialogueMask(self.sectionConfig.Color,
        self.sectionConfig.FadeInTime, self.sectionConfig.FadeOutTime, self.sectionConfig.Duration)
end

function DS_PureColorFade:OnFinish(finishReason)
    Game.DialogueManagerV2.UIProcessor:HideDialogueMask()
end
