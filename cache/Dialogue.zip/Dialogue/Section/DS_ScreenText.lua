---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/24 15:12
---
local DialogueSectionBase = kg_require("Gameplay.DialogueV2.Section.DialogueSectionBase").DialogueSectionBase

---@class DS_ScreenText : DialogueSectionBase
DS_ScreenText = DefineClass("DS_ScreenText", DialogueSectionBase)

function DS_ScreenText:OnInit()
	if not self.sectionConfig then
		Log.ErrorFormat("[DialogueV2][DS_ScreenText] sectionConfig is nil in dialogue: %s", self.DialogueID)
		return false
	end
	self.canSkipDuration = self.sectionConfig.CanSkipDuration or 2
	if self.sectionConfig.bCanSkip == nil then
		self.bCanSkip = true
	else
		self.bCanSkip = self.sectionConfig.bCanSkip
	end
	Game.GlobalEventSystem:AddListener(EEventTypesV2.ON_DIALOGUE_SCREEN_TEXT_CLICKED, "OnClicked", self)
end

function DS_ScreenText:OnStart()
	if not self.sectionConfig then
		Log.ErrorFormat("[DialogueV2][DS_ScreenText] sectionConfig is nil in dialogue: %s", self.DialogueID)
		return false
	end
	local sc = self.sectionConfig
	Game.GlobalEventSystem:Publish(EEventTypesV2.DIALOGUE_SCREEN_TEXT_INIT, sc.AsideID, sc.BlackScreenType, sc.NeedFadeIn, sc.NeedFadeOut, sc.Duration, self.bCanSkip, self.canSkipDuration)
    
	-- 开始的时候，屏蔽 自动、跳过、回顾 点击按钮
	Game.DialogueManagerV2.UIProcessor:SetDialogueControlPanelVisibilityByReason(false, "DS_ScreenText")

    local screenTextData = Game.TableData.GetDialogueBlackScreenTextRow(sc.AsideID)
    if screenTextData and not string.isEmpty(screenTextData.Text) then
        Game.DialogueManagerV2.DialogueHistory:Record(DialogueConst.HISTORY_ITEM_TYPE.SCREEN_TEXT, 
            screenTextData.Text, "", "",nil)
    end
    
end

function DS_ScreenText:OnTick(deltaTime)
    Game.GlobalEventSystem:Publish(EEventTypesV2.DIALOGUE_SCREEN_TEXT_TICK, deltaTime)
end

function DS_ScreenText:OnClicked()
	if self.bCanSkip and self.runningTime >= self.canSkipDuration then
		if not self.sectionConfig then
			Log.ErrorFormat("[DialogueV2][DS_ScreenText] sectionConfig is nil in dialogue: %s", self.DialogueID)
			return false
		end
		if not self.dialogueInstance then
			Log.ErrorFormat("[DialogueV2][DS_ScreenText] dialogueInstance is nil in dialogue: %s", self.DialogueID)
			return false
		end
		local leftTime = self.sectionConfig.Duration - self.runningTime + 0.1
		self.dialogueInstance:TryResume()
		self.dialogueInstance:SkipPeriodDialogue(leftTime)
	end
end

function DS_ScreenText:OnFinish(finishReason)
	if not self.sectionConfig then
		Log.ErrorFormat("[DialogueV2][DS_ScreenText] sectionConfig is nil in dialogue: %s", self.DialogueID)
		return false
	end
    if self.sectionConfig.NeedFadeOut then
        Game.GlobalEventSystem:Publish(EEventTypesV2.DIALOGUE_SCREEN_TEXT_FINISH)
        Game.DialogueManagerV2.UIProcessor:SetDialogueControlPanelVisibilityByReason(true, "DS_ScreenText")
    end

	Game.GlobalEventSystem:RemoveTargetAllListeners(self)

	if not self.dialogueInstance then
		Log.ErrorFormat("[DialogueV2][DS_ScreenText] dialogueInstance is nil in dialogue: %s", self.DialogueID)
		return false
	end
    self.dialogueInstance:SetBlackBoardValue(DialogueConst.BlackBoardKey.NEED_CLOSE_SCREEN_TEXT, true)
	
	-- 结束，恢复 自动、跳过、回顾 点击按钮
	--Game.DialogueManagerV2.UIProcessor:SetDialogueControlPanelVisibilityByReason(true, "DS_ScreenText")
end
