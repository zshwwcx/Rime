---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/8 15:51
---

-- 所有Section的基类,主要封装一些生命周期方法和公共初始化
---@class DialogueSectionBase
---@field trackPtp DialogueParticipant
---@field trackPtpEntity DialoguePerformer|DialogueCamera|DialogueRoutePoint|DialogueNiagara
---@field dialogueInstance DialogueInstanceBase|NormalDialogueInstance|NoCameraDialogueInstance|SimpleDialogueInstance|ListDialogueInstance
---@field DialogueID number
---@field ownerTrack DialogueTrack
---@field bInRunning boolean
---@field runningState DialogueSectionRunningState
---@field bPause boolean
---@field sectionIndex number
---@field sectionConfig UDialogueActionBase
DialogueSectionBase = DefineClass("DialogueSectionBase")

function DialogueSectionBase:ctor(dialogueInstance, track, sectionConfig, trackPtp, trackPtpEntity, sectionIndex)
    -- 暂停标记
    self.bPause = false
    -- Section激活标记
    self.bInRunning = false
    self.runningState = nil
    self.sectionConfig = sectionConfig
	self.sectionIndex = sectionIndex

    ---@type number 从Start->Finish的时间,不包括暂停的时间
    self.runningTime = 0
    ---@type number 从Start->Finish的时间,包括暂停的时间
    self.totalRunningTime = 0

    ---@type DialogueTrack
    self.ownerTrack = track

    ---@type DialogueParticipant
    self.trackPtp = trackPtp
    ---@type number 每次指定方法前获取一下,避免O(N)监听
    self.trackPtpEntityID = trackPtpEntity and trackPtpEntity:uid() or 0
    self.trackPtpEntity = trackPtpEntity

    ---@type NormalDialogueInstance
    self.dialogueInstance = dialogueInstance

    ---@type DialogueParticipantManager
    self.ptpManager = self.dialogueInstance.ptpManager
    ---@type number
    self.DialogueID = self.dialogueInstance.DialogueID
	
	---@type boolean 是否已经被跳过
	self.bJumped = false
end

function DialogueSectionBase:ToString()
    return string.format("%s:%s [%s][%s][%s]", self.__cname, tostring(self), self.sectionIndex, self.DialogueID, self.runningState)
end

---@public
function DialogueSectionBase:InitSection()
    self.runningState = DialogueConst.SECTION_RUNNING_STATE.INITED 
    self:OnInit()
end

---@public
---@param runningTime number @ 轨道当前的时间
---@param bSkip boolean @ 是否快速掠过/跳过
function DialogueSectionBase:StartSection(runningTime, bSkip)
    self.bInRunning = true
    self.runningState = DialogueConst.SECTION_RUNNING_STATE.RUNNING
    -- 由于对话是按帧执行，section的开始时间不会完全契合到帧上，
    -- 所以这里需要矫正runningTime，同时也要更新totalRunningTime
    self.runningTime = runningTime - self.sectionConfig.StartTime
    self.totalRunningTime = self.runningTime
    Log.DebugFormat("[DialogueV2]%s StartSection at time %s, bSkip:%s, running time:%s", 
        self:ToString(), runningTime, bSkip, self.runningTime)
    
    self:OnStart(bSkip)
    if DialogueConst.CANNOT_SKIP_SECTION[self.sectionConfig.ObjectClass] == 1 then
        if bSkip then
            -- 由于section分瞬间执行完毕和持续执行两类，对于瞬间执行完毕的section不通过AddBreakSkipPeriodSection/
            -- RemoveBreakSkipPeriodSection的控制来终止当前正在执行skip period流程
            self.dialogueInstance:BreakCurSkipPeriod(self)
        end
        self.dialogueInstance:AddBreakSkipPeriodSection(self)
    end
end

---@public
---@param deltaTime number
function DialogueSectionBase:TickSection(deltaTime, bSkip)
    self.totalRunningTime = self.totalRunningTime + deltaTime

    if not self.bPause then
        self.runningTime = self.runningTime + deltaTime

        -- 如果已超时,确保叠加的delta不会超过Duration
        if self.runningTime > self.sectionConfig.Duration then
            deltaTime = deltaTime - (self.runningTime - self.sectionConfig.Duration)
        end
    end
    
    if DialogueConst.IGNORE_PAUSE_SECTION[self.sectionConfig.ObjectClass] then
        -- 如果是alwaysTick的,不累加runningTime
        self:OnTick(deltaTime, bSkip)
    elseif not self.bPause then
        self:OnTick(deltaTime, bSkip)
    end
end

---@public
---@param finishReason DialogueSectionFinishReason
function DialogueSectionBase:FinishSection(finishReason)
    Log.DebugFormat("[DialogueV2]%s FinishSection at time %s duration:%s, finish reason:%s", 
        self:ToString(), self.ownerTrack.instanceRunningTime, self.runningTime, finishReason)
    self.bInRunning = false
    self.runningState = DialogueConst.SECTION_RUNNING_STATE.FINISHED
    self:OnFinish(finishReason)
    if DialogueConst.CANNOT_SKIP_SECTION[self.sectionConfig.ObjectClass] then
        self.dialogueInstance:RemoveBreakSkipPeriodSection(self)
    end
end

---@public
function DialogueSectionBase:PauseSection()
    if not self.bPause then
        Log.DebugFormat("[DialogueV2]%s PauseSection at time %s", self:ToString(), self.runningTime)
        self.bPause = true
        self:OnPause()
    end
end

---@public
function DialogueSectionBase:ResumeSection()
    if self.bPause then
        Log.DebugFormat("[DialogueV2]%s ResumeSection at time %s", self:ToString(), self.runningTime)
        self.bPause = false
        self:OnResume()
    end
end

---获取下一个SectionConfigm
function DialogueSectionBase:GetNextSectionConfig()
	local sectionConfigs = self.ownerTrack.trackConfig.ActionSections
	if self.sectionIndex and self.sectionIndex  < #sectionConfigs then
		return sectionConfigs[self.sectionIndex + 1]
	else
		return nil
	end
end

---暂停时累加总时长
---@public
---@param deltaTime number
function DialogueSectionBase:AddTotalRunningTimeOnPause(deltaTime)
    self.totalRunningTime = self.totalRunningTime + deltaTime
end

-- 判断当前Section是否已经激活
---@public
---@return boolean
function DialogueSectionBase:IsRunning()
    return self.bInRunning
end

-- 判断当前Section是否需要开始执行
---@public
---@return boolean
function DialogueSectionBase:NeedStart(trackRunningTime)
    if self:IsInRunningState(DialogueConst.SECTION_RUNNING_STATE.RUNNING) or self:IsInRunningState(DialogueConst.SECTION_RUNNING_STATE.FINISHED) then
        return false
    end
    
    return (self.bInRunning == false) and (trackRunningTime >= self.sectionConfig.StartTime) and (not self.bJumped)
end

---@param state DialogueSectionRunningState
---@return boolean
function DialogueSectionBase:IsInRunningState(state)
    return self.runningState and self.runningState == state
end
    
-- 判断当前Section是否已执行完毕
---@public
---@param bSkip boolean @ 是否为跳过
---@return boolean
function DialogueSectionBase:NeedFinish(bSkip)
    if self:IsInRunningState(DialogueConst.SECTION_RUNNING_STATE.FINISHED) then
        return false
    end

    if not self.sectionConfig.bConstant then
        return self.bInRunning == true
    end
    
    return (self.bInRunning == true) and (self.runningTime - self.sectionConfig.Duration > -0.00001)
end


--region LifeCycle


---@protected
function DialogueSectionBase:OnInit()
    -- 子类重写
end

---@protected
function DialogueSectionBase:OnStart()
    -- 子类重写
end

---@protected
function DialogueSectionBase:OnTick(deltaTime)
    -- 子类重写
end

---@protected
---@param finishReason DialogueSectionFinishReason
function DialogueSectionBase:OnFinish(finishReason)
    -- 子类重写
end

---@protected
function DialogueSectionBase:OnPause()
    -- 子类重写
end

---@protected
function DialogueSectionBase:OnResume()
    -- 子类重写
end


--endregion LifeCycle


--region SkipDialogue
---@public
---@param specificTime float @跳跃到的时间轴时间点
function DialogueSectionBase:JumpToSpecificTime(specificTime)
	local sectionStartTime = self.sectionConfig.StartTime
	local sectionEndTime = sectionStartTime + self.sectionConfig.Duration
	
	if specificTime < sectionStartTime then
		-- section还没开始，直接return
		return
	elseif sectionEndTime < specificTime then
		-- section已经终止，执行start+finish直接终止
		if self:NeedStart(specificTime) then
			self:InitSection()
			self:StartSection(specificTime, true)
		end
		self:FinishSection(DialogueConst.SECTION_FINISH_REASON.SKIP)
	elseif sectionStartTime <= specificTime and specificTime <= sectionEndTime then
		-- section执行了一段时间，但还未结束，需要做(specificTime-startTime)时长的模拟
		if self:NeedStart(specificTime) then
			self:InitSection()
			self:StartSection(sectionStartTime)
			self:SkipPeriodSection(specificTime - sectionStartTime)
		else
			local remainTime = specificTime - self.runningTime
			self:SkipPeriodSection(remainTime)
		end
	end
end

DialogueSectionBase.__SkipTickUnit__ = 0.10

function DialogueSectionBase:SkipPeriodSection(period)
	local count = math.ceil(period / self.__SkipTickUnit__)
	local success
	for i = count, 1, -1 do
		if period > self.__SkipTickUnit__ then
			period = period - self.__SkipTickUnit__
			success = xpcall(self.OnTick, CallBackError, self, self.__SkipTickUnit__, true)
		else
			success = xpcall(self.OnTick, CallBackError, self, period, true)
			period = 0
		end

		if not success then
			Log.DebugWarningFormat("[DialogueV2][DialogueSectionBase::SkipPeriodSection] tick failed, left period:%s", period)
		end

		if period <= 0 then
			break
		end
	end
end

function DialogueSectionBase:SetJumped(bJumped)
	self.bJumped = bJumped
end

--endregion


--region Common





--endregion Common
