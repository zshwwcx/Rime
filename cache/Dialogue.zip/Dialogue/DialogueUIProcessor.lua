---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/7 11:52
---
local TimerBase = kg_require("Framework.KGFramework.KGCore.TimerManager.TimerBase").TimerBase
local StringConst = kg_require("Gameplay.Const.StringConst.StringConst").StringConst
local DialogueTaggedObject = kg_require("Gameplay.DialogueV2.Core.DialogueTaggedObject").DialogueTaggedObject

---@class DialogueUIProcessor
DialogueUIProcessor = DefineClass("DialogueUIProcessor", TimerBase)

function DialogueUIProcessor:ctor()
    -- 当前UI状态
    self.curContentUIStyle = nil

    self.bInMoviePlaying = false
    self.bInPrinting = false

    ---@type DialogueTaggedObject
    self.disablePanelClickReasons = DialogueTaggedObject.new("DisableDialoguePanelClickable", self, "onDisableClickPanel", "onEnableClickPanel")
    ---@type DialogueTaggedObject
    self.disableSkipBtnReasons = DialogueTaggedObject.new("SkipBtnHidden", self, "onHideSkipBtn", "onShowSkipBtn")
    ---@type DialogueTaggedObject
    self.disableAutoPlayBtnReasons = DialogueTaggedObject.new("AutoPlayBtnHidden", self, "onHideAutoPlayBtn", "onShowAutoPlayBtn")
    ---@type DialogueTaggedObject
    self.disableReviewBtnReasons = DialogueTaggedObject.new("ReviewBtnHidden", self, "onHideReviewBtn", "onShowReviewBtn")
    ---@type DialoguePanelInterface
    self.panelInterface = nil
	
	self.lastClickTime = 0
    self.delayCallTimer = {}
end

function DialogueUIProcessor:Clear()
    self.curContentUIStyle = nil

    self.bInMoviePlaying = false
    self.bInPrinting = false
    self.disablePanelClickReasons:ClearAllTags()
    self.disableSkipBtnReasons:ClearAllTags()
    self.disableAutoPlayBtnReasons:ClearAllTags()
    self.delayCallTimer = {}
end

function DialogueUIProcessor:Init()
    ---@type EventSystemV2
    local EventSystem = Game.GlobalEventSystem
    EventSystem:AddListener(EEventTypesV2.ON_DIALOGUE_PANEL_CLICKED, "OnDialoguePanelClicked", self)
    EventSystem:AddListener(EEventTypesV2.ON_DIALOGUE_PRINT_START, "OnDialoguePrintStart", self)
    EventSystem:AddListener(EEventTypesV2.ON_DIALOGUE_PRINT_FINISH, "OnDialoguePrintFinish", self)
end

function DialogueUIProcessor:UnInit()
    self:Clear()
    Game.GlobalEventSystem:RemoveTargetAllListeners(self)
end

---@public
---@param panelInterface DialoguePanelInterface
function DialogueUIProcessor:SetDialoguePanelInterface(panelInterface)
    self.panelInterface = panelInterface
end

---@public
---@return boolean
function DialogueUIProcessor:IsDialoguePanelOpened()
    return Game.NewUIManager:CheckPanelIsOpen(UIPanelConfig.Dialogue_Panel)
end

---@public
---@param autoPlayType number
---@param bCanSkip boolean
---@param bShowCameraShot boolean
function DialogueUIProcessor:OpenDialoguePanel(autoPlayType, bCanSkip, bShowCameraShot)
    Game.NewUIManager:OpenPanel(UIPanelConfig.Dialogue_Panel, self, autoPlayType, bCanSkip, bShowCameraShot)
end

---@public
function DialogueUIProcessor:CloseDialoguePanel()
    Game.NewUIManager:ClosePanel(UIPanelConfig.Dialogue_Panel)
    self.panelInterface = nil
end

---设置台本打字机打印速度
---@public
---@param speed number
function DialogueUIProcessor:SetPrintSpeed(speed)
    self.panelInterface:SetPrintSpeed(speed)
end

---@public
---@param reason number @ 使用枚举DISABLE_PANEL_CLICK_REASON
function DialogueUIProcessor:AddDisablePanelClickReason(reason)
    if string.isEmpty(reason) then
        return
    end

    if not self.disablePanelClickReasons:AddTag(reason) then
        Log.WarningFormat("[DialogueV2][DialogueUIProcessor]AddDisablePanelClickReason: reentrancy reason %s", reason)
    else
        Log.InfoFormat("[DialogueV2][DialogueUIProcessor]AddDisablePanelClickReason reason:%s", reason)
    end
end

---@public
---@param reason number @ 使用枚举DISABLE_PANEL_CLICK_REASON
function DialogueUIProcessor:DelDisablePanelClickReason(reason)
    if not self.disablePanelClickReasons:RemoveTag(reason) then
        Log.WarningFormat("[DialogueV2][DialogueUIProcessor]DelDisablePanelClickReason: non exist reason %s", reason)
    else
        Log.InfoFormat("[DialogueV2][DialogueUIProcessor]DelDisablePanelClickReason %s", reason)
    end    
end

---UI点击,处理打字机,跳过等逻辑
function DialogueUIProcessor:OnDialoguePanelClicked()
    if Game.GameTimeMS - self.lastClickTime < DialogueConst.INTERVAL_CLICK then
        return
    end
    
    self.lastClickTime = Game.GameTimeMS

    if self.disablePanelClickReasons:HasAnyTag() then
        local reasons = self.disablePanelClickReasons:Dump()
        Log.InfoFormat("[DialogueV2][OnDialoguePanelClicked] panel click disabled by: %s", reasons)
        return
    end

    if self.bInMoviePlaying then
        -- todo:视频播放控制逻辑
        return
    end

    if self.bInPrinting then
        Log.DebugFormat("[DialogueV2]OnDialoguePanelClicked, dialogue is printing, try flush content printer")
        Game.DialogueManagerV2.UIProcessor:CallPanelFunction(DialogueConst.PanelFunction.TryFlushContentPrinter)
    else
        Game.GlobalEventSystem:Publish(EEventTypesV2.ON_DIALOGUE_SKIP_CONTENT)
        
        ---@type DialogueInstanceBase
        local dialogueInstance = Game.DialogueManagerV2.curExclusiveInstance
        if dialogueInstance then
            dialogueInstance:OnDialoguePanelClicked()
        end
    end
end

---获取当前小段下实际生效的SkipTips
---@public
---@return string
function DialogueUIProcessor:GetCurrentEpisodeSkipTips()
    local skipTips = ""

    local dialogueIns = Game.DialogueManagerV2.curExclusiveInstance
    if not dialogueIns then
        return skipTips
    end

    local dialogueAssetData = Game.TableData.GetDialogueAssetDataRow(dialogueIns.DialogueID)
    local dialogueTalkData = Game.TableData.GetDialogueTalkDataRow(tostring(dialogueIns.DialogueID))

    -- 当前小段如果有配置,则优先使用
    if dialogueTalkData then
        local episodeData = dialogueTalkData[dialogueIns.currentEpisode.episodeIdx]
        if episodeData then
            skipTips = episodeData[1].SkipTips
        end
    end

    -- 否则用资产上的数据
    if string.isEmpty(skipTips) then
        skipTips = dialogueAssetData.SkipTips
    end

    return skipTips
end

---@public
---@return boolean
function DialogueUIProcessor:IsDialoguePause()
    local dialogueIns = Game.DialogueManagerV2.curExclusiveInstance
    if not dialogueIns then
        return false
    end

    return dialogueIns:IsPause()
end

---面板中有些逻辑需要暂停对话
---@public
function DialogueUIProcessor:PauseDialogue()
    local dialogueIns = Game.DialogueManagerV2.curExclusiveInstance
    if not dialogueIns then
        return
    end

    dialogueIns:PausePlay()
end

---面板中有些逻辑需要恢复对话
---@public
function DialogueUIProcessor:ResumeDialogue()
    local dialogueIns = Game.DialogueManagerV2.curExclusiveInstance
    if not dialogueIns then
        return
    end

    dialogueIns:ResumePlay()
end

---跳过当前小段
---@public
function DialogueUIProcessor:OnSkipCurrentEpisode()
    local dialogueIns = Game.DialogueManagerV2.curExclusiveInstance
    if not dialogueIns then
        return
    end

    dialogueIns:SkipEpisode()
end

function DialogueUIProcessor:OnDialoguePrintStart()
    Log.DebugFormat("[DialogueV2]OnDialoguePrintStart")
    self.bInPrinting = true
end

function DialogueUIProcessor:OnDialoguePrintFinish()
    Log.DebugFormat("[DialogueV2]OnDialoguePrintFinish")
    self.bInPrinting = false
end

DialogueUIProcessor.__AsideTalker__ = "Asider"
DialogueUIProcessor.__PlayerTalker__ = "player"
DialogueUIProcessor.__CommonNpcTalker__ = "CommonNpc"

---展示台本
---@public
---@param talkerEntity DialoguePerformer
---@param talkerAppearanceID number
---@param bIsPlayer boolean
---@param lineTalkData _DialogueTalkDataRow
---@param bSimpleDialogue boolean
---@param sectionConfig table
---@param soundEventName string
---@param bShowTalkerNameInCSStyle boolean
function DialogueUIProcessor:ShowContent(talkerEntity, talkerAppearanceID, bIsPlayer, lineTalkData, bSimpleDialogue, sectionConfig, soundEventName, bShowTalkerNameInCSStyle)
    local npcInfoData = Game.TableData.GetNpcInfoDataRow(talkerAppearanceID)
    local passerbyNpcData = Game.TableData.GetPasserbyNpcDataRow(talkerAppearanceID)

    -- 获取TalkerType
    local talkerType
    if talkerEntity then
        talkerType = bIsPlayer and DialogueConst.TALKER_TYPE.PLAYER or DialogueConst.TALKER_TYPE.NPC
    elseif lineTalkData.Talker == self.__AsideTalker__ then
        talkerType = DialogueConst.TALKER_TYPE.ASIDE
    elseif lineTalkData.Talker == self.__PlayerTalker__ then
        talkerType = DialogueConst.TALKER_TYPE.PLAYER
    elseif lineTalkData.Talker == self.__CommonNpcTalker__ then
        talkerType = DialogueConst.TALKER_TYPE.NPC
    elseif bSimpleDialogue then
        talkerType = DialogueConst.TALKER_TYPE.NPC
    end

    if not talkerType then
        Log.Warning("[DialogueV2][ShowContent] invalid talker type, show nothing")
        return false
    end

    -- 说话人的称号显示
    local title
    if (bIsPlayer == false) and (lineTalkData.ShowNPCTitle == true) then
        if (npcInfoData ~= nil) and (string.isEmpty(npcInfoData.Title) == false) then
            title = npcInfoData.Title
        elseif (passerbyNpcData ~= nil) and (string.isEmpty(passerbyNpcData.Title) == false) then
            title = passerbyNpcData.Title
        end
    end

    -- 获取TalkerNameType
    local talkerNameType
    if string.isEmpty(lineTalkData.TalkerName) then
        talkerNameType = DialogueConst.TALKER_NAME_TYPE.SELF
    else
        talkerNameType = DialogueConst.TALKER_NAME_TYPE.OVERRIDE
    end

    -- 获取说话人的显示名字
    local talkerName = ""
    if not string.isEmpty(lineTalkData.TalkerName) then
        talkerName = lineTalkData.TalkerName
    elseif talkerType == DialogueConst.TALKER_TYPE.PLAYER then
        if Game.me then
            talkerName = Game.me.Name
        else
            talkerName = StringConst.Get("DAILOGUE_PLAYER_NAME")
        end
    elseif talkerType == DialogueConst.TALKER_TYPE.NPC then
        if npcInfoData then
            talkerName = npcInfoData.Name
        elseif passerbyNpcData then
            talkerName = passerbyNpcData.Name
        else
            talkerName = StringConst.Get("DIALOGUE_UNKNOWN_NAME")
        end
    end

    -- 获取台本内容
    local content
    if string.isEmpty(sectionConfig.OverrideText) then
        content = lineTalkData.Text
    else
        content = sectionConfig.OverrideText
    end

    Log.DebugFormat("[DialogueV2][ShowContent] talkerName: %s, content: %s", talkerName, content)

    assert(self.panelInterface, "self.panelInterface is nil, maybe panelInterface is destroyed")
    if self:HasValidPanel() then
        local subTitleType = 0
        if lineTalkData.SubTitleType then
            subTitleType = lineTalkData.SubTitleType
        end
        self.panelInterface:ShowContent(title, talkerName, content, talkerType,
            lineTalkData.SubTitle, lineTalkData.Small, 
            lineTalkData.SmallPos, bShowTalkerNameInCSStyle, sectionConfig, subTitleType)
    end
    self:CallPanelFunction(DialogueConst.PanelFunction.SetContentUIStyle, talkerType, talkerNameType)

    self:addChatInfo(talkerName, content, sectionConfig.SendOther)

	if not Game.DialogueManagerV2.curExclusiveInstance:GetBlackBoardValue(DialogueConst.BlackBoardKey.DIALOGUE_JUMP_SKIP) then
		Game.DialogueManagerV2.DialogueHistory:Record(
            DialogueConst.HISTORY_ITEM_TYPE.SCRIPT, lineTalkData.Text, 
            talkerName, soundEventName, nil)
	end

    return true
end

---@public
function DialogueUIProcessor:SetDialogueContentUIType(UIType)
    if self:HasValidPanel() then
	    self.panelInterface:SetDialogueContentUIType(UIType)
    end
end

---@public
function DialogueUIProcessor:PlayMovie(movieName)
    if self:HasValidPanel() then
        -- luacheck: push ignore
        self.panelInterface:PlayMovie(movieName, function()
            if not self.isDestroyed then
                self:StopMovie()
            end
        end)
        -- luacheck: pop
    end
end

---@public
function DialogueUIProcessor:StopMovie()
    if self:HasValidPanel() then
        self.panelInterface:StopMovie()
    end
end

---@public
---@return number
function DialogueUIProcessor:GetCurrentMovieDuration()
    if self:HasValidPanel() then
        return self.panelInterface:GetCurrentMovieDuration()
    end

    return 0
end

---对话信息发送到聊天频道内
---@private
---@param talkerName string
---@param content string
---@param bSendToOther boolean
function DialogueUIProcessor:addChatInfo(talkerName, content, bSendToOther)
    local msg
    if string.isEmpty(talkerName) then
        msg = content
    else
        msg = string.format(StringConst.Get("SOCIAL_CHAT_NPC"), talkerName, content)
    end

    msg = Game.NPCManager.GetFormatTalkText(msg)
    if bSendToOther then
        Game.ChatSystem:AddChannelSystemInfoByServer(msg, Enum.EChatChannelData.NEARBY)
    else
        Game.ChatSystem:AddChannelSystemInfo(msg, Game.GameTimeMS, Enum.EChatChannelData.NEARBY)
    end
end

--- 显示对话选项
---@param options DialogueOption[]
---@param optionType number
---@param bTimeLimit boolean
---@param timeLimited number
---@param bChoice boolean
function DialogueUIProcessor:ShowDialogueOptions(options, optionType, bTimeLimit, timeLimited, bChoice)
    if not self:HasValidPanel() then
        return
    end

    self.panelInterface:ShowOptions(options, optionType, bTimeLimit, timeLimited, bChoice)
end

---@private
---@param taggedObject DialogueTaggedObject
function DialogueUIProcessor:onDisableClickPanel(taggedObject)
    
end

---@private
---@param taggedObject DialogueTaggedObject
function DialogueUIProcessor:onEnableClickPanel(taggedObject)
    
end

---@private
---@param taggedObject DialogueTaggedObject
function DialogueUIProcessor:onHideSkipBtn(taggedObject)
    if not self:HasValidPanel() then
        return
    end

    self.panelInterface:SetSkipButtonVisible(false)
end

---@private
---@param taggedObject DialogueTaggedObject
function DialogueUIProcessor:onShowSkipBtn(taggedObject)
    if not self:HasValidPanel() then
        return
    end

    self.panelInterface:SetSkipButtonVisible(true)
end

function DialogueUIProcessor:onHideAutoPlayBtn(taggedObject)
    if not self:HasValidPanel() then
        return
    end

    self.panelInterface:SetAutoPlayButtonVisible(false)
end

function DialogueUIProcessor:onShowAutoPlayBtn(taggedObject)
    if not self:HasValidPanel() then
        return
    end

    self.panelInterface:SetAutoPlayButtonVisible(true)
end

function DialogueUIProcessor:onHideReviewBtn(taggedObject)
    if not self:HasValidPanel() then
        return
    end

    self.panelInterface:SetReviewButtonVisible(false)
end
function DialogueUIProcessor:onShowReviewBtn(taggedObject)
    if not self:HasValidPanel() then
        return
    end

    self.panelInterface:SetReviewButtonVisible(true)
end

---@param reason DialogueSkipBtnHideReason
---@param bVisible boolean
function DialogueUIProcessor:SetReviewButtonVisible(reason, bVisible)
    assert(not string.isEmpty(reason) and type(reason) == 'string', "SetSkipButtonVisible failed: must have reason")
    assert(bVisible ~= nil and type(bVisible) == 'boolean', "SetSkipButtonVisible failed:bVisible must be boolean")

    if bVisible then
        self.disableReviewBtnReasons:RemoveTag(reason)
    else
        self.disableReviewBtnReasons:AddTag(reason)
    end
    Log.InfoFormat("[DialogueV2][DialogueUIProcessor]SetReviewButtonVisible, reason:%s bVisible:%s, hide reasons:%s",
        reason, bVisible, self.disableReviewBtnReasons:Dump())
end

---@param reason DialogueSkipBtnHideReason
---@param bVisible boolean
---@param bForce boolean
function DialogueUIProcessor:SetSkipButtonVisible(reason, bVisible, bForce)
    assert(not string.isEmpty(reason) and type(reason) == 'string', "SetSkipButtonVisible failed: must have reason")
    assert(bVisible ~= nil and type(bVisible) == 'boolean', "SetSkipButtonVisible failed:bVisible must be boolean")

    if bVisible then
        self.disableSkipBtnReasons:RemoveTag(reason)
    else
        self.disableSkipBtnReasons:AddTag(reason)
    end

    Log.InfoFormat("[DialogueV2][DialogueUIProcessor]SetSkipButtonVisible, reason:%s bVisible:%s, hide reasons:%s",
        reason, bVisible, self.disableSkipBtnReasons:Dump())
end

---@param reason DialogueAutoPlayHideReason
---@param bVisible boolean
---@param bForce boolean
function DialogueUIProcessor:SetAutoPlayButtonVisible(reason, bVisible, bForce)
    assert(not string.isEmpty(reason) and type(reason) == 'string', "SetSkipButtonVisible failed: must have reason")
    assert(bVisible ~= nil and type(bVisible) == 'boolean', "SetSkipButtonVisible failed:bVisible must be boolean")

    if bVisible then
        self.disableAutoPlayBtnReasons:RemoveTag(reason)
    else
        self.disableAutoPlayBtnReasons:AddTag(reason)
    end

    Log.InfoFormat("[DialogueV2][DialogueUIProcessor]SetAutoPlayButtonVisible, reason:%s bVisible:%s, hide reasons:%s",
        reason, bVisible, self.disableReviewBtnReasons:Dump())
end

function DialogueUIProcessor:OnSelectOption()
    if not self:HasValidPanel() then
        return
    end

    self.panelInterface:HideOptionComp()
end

---@public
---@param funcName string
---@return any
function DialogueUIProcessor:CallPanelFunction(funcName, ...)
    if not self:HasValidPanel() then
        return
    end

    return self.panelInterface:InnerCallPanelFunction(funcName, ...)
end

---@param delay number @ delay time in seconds
---@param funcName string
---@return number @ timer token
function DialogueUIProcessor:DeferCallPanelFunction(delay, funcName, ...)
    if not self:HasValidPanel() then
        return
    end
    
    local params = table.pack(funcName, ...)
    local timerToken = self:AddTimer(delay, 1, "DelayCall", params)
    table.insert(params, 1, timerToken)
    self.delayCallTimer[timerToken] = funcName
    Log.DebugFormat("[DialogueV2][DialogueUIProcessor]DeferCallPanelFunction, funcName:%s delay:%s, timerToken:%s",
        funcName, delay, timerToken)
    return timerToken
end

function DialogueUIProcessor:DelayCall(params)
    if #params < 1 or not self:HasValidPanel() then
        return
    end

    local timerToken = params[1]
    if not timerToken then
        return
    end
    
    local funcName = params[2]
    assert(funcName and funcName ~= "", "function name is nil")
    
    if not self.delayCallTimer[timerToken] or self.delayCallTimer[timerToken] ~= funcName then
        return
    end
    
    Log.DebugFormat("[DialogueV2][DialogueUIProcessor]DelayCall, funcName:%s, timerToken:%s", funcName, timerToken)
    self.panelInterface:InnerCallPanelFunction(funcName, table.unpack(params, 2))
end

---@param timerToken number @ timer token
function DialogueUIProcessor:CancelDeferCall(timerToken)
    Log.DebugFormat("[DialogueV2][DialogueUIProcessor]CancelDeferCall, token:%s", timerToken)
    self:DelTimer(timerToken)
    self.delayCallTimer[timerToken] = nil
end

---@param timeCur number @ 单位：秒
---@param duration  number @ 单位：秒
function DialogueUIProcessor:UpdateDialogueProgress(timeCur, duration)
    if self:HasValidPanel() then
        self.panelInterface:UpdateDialogueProgress(timeCur, duration)
    end
end

function DialogueUIProcessor:HasValidPanel()
    return self.panelInterface and not self.panelInterface.isDestroyed
end

---@public
function DialogueUIProcessor:EnableMysteryMode()
    if self:HasValidPanel() then
        self:AddDisablePanelClickReason(DialogueConst.DISABLE_PANEL_CLICK_REASON.IN_MYSTERY)
        self:SetSkipButtonVisible(DialogueConst.SKIP_BTN_HIDE_REASON.MYSTERY, false)
        self:SetReviewButtonVisible(DialogueConst.REVIEW_BTN_HIDE_REASON.MYSTERY, false)
        self:SetAutoPlayButtonVisible(DialogueConst.AUTO_PLAY_HIDE_REASON.MYSTERY, false)
    end
end

---@public
function DialogueUIProcessor:DisableMysteryMode()
    if self:HasValidPanel() then
        self:DelDisablePanelClickReason(DialogueConst.DISABLE_PANEL_CLICK_REASON.IN_MYSTERY)
        self:SetSkipButtonVisible(DialogueConst.SKIP_BTN_HIDE_REASON.MYSTERY, true)
        self:SetReviewButtonVisible(DialogueConst.REVIEW_BTN_HIDE_REASON.MYSTERY, true)
        self:SetAutoPlayButtonVisible(DialogueConst.AUTO_PLAY_HIDE_REASON.MYSTERY, true)
    end
end

---@param color number
---@param fadeInTime number @ 单位：秒
---@param fadeOutTime number @ 单位：秒
---@param duration number @ 单位：秒
function DialogueUIProcessor:ShowDialogueMask(color, fadeInTime, fadeOutTime, duration)
    if self:HasValidPanel() then
        self.panelInterface:ShowDialogueMask(color, fadeInTime, fadeOutTime, duration)
    end
end

function DialogueUIProcessor:HideDialogueMask()
    if self:HasValidPanel() then
        self.panelInterface:HideDialogueMask()
    end
end

---@public 隐藏/显示 跳过、自动、回顾 按钮
function DialogueUIProcessor:SetDialogueControlPanelVisibilityByReason(bVisible, reason)
	if self:HasValidPanel() then
		self.panelInterface:SetDialogueControlPanelVisibilityByReason(bVisible, reason)
	end
end
