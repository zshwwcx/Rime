---@class DialogueFrameSmoother
---@field public windowSize number
---@field public buffer number[]
---@field public head number
---@field public tail number
---@field public count number
---@field public sum number
---@field public average number
---@field public variance number
---@field public minTime number
---@field public maxTime number
DialogueFrameSmoother = DefineClass("DialogueFrameSmoother")
-- 创建新的帧平滑器
function DialogueFrameSmoother:ctor(windowSize)
    self.windowSize = windowSize or 20 -- 默认20帧窗口
    self.buffer = {}                     -- 环形缓冲区存储帧时间
    self.head = 1                        -- 头部指针
    self.tail = 1                        -- 尾部指针
    self.count = 0                       -- 当前缓冲区中的帧数
    self.sum = 0.0                       -- 当前窗口总和
    self.average = 0.0                   -- 当前平均值
    self.variance = 0.0                  -- 当前方差
    self.minTime = 1e10                 -- 窗口内最小帧时间
    self.maxTime = 0.0                  -- 窗口内最大帧时间

    -- 初始化缓冲区
    for i = 1, self.windowSize do
        self.buffer[i] = 0.0
    end

    return self
end

-- 添加新帧时间并返回平滑值
function DialogueFrameSmoother:Smooth(frameTime)
    -- frameTime永远不能小于0.002秒
    frameTime = math.max(frameTime, 0.002)

    -- 更新极值记录（用于后续自适应）
    if frameTime < self.minTime then 
        self.minTime = frameTime 
    end
    
    if frameTime > self.maxTime then
        self.maxTime = frameTime
    end

    -- 窗口已满时的处理
    if self.count == self.windowSize then
        local oldest = self.buffer[self.head] -- 获取将要移出的旧值

        -- 增量更新平均值
        local delta = frameTime - oldest
        self.average = self.average + delta / self.windowSize

        -- 增量更新方差（避免两次遍历）
        local oldMean = self.average
        local newMean = self.average + delta / self.windowSize

        self.variance = self.variance
            + (frameTime - oldest) * (frameTime + oldest - oldMean - newMean) / self.windowSize
        self.variance = math.max(self.variance, 0) -- 确保方差非负

        -- 更新总和
        self.sum = self.sum - oldest + frameTime
    else
        -- 窗口未满时直接计算
        self.count = self.count + 1
        self.sum = self.sum + frameTime
        self.average = self.sum / self.count

        -- 临时计算方差（当窗口填满后会自动切换到增量计算）
        local tempVar = 0
        for i = 1, self.count do
            local index = (self.head + i - 2) % self.windowSize + 1
            local diff = self.buffer[index] - self.average
            tempVar = tempVar + diff * diff
        end
        self.variance = tempVar / self.count
    end

    -- 更新缓冲区
    self.buffer[self.tail] = frameTime
    self.tail = self.tail % self.windowSize + 1

    if self.count == self.windowSize then
        self.head = self.head % self.windowSize + 1
    end

    -- 自适应窗口调整（每10帧检查一次）
    if self.count % 10 == 0 then
        self:AdaptWindowSize()
    end

    return self.average
end

-- 自适应窗口调整
function DialogueFrameSmoother:AdaptWindowSize()
    local timeRange = self.maxTime - self.minTime

    -- 计算原始窗口比例（0-1范围）
    -- local fillRatio = self.count / self.windowSize

    -- 基于帧时间波动性调整窗口大小
    if self.count == self.windowSize then
        local stddev = math.sqrt(self.variance)
        local stability = stddev / self.average        -- 相对波动系数

        if stability > 0.25 then                       -- 高波动性
            local newSize = math.floor(self.windowSize * 1.3)
            self:ResizeWindow(math.min(newSize, 50)) -- 上限50帧
        elseif stability < 0.05 then                 -- 低波动性
            local newSize = math.floor(self.windowSize * 0.7)
            self:ResizeWindow(math.max(newSize, 5))   -- 下限5帧
        end
    end

    -- 当帧时间范围过大时扩展窗口
    if timeRange > self.average * 0.8 then
        local newSize = math.floor(self.windowSize * 1.2)
        self:ResizeWindow(math.min(newSize, 60))
    end

    -- 重置极值记录
    self.minTime = 1e10
    self.maxTime = 0.0
end

-- 调整窗口大小（内存高效实现）
function DialogueFrameSmoother:ResizeWindow(newSize)
    if newSize == self.windowSize then return end

    -- 创建新缓冲区
    local newBuffer = {}
    local numToCopy = math.min(self.count, newSize)
    -- 从旧缓冲区复制有效数据（保持时序）
    for i = 1, numToCopy do
        local srcIndex = (self.head + i - 1 - 1) % self.windowSize + 1
        newBuffer[i] = self.buffer[srcIndex]
    end

    -- 初始化剩余空间
    for i = numToCopy + 1, newSize do
        newBuffer[i] = 0.0
    end

    -- 更新状态
    self.buffer = newBuffer
    self.windowSize = newSize
    self.head = 1
    self.tail = numToCopy + 1
    self.count = numToCopy
    -- 重新计算统计值
    self.sum = 0
    for i = 1, numToCopy do
        self.sum = self.sum + self.buffer[i]
    end
    self.average = self.sum / numToCopy
end

-- 获取当前统计数据
function DialogueFrameSmoother:Stats()
    return {
        average = self.average,
        variance = self.variance,
        min = self.minTime,
        max = self.maxTime,
        windowSize = self.windowSize,
        fillRate = self.count / self.windowSize
    }
end
