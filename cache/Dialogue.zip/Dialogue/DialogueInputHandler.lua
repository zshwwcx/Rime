---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/7 11:51
---
---@class DialogueInputHandler
DialogueInputHandler = DefineClass("DialogueInputHandler")
