local math = require("math")
-- require "UnLua"


---@class DialogueAutoCameraOffline
DialogueAutoCameraOffline = DefineClass("DialogueAutoCameraOffline")

function DialogueAutoCameraOffline:ctor()
   self:ResetParams()
   self.bHaveFinishCal = false      -- 有无加载完模型能正确计算头部位置
end

-- 单人正打镜头
function DialogueAutoCameraOffline:CalculateCameraParamsOneActor(Actor, IsPlayer)
    self:ResetParams()
    if not Actor then
        return
    end
    self.Actor1 = Actor
    local Actor1Trans = self.Actor1:GetTransform()
    if not Actor1Trans then
        return
    end
    local ActorRotation = Actor1Trans:GetRotation()
    local ActorPosition = self:GetActorTargetPosition(self.Actor1)
    if(ActorPosition == FVector(0, 0, 0)) then
        return
    end
    local RightDist = 1000
    local LeftDist = 0
    local Dist = RightDist
    local DeltaOffset = 0.05
    local MaxCount = 1000
    local CurrentCount = 0

    local SectionData = {}
    SectionData.ActorFocusH = 0.6
    SectionData.ActorFocusV = 0.319
    SectionData.CameraFovX = 30
    SectionData.CameraYaw = -20
    SectionData.CameraPitch = 2
    if IsPlayer then
        SectionData.ActorFocusH = 0.4
        SectionData.CameraYaw = 20
    end

    local BreastPos = self:GetActorBreastPostion(self.Actor1, SectionData.ActorFocusH)
    --眼睛到胸高度差小于25代表是 小模型小孩 为了消除距离放大的视觉误差 需要太高其计算眼部高度
    if ActorPosition.Z - BreastPos.Z < 25 then
        ActorPosition.Z = ActorPosition.Z + 23 - (ActorPosition.Z - BreastPos.Z)
    end
    local CameraPos, CameraRotation, DeltaPos = self:GetOneCameraPosAndRotate(SectionData, ActorPosition, ActorRotation, BreastPos, Dist)

    -- 二分法求解最合适的距离
    while math.abs(DeltaPos) > DeltaOffset do
        if CurrentCount >= MaxCount then
            break
        end
        CurrentCount = CurrentCount + 1
        Dist = (LeftDist + RightDist) / 2
        CameraPos, CameraRotation, DeltaPos = self:GetOneCameraPosAndRotate(SectionData, ActorPosition, ActorRotation, BreastPos, Dist)
        if DeltaPos > 0 then
            RightDist = Dist
        else
            LeftDist = Dist
        end
    end

    Log.DebugFormat("CameraPos: pos: %f, %f, %f rotate: %f, %f, %f dist: %f eye to Breast: %f", CameraPos.X, CameraPos.Y, CameraPos.Z, CameraRotation.Yaw, CameraRotation.Pitch, CameraRotation.Roll, Dist, ActorPosition.Z - BreastPos.Z)
    return CameraPos, CameraRotation, SectionData.CameraFovX
end

-- 单人近景镜头
function DialogueAutoCameraOffline:CalculateCameraParamsOneActorCloseShot(Actor, IsPlayer)
    self:ResetParams()
    if not Actor then
        return
    end
    self.Actor1 = Actor
    local Actor1Trans = self.Actor1:GetTransform()
    if not Actor1Trans then
        return
    end
    local ActorRotation = Actor1Trans:GetRotation()
    local ActorPosition = self:GetActorTargetPosition(self.Actor1)
    if(ActorPosition == FVector(0, 0, 0)) then
        return
    end
    local RightDist = 1000
    local LeftDist = 0
    local Dist = RightDist
    local DeltaOffset = 0.05
    local MaxCount = 1000
    local CurrentCount = 0

    local SectionData = {}
    if not IsPlayer then
        SectionData.CameraFovX = 30
        SectionData.ActorFocusH = 0.6
        SectionData.ActorFocusV = 0.3
        SectionData.CameraYaw = -20
        SectionData.CameraPitch = -2
    else
        SectionData.CameraFovX = 30
        SectionData.ActorFocusH = 0.4
        SectionData.ActorFocusV = 0.3
        SectionData.CameraYaw = 20
        SectionData.CameraPitch = -2
    end


    local TummyPos = self:GetActorTummyPostion(self.Actor1)
    -- 如果表演者有小孩则特殊处理一下裁剪位置
    if self:IsChildModel(self.Actor1) then
        SectionData.CameraPitch = 0
        TummyPos = self:GetActorKneePostion(self.Actor1)
    end

    --眼睛到胸高度差小于25代表是 小模型小孩 为了消除距离放大的视觉误差 需要太高其计算眼部高度
    if ActorPosition.Z - TummyPos.Z < 25 then
        ActorPosition.Z = ActorPosition.Z + 23 - (ActorPosition.Z - TummyPos.Z)
    end
    local CameraPos, CameraRotation, DeltaPos = self:GetOneCameraPosAndRotate(SectionData, ActorPosition, ActorRotation, TummyPos, Dist)

    -- 二分法求解最合适的距离
    while math.abs(DeltaPos) > DeltaOffset do
        if CurrentCount >= MaxCount then
            break
        end
        CurrentCount = CurrentCount + 1
        Dist = (LeftDist + RightDist) / 2
        CameraPos, CameraRotation, DeltaPos = self:GetOneCameraPosAndRotate(SectionData, ActorPosition, ActorRotation, TummyPos, Dist)
        if DeltaPos > 0 then
            RightDist = Dist
        else
            LeftDist = Dist
        end
    end

    return CameraPos, CameraRotation, SectionData.CameraFovX
end



-- 单人中景镜头
function DialogueAutoCameraOffline:CalculateCameraParamsOneActorMidShot(Actor, IsPlayer)
    self:ResetParams()
    if not Actor then
        return
    end
    self.Actor1 = Actor
    local Actor1Trans = self.Actor1:GetTransform()
    if not Actor1Trans then
        return
    end
    local ActorRotation = Actor1Trans:GetRotation()
    local ActorPosition = self:GetActorTargetPosition(self.Actor1)
    if(ActorPosition == FVector(0, 0, 0)) then
        return
    end
    local RightDist = 1000
    local LeftDist = 0
    local Dist = RightDist
    local DeltaOffset = 0.05
    local MaxCount = 1000
    local CurrentCount = 0

    local SectionData = {}
    SectionData.CameraFovX = 37.5
    if not IsPlayer then
        SectionData.ActorFocusH = 0.6
        SectionData.ActorFocusV = 0.3
        SectionData.CameraYaw = -20
        SectionData.CameraPitch = -2
    else
        SectionData.ActorFocusH = 0.4
        SectionData.ActorFocusV = 0.3
        SectionData.CameraYaw = 20
        SectionData.CameraPitch = -2
    end
    local TummyPos = self:GetActorLegRootPostion(self.Actor1)
    if self:IsChildModel(self.Actor1) then
        SectionData.CameraPitch = 0
        TummyPos = self:GetActorKneePostion(self.Actor1)
    end

    --眼睛到胸高度差小于25代表是 小模型小孩 为了消除距离放大的视觉误差 需要太高其计算眼部高度
    if ActorPosition.Z - TummyPos.Z < 25 then
        ActorPosition.Z = ActorPosition.Z + 23 - (ActorPosition.Z - TummyPos.Z)
    end
    local CameraPos, CameraRotation, DeltaPos = self:GetOneCameraPosAndRotate(SectionData, ActorPosition, ActorRotation, TummyPos, Dist)

    -- 二分法求解最合适的距离
    while math.abs(DeltaPos) > DeltaOffset do
        if CurrentCount >= MaxCount then
            break
        end
        CurrentCount = CurrentCount + 1
        Dist = (LeftDist + RightDist) / 2
        CameraPos, CameraRotation, DeltaPos = self:GetOneCameraPosAndRotate(SectionData, ActorPosition, ActorRotation, TummyPos, Dist)
        if DeltaPos > 0 then
            RightDist = Dist
        else
            LeftDist = Dist
        end
    end

    return CameraPos, CameraRotation, SectionData.CameraFovX
end


-- 1V1 正打近景
function DialogueAutoCameraOffline:CalculateCameraParamsTwoActorTypeOne(Talker, Performer, TalkerIsPlayer)
    self:ResetParams()
    if not Talker or not Performer then
        return
    end
    self.Actor1 = Talker
    self.Actor2 = Performer
    local Actor1Trans = self.Actor1:GetTransform()
    local Actor2Trans = self.Actor2:GetTransform()
    if not Actor1Trans or not Actor2Trans then
        return
    end
    local Actor1Rotatation = Actor1Trans:GetRotation()
    local Actor1FacePosition = self:GetActorTargetPosition(self.Actor1)
    local Actor2FacePosition = self:GetActorTargetPosition(self.Actor2)
    if(Actor1FacePosition == FVector(0, 0, 0)) then
        return
    end
    if(Actor2FacePosition == FVector(0, 0, 0)) then
        return

    end
        -- pitch根据眼睛方向做后处理
    local CameraPitch = self:CalculatePitch(Actor1FacePosition, Actor2FacePosition)
    local ActorDistance = self:GetActorDistance(Actor1Trans:GetLocation(), Actor2Trans:GetLocation())
    local SectionData = self:GetSectionDataTwoActorTypeOne(ActorDistance, TalkerIsPlayer, CameraPitch)
    if SectionData == nil then
        return
    end

    local Face2ToFace1Vector = FVector(Actor1FacePosition.X - Actor2FacePosition.X,Actor1FacePosition.Y - Actor2FacePosition.Y, Actor1FacePosition.Z - Actor2FacePosition.Z)
    local Face1ToFace2Rotation = Face2ToFace1Vector:Rotation()
    local fov = SectionData.CameraFovX
    local theta = SectionData.CameraYaw
    local yaw = Face1ToFace2Rotation.Yaw + theta

    self.ActorTwo_Actor1Pos = Actor1FacePosition
    self.ActorTwo_Actor2Pos = Actor2FacePosition
    self.ActorTwo_CameraYaw = yaw
    self.ActorTwo_CameraFovX = fov
    self.ActorTwo_Actor1_H = SectionData.ActorFocusH
    self.ActorTwo_Actor1_V = SectionData.ActorFocusV
    self.ActorTwo_Actor2_H = SectionData.ActorBackendH
    self.ActorTwo_Actor2_V = SectionData.ActorBackendV

    local fov_x = SectionData.CameraFovX
    local TummyPos = self:GetActorTummyPostion(self.Actor1)
    -- 如果表演者有小孩则特殊处理一下裁剪位置
    if self:IsChildModel(self.Actor1) then
        SectionData.CameraPitch = 0
        TummyPos = self:GetActorKneePostion(self.Actor1)
    end
    if self:IsChildModel(self.Actor2) then
        SectionData.CameraPitch = 0
        TummyPos = self:GetActorKneePostion(self.Actor1)
        if TalkerIsPlayer then
            SectionData.ActorBackendH = 0.65
        end
        self.ActorTwo_Actor2_H = SectionData.ActorBackendH
    end
    return self:CalculateByDivided(SectionData, Actor1FacePosition, Actor1Rotatation, TummyPos, Actor2FacePosition, Face2ToFace1Vector, fov_x)
end
  
-- 1V1 正打中景
function DialogueAutoCameraOffline:CalculateCameraParamsTwoActorTypeTwo(Talker, Performer, TalkerIsPlayer)
    self:ResetParams()
    if not Talker or not Performer then
        return
    end
    self.Actor1 = Talker
    self.Actor2 = Performer
    local Actor1Trans = self.Actor1:GetTransform()
    local Actor2Trans = self.Actor2:GetTransform()
    if not Actor1Trans or not Actor2Trans then
        return
    end
    local Actor1Rotatation = Actor1Trans:GetRotation()
    local Actor1FacePosition = self:GetActorTargetPosition(self.Actor1)
    local Actor2FacePosition = self:GetActorTargetPosition(self.Actor2)
    if(Actor1FacePosition == FVector(0, 0, 0)) then
        return
    end
    if(Actor2FacePosition == FVector(0, 0, 0)) then
        return
    end
    local CameraPitch = self:CalculatePitch(Actor1FacePosition, Actor2FacePosition)
    local ActorDistance = self:GetActorDistance(Actor1Trans:GetLocation(), Actor2Trans:GetLocation())
        -- 调整相机的相关参数 应该走配置 这里先写在这里
    local SectionData = self:GetSectionDataTwoActorTypeTwo(ActorDistance, TalkerIsPlayer, CameraPitch)
    if SectionData == nil then
        return
    end
    local Face2ToFace1Vector = FVector(Actor1FacePosition.X - Actor2FacePosition.X,Actor1FacePosition.Y - Actor2FacePosition.Y, Actor1FacePosition.Z - Actor2FacePosition.Z)
    local Face1ToFace2Rotation = Face2ToFace1Vector:Rotation()
    local theta = SectionData.CameraYaw
    local yaw = Face1ToFace2Rotation.Yaw + theta

    self.ActorTwo_Actor1Pos = Actor1FacePosition
    self.ActorTwo_Actor2Pos = Actor2FacePosition
    self.ActorTwo_CameraYaw = yaw
    self.ActorTwo_CameraFovX = SectionData.CameraFovX
    self.ActorTwo_Actor1_H = SectionData.ActorFocusH
    self.ActorTwo_Actor1_V = SectionData.ActorFocusV
    self.ActorTwo_Actor2_H = SectionData.ActorBackendH
    self.ActorTwo_Actor2_V = SectionData.ActorBackendV

    local fov_x = SectionData.CameraFovX
    local TummyPos = self:GetActorLegRootPostion(self.Actor1)
    if self:IsChildModel(self.Actor1) then
        SectionData.CameraPitch = 0
        TummyPos = self:GetActorKneePostion(self.Actor1)
    end
    if self:IsChildModel(self.Actor2) then
        SectionData.CameraPitch = 0
        TummyPos = self:GetActorKneePostion(self.Actor1)
        if TalkerIsPlayer then
            SectionData.ActorBackendH = 0.65
        end
        self.ActorTwo_Actor2_H = SectionData.ActorBackendH
    end
    return self:CalculateByDivided(SectionData, Actor1FacePosition, Actor1Rotatation, TummyPos, Actor2FacePosition, Face2ToFace1Vector, fov_x)
end

function DialogueAutoCameraOffline:CalculateByDivided(SectionData, Actor1FacePosition, Actor1Rotatation, TummyPos, Actor2FacePosition, Face2ToFace1Vector, fov_x)
    local RightDist = 1000
    local LeftDist = 0
    local Dist = RightDist
    local DeltaOffset = 0.05
    local CameraPos, CameraRotation, DeltaPos = self:GetOneCameraPosAndRotate(SectionData, Actor1FacePosition, Actor1Rotatation, TummyPos, Dist)
    local MaxCount = 1000
    local CurrentCount = 0

    -- 二分法先求出距离
    while math.abs(DeltaPos) > DeltaOffset do
        if CurrentCount >= MaxCount then
            break
        end
        CurrentCount = CurrentCount + 1
        Dist = (LeftDist + RightDist) / 2
        CameraPos, CameraRotation, DeltaPos = self:GetOneCameraPosAndRotate(SectionData, Actor1FacePosition, Actor1Rotatation, TummyPos, Dist)
        if DeltaPos > 0 then
            RightDist = Dist
        else
            LeftDist = Dist
        end
    end
    local size =  Game.GameInstance:GetViewportSize()
    local ScreenPosHead = nil
    local LeftYaw = 0
    local RightYaw = 360
    local CurrentYaw = LeftYaw
    local YawDeltaOffset = 0.05
    local DeltaYaw = 0.5
    CurrentCount = 0
    Face2ToFace1Vector.Z = 0
    local ToActor1Dot = 0
    
    -- 二分法求出合适的Yaw
    while true do
        if CurrentYaw == RightYaw then
            break
        end
        CurrentYaw = CurrentYaw + DeltaYaw
        SectionData.CameraYaw = CurrentYaw
        CameraPos, CameraRotation, DeltaPos = self:GetOneCameraPosAndRotate(SectionData, Actor1FacePosition, Actor1Rotatation, TummyPos, Dist)
        ScreenPosHead = self:ProjectWorldToViewport(CameraPos, CameraRotation, fov_x, self.aspect_ratio, Actor2FacePosition, size)
        local CameraToFace1Vector = FVector(Actor1FacePosition.X - CameraPos.X, Actor1FacePosition.Y - CameraPos.Y, 0)
        ToActor1Dot = self:GetVector3Dot(CameraToFace1Vector, Face2ToFace1Vector)
        if ScreenPosHead and math.abs(ScreenPosHead.X - SectionData.ActorBackendH) <= YawDeltaOffset and ToActor1Dot > 0 then
            break
        end
    end
    Log.DebugFormat("CameraPos: pos CalculateCameraParamsTwoActorTypeOne: %f, %f, %f rotate: %f, %f, %f dist: %f ", CameraPos.X, CameraPos.Y, CameraPos.Z, CameraRotation.Yaw, CameraRotation.Pitch, CameraRotation.Roll, Dist)
    return CameraPos, CameraRotation, SectionData.CameraFovX
end

function DialogueAutoCameraOffline:GetSectionDataTwoActorTypeOne(Dist, TalkerIsPlayer, CameraPitch)
    local SectionData = {}
    local FirstDistance = 165
    local FirstFov = 30

    local SecondDistance = 200
    local SecondFov = 23.08

    local ThirdDistance = 300
    local ThirdFov = 18

    local FourthDistance = 400
    local FourthFov = 14

    local FifththDistance = 500
    local FifthFov = 12

    local SixthDistance = 600
    local SixthFov = 9.7

    if not TalkerIsPlayer then
        SectionData.CameraFovX = FirstFov
        SectionData.ActorFocusH = 0.65
        SectionData.ActorFocusV = 0.25
        SectionData.ActorBackendH = 0.1
        SectionData.ActorBackendV = 0.186
        SectionData.CameraYaw = 334
        SectionData.CameraPitch = CameraPitch
    else
        SectionData.CameraFovX = FirstFov
        SectionData.ActorFocusH = 0.3
        SectionData.ActorFocusV = 0.25
        SectionData.ActorBackendH = 0.9
        SectionData.ActorBackendV = 0.186
        SectionData.CameraYaw = 334
        SectionData.CameraPitch = CameraPitch
    end

    if Dist <= FirstDistance then
        SectionData.CameraFovX = FirstFov
    end

    if Dist > FirstDistance and Dist <= SecondDistance then
        local Rate = (Dist - FirstDistance) / (SecondDistance - FirstDistance)
        SectionData.CameraFovX =  FirstFov + Rate * (SecondFov - FirstFov)
    end

    if Dist > SecondDistance and Dist <= ThirdDistance then
        local Rate = (Dist - SecondDistance) / (ThirdDistance - SecondDistance)
        SectionData.CameraFovX = SecondFov + Rate * (ThirdFov - SecondFov)
        if TalkerIsPlayer then
            SectionData.CameraFovX = SecondFov + Rate * (ThirdFov - SecondFov)
            SectionData.ActorBackendH = 0.95
        end
    end

    if Dist > ThirdDistance and Dist <= FourthDistance then
        local Rate = (Dist - ThirdDistance) / (FourthDistance - ThirdDistance)
        SectionData.CameraFovX = ThirdFov - 2 + Rate * (FourthFov - ThirdFov)
        if TalkerIsPlayer then
            SectionData.CameraFovX = ThirdFov - 2 + Rate * (FourthFov - ThirdFov)
            SectionData.ActorBackendH = 0.95
        end
    end

    if Dist > FourthDistance and Dist <= FifththDistance then
        local Rate = (Dist - FourthDistance) / (FifththDistance - FourthDistance)
        SectionData.CameraFovX = FourthFov -4  + Rate * (FifthFov - FourthFov)
        if TalkerIsPlayer then
            SectionData.ActorBackendH = 0.95
        end
    end

    if Dist > FifththDistance and Dist <= SixthDistance then
        local Rate = (Dist - FifththDistance) / (SixthDistance - FifththDistance)
        SectionData.CameraFovX = FifthFov - 4 + Rate * (SixthFov - FifthFov)
    end
    
    local HighToLowRatio = 1.2
    local LowToHighRatio = 0.8
    local CommonPitch = -3
     if SectionData.CameraPitch < 0 then
        SectionData.CameraPitch = SectionData.CameraPitch * HighToLowRatio
    else
        SectionData.CameraPitch = SectionData.CameraPitch * LowToHighRatio
    end
    if ((SectionData.CameraPitch >= 0 or math.abs(SectionData.CameraPitch) < math.abs(CommonPitch)) and Dist < SecondDistance) then
        SectionData.CameraPitch = CommonPitch
    end
    return SectionData
end


function DialogueAutoCameraOffline:GetSectionDataTwoActorTypeTwo(Dist, TalkerIsPlayer, CameraPitch)
    local SectionData = {}
    local FirstDistance = 165
    local FirstFov = 37.4

    local SecondDistance = 200
    local SecondFov = 37.4

    local ThirdDistance = 300
    local ThirdFov = 25.08

    local FourthDistance = 400
    local FourthFov = 21.57

    local FifththDistance = 500
    local FifthFov = 19

    local SixthDistance = 600
    local SixthFov = 17

    if not TalkerIsPlayer then
        SectionData.ActorFocusH = 0.65
        SectionData.ActorFocusV = 0.3
        SectionData.ActorBackendH = 0.3
        SectionData.ActorBackendV = 0.2
        SectionData.CameraYaw = 344
        SectionData.CameraPitch = CameraPitch
    else
        SectionData.ActorFocusH = 0.35
        SectionData.ActorFocusV = 0.3
        SectionData.ActorBackendH = 0.85
        SectionData.ActorBackendV = 0.2
        SectionData.CameraYaw = 344
        SectionData.CameraPitch = CameraPitch
    end

    if Dist <= FirstDistance then
        SectionData.CameraFovX = FirstFov
    end

    if Dist > FirstDistance and Dist <= SecondDistance then
        local Rate = (Dist - FirstDistance) / (SecondDistance - FirstDistance)
        SectionData.CameraFovX = FirstFov + Rate * (SecondFov - FirstFov)
    end
    if Dist > SecondDistance and Dist <= ThirdDistance then
        local Rate = (Dist - SecondDistance) / (ThirdDistance - SecondDistance)
        SectionData.CameraFovX = SecondFov  + Rate * (ThirdFov - SecondFov)
    end


    if Dist > ThirdDistance and Dist <= FourthDistance then
        local Rate = (Dist - ThirdDistance) / (FourthDistance - ThirdDistance)
        SectionData.CameraFovX = ThirdFov - 2 + Rate * (FourthFov - ThirdFov)
    end

    if Dist > FourthDistance and Dist <= FifththDistance then
        local Rate = (Dist - FourthDistance) / (FifththDistance - FourthDistance)
        SectionData.CameraFovX = FourthFov -4  + Rate * (FifthFov - FourthFov)
    end

    if Dist > FifththDistance and Dist <= SixthDistance then
        local Rate = (Dist - FifththDistance) / (SixthDistance - FifththDistance)
         SectionData.CameraFovX = FifthFov - 4 + Rate * (SixthFov - FifthFov)
    end

    local HighToLowRatio = 1.2
    local LowToHighRatio = 0.8
    local CommonPitch = -2.5
     if SectionData.CameraPitch < 0 then
        SectionData.CameraPitch = SectionData.CameraPitch * HighToLowRatio
        if Dist > SecondDistance then
            SectionData.CameraPitch = SectionData.CameraPitch - 1
        end
    else
        SectionData.CameraPitch = SectionData.CameraPitch * LowToHighRatio
        if Dist > SecondDistance then
            SectionData.CameraPitch = SectionData.CameraPitch - 1
        end
    end
    if ((SectionData.CameraPitch >= 0 or math.abs(SectionData.CameraPitch) < math.abs(CommonPitch)) and Dist < SecondDistance) then
        SectionData.CameraPitch = CommonPitch
    end
    return SectionData
end


function DialogueAutoCameraOffline:GetActorDistance(Actor1Pos, Actor2Pos)
    return math.sqrt((Actor1Pos.X - Actor2Pos.X) * (Actor1Pos.X - Actor2Pos.X) + (Actor1Pos.Y - Actor2Pos.Y) * (Actor1Pos.Y - Actor2Pos.Y))
end

function  DialogueAutoCameraOffline:ProjectWorldToViewport(CameraPos, CameraRotation, FOV_X, AspectRatio, WorldLocation, ViewportSize)
    -- 1️⃣ 计算相机旋转矩阵（这里只处理简单情况，完整情况需使用矩阵库）
    local yaw = self:DegreesToRadians(CameraRotation.Yaw)
    local pitch = self:DegreesToRadians(CameraRotation.Pitch)

    -- 计算旋转矩阵的部分（仅简化版，完整版需要3D矩阵运算）
    local cosYaw, sinYaw = math.cos(yaw), math.sin(yaw)
    local cosPitch, sinPitch = math.cos(pitch), math.sin(pitch)

    -- 2️⃣ 计算局部坐标（世界坐标转换到相机坐标）
    local dx = WorldLocation.X - CameraPos.X
    local dy = WorldLocation.Y - CameraPos.Y
    local dz = WorldLocation.Z - CameraPos.Z

    -- 简化版：应用相机旋转（不考虑 roll）
    local LocalX = dx * cosYaw + dy * sinYaw
    local LocalY = -dx * sinYaw + dy * cosYaw
    local LocalZ = dz * cosPitch - LocalX * sinPitch
    LocalX = LocalX * cosPitch + dz * sinPitch

    -- 3️⃣ 判断是否在相机前方
    if LocalX <= 0.0 then
        return nil -- 点在相机后方，返回 nil
    end

    -- 4️⃣ 透视投影
    local tanHalfFOV_X = self:Tan(FOV_X * 0.5)
    local ProjX = LocalY / (LocalX * tanHalfFOV_X)
    local ProjY = LocalZ / (LocalX * tanHalfFOV_X / AspectRatio)

    -- 5️⃣ 归一化到 NDC（0~1）
    local NDC_X = (ProjX + 1.0) * 0.5
    local NDC_Y = (1.0 - (ProjY + 1.0) * 0.5) -- 反转 Y 轴

    return {X = NDC_X, Y = NDC_Y}
end


function DialogueAutoCameraOffline:IsChildModel(Actor)
    local ActorFacePosition = self:GetActorTargetPosition(Actor)
    local ActorFootPosition = self:GetActorFootPostion(Actor)
    return ActorFacePosition.Z - ActorFootPosition.Z < 120
end

function DialogueAutoCameraOffline:CalculatePitch(actor1Pos, actor2Pos)
    local deltaX = actor1Pos.X - actor2Pos.X
    local deltaY = actor1Pos.Y - actor2Pos.Y
    local deltaZ = actor1Pos.Z - actor2Pos.Z

    -- 计算水平距离
    local horizontalDistance = math.sqrt(deltaX * deltaX + deltaY * deltaY)

    -- 计算 Pitch 角度（math.atan2 处理零除问题）
    local pitchRadians = math.atan2(deltaZ, horizontalDistance)

    -- 转换为度
    local pitchDegrees = math.deg(pitchRadians)
    return pitchDegrees 
    
end


function DialogueAutoCameraOffline:GetOneCameraPosAndRotate(SectionData, ActorPosition, ActorRotation, BreastPos, Dist)
    local H = SectionData.ActorFocusH
    local V = SectionData.ActorFocusV  -- 希望人物在图像中的位置比例
    local fov_x = SectionData.CameraFovX
    local camera_rotation = {Yaw = ActorRotation:Euler().Z + 180 + SectionData.CameraYaw, Pitch = SectionData.CameraPitch, Roll = 0}  -- 相机的旋转角度
    local Face1ToCamera = self:GetCameraPostionBYHV(camera_rotation, H, V, fov_x)
    local c_x = math.cos(math.rad(camera_rotation.Pitch)) * math.cos(math.rad(camera_rotation.Yaw))
    local c_y = math.cos(math.rad(camera_rotation.Pitch)) * math.sin(math.rad(camera_rotation.Yaw))
    local c_z = math.sin(math.rad(camera_rotation.Pitch))
    local cosalpha = math.abs(Face1ToCamera.X * c_x + Face1ToCamera.Y * c_y + Face1ToCamera.Z * c_z)
    local CameraPosX = ActorPosition.X + Dist/cosalpha * Face1ToCamera.X
    local CameraPoxY = ActorPosition.Y + Dist/cosalpha * Face1ToCamera.Y
    local CameraPosZ =  ActorPosition.Z + Dist/cosalpha * Face1ToCamera.Z

    local CameraPos = FVector(CameraPosX, CameraPoxY, CameraPosZ)
    local CameraRotation =  FRotator(SectionData.CameraPitch, ActorRotation:Euler().Z + 180 + SectionData.CameraYaw, 0)
    local size =  Game.GameInstance:GetViewportSize()
    local ScreenPos = self:ProjectWorldToViewport(CameraPos, CameraRotation, fov_x, self.aspect_ratio, BreastPos, size)
    if not ScreenPos then
        return CameraPos, CameraRotation, -1
    end
    return CameraPos, CameraRotation, 1- ScreenPos.Y
end


function DialogueAutoCameraOffline:GetActorTargetPosition(Actor) 
    if not IsValid_L(Actor) then
        return
    end
    local USkeletalMeshComponent = Actor:GetMainMesh()
    local LeftEyeLocation = USkeletalMeshComponent:GetSocketLocation("lf_eye_root")
    local RightEyeLocation = USkeletalMeshComponent:GetSocketLocation("rt_eye_root")
    local footposition = self:GetActorFootPostion(Actor)
    -- 有的模型eye获取的高度是异常的 比如人物模型高160 但是eye高度只有20
    if LeftEyeLocation.Z - footposition.Z < 40 or RightEyeLocation.Z - footposition.Z  < 40 then
        return self:GetActorHeadPosition(Actor)
    end
    return FVector((LeftEyeLocation.X + RightEyeLocation.X) / 2, (LeftEyeLocation.Y + RightEyeLocation.Y) / 2, (LeftEyeLocation.Z + RightEyeLocation.Z) / 2)
end

function DialogueAutoCameraOffline:GetActorHeadPosition(Actor) 
    if not IsValid_L(Actor) then
        return
    end
    local USkeletalMeshComponent = Actor:GetMainMesh()
    local NoseLocation = USkeletalMeshComponent:GetSocketLocation("head")

    return FVector(NoseLocation.X, NoseLocation.Y, NoseLocation.Z)
end

function DialogueAutoCameraOffline:GetActorBreastPostion(Actor, H)
    if not IsValid_L(Actor) then
        return
    end
    local USkeletalMeshComponent = Actor:GetMainMesh()
    local LeftBreastPos = USkeletalMeshComponent:GetSocketLocation("Breast_L")
    local RightBreastPos = USkeletalMeshComponent:GetSocketLocation("Breast_R")
    if H >= 0.5 then
        return FVector(RightBreastPos.X, RightBreastPos.Y, RightBreastPos.Z)
    end
    return FVector(LeftBreastPos.X, LeftBreastPos.Y, LeftBreastPos.Z)
end

function DialogueAutoCameraOffline:GetActorTummyPostion(Actor)
    if not IsValid_L(Actor) then
        return
    end
    local USkeletalMeshComponent = Actor:GetMainMesh()
    local TummyPos = USkeletalMeshComponent:GetSocketLocation("spine_02")
    return FVector(TummyPos.X, TummyPos.Y, TummyPos.Z)
end

function DialogueAutoCameraOffline:GetActorKneePostion(Actor)
    if not IsValid_L(Actor) then
        return
    end
    local USkeletalMeshComponent = Actor:GetMainMesh()
    local TummyPos = USkeletalMeshComponent:GetSocketLocation("calf_r")
    return FVector(TummyPos.X, TummyPos.Y, TummyPos.Z)
end

function DialogueAutoCameraOffline:GetActorLegRootPostion(Actor)
    if not IsValid_L(Actor) then
        return
    end
    local USkeletalMeshComponent = Actor:GetMainMesh()
    local LeftPosition = USkeletalMeshComponent:GetSocketLocation("thigh_l")
    local RightPosition = USkeletalMeshComponent:GetSocketLocation("thigh_r")
    return FVector((LeftPosition.X + RightPosition.X) / 2, (LeftPosition.Y + RightPosition.Y) / 2, (LeftPosition.Z + RightPosition.Z) / 2)
end

function DialogueAutoCameraOffline:GetActorFootPostion(Actor)
    if not IsValid_L(Actor) then
        return
    end
    local USkeletalMeshComponent = Actor:GetMainMesh()
    local LeftPosition = USkeletalMeshComponent:GetSocketLocation("foot_r")
    local RightPosition = USkeletalMeshComponent:GetSocketLocation("foot_l")
    return FVector((LeftPosition.X + RightPosition.X) / 2, (LeftPosition.Y + RightPosition.Y) / 2, (LeftPosition.Z + RightPosition.Z) / 2)
end



function DialogueAutoCameraOffline:GetCameraPostionBYHV(CameraRotation, H, V, Fov_x)
    local fov_y = 2 *  math.deg(math.atan(math.tan(math.rad(Fov_x/2)) /self.aspect_ratio))
    local offset_pitch = math.atan(math.tan(math.rad((fov_y / 2)))* (1 - 2 * V))
    local offset_yaw = -math.atan(math.tan(math.rad((Fov_x / 2)))* (1 - 2 * H))
    local tmp_x = 1 / math.cos(offset_pitch) * math.cos(math.rad(CameraRotation.Pitch + math.deg(offset_pitch)))
    local tmp_y = math.tan(offset_yaw)
    local delta_yaw = math.atan(tmp_y / tmp_x)
    local target_yaw = math.rad(CameraRotation.Yaw + math.deg(delta_yaw))
    local target_pitch = math.atan(math.tan(math.rad(CameraRotation.Pitch + math.deg(offset_pitch))) * math.cos(delta_yaw))
    local v_x = -math.cos(target_pitch) * math.cos(target_yaw)
    local v_y = -math.cos(target_pitch) * math.sin(target_yaw)
    local v_z = -math.sin(target_pitch)
    return FVector(v_x, v_y, v_z)
end


-- 定义你的一元函数
function DialogueAutoCameraOffline:FunctionWithDist(Dist)
    local camera_rotation = {Yaw = self.ActorTwo_CameraYaw, Pitch = self.ActorTwo_CameraPitch, Roll = 0}  -- 相机的旋转角度
    local V1 = self:GetCameraPostionBYHV(camera_rotation, self.ActorTwo_Actor1_H, self.ActorTwo_Actor1_V, self.ActorTwo_CameraFovX)
    local O =  self.ActorTwo_Actor1Pos + V1 * Dist
    local Face2ToCamera = self.ActorTwo_Actor2Pos - O
    local Face2ToCamera_Yaw = FVector()
    Face2ToCamera_Yaw.X = Face2ToCamera.X * math.cos(-math.rad(self.ActorTwo_CameraYaw)) - Face2ToCamera.Y * math.sin(-math.rad(self.ActorTwo_CameraYaw))
    Face2ToCamera_Yaw.Y = Face2ToCamera.X * math.sin(-math.rad(self.ActorTwo_CameraYaw)) + Face2ToCamera.Y * math.cos(-math.rad(self.ActorTwo_CameraYaw))
    Face2ToCamera_Yaw.Z = Face2ToCamera.Z
    local Face2ToCamera_Yaw_Pintch = FVector()
    Face2ToCamera_Yaw_Pintch.X = Face2ToCamera_Yaw.X * math.cos(-math.rad(self.ActorTwo_CameraPitch)) - Face2ToCamera_Yaw.Z * math.sin(-math.rad(self.ActorTwo_CameraPitch))
    Face2ToCamera_Yaw_Pintch.Y = Face2ToCamera_Yaw.Y
    Face2ToCamera_Yaw_Pintch.Z = Face2ToCamera_Yaw.X * math.sin(-math.rad(self.ActorTwo_CameraPitch)) + Face2ToCamera_Yaw.Z * math.cos(-math.rad(self.ActorTwo_CameraPitch))
    local H = Face2ToCamera_Yaw_Pintch.Y/Face2ToCamera_Yaw_Pintch.X/math.tan(math.rad(self.ActorTwo_CameraFovX / 2)) * 0.5 + 0.5
    return H - self.ActorTwo_Actor2_H
end

function DialogueAutoCameraOffline:ResetParams()
    self.ActorTwo_Actor1Pos = nil
    self.ActorTwo_Actor2Pos = nil
    self.ActorTwo_CameraYaw = nil
    self.ActorTwo_CameraPitch = nil
    self.ActorTwo_CameraFovX = nil
    self.ActorTwo_Actor1_H = nil
    self.ActorTwo_Actor1_V = nil
    self.ActorTwo_Actor2_H = nil
    self.ActorTwo_Actor2_V = nil
    self.aspect_ratio = 16/9  -- 长宽比
    self.Actor1 = nil
    self.Actor2 = nil
end


-- 定义你的一元函数
function DialogueAutoCameraOffline:FunctionWithPitch(CameraPitch)
    local camera_rotation = {Yaw = self.ActorTwo_CameraYaw, Pitch = CameraPitch, Roll = 0}  -- 相机的旋转角度


    local Actor1ToCamera = self:GetCameraPostionBYHV(camera_rotation, self.ActorTwo_Actor1_H, self.ActorTwo_Actor1_V, self.ActorTwo_CameraFovX)
    local Actor2ToCamera = self:GetCameraPostionBYHV(camera_rotation, self.ActorTwo_Actor2_H, self.ActorTwo_Actor2_V, self.ActorTwo_CameraFovX)

    local Face1ToFace2 = self.ActorTwo_Actor1Pos - self.ActorTwo_Actor2Pos
    local CrossResult = self:GetVector3Cross(Actor1ToCamera, Actor2ToCamera)
    return self:GetVector3Dot(CrossResult, Face1ToFace2)
end


function DialogueAutoCameraOffline:GetVector3Dot(v1, v2)
    return v1.X * v2.X + v1.Y * v2.Y + v1.Z * v2.Z
end

function DialogueAutoCameraOffline:GetVector3Cross(v1, v2)
    local v3 ={x = v1.Y*v2.Z - v2.Y*v1.Z , y = v2.X*v1.Z-v1.X*v2.Z , z = v1.X*v2.Y-v2.X*v1.Y}
    return FVector(v3.x, v3.y, v3.z)
end

function DialogueAutoCameraOffline:DegreesToRadians(deg)
    return deg * math.pi / 180.0
end

function DialogueAutoCameraOffline:Tan(deg)
    return math.tan(self:DegreesToRadians(deg))
end
