
-- 被标记对象类 - 管理单个对象的标签状态
---@class DialogueTaggedObject : LuaClass
---@field private name string
---@field private ownerProxy table @ 使用这个DialogueTaggedObject的对象，弱引用
---@field private tags table<any, boolean> @ 标签数据，key为标签，value为boolean值，true表示生效时执行HasTags回调，false表示生效时执行NoTags回调
---@field private stackTagsForce any[] @ 强制标签栈，优先级高于tags标签
---@field private onHasTagsCallback string|fun(tagObj:DialogueTaggedObject):void @ 当标签列表不为空时的回调函数
---@field private onNoTagsCallback string|fun(tagObj:DialogueTaggedObject):void @ 当标签列表为空时的回调函数
---@field private bWasEmpty boolean @ 是否为空
---@field private bWasStackEmpty boolean @ 强制标签栈是否为空
DialogueTaggedObject = DefineClass("TaggedObject")

local DialogueUtilV2 = kg_require("Gameplay.DialogueV2.DialogueUtilV2").DialogueUtilV2

---@param name string
---@param owner table
---@param onHasTagsCallback string|fun(tagObj:DialogueTaggedObject):void @ 有标签的回调函数
---@param onNoTagsCallback string|fun(tagObj:DialogueTaggedObject):void @ 没有标签的回调函数
function DialogueTaggedObject:ctor(name, owner, onHasTagsCallback, onNoTagsCallback)
    self.name = name
    self.ownerProxy = setmetatable({owner = owner}, {__mode = "v"})

    self.tags = {} 
    self.stackTagsForce = {}
    self.onHasTagsCallback = onHasTagsCallback
    self.onNoTagsCallback = onNoTagsCallback
    self.bWasEmpty = true
    self.bWasStackEmpty = true
end

function DialogueTaggedObject:ToString()
    return string.format("DialogueTaggedObject %s:%s", self.name, tostring(self))
end

-- 添加标签
---@public
---@param tag string
---@return boolean
function DialogueTaggedObject:AddTag(tag, ...)
    if not tag or tag == "" then
        return false
    end

    -- 如果标签已存在，不重复添加
    if self.tags[tag] then
        return false
    end

    self.tags[tag] = true    
    self:checkStateChange(false, ...)
    return true
end

-- 移除标签
---@public
function DialogueTaggedObject:RemoveTag(tag, ...)
    if not tag or not self.tags[tag] then
        return false
    end

    self.tags[tag] = nil
    
    self:checkStateChange(false, ...)
    return true
end

-- 检查是否有某个标签
---@public
---@param tag any
---@return boolean
function DialogueTaggedObject:HasTag(tag)
    return self.tags[tag] ~= nil
end

function DialogueTaggedObject:HasAnyTag()
    return next(self.tags) ~= nil
end

-- 获取所有标签列表
---@public
---@return any[]
function DialogueTaggedObject:GetTags()
    local tagList = {}
    for tag, _ in pairs(self.tags) do
        table.insert(tagList, tag)
    end
    
    return tagList
end

-- 获取标签数量
---@public
---@return number
function DialogueTaggedObject:GetTagCount()
    local count = 0
    for _ in pairs(self.tags) do
        count = count + 1
    end
    return count
end

-- 清空所有标签
---@public
---@param bDoCallback boolean @ 是否执行回调
function DialogueTaggedObject:ClearAllTags(bDoCallback)
    if next(self.tags) == nil then
        return  -- 已经是空的了
    end

    table.clear(self.tags)
    
    if bDoCallback then
        self:checkStateChange(true)
    end
end

-- 检查状态变化并触发相应回调
---@private
---@param forceCheck boolean @  强制进行检查与回调
function DialogueTaggedObject:checkStateChange(forceCheck, ...)
    local func
    local isEmpty = next(self.tags) == nil
    -- 只有当状态真正发生变化时才触发回调
    if forceCheck or self.bWasEmpty ~= isEmpty then
        self.bWasEmpty = isEmpty
        if isEmpty then
            func = self.onNoTagsCallback
        else
            func = self.onHasTagsCallback
        end
    end
    
    local type = type(func)
    if type == 'string' then
        if self.ownerProxy.owner then
            func = self.ownerProxy.owner[func]
        else
            func = nil
        end
    elseif type == 'function' then
    else
        Log.Warning("[DialogueV2][DialogueTaggedObject]Tagged Object: %s has no callback", self.name)
        func = nil
    end

    if func then
        DialogueUtilV2.SafeCall(self, func, self.ownerProxy.owner, ...)
    end
end

-- 设置回调函数
---@public
---@param onHasTagsCallback string|fun(tagObj:DialogueTaggedObject):void @ 有标签的回调函数
---@param onNoTagsCallback string|fun(tagObj:DialogueTaggedObject):void @ 没有标签的回调函数
function DialogueTaggedObject:SetCallbacks(onHasTagsCallback, onNoTagsCallback)
    if onHasTagsCallback then
        self.onHasTagsCallback = onHasTagsCallback
    end
    
    if onNoTagsCallback then
        self.onNoTagsCallback = onNoTagsCallback
    end
end

---@public
---@return string
function DialogueTaggedObject:Dump()
    local insert = table.insert
    
    local t = {}
    for tag, _ in pairs(self.tags) do
        insert(t, tag)
    end
    
    return table.concat(t, ",")
end
