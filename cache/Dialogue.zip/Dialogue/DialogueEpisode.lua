---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/7 14:19
---

local DialogueTrack = kg_require("Gameplay.DialogueV2.DialogueTrack").DialogueTrack
local DialogueOption = kg_require("Gameplay.DialogueV2.DialogueOption").DialogueOption
-- luacheck: push ignore
local DialogueOptionActions = kg_require("Gameplay.DialogueV2.DialogueOptionActions")
local EpState_Init = kg_require("Gameplay.DialogueV2.EpisodeState.EpState_Init").EpState_Init
local EpState_TickTracks = kg_require("Gameplay.DialogueV2.EpisodeState.Epstate_TickTracks").EpState_TickTracks
local EpState_Options = kg_require("Gameplay.DialogueV2.EpisodeState.EpState_Options").EpState_Options
local EpState_SubmitItem = kg_require("Gameplay.DialogueV2.EpisodeState.EpState_SubmitItem").EpState_SubmitItem
local EpState_AcceptQuest = kg_require("Gameplay.DialogueV2.EpisodeState.EpState_AcceptQuest").EpState_AcceptQuest
local EpState_Finish = kg_require("Gameplay.DialogueV2.EpisodeState.EpState_Finish").EpState_Finish
local EpState_WaitCloseUI = kg_require("Gameplay.DialogueV2.EpisodeState.EpState_WaitCloseUI").EpState_WaitCloseUI
-- luacheck: pop ignore

---@class DialogueEpisode : LuaClass
---@field private dialogueInstance DialogueInstanceBase
---@field private options DialogueOption[]
---@field private states table<DialogueEpisodeStateID, EpStateBase>
---@field private curState EpStateBase
---@field private loopTimes number @ 无镜对话循环次数
---@field private tracks DialogueTrack[]
---@field private tracksNeedTick DialogueTrack[]
---@field private bFinish boolean
---@field private bLastEpisode boolean
---@field private showOptions DialogueOption[]
---@field SelectedOptionData DialogueOption
DialogueEpisode = DefineClass("DialogueEpisode")
---@param dialogueInstance DialogueInstanceBase
---@param episodeIdx number
---@param episodeConfig FDialogueEpisode
function DialogueEpisode:ctor(dialogueInstance, episodeIdx, episodeConfig)
    assert(dialogueInstance, "dialogueInstance is nil")
    assert(episodeIdx, "episodeIdx is nil")
    assert(episodeConfig, "episodeConfig is nil")

    ---@type DialogueInstanceBase
    self.dialogueInstance = dialogueInstance
    self.episodeIdx = episodeIdx
    self.episodeConfig = episodeConfig
    self.bLastEpisode = false

    ---暂停标记
    self.bPause = false
    ---结束标记
    self.bFinish = false

    ---@type number @ 播放时长
    self.runningTime = 0

    ---@type number @ 对话实例播放时长
    self.instanceRunningTime = 0

    ---@type number @ 真实世界播放时长
    self.realWorldTime = 0

    ---@type DialogueTrack[]
    self.tracks = {}

    ---@type DialogueOption[]
    self.options = {}
	
	---@type boolean 是否处于特殊交互阶段(选项、QTE、提交道具、领取任务)
	self.bInStopPoint = false

    ---@type number
    self.loopTimes = episodeConfig.LoopTimes

    local EPISODE_STATE = DialogueConst.EPISODE_STATE
    self.states = {
        [EPISODE_STATE.EP_STATE_INIT] = EpState_Init.new(self, EPISODE_STATE.EP_STATE_INIT),
        [EPISODE_STATE.EP_STATE_TICKTRACKS] = EpState_TickTracks.new(self, EPISODE_STATE.EP_STATE_TICKTRACKS),
        [EPISODE_STATE.EP_STATE_PAUSE_SUB_OPTIONS] = EpState_Options.new(self, EPISODE_STATE.EP_STATE_PAUSE_SUB_OPTIONS),
        [EPISODE_STATE.EP_STATE_PAUSE_SUB_SUBMITTING_ITEM] = EpState_SubmitItem.new(self,
            EPISODE_STATE.EP_STATE_PAUSE_SUB_SUBMITTING_ITEM),
        [EPISODE_STATE.EP_STATE_PAUSE_SUB_ACCEPTING_QUEST] = EpState_AcceptQuest.new(self,
            EPISODE_STATE.EP_STATE_PAUSE_SUB_ACCEPTING_QUEST),
        [EPISODE_STATE.EP_STATE_FINISH] = EpState_Finish.new(self, EPISODE_STATE.EP_STATE_FINISH),
        [EPISODE_STATE.EP_STATE_WAIT_CLOSE_UI] = EpState_WaitCloseUI.new(self, EPISODE_STATE.EP_STATE_WAIT_CLOSE_UI),
    }
end

function DialogueEpisode:dtor()
    Game.GlobalEventSystem:RemoveTargetAllListeners(self)
end

function DialogueEpisode:ToString()
    return string.format("Episode[%s] in %s", self.episodeIdx, self.dialogueInstance:ToString())
end

---@public
function DialogueEpisode:Init()
    Log.DebugFormat("[DialogueV2]Init %s", self:ToString())

    self.tracksNeedTick = {}
    -- 创建所有Track
    local allTrackConfigs = self.dialogueInstance:GetAllTrackConfigsInEpisode(self.episodeIdx)
    local insert = table.insert
    for _, trackConfig in ipairs(allTrackConfigs) do
        ---@type DialogueTrack
        local newTrack = DialogueTrack.new(self.dialogueInstance, trackConfig)
        newTrack:Init()
        insert(self.tracks, newTrack)

        if (trackConfig.ActionSections and #trackConfig.ActionSections > 0)
            or (trackConfig.Actions and #trackConfig.Actions > 0) then
            insert(self.tracksNeedTick, newTrack)
        end
    end
    
    -- 初始化所有选项
    self:InitDialogueOptions()

    -- 检查是否为最后一个小段
    -- 注意：最后一个小段是对话逻辑的最后一阶段，不是Episode数组的最后一个
    -- 最后一个小段的判定条件（二选一）：
    -- 1. 没有选项了
    -- 2. 所有选项的都没有跳转到其他小段
    local bLastEpisode = true
    local options = self:GetEpisodeOptions()
    ---@param option DialogueOption
    for _, option in pairs(options) do
        if option:GetTargetEpisodeID() > 0 then
            bLastEpisode = false
            break
        end
    end
    
    self.bLastEpisode = bLastEpisode

    self.curState = self.states[DialogueConst.EPISODE_STATE.EP_STATE_INIT]
    self.curState:Enter()
    self:TransitState()
end

function DialogueEpisode:TransitState()
    local curState = self.curState
    if not curState then
        return
    end

    -- 这里使用循环的原因是有些state会在enter的时候就执行完毕，后续不再需要Tick
    -- 那么可以将这些state的tick直接跳过，立即切换到下一个状态，保证对话逻辑不会
    -- 因为这些无意义的Tick导致穿帮/空镜等问题
    while (curState and curState:CanTransit()) do
        local nextStateId = curState:GetNextStateId()
        if nextStateId ~= self.curState.stateId then
            local preStateId = curState.stateId
            curState:Exit()

            curState = self.states[nextStateId]
            self.curState = curState
            if curState then
                curState:Enter(preStateId)
            end
        end
    end
end

--------------------------------------------------------- REGION Options ----------------------------------------------
---@type fun(): nil 初始化所有Dialogue选项
function DialogueEpisode:InitDialogueOptions()
    -- 清理options
    self.options = {}
    -- 展示options
    self.showOptions = {}
    -- 初始化options
    local EpisodeOptions = self.episodeConfig.Options
    for i = 1, #EpisodeOptions do
        ---@type DialogueOption
        local OptionInstance = DialogueOption.new()
        OptionInstance:InitData(self, EpisodeOptions[i], i)
        table.insert(self.options, OptionInstance)
    end
end

---@type fun(): table 获取Dialogue的所有可见选项
function DialogueEpisode:GetEpisodeOptions()
    table.clear(self.showOptions)
    
    ---@type DialogueHistory
    local history = Game.DialogueManagerV2.DialogueHistory
    
    ---@param option DialogueOption
    for index, option in ipairs(self.options) do
        local OptionData = self.episodeConfig.Options[index]
        option.EpisodeID = OptionData.EpisodeID
        option.DialogueLineIdx = OptionData.DialogueLineIndex

        -- 如果已经选过该option，并且配置了选择后隐藏，则过滤
        if option.OptionID ~= 0 and history:HasSelectedOption(option.OptionID) and option:HideWhenPassed() then
			-- 浮动选项保留，固定选项剔除
			if self.episodeConfig.OptionType == 1 then
				option.HasBeenSelected = true
			else
				goto continue
			end
        end
        
        -- 更新option的state数据(之前的逻辑有冗余，可以合并优化到一个函数里面去)
        option:SetOptionState(option:CheckOptionConditionValid(OptionData.Condition))
        option.OptionText = Game.NPCManager.GetFormatTalkText(option.OptionTextCfg)
        option.Order = index

        if option:IsLock() then
            --该选项被锁定，去选项表查询这个选项释放应该显示, (只有浮动选项可以,普通选项配置了也不会生效)
            if (option.LockVisible == 1) and (self.episodeConfig.OptionType == 1) then
                --锁定的时候也显示
                --获取锁定状态的文本
                if option.LockText ~= "" then
                    option.OptionText = Game.NPCManager.GetFormatTalkText(option.LockText)
                end
                table.insert(self.showOptions, option)
                Log.DebugFormat("[DialogueV2]Show Option %s", option.OptionText)
            else
                --锁定的时候不显示，则不添加这个选项到UI
            end
        else
            table.insert(self.showOptions, option)
            Log.DebugFormat("[DialogueV2]Show Option %s", option.OptionText)
        end
        :: continue ::
    end

    return self.showOptions
end

---@type fun(): nil 展示选项
function DialogueEpisode:ShowDialogueOptions()
    -- 通过DialogueManagerV2.UIProcessor 拉起WBP_Dialogue，显示UI数据
    Game.DialogueManagerV2.UIProcessor:ShowDialogueOptions(self.showOptions, self.episodeConfig.OptionType,
        self.episodeConfig.TimeLimit ~= 0, self.episodeConfig.TimeLimit, self.episodeConfig.TimeOutDefaultChoice)

    -- 开始展示选项逻辑，暂停Episode track Tick后的逻辑
    self:SetInOptionProcess(true)
end

function DialogueEpisode:SetInOptionProcess(bResult)
    Log.DebugFormat("[DialogueV2][DialogueEpisode]SetInOptionProcess %s", bResult)
    self.bInOptionProcess = bResult
    --if bResult then
    --    self.dialogueInstance:AddDialogueBarrier(DialogueConst.BARRIER_TYPE.WAIT_SELECT_OPTION)
    --end
end

function DialogueEpisode:OnSelectOption(Index)
    local SelectedOptionData = self.options[Index]
    self.SelectedOptionData = SelectedOptionData
    SelectedOptionData:SetOptionState(DialogueConst.OptionState.Passed)

    -- 通知倒计时系统停止
    local systemCountDown = Game.NPCCountDownSystem
    xpcall(systemCountDown.OnDialogueChoiceMade, _G.CallBackError, systemCountDown)

    Game.DialogueManagerV2.DialogueHistory:Record(
        DialogueConst.HISTORY_ITEM_TYPE.OPTION, SelectedOptionData.OptionText, 
        "", "", SelectedOptionData.OptionID)

    Game.DialogueManagerV2:SetLastOptionSelected(SelectedOptionData.OptionID, Index)
    -- 执行额外的行为
    if SelectedOptionData.ExtraAction and ksbcnext(SelectedOptionData.ExtraAction) then
        SelectedOptionData:executeExtraAction(SelectedOptionData.ExtraAction)
    end

    local uiProcessor = Game.DialogueManagerV2.UIProcessor
    uiProcessor:SetReviewButtonVisible(DialogueConst.REVIEW_BTN_HIDE_REASON.NORMAL, true)
    uiProcessor:SetSkipButtonVisible(DialogueConst.SKIP_BTN_HIDE_REASON.NORMAL, true)
    -- 已经选择过选项，关闭掉选项UI
    uiProcessor:OnSelectOption()

    Game.DialogueManagerV2.DialogueHistory:AddSelectOption(SelectedOptionData.OptionID,
        self.dialogueInstance.DialogueID)

    -- 选项部分逻辑结束，恢复Episode的Tick逻辑
    self:SetInOptionProcess(false)
end

function DialogueEpisode:ExecuteSelectOption(SelectedOptionData)
    if SelectedOptionData and SelectedOptionData.bClose == true then
        -- 如果配置了关闭,则直接关闭
        Log.DebugFormat("[DialogueV2][OnSelectOption] %d directly finish", SelectedOptionData.OptionID)
        self.dialogueInstance:Deactivate()
        return
    end

    local NextEpisodeRef = self.dialogueInstance:GetEpisodeByIndex(SelectedOptionData.EpisodeID)
    if not NextEpisodeRef then
        --未找到合法的Episode数据
        local NextEpisodeIndex = self.dialogueInstance:GetCurEpisodeIndex() + 1
        Log.WarningFormat(
            "[DialogueV2]Dialogue %s has no valid episode %d, Cur Selected OptionID is %s. Please check the validity of the data",
            tostring(self.dialogueInstance.DialogueID), NextEpisodeIndex, tostring(SelectedOptionData.OptionID))
		self.dialogueInstance:Deactivate()
        return
    end

    --TOOD: 在这里发送一个事件，告诉外部系统玩法，比如阿罗德斯对话玩法，此时外部系统可以借机填充对话数据
    --Game.GlobalEventSystem:Publish(EEventTypesV2.DIALOGUE_ON_SELECT_OPTION, SelectedOptionData.OptionID, Game.DialogueManagerV2.OptionTalkID, Game.DialogueManagerV2.DialogueTable)

    self.dialogueInstance:PlayEpisode(SelectedOptionData.EpisodeID, SelectedOptionData.DialogueLineIdx)
end

--------------------------------------------------------- REGION Options End ----------------------------------------------

---@public
function DialogueEpisode:UnInit()
    Log.InfoFormat("[DialogueV2]UnInit: %s", self:ToString())

    -- 小段结束的时候检查是否有没处理的消息
    local flowchartMsgList = self.dialogueInstance:GetBlackBoardValue(DialogueConst.BlackBoardKey.FLOWCHART_MSG)
    if (flowchartMsgList ~= nil) and (Game.me ~= nil) then
        for _, msg in pairs(flowchartMsgList) do
            Log.InfoFormat("[DialogueV2][checkLogicBeforeFinish] send flowchart msg:%s", msg)
            Game.me:ReqClientAIMessage(msg)
        end

        self.dialogueInstance:SetBlackBoardValue(DialogueConst.BlackBoardKey.FLOWCHART_MSG, nil)
    end

    local curState = self.curState
    if curState and curState:IsActive() then
        curState:Exit()
    end

    for _, track in pairs(self.tracks) do
        track:UnInit()
        track:delete()
    end
    table.clear(self.tracks)

    ---- 清理所有options
    --for _, option in pairs(self.options) do
    --    option:UnInit()
    --end
    table.clear(self.options)

    -- 如果销毁比 UI_CLOSE早的话，也需要把listener清理掉
    Game.GlobalEventSystem:RemoveListener(EEventTypesV2.ON_UI_CLOSE, "OnCloseUI", self)
end

---@public
---@param runningTime number @ 当前小段运行时间， 单位：秒
---@param instanceRunningTime number @ 当前对话运行时间，单位：秒
---@param realWorldTime number @ 当前真实世界时间，单位：秒
function DialogueEpisode:SetTime(runningTime, instanceRunningTime, realWorldTime)
    self.runningTime = runningTime
    self.instanceRunningTime = instanceRunningTime
    self.realWorldTime = realWorldTime
end

---@public
---@param deltaTime number
---@param bSkip boolean
function DialogueEpisode:Tick(deltaTime, bSkip)
    self.curState:OnTick(deltaTime, bSkip)
    self:TransitState()
end

--function DialogueEpisode:CheckDialogueSubmit()
--    return self.dialogueInstance.PlayParams.SubmitItemID or self.dialogueInstance.PlayParams.NewSubmitCfg
--end

--function DialogueEpisode:ShowSubmitItemPanel()
--    Game.GlobalEventSystem:AddListener(EEventTypesV2.ON_UI_CLOSE, "OnCloseUI", self)
--    self.WaitCloseUI = UIPanelConfig.SubmitNew_Panel
--    Log.DebugFormat("[DialogueV2]execute SubmitItem function, now open %s", self.WaitCloseUI)
--    local submitParam = self.dialogueInstance.PlayParams
--    ---@type ItemSubmitCompatibleParams
--    local realSubmitParam = {
--        ItemSubmitID = submitParam.SubmitItemID,
--        TaskRingID = submitParam.TaskRingID,
--        QuestID = submitParam.QuestID,
--        CondIdx = submitParam.CondIdx,
--        NewSubmitCfg = submitParam.NewSubmitCfg,
--        OpIdx = self.LastOpIdx or 1,
--    }
--    Game.ItemSubmitSystem:ShowItemSubmitUICompatible(realSubmitParam)
--end

--function DialogueEpisode:OnCloseUI(UIName)
--    if self.WaitCloseUI == UIName then
--        Log.DebugFormat("[DialogueV2][DialogueEpisode] OnCloseUI %s.", UIName)
--        Game.GlobalEventSystem:RemoveListener(EEventTypesV2.ON_UI_CLOSE, "OnCloseUI", self)
--        self.WaitCloseUI = nil
--        self.dialogueInstance:Deactivate()
--    end
--end

--function DialogueEpisode:ShowReceiveRingPanel()
--    Game.GlobalEventSystem:AddListener(EEventTypesV2.ON_UI_CLOSE, "OnCloseUI", self)
--    self.WaitCloseUI = UIPanelConfig.TaskAcceptPanel
--    local receiveRingID = self.dialogueInstance.PlayParams.ReceiveRingID
--    local npcCfgID = self.dialogueInstance.PlayParams.NPCID
--    Log.DebugFormat("[DialogueV2][DialogueEpisode] execute Receive Ring function, now open %s RingID is %d", UIName, receiveRingID)
--    Game.NewUIManager:OpenPanel(self.WaitCloseUI, receiveRingID, npcCfgID or 0, self.dialogueInstance.DialogueID)
--end

--function DialogueEpisode:DealWithDialogueOptionsLogic()
--    if #self.showOptions > 0 then
--        local bOptionHasBeenAutoDone = false
--        -- 检查对话选项中是否存在DialogueID == 0的存在，如果有的话，则无需点击，判断condition后直接执行option对应的action
--        for _, option in ipairs(self.showOptions) do
--            if option.OptionID == 0 then
--                option:SetOptionState(option:CheckOptionConditionValid(option.Condition))
--                if option:IsUnlock() then
--                    self.dialogueInstance:CreateNewEpisode(option.EpisodeID, option.DialogueLineIdx)
--                    bOptionHasBeenAutoDone = true
--                    break
--                end
--            end
--        end
--        -- 没有任何自动执行的选项逻辑，开始正常的选项展示了
--        if not bOptionHasBeenAutoDone then
--            self:ShowDialogueOptions()
--        end
--    end
--end

---@public
---@return number
function DialogueEpisode:GetEpisodeIndex()
    return self.episodeIdx
end

---@public
---@return number
function DialogueEpisode:GetRemainTime()
    return self.episodeConfig.Duration - self.runningTime
end
---@public
---@return number
function DialogueEpisode:GetDuration()
    local duration = 0
    
    local config = self.episodeConfig
    if config ~= nil and config.Duration ~= nil then
        duration = config.Duration
    end

    return duration
end

---从指定时间点开始播放对话小段
---@public
---@param startTime number|nil 不传则默认从0开始
---@return number
function DialogueEpisode:StartEpisodeFromSpecificTime(startTime)
    startTime = startTime or 0

    -- 传入时间非法
    if (startTime < 0) or (self:GetDuration() < startTime) then
        Log.ErrorFormat("[DialogueV2][StartEpisodeFromSpecificTime] illegal start time %s", startTime)
        return
    end

    self.startTime = startTime
    Log.InfoFormat("[DialogueV2]StartEpisodeFromSpecificTime %s startTime=%s", self:ToString(), startTime)

    -- 如果不是从0开始的,需要先Tick到对应时间
    if self.startTime > 0 then
        self:JumpToSpecificTime(startTime)
    end
    return self.startTime
end

---从第几句台本开始播放对话小段
---@public
---@param lineIndex number
---@return number
function DialogueEpisode:StartEpisodeFromLineIndex(lineIndex)
    Log.InfoFormat("[DialogueV2][StartEpisodeFromLineIndex] try start episode %s from %s", self:ToString(), lineIndex)
    local startTime = 0
    local sectionConfigs = self:getDialogueSectionConfigs()
    if (sectionConfigs ~= nil) and (lineIndex <= #sectionConfigs) then
        local targetSection = sectionConfigs[lineIndex]
        startTime = targetSection.StartTime
    else
        Log.WarningFormat("[DialogueV2][StartEpisodeFromLineIndex] invalid line index %s in %s", lineIndex, self:ToString())
    end

    -- 记录下，当前处于批量跳过的状态
    self.dialogueInstance:SetBlackBoardValue(DialogueConst.BlackBoardKey.DIALOGUE_JUMP_SKIP, true)
    self:StartEpisodeFromSpecificTime(startTime)
    self.dialogueInstance:SetBlackBoardValue(DialogueConst.BlackBoardKey.DIALOGUE_JUMP_SKIP, false)
    return startTime
end

---@public
function DialogueEpisode:PauseEpisode()
    self.bPause = true

    for _, track in pairs(self.tracks) do
        track:PauseTrack()
    end
end

---@public
function DialogueEpisode:ResumeEpisode()
    self.bPause = false

    for _, track in pairs(self.tracks) do
        track:ResumeTrack()
    end
end

---获取当前小段一共有几句台本
---@private
---@return table[]
function DialogueEpisode:getDialogueSectionConfigs()
    for _, trackConfig in ksbcipairs(self.episodeConfig.TrackList) do
        if trackConfig.ObjectClass == DialogueConst.DIALOGUE_TRACK_TYPE.DIALOGUE then
            return trackConfig.ActionSections
        end
    end

    return nil
end

---@return number
function DialogueEpisode:GetLoopTimes()
    return self.loopTimes
end

---@param inLoopTimes number
function DialogueEpisode:SetLoopTimes(inLoopTimes)
    self.loopTimes = inLoopTimes
end

-- 直接跳转到指定的时间轴位置
function DialogueEpisode:JumpToSpecificTime(specificTime)
	local NeedDealSectionList = {}
	for _, track in ipairs(self.tracks) do
		track:SetTime(self.runningTime, self.instanceRunningTime, self.realWorldTime)
		local sectionList = track:JumpToSpecificTime(specificTime)
		for _, section in ipairs(sectionList) do
			table.insert(NeedDealSectionList, section)
		end
	end

	if (next(NeedDealSectionList)) then
		table.sort(NeedDealSectionList, function(a, b)
			return a.sectionConfig.StartTime < b.sectionConfig.StartTime
		end)

		for _, section in ipairs(NeedDealSectionList) do
			if not section.isDestroyed then
				section:JumpToSpecificTime(specificTime)
				--section:SetJumped(true)
			end
		end
	end
end

function DialogueEpisode:TerminateDialogueEpisodeByJump()
	for index, track in ipairs(self.tracks) do
		track:TerminateDialogueTrackByJump()
	end
end

function DialogueEpisode:CheckInStopPoint()
	return self.bInStopPoint
end

function DialogueEpisode:SetStopPoint(bInStopPoint)
	self.bInStopPoint = bInStopPoint
end

function DialogueEpisode:CheckDialogueSubmit()
   if not self.bLastEpisode then
      return false
   end
    
    local dialogueInstance = self.dialogueInstance
    if dialogueInstance == nil or dialogueInstance.isDestroyed then
        return false
    end
    
    return dialogueInstance:CheckDialogueSubmit()
end

function DialogueEpisode:CheckAcceptQuest()
    if not self.bLastEpisode  then
        return false
    end

    local dialogueInstance = self.dialogueInstance
    if dialogueInstance == nil or dialogueInstance.isDestroyed then
        return false
    end

    return dialogueInstance:CheckAcceptQuest()
end

function DialogueEpisode:IsFinished()
    return self.bFinish
end 

function DialogueEpisode:OnFinish()
    Log.InfoFormat("[DialogueV2]Episode OnFinish:%s", self:ToString())
    local endReason = DialogueConst.SECTION_FINISH_REASON.TERMINATE 
    for _, track in pairs(self.tracks) do
        track:Finish(endReason)
    end
end 