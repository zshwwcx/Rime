local EpisodeStateBase = kg_require("Gameplay.DialogueV2.EpisodeState.EpStateBase").EpStateBase
---@class EpState_Finish : EpStateBase
EpState_Finish = DefineClass("EpState_Finish", EpisodeStateBase)

--function EpState_Finish:ctor(episode, epStateId)
--end

function EpState_Finish:OnEnter(preStateId)
    local episode = self.episode
    episode.bFinish = true
    episode:OnFinish()
    
    local instance = episode.dialogueInstance
    if instance and not instance.isDestroyed then
        -- 将未停止的摄像机震动停止
        local blackboardKey = DialogueConst.BlackBoardKey.CAMERA_HANDHELD_TOKEN
        local curCameraHandheldToken = instance:GetBlackBoardValue(blackboardKey)
        if curCameraHandheldToken then
            Game.CameraManager:StopCameraShakeByToken(curCameraHandheldToken)
            instance:SetBlackBoardValue(blackboardKey, nil)
            Log.DebugFormat("[SimHandheldCamera]episode finished, stop shake:%s", curCameraHandheldToken)
        end
        
        -- 取消之前设定的延迟隐藏台本
        local token = instance:GetBlackBoardValue(DialogueConst.BlackBoardKey.PENDING_HIDE_LINE)
        if token then
            Game.DialogueManagerV2.UIProcessor:CancelDeferCall(token)
            Game.DialogueManagerV2.UIProcessor:CallPanelFunction(DialogueConst.PanelFunction.HideContent)
            instance:SetBlackBoardValue(DialogueConst.BlackBoardKey.PENDING_HIDE_LINE, nil)
        end
    end
end


function EpState_Finish:CanTransit()
    return false
end

function EpState_Finish:GetNextStateId()
    return nil
end
