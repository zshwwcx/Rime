---@class EpStateBase
---@field public episode DialogueEpisode
---@field public stateId DialogueEpisodeStateID
---@field public bActive boolean
EpStateBase = DefineClass("EpStateBase")
function EpStateBase:ctor(episode, epStateId)
    self.episode = episode
    self.stateId = epStateId
    self.bActive = false
end

---@return boolean
function EpStateBase:IsActive()
    return self.bActive
end

function EpStateBase:Enter(preStateId)
    Log.InfoFormat("[DialogueV2]DialogueEpisode Enter EpState: %s in %s", self.__cname, self.episode:ToString())
    self.bActive = true
    self:OnEnter(preStateId)    
end

---@param preStateId DialogueEpisodeStateID
function EpStateBase:OnEnter(preStateId)
end

---@param deltaTime number
---@param bSkip boolean
function EpStateBase:OnTick(deltaTime, bSkip)
end

function EpStateBase:Exit()
    Log.InfoFormat("[DialogueV2]DialogueEpisode Exit EpState: %s in %s", self.__cname, self.episode:ToString())
    self:OnExit()
    self.bActive = false
end

function EpStateBase:OnExit()
end

function EpStateBase:CanTransit()
    return true
end

---@return DialogueEpisodeStateID
function EpStateBase:GetNextStateId()
end
