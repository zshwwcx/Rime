local EpisodeStateBase = kg_require("Gameplay.DialogueV2.EpisodeState.EpStateBase").EpStateBase
---@class EpState_AcceptQuest : EpisodeStateBase
EpState_AcceptQuest = DefineClass("EpState_AcceptQuest", EpisodeStateBase)
--function EpState_AcceptQuest:ctor(episode, epStateId)
--end

function EpState_AcceptQuest:OnEnter(preStateId)
    self.WaitCloseUI = UIPanelConfig.TaskAcceptPanel
    Game.GlobalEventSystem:AddListener(EEventTypesV2.ON_UI_CLOSE, "OnCloseUI", self)
    local episode = self.episode
    local dialogueInstance = episode.dialogueInstance

    local token = dialogueInstance:GetBlackBoardValue(DialogueConst.BlackBoardKey.PENDING_HIDE_LINE)
    if token then
        Game.DialogueManagerV2.UIProcessor:CancelDeferCall(token)
        dialogueInstance:SetBlackBoardValue(DialogueConst.BlackBoardKey.PENDING_HIDE_LINE, nil)
    end
    
    local receiveRingID = dialogueInstance.PlayParams.ReceiveRingID
    local npcCfgID = dialogueInstance.PlayParams.NPCID
    Log.InfoFormat("[DialogueV2]EpState_AcceptQuest open %s RingID is %d in %s", self.WaitCloseUI, receiveRingID, self.episode:ToString())
    Game.NewUIManager:OpenPanel(UIPanelConfig.TaskAcceptPanel, receiveRingID, npcCfgID or 0, dialogueInstance.DialogueID)
end

function EpState_AcceptQuest:OnExit()
    Game.GlobalEventSystem:RemoveListener(EEventTypesV2.ON_UI_CLOSE, "OnCloseUI", self)
end

function EpState_AcceptQuest:CanTransit()
    return self.WaitCloseUI == nil
end

function EpState_AcceptQuest:GetNextStateId()
    return DialogueConst.EPISODE_STATE.EP_STATE_FINISH
end

function EpState_AcceptQuest:OnCloseUI(uid)
    if uid == self.WaitCloseUI then
        self.WaitCloseUI = nil
    end
end
