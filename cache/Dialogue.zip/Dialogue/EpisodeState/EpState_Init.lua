local EpStateBase = kg_require("Gameplay.DialogueV2.EpisodeState.EpStateBase").EpStateBase
---@class EpState_Init:EpStateBase
EpState_Init = DefineClass("EpState_Init", EpStateBase)
--function EpState_Init:ctor(episode, epStateId)
--end

function EpState_Init:OnEnter(preStateId)
end

function EpState_Init:CanTransit()
    return true
end

function EpState_Init:GetNextStateId()
    return DialogueConst.EPISODE_STATE.EP_STATE_TICKTRACKS
end
