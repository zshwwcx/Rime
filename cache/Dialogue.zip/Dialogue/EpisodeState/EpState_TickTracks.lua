local EpStateBase = kg_require("Gameplay.DialogueV2.EpisodeState.EpStateBase").EpStateBase

---@class EpState_TickTracks : EpStateBase
---@field private episode DialogueEpisode
---@field private stateId DialogueEpisodeStateID
EpState_TickTracks = DefineClass("EpState_TickTracks", EpStateBase)
function EpState_TickTracks:ctor(episode, epStateId)
    self.episode = episode
    self.stateId = epStateId
end

---@param preStateId DialogueEpisodeStateID
function EpState_TickTracks:OnEnter(preStateId)
    self.bIsDone = false
end

---@param deltaTime number
---@param bSkip boolean
function EpState_TickTracks:OnTick(deltaTime, bSkip)
    local episode = self.episode
    if episode.bPause then
        return
    end

    local tracks = episode.tracksNeedTick
    -- 这里分为3tick的原因是已经启动的section会暂停对话或者插入barrier，会影响对话后续section的执行，所以需要一次性将所有启动
    -- 的section全部tick完毕，然后再启动需要启动的section，最后检查track上的section是否都完成，决定TickTrack状态是否需要结束。
    -- ！！！注意这个顺序不能乱改！！！
    -- 首先对已经启动的section进行tick
    for _, track in ipairs(tracks) do
        track:SetTime(episode.runningTime, episode.instanceRunningTime, episode.realWorldRunningTime)
        track:TickRunningSections(deltaTime, bSkip)
    end
    
    -- 启动未启动的section
    for _, track in ipairs(tracks) do
        track:StartSections(bSkip)
    end

    -- 检查所有track是否完成
    local bAllTrackDone = true
    for _, track in ipairs(tracks) do
        if not track:IsDone() then
            bAllTrackDone = false
        end
    end

    if bAllTrackDone or self.episode:GetRemainTime() <= 0 then
        self.bIsDone = true
    end
end

function EpState_TickTracks:OnExit()
end

function EpState_TickTracks:CanTransit()
    return not self.episode.bPause and self.bIsDone
end

---@return IDialogueStateID
function EpState_TickTracks:GetNextStateId()
    local episode = self.episode
    if next(episode:GetEpisodeOptions()) then
        return DialogueConst.EPISODE_STATE.EP_STATE_PAUSE_SUB_OPTIONS
    elseif episode:CheckDialogueSubmit() then
        return DialogueConst.EPISODE_STATE.EP_STATE_PAUSE_SUB_SUBMITTING_ITEM
    elseif episode:CheckAcceptQuest() then
        return DialogueConst.EPISODE_STATE.EP_STATE_PAUSE_SUB_ACCEPTING_QUEST
    else
        return DialogueConst.EPISODE_STATE.EP_STATE_FINISH
    end
end
