local EpStateBase = kg_require("Gameplay.DialogueV2.EpisodeState.EpStateBase").EpStateBase
---@class EpState_SubmitItem : EpStateBase
EpState_SubmitItem = DefineClass("EpState_SubmitItem", EpStateBase)
function EpState_SubmitItem:ctor(episode, epStateId)
    self.WaitCloseUI = nil
end

function EpState_SubmitItem:OnEnter(preStateId)
    Game.GlobalEventSystem:AddListener(EEventTypesV2.ON_UI_CLOSE, "OnCloseUI", self)
    self.WaitCloseUI = UIPanelConfig.SubmitNew_Panel
    Log.InfoFormat("[DialogueV2]EpState_SubmitItem, now open UI: %s in %s", self.WaitCloseUI, self.episode:ToString())

    local episode = self.episode
    local dialogueInstance = episode.dialogueInstance
    local submitParam = dialogueInstance.PlayParams
    
    local lastOptionIdx = 1
    local lastOption = Game.DialogueManagerV2:GetLastOptionSelected()
    if lastOption and lastOption.OptionIndex then
        lastOptionIdx = lastOption.OptionIndex
    end
    
    ---@type ItemSubmitCompatibleParams
    local realSubmitParam = {
        ItemSubmitID = submitParam.SubmitItemID,
        TaskRingID = submitParam.TaskRingID,
        QuestID = submitParam.QuestID,
        CondIdx = submitParam.CondIdx,
        NewSubmitCfg = submitParam.NewSubmitCfg,
        OpIdx = lastOptionIdx,
    }

    local systemItemSubmit = Game.ItemSubmitSystem
    xpcall(systemItemSubmit.ShowItemSubmitUICompatible, _G.CallBackError, systemItemSubmit, realSubmitParam)
end

function EpState_SubmitItem:OnExit()
    Game.GlobalEventSystem:RemoveListener(EEventTypesV2.ON_UI_CLOSE, "OnCloseUI", self)
end

function EpState_SubmitItem:CanTransit()
    return self.WaitCloseUI == nil
end

function EpState_SubmitItem:GetNextStateId()
    return DialogueConst.EPISODE_STATE.EP_STATE_FINISH
end

function EpState_SubmitItem:OnCloseUI(uid)
    if uid == self.WaitCloseUI then
        self.WaitCloseUI = nil
    end
end
