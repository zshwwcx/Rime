local EpStateBase = kg_require("Gameplay.DialogueV2.EpisodeState.EpStateBase").EpStateBase
---@class EpState_Options : EpStateBase
EpState_Options = DefineClass("EpState_Options", EpStateBase)
function EpState_Options:ctor(episode, epStateId)
    self.bInOptionProcess = false
    self.nextStateId = nil
end

function EpState_Options:OnEnter(preStateId)
    self.bInOptionProcess = true
    local showOptions = self.episode.showOptions

    self.nextStateId =  DialogueConst.EPISODE_STATE.EP_STATE_FINISH
    if #showOptions <= 0 then
        self.bInOptionProcess = false
        return
    end

    -- 检查对话选项中是否存在DialogueID == 0的存在，如果有的话，
    -- 则无需点击，判断condition后直接执行option对应的action
    for _, option in ipairs(showOptions) do
        if option.OptionID == 0 then
            option:SetOptionState(option:CheckOptionConditionValid(option.Condition))
            if option:IsUnlock() then
                self.nextStateId = DialogueConst.EPISODE_STATE.EP_STATE_FINISH
                self.episode.SelectedOptionData = option
                self.bInOptionProcess = false
                return
            end
        end
    end

    local dialogueInstance = self.episode.dialogueInstance
    local token = dialogueInstance:GetBlackBoardValue(DialogueConst.BlackBoardKey.PENDING_HIDE_LINE)
    if token then
        Game.DialogueManagerV2.UIProcessor:CancelDeferCall(token)
        dialogueInstance:SetBlackBoardValue(DialogueConst.BlackBoardKey.PENDING_HIDE_LINE, nil)
    end

    -- 没有任何自动执行的选项逻辑，开始正常的选项展示了
    self.episode:ShowDialogueOptions()

	self.episode:SetStopPoint(true)
	
    Game.GlobalEventSystem:AddListener(EEventTypesV2.ON_DIALOGUE_OPTION_CHOOSED, "OnDialogueOptionChoosed", self)
end

function EpState_Options:OnTick(deltaTime, bSkip)
end

function EpState_Options:OnExit()
	self.episode:SetStopPoint(false)
    Game.GlobalEventSystem:RemoveListener(EEventTypesV2.ON_DIALOGUE_OPTION_CHOOSED, "OnDialogueOptionChoosed", self)
end

function EpState_Options:CanTransit()
    return not self.bInOptionProcess
end

function EpState_Options:GetNextStateId()
    local episode = self.episode
    if episode.WaitCloseUI then
        return DialogueConst.EPISODE_STATE.EP_STATE_WAIT_CLOSE_UI
    elseif episode.SelectedOptionData:GetTargetEpisodeID() ~= 0 then
        return DialogueConst.EPISODE_STATE.EP_STATE_FINISH
    elseif episode:CheckDialogueSubmit() then
        return DialogueConst.EPISODE_STATE.EP_STATE_PAUSE_SUB_SUBMITTING_ITEM
    elseif episode:CheckAcceptQuest() then
        return DialogueConst.EPISODE_STATE.EP_STATE_PAUSE_SUB_ACCEPTING_QUEST
    elseif self.nextStateId ~= nil then
        return self.nextStateId
    else
        return DialogueConst.EPISODE_STATE.EP_STATE_FINISH
    end
end

---@param optionIndex number @ option index
function EpState_Options:OnDialogueOptionChoosed(optionIndex)
    Log.InfoFormat("[DialogueV2][EpState_Option]OnDialogueOptionChoosed option Index:%s in %s", optionIndex, self.episode:ToString())
    self.episode:OnSelectOption(optionIndex)
    self.bInOptionProcess = false
end
