local EpisodeState = kg_require("Gameplay.DialogueV2.EpisodeState.EpStateBase").EpStateBase

---@class EpState_Freezing : EpisodeStateBase
EpState_Freezing = DefineClass("EpState_Freezing", EpisodeState)

function EpState_Freezing:ctor(episode, epStateId)
    self.bFreezing = false
end

function EpState_Freezing:OnEnter(preStateId)
    sel.bFreezing = true
end

function EpState_Freezing:Tick(deltaTime, bSkip)
end

function EpState_Freezing:OnExit()
end

function EpState_Freezing:CanTransit()
    return not self.bFreezing
end

function EpState_Freezing:GetNextStateId()
    return DialogueConst.EPISODE_STATE.EP_STATE_TICKTRACKS
end
