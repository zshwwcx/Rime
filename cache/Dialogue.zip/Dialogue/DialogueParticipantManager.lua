---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/7 14:25
---
local EAttachmentRule = import("EAttachmentRule")
local UMeshComponent = import("MeshComponent")
local DialogueParticipant = kg_require("Gameplay.DialogueV2.DialogueParticipant").DialogueParticipant
local DialogueUtilV2 = kg_require("Gameplay.DialogueV2.DialogueUtilV2").DialogueUtilV2
local TimerBase = kg_require("Framework.KGFramework.KGCore.TimerManager.TimerBase").TimerBase

---@class DialogueParticipantManager : LuaCalss
---@field private lookAtLookUp table<LocalEntityBase, {targetEntity:LocalEntityBase, socket:string, bAutoLookAt:boolean}>
DialogueParticipantManager = DefineClass("DialogueParticipantManager", TimerBase)

---@param dialogueInstance DialogueInstanceBase
function DialogueParticipantManager:ctor(dialogueInstance)
    assert(dialogueInstance, "dialogue instance is nil")
    
    self.dialogueID = dialogueInstance.DialogueID
    self.playParams = dialogueInstance.PlayParams

    ---@type DialogueInstanceBase
    self.dialogueInstance = dialogueInstance
    self.dialogueConfig = dialogueInstance.DialogueConfig

    ---@type table<string, DialogueParticipant>
    self.participants = {}
    ---@type table<DialogueParticipant, boolean>
    self.participantsReady = {}
    ---@type table<string, table>
    self.participantConfigs = {}
    self.lookAtLookUp = {}

    self.participantTotalNum = 0
    self.participantReadyNum = 0

    -- 标记是否使用真实玩家表演
    self.bUseRealMainPlayer = false

    ---所有演员看向说话者
    self.bEnableAllPerformerLookAtTalker = false
    ---@type DialoguePerformer 当前的说话人
    self.curTalker = nil
	---@TYPE DialoguePerformer 下一句说话人
	self.nextTalker = nil
	---@type DialoguePerformer 说话人需要看向的目标
    self.talkerLookAtTarget = nil

    self.delayLookAtTimerList = {}

    --- 语音相关参数，同时只能有一个语音在播放
    self.voiceEventName = ""
    self.voicePlayingID = 0
    self.talkerEntityID = 0
    self.performer2FaceAnimPlayID = {}
end

---@public
function DialogueParticipantManager:UnInit()
    for _, timer in ipairs(self.delayLookAtTimerList) do
		self:DelTimer(timer)
    end
    table.clear(self.delayLookAtTimerList)

    self:DestroyAllParticipant()

    self:delete()
end

---@public
function DialogueParticipantManager:SpawnAllParticipant()
    self.participantConfigs = {}

	if not self.dialogueConfig then
		Log.WarningFormat("[DialogueV2][DialogueParticipantManager:SpawnAllParticipant] dialogueConfig is nil value.")
		return
	end

    self:GatherAllParticipantsConfig()
    -- 没有参与者
    if self.participantTotalNum == 0 then
        Log.InfoFormat("[SpawnAllParticipant] no participant found in %s", self.dialogueID)
        self.dialogueInstance:OnAllParticipantReady()
        return
    end

    table.clear(self.participantsReady)
    self.participantReadyNum = 0
    for _, config in pairs(self.participantConfigs) do
        self:spawnSingleParticipant(config)
    end
end

---@private
---@param ptpConfig UDialogueActor
function DialogueParticipantManager:spawnSingleParticipant(ptpConfig)
    local trackName = ptpConfig.TrackName
    local participant = self.participants[trackName]
    if participant then
        if participant:IsReady() then
            self:OnParticipantReady(participant, trackName)
        end
        return
    end

    local bSimpleDialogue = self.dialogueInstance.bSimpleDialogue

    ---@type DialogueParticipant
    local newParticipant = DialogueParticipant.new(self, ptpConfig)
    self.participants[trackName] = newParticipant

    local spawnTransform = self:getParticipantSpawnTransform(ptpConfig, self.playParams.SpawnTransform)
    if ptpConfig.UseSceneActor then
        newParticipant:BindDialogueEntity(spawnTransform, bSimpleDialogue)
        if ptpConfig.bIsPlayer then
            self.bUseRealMainPlayer = true
        end
        Log.DebugFormat("[DialogueV2]spawnSingleParticipant: using scene actor, entity: %s, trackName:%s isPlayer:%s", 
            newParticipant, trackName, self.bUseRealMainPlayer)
    else
        newParticipant:SpawnDialogueEntity(spawnTransform)
        Log.DebugFormat("[DialogueV2]spawnSingleParticipant, entity: %s, trackName:%s ", newParticipant, trackName)
    end
end

---@public
---@param participant DialogueParticipant
---@param trackName string
function DialogueParticipantManager:OnParticipantReady(participant, trackName)
    if self.participantsReady[participant] then
        return
    end
    
    self.participantsReady[participant] = true
    
    self.participantReadyNum = 0
    for _, ready in pairs(self.participantsReady) do
        if ready then
            self.participantReadyNum = self.participantReadyNum + 1
        end
    end
    
    Log.InfoFormat("DialogueParticipantManager:OnParticipantReady. participant:%s is ready. participantReadyNum: %s/%s",
        participant.TrackName, self.participantReadyNum, self.participantTotalNum)
    if self.participantTotalNum == self.participantReadyNum then
        -- 全员就绪,处理挂接
        self:handleAllPtpAttachRelation()
        self.dialogueInstance:OnAllParticipantReady()
    end
end

---处理所有参与者和参与者之间的挂接关系
---@private
function DialogueParticipantManager:handleAllPtpAttachRelation()
    local attachRule = EAttachmentRule.KeepWorld
    local ptpEntity = nil
    local parentEntity = nil
    local attachCompID = 0
    local attachSocket = ""
    for _, ptp in pairs(self.participants) do
        ptpEntity = ptp:GetDialogueLocalEntity()
        if not ptpEntity then
            goto continue
        end

        parentEntity = self:GetParticipantEntityByName(ptp.ptpConfig.Parent)
        if not parentEntity then
            goto continue
        end

        -- 感觉为空也可以支持,但之前的逻辑不支持,先照搬了过来
        attachSocket = ptp.ptpConfig.FollowParentSocket
        if string.isEmpty(attachSocket) then
            goto continue
        end

        attachCompID = parentEntity.CppEntity:KAPI_Actor_FxGetComponentBySocket(attachSocket)
        if attachCompID == 0 then
            Log.WarningFormat("[handleAllPtpAttachRelation] find socket %s component on %s failed", attachSocket, parentEntity.ptpConfig.TrackName)
            goto continue
        end

        ptpEntity.CppEntity:KAPI_Actor_AttachToComponent(attachCompID, attachSocket, attachRule, attachRule, attachRule, true)
        :: continue ::
    end
end

---@public
function DialogueParticipantManager:SetParticipantDefaultVisibility()
    Log.InfoFormat("[DialogueV2]SetParticipantDefaultVisibility on dialogue:%s", self.dialogueInstance:ToString())
    for _, participant in pairs(self.participants) do
        participant:SetDefaultVisibility()
    end
end

---@public
function DialogueParticipantManager:HideAllParticipant()
    for _, participant in pairs(self.participants) do
        participant:Hide(DialogueConst.PARTICIPANT_HIDE_SOURCE.DIALOGUE_LOGIC)
    end
end

---@public
function DialogueParticipantManager:DestroyAllParticipant()
    Log.InfoFormat("[DialogueV2]DestroyAllParticipant on dialogue:%s", self.dialogueInstance:ToString())
    for _, participant in pairs(self.participants) do
        if participant.ptpConfig.UseSceneActor then
            participant:UnbindDialogueEntity()
        else
            participant:DestroyDialogueEntity()
        end
    end
    table.clear(self.participants)
    table.clear(self.participantsReady)
end

---@public
---@param name string
---@return DialogueParticipant|nil
function DialogueParticipantManager:GetParticipantByName(name)
    return self.participants[name]
end

---根据名称获取参与者Entity
---@public
---@param name string
---@return DialoguePerformer|DialogueCamera|DialogueNiagara|DialogueModel|DialogueLight
function DialogueParticipantManager:GetParticipantEntityByName(name)
    local ptp = self.participants[name]
    if ptp then
        return ptp:GetDialogueLocalEntity()
    end
end

---获取演员外观ID,直接从表里获取
---@public
---@param performerName
---@return number
function DialogueParticipantManager:GetPerformerAppearanceID(performerName)
    local appearanceID = 0

    -- 先从表格里取
    local dialogueAssetData = Game.TableData.GetDialogueAssetDataRow(self.dialogueID)
    for _, performerInfo in ksbcpairs(dialogueAssetData.Actors) do
        if performerInfo.tag == performerName then
            appearanceID = performerInfo.npcID
            break
        end
    end

    if appearanceID ~= 0 then
        return appearanceID
    end

    -- 再从参与者里面取
    local ptp = self:GetParticipantByName(performerName)
    return ptp and ptp.ptpConfig.AppearanceID or 0
end

---@public
---@param ptpName string
---@param bExclude boolean
function DialogueParticipantManager:SetPtpExcludeFromPostProcess(ptpName, bExclude)
    local ptpEntity = self:GetParticipantEntityByName(ptpName)
    if not ptpEntity then
        return
    end

    local meshCompIDs = ptpEntity.CppEntity:KAPI_Actor_K2_GetComponentsByClass(UMeshComponent)
    for _, meshCompID in pairs(meshCompIDs) do
        -- todo:这里cpp接口把number转成了boolean,应该直接传对应类型
        ptpEntity.CppEntity:KAPI_PrimitiveID_SetCustomDepthAndStencilValue(meshCompID, bExclude and 1 or 0, 10)
    end
end

---获取配置一致的演员
---@public
---@param configID number
---@return DialoguePerformer[]
function DialogueParticipantManager:GetSameConfigPerformers(configID)
    local result = {}
    local ptpEntity
    local ptpType_PERFORMER = DialogueConst.PARTICIPANT_TYPE.PERFORMER

    for _, participant in pairs(self.participants) do
        if participant.PtpType ~= ptpType_PERFORMER then
            goto continue
        end

        ptpEntity = participant:GetDialogueLocalEntity()
        if not ptpEntity then
            goto continue
        end

        if participant.ptpConfig.AppearanceID == configID then
            table.insert(result, ptpEntity)
        end

        :: continue ::
    end

    return result
end

local __UnitTransform__ = FTransform(FQuat(0, 0, 0, 1), FVector(0, 0, 0), FVector(1, 1, 1)) -- luacheck: ignore
local __OneVector__ = FVector(1, 1, 1) -- luacheck: ignore
local __ZeroVector__ = FVector(0, 0, 0) -- luacheck: ignore

---@private
function DialogueParticipantManager:getParticipantSpawnTransform(ptpConfig, spawnTransform)
    if not ptpConfig then
        return __UnitTransform__
    end

    local ptpParentConfig = self:getParticipantParentConfig(ptpConfig)
    if ptpParentConfig then
        local ptpSpawnTransform = DialogueUtilV2.DialogueTransformToUETransform(ptpConfig.SpawnTransform)
        local parentPtpSpawnTransform = self:getParticipantSpawnTransform(ptpParentConfig, spawnTransform)
        return ptpSpawnTransform * parentPtpSpawnTransform
    end

    -- 已经找不到父级,如果传入了额外的spawnTransform,则使用
    if spawnTransform then
        return spawnTransform
    end

    -- 如果外界没有指定位置,但使用了绝对位置的情况下(ZERO),使用自身的SpawnTransform
    if self.dialogueConfig.AnchorType == DialogueConst.ANCHOR_TYPE.ABSOLUTE then
        return DialogueUtilV2.DialogueTransformToUETransform(ptpConfig.SpawnTransform)
    end

    -- 未使用绝对坐标,根据锚点类型取位置
    return self:GetAnchorTransform()
end

---@private
function DialogueParticipantManager:getParticipantParentConfig(ptpConfig)
    if (ptpConfig == nil) or (string.isEmpty(ptpConfig.Parent) == true) then
        return
    end

    return self.participantConfigs[ptpConfig.Parent]
end

---@public
function DialogueParticipantManager:GetAnchorTransform()
    if not self.dialogueConfig then
        return __UnitTransform__
    end

    local position, rotation

    if (self.dialogueConfig.AnchorType == DialogueConst.ANCHOR_TYPE.NPC_SPAWNER)
            or (self.dialogueConfig.AnchorType == DialogueConst.ANCHOR_TYPE.TRIGGER)
            or (self.dialogueConfig.AnchorType == DialogueConst.ANCHOR_TYPE.INTERACTOR)
    then
        -- 以场景物为锚点,从场景侧取数据
        position, rotation = Game.WorldDataManager:GetSceneActorRootPos(self.dialogueConfig.AnchorID)
    elseif self.dialogueConfig.AnchorType == DialogueConst.ANCHOR_TYPE.PLAYER then
		-- 以玩家为锚点,取玩家坐标
		if Game.me then
			position, rotation = Game.me:GetPosition(), Game.me:GetRotation()
		end
    end

    if (position ~= nil) and (rotation ~= nil) then
        return FTransform(rotation:ToQuat(), position, __OneVector__)
    else
        return __UnitTransform__
    end
end

DialogueParticipantManager.__AnchorPtpName__ = "锚点" -- luacheck: ignore

-- todo: 有点暴力,先这么用
---获取锚点参与者单位的位置
---@public
---@return PVector3
function DialogueParticipantManager:GetAnchorPtpLocation()
    local anchorPtp = self.participants[self.__AnchorPtpName__]
    local anchorPtpEntity = anchorPtp and anchorPtp:GetDialogueLocalEntity() or nil
    if not anchorPtpEntity then
        return __ZeroVector__
    end

    return anchorPtpEntity:GetPosition()
end

---更新当句的说话者,处理AutoLookAt的逻辑
---@public
---@param talkerName string
function DialogueParticipantManager:SetCurDialogueTalker(talkerName)
    self.curTalker = self:GetParticipantEntityByName(talkerName)

    if self.bEnableAllPerformerLookAtTalker then
        self:handleAllPerformerLookAtTalker()
		self:handleTalkerLookAtTarget()
    end
end

--- 更新下一个台本的说话者，用于更新LookAt信息
function DialogueParticipantManager:SetCurDialogueNextTalker(talkerName)
	self.nextTalker = self:GetParticipantEntityByName(talkerName)
end

---控制全体LookAt的开关
---@public
---@param bEnable boolean
function DialogueParticipantManager:SetEnableAllPtpLookAtTalker(bEnable)
    if self.bEnableAllPerformerLookAtTalker == bEnable then
        return
    end

    Log.DebugFormat("[SetEnableAllPtpLookAtTalker] bEnable=%s", bEnable)
    self.bEnableAllPerformerLookAtTalker = bEnable
	if bEnable == true then
		self:handleAllPerformerLookAtTalker()
	end
end

---@public
---@param bEnable boolean
---@param targetName string
function DialogueParticipantManager:SetEnableTalkerLookAtTarget(targetName)
    self.talkerLookAtTarget = self:GetParticipantEntityByName(targetName)
    self:handleTalkerLookAtTarget()
end

---说话人看向目标,说话人切换时也会调用
---@private
function DialogueParticipantManager:handleTalkerLookAtTarget()
    local talkerLookAtTarget = self.talkerLookAtTarget
    local targetCharacterID = talkerLookAtTarget and talkerLookAtTarget.CharacterID or 0
    local curTalker = self.curTalker
    if curTalker then
        if targetCharacterID ~= 0 then
			-- 说话者看向了自身，则说话人不做看向处理
			if talkerLookAtTarget == curTalker then
				self:UnlookAt(curTalker, "talkerLookAtTarget == curTalker")
			else
				self:LookAtEntity(curTalker, talkerLookAtTarget, 0, DialogueConst.HEAD_SOCKET_NAME, true)
			end
		else
			if self.nextTalker and self.nextTalker ~= curTalker then
				self:LookAtEntity(curTalker, self.nextTalker, 0, DialogueConst.HEAD_SOCKET_NAME, true)
			end
        end
    end
end

---其他演员看向说话人,说话人切换时也会调用
---@private
function DialogueParticipantManager:handleAllPerformerLookAtTalker()
    local targetCharacterID = self.curTalker and self.curTalker.CharacterID or 0
    local socket = DialogueConst.HEAD_SOCKET_NAME
    local participantTypePerformer = DialogueConst.PARTICIPANT_TYPE.PERFORMER
    local curTalker = self.curTalker

    for _, participant in pairs(self.participants) do
        if participant.PtpType ~= participantTypePerformer then
            goto continue
        end

        local ptpEntity = participant:GetDialogueLocalEntity()
        if not ptpEntity then
            goto continue
        end

		-- 如果已经手动看向某人，则不使用自动看向
		if self.lookAtLookUp[ptpEntity] then
			if self.lookAtLookUp[ptpEntity].bAutoLookAt == false then
				goto continue
			end
		end


		if ptpEntity == self.curTalker then
			if self.talkerLookAtTarget == self.curTalker then
				self:UnlookAt(ptpEntity, "talkerLookAtTarget == curTalker")
			end
			goto continue
		end

        -- 如果没找到目标,也需要取消Gaze
        if (self.bEnableAllPerformerLookAtTalker == true) and (targetCharacterID ~= 0) then
            if self:canApplyAutoLookAt(ptpEntity) then
                self:LookAtEntity(ptpEntity, curTalker, 0, socket, true)
            end
        else
            self:UnlookAt(ptpEntity, "Cannot find target")
        end

        :: continue ::
    end
end

---Section是瞬时的,如果有Delay的LookAt需要通过ptpManager管理
---@public
---@param lookerEntity DialoguePerformer
---@param targetEntity DialoguePerformer
---@param delay number
---@param lookAtSocket string @ lookAt的位置
---@param bAutoLookAt boolean @ 是否为自动LookAt
---@param bGazeInstance boolean @ 是否瞬转
---@param gazeAlphaBlendOp @ 看向曲线
function DialogueParticipantManager:AddDelayLookAtTask(lookerEntity, targetEntity, delay, lookAtSocket, bAutoLookAt,
                                                       bRotateUpBody, bGazeInstance, gazeAlphaBlendOp)
    if (delay == nil) or (delay <= 0) then
        Log.WarningFormat("[AddDelayLookAtTask] invalid delay %s", delay)
        return
    end

    local lookerEntityUID = lookerEntity and lookerEntity:uid() or 0
    local targetEntityUID = targetEntity and targetEntity:uid() or 0

    if (lookerEntityUID == 0) or (targetEntityUID == 0) then
        Log.WarningFormat("[AddDelayLookAtTask] invalid entity looker=%s, target=%s", lookerEntityUID, targetEntityUID)
        return
    end
    local lookAtParams = {
        lookerEntityUID = lookerEntityUID, 
        targetEntityUID = targetEntityUID, 
        lookAtSocket = lookAtSocket,
        bAutoLookAt = bAutoLookAt, 
        bRotateUpBody = bRotateUpBody, 
        bGazeInstance = bGazeInstance, 
        gazeAlphaBlendOp = gazeAlphaBlendOp
    }
    local timer = self:AddTimer(delay, 1, "realDelayLookAt", lookAtParams)

    table.insert(self.delayLookAtTimerList, timer)
end

---@private
---@param lookAtParams table
function DialogueParticipantManager:realDelayLookAt(lookAtParams)
    local lookerEntity = Game.EntityManager:GetEntityByIntID(lookAtParams.lookerEntityUID)
    local targetEntity = Game.EntityManager:GetEntityByIntID(lookAtParams.targetEntityUID)
    if (lookerEntity == nil) or (targetEntity == nil) then
        Log.DebugWarningFormat("[realDelayLookAt] entity already destroyed looker=%s, target=%s", lookAtParams.lookerEntityUID, lookAtParams.targetEntityUID)
        return
    end

    self:LookAtEntity(lookerEntity, targetEntity, 0, lookAtParams.lookAtSocket, lookAtParams.bAutoLookAt, lookAtParams.bRotateUpperBody, lookAtParams.bGazeInstance, lookAtParams.gazeAlphaBlendOp)
end

---@public
---@param lookerEntity string
---@param targetEntity string
---@param delay number
---@param lookAtSocket string
---@param bAutoLookAt boolean @ 是否为自动LookAt
function DialogueParticipantManager:LookAt(lookerName, targetname, delay, lookAtSocket, bAutoLookAt)
    local lookerEntity = self:GetParticipantEntityByName(lookerName)
    local targetEntity = self:GetParticipantEntityByName(targetname)
    self:LookAtEntity(lookerEntity, targetEntity, delay, lookAtSocket, bAutoLookAt)
end

---@public
---@param lookerEntity DialoguePerformer|DialogueCamera|DialogueNiagara|DialogueModel|DialogueRoutePoint
---@param targetEntity DialoguePerformer|DialogueCamera|DialogueNiagara|DialogueModel|DialogueRoutePoint
---@param delay number
---@param lookAtSocket string @ lookAt的位置，默认为 "head"
---@param bAutoLookAt boolean @ 是否为自动LookAt
---@param bRotateUpperBody boolean @ 是否旋转上半身，默认为true
---@param bGazeInstance boolean @ 是否瞬转
---@param gazeAlphaBlendOp EAlphaBlendOption @ 看向曲线
function DialogueParticipantManager:LookAtEntity(lookerEntity, targetEntity, delay, lookAtSocket,
                                                 bAutoLookAt, bRotateUpperBody, bGazeInstance, gazeAlphaBlendOp)
    if lookerEntity == nil then
        return
    end

    if targetEntity == nil then
        self:UnlookAt(lookerEntity, "Target is nil")
        return
    end

    delay = delay or 0
    local socket = lookAtSocket or DialogueConst.HEAD_SOCKET_NAME
    
    if delay > 0 then
        Log.DebugFormat("[DialogueV2][DialogueParticipantManager_LookAt] %s look at %s after %s seconds, autoLookAt:%s",
            lookerEntity.ptpConfig.TrackName, targetEntity.ptpConfig.TrackName, delay, bAutoLookAt)

        self:AddDelayLookAtTask(lookerEntity, targetEntity, delay, socket, bAutoLookAt, bRotateUpperBody, bGazeInstance, gazeAlphaBlendOp)
    else
        local spineCoe = bRotateUpperBody == false and 0 or 1

        Log.DebugFormat("[DialogueV2][DialogueParticipantManager_LookAt] %s look at %s, autoLookAt:%s rotateUpperBody:%s",
            lookerEntity.ptpConfig and lookerEntity.ptpConfig.TrackName or lookerEntity.__debug_info,
            targetEntity.ptpConfig and targetEntity.ptpConfig.TrackName or targetEntity.__debug_info,
            bAutoLookAt, spineCoe)

        lookerEntity:SetGazePartBlendAlpha(1, 1, spineCoe, 1)
        lookerEntity:StartGazeActor(Enum.ELookAtTypeMap.DIALOGUE, targetEntity.CharacterID, socket, nil, nil, bGazeInstance, gazeAlphaBlendOp)
    end

    self.lookAtLookUp[lookerEntity] = { targetEntity = targetEntity, socket = socket, bAutoLookAt = bAutoLookAt }
end

--- 解除LookAt
---@public
---@param lookerEntity DialoguePerformer|DialogueCamera|DialogueNiagara|DialogueModel|DialogueRoutePoint
function DialogueParticipantManager:UnlookAt(lookerEntity, reason)
    if lookerEntity then
		Log.DebugFormat("[DialogueV2][DialogueParticipantManager_LookAt] %s UnlookAt, reason: %s", lookerEntity.ptpConfig.TrackName, reason)
        self.lookAtLookUp[lookerEntity] = nil
        lookerEntity:UnGaze(Enum.ELookAtTypeMap.DIALOGUE)
    end
end

--- 是否可以使用自动LookAt
--- 当entity已经被手动设置过lookAt目标时，不能使用自动lookAt，
--- 详情参见reminder：#157567 【剧情编辑器优化】LookAt功能优先级调整 
--- https://gamecloud-redmine.corp.kuaishou.com/1007/projects/c7/issues/157567
---@private
---@param lookerEntity DialoguePerformer|DialogueCamera|DialogueNiagara|DialogueModel|DialogueRoutePoint
---@return boolean
function DialogueParticipantManager:canApplyAutoLookAt(lookerEntity)
    local lookAtInfo = self.lookAtLookUp[lookerEntity]
    if lookAtInfo then
        return lookAtInfo.bAutoLookAt ~= false
    end

    return true
end

---@param bVisible boolean
---@param tag DialogueParticipantHideSource
function DialogueParticipantManager:SetAllParticipantsVisibility(bVisible, tag)
    for _, participant in pairs(self.participants) do
        if not participant.isDestroyed then
            if bVisible then
                participant:Show(tag)
            else
                participant:Hide(tag)
            end
        end
    end
end

function DialogueParticipantManager:GatherAllParticipantsConfig()
    -- luacheck: push ignore
    -- 优先将锚点加入列表
    for _, cameraConfig in ksbcipairs(self.dialogueConfig.CameraList) do
        self.participantTotalNum = self.participantTotalNum + 1
        self.participantConfigs[cameraConfig.TrackName] = cameraConfig
        break
    end
    -- luacheck: pop

    for _, performerConfig in ksbcipairs(self.dialogueConfig.PerformerList) do
        self.participantTotalNum = self.participantTotalNum + 1
        self.participantConfigs[performerConfig.TrackName] = performerConfig
    end

    for index, cameraConfig in ksbcipairs(self.dialogueConfig.CameraList) do
        if index > 1 then
            self.participantTotalNum = self.participantTotalNum + 1
            self.participantConfigs[cameraConfig.TrackName] = cameraConfig
        end
    end

    for _, routePointConfig in ksbcipairs(self.dialogueConfig.RoutePointList) do
        self.participantTotalNum = self.participantTotalNum + 1
        self.participantConfigs[routePointConfig.TrackName] = routePointConfig
    end

    for _, otherConfig in ksbcipairs(self.dialogueConfig.NewEntityList) do
        self.participantTotalNum = self.participantTotalNum + 1
        self.participantConfigs[otherConfig.TrackName] = otherConfig
    end
end 


function DialogueParticipantManager:StopVoice()
    if self.voicePlayingID == 0 then
        return
    end
    Game.AkAudioManager:StopEvent(self.voicePlayingID)
    self.voicePlayingID = 0
end


---播放台本语音
---@private
function DialogueParticipantManager:PlayContentVoice(dialogueID, episodeID, contentIndex, talkerPtpEntity)
    self:StopVoice()
    self.voicePlayingID, self.voiceEventName = Game.AkAudioManager:PlayDialogueVoice(dialogueID, episodeID, contentIndex, talkerPtpEntity)
end

function DialogueParticipantManager:StopVoiceFaceAnim()
    local talkerEntity = Game.EntityManager:GetEntityByIntID(self.talkerEntityID)
    if talkerEntity then
        local appearanceID = talkerEntity:GetConfigTemplateID()
        if (appearanceID == nil or appearanceID == 0) and talkerEntity.ptpConfig ~= nil then
            appearanceID = talkerEntity.ptpConfig.AppearanceID
        end

        local faceAnimPlayID
        local sameConfigPerformers = self:GetSameConfigPerformers(appearanceID)
        for _, performerEntity in ipairs(sameConfigPerformers) do
            faceAnimPlayID = self.performer2FaceAnimPlayID[performerEntity:uid()]
            if (faceAnimPlayID ~= nil) and (faceAnimPlayID ~= 0) then
                performerEntity:StopFaceAnimation()
            end
        end
        self.talkerEntityID = 0
    end
end

function DialogueParticipantManager:SetTalkerEntityID(talkerEntityID)
    self.talkerEntityID = talkerEntityID
end

-- todo@shijingzhe: 目前方案是直接读取美术生成的口型数据,后续会探索自动方案
---播放口型动画
function DialogueParticipantManager:playVoiceFaceAnim(dialogueID, episodeID, contentIndex, talkerEntity)
    self:StopVoiceFaceAnim()
    if not talkerEntity then
        Log.Warning("[DialogueV2][DialogueParticipantManager:playVoiceFaceAnim] talkerEntity is nil.")
        return
    end

    -- 语音没播放
    if self.voicePlayingID == 0 then
        Log.Warning("[DialogueV2][DialogueParticipantManager:playVoiceFaceAnim] voicePlaying ID == 0.")
        return
    end

    -- @shijingzhe:文案需求
    --      前提是文案希望把口型功能放在台本Section里,这样不用配置,自动触发
    --      但是可能摆多个AppearanceID一致的角色用于表演,且台本里填的说话人和当前镜头拍的人不一定一致,所以会出现口型动画看不到的情况
    --      所以文案要求所有外观ID一致的演员一起播放口型
    local faceAnimPlayID
    local sameConfigPerformers = self:GetSameConfigPerformers(talkerEntity.ptpConfig.AppearanceID)
    for _, performerEntity in ipairs(sameConfigPerformers) do
        faceAnimPlayID = performerEntity:PlayDialogueLipSyncAnim(dialogueID, episodeID, contentIndex)
        self.performer2FaceAnimPlayID[performerEntity:uid()] = faceAnimPlayID
    end
end