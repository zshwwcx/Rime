---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/7 17:33
---
local ECameraEaseFunction = import("ECameraEaseFunction")
local ECameraViewBlendFunction = import("ECameraViewBlendFunction")
local DialogueAutoCameraManager = kg_require("Gameplay.DialogueV2.DialogueAutoCameraManagerV2").DialogueAutoCameraManagerV2
local DialogueInstanceBase = kg_require("Gameplay.DialogueV2.Instance.DialogueInstanceBase").DialogueInstanceBase

---@class NormalDialogueInstance : DialogueInstanceBase
NormalDialogueInstance = DefineClass("NormalDialogueInstance", DialogueInstanceBase)

NormalDialogueInstance.__BlackColor__ = FLinearColor(0, 0, 0)

function NormalDialogueInstance:ctor()
    ---当次相机过渡的持续时间
    self.cameraFadeTime = 0
    ---当次相机过渡的目标时间
    self.cameraFadeTargetTime = 0

    self.cameraFadeTimer = nil
    self.cameraFadeCurve = slua.loadObject(DialogueConst.CameraFadeCurve)

    ---@type DB_SubmitItem
    self.barrierSubmitItem = nil

    ---@type DB_AcceptQuest
    self.barrierAcceptQuest = nil
    
    ---@type DialogueAutoCameraManagerV2
    self.AutoCameraManager = DialogueAutoCameraManager.new(self)

    if not self.cameraFadeCurve then
        Log.Error("[ctor] load CameraFadeCurve %s failed", DialogueConst.CameraFadeCurve)
    end
end

---@overload
function NormalDialogueInstance:RegisterStage()
    self.registeredInStage = {
        [DialogueConst.STAGE.CAMERA_FADE_IN_1ST_HALF] = 1,
        [DialogueConst.STAGE.PRELOAD_RESOURCE] = 1,
        [DialogueConst.STAGE.SPAWN_PARTICIPANT] = 1,
        [DialogueConst.STAGE.OPEN_DIALOGUE_PANEL] = 1,
        [DialogueConst.STAGE.BEGIN_PLAY] = 1,
        [DialogueConst.STAGE.CAMERA_FADE_IN_2ND_HALF] = 1,
        [DialogueConst.STAGE.TICKING] = 1,
        [DialogueConst.STAGE.CAMERA_FADE_OUT_1ST_HALF] = 1,
        [DialogueConst.STAGE.END_PLAY] = 1,
        [DialogueConst.STAGE.CAMERA_FADE_OUT_2ND_HALF] = 1,
        [DialogueConst.STAGE.FINISH] = 1,
    }
end

---@overload
function NormalDialogueInstance:Init()
    local bSuccess = DialogueInstanceBase.Init(self)
    Game.GlobalEventSystem:AddListener(EEventTypesV2.ON_UI_OPEN, "OnDialoguePanelOpened", self)
    Game.DialogueManagerV2.InputProcessor.OnDialogueActionKeyUp:Bind("OnDialogueActionKeyUp", self)
    Game.DialogueManagerV2.InputProcessor.OnDialogueActionKeyLongPressed:Bind("OnDialogueActionKeyLongPressed", self)

    -- 设置自动播放
    self:InitAutoPlay()    
    
	--提升角色品质
	AvatarFactory.EnhanceEffects(true)
    return bSuccess
end

function NormalDialogueInstance:UnInit()
    --恢复角色品质
    AvatarFactory.EnhanceEffects(false)

    Game.NewUIManager:ClosePanel(UIPanelConfig.BlackScreenPanel)

    Game.GlobalEventSystem:RemoveTargetAllListeners(self)
    DialogueInstanceBase.UnInit(self)
end

---外部Terminate无法清理timer,需要重载
---@param endReason DialogueEndReason
function NormalDialogueInstance:Terminate(endReason)
    AvatarFactory.EnhanceEffects(false)

    Game.NewUIManager:ClosePanel(UIPanelConfig.BlackScreenPanel)

    Game.GlobalEventSystem:RemoveTargetAllListeners(self)
    self:LockPlayerInput(false)
    DialogueInstanceBase.Terminate(self, endReason)
end

---@protected
function NormalDialogueInstance:DealStateAndEventOnStart()
    DialogueInstanceBase.DealStateAndEventOnStart(self)
    if Game.QuestSystem and Game.QuestSystem:CanEnterDialogueControlState() then
        Game.QuestSystem:EnterDialogueControlState()
    end
	Game.GlobalEventSystem:Publish(EEventTypesV2.CINEMATIC_ON_START, Enum.CinematicType.Dialogue, self.DialogueID)
    Game.AkAudioManager:SetGroupState(Enum.EAudioConstNew.DIALOGUE_GROUP, Enum.EAudioConstNew.IN_DIALOGUE_STATE)
end

---@protected
---@param endReason DialogueEndReason
function NormalDialogueInstance:DealStateAndEventOnEnd(endReason)
    DialogueInstanceBase.DealStateAndEventOnEnd(self, endReason)
    Game.AkAudioManager:ResetGroupState(Enum.EAudioConstNew.DIALOGUE_GROUP)
	Game.GlobalEventSystem:Publish(EEventTypesV2.CINEMATIC_ON_END, Enum.CinematicType.Dialogue, self.DialogueID)
    if Game.QuestSystem then
        Game.QuestSystem:LeaveDialogueControlState()
    end
end


--region Stage


NormalDialogueInstance.__CameraFadeStageTime__ = 0.6

function NormalDialogueInstance:ON_STAGE_OPEN_DIALOGUE_PANEL()
    Game.DialogueManagerV2.UIProcessor:OpenDialoguePanel(self.DialogueConfig.AutoPlayType, self.bCanSkip, self.bShowCameraShot)
end

---@param panelUID string
function NormalDialogueInstance:OnDialoguePanelOpened(panelUID)
    if panelUID == UIPanelConfig.Dialogue_Panel then
        self:ProgressStage()
    end
end

function NormalDialogueInstance:ON_STAGE_CAMERA_FADE_IN_1ST_HALF()
    if not self:NeedFadeIn() then
        self:ProgressStage()
        return
    end

    local time = 0
    if self.DialogueConfig.NeedFadeIn == DialogueConst.FADE_IN_TYPE.BLACKSCREEN_AND_FADE_IN then
        time = self.DialogueConfig.FadeInMinTime
        if  not time then
            time = self.__CameraFadeStageTime__
        else
            time = time
        end
    end
    
    Log.InfoFormat("[DialogueV2]ON_STAGE_CAMERA_FADE_IN_1ST_HALF, fade in time:%s on %s", time, self:ToString())

	Game.SequenceManager:DestroyBlackPanelProtectTimer()
    Game.NewUIManager:OpenPanel(UIPanelConfig.BlackScreenPanel, time, true, "OnFadeInFirstHalfDone", self)
end

function NormalDialogueInstance:OnFadeInFirstHalfDone()
    if self.stage ~= DialogueConst.STAGE.CAMERA_FADE_IN_1ST_HALF then
        Log.WarningFormat("[DialogueV2]OnFadeInFirstHalfDone, but stage is not CAMERA_FADE_IN_1ST_HALF, stage:%s on %s", self.stage, self:ToString())
        return
    end
    
    Log.InfoFormat("[DialogueV2]OnFadeInFirstHalfDone on %s", self:ToString())
    self:ProgressStage()
end

function NormalDialogueInstance:ON_STAGE_BEGIN_PLAY()
    Log.InfoFormat("[DialogueV2][ON_STAGE_BEGIN_PLAY]dialogue: %s", self:ToString())
    -- 处理各单位显隐
    self:DealEntityVisibilityBeforeDialogueBegin()

    -- 处理外部事件
    self.bActivated = true
    self:DealStateAndEventOnStart()
    
    -- 禁用主角输入
    self:LockPlayerInput(true)
    
    if self:NeedFadeIn() then
        -- 处理相机模式
        Game.CameraManager:EnableDialogueCamera(true)
        -- 将相机预先设置到位
        self:SetViewTargetToFirstCamera()
    else
        -- fade和blend逻辑上互斥
        local blendParams = {
            OverrideBlendOut = self.DialogueConfig.BlendOutCamera,
            BlendOutTime = 1,
            BlendOutFunc = ECameraEaseFunction.EaseInOutCubic,
        }

        if self.DialogueConfig.BlendInCamera then
            blendParams.OverrideBlendIn = true
            blendParams.BlendInTime = 0.9
            blendParams.BlendInFunc = ECameraEaseFunction.EaseInOutCubic
        end

        Game.CameraManager:EnableDialogueCamera(true, blendParams)
    end
    
    local callback = self.PlayParams.OnCinematicPlay
    if callback then
        DialogueManagerV2.xpcall(callback, self)
    end

    self:Tick(0, false)

    self:ProgressStage()
end

function NormalDialogueInstance:ON_STAGE_CAMERA_FADE_IN_2ND_HALF()
    if not self:NeedFadeIn() then
        self:ProgressStage()
        return
    end
    
    local time = self.__CameraFadeStageTime__
    local BlackScreen = UIPanelConfig.BlackScreenPanel
    
    Log.InfoFormat("[DialogueV2]ON_STAGE_CAMERA_FADE_IN_2ND_HALF, [BlackScreen] fade time:%s on %s",
        time, self:ToString())
    
    local uiMgr = Game.NewUIManager
    if uiMgr:IsOpened(BlackScreen) then
        uiMgr:InvokePanel(BlackScreen, "Refresh", time, false, "OnFadeInDone", self)
    else
        uiMgr:OpenPanel(BlackScreen, time, false, "OnFadeInDone", self)
    end
end

function NormalDialogueInstance:OnFadeInDone()
    if self.stage ~= DialogueConst.STAGE.CAMERA_FADE_IN_2ND_HALF then
        Log.WarningFormat("[DialogueV2]OnFadeInDone, but stage is not CAMERA_FADE_IN_2ND_HALF, stage:%s on %s",
            self.stage, self:ToString())
        return
    end
    
    Log.InfoFormat("[DialogueV2]OnFadeInDone on %s", self:ToString())
    if self.DialogueConfig.NeedFadeOut then
        Game.NewUIManager:HidePanel("DialogueStage", UIPanelConfig.BlackScreenPanel)
    else
        Game.NewUIManager:ClosePanel(UIPanelConfig.BlackScreenPanel)
    end
    
    self:ProgressStage()
end

function NormalDialogueInstance:ON_STAGE_TICKING()
end

function NormalDialogueInstance:ON_STAGE_SUBMIT_ITEM()
    if self:CheckDialogueSubmit() then
        local barrier = self:AddDialogueBarrier(DialogueConst.BARRIER_TYPE.SUBMIT_ITEM, nil)
        if barrier then
            barrier.OnFinishDelegate:Add(self, "OnSubmitBarrierFinished")
        end
        self.barrierSubmitItem = barrier
        return
    end

    self:ProgressStage()
end

function NormalDialogueInstance:OnSubmitBarrierFinished(barrier)
    if self.barrierSubmitItem == barrier then
        self.barrierSubmitItem = nil
        self:AddTimer(0.01, 1, "FinishSubmitItemStage")
    end
end

function NormalDialogueInstance:FinishSubmitItemStage()
    assert(self.barrierSubmitItem == nil, "can not finish submit item stage, because submit item barrier exist.")
    self:ProgressStage()
end

function NormalDialogueInstance:ON_STAGE_ACCEPT_QUEST()
    if self:CheckAcceptQuest() then
        local barrier = self:AddDialogueBarrier(DialogueConst.BARRIER_TYPE.ACCEPT_QUEST, nil, self.PlayParams.ReceiveRingID)
        if barrier then
            barrier.OnFinishDelegate:Add(self, "OnAcceptQuestFinished")
        end
        self.barrierAcceptQuest = barrier
        return
    end

    self:ProgressStage()
end

function NormalDialogueInstance:OnAcceptQuestFinished(barrier)
    if self.barrierAcceptQuest == barrier then
        self.barrierAcceptQuest = nil
        self:AddTimer(0.01, 1, "FinishAcceptQuestStage")
    end
end

function NormalDialogueInstance:FinishAcceptQuestStage()
    assert(self.barrierSubmitItem == nil, "can not finish accept quest stage, because accept quest barrier exist.")
    self:ProgressStage()
end

function NormalDialogueInstance:ON_STAGE_CAMERA_FADE_OUT_1ST_HALF()
    if not self:NeedFadeOut() then
        self:ProgressStage()
        return
    end

    Log.InfoFormat("[DialogueV2]ON_STAGE_CAMERA_FADE_OUT_1ST_HALF, fade out time:%s", self.__CameraFadeStageTime__)

	Game.SequenceManager:DestroyBlackPanelProtectTimer()
    -- 这里直接忽略黑屏淡入，具体原因参考这个bug单：
    -- #225689 【Bug】【对话】10040081结尾的dialoguesequence播放完显示一帧错误镜头（DialogueSequence结束，闪回了Dialogue前一个镜头状态，再退出dialogue）
    -- https://gamecloud-redmine.corp.kuaishou.com/1007/projects/c7/issues/225689
    Game.NewUIManager:OpenPanel(UIPanelConfig.BlackScreenPanel, 0, true, "OnFadeOutFirstHalfDone", self)
end

function NormalDialogueInstance:OnFadeOutFirstHalfDone()
    if self.stage ~= DialogueConst.STAGE.CAMERA_FADE_OUT_1ST_HALF then
        Log.WarningFormat("[DialogueV2]OnFadeOutFirstHalfDone, but stage is not CAMERA_FADE_OUT_1ST_HALF, stage:%s on %s",
            self.stage, self:ToString())
        return
    end
    
    local fadeOutKeepTime = self.DialogueConfig.FadeOutKeepTime
    if fadeOutKeepTime and fadeOutKeepTime  > 0 then
        Log.InfoFormat("[DialogueV2]OnFadeOutFirstHalfDone, keep black screen for %s seconds on %s", fadeOutKeepTime, self:ToString())
        self:AddTimer(fadeOutKeepTime, 1, "OnTimerKeepBlackScreenDone")
    else
        Log.InfoFormat("[DialogueV2]OnFadeOutFirstHalfDone on %s", self:ToString())
        self:ProgressStage()
    end
end

function NormalDialogueInstance:OnTimerKeepBlackScreenDone()
    Log.DebugFormat("[DialogueV2]OnTimerKeepBlackScreenDone on %s", self:ToString())
    self:ProgressStage()
end

function NormalDialogueInstance:ON_STAGE_END_PLAY()
    Log.InfoFormat("[ON_STAGE_END_PLAY]dialogue: %s", self:ToString())
    self:HandleBeforeEndPlay()

    -- 处理相机模式
    Game.CameraManager:EnableDialogueCamera(false)
    -- 处理各单位显隐
    self:DealEntityVisibilityAfterDialogueEnd()
    
    -- 关闭UI
    Game.DialogueManagerV2.UIProcessor:CloseDialoguePanel()
    -- 处理外部事件
    self:DealStateAndEventOnEnd(DialogueConst.END_REASON.NORMAL)
    self.bActivated = false

    -- 解除输入的禁用
    self:LockPlayerInput(false)
    
    self:ProgressStage()
end

function NormalDialogueInstance:ON_STAGE_CAMERA_FADE_OUT_2ND_HALF()
    if not self:NeedFadeOut() then
        self:ProgressStage()
        return
    end
    
    local BlackScreen = UIPanelConfig.BlackScreenPanel
    local time = self.__CameraFadeStageTime__
    local uiMgr = Game.NewUIManager
    if uiMgr:IsOpened(BlackScreen) then
        uiMgr:InvokePanel(BlackScreen, "Refresh", time, false, "OnFadeOutDone", self)
    else
        uiMgr:OpenPanel(BlackScreen, time, false, "OnFadeOutDone", self)
    end

    Log.InfoFormat("[DialogueV2]ON_STAGE_CAMERA_FADE_OUT_2ND_HALF, fade time:%s on %s", time, self:ToString())
end

function NormalDialogueInstance:OnFadeOutDone()
    if self.stage ~= DialogueConst.STAGE.CAMERA_FADE_OUT_2ND_HALF then
        Log.WarningFormat("[DialogueV2]OnFadeOutDone, but stage is not CAMERA_FADE_OUT_2ND_HALF, stage:%s on %s",
            self.stage, self:ToString())
        return
    end
    
    Log.DebugFormat("[DialogueV2]OnFadeOutDone on %s", self:ToString())
    Game.NewUIManager:ClosePanel(UIPanelConfig.BlackScreenPanel)
    self:ProgressStage()
end
--endregion Stage


---获取第一个分镜相机名称,可能不存在
---@private
---@return string|nil
function NormalDialogueInstance:getFirstShotCameraName()
    local allTracksConfig = self:GetAllTrackConfigsInEpisode(1)
    for _, trackConfig in ksbcipairs(allTracksConfig) do
        if trackConfig.SectionType == DialogueConst.DIALOGUE_SECTION_TYPE.DIALOGUE_SHOT or
            trackConfig.SectionType == DialogueConst.DIALOGUE_SECTION_TYPE.DIALOGUE_SHOT_OLD
        then
            if #trackConfig.ActionSections > 0 then
                return trackConfig.ActionSections[1].TargetCamera
            end
        end
    end
end

function NormalDialogueInstance:OnDialogueActionKeyUp()
    Log.DebugFormat("[DialogueV2][NormalInstance]OnDialogueActionKeyUp")
    Game.GlobalEventSystem:Publish(EEventTypesV2.ON_DIALOGUE_PANEL_CLICKED)
end

function NormalDialogueInstance:OnDialogueActionKeyLongPressed()
    Log.DebugFormat("OnDialogueActionKeyLongPressed")
    -- self:SkipEpisode()
end

function NormalDialogueInstance:LockPlayerInput(bLock)
    Log.InfoFormat("[DialogueV2]LockPlayerInput, bLock:%s on %s", bLock, self:ToString())
    Game.InputManager:DisableControllerInput(Enum.ELocoControlTag.Dialogue, bLock, true)
end

function NormalDialogueInstance:NeedFadeIn()
    local needFadeIn = self.DialogueConfig.NeedFadeIn 
    if not needFadeIn or needFadeIn == DialogueConst.FADE_IN_TYPE.NONE then
        return false
    end
    
    return true
end

function NormalDialogueInstance:NeedFadeOut()
    local needFadeOut = self.DialogueConfig.NeedFadeOut
    if not needFadeOut or needFadeOut == DialogueConst.FADE_OUT_TYPE.NONE then
        return false
    end
    
    return true
end

function NormalDialogueInstance:TryFinishOnSequenceFinished()
    local episode = self.currentEpisode
    if episode and not episode.isDestroyed then
        Log.InfoFormat("[DialogueV2]TryFinishOnSequenceFinished %s", self:ToString())
        episode:Tick(0, false)
        if episode:IsFinished() then
            self:FinishEpisode(episode, false)
        end
    else
        Log.ErrorFormat("[DialogueV2]TryFinishOnSequenceFinished failed: instance may be destroyed,dialogueID maybe %s",
            self.DialogueID)
    end
end

function NormalDialogueInstance:SetViewTargetToFirstCamera()
    local firstCameraName = self:getFirstShotCameraName()
    
    ---@type DialogueCamera
    local cameraPtpEntity = self.ptpManager:GetParticipantEntityByName(firstCameraName)
    if not cameraPtpEntity then
        Log.WarningFormat("[DialogueV2]SetViewTargetToFirstCamera failed: cameraPtpEntity not found,firstCameraName:%s dialogue:%s",
            firstCameraName, self:ToString())
        return
    end
    
    cameraPtpEntity:AdjustTransformForCameraConfig()
    Log.InfoFormat("[DialogueV2]SetViewTargetToFirstCamera, init dialogue camera to cameraPtpEntity:%s[%s] camera name:%s",
        cameraPtpEntity, cameraPtpEntity:uid(), firstCameraName)
    
    Game.CameraManager:SetDialogueCameraWithCustomBlend(cameraPtpEntity.CharacterID, 0,
        ECameraEaseFunction.Linear, ECameraViewBlendFunction.Linear)
end

function NormalDialogueInstance:InitAutoPlay()
    local bPlayerAutoPlaySetting = Game.DialogueManagerV2:GetPlayerAutoPlaySetting()
    local bAutoPlay = bPlayerAutoPlaySetting
    
    local autoPlayType = self.DialogueConfig.AutoPlayType
    local bAutoPlayInConfig = false
    if autoPlayType and autoPlayType == Enum.EDialogueAutoPlayType.ShowUIAndAutoPlay then
        bAutoPlayInConfig = true
        bAutoPlay = true
    end

    Log.InfoFormat("[DialogueV2]InitAutoPlay, bAutoPlay:%s, bAutoPlayInConfig:%s, PlayerAutoPlaySetting:%s dialogue:%s",
        bAutoPlay, bAutoPlayInConfig, bPlayerAutoPlaySetting, self:ToString())
    
    self:SetAutoPlay(bAutoPlay)
end 