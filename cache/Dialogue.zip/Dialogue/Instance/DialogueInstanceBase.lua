---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/7 11:20
---
local TimerBase = kg_require("Framework.KGFramework.KGCore.TimerManager.TimerBase").TimerBase
local DialogueParticipantManager = kg_require("Gameplay.DialogueV2.DialogueParticipantManager").DialogueParticipantManager
--local DialogueInputHandler = kg_require("Gameplay.DialogueV2.DialogueInputHandler").DialogueInputHandler
local DialogueEpisode = kg_require("Gameplay.DialogueV2.DialogueEpisode").DialogueEpisode
local PostProcessConst = kg_require("Gameplay.Effect.PostProcessConst")
local NiagaraEffectConst = kg_require("Gameplay.Effect.NiagaraEffectConst")
local NewHeadInfoConst = kg_require("Gameplay.LogicSystem.NewHeadInfo.System.NewHeadInfoConst")

local NIAGARA_EFFECT_TAG = NiagaraEffectConst.NIAGARA_EFFECT_TAG
local NIAGARA_HIDDEN_REASON = NiagaraEffectConst.NIAGARA_HIDDEN_REASON

---@class DialogueInstanceBase : TimerBase
---@field DialogueConfig DialogueTable
---@field bSimpleDialogue boolean
---@field bUseCSStyle boolean
---@field currentEpisode DialogueEpisode
---@field bShowCameraShot boolean
---@field bAutoPlay boolean @ 是否自动播放
---@field private bPendingTerminate boolean @ 是否等待终止
---@field private pendingTerminateReason DialogueEndReason @ 终止原因
---@field private tickLock number @ tick过程中的锁，标记是否处于Tick过程
DialogueInstanceBase = DefineClass("DialogueInstanceBase", TimerBase)

---@param playParams DialoguePlayParams
---@param dialogueType number
function DialogueInstanceBase:ctor(playParams, dialogueType)
    -- 添加参数验证
    if not playParams or not dialogueType then
        Log.Error("[DialogueV2]DialogueInstanceBase:ctor failed: Invalid parameters")
        return
    end

    self.stage = 0

    self.DialogueID = playParams.AssetID
    self.PlayParams = playParams
    self.DialogueType = dialogueType

    --region 一些关键状态
    ---标记对话表演真正开启
    self.bActivated = false
    ---标记暂停
    self.bPause = false
    ---标记是否可跳过
    self.bCanSkip = true
    --是否自动播放
    self.bAutoPlay = false
    --是否显示截屏
    self.bShowCameraShot = false
    ---跳过过程中的锁
    self.skipLock = nil
    --tick过程中的锁
    self.tickLock = nil
    self.bPendingTerminate = false
    self.pendingTerminateReason = nil
    --endregion 一些关键状态

    -- 预加载资源的loadID
    self.LoadIDPreloadRes = nil

    -- 对话资产静态数据
    self.DialogueConfig = nil

    ---@type DialogueParticipantManager
    self.ptpManager = nil

    ---@type DialogueInputHandler
    self.inputHandler = nil

    ---@type DialogueEpisode 当前正在播放的小段
    self.currentEpisode = nil

    ---@type number @ 总时长
    self.duration = 10

    ---@type number @ 当前小段播放的时长
    self.episodeRunningTime = 0

    ---@type number @ 当前播放的时长，包括当前正在播放的小段的时长
    self.runningTime = 0

    ---@type number @ 当前播放的真实世界时长，无视暂停，每帧持续累加的时长
    self.realWorldTime = 0

    ---@type boolean @ 是否使用CS样式
    self.bUseCSStyle = false

    ---@type boolean @ 是否在使用CSStyle样式时显示名字
    self.bShowTalkerNameInCSStyle = false

    ---@type boolean @ 是否屏蔽对话外后处理
    self.bDisableGamePostProcess = false
    self.counterDisableGamePP = 0

    -- 临时table
    self.tempArrayList = {}
    
    --- 黑板类
    self.BlackBoard = {}

    ---用于处理范围Npc隐藏的trigger
    self.rangeHideNpcTrigger = nil

    ---@type DialogueBarrierBase[] 暂停屏障
    self.tickBarriers = {}
	
	---@type table @ 使用后需要隐藏的entityID list
	self.hideCharacterList = playParams.HideCharacterList or {}
	
	---@type number @ 隐藏延迟时间
	self.hideDuration = playParams.HideDuration or 0

    ---@type table<DialogueSectionBase, DialogueSectionBase> @ 当前可以中断SkipPeriod流程的section列表，弱引用表
    self.sectionsBreakSkipPeriod = setmetatable({}, {__mode="kv"})
    
    -- 存储Cinematic结束后的回调
    if playParams and playParams.OnCinematicFinished then
        self.OnCinematicFinished = playParams.OnCinematicFinished
    else
        self.OnCinematicFinished = nil
    end
end

function DialogueInstanceBase:dtor()
    Log.DebugFormat("[DialogueV2]DialogueInstanceBase:dtor %s", self:ToString())
    self:ReleaseResource()
    Game.GlobalEventSystem:RemoveTargetAllListeners(self)
end

function DialogueInstanceBase:ToString()
    return string.format("%s:%s[%s]", self.__cname, tostring(self), self.DialogueID or "unknown")
end

---@public
function DialogueInstanceBase:RegisterStage()
    error("need override RegisterStage")
end

function DialogueInstanceBase:Init()
    Log.InfoFormat("[DialogueV2]Init dialogue instance:%s", self:ToString())
    
    -- 添加配置获取失败的处理
    self.DialogueConfig = self:GetDialogueConfig()
    if not self.DialogueConfig then
        Log.ErrorFormat("[DialogueV2]Init failed: get dialogue config for %s failed", self:ToString())
        return false
    end
    
    local dialogueAssetData = Game.TableData.GetDialogueAssetDataRow(self.DialogueID)
    
    self.bCanSkip = true
    self.bShowCameraShot = false
    if dialogueAssetData then
        if dialogueAssetData.CanSkip ~= nil then
            self.bCanSkip = dialogueAssetData.CanSkip
        end

        if dialogueAssetData.bOpenCameraShot ~= nil then
            self.bShowCameraShot = dialogueAssetData.bOpenCameraShot
        end
    end

    -- 每次起新的dialogueInstance，清理掉DialogueHistory的Review部分
    Game.DialogueManagerV2.DialogueHistory:ClearReview()
    -- 每次起新的dialogueInstance，读表清理所有的选项数据
    if dialogueAssetData and dialogueAssetData.bClearOptionSelected then
        Game.DialogueManagerV2.DialogueHistory:ClearSelectOptions()
    end

    -- 处理后处理逻辑
    self.bDisableGamePostProcess = false
    if self.DialogueConfig.bDisableGamePostProcess ~= nil then
        self.bDisableGamePostProcess = self.DialogueConfig.bDisableGamePostProcess
    end

    if self.bDisableGamePostProcess then
        self:DisableGamePostProcess()
    end
    
    return true
end

function DialogueInstanceBase:UnInit()
    self:HandleBeforeFinish()
end

---对话EndPlay前触发一些清理逻辑
---@protected
function DialogueInstanceBase:HandleBeforeEndPlay()
    self:HandleBlackBoardBeforeEndPlay()

    self:destroyCurEpisode("InstanceEndPlay")
end

---对话真正结束前的清理,状态重置,事件触发,时序很重要,如果修改需要多测
---@protected
function DialogueInstanceBase:HandleBeforeFinish()
    self:destroyCurEpisode("InstanceFinished")
    
    -- 上面所有Section结束,有些黑板值才会设置上来
    self:HandleBlackBoardBeforeFinish()

    for idx = #self.tickBarriers, 1, -1 do
        local barrier = self.tickBarriers[idx]
        if barrier and not barrier.isDestroyed then
            barrier:FinishBarrier()
        end
        self.tickBarriers[idx] = nil
    end

    -- 前面的Section结束和黑板值有的依赖演员,所以演员要在之后销毁
    if self.ptpManager then
        self.ptpManager:UnInit()
        self.ptpManager = nil
    end

    -- 恢复后处理屏蔽逻辑
    if self.bDisableGamePostProcess then
        Game.NewPostProcessManager:DisablePPBySourceType(PostProcessConst.PP_SOURCE_TYPE.GAME, false)
    end

    self:ReleaseResource()
	
	local preloadRes = self.DialogueConfig.PreloadRes
	if preloadRes then
		for _, res in ksbcipairs(preloadRes) do
			if res.Type == DialogueConst.PRELOAD_RES_TYPE.Sequence then
				if res.PathName then
					local Task = Game.SequenceManager:FindPlayTaskByTypeAndAssetID(Enum.CinematicType.DialogueSequence, tonumber(res.PathName))
					if Task then
						Game.SequenceManager:Terminate(Task:GetLoadHandleID())
					end
				end
			end
		end
	end
end

---获取对话Table,可以重载
---@protected
function DialogueInstanceBase:GetDialogueConfig()
    if self.DialogueConfig then
        return self.DialogueConfig
    end
    return Game.DialogueManagerV2:GetDialogueConfig(self.DialogueID)
end

---处理对话表演开始前的逻辑
---@public
function DialogueInstanceBase:Activate()
    Log.InfoFormat("[DialogueV2]Activate Dialogue:%s", self:ToString())
    self:ProgressStage()
end

---处理对话表演结束后的逻辑
---@public
function DialogueInstanceBase:Deactivate()
    Log.InfoFormat("[DialogueV2]Deactivate Dialogue:%s", self:ToString())
    if self.stage == DialogueConst.STAGE.CAMERA_FADE_OUT_1ST_HALF  then
        -- CAMERA_FADE_OUT_1ST_HALF阶段如有黑屏淡出的处理，需要等待FadeIn效果完成才能继续
        return
    end

    self:ProgressStage()
end

--- 获取时长
---@return number
function DialogueInstanceBase:GetDuration()
    return self.duration
end

---外部中断对话
---@public
---@param endReason DialogueEndReason
function DialogueInstanceBase:Terminate(endReason)
    if self.tickLock then
        --处于tick过程中，如果发生中断，直接放到Tick末尾执行，这么做的原因是为了防止Tick过程中销毁导致各种逻辑的错乱
        self.bPendingTerminate = true
        self.pendingTerminateReason = endReason
        Log.WarningFormat("[DialogueV2]Pending terminate dialogue:%s, Stage=%d terminate reason:%s, will be executed on Tick end", 
            self:ToString(), self.stage or -1, endReason)
        return
    end
    
    Log.InfoFormat("[DialogueV2]Terminate Dialogue:%s, Stage=%d terminate reason:%s", 
        self:ToString(), self.stage or -1, endReason)
    
    -- 将状态强制设置为FINISH，中断当前可能的ProgressStage流程
    self.stage = DialogueConst.STAGE.FINISH
    
    -- 中断不走stage逻辑,直接退出
    self:destroyCurEpisode(endReason)

    self:HandleBlackBoardBeforeFinish()

    self:DealEntityVisibilityAfterDialogueEnd()

    if self.ptpManager then
        self.ptpManager:UnInit()
        self.ptpManager = nil
    end

    self:ReleaseResource()

    if Game.CameraManager then
        Game.CameraManager:EnableDialogueCamera(false)
    end

    Game.DialogueManagerV2.UIProcessor:CloseDialoguePanel()

    self:DealStateAndEventOnEnd(endReason)
end

---@protected
function DialogueInstanceBase:DealStateAndEventOnStart()
    local actorEntityID
    if self.PlayParams then
        actorEntityID = self.PlayParams.ActorEntityID
    end
    Game.GlobalEventSystem:Publish(EEventTypesV2.DIALOGUE_PLOT_ON_START, self.DialogueID, actorEntityID)
end

---@protected
---@param endReason DialogueEndReason
function DialogueInstanceBase:DealStateAndEventOnEnd(endReason)
    if endReason == nil then
        endReason = DialogueConst.END_REASON.NORMAL
    end

    -- 网络链接断开导致的中断，不触发OnCinematicFinished，因为网络断开后很多状态不对了，不能对话结束事件传递出去
    if endReason == DialogueConst.END_REASON.TERMINATE_ON_NET_DISCONNECTED then
        Log.InfoFormat("[DialogueV2]DealStateAndEventOnEnd, do not dispatch end event for endReason:%s", endReason)
        return
    end
    
    local lastOptionID = Game.DialogueManagerV2.DialogueHistory.LastOptionTextID
    Game.GlobalEventSystem:Publish(EEventTypesV2.DIALOGUE_PLOT_ON_END, 
        self.PlayParams and self.PlayParams.AssetID, 
        lastOptionID,
        self.PlayParams and self.PlayParams.NPCID, 
        self.PlayParams and self.PlayParams.ActorEntityID, 
        self.PlayParams and self.PlayParams.QuestID, 
        self.PlayParams and self.PlayParams.CondIdx,
		endReason
	)
    
    if self.OnCinematicFinished then
        Game.DialogueManagerV2:SetLastDialogueEndReason(endReason)
        xpcall(self.OnCinematicFinished, _G.CallBackError)
        Game.DialogueManagerV2:SetLastDialogueEndReason(nil)
    end
end

---@public
---@return boolean
function DialogueInstanceBase:IsPause()
    return self.bPause == true
end

---@public
---@param bFromBarrier boolean 暂停来自Barrier
function DialogueInstanceBase:PausePlay(bFromBarrier)
    -- 处于自动播放中,且没有锁,不能暂停
    if (not bFromBarrier) and (Game.DialogueManagerV2:IsAutoPlay() == true) and (self.skipLock == nil) then
        Log.InfoFormat("[DialogueV2]PausePlay failed for reason: in auto playing, cannot pause.Dialogue:%s", self:ToString())
        return
    end

    if self.bPause then
        Log.DebugFormat("[DialogueV2]PausePlaye faield for reason: in pausing, cannot reentrancy.Dialogue:%s", self:ToString())
        return
    end

    Log.InfoFormat("[DialogueV2]PausePlay Dialogue:%s", self:ToString())
    self.bPause = true
    if self.currentEpisode then
        self.currentEpisode:PauseEpisode()
    end
end

---@public
function DialogueInstanceBase:ResumePlay()
    if not self.bPause then
        Log.DebugWarningFormat("[DialogueV2]ResumePlay failed for reason: in playing, cannot reentrancy.Dialogue:%s", self:ToString())
        return
    end

    Log.InfoFormat("[DialogueV2]ResumePlay Dialogue:%s", self:ToString())
    self.bPause = false
    if self.currentEpisode then
        self.currentEpisode:ResumeEpisode()
    end
end

---@public
---@param deltaTime number
---@param bSkip boolean
function DialogueInstanceBase:Tick(deltaTime, bSkip)
    if not self.bActivated then
        return
    end

    self.tickLock = 1
    local episodeRunningTime, runningTime, realWorldTime = self:updateTime(deltaTime)
    self:updateBarriers(deltaTime)

    self:tickEpisode(self.currentEpisode, episodeRunningTime, runningTime, realWorldTime, deltaTime, bSkip)

    self.runningTime = runningTime
    Game.DialogueManagerV2.UIProcessor:UpdateDialogueProgress(runningTime, self.duration)
    self.tickLock = nil

    if not self.isDestroyed then
        -- 在正常的Tick过程中，对话是会出现销毁的情况
        self:doPendingTerminate()
    end
end

---@public
---@param bAutoPlay boolean
function DialogueInstanceBase:OnAutoPlayStateChange(bAutoPlay)
    self:SetAutoPlay(bAutoPlay)
    -- 如果开启自动播放的同时在暂停中,继续
    if (bAutoPlay == true) and (self.bPause == true) then
        self:ResumePlay()
    end
end

---@public
function DialogueInstanceBase:ReleaseResource()
    Log.InfoFormat("[DialogueV2]ReleaseResource Dialogue:%s", self:ToString())
    self:releaseAssetLoadHandler()
    
    if self.bDisableGamePostProcess then
        self:EnableGamePostProcess(true)
    end
end

---@public
---@return number
function DialogueInstanceBase:GetCurEpisodeIndex()
    if not self.currentEpisode then
        return 0
    end

    return self.currentEpisode:GetEpisodeIndex()
end

---@public
---@param episodeIdx number
---@param dialogueLineIdx number @ 开始的台本序号，-1表示跳转到本小段的最后一个台本的结束位置
---@return PlayDialogueErrorCode, number?
function DialogueInstanceBase:CreateNewEpisode(episodeIdx, dialogueLineIdx)
    -- 先清理barrier
    for _, barrier in pairs(self.tickBarriers) do
        barrier:FinishBarrier()
    end
    table.clear(self.tickBarriers)

    self:destroyCurEpisode("CreateNewEpisode")

    local episodeConfig = self.DialogueConfig.Episodes[episodeIdx]
    if not episodeConfig then
        if episodeIdx == 0 then
            Log.DebugFormat("[DialogueV2]CreateNewEpisode failed: no episode idx %s in %s and deactivate dialogue", episodeIdx, self:ToString())
            self:Deactivate()
        else
            Log.ErrorFormat("[DialogueV2]CreateNewEpisode failed: no target episode config for episode index %s in %s", episodeIdx, 
                self:ToString())
        end
        return DialogueConst.PlayDialogueErrorCode.HAS_NO_EPISODE_CONFIG
    end

    Log.InfoFormat("[DialogueV2]CreateNewEpisode, episode index:%s on %s", episodeIdx, self:ToString())
    self.currentEpisode = DialogueEpisode.new(self, episodeIdx, episodeConfig)
    self.currentEpisode:Init()
    self.episodeRunningTime = 0

    local startTime = 0
    if self.PlayParams and self.PlayParams.StartEpisodeLineIdx then
        startTime = self.currentEpisode:StartEpisodeFromLineIndex(self.PlayParams.StartEpisodeLineIdx)
    elseif dialogueLineIdx and dialogueLineIdx ~= 0 then
        if dialogueLineIdx == -1 then
            startTime = self.currentEpisode:StartEpisodeFromSpecificTime(self.currentEpisode:GetDuration())
        else
            startTime = self.currentEpisode:StartEpisodeFromLineIndex(dialogueLineIdx)
        end
    else
        if self.PlayParams ~= nil and episodeIdx == self.PlayParams.StartEpisodeIndex and
            self.PlayParams.StartTime and self.PlayParams.StartTime >= 0 then
            startTime = self.PlayParams.StartTime
        end
    end
    return DialogueConst.PlayDialogueErrorCode.SUCCESS, startTime
end

---获取下个小段index,如果没有就返回-1
---@private
---@return number
function DialogueInstanceBase:getNextEpisodeIndex()
    local nextEpisodeIndex = self:GetCurEpisodeIndex() + 1

    local config = self.DialogueConfig
    if config and config.Episodes ~= nil and config.Episodes[nextEpisodeIndex] ~= nil then
        return nextEpisodeIndex
    else
        return -1
    end
end

function DialogueInstanceBase:GetEpisodeByIndex(EpisodeIndex)
    local config = self.DialogueConfig
    if not config or not config.Episodes then
        return nil
    end

    return config.Episodes[EpisodeIndex]
end

---@public
---@param barrierType number
---@param duration number|nil 传空表示无限时长
function DialogueInstanceBase:AddDialogueBarrier(barrierType, duration, ...)
    local barrierCls = DialogueConst.BARRIER_CLASS[barrierType]
    if not barrierCls then
        Log.ErrorFormat("[DialogueV2]AddDialogueBarrier failed: barrier type %s has no class existed", barrierType)
        return
    end

    ---@type DialogueBarrierBase
    local barrier = barrierCls.new(self, duration, ...)
    barrier:StartBarrier()
    table.insert(self.tickBarriers, barrier)
    Log.InfoFormat("[DialogueV2]AddDialogueBarrier: %s duration:%s in %s",
        barrier.__cname, duration, self:ToString())
    return barrier
end

---@param barrier DialogueBarrierBase
function DialogueInstanceBase:RemoveDialogueBarrier(barrier)
    for key, val in ipairs(self.tickBarriers) do
        if val == barrier then
            barrier:FinishBarrier()
            table.remove(self.tickBarriers, key)
            Log.InfoFormat("[DialogueV2]RemoveDialogueBarrier: %s in %s",
                barrier.__cname, self:ToString())
            break
        end
    end
end

---@public
function DialogueInstanceBase:OnDialoguePanelClicked()
    Log.InfoFormat("[DialogueV2]OnDialoguePanelClicked in %s", self:ToString())
    -- 没有屏障,点击就执行跳过
    if #self.tickBarriers == 0 then
        self:ResumePlay()
        return
    end

    -- 否则只执行屏障逻辑
    for idx = #self.tickBarriers, 1, -1 do
        local barrier = self.tickBarriers[idx]
        if barrier:CanSkip() then
            barrier:FinishBarrier()
            self.tickBarriers[idx] = nil
        end
    end

    -- 屏障都没了,也执行恢复
    if #self.tickBarriers == 0 then
        self:ResumePlay()
    end
end

function DialogueInstanceBase:TryResume()
	-- 没有屏障,点击就执行跳过
	if #self.tickBarriers == 0 then
		self:ResumePlay()
		return
	end
end

function DialogueInstanceBase:OnDialogueContentPause(dialogueID)
    if self.DialogueID == dialogueID then
        self:PausePlay()
    end
end

---跳过时的tick间隔,按30帧给
DialogueInstanceBase.__SkipTickUnit__ = 0.033

---直接跳到小段末尾
---@public
function DialogueInstanceBase:SkipEpisode()
	-- 如果currentEpisode已经无了，则直接跳过
	if not self.currentEpisode or self.currentEpisode.isDestroyed then
		Log.WarningFormat("[DialogueV2]SkipEpisode failed: currentEpisode has been destroyed.")
		return
	end
    Log.InfoFormat("[DialogueV2]SkipEpisode, dialogue:%s", self:ToString())
    -- 跳过时如果在暂停,需要先恢复
    if self:IsPause() then
        self:ResumePlay()
    end
    Game.DialogueManagerV2.UIProcessor:CallPanelFunction(DialogueConst.PanelFunction.TryFlushContentPrinter)
    
	self:SkipEntireDialogue()
end

---@public
---@param period number
function DialogueInstanceBase:SkipPeriodDialogue(period)
    if self.isDestroyed then
        Log.InfoFormat("[DialogueV2]SkipPeriodDialogue failed: instance is destroyed %s", self.DialogueID)
        return
    end

    if not self.Tick then
        Log.InfoFormat("[DialogueV2]SkipPeriodDialogue failed: Tick is nil, dialogue:%s", self.DialogueID)
        return
    end

    if self:HasBreakSkipPeriodSections() then
        Log.WarningFormat("[DialogueV2]SkipPeriodDialogue failed: has sections breaking skip period.")
        return
    end

    local skipTickUnit = Game.DialogueManagerV2.avgFrameTime or self.__SkipTickUnit__
    if not skipTickUnit then
        return
    end

    if skipTickUnit <= 0 or skipTickUnit > 0.1 then
        Log.WarningFormat("[DialogueV2]SkipPeriodDialogue failed: skipTickUnit is invalid: %s", skipTickUnit)
        skipTickUnit = self.__SkipTickUnit__
    end

    Log.InfoFormat("[DialogueV2]SkipPeriodDialogue dialogue:%s period=%s skipTickUnit=%s skipLock=%s", self:ToString(), period, skipTickUnit, self.skipLock)

    local strDialogue = self:ToString()
    self.skipLock = 1
    self.bBreakingSkipPeriod = nil -- 重置终止skip标记
    local STAGE_FINISH = DialogueConst.STAGE.FINISH

    local count = math.ceil(period / skipTickUnit)
    local success
    for i = count, 1, -1 do
        if period > skipTickUnit then
            period = period - skipTickUnit
            success = xpcall(self.Tick, _G.CallBackError, self, skipTickUnit, true)
        else
            success = xpcall(self.Tick, _G.CallBackError, self, period, true)
            period = 0
        end

        if not success then
            Log.DebugWarningFormat("[DialogueV2]SkipPeriodDialogue tick failed, left period:%s", period)
        end
        
        -- 如果有打断skip period流程的section执行了，需要推出当前skip流程
        if (not self.isDestroyed and self:HasBreakSkipPeriodSections()) or self.bBreakingSkipPeriod then
            Log.InfoFormat("[DialogueV2]SkipPeriodDialogue, has sections breaking skip period")
            break
        end

        -- 如果有其他section暂停了对话,那么这里也要暂停
        if self.bPause then
            Log.InfoFormat("[DialogueV2]SkipPeriodDialogue pause in process skip, period left %s", period)
            break
        end

        if self.stage == STAGE_FINISH then
            Log.InfoFormat("[DialogueV2]SkipPeriodDialogue dialogue is done, dialogue:%s", strDialogue)
            break
        end

        if period <= 0 then
            break
        end
    end

    self.skipLock = nil
    self.bBreakingSkipPeriod = nil
end

-- 设置黑板属性数据
---@param key DialogueBlackboardKey
---@param value any
---@param bNoLog boolean
function DialogueInstanceBase:SetBlackBoardValue(key, value, bNoLog)
    if not self.BlackBoard then
        self.BlackBoard = {}
    end
    self.BlackBoard[key] = value
    
    if not bNoLog then
        Log.DebugFormat("[DialogueV2]SetBlackBoardValue key:%s value:%s", key, tostring(value))
    end
end

-- 获取黑板属性数据
function DialogueInstanceBase:GetBlackBoardValue(key)
    if not self.BlackBoard then
        return nil
    end
    return self.BlackBoard[key]
end

--- 沿着Parent->Child链广度递归获取所有TrackConfig
---@public
---@return table[]
function DialogueInstanceBase:GetAllTrackConfigsInEpisode(episodeIdx)
    if not self.DialogueConfig or not self.DialogueConfig.Episodes then
        return {}
    end
    
    local episodeConfig = self.DialogueConfig.Episodes[episodeIdx]
    if not episodeConfig then
        return {}
    end


    local trackList = DialogueUtilV2.GetAllEpisodeTracksByRef(episodeConfig, false)
    local insert = table.insert
    local remove = table.remove
    -- 这里重新排序的原因是要每轮tick时都要最先tick到台本Section,因为台本section内部会控制对话的暂停状态
    for idx, track in ksbcipairs(trackList) do
        if track.TrackName == "Dialogue" then
            remove(trackList, idx)
            insert(trackList, 1, track)
            break
        end
    end

    return trackList
end

--- 获取TrackName下的所有Section，包含所有小段下的trackName轨道的section
---@param trackName string
---@return UDialogueActionBase[]
function DialogueInstanceBase:GetAllSectionsOnTrack(trackName)
    local trackList = {}
    local queue = {}

    local insert = table.insert
    local remove = table.remove
    local timeOffset = 0
    for _, episodeConfig in ksbcipairs(self.DialogueConfig.Episodes) do
        for _, v in ksbcipairs(episodeConfig.TrackList) do
            insert(queue, {v, timeOffset})
        end

        while #queue ~= 0 do
            local queueTrack = queue[1]
            remove(queue, 1)
            
            local track = queueTrack[1]
            if track.TrackName == trackName then
                insert(trackList, queueTrack)
            end
            
            if track.Childs then
                for _, v in ksbcipairs(track.Childs) do
                    insert(queue, { v, timeOffset })
                end
            end

            if track.Actions then
                for _, v in ksbcipairs(track.Actions) do
                    insert(queue, { v, timeOffset })
                end
            end
        end
        timeOffset = timeOffset + episodeConfig.Duration
    end
    
    local sections = {}
    for _, trackData in ksbcipairs(trackList) do
        local track = trackData[1]
        timeOffset = trackData[2]
        if track.ActionSections then
            for _, section in ksbcipairs(track.ActionSections) do
                insert(sections, { section, section.StartTime + timeOffset })
            end
        end
    end
    
    return sections
end
---控制非对话单位的显隐
---@public
---@param bVisible boolean
function DialogueInstanceBase:DealNonDialogueNpcVisibility(bVisible)
    ---@type WorldManager
    local worldMgr = Game.WorldManager
    local dialogueConfig = self.DialogueConfig
    if not dialogueConfig then
        Log.InfoFormat("[DialogueV2]DealNonDialogueNpcVisibility failed: has no dialogue config, dialogue:%s", self:ToString())
        return
    end

    Log.InfoFormat("[DialogueV2]DealNonDialogueNpcVisibility %s", bVisible)
    
    worldMgr:SetEntityVisibleByCategory(Enum.EHideEntityCategory.AoiPlayer, bVisible)
    worldMgr:SetEntityVisibleByCategory(Enum.EHideEntityCategory.PerformPet, bVisible)
	worldMgr:SetEntityVisibleByCategory(Enum.EHideEntityCategory.SecretPartner, bVisible)

    -- 处理服务器Npc
    local hideNpcType = dialogueConfig.HideNpcType
    if hideNpcType == DialogueConst.NPC_HIDE_TYPE.ALL then
        worldMgr:SetTaskNpcCategoryVisible(bVisible)
        worldMgr:SetEntityVisibleByCategory(Enum.EHideEntityCategory.Monster, bVisible)
        worldMgr:SetEntityVisibleByCategory(Enum.EHideEntityCategory.LocalClientVibeNpc, bVisible)
    elseif hideNpcType == DialogueConst.NPC_HIDE_TYPE.RANGE then
        local anchorLocation = self.ptpManager:GetAnchorPtpLocation()
        if self.rangeHideNpcTrigger then
            if Game.me and not Game.me.isDestroyed then
                worldMgr:ReleaseContinuousHiddenByDis(self.rangeHideNpcTrigger)
            else
                Log.WarningFormat("[DialogueV2]DealNonDialogueNpcVisibility failed: has no Game.me, dialogue:%s", 
                    self:ToString())
            end
            self.rangeHideNpcTrigger = nil
        end

        if not bVisible then
            if Game.me and not Game.me.isDestroyed then
                self.rangeHideNpcTrigger = worldMgr:ClaimContinuousHiddenByDis(anchorLocation,
                    dialogueConfig.HideNpcRange)
            else
                Log.WarningFormat("[DialogueV2]DealNonDialogueNpcVisibility failed: has no Game.me, dialogue:%s", 
                    self:ToString())    
            end
        end
    
        for _, performerConfig in ksbcipairs(dialogueConfig.PerformerList) do
            if not performerConfig.bIsPlayer then
                worldMgr:SetNpcInvisibleControlByConfigIDForDialogue(not bVisible, performerConfig.AppearanceID)
            end
        end
    elseif hideNpcType == DialogueConst.NPC_HIDE_TYPE.SAME_CONFIG then
        for _, performerConfig in ksbcipairs(dialogueConfig.PerformerList) do
            worldMgr:SetNpcInvisibleControlByConfigIDForDialogue(not bVisible, performerConfig.AppearanceID)
        end
    end

    -- 处理特效
    Game.EffectManager:UpdateNiagaraHiddenStateByEffectTag(NIAGARA_EFFECT_TAG.BATTLE, not bVisible,
        NIAGARA_HIDDEN_REASON.DIALOGUE)

    -- 处理氛围Npc
    if dialogueConfig.HideAtmosphereNpc then
        worldMgr:SetEntityVisibleByCategory(Enum.EHideEntityCategory.MassAI, bVisible)
    end
end

---对话表演前,处理对话内外所有单位的显隐
---@protected
function DialogueInstanceBase:DealEntityVisibilityBeforeDialogueBegin()
    -- 未使用真人玩家,到一半时隐藏
    if not self.ptpManager.bUseRealMainPlayer then
		if Game.me then
			Game.me:ForceToInvisibleByDialogue()
		end
    end

    local entityUID = {}
    for _, participant in pairs(self.ptpManager.participants) do
        table.insert(entityUID, participant.dialogueEntityID)
    end

    Game.NewHeadInfoSystem:ApplySourceHiddenOnAllHeadInfos(NewHeadInfoConst.HeadInfoHiddenFlag.Dialogue, entityUID)
    Game.WorldWidgetManager2:HideAllLayers({UE.EWorldWidgetLayerType2.HeadInfo})

    -- 处理其他单位显隐
    self:DealNonDialogueNpcVisibility(false)

    -- 处理所有参与者显隐
    self.ptpManager:SetParticipantDefaultVisibility()
end

---对话表演后,处理对话内外所有单位的显隐
---@protected
function DialogueInstanceBase:DealEntityVisibilityAfterDialogueEnd()
    -- 无论是否使用真人玩家，结束的时候强制清除Dialogue对玩家的显示控制
    if Game.me ~= nil then
        Game.me:CleanForceVisibleControlByDialogue()
    end

    Game.NewHeadInfoSystem:CancelSourceHiddenOnAllHeadInfos(NewHeadInfoConst.HeadInfoHiddenFlag.Dialogue)
    Game.WorldWidgetManager2:ShowAllLayers({UE.EWorldWidgetLayerType2.HeadInfo})

    -- todo: 针对不同状态下的Terminate接口实现后,就可以移除这里的保护
    -- 隐藏所有参与者
    if self.ptpManager then
        -- 处理其他单位显隐
        self:DealNonDialogueNpcVisibility(true)

        self.ptpManager:HideAllParticipant()
    end
end

---EndPlay时处理残留的黑板逻辑
---@private
function DialogueInstanceBase:HandleBlackBoardBeforeEndPlay()
    local sequencePlayID = self:GetBlackBoardValue(DialogueConst.BlackBoardKey.SEQUENCE_PLAY_ID)
    if sequencePlayID then
        Game.DialogueManagerV2.SequenceManager:StopLevelSequence(sequencePlayID)
    end
end

---结束时处理残留的黑板逻辑
---@private
function DialogueInstanceBase:HandleBlackBoardBeforeFinish()
    local blackboardKey = DialogueConst.BlackBoardKey.ASPECT_RATIO_CROSS_EPISODES
    local aspectRatioCrossEpisodes = self:GetBlackBoardValue(blackboardKey)
    if aspectRatioCrossEpisodes then
        Game.NewUIManager:ClosePanel(aspectRatioCrossEpisodes.UINameOpened)
        self:SetBlackBoardValue(blackboardKey, nil)
    end
    
    -- 重置雾效
    local bNeedRestFog = self:GetBlackBoardValue(DialogueConst.BlackBoardKey.NEED_RESET_FOG)
    if bNeedRestFog then
        Game.NewPostProcessManager:RemoveFog(0, PostProcessConst.PP_SOURCE_TYPE.DIALOGUE)
    end

    -- 重置后效
    local ppIDList = self:GetBlackBoardValue(DialogueConst.BlackBoardKey.POST_PROCESS_ID_LIST)
    for _, ppID in pairs(ppIDList or {}) do
        Game.NewPostProcessManager:StopPostProcessByPPToken(ppID)
    end

    -- 重置因后效设置而受影响的单位
    local ppExcludePerformerList = self:GetBlackBoardValue(DialogueConst.BlackBoardKey.PP_EXCLUDE_PERFORMERS)
    for _, ptpName in pairs(ppExcludePerformerList or {}) do
        self.ptpManager:SetPtpExcludeFromPostProcess(ptpName, false)
    end

    -- 重置简易相机模式
    local bNeedExitSimpleCameraMode = self:GetBlackBoardValue(DialogueConst.BlackBoardKey.NEED_EXIT_SIMPLE_CAMERA_MODE)
    if bNeedExitSimpleCameraMode then
        Game.CameraManager:EnableSimpleDialogueCamera(false)
    end

    -- 重置相机摇晃
    local curCameraHandheldToken = self:GetBlackBoardValue(DialogueConst.BlackBoardKey.CAMERA_HANDHELD_TOKEN)
    if curCameraHandheldToken then
        Game.CameraManager:StopCameraShakeByToken(curCameraHandheldToken)
    end

    -- 如果有黑屏白字界面没关闭,需要关闭
    local bNeedCloseScreenText = self:GetBlackBoardValue(DialogueConst.BlackBoardKey.NEED_CLOSE_SCREEN_TEXT)
    if bNeedCloseScreenText then
        Game.GlobalEventSystem:Publish(EEventTypesV2.DIALOGUE_SCREEN_TEXT_FINISH)
    end

    table.clear(self.BlackBoard)
end

--region Stage


function DialogueInstanceBase:ON_STAGE_PRELOAD_RESOURCE()
    Log.InfoFormat("[DialogueV2]ON_STAGE_PRELOAD_RESOURCE Dialogue:%s", self:ToString())

    self.bUseCSStyle = self.DialogueConfig.bUseCSStyle or false
    self.bShowTalkerNameInCSStyle = self.DialogueConfig.bShowTalkerNameInCSStyle or false
    self.duration = 0
    local duration = self.DialogueConfig.Duration
    if duration then
        self.duration = duration
    end

    Game.DialogueManagerV2.AssetMgr:PreloadDialogue(self.DialogueID, self.DialogueConfig, 100, self, "OnResourceLoaded")

	if _G.StoryEditor then
		-- 资源加载完毕，在这里处理角色补光
		local levelPath
		local currentLevel = Game.LevelManager.GetCurrentLevel()
		if currentLevel then
			levelPath = currentLevel.LevelPath
		end

		if levelPath then
			Game.CharacterLightManager:RefreshLightFixDataReference(levelPath)
			Game.CharacterLightManager.cppMgr.bActive = true
			Game.CharacterLightManager:ActivateCharacterLight()
		end
	end
end

function DialogueInstanceBase:OnResourceLoaded(loadId, loadObjects)
    Log.InfoFormat("[DialogueV2]OnResourceLoaded for Dialogue:%s", self:ToString())
    self:ProgressStage()
end

function DialogueInstanceBase:ON_STAGE_SPAWN_PARTICIPANT()
    self.ptpManager = DialogueParticipantManager.new(self)
    self.ptpManager:SpawnAllParticipant()
end

function DialogueInstanceBase:OnAllParticipantReady()
    Log.InfoFormat("[DialogueV2]OnAllParticipantReady for dialogue:%s", self:ToString())
    
    local startEpisodeIdx = 1
    if self.PlayParams and self.PlayParams.StartEpisodeIndex then
        startEpisodeIdx = self.PlayParams.StartEpisodeIndex
    end
    self:CreateNewEpisode(startEpisodeIdx, nil, self.PlayParams and self.PlayParams.StartTime)
    self:ProgressStage()
end

function DialogueInstanceBase:ON_STAGE_FINISH()
    Game.DialogueManagerV2:OnDialogueFinished(self.DialogueID)
end

--endregion Stage


--region StageProgress


---阶段函数公共前缀
DialogueInstanceBase.__StageFuncPrefix__ = "ON_STAGE_"

---步进阶段
---@protected
function DialogueInstanceBase:ProgressStage()
    if self.isDestroyed then
        Log.WarningFormat("[DialogueV2]ProgressStage failed: dialogue instance[%s] is destroyed.", self.DialogueID)
        return
    end
    
    self.stage = self.stage + 1

    if self.stage > DialogueConst.STAGE.FINISH then
        Log.WarningFormat("[[DialogueV2]ProgressStage failed: dialogue instance[%s] is finished.", self.DialogueID)
        return
    end

    -- 如果未注册对应阶段,则继续步进到下一个阶段
    if not self.registeredInStage or not self.registeredInStage[self.stage] then
        Log.WarningFormat("[DialogueV2]ProgressStage failed: stage:%s is not registed and go to next stage", DialogueConst.STAGE_NAME[self.stage])
        self:ProgressStage()
        return
    end

    local stageName = DialogueConst.STAGE_NAME[self.stage]
    local funcName = string.format("%s%s", self.__StageFuncPrefix__, stageName)
    local func = self[funcName]
    if (func == nil) or (type(func) ~= "function") then
        Log.ErrorFormat("[DialogueV2]ProgressStage failed: %s:%s stage function not implemented in %s", stageName, self.stage,
            self:ToString())
        return
    end

    Log.InfoFormat("[DialogueV2]ProgressStage stage %s:%s in dialogue %s", self.stage, stageName, self:ToString())
    xpcall(func, _G.CallBackError, self)
end

---跳到指定阶段
---@protected
function DialogueInstanceBase:SkipToTargetStage(newStage)
    Log.InfoFormat("[DialogueV2]SkipToStage stage %s in dialogue %s", newStage, self:ToString())
    self.stage = newStage - 1
    self:ProgressStage()
end

--endregion StageProgress

--- 更新时间
---@private
---@param deltaTime number
---@return number, number
function DialogueInstanceBase:updateTime(deltaTime)
    self.realWorldTime = self.realWorldTime + deltaTime

    local bPause = self.bPause
    local runningTime = self.runningTime
    if not bPause then
        runningTime = runningTime + deltaTime
    end

    local duration = self.duration
    if duration > 0 and runningTime > duration then
        runningTime = duration
    end
    self.runningTime = runningTime

    -- 更新小段运行时长
    local episodeTime = self.episodeRunningTime
    if not bPause then
        -- episode会在tick中进行stage的转换，当stage切换到Finish的时候会对episode
        -- 进行清理，导致self.currentEpisode为nil，同时这个是会在Episode结束的处理
        -- 函数CreateNewEpisode或者DialogueInstanceBase的HandleBeforeFinish里面更
        -- 新episodeRunningTime，所以这里要判断currentEpisode
        if self.currentEpisode then
            episodeTime = episodeTime + deltaTime

            local episodeDuration = self.currentEpisode:GetDuration()
            if episodeTime > episodeDuration then
                episodeTime = episodeDuration
            end

            self.episodeRunningTime = episodeTime
        end
    end

    
    return episodeTime, runningTime, self.realWorldTime
end

function DialogueInstanceBase:releaseAssetLoadHandler()
    if self.LoadIDPreloadRes then
        Game.DialogueManagerV2.AssetMgr:ReleaseHandler(self.LoadIDPreloadRes)
        self.LoadIDPreloadRes = nil
    end
end

function DialogueInstanceBase:DisableGamePostProcess()
    self.counterDisableGamePP = self.counterDisableGamePP + 1
    if self.counterDisableGamePP > 0 then
        Game.NewPostProcessManager:DisablePPBySourceType(PostProcessConst.PP_SOURCE_TYPE.GAME, true)
    end
    Log.InfoFormat("[DialogueV2]DisableGamePostProcess, counter:%s on %s",
        self.counterDisableGamePP, self:ToString())
end

---@param bForce boolean
function DialogueInstanceBase:EnableGamePostProcess(bForce)
    if bForce then
        self.counterDisableGamePP = 0
    else
        self.counterDisableGamePP = self.counterDisableGamePP - 1
        if self.counterDisableGamePP < 0 then
            self.counterDisableGamePP = 0
        end
    end

    if self.counterDisableGamePP == 0 then
        Game.NewPostProcessManager:DisablePPBySourceType(PostProcessConst.PP_SOURCE_TYPE.GAME, false)
    end
    
    Log.InfoFormat("[DialogueV2]EnableGamePostProcess, counter:%s bForce:%s on %s", 
        self.counterDisableGamePP, bForce, self:ToString())
end

function DialogueInstanceBase:CheckDialogueSubmit()
    return self.PlayParams.SubmitItemID or self.PlayParams.NewSubmitCfg
end

function DialogueInstanceBase:CheckAcceptQuest()
    return self.PlayParams.ReceiveRingID
end

---@param time number
---@return number, string, LocalEntityBase
function DialogueInstanceBase:GetNextCamera(time)
    if self.bFinish then
        return KG_INVALID_ID
    end
    
    local episode = self.currentEpisode
    if not episode then
        return KG_INVALID_ID
    end
    
    local TRACK_NAME_CAMERA_CUT = DialogueConst.TRACK_NAME_CAMERA_CUT
    local sectionsCameraCut = self:GetAllSectionsOnTrack(TRACK_NAME_CAMERA_CUT)
    
    local minTime = 999999999
    ---@type BPS_DialogueShot_C
    local sectionTarget
    for _, sectionData in ipairs(sectionsCameraCut) do
        local section = sectionData[1]
        local timeOffset = sectionData[2]
        if time <= timeOffset and timeOffset < minTime then
            minTime = timeOffset
            sectionTarget = section
        end
    end

    if sectionTarget then
        local entityCamera = self.ptpManager:GetParticipantEntityByName(sectionTarget.TargetCamera)
        if entityCamera then
            return entityCamera.CharacterID, sectionTarget.TargetCamera, sectionTarget.KeepPreShotTransform 
        else
            return KG_INVALID_ID, sectionTarget.TargetCamera
        end
    end
    
    return KG_INVALID_ID
end

---------------------------------- 新版 剧编跳过功能实现 ---------------------------------------
--- 获取当前dialogue的所有轨道信息，为每个轨道构造一个list，用于梳理跳过时需要执行的section逻辑
function DialogueInstanceBase:GetAllTrackTypesInDialogue()
	-- 因为任意Episode都会拥有全量的Track信息，所以从episode1取trackList即可
	local FirstEpisode = self.DialogueConfig.Episodes[1]
	if FirstEpisode then
		local TrackList = FirstEpisode.TrackList
		for trackIndex, Track in ipairs(TrackList) do

		end
	end
end

--- 获取当前DialogueInstance需要停下的episode，以及对应的停止时间
--- return EpisodeIndex:number, RunningTime:number
function DialogueInstanceBase:GetSkipJumpEpisodeAndTime()
	local Episodes = self.DialogueConfig.Episodes
	local PendingCompareList = {}
	-- 防止递归超时，添加递归上限
	local RecursiveNumLimit = 100

	local CurrentEpisode = Episodes[self.currentEpisode.episodeIdx]

	local LoopTimes = 0

	while true do
		local TrackList = CurrentEpisode.TrackList
		for TrackIndex, TrackConfig in ksbcipairs(TrackList) do
			for sectionIndex, sectionConfig in ksbcipairs(TrackConfig.ActionSections or {}) do
				if sectionConfig.Enable then
					if DialogueConst.CANNOT_SKIP_SECTION[sectionConfig.ObjectClass] then
						local sectionInfo = {trackName = TrackConfig.TrackName, sectionConfig = sectionConfig}
						table.insert(PendingCompareList, sectionInfo)
					end
				end
			end

			for _, actionConfig in ksbcipairs(TrackConfig.Actions or {}) do
				for sectionIndex, sectionConfig in ksbcipairs(actionConfig.ActionSections) do
					if sectionConfig.Enable then
						if DialogueConst.CANNOT_SKIP_SECTION[sectionConfig.ObjectClass] then
							local sectionInfo = {trackName = TrackConfig.TrackName, sectionConfig = sectionConfig}
							table.insert(PendingCompareList, sectionInfo)
						end
					end
				end
			end
		end

		-- 先检查是否存在需要暂停的Section.
		if #PendingCompareList > 0 then
			-- 找出StartTime最小的section，作为暂停点
			local StopStartTime = self.currentEpisode:GetDuration()
			for index, sectionInfo in ipairs(PendingCompareList) do
				local sectionConfig = sectionInfo.sectionConfig
				-- 找到当前episodeRunningTime往后的第一个暂停点
				if self.episodeRunningTime < sectionConfig.StartTime then
					if sectionConfig.StartTime < StopStartTime then
						StopStartTime = sectionConfig.StartTime
					end
				end
			end
			-- 找到了第一个暂停点，直接return
			return CurrentEpisode.EpisodeID, StopStartTime
		end

		-- 没有需要停住的section，检查是否有主动选项(选项一定是在小段最后)
		local bHasOption = false
		local optionNextEpisode = nil
		local Options = CurrentEpisode.Options
		if #Options > 0 then
			-- 剔除掉自动选项
			if #Options == 1 then
				local OptionConfig = Options[1]
				if OptionConfig.DialogueID ~= 0 then
					bHasOption = true
				else
					optionNextEpisode = OptionConfig.EpisodeID
				end
			else
				bHasOption = true
			end
		end

		if bHasOption then
			-- 有选项，直接返回当前小段的ID, 时长
			return CurrentEpisode.EpisodeID, CurrentEpisode.Duration
		else
            if CurrentEpisode.EpisodeID == #Episodes and (self:CheckAcceptQuest() or self:CheckDialogueSubmit()) then
                -- 如果是任务或者道具提交，则直接返回当前
                return CurrentEpisode.EpisodeID, CurrentEpisode.Duration
            end
            
			if optionNextEpisode then
				-- 选项自动执行，且有用一个跳转id
				CurrentEpisode = self.DialogueConfig.Episodes[optionNextEpisode]
			else
                ---- 如果没有选项/领取任务/提交道具，则获取下一个Episode(ID+1的Episode)
                --CurrentEpisode = self.DialogueConfig.Episodes[CurrentEpisode.EpisodeID + 1]
				return CurrentEpisode.EpisodeID, CurrentEpisode.Duration
			end
		end

		-- 如果没有Episode了，则break
		if not CurrentEpisode then
			break
		end

		-- 超过递归上限了，可能有死循环
		if LoopTimes >= RecursiveNumLimit then
			break
		end

		LoopTimes = LoopTimes + 1
	end

	return nil, nil
end


--- 跳过整段dialogue，当遇到阻塞性事件时停下(打开UI，提交道具，领取任务，主动选项)
function DialogueInstanceBase:SkipEntireDialogue()
	-- 检查下当前是不是不能跳过(已经处于暂停的section里面了)
	if self.currentEpisode:CheckInStopPoint() then
		-- 如果已经在暂停点里面了，则直接return
		return
	end
	local epIndex, epTime = self:GetSkipJumpEpisodeAndTime()
	if epIndex and epTime then
        Log.InfoFormat("[DialogueV2][DialogueInstanceBase]SkipEntireDialogue, jump to episode:%s, time:%s",
            epIndex, epTime)
		-- 找到了暂停episode以及对应的暂停时间点
		if self.currentEpisode.episodeIdx == epIndex then
			-- 如果需要跳到的episode和当前episode一致，则直接基于当前Episode进行跳转即可
			self:updateTime(epTime)
			self.currentEpisode:JumpToSpecificTime(epTime)
		else
			-- 如果episode和当前episode不一样，则需要创建Episode，并进行跳转
			self:CreateNewEpisode(epIndex)
			self:updateTime(epTime)
			self.currentEpisode:JumpToSpecificTime(epTime)
		end
	else
        Log.InfoFormat("[DialogueV2][DialogueInstanceBase]SkipEntireDialogue, jump to end, dialogue:%s", self:ToString())
		-- 处理所有section
		self:TerminateDialogueInstanceByJump()
		-- 没找到，直接结束当前dialogueInstance
		self:Deactivate()
	end
end

function DialogueInstanceBase:TerminateDialogueInstanceByJump()
	if self.currentEpisode then
		-- 先将当前instance时间更新到episode的结束
		local epTime = self.currentEpisode:GetRemainTime()
		self:updateTime(epTime)
		self.currentEpisode:TerminateDialogueEpisodeByJump()
	end
end

---------------------------------- 新版 剧编跳过功能实现 ---------------------------------------

---@param section DialogueSectionBase
function DialogueInstanceBase:AddBreakSkipPeriodSection(section)
    if not section then
        return
    end

    self.sectionsBreakSkipPeriod[section] = section
    Log.InfoFormat("[DialogueV2]AddBreakSkipPeriodSection section:%s on %s", section:ToString(), self:ToString())
end

---@param section DialogueSectionBase
function DialogueInstanceBase:RemoveBreakSkipPeriodSection(section)
    self.sectionsBreakSkipPeriod[section] = nil
    Log.InfoFormat("[DialogueV2]RemoveBreakSkipPeriodSection section:%s on %s", section:ToString(), self:ToString())
end

---@param DialogueSectionBase
function DialogueInstanceBase:BreakCurSkipPeriod(section)
    if section and self.skipLock ~= nil then
        self.bBreakingSkipPeriod = true
        Log.InfoFormat("[DialogueV2]BreakCurSkipPeriod by section:%s", section:ToString())
    end
end

---@return boolean
function DialogueInstanceBase:HasBreakSkipPeriodSections()
    if not next(self.sectionsBreakSkipPeriod) then
        return false
    end
    
    local count = 0
    for k, v in pairs(self.sectionsBreakSkipPeriod) do
        if v then
            if v.IsDestroyed then
                self.sectionsBreakSkipPeriod[k] = nil
            else
                count = count + 1
            end
        end
    end
    
    return count > 0
end

function DialogueInstanceBase:doPendingTerminate()
    if self.bPendingTerminate then
        Log.InfoFormat("[DialogueV2]doPendingTerminate, terminate reason:%s on %s", 
            self.pendingTerminateReason, self:ToString())
        self:Terminate(self.pendingTerminateReason)
        self.bPendingTerminate = false
        self.pendingTerminateReason = nil
    end
end

---@param deltaTime number
function DialogueInstanceBase:updateBarriers(deltaTime)
    local pendingRemoveIndex = self.tempArrayList
    table.clear(pendingRemoveIndex)
    
    local insert = table.insert
    local tickBarriers = self.tickBarriers
    for idx = #tickBarriers, 1, -1 do
        local barrier = tickBarriers[idx]
        if barrier and not barrier.isDestroyed then
            barrier:TickBarrier(deltaTime)
            if barrier:NeedFinish() then
                barrier:FinishBarrier()
                insert(pendingRemoveIndex, idx)
            end
        else
            insert(pendingRemoveIndex, idx)
        end
    end

    local remove = table.remove
    for idx = 1, #pendingRemoveIndex do
        remove(tickBarriers, idx)
    end
    
    table.clear(pendingRemoveIndex)
end

---@private
---@param episode DialogueEpisode
---@param episodeRunningTime number
---@param runningTime number
---@param realWorldTime number
function DialogueInstanceBase:tickEpisode(episode, episodeRunningTime, runningTime, realWorldTime, deltaTime, bSkip)
    if episode and not episode.isDestroyed then
        episode:SetTime(episodeRunningTime, runningTime, realWorldTime)
        episode:Tick(deltaTime, bSkip)

        if episode:IsFinished() then
            self:FinishEpisode(episode, bSkip)
        end
    end
end

function DialogueInstanceBase:TryFinishOnSequenceFinished()
end

---@param episodeID number
---@param dialogueLineIdx number
function DialogueInstanceBase:PlayEpisode(episodeID, dialogueLineIdx)
    local result, startTime = self:CreateNewEpisode(episodeID, dialogueLineIdx)
    if result == DialogueConst.PlayDialogueErrorCode.SUCCESS then
        if startTime and startTime > 0 then
            self.runningTime = self.runningTime + startTime
            self.episodeRunningTime = startTime
        end
        
        self:tickEpisode(self.currentEpisode, self.episodeRunningTime, self.runningTime, self.realWorldTime, 0, false)
    end
    return result
end

---@param episode DialogueEpisode
---@param bSkip boolean
function DialogueInstanceBase:FinishEpisode(episode, bSkip)
    if self.isDestroyed then
        Log.WarningFormat("[DialogueV2]FinishEpisode failed:instance is destroyed, dialogueID:%s", self.DialogueID)
        return
    end
    
    Log.InfoFormat("[DialogueV2]FinishEpisode episode:%s bSkip:%s", episode:ToString(), bSkip)
    local selectedOptionData = episode.SelectedOptionData
    if selectedOptionData then
        if selectedOptionData.OptionID ~= 0 then
            episode:ExecuteSelectOption(selectedOptionData)
        else
            self:PlayEpisode(selectedOptionData.EpisodeID, selectedOptionData.DialogueLineIdx)
        end
    elseif self.DialogueConfig.Unique == false and (episode:GetLoopTimes() == -1 or episode:GetLoopTimes() > 0) then
        local loopTimes = episode:GetLoopTimes()
        self:CreateNewEpisode(episode.episodeIdx)
        local leftLoopTimes
        if loopTimes == -1 then
            leftLoopTimes = -1
        else
            leftLoopTimes = loopTimes - 1
        end

        self.currentEpisode:SetLoopTimes(leftLoopTimes)
        self:tickEpisode(self.currentEpisode, 0, self.runningTime, self.realWorldTime, 0, bSkip)
    else
        self:Deactivate()
    end
end

function DialogueInstanceBase:SetAllParticipantsVisibility(bVisible, tag)
    local ptpMgr = self.ptpManager
    if ptpMgr and not ptpMgr.isDestroyed then
        ptpMgr:SetAllParticipantsVisibility(bVisible, tag)
    end
end

function DialogueInstanceBase:IsSkipLock()
    return self.skipLock ~= nil
end

function DialogueInstanceBase:IsAutoPlay()
    return self.bAutoPlay
end 

---@param bAutoPlay boolean
function DialogueInstanceBase:SetAutoPlay(bAutoPlay)
    self.bAutoPlay = bAutoPlay
    Log.InfoFormat("[DialogueV2]SetAutoPlay bAutoPlay:%s on %s", bAutoPlay, self:ToString())
end 

---@private
---@param destroyReason string
function DialogueInstanceBase:destroyCurEpisode(destroyReason)
    local curEpisode = self.currentEpisode
    if curEpisode and not curEpisode.isDestroyed then
        Log.InfoFormat("[DialogueV2]destroy current episode:%s reason:%s in %s", curEpisode:ToString(), destroyReason, self:ToString())
        self.episodeRunningTime = curEpisode:GetDuration()
        curEpisode:UnInit()
        curEpisode:delete()
        self.currentEpisode = nil
    end
end 