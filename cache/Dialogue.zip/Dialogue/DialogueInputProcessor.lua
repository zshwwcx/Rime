---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/7 14:42
---
---
local TimerBase = kg_require("Framework.KGFramework.KGCore.TimerManager.TimerBase").TimerBase
local InputConst = kg_require("Gameplay.3C.Input.InputConst")
local ETriggerEvent = InputConst.ETriggerEvent
local InputAction = InputConst.InputAction

---@class DialogueInputProcessor: TimerBase
---@field private keyPressTime number
---@field private timerLongPress Timer
---@field public OnDialogueActionKeyUp LuaDelegate
---@field public OnDialogueActionKeyLongPressed LuaDelegate
DialogueInputProcessor = DefineClass("DialogueInputProcessor", TimerBase)

local LuaDelegate = kg_require("Framework.KGFramework.KGCore.Delegates.LuaDelegate").LuaDelegate
local ULLFunc = import("LowLevelFunctions")
function DialogueInputProcessor:ctor()
    ---@type number
    self.keyPressTime = nil
    self.timerLongPress = nil
    self.OnDialogueActionKeyUp = LuaDelegate.new()
    self.OnDialogueActionKeyLongPressed = LuaDelegate.new()
end

function DialogueInputProcessor:Init()
    Game.InputManager:BindInput(InputAction.IA_Dialogue, ETriggerEvent.StartedAndCompleted, "OnDialogue", self)
end

function DialogueInputProcessor:UnInit()
    Game.InputManager:UnBindInput(InputAction.IA_Dialogue, ETriggerEvent.StartedAndCompleted, "OnDialogue", self)
end

function DialogueInputProcessor:OnDialogue(ActionName, TriggerEvent, AxisX, AxisY)
    if TriggerEvent == InputConst.ETriggerEvent.Started then
        self:OnKeyDown()
    else
        self:OnKeyUp()
    end
end

function DialogueInputProcessor:OnKeyDown()
    self.keyPressTime = ULLFunc.GetUtcMillisecond()
    if self.timerLongPress then
		self:DelTimer(self.timerLongPress)
    end
	
	self.timerLongPress = self:AddGameTimeTimer(DialogueConst.LONG_PRESS_TIME, 1, "OnLongPress")
end

function DialogueInputProcessor:OnKeyUp()
    if self.timerLongPress then
		self:DelTimer(self.timerLongPress)
        self.timerLongPress = nil
    end

    self.keyPressTime = nil
    self.OnDialogueActionKeyUp:Execute()
end

function DialogueInputProcessor:OnLongPress()
    self.timerLongPress = nil
    self.OnDialogueActionKeyLongPressed:Execute()
end
