---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/7 14:26
---
local CollisionConst = kg_require("Shared.Const.CollisionConst")

kg_require("Gameplay.NetEntities.LocalEntity.LocalEntityBase")
local ViewControlVisibleComponent = kg_require("Gameplay.NetEntities.Comps.ViewControl.ViewControlVisibleComponent").ViewControlVisibleComponent
local ViewControlFxComponent = kg_require("Gameplay.NetEntities.Comps.ViewControl.ViewControlFxComponent").ViewControlFxComponent
local DialogueComponent = kg_require("Gameplay.DialogueV2.Entity.Component.DialogueComponent").DialogueComponent

---@class DialogueNiagara : LocalEntityBase
---@field OwnerParticipant DialogueParticipant
---@field ptpConfig UDialogueActor
---@field Position FVector
---@field Rotation FRotator
---@field IsDialogueLocalEntity boolean
---@field bIsReady boolean
---@field isAvatar boolean @ 是否为玩家
---@field bEnableDof boolean
DialogueNiagara = DefineLocalEntity("DialogueNiagara", LocalEntityBase, {
    ViewControlVisibleComponent,
    ViewControlFxComponent,
    DialogueComponent,
})

DialogueNiagara:Register("DialogueNiagara")

DialogueNiagara.DEFAULT_PRIMITIVE_COLLISION_PRESETS = {
    CollisionConst.COLLISION_PRESET_NAMES.NO_COLLISION_COMPONENT_PRESET
}

function DialogueNiagara:ctor()
    self.niagaraID = 0
    self.IsDialogueLocalEntity = true
    self.bIsReady = false
    self.bDialoguePerformer = false
end

function DialogueNiagara:AfterEnterWorld()
    Log.InfoFormat("[DialogueV2][DialogueNiagara]AfterEnterWorld %s uid:%s", self.ptpConfig.TrackName, self:uid())
    self.CppEntity:KAPI_Actor_AddActorTag(self.ptpConfig.TrackName)
    self.OwnerParticipant:CompleteReady()
    self.bIsReady = true
end

function DialogueNiagara:BeforeExitWorld()

end

---@public
---@param audioEventName string
function DialogueNiagara:ActivateNiagara(audioEventName)
    self.niagaraID = self:PlayNiagaraEffectAttached(self.ptpConfig.Effect)
    if audioEventName then
        self:SetEffectAudio(self.niagaraID, audioEventName)
    end
end

---@public
function DialogueNiagara:DeactivateNiagara()
    self:DestroyNiagaraSystem(self.niagaraID)
end

function DialogueNiagara:GetConfigTemplateID()
    return nil
end

function DialogueNiagara:GetConfigModelID()
    return nil
end
