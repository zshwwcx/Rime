---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/7 14:26
---
local CollisionConst = kg_require("Shared.Const.CollisionConst")
local WorldViewBudgetConst = kg_require("Gameplay.CommonDefines.WorldViewBudgetConst")
local NewHeadInfoConst = kg_require("Gameplay.LogicSystem.NewHeadInfo.System.NewHeadInfoConst")
local EHeadInfoActorTypes = NewHeadInfoConst.EHeadInfoActorTypes

kg_require("Gameplay.NetEntities.LocalEntity.LocalEntityBase")
local EquipUtils = kg_require("Shared.Utils.EquipUtils")
local ViewControlGazeComponent = kg_require("Gameplay.NetEntities.Comps.ViewControl.ViewControlGazeComponent").ViewControlGazeComponent
local MoveComponent = kg_require("Gameplay.NetEntities.Comps.MoveComponent").MoveComponent
local ViewControlRotateComponent = kg_require("Gameplay.NetEntities.Comps.ViewControl.ViewControlRotateComponent").ViewControlRotateComponent
local LocomotionControlComponent = kg_require("Gameplay.NetEntities.Comps.LocomotionControlComponent").LocomotionControlComponent
local FashionComponent = kg_require("Gameplay.NetEntities.Comps.FashionComponent").FashionComponent
local ComponentsUtil = kg_require("Gameplay.NetEntities.Comps.ViewControl.ComponentsUtil")
local DialogueComponent = kg_require("Gameplay.DialogueV2.Entity.Component.DialogueComponent").DialogueComponent
---@class DialoguePerformer : LocalEntityBase
---@field OwnerParticipant DialogueParticipant
---@field ptpConfig UDialogueActor
---@field Position FVector
---@field Rotation FRotator
---@field IsDialogueLocalEntity boolean
---@field bIsReady boolean
---@field isAvatar boolean @ 是否为玩家
---@field bEnableDof boolean
---@field TrackName  string
DialoguePerformer = DefineLocalEntity("DialoguePerformer", LocalEntityBase, {
    ViewControlGazeComponent,
    MoveComponent,
    ViewControlRotateComponent,
    LocomotionControlComponent,
    FashionComponent,
    DialogueComponent,
	table.unpack(ComponentsUtil.SimpleViewControlComponents)
})

DialoguePerformer:Register("DialoguePerformer")

DialoguePerformer.DEFAULT_PRIMITIVE_COLLISION_PRESETS = {
    CollisionConst.COLLISION_PRESET_NAMES.MOVABLE_UNIT_WITH_LOCAL_DRIVE_PRESET,
    CollisionConst.COLLISION_PRESET_NAMES.NO_COLLISION_COMPONENT_PRESET
}

function DialoguePerformer:ctor()
    self.Position = self.Position or { 0, 0, 0 }
    self.Rotation = self.Rotation or { 0, 0, 0 }
    self.Scale3D = self.Scale3D or {1, 1, 1}
    self.animLoadID = 0    
    ---半透Section记录变量
    self.MaterialChangeReqID = 0

    -- 使用完整的动画组件功能
    self.bUseComplexAnimVersion = true
    self.IsDialogueLocalEntity = true
    self.bIsReady = false
    self.bDialoguePerformer = true
    self.bCloseBodyControl = self.bCloseBodyControl or false
end

function DialoguePerformer:GetHeadInfoActorType()
    return EHeadInfoActorTypes.DialogueActor
end

function DialoguePerformer:AfterEnterWorld()
	self:SetForceUseClothTeleport(true)
    Log.InfoFormat("[DialogueV2][DialoguePerformer]AfterEnterWorld %s uid:%s", self.ptpConfig.TrackName, self:uid())
    self.CppEntity:KAPI_Actor_AddActorTag(self.ptpConfig.TrackName)

    self.CppEntity:KAPI_SkeletalMesh_SetUpdateBoundWithFirstSkinnedBoneOnAllMesh(true)
	
	-- 这里将entity一定1cm，再移回去，是为了接口某些entity的mesh offset设置了不生效的问题
	-- 详情可以参考：
	-- #236683 【Bug】【剧情】10040086和10040488，里面都摆了一个黄水晶的NPC,然后这个黄水晶在剧编预览时和游戏中显示的不一样:ks-poor:预览时是摆好了紧贴着桌面的，但运行时会有一些浮空 
	-- https://gamecloud-redmine.corp.kuaishou.com/1007/projects/c7/issues/236683
	local x, y, z = self.CppEntity:KAPI_GetLocation_P()
	self.CppEntity:KAPI_SetLocation_P(x + 1, y, z)
	self.CppEntity:KAPI_SetLocation_P(x, y, z)

    local mainMeshID = self.CppEntity:KAPI_Actor_GetMainMesh()
    if mainMeshID >= 0 then
        LuaScriptAPI.SetSkeletalMeshUpdateAnimationInEditor(mainMeshID, true)
        LuaScriptAPI.SetSkeletalMeshEnableGravity(mainMeshID, false)
    end

    --创建之后要立马隐藏,防止穿帮
    self:DialogueHide(DialogueConst.PARTICIPANT_HIDE_SOURCE.DIALOGUE_LOGIC)

    -- 剧编角色默认为NoDrive，无法使用默认出生贴地机制， 需要手动控制贴地
    if self:NeedBornStickGround() then
        if not self.CppEntity:KAPI_Character_SimpleSetActorStickGround() then
            Log.WarningFormat("[DialogueV2][DialoguePerformer]AfterEnterWorld, %s[%s] stick ground failed", self.ptpConfig.TrackName, self:uid())
        end
    end

    self:AkSetRtpcValue(Enum.EAudioConstNew.RTPC_NAME_ACTOR_ACTING, Enum.EAudioConstNew.RTPC_VALUE_ACTOR_ACTING)

    self:preloadAnimLib()

    if self.bCloseBodyControl then
        self.CppEntity:KAPI_Animation_SetIsEnableBodyControl(false)
    end
end

function DialoguePerformer:BeforeExitWorld()
    self:AkResetRtpcValue(Enum.EAudioConstNew.RTPC_NAME_ACTOR_ACTING)

    if self.animLoadID ~= 0 then
        self:CancelPreLoadAndCacheMontage(self.animLoadID)
        self.animLoadID = 0
    end
end


--region 外观相关


function DialoguePerformer:GetEntityConfigData()
    local appearanceID = self.ptpConfig.AppearanceID

    -- 玩家
    local ExactPlayerData = self:getPlayerBattleDataByAppearanceID(appearanceID)
    if ExactPlayerData then
        return ExactPlayerData
    end

    -- NPC
    local NpcData = Game.TableData.GetNpcInfoDataRow(appearanceID)
    if NpcData then
        return NpcData
    end

    -- Passerby
    local PasserbyData = Game.TableData.GetPasserbyNpcDataRow(appearanceID)
    if PasserbyData then
        return PasserbyData
    end

    return nil
end

function DialoguePerformer:GetConfigFacadeControlData()
    if not self.FacadeControlID then
        self:decideFacadeControlID()
    end

    return Game.TableData.GetFacadeControlDataRow(self.FacadeControlID)
end

function DialoguePerformer:GetConfigAnimAssetID()
    local facadeControlData = self:GetConfigFacadeControlData()
    if facadeControlData then
        local FacadeAnimAssetID = facadeControlData.AnimAssetID
        if FacadeAnimAssetID and FacadeAnimAssetID ~= "" then
            return FacadeAnimAssetID
        end
    end
    local modelData = Game.ActorAppearanceManager:GetModelLibData(self:GetConfigModelID())
    return modelData and modelData.AnimFlag or 0
end

function DialoguePerformer:GetConfigModelID()
    if self.ModelID ~= nil and self.ModelID ~= 0 then
        return self.ModelID
    end

    self.ModelID = self:GetConfigFacadeControlData() and self:GetConfigFacadeControlData().ModelID or 0
    return self.ModelID
end

function DialoguePerformer:GetConfigTemplateID()
    return self.TemplateID
end

function DialoguePerformer:CalculateViewRoleImportance()
    return WorldViewBudgetConst.FIRST_ROLE_IMPORTANCE
end



function DialoguePerformer:GetDefaultLocoControlTemplateID()
	return Enum.LocoControlDefaultTemplate.DialogueEntity
end

function DialoguePerformer:NeedBornStickGround()
    return self.ptpConfig.StickGround
end

function DialoguePerformer:decideFacadeControlID()
    local appearanceID = self.ptpConfig.AppearanceID

    --对于玩家来说，配置为12000020  前面7位表示职业，最后一位表示性别
    --对于玩家类型，旧的配置是1200002 新的配置是12000020，新的多最后一位代表性别

    local playerBattleData = self:getPlayerBattleDataByAppearanceID(appearanceID)
    self.TemplateID = appearanceID

    if playerBattleData then
        self.Sex = playerBattleData.Sex
        self.FacadeControlID = playerBattleData.FacadeControlID
    else
        local TaskNpcData = Game.TableData.GetNpcInfoDataTable()

        local NpcData = TaskNpcData[appearanceID]
        local PasserbyData = Game.TableData.GetPasserbyNpcDataRow(appearanceID)
		
        if NpcData then
            self.FacadeControlID = NpcData.FacadeControlID
			self.Sex = self:GetModelGender()
        elseif PasserbyData then
            self.FacadeControlID = PasserbyData.FacadeControlID
			self.Sex = self:GetModelGender()
        else
            Log.WarningFormat("[DialogueV2]Can not find AppearanceID %d Data for %s", appearanceID, self.TrackName)
            self.OwnerParticipant:CompleteReady()
            return
        end
    end
end

---@private
---@param appearanceID number
function DialoguePerformer:getPlayerBattleDataByAppearanceID(appearanceID)
    local playerBattleData = EquipUtils.GetPlayerBattleDataRow(appearanceID, 0)
    if playerBattleData then
        --如果旧的AppearanceID查找到了玩家数据，说明是旧的7位数配置，默认性别为0
        return playerBattleData
    else
        --尝试用8位数解析出ProfessionID和Sex
        local professionID = math.floor(appearanceID / 10)
        local gender = appearanceID % 10
        return EquipUtils.GetPlayerBattleDataRow(professionID, gender)
    end
end


--endregion 外观相关

--region 动画预加载
DialoguePerformer.__AnimSlotName__ = "LowerLoco"

-- 预加载动作资源,主要是Idle动作
---@private
function DialoguePerformer:preloadAnimLib()
    -- 没动作不处理
    if string.isEmpty(self.ptpConfig.IdleAnimLibAssetID.AssetID)then
        self:OnAnimLibLoaded()
        return
    end

    -- 只预加载初始动作
    local loadConfig = { [self.FacadeControlID] = { self.ptpConfig.IdleAnimLibAssetID.AssetID } }
    self.animLoadID = self:PreLoadAndCacheMontageForDialogue(loadConfig, self.__AnimSlotName__, 0, 0, self, "OnAnimLibLoaded")

    -- todo@shijingzhe: #163427 【Bug】【新队长资产】玩家和NPC都没显示出来
    -- 这里先临时处理, ViewControlAnimComponent:PreLoadAndCacheMontageByPath 逻辑有点疑问,迭代后再动这里
    if self.OwnerParticipant.bReady then
        return
    end

    -- 没有能加载的资源
    if self.animLoadID == 0 then
        self:OnAnimLibLoaded()
    end
end

function DialoguePerformer:OnAnimLibLoaded()
    local animAssetID = self.ptpConfig.IdleAnimLibAssetID.AssetID
    if not string.isEmpty(animAssetID) then
        -- todo:这里先不传Loop,观察下,理论上不需要传
        self:PlayAnimLibMontage(animAssetID, self.ptpConfig.IdleAnimLibAssetID.StateName, true, 0)
    end

    self.bIsReady = true
    self.OwnerParticipant:CompleteReady()
end


--endregion 动画预加载
