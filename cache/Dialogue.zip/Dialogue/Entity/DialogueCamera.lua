---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/7 14:27
---
local KML = import("KismetMathLibrary")
local CollisionConst = kg_require("Shared.Const.CollisionConst")

kg_require("Gameplay.NetEntities.LocalEntity.LocalEntityBase")
local ViewControlVisibleComponent = kg_require("Gameplay.NetEntities.Comps.ViewControl.ViewControlVisibleComponent").ViewControlVisibleComponent
local DialogueComponent = kg_require("Gameplay.DialogueV2.Entity.Component.DialogueComponent").DialogueComponent
local M3D = kg_require("Framework.Library.Math3D")

---@class DialogueCamera : LocalEntityBase
---@field OwnerParticipant DialogueParticipant
---@field ptpConfig UDialogueCamera
---@field Position FVector
---@field Rotation FRotator
---@field IsDialogueLocalEntity boolean
---@field bIsReady boolean
---@field isAvatar boolean @ 是否为玩家
---@field bEnableDof boolean
---@field TrackName  string
DialogueCamera = DefineLocalEntity("DialogueCamera", LocalEntityBase, {
    ViewControlVisibleComponent,
    DialogueComponent,
})

DialogueCamera:Register("DialogueCamera")

DialogueCamera.DEFAULT_PRIMITIVE_COLLISION_PRESETS = {
    CollisionConst.COLLISION_PRESET_NAMES.NO_COLLISION_COMPONENT_PRESET
}

function DialogueCamera:ctor()
    self.bIsReady = false
    self.bDialoguePerformer = false
end

function DialogueCamera:AfterEnterWorld()
    Log.DebugFormat("[DialogueV2][DialogueCamera]AfterEnterWorld %s uid:%s", self.ptpConfig.TrackName, self:uid())
    self.CppEntity:KAPI_Actor_AddActorTag(self.ptpConfig.TrackName)
    self:initializeCameraParams()
    self.OwnerParticipant:CompleteReady()
    self.bIsReady = true
end

function DialogueCamera:BeforeExitWorld()
end

function DialogueCamera:NeedBornStickGround()
    return false
end

---@private
function DialogueCamera:initializeCameraParams()
    if not self.CharacterID or self.CharacterID == KG_INVALID_ID then
        Log.ErrorFormat("[DialogueV2][initializeCameraParams] get camera component failed %s:%s", self.ptpConfig.TrackName, self:uid())
        return
    end

    local ptpConfig = self.ptpConfig
    local bOverride_dof = self.bEnableDof and ptpConfig.bOverride_DepthOfField or false
    local dofDistance = ptpConfig.DepthOfFieldFocalDistance
    if not string.isEmpty(ptpConfig.DepthOfFieldFocusActor) then
        dofDistance = self:GetFocusActorDistance() or dofDistance
    end

    Game.CameraManager:KAPI_Camera_DialogueCamera_SetCameraPostProcessSetting(
            self.CharacterID,
            bOverride_dof,
            dofDistance,
            bOverride_dof,
            ptpConfig.DepthOfFieldFStop,
            bOverride_dof,
            ptpConfig.DepthOfFieldSensorWidth,
            bOverride_dof,
            ptpConfig.DepthOfFieldFocalRegion,
            bOverride_dof,
            ptpConfig.DepthOfFieldNearTransitionRegion,
            bOverride_dof,
            ptpConfig.DepthOfFieldFarTransitionRegion,
            bOverride_dof,
            bOverride_dof,
            bOverride_dof,
            bOverride_dof,
            ptpConfig.FOV
    )
end

DialogueCamera.__HeadSocketName__ = "head"
DialogueCamera.__BipHeadSocketName__ = "Bip001-Head"

---获取相机到其关注目标(头部骨骼)的距离
---@public
---@param targetPtpName string
---@return number|nil 返回空代表没找到
function DialogueCamera:GetFocusActorDistance(targetEntity)
	if not targetEntity then
		Log.WarningFormat("[DialogueV2][GetFocusActorDistance] get targetEntity %s failed", targetEntity)
		return
	end
	
    local mainMeshCompID = targetEntity.CppEntity:KAPI_Actor_GetMainMesh()
    local _, _, targetZ = targetEntity:GetPosition_P()
    local headLocation = targetEntity.CppEntity:KAPI_SceneID_GetSocketLocation(mainMeshCompID, self.__HeadSocketName__)
    if headLocation.Z < targetZ then
        headLocation = targetEntity.CppEntity:KAPI_SceneID_GetSocketLocation(mainMeshCompID, self.__BipHeadSocketName__)
    end

    -- 总之不能比目标本身位置还低
    local finalLocation = (headLocation.Z < targetZ) and targetEntity:GetPosition() or headLocation
    return KML.Vector_Distance(self:GetPosition(), finalLocation)
end

function DialogueCamera:GetConfigTemplateID()
    return nil
end

function DialogueCamera:GetConfigModelID()
    return nil
end

---@return FTransform
function DialogueCamera:AdjustTransformForCameraConfig()
    ---@type UDialogueCamera
    local cameraConfig = self.ptpConfig
    if not cameraConfig then
        Log.WarningFormat("[DialogueV2][DialogueCamera]AdjustTransformForCameraConfig failed: cameraConfig not found,CameraName:%s", self.TrackName)
        return false
    end

    assert(self.OwnerParticipant, "Participant is nil")
    
    local ptpManager = self.OwnerParticipant.ptpManager
    local parentEntity = ptpManager:GetParticipantEntityByName(cameraConfig.Parent)

    local parent_x, parent_y, parent_z, parent_rx, parent_ry, parent_rz, parent_rw, parent_sx, parent_sy, parent_sz = parentEntity:GetTransform_P()
    local spawn_x, spawn_y, spawn_z, spawn_rx, spawn_ry, spawn_rz, spawn_rw, spawn_sx, spawn_sy, spawn_sz = DialogueUtilV2.UnpackDialogueTransform(cameraConfig.SpawnTransform)
    local x, y, z, pitch, yaw, roll, sx, sy, sz = M3D.MultiplyTransform_P_EulerAngle(
            spawn_x, spawn_y, spawn_z, parent_rx, parent_ry, parent_rz, parent_rw, spawn_sx, spawn_sy, spawn_sz,
            parent_x, parent_y, parent_z, spawn_rx, spawn_ry, spawn_rz, spawn_rw, parent_sx, parent_sy, parent_sz
    )

    if cameraConfig.bEnableLookAt then
        local targetEntity = ptpManager:GetParticipantEntityByName(cameraConfig.LookAtTarget)
        if targetEntity then
            local mainMeshID = targetEntity.CppEntity:KAPI_Actor_GetMainMesh()
            local boneIndex = targetEntity.CppEntity:KAPI_SkeletalMeshID_GetBoneIndex(mainMeshID, cameraConfig.BoneName)
            if boneIndex ~= -1 then
                local boneLoc = targetEntity.CppEntity:KAPI_SkeletalMeshID_GetBoneLocation(mainMeshID, cameraConfig.BoneName, 0)
                z = boneLoc.Z + cameraConfig.OffsetZ
                Log.DebugFormat("[DialogueV2][DialogueCamera]AdjustTransformForCameraConfig: bone:%s boneLoc:%s, OffsetZ:%s, newLoc:%s,%s.%s",
                    cameraConfig.BoneName, boneLoc, cameraConfig.OffsetZ, x, y, z)
            end
        end
    end

    self:SetTransform_P_EulerAngle(x, y, z, pitch, yaw, roll, sx, sy, sz)
    Log.InfoFormat("[DialogueV2][DialogueCamera] AdjustTransformForCameraConfig: cameraName:%s, X:%s,Y:%s,Z:%s,Pitch:%s,Yaw:%s,Roll:%s,ScaleX:%s,ScaleY:%s,ScaleZ%s",
        self.TrackName, x, y, z, pitch, yaw, roll, sx, sy, sz)
    return true
end
