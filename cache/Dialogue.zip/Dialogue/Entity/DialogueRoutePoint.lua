---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/7 14:27
---
local CollisionConst = kg_require("Shared.Const.CollisionConst")

kg_require("Gameplay.NetEntities.LocalEntity.LocalEntityBase")
local ViewControlVisibleComponent = kg_require("Gameplay.NetEntities.Comps.ViewControl.ViewControlVisibleComponent").ViewControlVisibleComponent
local DialogueComponent = kg_require("Gameplay.DialogueV2.Entity.Component.DialogueComponent").DialogueComponent

---@class DialogueRoutePoint : LocalEntityBase
---@field OwnerParticipant DialogueParticipant
---@field ptpConfig UDialogueActor
---@field Position FVector
---@field Rotation FRotator
---@field IsDialogueLocalEntity boolean
---@field bIsReady boolean
---@field isAvatar boolean @ 是否为玩家
---@field bEnableDof boolean
---@field TrackName  string
DialogueRoutePoint = DefineLocalEntity("DialogueRoutePoint", LocalEntityBase, {
    ViewControlVisibleComponent,
    DialogueComponent,
})

DialogueRoutePoint:Register("DialogueRoutePoint")

DialogueRoutePoint.DEFAULT_PRIMITIVE_COLLISION_PRESETS = {
    CollisionConst.COLLISION_PRESET_NAMES.NO_COLLISION_COMPONENT_PRESET
}

function DialogueRoutePoint:ctor()
    self.IsDialogueLocalEntity = true
    self.bIsReady = false
    self.bDialoguePerformer = false
end

function DialogueRoutePoint:AfterEnterWorld()
    Log.InfoFormat("[DialogueV2][DialogueRoutePoint]AfterEnterWorld %s uid:%s", self.ptpConfig.TrackName, self:uid())
    self.CppEntity:KAPI_Actor_AddActorTag(self.ptpConfig.TrackName)
    self.OwnerParticipant:CompleteReady()
    self.bIsReady = true
end

function DialogueRoutePoint:GetConfigTemplateID()
    return nil
end

function DialogueRoutePoint:GetConfigModelID()
    return nil
end
