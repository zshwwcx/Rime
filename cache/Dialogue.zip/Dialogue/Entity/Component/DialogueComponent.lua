---@class DialogueComponent : LuaClass
---@field private hiddenTags DialogueTaggedObject
DialogueComponent = DefineComponent("DialogueComponent")

local DialogueTaggedObject = kg_require("Gameplay.DialogueV2.Core.DialogueTaggedObject").DialogueTaggedObject

function DialogueComponent:ctor()
    self.hiddenTags = DialogueTaggedObject.new(string.format("HideTags_%s", self.TrackName),
        self, "doHidden", "doShown")
end

--function DialogueComponent:__component_AfterLoadActor__()
--
--end

function DialogueComponent:__component_AfterEnterWorld__()
    local scale = self.Scale3D
    if scale then
        -- entity创建出来的时候Actor上的scale只有模型库里面的缩放，对话资产里面可以对entity
        -- 施加一个额外的缩放，所以这里需要将对话资产里面的scale添加的模型库的缩放上
        local origScaleX, origScaleY, origScaleZ = self:GetScale_P()
        if scale[1] then
            origScaleX = origScaleX * scale[1]
        end

        if scale[2] then
            origScaleY = origScaleY * scale[2]
        end

        if scale[3] then
            origScaleZ = origScaleZ * scale[3]
        end

        self:SetScale_P(origScaleX, origScaleY, origScaleZ)
    end
end

--- 显示对话角色，show和hide需要成对调用且传入相同的tag
---@public
---@param tag string @ 标签，
---@param dissolveEffect any @ 溶解效果参数
function DialogueComponent:DialogueShow(tag, dissolveEffect)
    if string.isEmpty(tag) then
        return
    end

    Log.DebugFormat("[DialogueV2]Show entity: %s[uid:%s] reason: %s", self.TrackName, self:uid(), tag)
    self.hiddenTags:RemoveTag(tag, dissolveEffect)
end

--- 隐藏对话角色，show和hide需要成对调用且传入相同的tag
---@public
---@param tag string @ 标签，
---@param dissolveEffect any @ 溶解效果参数
function DialogueComponent:DialogueHide(tag, dissolveEffect)
    if string.isEmpty(tag) then
        return
    end

    Log.DebugFormat("[DialogueV2]Hide entity: %s[%s] reason: %s", self.TrackName, self:uid(), tag)
    self.hiddenTags:AddTag(tag, dissolveEffect)
end


---@private
function DialogueComponent:doHidden(dissolveEffect)
    if self.OnHidden then
        self:OnHidden(dissolveEffect)
    end
    
    self:ForceToInvisibleByDialogue(dissolveEffect)
end

---@private
function DialogueComponent:doShown(dissolveEffect)
    if self.OnShown then
        self:OnShown(dissolveEffect)
    end
    
    self:ForceToVisibleByDialogue(dissolveEffect)
end