---
--- Created by shijingzhe@kuaishou.com
--- DateTime: 2025/5/7 14:26
---
local CollisionConst = kg_require("Shared.Const.CollisionConst")
local SkeletalMeshComponent = import("SkeletalMeshComponent")
local StaticMeshComponent = import("StaticMeshComponent")

kg_require("Gameplay.NetEntities.LocalEntity.LocalEntityBase")
local ViewControlVisibleComponent = kg_require("Gameplay.NetEntities.Comps.ViewControl.ViewControlVisibleComponent").ViewControlVisibleComponent
local DialogueComponent = kg_require("Gameplay.DialogueV2.Entity.Component.DialogueComponent").DialogueComponent

---@class DialogueModel : LocalEntityBase
---@field OwnerParticipant DialogueParticipant
---@field ptpConfig UDialogueActor
DialogueModel = DefineLocalEntity("DialogueModel", LocalEntityBase, {
    ViewControlVisibleComponent,
    DialogueComponent,
})

DialogueModel:Register("DialogueModel")

DialogueModel.DEFAULT_PRIMITIVE_COLLISION_PRESETS = {
    CollisionConst.COLLISION_PRESET_NAMES.NO_COLLISION_COMPONENT_PRESET
}

function DialogueModel:ctor()
	self.actorBPClassPath = ""
	self.childBPEntity = nil
    self.Position = self.Position or { 0, 0, 0 }
    self.Rotation = self.Rotation or { 0, 0, 0 }
    self.Scale3D = self.Scale3D or {1, 1, 1}

    self.bIsReady = false
    self.bDialoguePerformer = false
end

function DialogueModel:AfterEnterWorld()
    Log.DebugFormat("[DialogueV2][DialogueModel]AfterEnterWorld %s uid:%s", self.ptpConfig.TrackName, self:uid())
    self.CppEntity:KAPI_Actor_AddActorTag(self.ptpConfig.TrackName)

    -- 优先级： StaticMesh > SkeletalMesh > BP_Actor
    local modelAssetPath
    if not string.isEmpty(self.ptpConfig.StaticMesh) then
        modelAssetPath = self.ptpConfig.StaticMesh
    elseif not string.isEmpty(self.ptpConfig.SkeletalMesh) then
        modelAssetPath = self.ptpConfig.SkeletalMesh
	elseif not string.isEmpty(self.ptpConfig.BPActor.AssetPath.PackageName ~= "None") then
		modelAssetPath = string.format("%s.%s_C" ,self.ptpConfig.BPActor.AssetPath.PackageName, self.ptpConfig.BPActor.AssetPath.AssetName)
		
		local spawnParams = {
			Position = self.Position,
			Rotation = self.Rotation,
			OwnerParticipant = self.OwnerParticipant,
			ptpConfig = self.ptpConfig,
			isAvatar = false
		}
		self.childBPEntity = Game.EntityManager:CreateLocalEntity("DialogueModelBP", spawnParams, modelAssetPath)

		-- 处理Scale3D
        local Scale3D = self.ptpConfig.SpawnTransform.Scale3D
        self.childBPEntity:SetScale_P(Scale3D.X, Scale3D.Y, Scale3D.Z)
        
        modelAssetPath = nil
    end

    --创建之后要立马隐藏,防止穿帮
    self:DialogueHide(DialogueConst.PARTICIPANT_HIDE_SOURCE.DIALOGUE_LOGIC)
    
    -- 没有外观6
    if string.isEmpty(modelAssetPath) then
        self.OwnerParticipant:CompleteReady()
        self.bIsReady = true
    else
        self:DoAsyncLoadAsset(modelAssetPath, "OnAsyncLoadAssetCallback")
    end
end

function DialogueModel:destroy()
	-- 如果有Child ModelBP，先销毁Child ModelBP
	if self.childBPEntity then
		self.childBPEntity:destroy()
	end
	-- 再销毁自己
	LocalEntityBase.destroy(self)
end

function DialogueModel:BeforeExitWorld()
end

function DialogueModel:OnAsyncLoadAssetCallback(loadID, assetID)
    if assetID ~= 0 then
        self.meshAssetID = assetID

        if not string.isEmpty(self.ptpConfig.StaticMesh) then
            local meshCompID = self.CppEntity:KAPI_Actor_GetComponentByClass(StaticMeshComponent)
            if meshCompID ~= 0 then
                self.CppEntity:KAPI_StaticMeshID_SetStaticMesh(meshCompID, self.meshAssetID)
            end
        elseif not string.isEmpty(self.ptpConfig.SkeletalMesh) then
            local meshCompID = self.CppEntity:KAPI_Actor_GetComponentByClass(SkeletalMeshComponent)
            if meshCompID ~= 0 then
                self.CppEntity:KAPI_SkeletalMeshID_SetSkeletalMesh(meshCompID, self.meshAssetID, true)
            end
        end
    end

    self.OwnerParticipant:CompleteReady()
    self.bIsReady = true
end

function DialogueModel:GetConfigTemplateID()
    return nil
end

function DialogueModel:GetConfigModelID()
    return nil
end

function DialogueModel:OnHidden(dissolveEffect)
    if  self.childBPEntity then
        self.childBPEntity:ForceToInvisibleByDialogue(dissolveEffect)
    end
end

function DialogueModel:OnShown(dissolveEffect)
    if  self.childBPEntity then
        self.childBPEntity:ForceToVisibleByDialogue(dissolveEffect)
    end
end

