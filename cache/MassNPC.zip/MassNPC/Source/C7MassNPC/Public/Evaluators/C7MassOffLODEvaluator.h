// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "MassLODTypes.h"
#include "MassStateTreeTypes.h"
#include "MassSimulationLOD.h"
#include "C7MassOffLODEvaluator.generated.h"

USTRUCT()
struct C7MASSNPC_API FC7MassOffLODEvaluatorInstanceData
{
	GENERATED_BODY()

	UPROPERTY(VisibleAnywhere, Category = Output)
	TEnumAsByte<EMassLOD::Type> LOD = EMassLOD::Off;
};

USTRUCT(meta = (DisplayName = "C7 Mass OffLOD Eval"))
struct C7MASSNPC_API FC7MassOffLODEvaluator : public FMassStateTreeEvaluatorBase
{
	GENERATED_BODY()

	using FInstanceDataType = FC7MassOffLODEvaluatorInstanceData;
	
protected:
	virtual bool Link(FStateTreeLinker& Linker) override;
	virtual const UStruct* GetInstanceDataType() const override { return FInstanceDataType::StaticStruct(); }
	virtual void Tick(FStateTreeExecutionContext& Context, const float DeltaTime) const override;

	TStateTreeExternalDataHandle<FMassSimulationLODFragment> SimulationLODFragmentHandle;
};
