// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com
#pragma once

#include "CoreMinimal.h"
#include "MassAgentTraits.h"
#include "C7MassAgentCapsuleCollisionSyncTrait.generated.h"

/**
 * 支持使用Box作为半径
 */
UCLASS()
class C7MASSNPC_API UC7MassAgentCapsuleCollisionSyncTrait : public UMassAgentCapsuleCollisionSyncTrait
{
	GENERATED_BODY()
	
	UPROPERTY(EditAnywhere, Category = Mass)
	float ConstRadius = 0;

protected:
	virtual void BuildTemplate(FMassEntityTemplateBuildContext& BuildContext, const UWorld& World) const override;
};
