// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "MassStateTreeTrait.h"
#include "C7MassStateTreeTrait.generated.h"

/**
 *  Feature that adds StateTree execution functionality to a mass agent.
 */
UCLASS(meta = (DisplayName = "C7StateTree"))
class UC7MassStateTreeTrait : public UMassStateTreeTrait
{
	GENERATED_BODY()

protected:
	virtual void BuildTemplate(FMassEntityTemplateBuildContext& BuildContext, const UWorld& World) const override;

	UPROPERTY(Category = "StateTree", EditAnywhere, meta = (RequiredAssetDataTags = "Schema=/Script/MassAIBehavior.MassStateTreeSchema"))
	TObjectPtr<UStateTree> LowStateTree;
};
