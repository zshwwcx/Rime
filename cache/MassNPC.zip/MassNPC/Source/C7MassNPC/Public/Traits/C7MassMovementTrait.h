// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Movement/MassMovementTrait.h"
#include "C7MassMovementTrait.generated.h"

UCLASS(meta = (DisplayName = "C7Movement"))
class C7MASSNPC_API UC7MassMovementTrait : public UMassMovementTrait
{
	GENERATED_BODY()

protected:
	virtual void BuildTemplate(FMassEntityTemplateBuildContext& BuildContext, const UWorld& World) const override;

	UPROPERTY(Category = "MassNPC", EditAnywhere)
	FString Rank;

	UPROPERTY(Category = "MassNPC", EditAnywhere)
	FString BodyType;
};
