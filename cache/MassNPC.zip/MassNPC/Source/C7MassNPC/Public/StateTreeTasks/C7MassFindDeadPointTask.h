// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: luyilong@kuaishou.com

#pragma once

#include "MassStateTreeTypes.h"
#include "MassStateTreeExecutionContext.h"
#include "Tasks/MassZoneGraphPathFollowTask.h"
#include "MassZoneGraphNavigationFragments.h"
#include "ZoneGraphSubsystem.h"
#include "Subsystems/CrowdNpcControlSubsystem.h"
#include "C7MassFindDeadPointTask.generated.h"


/**
 * Updates TargetLocation to a wander target based on the agents current location on ZoneGraph.
 */
USTRUCT()
struct C7MASSNPC_API FMassZoneGraphFindDeadPointInstanceData
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, Category = Output)
	FMassZoneGraphTargetLocation DeadPointLocation;

	UPROPERTY(EditAnywhere, Category = Parameter)
	float NearbyRadius = 20000.0f;
};


USTRUCT(meta = (DisplayName = "C7Mass ZG Find Dead Point"))
struct C7MASSNPC_API FC7MassFindDeadPointTask : public FMassStateTreeTaskBase
{
	GENERATED_BODY()

	using FInstanceDataType = FMassZoneGraphFindDeadPointInstanceData;
	
	FC7MassFindDeadPointTask();
	
protected:
	virtual bool Link(FStateTreeLinker& Linker) override;
	virtual const UStruct* GetInstanceDataType() const override { return FInstanceDataType::StaticStruct(); }
	virtual EStateTreeRunStatus EnterState(FStateTreeExecutionContext& Context, const FStateTreeTransitionResult& Transition) const override;
	bool IsPointInDeadPoint(const FVector& Point, TSet<FMassOverlapPointInfo>& DeadPoints) const;

	TStateTreeExternalDataHandle<FMassZoneGraphLaneLocationFragment> LocationHandle;
	TStateTreeExternalDataHandle<UZoneGraphSubsystem> ZoneGraphSubsystemHandle;
	TStateTreeExternalDataHandle<UCrowdNpcControlSubsystem> CrowdNpcControlSubsystemHandle;

	UPROPERTY(EditAnywhere, Category = Parameter)
	FZoneGraphTagFilter AllowedAnnotationTags;
};
