// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: pengqi05@kuaishou.com

#pragma once

#include "Tasks/MassUseSmartObjectTask.h"
#include "MassActorSubsystem.h"
#include "C7MassUseSmartObjectTask.generated.h"

struct FMassActorFragment;

/**
 * 插入一下Use smart object task自定义的逻辑
 */
USTRUCT(meta = (DisplayName = "C7Mass Use SmartObject"))
struct C7MASSNPC_API FC7MassUseSmartObjectTask : public FMassUseSmartObjectTask
{
	GENERATED_BODY()

protected:
	virtual bool Link(FStateTreeLinker& Linker) override;
	virtual EStateTreeRunStatus EnterState(FStateTreeExecutionContext& Context, const FStateTreeTransitionResult& Transition) const override;

	TStateTreeExternalDataHandle<FMassActorFragment> ActorHandle;
};
