// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: pengqi05@kuaishou.com

#pragma once

#include "MassStateTreeTypes.h"
#include "MassStateTreeExecutionContext.h"
#include "Tasks/MassClaimSmartObjectTask.h"
#include "MassActorSubsystem.h"
#include "C7MassClaimSmartObjectTask.generated.h"


USTRUCT(meta = (DisplayName = "C7Mass Claim SmartObject"))
struct C7MASSNPC_API FC7MassClaimSmartObjectTask : public FMassClaimSmartObjectTask
{
	GENERATED_BODY()

protected:
	virtual bool Link(FStateTreeLinker& Linker) override;

	// 之所以重载这个函数，是因为需要在Claim时声明Slot释放相关的回调，使MassEntity在Slot释放时及时响应
	virtual EStateTreeRunStatus EnterState(FStateTreeExecutionContext& Context, const FStateTreeTransitionResult& Transition) const override;

	TStateTreeExternalDataHandle<FMassActorFragment> ActorHandle;
};
