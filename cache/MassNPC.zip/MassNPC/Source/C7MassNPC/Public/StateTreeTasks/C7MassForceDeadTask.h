// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: luyilong@kuaishou.com

#pragma once

#include "MassStateTreeTypes.h"
#include "MassStateTreeExecutionContext.h"
#include "Subsystems/CrowdNpcControlSubsystem.h"
#include "StateTreeLinker.h"
#include "C7MassForceDeadTask.generated.h"


USTRUCT()
struct C7MASSNPC_API FC7MassForceDeadTaskInstanceData
{
	GENERATED_BODY()
};


USTRUCT(meta = (DisplayName = "C7Mass ZG Force Dead"))
struct C7MASSNPC_API FC7MassForceDeadTask : public FMassStateTreeTaskBase
{
	GENERATED_BODY()

	using FInstanceDataType = FC7MassForceDeadTaskInstanceData;
	
	FC7MassForceDeadTask();
	
protected:
	virtual bool Link(FStateTreeLinker& Linker) override;
	virtual const UStruct* GetInstanceDataType() const override { return FInstanceDataType::StaticStruct(); }
	virtual EStateTreeRunStatus EnterState(FStateTreeExecutionContext& Context, const FStateTreeTransitionResult& Transition) const override;

	TStateTreeExternalDataHandle<UCrowdNpcControlSubsystem> CrowdNpcControlSubsystemHandle;
};
