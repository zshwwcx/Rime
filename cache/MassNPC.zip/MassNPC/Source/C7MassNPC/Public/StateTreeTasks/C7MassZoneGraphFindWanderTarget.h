// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Tasks/MassZoneGraphFindWanderTarget.h"
#include "Fragments/C7MassWanderTagsFragment.h"
#include "C7MassZoneGraphFindWanderTarget.generated.h"

struct FStateTreeLinker;
struct FStateTreeExecutionContext;
struct FStateTreeTransitionResult;


USTRUCT(meta = (DisplayName = "C7Mass ZG Find Wander Target"))
struct C7MASSNPC_API FC7MassZoneGraphFindWanderTarget : public FMassZoneGraphFindWanderTarget
{
	GENERATED_BODY()

protected:
	virtual bool Link(FStateTreeLinker& Linker) override;
	virtual EStateTreeRunStatus EnterState(FStateTreeExecutionContext& Context, const FStateTreeTransitionResult& Transition) const override;
	TStateTreeExternalDataHandle<FC7MassWanderTagsFragment> C7MassWanderTagsFragmentHandle;
	
};
