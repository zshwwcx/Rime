// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "MassEntityQuery.h"
#include "ZoneGraphTypes.h"
#include "C7MassWanderTagsFragment.generated.h"

USTRUCT()
struct C7MASSNPC_API FC7MassWanderTagsFragment : public FMassFragment
{
	GENERATED_BODY()
	
	UPROPERTY(EditAnywhere)
	FZoneGraphTagFilter AllowWanderAnnotationTags;
};

// Delete by liuruilin@kuaishou.com 这里是按照Rank去区分, 跟策划确认过后, 改成按照更具体的NPC类型去区分可行走区域. 具体实现见 UC7MassNpcInitializeProcessor
// class C7MASSNPC_API UC7MassWanderTagsFragmentInitializer : public UMassObserverProcessor