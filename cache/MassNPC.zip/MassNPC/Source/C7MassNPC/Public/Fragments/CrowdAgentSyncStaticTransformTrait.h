// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "MassAgentTraits.h"
#include "CrowdAgentSyncStaticTransformTrait.generated.h"

/** The trait initializes the entity with actor transform.*/
UCLASS(BlueprintType, EditInlineNew, CollapseCategories, meta = (DisplayName = "Agent Static Transform Sync"))
class C7MASSNPC_API UCrowdAgentSyncStaticTransformTrait : public UMassAgentSyncTrait
{
	GENERATED_BODY()
protected:
	virtual void BuildTemplate(FMassEntityTemplateBuildContext& BuildContext, const UWorld& World) const override;

	UPROPERTY(EditAnywhere, Category = Mass)
	float Radius=40.0;
};

