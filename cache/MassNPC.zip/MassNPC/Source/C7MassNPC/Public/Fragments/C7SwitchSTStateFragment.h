// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: luyilong@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "MassEntityTypes.h"
#include "C7SwitchSTStateFragment.generated.h"


UENUM(BlueprintType, Blueprintable)
enum class ETargetStateType : uint8
{
	None = 0 UMETA(DisplayName = "None"),
	ENTER_REACTING = 1 UMETA(DisplayName = "EnterReacting"),
	LEAVE_REACTING = 2 UMETA(DisplayName = "LeaveReacting"),
	STOP_SO_TASKS = 3 UMETA(DisplayName = "StopSOTasks"),
	GO_TO_DEAD_POINT = 4 UMETA(DisplayName = "GoToDeadPoint"),
	STOP_STATE_TREE_TASKS = 5 UMETA(DisplayName = "StopStateTreeTasks"),

	ETST_Max UMETA(DisplayName = "Undefine")
};


USTRUCT()
struct C7MASSNPC_API FC7SwitchSTStateFragment : public FMassFragment
{
	GENERATED_BODY()

	// do not CHANGE, contact Programmers@lizhang@luyilong
	UPROPERTY(EditAnywhere)
	ETargetStateType TargetState = ETargetStateType::None;

	// todo 后续按需扩展state以及对应的数据
};

