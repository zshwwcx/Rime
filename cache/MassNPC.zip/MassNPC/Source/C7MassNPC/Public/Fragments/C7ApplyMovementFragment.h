// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: luyilong@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "MassEntityTypes.h"
#include "C7ApplyMovementFragment.generated.h"


USTRUCT()
struct C7MASSNPC_API FC7ApplyMovementFragment : public FMassFragment
{
	GENERATED_BODY()

	// do not CHANGE, contact Programmers@lizhang@luyilong
	UPROPERTY(EditAnywhere)
	bool bAvailable = false;

	// Velocity.X
	UPROPERTY(EditAnywhere)
	float VelocityX = 0.0f;

	// Velocity.Y
	UPROPERTY(EditAnywhere)
	float VelocityY = 0.0f;

	// Velocity.Z
	UPROPERTY(EditAnywhere)
	float VelocityZ = 0.0f;
};

