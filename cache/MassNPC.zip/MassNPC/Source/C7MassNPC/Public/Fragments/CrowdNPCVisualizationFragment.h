// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "MassEntityTypes.h"
#include "MassObserverProcessor.h"
#include "AnimToTextureDataAsset.h"
#include "CrowdNPCVisualizationFragment.generated.h"


struct FMassEntityQuery;
class ACrowdNPCCharacter;


USTRUCT()
struct C7MASSNPC_API FCrowdNPCVisualizationFragment : public FMassFragment
{
	GENERATED_BODY()

	// SuitLib的ID
	UPROPERTY(EditAnywhere)
	FString SuitLibKey;

	// 上衣颜色
	UPROPERTY(EditAnywhere)
	FColor SuitLibBodyColor;

	// 下衣颜色
	UPROPERTY(EditAnywhere)
	FColor SuitLibLowerColor;
};

UCLASS()
class C7MASSNPC_API UCrowdNPCVisualizationFragmentInitializer : public UMassObserverProcessor
{
	GENERATED_BODY()
	
public:
	UCrowdNPCVisualizationFragmentInitializer();	

protected:
	virtual void ConfigureQueries() override;
	virtual void Execute(FMassEntityManager& EntityManager, FMassExecutionContext& Context) override;

protected:
	FMassEntityQuery EntityQuery;
	
	UAnimToTextureDataAsset* GetAnimToTextureDataAsset(TSoftObjectPtr<UAnimToTextureDataAsset> SoftPtr);
};