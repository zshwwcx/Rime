﻿// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: zhulingwei03@kuaishou.com

#pragma once

#include "MassEntityZoneGraphSpawnPointsGenerator.h"
#include "CoreMinimal.h"
#include "Subsystems/CrowdNpcControlSubsystem.h"
#include "ZoneGraphTypes.h"

#include "CrowdMassEntityZoneGraphSpawnPointsGenerator.generated.h"

class AZoneGraphData;

UCLASS(BlueprintType, meta=(DisplayName="Crowd ZoneGraph SpawnPoints Generator"))
class C7MASSNPC_API UCrowdMassEntityZoneGraphSpawnPointsGenerator : public UMassEntityZoneGraphSpawnPointsGenerator
{
	GENERATED_BODY()
public:
	 /** Populates empty generator results from EntityTypes based on the provided proportions. 
	 * @param SpawnCount How many entities to distributed among the EntityTypes
	 * @param EntityTypes Types of entities to generate data for.
	 * @param OutResults Generator result for each entity type that had > 0 entities assigned to it.
	 */
	virtual void BuildResultsFromEntityTypes(const int32 SpawnCount, TConstArrayView<FMassSpawnedEntityType> EntityTypes, TArray<FMassEntitySpawnDataGeneratorResult>& OutResults) const override;
	virtual void Generate(UObject& QueryOwner, TConstArrayView<FMassSpawnedEntityType> EntityTypes, int32 Count, FFinishedGeneratingSpawnDataSignature& FinishedGeneratingSpawnPointsDelegate) const override;
	void SetRadius(float radius);

	void SetGap(float InMinGap, float InMaxGap);

	void SetTagFilter(FZoneGraphTagFilter&& InTagFilter);
	
	void SetAreaTypes(int32 InAreaTag, const TArray<FName>& InAreaConfigTypes);
	void SetOverrideLODSettings(TSharedPtr<FOverrideTraitLODSettings> InOverrideTraitLODSettings);

protected:
	virtual void GeneratePointsForZoneGraphData(const ::AZoneGraphData& ZoneGraphData, TArray<FVector>& Locations, const FRandomStream& RandomStream) const override;

	bool IsPointOutCircle(const FVector& Point, const FVector& Center) const;

	bool IsPointInBornPoint(const FVector& Point, TSet<FMassOverlapPointInfo>& BornPoints) const;

	bool IsControlledByDesigner() const { return !AreaConfigTypes.IsEmpty(); }

	void ApplyOverrideTraitLODSettings(TConstArrayView<FMassSpawnedEntityType, int> EntityTypes) const;
private:
	float Radius = 0.0f;
	int32 AreaTag = 0;
	TArray<FName> AreaConfigTypes;
	TSharedPtr<FOverrideTraitLODSettings> OverrideTraitLODSettings;
	int32 OverrideTraitLODSettingsVersion = -1;
};
