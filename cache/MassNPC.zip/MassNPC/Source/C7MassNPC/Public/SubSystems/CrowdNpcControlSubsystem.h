// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "MassEntityTypes.h"
#include "Processors/C7MassNpcInitializeProcessor.h"
#include "Subsystems/WorldSubsystem.h"
#include "ZoneGraphTypes.h"
#include "CrowdNpcControlSubsystem.generated.h"

enum class EMassRepresentationType : uint8;
struct FCrowdAdjustTime;
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnNotifyEntityDeleted, const TArray<FMassEntityHandle>&, DeletedEntities);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnNotifyEntityActive, bool, bActivated);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnNotifyEntityScale, float, ClimateScaleRatio);

/**
 * A subsystem managing crowd globally, support functions like hiding entity,delete entities.
 * make sure entity is deleted when it's out of player's sight.
 * Entities are actually deleted in CrowdDeleteEntityProcessor
 */

UENUM(BlueprintType, Blueprintable)
enum class ECrowdOverlapPointType : uint8
{
	Hide,
	Born,
	Dead,
	React, // 指定地点反馈表现
};

USTRUCT(BlueprintType)
struct C7MASSNPC_API FMassNPCMovementData
{
	GENERATED_BODY()

	UPROPERTY()
	float MaxSpeed = 200.f;

	UPROPERTY()
	float WalkSpeed = 160.f;
};

USTRUCT(BlueprintType)
struct C7MASSNPC_API FMassReactTriggerData
{
	GENERATED_BODY()

	/** 填世界坐标即可.*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, DisplayName = "看向位置")
	FVector LookAtLocation;

	/** 填动作库的动作ID即可，如Walk, 在列表项里随机播放一个*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, DisplayName = "播放动画")
	TArray<FString> ReactAnimations;

	/** NPC头顶冒泡文字*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, DisplayName = "冒泡文字")
	FString BubbleText;
};


USTRUCT()
struct C7MASSNPC_API FCanDirectDeleteTag : public FMassTag
{
	GENERATED_BODY()
};

USTRUCT()
struct C7MASSNPC_API FLongTimeTaskTag : public FMassTag
{
	GENERATED_BODY()
};

USTRUCT()
struct C7MASSNPC_API FGoToDeadZoneTag : public FMassTag
{
	GENERATED_BODY()
};

USTRUCT()
struct C7MASSNPC_API FToBeDeleteTag : public FMassTag
{
	GENERATED_BODY()
};

/** 自定义的 Mass NPC 的 LOD 参数, 从Lua中来, 去覆盖掉资产中的 Trait 中的 LOD 参数. */
struct C7MASSNPC_API FOverrideTraitLODSettings
{
	/** 基础LOD距离, 超出距离就降LOD */
	TArray<float> BaseLODDistance;
	
	/** 每层LOD的数量, 上一层LOD塞不下来, 就掉到下一层 */
	TArray<int32> LODMaxCount;
	
	/** 可视的LOD距离, 超出就不可见, 和LOD没啥关系 */
	TArray<float> VisibleLODDistance;
	
	/** Tick的LOD距离, 每层的Tick频率不相同 */
	TArray<float> SimulationLODDistance;
	
	/** Tick的LOD数量, 同理 */
	TArray<int32> SimulationLODMaxCount;
	
	int32 Version = 0;
};

USTRUCT()
struct C7MASSNPC_API FMassOverlapPointInfo
{
	GENERATED_BODY()
	
	FMassOverlapPointInfo()
	:PointPos(FVector()), TriggerRadius(0.0f)
	{};
	
	FMassOverlapPointInfo(const FVector& InPointPos, const float InTriggerRadius, const FString& InInstanceID, ECrowdOverlapPointType InType)
		:PointPos(InPointPos), TriggerRadius(InTriggerRadius), InstanceID(InInstanceID), Type(InType)
	{};

	FORCEINLINE bool operator==(const FMassOverlapPointInfo& Other) const
	{
		return (Other.PointPos.Equals(PointPos)) && (FMath::Abs(Other.TriggerRadius - TriggerRadius) < UE_KINDA_SMALL_NUMBER);
	}

	friend inline uint32 GetTypeHash(const FMassOverlapPointInfo& Key)
	{
		return HashCombine(GetTypeHash(Key.PointPos), GetTypeHash(Key.PointPos));
	}

	UPROPERTY()
	FVector PointPos;

	UPROPERTY()
	float TriggerRadius;

	UPROPERTY()
	FString InstanceID;

	UPROPERTY()
	ECrowdOverlapPointType Type;
};

UCLASS()
class C7MASSNPC_API UCrowdNpcControlSubsystem : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	virtual void Deinitialize() override;
	
	/** Mark entities need to be deleted, entity will be deleted when "RepresentationType" is None
	*  @param MarkEntities Entities array */
	void MarkDeleteEntities(const TArray<FMassEntityHandle>& MarkEntities, bool bDeleteDirectly = false);

	/** Mark entity need to be deleted, entity will be deleted when "RepresentationType" is None
	*  @param MarkEntity Entity */
	void MarkDeleteEntity(const FMassEntityHandle MarkEntity, bool bDeleteDirectly = false);

	/** When entities deleted, make sure notify this subsystem to remove them from tobe deleted array
	*  @param DeletedEntities Entities array */
	void OnEntitiesDeleted(const TArray<FMassEntityHandle>& DeletedEntities);

	/** Hide all entities or not
	*  @param bHidden hide or not hide all */
	UFUNCTION(BlueprintCallable)
	void SetAllEntitiesHidden(bool bHidden=true);

	/** Get all entities hidden state
	*  @return bool hide or not */
	UFUNCTION(BlueprintCallable)
	bool IsAllEntitiesHidden();

	/** Activate all entities or not
	*  @param bActivated activate or disactivate all */
	UFUNCTION(BlueprintCallable)
	void SetAllEntitiesActivate(bool bActivated);

	/** Get all entities Activated state
	*  @return bool activated or not */
	UFUNCTION(BlueprintCallable)
	bool IsAllEntitiesActivated();

	/** When input the SuitLibKey, then delete all Npc then generate the specific Npc
	*  @param SuitLibKey specific npc name */
	UFUNCTION(BlueprintCallable)
	void ChangeSuitLibKey(FString SuitLibKey);

	/** Get all entities was marked tobe delete
	*  @return to be delete entities array */
	TSet<FMassEntityHandle>& GetToBeDeleteEntities(){return ToBeDeleteEntities;};
	
	/** Get all interest points
	*  @return interest points array */
	TSet<FMassOverlapPointInfo>& GetInterestPoints(ECrowdOverlapPointType PointType);

	/** Change climateScaleRatio from Lua
	*  @param InClimateScaleRatio change MassNpc Num */
	UFUNCTION(BlueprintCallable)
	void SetClimateScaleRatio(float InClimateScaleRatio);

	/** Register interest point, may notice Mass actor when enter/leave by C7OverlapDetectProcessor
	*  @param WorldLoc the Location of the Point
	*  @param TriggerRadius the Radius of the Point
	*  @param PointType the Type of the Point*/
	UFUNCTION(BlueprintCallable)
	void RegInterestPoint(ECrowdOverlapPointType PointType, const FVector& WorldLoc, const float TriggerRadius, const FString& InstanceID);

	UFUNCTION(BlueprintCallable)
	void UnRegInterestPoint(ECrowdOverlapPointType PointType, const FVector& WorldLoc);

	TSet<FMassOverlapPointInfo*> GetInterestTriggerPoints(const TArray<ECrowdOverlapPointType>& FilterTypes);

	UFUNCTION(BlueprintCallable)
	void ClearInterestPoints() { InterestPoint.Empty(); };

	UFUNCTION(BlueprintCallable)
	bool ClaimSmartObjectSlotByActor(int64 SmartObjectUserID, int64 SmartObjectOwnerID, int32 SlotIndex);

	UFUNCTION(BlueprintCallable)
	bool ReleaseSmartObjectSlotByActor(int64 SmartObjectUserID, int64 SmartObjectOwnerID, int32 SlotIndex);

	UFUNCTION()
	void RegCrowdNPCWanderTag(const FString& NPCType, int32 WanderTag);

	UFUNCTION()
	void BeginSpawnEntities();

	// 获取对应lane的tags
	UFUNCTION()
	int64 GetZoneGraphLaneTagsByPos(const FVector& InPosition);

	UFUNCTION()
	void RegCrowdNPCMovementData(const FString& NPCType, const FMassNPCMovementData& MovementData);

	const FMassNPCMovementData* GetNPCMovementDataByType(const FString& NPCType);
	/** 设置时间段的数据 */
	UFUNCTION(BlueprintCallable)
	void SetSpawnAdjustTimeData(int32 ID, const TArray<int32>& TimeRanges, const TArray<float>& Scales);

	/** 初始化world内的Mass Spawner的数据 */
	UFUNCTION(BlueprintCallable)
	void InitializeSpawnerData(const TArray<int32>& IntData, const TArray<FString>& TagData, const int32 TagNumber,
		const int32 Radius, const int32 MinGap, const int32 MaxGap);
	
	UFUNCTION(BlueprintCallable)
	void SetOverrideTraitLODSettings(TArray<float> BaseLODDistance, TArray<int32> LODMaxCount, TArray<float> VisibleLODDistance, TArray<float> SimulationLODDistance, TArray<int32> SimulationLODMaxCount);

	UFUNCTION(BlueprintCallable)
	void SetDeleteEntityParameters(float InOverflowRatioLimit, float InCheckSpawnProportionInterval);
	
	UFUNCTION(BlueprintCallable)
	bool SetAvoidanceProcessEnable(const bool bEnable);

	/** 设置是否使用更低级的StateTree*/
	UFUNCTION()
	void SetUseLowStateTree(bool bOutUseLowStateTree) { bUseLowStateTree = bOutUseLowStateTree; }
	
	UFUNCTION()
	bool GetUseLowStateTree() { return bUseLowStateTree; }

	bool bUseLowStateTree = false;
	float ClimateScaleRatio = 1.0f;

	const TArray<int32>* GetWanderTagsByNPCType(const FString& NPCType) { return CrowdNPCWanderTags.Find(NPCType); }

	// 后续非常多Spawn的信息都要从脚本穿到这里，必然需要时机控制
	bool IsEnableToSpawnEntities();

	bool bEnableToSpawn = false;

	TMap<FName, FZoneGraphTagMask> NpcAllowedAreas;
	uint32 ValidAreaTags;
	TMap<int32, TMap<FName, int32>> CachedEntityCountMaps;
	TMap<FMassEntityHandle, FC7AreaConfigData> EntityAreas;
	void RecordAreaOnEntitiesCreated(TConstArrayView<FMassEntityHandle> Entities, const FC7AreaConfigData& InitData);
	void RecordAreaOnEntityLaneChanged(const FMassEntityHandle& Entity, int32 NewAreaTags);
	void RecordAreaOnEntitiesDestroyed(TConstArrayView<FMassEntityHandle> Entities);
	
	TSharedPtr<FOverrideTraitLODSettings> OverrideTraitLODSettings;
	
	float OverflowRatioLimit = 0.2f;
	float CheckSpawnProportionInterval = 30;

	// delegate
	FOnNotifyEntityDeleted OnNotifyEntityDeleted;
	FOnNotifyEntityActive OnNotifyEntityActive;
	FOnNotifyEntityScale OnNotifyEntityScale;

	// debug draw entity
	UFUNCTION()
	static bool IsEnabledDebugDrawOnBigMap();
	
	UFUNCTION()
	void SetBigMapStatus(bool bIsOpen);
	
	UFUNCTION()
	void SetDebugMapParams(FVector2D InStartViewportPos, FVector2D InEndViewportPos, FVector2D InStartWorldPos, FVector2D InEndWorldPos);

	UFUNCTION()
	FVector2D WorldPosToScreenPos(const FVector& WorldPos) const;

	FVector2D GetScreenPosition(FVector2D ViewportPosition) const;
	void ResetDebugEntityInfo();
	void AddDebugEntityInfo(EMassRepresentationType RepresentationType, const FVector& Location, bool IsToBeDeleted);
	void DebugDraw(UCanvas* Canvas, class APlayerController* PC);
	bool IsBigMapOpened() const{ return bBigMapOpen; }
	// end of debug draw entity
protected:
	// debug draw entity
	bool bBigMapOpen = false;
	FVector2D StartViewportPos;
	FVector2D EndViewportPos;
	FVector2D StartWorldPos;
	FVector2D EndWorldPos;
	FDelegateHandle	DrawHandle;
	TMap<int32,TArray<FVector2D>>	DebugDrawEntityMap;
	// end of debug draw entity
	
	TSet<FMassEntityHandle> ToBeDeleteEntities;
	TMap<ECrowdOverlapPointType, TSet<FMassOverlapPointInfo>> InterestPoint;
	TMap<FString, TArray<int32>> CrowdNPCWanderTags;
	TMap<int32, TArray<FCrowdAdjustTime>> AllSpawnAdjustTimeData;
	TMap<FString, FMassNPCMovementData> CrowdNpcMovementConfigs;
};
