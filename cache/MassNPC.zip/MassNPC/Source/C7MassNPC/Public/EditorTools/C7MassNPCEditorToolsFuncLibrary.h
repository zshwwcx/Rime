// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: pengqi05@kuaishou.com
#if WITH_EDITOR
#pragma once

#include "CoreMinimal.h"

namespace C7MassNPCEditorTools
{
	// ZoneShape编辑时贴地指令。
	void SetZoneShapesStickGround(IConsoleVariable* Var);
}
#endif