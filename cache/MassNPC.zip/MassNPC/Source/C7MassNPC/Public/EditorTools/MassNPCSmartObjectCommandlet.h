// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: pengqi05@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "Commandlets/Commandlet.h"
#include "MassNPCSmartObjectCommandlet.generated.h"

/**
 * 自动化构建以及smart object的收集
 */
UCLASS()
class C7MASSNPC_API UMassNPCSmartObjectCommandlet : public UCommandlet
{
	GENERATED_BODY()

#if WITH_EDITOR	
public:
	virtual int32 Main(const FString& Params)override;

	// params name start
	static const FString PARAM_TARGET_ASSET_PATH;
	// params name end

private:
	int32 RunCommandlet();
	bool SplitParams(TMap<FString, FString>& Map, const FString& Params);
	bool RebuildSmartObjectCollectionInLevel(UWorld* World);
	bool RebuildSOZoneAnotationsInLevel(UWorld* World);
	bool BuildWorldPartitionSOCollection(UWorld* World);
	bool BuildWorldPartitionSOZoneAnotation(UWorld* World, TArray<UPackage*>& SavePackages);

	TMap<FString, FString> ParamsMap;
#endif
};

