﻿// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: zhulingwei03@kuaishou.com

#pragma once

#include "LuaOverriderInterface.h"
#include "MassSpawner.h"
#include "CrowdMassSpawner.generated.h"


C7MASSNPC_API DECLARE_LOG_CATEGORY_EXTERN(LogC7Mass, Log, All);


USTRUCT(BlueprintType)
struct C7MASSNPC_API FCrowdAdjustTime
{
	GENERATED_BODY()

	FCrowdAdjustTime() {}
	FCrowdAdjustTime(int StartHour, int StartMin, int EndHour, int EndMin, float TheScale) : StartTimeHour(StartHour), StartTimeMinute(StartMin), EndTimeHour(EndHour), EndTimeMinute(EndMin), Scale(TheScale){}

	UPROPERTY(EditAnywhere, Config, Category = "Start Time Hour", Meta = (ClampMin = 0, ClampMax = 23, UIMin = 0, UIMax = 23))
	int StartTimeHour = 0;

	UPROPERTY(EditAnywhere, Config, Category = "Start Time Minute", Meta = (ClampMin = 0, ClampMax = 59, UIMin = 0, UIMax = 59))
	int StartTimeMinute = 0;

	UPROPERTY(EditAnywhere, Config, Category = "End Time Hour", Meta = (ClampMin = 0, ClampMax = 23, UIMin = 0, UIMax = 23))
	int EndTimeHour = 0;

	UPROPERTY(EditAnywhere, Config, Category = "End Time Minute", Meta = (ClampMin = 0, ClampMax = 59, UIMin = 0, UIMax = 59))
	int EndTimeMinute = 0;

	UPROPERTY(EditAnywhere, Config, Category = "Scale", Meta = (ClampMin = 0.1, ClampMax = 2.0, UIMin = 0.1, UIMax = 2.0))
	float Scale = 1.0f;
	
	int GetStartTotalMinutes() const
	{
		return StartTimeHour * 60 + StartTimeMinute;
	}
	
	int GetEndTotalMinutes() const
	{
		return EndTimeHour * 60 + EndTimeMinute;
	}
};

UCLASS(hidecategories = (Object, Actor, Input, Rendering, LOD, Cooking, Collision, HLOD, Partition))
class C7MASSNPC_API ACrowdMassSpawner : public AMassSpawner
{
	GENERATED_BODY()
public:
	
	ACrowdMassSpawner();

	// Called every frame
	virtual void Tick(float DeltaTime) override;

	virtual void OnConstruction(const FTransform& Transform) override;

	virtual void BeginPlay() override;

	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	
	void StartDoSpawning();

	// Add a certain number of NPCs
	void SpawnerAddCount(int AddCount);

	// Remove a certain number of NPCs
	void SpawnerReduceCount(int ReduceCount);

	/** 调整NPC的数量, 根据当前比例 */
	void CheckSpawnProportion(int32 TargetCount);
	
	// On Notify Certain Entities Deleted
	UFUNCTION()
	void OnNotifyEntityDeleted(const TArray<FMassEntityHandle>& TargetEntities);

	// On Notify Certain Entities Activate
	UFUNCTION()
	void OnNotifyEntityActiveChanged(const bool bActivate);
	
	// Set Climate Scale Ratio
	UFUNCTION()
	void OnNotifyClimateScaleRatio(const float InClimateScaleRatio);
	
	int32 GetCurrentCount();
	
	void SetAreaTypes(int32 InAreaTag, const TArray<FName>& InAreaConfigTypes);
	void SetDeleteEntityParameters(float InOverflowRatioLimit, float InCheckSpawnProportionInterval);

	/** 初始化时, 用来设置Count属性 */
	void InitializeSetCount(const int32 NewCount);
	void InitializeSetEntityTypes(TArray<FMassSpawnedEntityType>&& NewEntityTypes);
	void InitializeSetSpawnDataGenerators(TArray<FMassSpawnDataGenerator>&& NewSpawnDataGenerators);

	bool IsControlledByDesigner() const { return !AreaConfigTypes.IsEmpty(); }
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mass|Spawn")
	TArray<FCrowdAdjustTime> CrowdAdjustTimes;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mass|Spawn", meta = (ClampMin = "0"))
	float GenerateOutRadius = 5000;

protected:
	void DeferOnSpawnDataGenerationFinished(TConstArrayView<FMassEntitySpawnDataGeneratorResult> Results, FMassSpawnDataGenerator* FinishedGenerator);
	
private:
	void CheckTimeArrange();
	float ClimateScaleRatio = 1.0f;
	float GetFinalScaleRatio();

	float OverflowRatioLimit = 0.2f;
	float CheckSpawnProportionInterval = 30;
	float CheckSpawnProportionTick = 30;
	int32 AreaTag = 0;
    TArray<FName> AreaConfigTypes;
	int32 ConfigVersion = 0;
};
