// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: luyilong@kuaishou.com

#pragma once

#include "MassSmartObjectBehaviorDefinition.h"
#include "C7SmartObjectMassInteractionDefinition.generated.h"


UCLASS(EditInlineNew)
class C7MASSNPC_API UC7SmartObjectMassInteractionDefinition : public USmartObjectMassBehaviorDefinition
{
	GENERATED_BODY()

protected:
	virtual void Activate(FMassCommandBuffer& CommandBuffer, const FMassBehaviorEntityContext& EntityContext) const override;
	virtual void Deactivate(FMassCommandBuffer& CommandBuffer, const FMassBehaviorEntityContext& EntityContext) const override;

	// UPROPERTY(EditAnywhere, Category = Anim)
	// class UContextualAnimSceneAsset* ContextualAnimAsset;
};
