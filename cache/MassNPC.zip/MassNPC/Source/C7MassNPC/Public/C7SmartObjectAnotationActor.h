// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: pengqi05@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "C7SmartObjectAnotationActor.generated.h"

UCLASS()
class C7MASSNPC_API AC7SmartObjectAnotationActor : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AC7SmartObjectAnotationActor();

#if WITH_EDITOR
	// 现有一个Acotr的Compenent在PIE下会register两次，第二次时某个TArray的数据反序列化失败了的bug，只能先绕过了。
	virtual void RerunConstructionScripts() override {};
#endif

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

};
