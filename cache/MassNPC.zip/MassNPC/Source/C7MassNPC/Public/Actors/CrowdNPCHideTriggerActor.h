// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "CrowdNPCHideTriggerActor.generated.h"

UCLASS()
class C7MASSNPC_API ACrowdNPCHideTriggerActor : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	ACrowdNPCHideTriggerActor();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
#if WITH_EDITOR
	virtual bool ShouldTickIfViewportsOnly() const override { return true; }
#endif

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	/** MassNPC隐藏trigger的半径大小.*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "MassNPC")
	float TriggerRadius = 1000;

	FVector RegisterLocation = FVector::ZeroVector;
};
