// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: luyilong@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "MassProcessor.h"
#include "MassEntityTypes.h"
#include "C7StateTreeSendEventProcessor.generated.h"


/**
 * A processor managing to Switch StateTree to Reacting State
 */

UCLASS()
class C7MASSNPC_API UC7StateTreeSendEventProcessor : public UMassProcessor
{
	GENERATED_BODY()
public:
	UC7StateTreeSendEventProcessor();
protected:
	/** Configure the owned FMassEntityQuery instances to express processor's requirements */
	virtual void ConfigureQueries() override;
	virtual void Initialize(UObject& InOwner) override;
	virtual void Execute(FMassEntityManager& EntitySubSystem, FMassExecutionContext& Context) override;
	
protected:
	FMassEntityQuery EntityQuery;
};

