// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com
#pragma once

#include "CoreMinimal.h"
#include "MassSignalProcessorBase.h"
#include "C7AreaCrowdProportionProcessor.generated.h"

class UCrowdNpcControlSubsystem;

/**
 * 
 */
UCLASS()
class C7MASSNPC_API UC7AreaCrowdProportionProcessor : public UMassSignalProcessorBase
{
	GENERATED_BODY()

public:
	UC7AreaCrowdProportionProcessor();
	virtual void Initialize(UObject& Owner) override;

protected:
	virtual void ConfigureQueries() override;
	virtual void Execute(FMassEntityManager& EntityManager, FMassExecutionContext& Context) override;
	virtual void OnSignalReceived(FName SignalName, TConstArrayView<FMassEntityHandle> Entities) override;
	virtual bool ShouldAllowQueryBasedPruning(const bool bRuntimeMode = true) const override { return false; }
	
private:
	TArray<FMassEntityHandle> DirtyEntities;
	
	int32 ValidAreaTag = 0;
	TMap<int32, int32> TagToIndex;
	TMap<FMassEntityHandle, TTuple<int32, int32>> EntityAreas;
	FMassEntityQuery EntityQuery;
};
