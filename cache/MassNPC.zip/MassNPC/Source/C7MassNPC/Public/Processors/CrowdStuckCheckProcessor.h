// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "MassProcessor.h"
#include "Subsystems/CrowdNpcControlSubsystem.h"
#include "CrowdStuckCheckProcessor.generated.h"

 /**
  * A processor check and remove stuck entities
  */
 UCLASS()
 class C7MASSNPC_API UCrowdStuckCheckProcessor : public UMassProcessor
 {
 	GENERATED_BODY()
 public:
 	UCrowdStuckCheckProcessor();
 protected:
 	/** Configure the owned FMassEntityQuery instances to express processor's requirements */
 	virtual void ConfigureQueries() override;
 	virtual void Initialize(UObject& InOwner) override;
 	virtual void Execute(FMassEntityManager& EntitySubSystem, FMassExecutionContext& Context) override;
 	
 protected:
 	FMassEntityQuery EntityQuery;
 	TWeakObjectPtr<UCrowdNpcControlSubsystem> CrowdNpcControlSubsystem;
 };
