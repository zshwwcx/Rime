// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: luyilong@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "MassProcessor.h"
#include "Subsystems/CrowdNpcControlSubsystem.h"
#include "C7OverlapDetectProcessor.generated.h"


/**
 * A processor managing Overlap Detect for Static Interest Point 
 */

UCLASS()
class C7MASSNPC_API UC7OverlapDetectProcessor : public UMassProcessor
{
	GENERATED_BODY()
public:
	UC7OverlapDetectProcessor();
protected:
	/** Configure the owned FMassEntityQuery instances to express processor's requirements */
	virtual void ConfigureQueries() override;
	virtual void Initialize(UObject& InOwner) override;
	virtual void Execute(FMassEntityManager& EntityManager, FMassExecutionContext& Context) override;
	
protected:
	FMassEntityQuery EntityQuery;
	TWeakObjectPtr<UCrowdNpcControlSubsystem> CrowdDeleteEntitySubsystem;
	TMap<FMassOverlapPointInfo, TArray<FMassEntityHandle>> InterestPointsEnter;
};
