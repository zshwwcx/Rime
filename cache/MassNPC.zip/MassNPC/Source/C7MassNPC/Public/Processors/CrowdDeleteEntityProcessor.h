// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "MassProcessor.h"
#include "CrowdDeleteEntityProcessor.generated.h"

class UCrowdNpcControlSubsystem;
/**
 * A processor managing delete entities,
 * delete out sight entities get from CrowdDeleteEntitySubsystem::GetToBeDeleteEntities()
 */
UCLASS()
class C7MASSNPC_API UCrowdDeleteEntityProcessor : public UMassProcessor
{
	GENERATED_BODY()
public:
	UCrowdDeleteEntityProcessor();
protected:
	/** Configure the owned FMassEntityQuery instances to express processor's requirements */
	virtual void ConfigureQueries() override;
	virtual void Initialize(UObject& InOwner) override;
	virtual void Execute(FMassEntityManager& EntitySubSystem, FMassExecutionContext& Context) override;
	
protected:
	FMassEntityQuery EntityQuery;
	TWeakObjectPtr<UCrowdNpcControlSubsystem> CrowdDeleteEntitySubsystem;
};
