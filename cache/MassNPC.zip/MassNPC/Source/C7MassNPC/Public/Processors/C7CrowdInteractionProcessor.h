// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: luyilong@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "MassProcessor.h"
#include "MassEntityTypes.h"
#include "C7CrowdInteractionProcessor.generated.h"


/**
 * A processor managing finish Use Smart Object Task, via TimedBehaviorFragment.UseTime = 0
 */

USTRUCT()
struct C7MASSNPC_API FDeActiveC7SmartObjectMassInteractionTag : public FMassTag
{
	GENERATED_BODY()
};

UCLASS()
class C7MASSNPC_API UC7CrowdInteractionProcessor : public UMassProcessor
{
	GENERATED_BODY()
public:
	UC7CrowdInteractionProcessor();
protected:
	/** Configure the owned FMassEntityQuery instances to express processor's requirements */
	virtual void ConfigureQueries() override;
	virtual void Initialize(UObject& InOwner) override;
	virtual void Execute(FMassEntityManager& EntitySubSystem, FMassExecutionContext& Context) override;
	
protected:
	FMassEntityQuery EntityQuery;
};

