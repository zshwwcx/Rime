// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: luyilong@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "MassProcessor.h"
#include "MassEntityTypes.h"
#include "C7ApplyMovementProcessor.generated.h"


/**
 * A processor managing Apply Movement AFTER Mass Movement and BEFORE Sync to Actor
 */

namespace UE::Mass::ProcessorGroupNames
{
	const FName PostMovement = FName(TEXT("PostMovement"));
}


UCLASS()
class C7MASSNPC_API UC7ApplyMovementProcessor : public UMassProcessor
{
	GENERATED_BODY()
public:
	UC7ApplyMovementProcessor();
protected:
	/** Configure the owned FMassEntityQuery instances to express processor's requirements */
	virtual void ConfigureQueries() override;
	virtual void Initialize(UObject& InOwner) override;
	virtual void Execute(FMassEntityManager& EntitySubSystem, FMassExecutionContext& Context) override;
	
protected:
	FMassEntityQuery EntityQuery;
};

