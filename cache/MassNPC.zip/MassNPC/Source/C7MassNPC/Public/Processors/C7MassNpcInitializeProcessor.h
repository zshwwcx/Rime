// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "MassSpawnLocationProcessor.h"
#include "C7MassNpcInitializeProcessor.generated.h"

USTRUCT()
struct FC7AreaConfigData
{
	GENERATED_BODY()

	/** 这个NPC属于哪个区域 */
	UPROPERTY()
	int32 AreaTag;
	
	/** NPC的类型标签 */
	UPROPERTY()
	FName AreaConfigType;
	
	/** 哪些区域可以有这个类型的NPC, 可以不参与hash */
	UPROPERTY()
	int32 AllowedAreaTags;
	
	friend uint32 GetTypeHash(const FC7AreaConfigData& Fragment)
	{
		return HashCombine(GetTypeHash(Fragment.AreaTag), GetTypeHash(Fragment.AreaConfigType));
	}
};

USTRUCT()
struct FC7MassNpcSpawnData
{
	GENERATED_BODY()

	/** 初始的每个NPC的坐标 */
	TArray<FTransform> Transforms;
	
	/** 这一批次的NPC的区域相关配置 */
	FC7AreaConfigData InitAreaConfigTypeFragment;
	
	bool bRandomize;
};

/**
 * 用于初始化Entity
 */
UCLASS()
class C7MASSNPC_API UC7MassNpcInitializeProcessor : public UMassSpawnLocationProcessor
{
	GENERATED_BODY()

	UC7MassNpcInitializeProcessor();
protected:
	virtual void ConfigureQueries() override;
	virtual void Execute(FMassEntityManager& EntityManager, FMassExecutionContext& Context) override;
	
	FMassEntityQuery EntityQuery;
	FRandomStream RandomStream;
};
