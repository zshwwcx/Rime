// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "AnimToTextureDataAsset.h"
#include "3C/Character/BaseCharacter.h"
#include "IMassCrowdActor.h"
#include "VisualizationTemplate.h"
#include "MassRepresentationTypes.h"
#include "Fragments/C7SwitchSTStateFragment.h"
#include "SubSystems/CrowdNpcControlSubsystem.h"
#include "CrowdNPCCharacter.generated.h"

enum class ETargetStateType : uint8;

UCLASS()
class C7MASSNPC_API ACrowdNPCCharacter : public ABaseCharacter, public IMassCrowdActorInterface
{
	GENERATED_BODY()	
public:
	// Sets default values for this character's properties
	ACrowdNPCCharacter();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

public:
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

	virtual void OnGetOrSpawn(FMassEntityManager* EntityManager, const FMassEntityHandle MassAgent) override;
	
	virtual void SetAdditionalMeshOffset(const float Offset) override;

	virtual void OnActorEnabledTypeChange(const EMassActorEnabledType EnabledType) override;

	// Todo, Temp AnimToTexture Data 
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "CrowdNPC")
	UAnimToTextureDataAsset* AnimToTextureData;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "CrowdNPC")
	float ScaleMin = 0.98;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "CrowdNPC")
	float ScaleMax = 1.02;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "CrowdNPC")
	FString BodyType = "Man";

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "CrowdNPC")
	FString Rank = "Normal";

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "CrowdNPC")
	UMassSuitLibDataAsset* SuitLibDataAsset;

public:
	// SuitLib的ID
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "CrowdNPC")
	FString SuitLibKey;
	
	void OnActorEnterISM(bool bEnter);

	// 通知lua接口实现
	void OnStartInteractWithSceneActor(int64 InsID, int64 SlotNum, float InteractTime) const;
	void OnFinishInteractWithSceneActor(int64 InsID) const;
	void OnActorEnterTrigger(const FVector& TriggerPos, float TriggerRadius, const FString& InstanceID, ECrowdOverlapPointType Type) const;
	void OnActorLeaveTrigger(const FVector& TriggerPos, float TriggerRadius, const FString& InstanceID, ECrowdOverlapPointType Type) const;

	// lua调用接口实现
	virtual void FinishInteract() override;
	virtual void SetCrowdNpcVelocity(bool bSet, float VelocityX, float VelocityY, float VelocityZ) override;
	virtual void DoReactingToPlayer() override;
	virtual void FinishReactingToPlayer() override;
	virtual void SetActorHiddenInGame_L(bool bNewHidden) override;
	virtual void StopStateTreeTasks() override;
	virtual bool IsCrowdNpc() override { return true; }
	void DestroyMassImmediate() const;

	virtual void SetActorHiddenInGame(bool bNewHidden) override;
	bool GetIsInIsm() const { return bInISM; };
	void ChangeStateTreeStateTo(ETargetStateType TargetState);
	FMassEntityManager* GetMassEntityManager() const;

private:
	// init in ISM or None, no CrowdNPC
	// init in HighRes or LowRes, bInISM = false in default
	bool bInISM = false;
	
	bool HiddenFromScript = false;
	bool HiddenFromMass = false;
};
