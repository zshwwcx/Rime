// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#include "Evaluators/C7MassOffLODEvaluator.h"

#include "MassLODTypes.h"
#include "MassSimulationLOD.h"
#include "StateTreeExecutionContext.h"
#include "StateTreeLinker.h"

bool FC7MassOffLODEvaluator::Link(FStateTreeLinker& Linker)
{
	Linker.LinkExternalData(SimulationLODFragmentHandle);
	return true;
}

void FC7MassOffLODEvaluator::Tick(FStateTreeExecutionContext &Context, const float DeltaTime) const
{
	FMassSimulationLODFragment SimLODFragment = Context.GetExternalData(SimulationLODFragmentHandle);
	FInstanceDataType& InstanceData = Context.GetInstanceData(*this);
	InstanceData.LOD = SimLODFragment.LOD;
}

