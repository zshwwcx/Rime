// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: pengqi05@kuaishou.com


#include "C7SmartObjectAnotationActor.h"

// Sets default values
AC7SmartObjectAnotationActor::AC7SmartObjectAnotationActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void AC7SmartObjectAnotationActor::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AC7SmartObjectAnotationActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

