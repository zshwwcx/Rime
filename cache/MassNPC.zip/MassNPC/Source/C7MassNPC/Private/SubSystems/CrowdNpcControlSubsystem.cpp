// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#include "Subsystems/CrowdNpcControlSubsystem.h"

#include "CrowdMassSpawner.h"
#include "SmartObjectSubsystem.h"
#include "Kismet/GameplayStatics.h"
#include "3C/Util/KGUtils.h"
#include "ZoneGraphSubsystem.h"
#include "EngineUtils.h"
#include "MassEntitySettings.h"
#include "MassRepresentationTypes.h"
#include "MassSimulationSubsystem.h"
#include "Avoidance/MassAvoidanceProcessors.h"
#include "Debug/DebugDrawService.h"
#include "Engine/Canvas.h"
#include "Generators/CrowdMassEntityZoneGraphSpawnPointsGenerator.h"
#include "Slate/SGameLayerManager.h"

namespace UE::MassCrowd
{
	extern MASSCROWD_API int32 GCrowdTurnOffVisualization;
	
	int32 GCrowdActivateAllEntities = 1;
	FAutoConsoleVariableRef CVarCrowdActivateAllEntities(TEXT("Mass.CrowdActivateAllEntities"), GCrowdActivateAllEntities, TEXT("Activate all crowd entities"));

	FString GCrowdSpecificNpcName = "";
	FAutoConsoleVariableRef CVarCrowdSpecificNpcName(TEXT("Mass.CrowdSpecificNpcName"), GCrowdSpecificNpcName, TEXT("Generate specific npc from name"));

	float GCrowdOverlapDetectRadiusSquared = 49000000.f;
	FAutoConsoleVariableRef CVarCrowdOverlapDetectRadiusSquared(TEXT("Mass.CrowdOverlapDetectRadiusSquared"), GCrowdOverlapDetectRadiusSquared, TEXT("radius squared for overlap detect"));

	bool GCrowdEnableDebugDrawOnBigMap = false;
	FAutoConsoleVariableRef CVarCrowdEnableDebugDrawOnBigMap(TEXT("Mass.EnableDebugDrawOnBigMap"), GCrowdEnableDebugDrawOnBigMap, TEXT("Enable debug draw on big map in game"));
}

// Debug Commands
FAutoConsoleCommand DebugCommandHideAllEntities(TEXT("massnpc.hideall"), TEXT("switch hide all entities"),
	FConsoleCommandDelegate::CreateLambda([]()
	{
		const auto World = GEngine->GetCurrentPlayWorld();
		const auto CrowdGlobalControlSubSystem = UWorld::GetSubsystem<UCrowdNpcControlSubsystem>(World);
		TArray<AActor*> Spawners;
		CrowdGlobalControlSubSystem->SetAllEntitiesHidden(!UE::MassCrowd::GCrowdTurnOffVisualization);
	})
);

FAutoConsoleCommand DebugCommandActivateAllEntities(TEXT("massnpc.activateall"), TEXT("switch activate all entities"),
	FConsoleCommandDelegate::CreateLambda([]()
	{
		const auto World = GEngine->GetCurrentPlayWorld();
		const auto CrowdGlobalControlSubSystem = UWorld::GetSubsystem<UCrowdNpcControlSubsystem>(World);
		CrowdGlobalControlSubSystem->SetAllEntitiesActivate(!UE::MassCrowd::GCrowdActivateAllEntities);
	})
);

void UCrowdNpcControlSubsystem::MarkDeleteEntities(const TArray<FMassEntityHandle>& MarkEntities, bool bDeleteDirectly)
{
	if (MarkEntities.Num() <= 0)
		return;
	
	ToBeDeleteEntities.Append(MarkEntities);
	if (const FMassEntityManager* EntityManager = UE::Mass::Utils::GetEntityManager(GetWorld()))
	{
		if (bDeleteDirectly)
			EntityManager->Defer().PushCommand<FMassCommandAddTags<FCanDirectDeleteTag>>(MarkEntities);
		EntityManager->Defer().PushCommand<FMassCommandAddTags<FToBeDeleteTag>>(MarkEntities);
	}
}

void UCrowdNpcControlSubsystem::MarkDeleteEntity(const FMassEntityHandle MarkEntity, bool bDeleteDirectly)
{
	ToBeDeleteEntities.Add(MarkEntity);
	if (const FMassEntityManager* EntityManager = UE::Mass::Utils::GetEntityManager(GetWorld()))
	{
		if (bDeleteDirectly)
			EntityManager->Defer().PushCommand<FMassCommandAddTags<FCanDirectDeleteTag>>(MarkEntity);
		EntityManager->Defer().PushCommand<FMassCommandAddTags<FToBeDeleteTag>>(MarkEntity);
	}
}

void UCrowdNpcControlSubsystem::OnEntitiesDeleted(const TArray<FMassEntityHandle>& DeletedEntities)
{
	if (DeletedEntities.Num() <= 0)
		return;

	RecordAreaOnEntitiesDestroyed(DeletedEntities);
	
	for (const FMassEntityHandle& DeleteEntity : DeletedEntities)
	{
		ToBeDeleteEntities.Remove(DeleteEntity);
	}
	
	if (OnNotifyEntityDeleted.IsBound())
	{
		OnNotifyEntityDeleted.Broadcast(DeletedEntities);
	}
}

void UCrowdNpcControlSubsystem::SetAllEntitiesHidden(bool bHidden)
{
	UE::MassCrowd::GCrowdTurnOffVisualization = bHidden ? 1 : 0;
}

bool UCrowdNpcControlSubsystem::IsAllEntitiesHidden()
{
	return UE::MassCrowd::GCrowdTurnOffVisualization!=0;
}

void UCrowdNpcControlSubsystem::SetAllEntitiesActivate(bool bActivated)
{
	UE::MassCrowd::GCrowdActivateAllEntities = bActivated ? 1 : 0;
	
	if (OnNotifyEntityActive.IsBound())
	{
		OnNotifyEntityActive.Broadcast(IsAllEntitiesActivated());
	}
}

bool UCrowdNpcControlSubsystem::IsAllEntitiesActivated()
{
	return UE::MassCrowd::GCrowdActivateAllEntities!=0;
}

void UCrowdNpcControlSubsystem::ChangeSuitLibKey(FString SuitLibKey)
{
	UE::MassCrowd::GCrowdSpecificNpcName = SuitLibKey;
}

void UCrowdNpcControlSubsystem::SetClimateScaleRatio(float InClimateScaleRatio)
{
	ClimateScaleRatio = InClimateScaleRatio;
	if (OnNotifyEntityScale.IsBound())
	{
		OnNotifyEntityScale.Broadcast(InClimateScaleRatio);
	}
}

TSet<FMassOverlapPointInfo>& UCrowdNpcControlSubsystem::GetInterestPoints(ECrowdOverlapPointType PointType)
{
	if (!InterestPoint.Contains(PointType))
	{
		static TSet<FMassOverlapPointInfo> EmptySet;
		return EmptySet;
	}
	return InterestPoint[PointType];
}

void UCrowdNpcControlSubsystem::RegInterestPoint(ECrowdOverlapPointType PointType, const FVector& WorldLoc, const float TriggerRadius, const FString& InstanceID)
{
	if (!InterestPoint.Contains(PointType))
	{
		TSet<FMassOverlapPointInfo> EmptySet;
		InterestPoint.Add(PointType, EmptySet);
	}
	
	for (FMassOverlapPointInfo InterestPointInfo : InterestPoint[PointType])
	{
		if (InterestPointInfo.PointPos.Equals(WorldLoc))
			return;
	}
	InterestPoint[PointType].Add(FMassOverlapPointInfo(WorldLoc, TriggerRadius, InstanceID, PointType));
}

void UCrowdNpcControlSubsystem::UnRegInterestPoint(ECrowdOverlapPointType PointType, const FVector& WorldLoc)
{
	if (!InterestPoint.Contains(PointType))
		return;
	
	const FMassOverlapPointInfo* TargetInfo = nullptr;
	for (FMassOverlapPointInfo InterestPointInfo : InterestPoint[PointType])
	{
		if (InterestPointInfo.PointPos.Equals(WorldLoc))
		{
			TargetInfo = &InterestPointInfo;
			break;
		}
	}
	if (TargetInfo != nullptr)
		InterestPoint[PointType].Remove(*TargetInfo);	
}

TSet<FMassOverlapPointInfo*> UCrowdNpcControlSubsystem::GetInterestTriggerPoints(const TArray<ECrowdOverlapPointType>& FilterTypes)
{
	FVector PlayerLocation = FVector(0, 0, 0);
	APlayerController* PlayerController = UGameplayStatics::GetPlayerController(GetWorld(), 0);
	TSet<FMassOverlapPointInfo*> OutPoints;
	if (PlayerController && PlayerController->GetPawn())
	{
		PlayerLocation = PlayerController->GetPawn()->GetActorLocation();
		for (ECrowdOverlapPointType FilterType : FilterTypes)
		{
			if (!InterestPoint.Find(FilterType))
			{
				continue;
			}
			for (auto& Point : InterestPoint[FilterType])
			{
				if (FVector::DistSquared2D(PlayerLocation, Point.PointPos) < UE::MassCrowd::GCrowdOverlapDetectRadiusSquared)
				{
					OutPoints.Add(&Point);
				}
			}
		}
	}

	return OutPoints;
}

bool UCrowdNpcControlSubsystem::ClaimSmartObjectSlotByActor(int64 SmartObjectUserID, int64 SmartObjectOwnerID, int32 SlotIndex)
{
	if (USmartObjectSubsystem* SOSubSys = UWorld::GetSubsystem<USmartObjectSubsystem>(GetWorld()))
	{
		AActor* SmartObjectUser = KGUtils::GetActorByID(SmartObjectUserID);
		AActor* SmartObjectOwner = KGUtils::GetActorByID(SmartObjectOwnerID);
		if (SmartObjectOwner && SmartObjectUser)
		{
			return SOSubSys->ClaimSmartObjectSlotByActor(SmartObjectUser, SmartObjectOwner, SlotIndex);
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("[CrowdNpcSubsys::ClaimSmartObjectSlotByActor] Found Actors error SOUser:%p, SOOwner:%p"), SmartObjectUser, SmartObjectOwner);
		}
	}
	return false;
}

bool UCrowdNpcControlSubsystem::ReleaseSmartObjectSlotByActor(int64 SmartObjectUserID, int64 SmartObjectOwnerID, int32 SlotIndex)
{
	if (USmartObjectSubsystem* SOSubSys = UWorld::GetSubsystem<USmartObjectSubsystem>(GetWorld()))
	{
		AActor* SmartObjectUser = KGUtils::GetActorByID(SmartObjectUserID);
		AActor* SmartObjectOwner = KGUtils::GetActorByID(SmartObjectOwnerID);
		if (SmartObjectOwner && SmartObjectUser)
		{
			return SOSubSys->ReleaseSmartObjectSlotByActor(SmartObjectUser, SmartObjectOwner, SlotIndex);
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("[CrowdNpcSubsys::ReleaseSmartObjectSlotByActor] Found Actors error SOUser:%p, SOOwner:%p"), SmartObjectUser, SmartObjectOwner);
		}
	}
	return false;
}

void UCrowdNpcControlSubsystem::RegCrowdNPCWanderTag(const FString& NPCType, int32 WanderTag)
{
	if (!CrowdNPCWanderTags.Find(NPCType))
	{
		CrowdNPCWanderTags.Add(NPCType, TArray<int32>());
	}
	CrowdNPCWanderTags[NPCType].Add(WanderTag);
}

bool UCrowdNpcControlSubsystem::IsEnableToSpawnEntities()
{
	return bEnableToSpawn;
}

void UCrowdNpcControlSubsystem::RecordAreaOnEntitiesCreated(TConstArrayView<FMassEntityHandle> Entities, const FC7AreaConfigData& InitData)
{
	// UE_LOG(LogTemp, Warning, TEXT("[CrowdNpcSubsys::RecordAreaOnEntitiesCreated] %d"), Entities.Num());
	TMap<FName, int>& AreaTypeCounts = CachedEntityCountMaps.FindOrAdd(InitData.AreaTag, {});
	for (const FMassEntityHandle& Entity : Entities)
	{
		EntityAreas.Emplace(Entity, InitData);
		AreaTypeCounts.FindOrAdd(InitData.AreaConfigType, 0)++;
	}
}

void UCrowdNpcControlSubsystem::RecordAreaOnEntityLaneChanged(const FMassEntityHandle& Entity, int32 NewAreaTags)
{
	if (FC7AreaConfigData* AreaConfig = EntityAreas.Find(Entity))
	{
		if (TMap<FName, int32>* AreaTypeCountsPtr = CachedEntityCountMaps.Find(AreaConfig->AreaTag))
		{
			if (int32* Count = AreaTypeCountsPtr->Find(AreaConfig->AreaConfigType))
			{
				(*Count)--;
			}
		}
		if (TMap<FName, int>* AreaTypeCountsPtr = CachedEntityCountMaps.Find(NewAreaTags))
		{
			AreaConfig->AreaTag = NewAreaTags;
			AreaTypeCountsPtr->FindOrAdd(AreaConfig->AreaConfigType, 0)++;
		}
	}
}

void UCrowdNpcControlSubsystem::RecordAreaOnEntitiesDestroyed(TConstArrayView<FMassEntityHandle> Entities)
{
	// UE_LOG(LogTemp, Warning, TEXT("[CrowdNpcSubsys::RecordAreaOnEntitiesDestroyed] %d"), Entities.Num());
	for (const FMassEntityHandle& Entity : Entities)
	{
		if (const FC7AreaConfigData* AreaConfig = EntityAreas.Find(Entity))
		{
			if (TMap<FName, int>* AreaTypeCountsPtr = CachedEntityCountMaps.Find(AreaConfig->AreaTag))
			{
				if (int32* Count = AreaTypeCountsPtr->Find(AreaConfig->AreaConfigType))
				{
					(*Count)--;
				}
			}
			
			EntityAreas.Remove(Entity);
		}
	}
}

void UCrowdNpcControlSubsystem::BeginSpawnEntities()
{
	bEnableToSpawn = true;
	if (OnNotifyEntityActive.IsBound())
	{
		OnNotifyEntityActive.Broadcast(true);
	}
}

int64 UCrowdNpcControlSubsystem::GetZoneGraphLaneTagsByPos(const FVector& InPosition)
{
	UZoneGraphSubsystem* ZoneGraphSubsystem = UWorld::GetSubsystem<UZoneGraphSubsystem>(GetWorld());
	if (ZoneGraphSubsystem == nullptr)
	{
		return -1;
	}
	const FVector SearchExtent = FVector(2500);
	const FBox QueryBounds(InPosition - SearchExtent, InPosition + SearchExtent);
	float OutDistanceSqr;
	FZoneGraphLaneLocation OutLaneLocation;

	bool bResult = ZoneGraphSubsystem->FindNearestLane(QueryBounds, FZoneGraphTagFilter(), OutLaneLocation, OutDistanceSqr);
	if (!bResult)
	{
		// UE_LOG(LogTemp, Error, TEXT("[CrowdNpcSubsys::GetZoneGraphLaneTagsByPos] can't find lane by postiton %s"), *InPosition.ToString());
		return -1;
	}
	const FZoneGraphStorage* Storage = ZoneGraphSubsystem->GetZoneGraphStorage(OutLaneLocation.LaneHandle.DataHandle);
	const int32 LaneIndex = OutLaneLocation.LaneHandle.Index;
	if (LaneIndex < Storage->Lanes.Num())
	{
		return Storage->Lanes[LaneIndex].Tags.GetValue();
	}
	return -1 ;
}

void UCrowdNpcControlSubsystem::SetSpawnAdjustTimeData(int32 ID, const TArray<int32>& TimeRanges, const TArray<float>& Scales)
{
	TRACE_CPUPROFILER_EVENT_SCOPE(UCrowdNpcControlSubsystem::SetSpawnAdjustTimeData)
	TArray<FCrowdAdjustTime> AdjustTimes;
	for (int32 i = 0; i < TimeRanges.Num() - 1; i++)
		AdjustTimes.Emplace(FCrowdAdjustTime(TimeRanges[i], 0, TimeRanges[i + 1] - 1, 59, Scales[i]));
	AdjustTimes.Emplace(FCrowdAdjustTime(TimeRanges[TimeRanges.Num() - 1], 0, 23, 59, Scales[Scales.Num() - 1]));
	AllSpawnAdjustTimeData.Emplace(ID, AdjustTimes);
}

void UCrowdNpcControlSubsystem::InitializeSpawnerData(const TArray<int32>& IntData, const TArray<FString>& TagData, const int32 TagNumber,
	const int32 Radius, const int32 MinGap, const int32 MaxGap)
{
	TRACE_CPUPROFILER_EVENT_SCOPE(UCrowdNpcControlSubsystem::InitializeSpawnerData)
	constexpr int32 IntConstNumber = 3;
	int32 IntCount = TagNumber + IntConstNumber;
	if (!ensure(IntData.Num() % IntCount == 0 && IntData.Num() / IntCount == TagData.Num() / TagNumber))
		return;

	UWorld* CurrentWorld = GetWorld();
	if (!ensure(CurrentWorld))
		return;
	
	const int32 SpawnerNum = IntData.Num() / IntCount;

	TArray<ACrowdMassSpawner*> Spawners;
	for (TActorIterator<ACrowdMassSpawner> It(CurrentWorld); It; ++It)
	{
		Spawners.Emplace(*It);
	}

	if (Spawners.Num() < SpawnerNum)
	{
		// spawn actors
		for (int32 i = Spawners.Num(); i < SpawnerNum; i++)
		{
			// 可以创建在(0, 0, 0)
			FActorSpawnParameters SpawnParams;
			ACrowdMassSpawner* NewSpawner = CurrentWorld->SpawnActor<ACrowdMassSpawner>(SpawnParams);
			Spawners.Emplace(NewSpawner);
		}
	}
	else if (Spawners.Num() > SpawnerNum)
	{
		for (int32 i = SpawnerNum; i < Spawners.Num(); i++)
		{
			Spawners[i]->Destroy();
		}
	}

	NpcAllowedAreas.Reset();
	ValidAreaTags = 0;
	for (int32 i = 0; i < SpawnerNum; i++)
	{
		const int32 AreaTagID = IntData[i * IntCount + 0];
		const int32 AdjustTimeID = IntData[i * IntCount + 1];
		const int32 SpawnCount = IntData[i * IntCount + 2];

		ValidAreaTags = ValidAreaTags | (1 << AreaTagID);
		
		ACrowdMassSpawner* Spawner = Spawners[i];
		if (AllSpawnAdjustTimeData.Contains(AdjustTimeID))
		{
			Spawner->CrowdAdjustTimes = AllSpawnAdjustTimeData[AdjustTimeID];
		}

		Spawner->GenerateOutRadius = Radius;
		Spawner->InitializeSetCount(SpawnCount);

		// Entity Types
		TArray<FMassSpawnedEntityType> EntityTypes;
		float ProportionSum = 0;
		TArray<FName> NpcTypeName;
		for (int32 j = 0; j < TagNumber; j++)
		{
			FString TagName = TagData[i * TagNumber + j];
			NpcTypeName.Add(FName(TagName));
			NpcAllowedAreas.FindOrAdd(FName(TagName), FZoneGraphTagMask()).Add(FZoneGraphTag(AreaTagID));
			
			FString Left, Category;
			TagName.Split(TEXT("_"), &Left, &Category, ESearchCase::IgnoreCase, ESearchDir::FromEnd);
			if (Category.IsEmpty())
				continue;

			FString FullPath = FString::Printf(TEXT("/Game/Blueprint/MassNPC/EntityConfig/%s/DA_MassEntityConfig_%s"), *Category, *TagName);
			FMassSpawnedEntityType EntityType = FMassSpawnedEntityType();
			EntityType.EntityConfig = FSoftObjectPath(FName(FullPath), FName(FString::Printf(TEXT("DA_MassEntityConfig_%s"), *TagName)), FString());
			EntityType.Proportion = IntData[i * IntCount + IntConstNumber + j];
			ProportionSum += EntityType.Proportion;
			EntityTypes.Emplace(EntityType);
		}

		for (auto& EntityType : EntityTypes)
		{
			EntityType.Proportion /= ProportionSum;
		}
		
		Spawner->InitializeSetEntityTypes(MoveTemp(EntityTypes));
		Spawner->SetAreaTypes(AreaTagID, NpcTypeName);
		Spawner->SetDeleteEntityParameters(OverflowRatioLimit, CheckSpawnProportionInterval + i);
		Spawner->OnNotifyClimateScaleRatio(ClimateScaleRatio);

		// Generators
		UCrowdMassEntityZoneGraphSpawnPointsGenerator* GeneratorInstance = NewObject<UCrowdMassEntityZoneGraphSpawnPointsGenerator>(Spawner);
		FZoneGraphTagFilter Filter;
		Filter.AnyTags.Add(FZoneGraphTag(AreaTagID));
		GeneratorInstance->SetTagFilter(MoveTemp(Filter));
		GeneratorInstance->SetGap(MinGap, MaxGap);
		GeneratorInstance->SetAreaTypes(AreaTagID, NpcTypeName);
		GeneratorInstance->SetOverrideLODSettings(OverrideTraitLODSettings);
		
		TArray<FMassSpawnDataGenerator> Generators;
		FMassSpawnDataGenerator& Generator = Generators.AddDefaulted_GetRef();
		Generator.GeneratorClass = UCrowdMassEntityZoneGraphSpawnPointsGenerator::StaticClass();
		Generator.GeneratorInstance = GeneratorInstance;

		Spawner->InitializeSetSpawnDataGenerators(MoveTemp(Generators));
	}
}

void UCrowdNpcControlSubsystem::SetOverrideTraitLODSettings(TArray<float> BaseLODDistance, TArray<int32> LODMaxCount,
	TArray<float> VisibleLODDistance, TArray<float> SimulationLODDistance, TArray<int32> SimulationLODMaxCount)
{
	if (!OverrideTraitLODSettings.IsValid())
		OverrideTraitLODSettings = MakeShared<FOverrideTraitLODSettings>();
	OverrideTraitLODSettings->BaseLODDistance = BaseLODDistance;
	OverrideTraitLODSettings->LODMaxCount = LODMaxCount;
	OverrideTraitLODSettings->VisibleLODDistance = VisibleLODDistance;
	OverrideTraitLODSettings->SimulationLODDistance = SimulationLODDistance;
	OverrideTraitLODSettings->SimulationLODMaxCount = SimulationLODMaxCount;
	OverrideTraitLODSettings->Version++;
}

void UCrowdNpcControlSubsystem::SetDeleteEntityParameters(float InOverflowRatioLimit, float InCheckSpawnProportionInterval)
{
	OverflowRatioLimit = InOverflowRatioLimit;
	CheckSpawnProportionInterval = InCheckSpawnProportionInterval;
}

bool UCrowdNpcControlSubsystem::SetAvoidanceProcessEnable(const bool bEnable)
{
	// 暂时不需要搞成通用的Process开关, 后续如果有必要可以根据Processor名称来搞.
	FMassProcessingPhaseConfig* ConfigArray = GetMutableDefault<UMassEntitySettings>()->ProcessingPhasesConfig;
	FMassProcessingPhaseConfig& PhaseConfig = ConfigArray[(uint32)EMassProcessingPhase::PrePhysics];
	if (bEnable)
	{
		TObjectPtr<UMassProcessor>* FoundProcessor = PhaseConfig.ProcessorCDOs.FindByPredicate([](TObjectPtr<UMassProcessor> CDO) { return CDO && CDO->GetName().Equals(TEXT("MassMovingAvoidanceProcessor")); });
		if (FoundProcessor == nullptr)
		{
			if (UMassProcessor* CDO = UMassMovingAvoidanceProcessor::StaticClass()->GetDefaultObject<UMassProcessor>())
			{
				PhaseConfig.ProcessorCDOs.Add(CDO);
				return true;
			}
		}
	}
	else
	{
		PhaseConfig.ProcessorCDOs.RemoveAll([](TObjectPtr<UMassProcessor> CDO) { return CDO == UMassMovingAvoidanceProcessor::StaticClass()->GetDefaultObject<UMassProcessor>(); });
		return true;
	}
	
	return false;
}

void UCrowdNpcControlSubsystem::RegCrowdNPCMovementData(const FString& NPCType, const FMassNPCMovementData& MovementData)
{
	CrowdNpcMovementConfigs.Add(NPCType, MovementData);
}

const FMassNPCMovementData* UCrowdNpcControlSubsystem::GetNPCMovementDataByType(const FString& NPCType)
{
	return CrowdNpcMovementConfigs.Find(NPCType);
}

bool UCrowdNpcControlSubsystem::IsEnabledDebugDrawOnBigMap()
{
	return UE::MassCrowd::GCrowdEnableDebugDrawOnBigMap;
}

void UCrowdNpcControlSubsystem::SetBigMapStatus(bool bIsOpen)
{
	bBigMapOpen = bIsOpen;
	if (bBigMapOpen)
	{
		if (!IsEnabledDebugDrawOnBigMap())
			return;
	
		if (!DrawHandle.IsValid())
		{
			DrawHandle = UDebugDrawService::Register(TEXT("Game"), FDebugDrawDelegate::CreateUObject(this, &UCrowdNpcControlSubsystem::DebugDraw));	
		}
	}
	else
	{
		if (DrawHandle.IsValid())
		{
			UDebugDrawService::Unregister(DrawHandle);
			DrawHandle.Reset();
		}
		StartViewportPos = FVector2D::ZeroVector;
		EndViewportPos = FVector2D::ZeroVector;
		StartWorldPos = FVector2D::ZeroVector;
		EndWorldPos = FVector2D::ZeroVector;
	}
}

FVector2D UCrowdNpcControlSubsystem::GetScreenPosition(FVector2D ViewportPosition) const
{
	if (UGameViewportClient* ViewportClient = GetWorld()->GetGameViewport())
	{
		TSharedPtr<IGameLayerManager> GameLayerManager = ViewportClient->GetGameLayerManager();
		if (GameLayerManager.IsValid())
		{
			FVector2D ViewportSize;
			ViewportClient->GetViewportSize(ViewportSize);
	
			const FGeometry& ViewportGeometry = GameLayerManager->GetViewportWidgetHostGeometry();
			const FVector2D ScreenPosition = (ViewportPosition / ViewportGeometry.GetLocalSize()) * ViewportSize;
			return ScreenPosition;
		}
	}
	return ViewportPosition;
}

void UCrowdNpcControlSubsystem::SetDebugMapParams(FVector2D InStartViewportPos, FVector2D InEndViewportPos, FVector2D InStartWorldPos
	, FVector2D InEndWorldPos)
{
	SetBigMapStatus(true);
	StartViewportPos = InStartViewportPos;
	EndViewportPos = InEndViewportPos;
	StartWorldPos = InStartWorldPos;
	EndWorldPos = InEndWorldPos;
}

FVector2D UCrowdNpcControlSubsystem::WorldPosToScreenPos(const FVector& WorldPos) const
{
	if ( EndWorldPos.Equals(StartWorldPos) || EndViewportPos.Equals(StartViewportPos) )
	{
		return FVector2D::ZeroVector;
	}
	
	FVector2D RefVectorWorld = EndWorldPos - StartWorldPos;
	FVector2D RefVectorView = EndViewportPos - StartViewportPos;
	
	float Scale = RefVectorView.Length() / RefVectorWorld.Length();
	FVector2D ScaledWorldPos = (FVector2D(WorldPos.X,WorldPos.Y) - StartWorldPos) * Scale;
	
	float AngleRad = FMath::Atan2(RefVectorView.Y, RefVectorView.X) - FMath::Atan2(RefVectorWorld.Y, RefVectorWorld.X);
	float RotatedX = ScaledWorldPos.X * FMath::Cos( AngleRad ) - ScaledWorldPos.Y * FMath::Sin( AngleRad );
	float RotatedY = ScaledWorldPos.X * FMath::Sin( AngleRad ) + ScaledWorldPos.Y * FMath::Cos( AngleRad );
	
	FVector2D ViewportPosition = FVector2D(RotatedX, RotatedY) + StartViewportPos;
	return GetScreenPosition(ViewportPosition);
}

void UCrowdNpcControlSubsystem::ResetDebugEntityInfo()
{
	DebugDrawEntityMap.Empty();
}

void UCrowdNpcControlSubsystem::AddDebugEntityInfo(EMassRepresentationType RepresentationType, const FVector& Location, bool IsToBeDeleted)
{
	if (!IsEnabledDebugDrawOnBigMap())
		return;
	
	int32 DebugDrawType = 0;
	if (!IsToBeDeleted)
	{
		switch (RepresentationType)
		{
			case EMassRepresentationType::HighResSpawnedActor:
				{
					DebugDrawType = 1;
					break;
				}
			case EMassRepresentationType::LowResSpawnedActor:
				{
					DebugDrawType = 2;
					break;
				}
			case EMassRepresentationType::StaticMeshInstance:
				{
					DebugDrawType = 3;
					break;
				}
			case EMassRepresentationType::None:
				{
					DebugDrawType = 4;
					break;
				}
			case EMassRepresentationType::Detached:
				{
					DebugDrawType = 5;
					break;
				}
			default:
				break;
		}
	}
	TArray<FVector2D>& Values = DebugDrawEntityMap.FindOrAdd(DebugDrawType);
	Values.Add(WorldPosToScreenPos(Location));
}

void UCrowdNpcControlSubsystem::DebugDraw(UCanvas* Canvas, class APlayerController* PC)
{
	if (!IsEnabledDebugDrawOnBigMap())
		return;
	
	for (auto& Pair : DebugDrawEntityMap)
	{
		FVector2D ScreenSize(4.0f, 4.0f);
		switch (Pair.Key)
		{
		case 0://ToBeDeleted
			{
				Canvas->SetDrawColor(FColor::Red);
				break;
			}
		case 1://HighResSpawnedActor
			{
				Canvas->SetDrawColor(FColor::Purple);
				ScreenSize.X = 10;
				ScreenSize.Y = 10;
				break;
			}
		case 2://LowResSpawnedActor
			{
				Canvas->SetDrawColor(FColor::Green);
				ScreenSize.X = 8;
				ScreenSize.Y = 8;
				break;
			}
		case 3://StaticMeshInstance
			{
				Canvas->SetDrawColor(FColor::Yellow);
				ScreenSize.X = 6;
				ScreenSize.Y = 6;
				break;
			}
		case 4://None
			{
				Canvas->SetDrawColor(FColor::Silver);
				ScreenSize.X = 5;
				ScreenSize.Y = 5;
				break;
			}
		case 5://Detached
			{
				Canvas->SetDrawColor(FColor::White);
				break;
			}
		default:
			{
				Canvas->SetDrawColor(FColor::Cyan);
				break;
			}
		}
		float DPIScale = Canvas->Canvas->GetDPIScale();
		for (auto& ScreenLoc : Pair.Value)
		{
			Canvas->K2_DrawBox(ScreenLoc / DPIScale - ScreenSize/2, ScreenSize, 8, Canvas->DrawColor);
		}
	}
}

void UCrowdNpcControlSubsystem::Deinitialize()
{
	// 清理一下Delegate
	OnNotifyEntityDeleted.Clear();
	OnNotifyEntityActive.Clear();
	OnNotifyEntityScale.Clear();

	if (DrawHandle.IsValid())
	{
		UDebugDrawService::Unregister(DrawHandle);
		DrawHandle.Reset();
	}
	
	Super::Deinitialize();
}
