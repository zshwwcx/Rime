#include "Actors/CrowdNPCHideTriggerActor.h"
#include "Subsystems/CrowdNpcControlSubsystem.h"
#if WITH_EDITOR
#include "DrawDebugHelpers.h"
#endif

// Sets default values
ACrowdNPCHideTriggerActor::ACrowdNPCHideTriggerActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;
#if WITH_EDITOR
	PrimaryActorTick.bCanEverTick = true;
#endif
}

// Called when the game starts or when spawned
void ACrowdNPCHideTriggerActor::BeginPlay()
{
	Super::BeginPlay();
	GetWorld()->GetTimerManager().SetTimerForNextTick([this]()
	{
		if (UCrowdNpcControlSubsystem* CrowdNpcControlSubsystem = UWorld::GetSubsystem<UCrowdNpcControlSubsystem>(GetWorld()))
		{
			RegisterLocation = GetActorLocation();
			CrowdNpcControlSubsystem->RegInterestPoint(ECrowdOverlapPointType::Hide, RegisterLocation, TriggerRadius, "InvalidInstanceID");
		}
	});
}

void ACrowdNPCHideTriggerActor::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
	if (UCrowdNpcControlSubsystem* CrowdNpcControlSubsystem = UWorld::GetSubsystem<UCrowdNpcControlSubsystem>(GetWorld()))
	{
		CrowdNpcControlSubsystem->UnRegInterestPoint(ECrowdOverlapPointType::Hide, RegisterLocation);
	}
}

// Called every frame
void ACrowdNPCHideTriggerActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
#if WITH_EDITOR
	if (UWorld* World = GetWorld())
	{
		if (World->WorldType == EWorldType::Editor || World->WorldType == EWorldType::EditorPreview)
		{
			DrawDebugSphere(
				World,
				GetActorLocation(),
				TriggerRadius,
				20,
				FColor::Red,
				false,
				0,
				/*DepthPriority*/ 0,
				5
			);
		}
	}
#endif
}
