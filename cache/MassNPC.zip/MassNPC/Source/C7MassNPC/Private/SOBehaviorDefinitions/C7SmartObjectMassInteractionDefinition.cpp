// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: luyilong@kuaishou.com

#include "SOBehaviorDefinitions/C7SmartObjectMassInteractionDefinition.h"
#include "CrowdNPCCharacter.h"
#include "MassActorSubsystem.h"
#include "SmartObjectSubsystem.h"
#include "SmartObjectComponent.h"
#include "MassSmartObjectFragments.h"
#include "3C/Interactor/SceneActorBase.h"


void UC7SmartObjectMassInteractionDefinition::Activate(FMassCommandBuffer& CommandBuffer, const FMassBehaviorEntityContext& EntityContext) const
{
	Super::Activate(CommandBuffer, EntityContext);

	const FMassActorFragment& ActorFragment = EntityContext.EntityView.GetFragmentData<FMassActorFragment>();
	if (const ACrowdNPCCharacter* CrowdCharacter = Cast<ACrowdNPCCharacter>(ActorFragment.Get()))
	{
		const FMassSmartObjectUserFragment& SOUser = EntityContext.EntityView.GetFragmentData<FMassSmartObjectUserFragment>();
		const USmartObjectSubsystem& Subsystem = EntityContext.SmartObjectSubsystem;
		const USmartObjectComponent* SmartObjectComponent = Subsystem.GetSmartObjectComponent(SOUser.InteractionHandle);
		if (AActor* SOActor = SmartObjectComponent ? SmartObjectComponent->GetOwner() : nullptr)
		{
			if (ASceneActorBase* SceneActor = Cast<ASceneActorBase>(SOActor))
			{
				CrowdCharacter->OnStartInteractWithSceneActor(SceneActor->GetInstanceID(), SOUser.InteractionHandle.SlotHandle.GetSlotIndex(), UseTime);
			}
		}
	}
}

void UC7SmartObjectMassInteractionDefinition::Deactivate(FMassCommandBuffer& CommandBuffer, const FMassBehaviorEntityContext& EntityContext) const
{
	Super::Deactivate(CommandBuffer, EntityContext);

	const FMassActorFragment& ActorFragment = EntityContext.EntityView.GetFragmentData<FMassActorFragment>();
	if (const ACrowdNPCCharacter* CrowdCharacter = Cast<ACrowdNPCCharacter>(ActorFragment.Get()))
	{
		const FMassSmartObjectUserFragment& SOUser = EntityContext.EntityView.GetFragmentData<FMassSmartObjectUserFragment>();
		const USmartObjectSubsystem& Subsystem = EntityContext.SmartObjectSubsystem;
		const USmartObjectComponent* SmartObjectComponent = Subsystem.GetSmartObjectComponent(SOUser.InteractionHandle);
		if (AActor* SOActor = SmartObjectComponent ? SmartObjectComponent->GetOwner() : nullptr)
		{
			if (ASceneActorBase* SceneActor = Cast<ASceneActorBase>(SOActor))
			{
				CrowdCharacter->OnFinishInteractWithSceneActor(SceneActor->GetInstanceID());
			}
		}
	}
}
