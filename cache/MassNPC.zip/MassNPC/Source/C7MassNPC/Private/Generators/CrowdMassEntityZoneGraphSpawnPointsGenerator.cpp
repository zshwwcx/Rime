// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: luyilong@kuaishou.com

#include "Generators/CrowdMassEntityZoneGraphSpawnPointsGenerator.h"

#include "MassEntityZoneGraphSpawnPointsGenerator.h"
#include "ZoneGraphSubsystem.h"
#include "ZoneGraphQuery.h"
#include "Engine/World.h"
#include "VisualLogger/VisualLogger.h"
#include "Engine/World.h"
#include "Kismet/GameplayStatics.h"
#include "MassSpawnerTypes.h"
#include "CrowdMassSpawner.h"
#include "MassCommonUtils.h"
#include "MassEntityConfigAsset.h"
#include "MassGameplaySettings.h"
#include "MassLODTrait.h"
#include "MassVisualizationTrait.h"
#include "Processors/C7AreaCrowdProportionProcessor.h"
#include "Processors/C7MassNpcInitializeProcessor.h"


static TAutoConsoleVariable<bool> CVarCrowdMassGeneratorDebug(TEXT("Mass.CrowdMassGeneratorDebug"), false, TEXT("Generate Only In Born Point"));


void UCrowdMassEntityZoneGraphSpawnPointsGenerator::SetRadius(float radius)
{
	this->Radius = radius;
}

void UCrowdMassEntityZoneGraphSpawnPointsGenerator::SetGap(const float InMinGap, const float InMaxGap)
{
	this->MinGap = InMinGap;
	this->MaxGap = InMaxGap;
}

void UCrowdMassEntityZoneGraphSpawnPointsGenerator::SetTagFilter(FZoneGraphTagFilter&& InTagFilter)
{
	this->TagFilter = MoveTemp(InTagFilter);
}

void UCrowdMassEntityZoneGraphSpawnPointsGenerator::SetAreaTypes(int32 InAreaTag, const TArray<FName>& InAreaConfigTypes)
{
	AreaTag = InAreaTag;
	AreaConfigTypes = InAreaConfigTypes;
}

void UCrowdMassEntityZoneGraphSpawnPointsGenerator::SetOverrideLODSettings(TSharedPtr<FOverrideTraitLODSettings> InOverrideTraitLODSettings)
{
	OverrideTraitLODSettings = InOverrideTraitLODSettings;
}

void UCrowdMassEntityZoneGraphSpawnPointsGenerator::GeneratePointsForZoneGraphData(const ::AZoneGraphData& ZoneGraphData, TArray<FVector>& Locations, const FRandomStream& RandomStream) const
{
	// Avoid an infinite loop.
	if (MinGap == 0.0f && MaxGap == 0.0f)
	{
		// UE_VLOG_UELOG(this, LogC7Mass, Error, TEXT("You cannot set both Min Gap and Max Gap to 0.0f"));
		return;						
	}

	UCrowdNpcControlSubsystem* ControlSubSys = UWorld::GetSubsystem<UCrowdNpcControlSubsystem>(GetWorld());
	if(!ControlSubSys)
	{
		return;
	}

	// todo 如果后面点很多, 需要做剔除的逻辑
	TSet<FMassOverlapPointInfo>& BornPoints = ControlSubSys->GetInterestPoints(ECrowdOverlapPointType::Born);

	const FZoneGraphStorage &ZoneGraphStorage = ZoneGraphData.GetStorage();

	FVector PlayerLocation = FVector(0, 0, 0);
	APlayerController* PlayerController = UGameplayStatics::GetPlayerController(GetWorld(), 0);
	if (PlayerController && PlayerController->GetPawn())
	{
		PlayerLocation = PlayerController->GetPawn()->GetActorLocation();
	} else
	{
		UE_LOG(LogC7Mass, Warning, TEXT("No player found when CrowdMassEntityZoneGraphSpawnPointsGenerator generator."));
	}

	// DrawDebugCircle(GetWorld(), PlayerLocation, Radius, 50, FColor::Green, true, -1, 0, 10.0f, FVector(1, 0, 0), FVector(0, 1, 0), false);
	// UE_LOG(LogC7Mass, Log, TEXT("[CrowdNPCCharacter] The PlayerLocation is %f, %f, %f"), PlayerLocation.X, PlayerLocation.Y, PlayerLocation.Z);
	
	for (int32 LaneIndex = 0; LaneIndex < ZoneGraphStorage.Lanes.Num(); ++LaneIndex)
	{
		const FZoneLaneData& Lane = ZoneGraphStorage.Lanes[LaneIndex];
		
		const float LaneHalfWidth = Lane.Width / 2.0f;
		if (TagFilter.Pass(Lane.Tags))
		{
			float LaneLength = 0.0f;
			UE::ZoneGraph::Query::GetLaneLength(ZoneGraphStorage, LaneIndex, LaneLength);

			float Distance = static_cast<float>(RandomStream.FRandRange(MinGap, MaxGap)); // ..initially
			while (Distance <= LaneLength)
			{
				// Add location at the center of this space.
				FZoneGraphLaneLocation LaneLocation;
				UE::ZoneGraph::Query::CalculateLocationAlongLane(ZoneGraphStorage, LaneIndex, Distance, LaneLocation);
				if (IsPointOutCircle(LaneLocation.Position, PlayerLocation) || IsPointInBornPoint(LaneLocation.Position, BornPoints))
				{
					const FVector Perp = LaneLocation.Direction ^ LaneLocation.Up;
					Locations.Add(LaneLocation.Position + Perp * RandomStream.FRandRange(-LaneHalfWidth, LaneHalfWidth));
				}
				
				// Advance ahead past the space we just consumed, plus a random gap.
				Distance += static_cast<float>(RandomStream.FRandRange(MinGap, MaxGap));
			}
		}
	}
}

// 函数检查一个点是否在圆外
bool UCrowdMassEntityZoneGraphSpawnPointsGenerator::IsPointOutCircle(const FVector& Point, const FVector& Center) const
{
#if !UE_BUILD_SHIPPING
	if (CVarCrowdMassGeneratorDebug.GetValueOnAnyThread())
		return false;
#endif
	
	FVector2D NewPoint(Point.X, Point.Y);
	FVector2D NewCenter(Center.X, Center.Y);
	
	float DistanceSquared = FVector2D::DistSquared(NewPoint, NewCenter);
	return DistanceSquared >= FMath::Square(Radius);
}

// 函数检查一个点是否在出生点范围
bool UCrowdMassEntityZoneGraphSpawnPointsGenerator::IsPointInBornPoint(const FVector& Point, TSet<FMassOverlapPointInfo>& BornPoints) const
{
	bool bInBornPoint = false;
	for (const FMassOverlapPointInfo& BornPointInfo : BornPoints)
	{
		if (FVector::Distance(Point, BornPointInfo.PointPos) <= BornPointInfo.TriggerRadius)
		{
			bInBornPoint = true;
			break;	
		}
	}
	return bInBornPoint;
}

// 这里我们override来实现精确的数量生成
void UCrowdMassEntityZoneGraphSpawnPointsGenerator::BuildResultsFromEntityTypes(const int32 SpawnCount, TConstArrayView<FMassSpawnedEntityType> EntityTypes, TArray<FMassEntitySpawnDataGeneratorResult>& OutResults) const
{
	const int EntityTypeNumber = EntityTypes.Num();
	float TotalProportion = 0.0f;
	TArray<float> AdjustedProportion;
	AdjustedProportion.Reserve(EntityTypeNumber);
	for (const FMassSpawnedEntityType& EntityType : EntityTypes)
	{
		TotalProportion += EntityType.Proportion;
		AdjustedProportion.Add(EntityType.Proportion);
	}

	if (TotalProportion <= 0)
	{
		UE_LOG(LogC7Mass, Warning, TEXT("[CrowdMassSpawner] The total combined proportion of all the entity types needs to be greater than 0."));
		return;
	}

	if (IsControlledByDesigner())
	{
		if (AreaConfigTypes.Num() < EntityTypeNumber)
		{
			UE_LOG(LogC7Mass, Warning, TEXT("[CrowdMassSpawner] The number of AreaConfigTypes needs to be greater than the number of EntityTypes."));
			return;
		}
	
		if (UCrowdNpcControlSubsystem* ControlSubSys = UWorld::GetSubsystem<UCrowdNpcControlSubsystem>(GetWorld()))
		{
			if (TMap<FName, int32>* TypeCountMap = ControlSubSys->CachedEntityCountMaps.Find(AreaTag))
			{
				int32 CurrentTotalCount = 0;
				for (int i = 0; i < EntityTypeNumber; i++)
					CurrentTotalCount += FMath::Abs(TypeCountMap->FindRef(AreaConfigTypes[i]));
				if (CurrentTotalCount > 0)
				{
					for (int i = 0; i < EntityTypeNumber; i++)
					{
						const float CurrentCount = (float)TypeCountMap->FindRef(AreaConfigTypes[i]) / CurrentTotalCount;
						const float NewProportion = FMath::Max(0, EntityTypes[i].Proportion / TotalProportion - CurrentCount);
						TotalProportion += NewProportion - EntityTypes[i].Proportion;
						AdjustedProportion[i] = NewProportion;
					}
				}
			}
		}
	}

	int32 AlreadySpawnCount = 0;
	TArray<int32> EntityCounts;
	EntityCounts.Reserve(EntityTypeNumber);
	for (int32 i = 0; i < EntityTypeNumber; i++)
	{
		int32 EntityCount = FMath::FloorToInt(SpawnCount * AdjustedProportion[i] / TotalProportion);
		AlreadySpawnCount += EntityCount;
		EntityCounts.Add(EntityCount);
	}

	const int32 RemainCnt = SpawnCount - AlreadySpawnCount;
	ensure(RemainCnt >= 0);
	ensure(RemainCnt <= EntityTypeNumber);
	if (RemainCnt > 0)
	{
		// 这里按权重随机, 因为很多时候都是只需要生成几个Entity, 大概率都是全部在这里生成, 所以这里也按照权重来生成很重要.
		for(int i = 1;i < EntityTypeNumber; i++)
		{
			AdjustedProportion[i] += AdjustedProportion[i - 1];
		}
		for (int i = 0; i < RemainCnt; i++)
		{
			float RandValue = FMath::RandRange(.0f, TotalProportion);
			// 二分法查找
			const int32 Index = Algo::UpperBound(AdjustedProportion, RandValue);
			if (EntityCounts.IsValidIndex(Index))
				EntityCounts[Index]++;
		}
	}

	for (int i = 0; i < EntityTypeNumber; i++)
	{		
		FMassEntitySpawnDataGeneratorResult& Res = OutResults.AddDefaulted_GetRef();
		Res.NumEntities = EntityCounts[i];
		Res.EntityConfigIndex = i;
		Res.PostSpawnProcessors.Add(UC7AreaCrowdProportionProcessor::StaticClass());
	}
}

void UCrowdMassEntityZoneGraphSpawnPointsGenerator::Generate(UObject& QueryOwner, TConstArrayView<FMassSpawnedEntityType> EntityTypes, int32 Count, FFinishedGeneratingSpawnDataSignature& FinishedGeneratingSpawnPointsDelegate) const
{
	if (Count <= 0)
	{
		FinishedGeneratingSpawnPointsDelegate.Execute(TArray<FMassEntitySpawnDataGeneratorResult>());
		return;
	}
	
	// 这里处于资产刚被异步加载完的时机, 对 const Entity Config 强行进行修改.
	ApplyOverrideTraitLODSettings(EntityTypes);
	
	const UZoneGraphSubsystem* ZoneGraph = UWorld::GetSubsystem<UZoneGraphSubsystem>(QueryOwner.GetWorld());
	if (ZoneGraph == nullptr)
	{
		UE_VLOG_UELOG(&QueryOwner, LogTemp, Error, TEXT("No zone graph subsystem found in world"));
		return;
	}

	TArray<FVector> Locations;
	
	const FRandomStream RandomStream(UE::Mass::Utils::OverrideRandomSeedForTesting(GetRandomSelectionSeed()));
	const TConstArrayView<FRegisteredZoneGraphData> RegisteredZoneGraphs = ZoneGraph->GetRegisteredZoneGraphData();
	if (RegisteredZoneGraphs.IsEmpty())
	{
		UE_VLOG_UELOG(&QueryOwner, LogTemp, Error, TEXT("No zone graphs found"));
		return;
	}

	for (const FRegisteredZoneGraphData& Registered : RegisteredZoneGraphs)
	{
		if (Registered.bInUse && Registered.ZoneGraphData)
		{
			GeneratePointsForZoneGraphData(*Registered.ZoneGraphData, Locations, RandomStream);
		}
	}

	if (Locations.IsEmpty())
	{
		UE_VLOG_UELOG(&QueryOwner, LogTemp, Error, TEXT("No locations found on zone graphs"));
		return;
	}

	// Randomize them
	const int32 NeedCount = FMath::Min(Count, Locations.Num()); // 经常只需要一个
	for (int32 I = 0; I < NeedCount; ++I)
	{
		const int32 J = RandomStream.RandRange(I, Locations.Num() - 1);
		Locations.Swap(I, J);
	}

	// If we generated too many, shrink it.
	if (Locations.Num() > Count)
	{
		Locations.SetNum(Count);
	}

	// Build array of entity types to spawn.
	TArray<FMassEntitySpawnDataGeneratorResult> Results;
	BuildResultsFromEntityTypes(Count, EntityTypes, Results);

	const int32 LocationCount = Locations.Num();
	int32 LocationIndex = 0;

	// Distribute points amongst the entities to spawn.
	for (FMassEntitySpawnDataGeneratorResult& Result : Results)
	{
		// @todo: Make separate processors and pass the ZoneGraph locations directly.
		Result.SpawnDataProcessor = UC7MassNpcInitializeProcessor::StaticClass();
		Result.SpawnData.InitializeAs<FC7MassNpcSpawnData>();
		FC7MassNpcSpawnData& SpawnData = Result.SpawnData.GetMutable<FC7MassNpcSpawnData>();

		SpawnData.Transforms.Reserve(Result.NumEntities);
		for (int i = 0; i < Result.NumEntities; i++)
		{
			FTransform& Transform = SpawnData.Transforms.AddDefaulted_GetRef();
			Transform.SetLocation(Locations[LocationIndex % LocationCount]);
			LocationIndex++;
		}

		SpawnData.InitAreaConfigTypeFragment.AreaTag = AreaTag;
		if (AreaConfigTypes.IsValidIndex(Result.EntityConfigIndex))
			SpawnData.InitAreaConfigTypeFragment.AreaConfigType = AreaConfigTypes[Result.EntityConfigIndex]; 
	}

#if ENABLE_VISUAL_LOG
	UE_VLOG(this, LogTemp, Log, TEXT("Spawning at %d locations"), LocationIndex);
	if (GetDefault<UMassGameplaySettings>()->bLogSpawnLocations)
	{
		if (FVisualLogEntry* LogEntry = FVisualLogger::Get().GetLastEntryForObject(this))
		{
			FVisualLogShapeElement Element(TEXT(""), FColor::Orange, /*Thickness*/20, LogTemp.GetCategoryName());

			Element.Points.Reserve(LocationIndex);
			for (const FMassEntitySpawnDataGeneratorResult& Result : Results)
			{
				const FC7MassNpcSpawnData& SpawnData = Result.SpawnData.Get<FC7MassNpcSpawnData>();
				for (int i = 0; i < Result.NumEntities; i++)
				{
					Element.Points.Add(SpawnData.Transforms[i].GetLocation());
				}
			}
			
			Element.Type = EVisualLoggerShapeElement::SinglePoint;
			Element.Verbosity = ELogVerbosity::Display;
			LogEntry->AddElement(Element);
		}
	}
#endif // ENABLE_VISUAL_LOG

	FinishedGeneratingSpawnPointsDelegate.Execute(Results);
}

void UCrowdMassEntityZoneGraphSpawnPointsGenerator::ApplyOverrideTraitLODSettings(const TConstArrayView<FMassSpawnedEntityType> EntityTypes) const
{
	TRACE_CPUPROFILER_EVENT_SCOPE(UCrowdMassEntityZoneGraphSpawnPointsGenerator::ApplyOverrideTraitLODSettings)
	if (!OverrideTraitLODSettings.IsValid())
		return;
	
	// 如果已经设置过了, 就不再设置了.
	if (OverrideTraitLODSettingsVersion == OverrideTraitLODSettings->Version)
		return;
	const_cast<UCrowdMassEntityZoneGraphSpawnPointsGenerator*>(this)->OverrideTraitLODSettingsVersion = OverrideTraitLODSettings->Version;
	
	for (const FMassSpawnedEntityType& EntityType : EntityTypes)
	{
		const UMassEntityConfigAsset* ConfigAsset = EntityType.EntityConfig.Get();
		if (!ConfigAsset)
		{ 
			// 理论上这个时候, 资产都已经加在进来了.
			UE_LOG(LogTemp, Error, TEXT("MassEntityConfigAsset in EntityTypes not loaded"));
			continue;
		}
		
		// 会修改Config资产, 但是不会Mark Dirty, 如果策划在编辑器中保存资产, 则有可能将被修改的只保存下来.
		// 但是之后资产中的这些值不会被直接使用, 总是先被这里覆盖之后, 才会生效.
		// Visual Trait
		const UMassEntityTraitBase* ConstVisualTrait = ConfigAsset->FindTrait(UMassVisualizationTrait::StaticClass());
		if (UMassVisualizationTrait* VisualTrait = Cast<UMassVisualizationTrait>(const_cast<UMassEntityTraitBase*>(ConstVisualTrait)))
		{
			FMassVisualizationLODParameters& LODParams = VisualTrait->LODParams;
			for (int i = 0; i < EMassLOD::Max; i++)
			{
				if (OverrideTraitLODSettings->BaseLODDistance.IsValidIndex(i))
					LODParams.BaseLODDistance[i] = OverrideTraitLODSettings->BaseLODDistance[i];
				if (OverrideTraitLODSettings->LODMaxCount.IsValidIndex(i))
					LODParams.LODMaxCount[i] = OverrideTraitLODSettings->LODMaxCount[i];
				if (OverrideTraitLODSettings->VisibleLODDistance.IsValidIndex(i))
					LODParams.VisibleLODDistance[i] = OverrideTraitLODSettings->VisibleLODDistance[i];
			}
		}
		
		// Simulation Trait
		const UMassEntityTraitBase* ConstSimulationTrait = ConfigAsset->FindTrait(UMassSimulationLODTrait::StaticClass());
		if (UMassSimulationLODTrait* SimulationTrait = Cast<UMassSimulationLODTrait>(const_cast<UMassEntityTraitBase*>(ConstSimulationTrait)))
		{
			if (const auto ParamsProperty = SimulationTrait->GetClass()->FindPropertyByName(FName("Params")))
			{
				if (FMassSimulationLODParameters* LODParams = ParamsProperty->ContainerPtrToValuePtr<FMassSimulationLODParameters>(SimulationTrait))
				{
					for (int i = 0; i < EMassLOD::Max; i++)
					{
						if (OverrideTraitLODSettings->SimulationLODDistance.IsValidIndex(i))
							LODParams->LODDistance[i] = OverrideTraitLODSettings->SimulationLODDistance[i];
						if (OverrideTraitLODSettings->SimulationLODMaxCount.IsValidIndex(i))
							LODParams->LODMaxCount[i] = OverrideTraitLODSettings->SimulationLODMaxCount[i];
					}
				}
			}
		}
	}
}
