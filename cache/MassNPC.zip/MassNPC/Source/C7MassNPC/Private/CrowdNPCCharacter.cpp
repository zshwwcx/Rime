// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#include "CrowdNPCCharacter.h"

#include "CrowdMassSpawner.h"
#include "MassAgentComponent.h"
#include "Processors/C7CrowdInteractionProcessor.h"
#include "MassEntityManager.h"
#include "Fragments/C7ApplyMovementFragment.h"
#include "Fragments/C7SwitchSTStateFragment.h"
#include "3C/Interactor/WorldManager.h"
#include "3C/Character/LuaActorBase.h"
#include "Fragments/CrowdNPCVisualizationFragment.h"

namespace UE::MassCrowd
{
	extern FString GCrowdSpecificNpcName;
}

// Sets default values
ACrowdNPCCharacter::ACrowdNPCCharacter()
{
	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
}

// Called when the game starts or when spawned
void ACrowdNPCCharacter::BeginPlay()
{
	Super::BeginPlay();
	//设置DistanceFactorThesholds表，3级URO LOD
	if (USkeletalMeshComponent* SkeletalMesh = GetMesh())
	{
		if (FAnimUpdateRateParameters* AnimUpdateRateParams = SkeletalMesh->AnimUpdateRateParams)
		{
			static const float ThresholdTable[] =
			{
				0.004f, 0.002f, 0.f
			};
			static const int32 TableNum = UE_ARRAY_COUNT(ThresholdTable);
			
			TArray<float>& Thresholds = AnimUpdateRateParams->BaseVisibleDistanceFactorThesholds;
			Thresholds.Empty(TableNum);
			for (int32 Index = 0; Index < TableNum; ++Index)
			{
				Thresholds.Add(ThresholdTable[Index]);
			}
		}
	}
}

void ACrowdNPCCharacter::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
	// 通知脚本entity销毁
	OnActorEnterISM(true);
}

// Called every frame
void ACrowdNPCCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

// Called to bind functionality to input
void ACrowdNPCCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
}

void ACrowdNPCCharacter::OnGetOrSpawn(FMassEntityManager* EntityManager, const FMassEntityHandle MassAgent)
{
	if (EntityManager && EntityManager->IsEntityActive(MassAgent))
	{
		if (FCrowdNPCVisualizationFragment* CrowdNPCVisualizationFragment = EntityManager->GetFragmentDataPtr<FCrowdNPCVisualizationFragment>(MassAgent))
		{
			if (UE::MassCrowd::GCrowdSpecificNpcName != "")
			{
				SuitLibKey = UE::MassCrowd::GCrowdSpecificNpcName;
			}
			else if (SuitLibKey != CrowdNPCVisualizationFragment->SuitLibKey)
			{
				SuitLibKey = CrowdNPCVisualizationFragment->SuitLibKey;
			}
		}
	}
	// 通知脚本创建Entity
	OnActorEnterISM(false);
}

void ACrowdNPCCharacter::SetAdditionalMeshOffset(const float Offset)
{
	// do nothing
}

void ACrowdNPCCharacter::OnActorEnabledTypeChange(const EMassActorEnabledType EnabledType)
{
	if (EnabledType == EMassActorEnabledType::Disabled)
	{
		if (!bInISM)
		{
			bInISM = true;
			OnActorEnterISM(bInISM);
		}
	}
	else
	{
		if (bInISM)
		{
			bInISM = false;
			OnActorEnterISM(bInISM);
		}
	}
}

void ACrowdNPCCharacter::OnActorEnterISM(bool bEnter)
{
	if (UWorldManager* WorldMgr = UWorldManager::GetInstance(GetWorld()))
	{
		if (!bEnter)
		{
			WorldMgr->RegisterMassNPCActor(this, SuitLibKey, BodyType, Rank);
		}
		else
		{
			WorldMgr->UnRegisterMassNPCActor(this, SuitLibKey, BodyType, Rank);
		}
	}

}

void ACrowdNPCCharacter::FinishInteract()
{
	const FMassEntityManager* EntityManager = GetMassEntityManager();
	if (!EntityManager) return;
	
	const UMassAgentComponent* AgentComp = FindComponentByClass<UMassAgentComponent>();
	if (!AgentComp) return;
	
	EntityManager->Defer().AddTag<FDeActiveC7SmartObjectMassInteractionTag>(AgentComp->GetEntityHandle());
}

void ACrowdNPCCharacter::SetCrowdNpcVelocity(bool bSet, float VelocityX, float VelocityY, float VelocityZ)
{
	const FMassEntityManager* EntityManager = GetMassEntityManager();
	if (!EntityManager) return;
	
	const UMassAgentComponent* AgentComp = FindComponentByClass<UMassAgentComponent>();
	if (!AgentComp) return;
	
	{
		FMassEntityHandle EntityHandle = AgentComp->GetEntityHandle();
		EntityManager->Defer().PushCommand<FMassDeferredSetCommand>([EntityHandle, bSet, VelocityX, VelocityY, VelocityZ](const FMassEntityManager& InManager)
		{
			if (!InManager.IsEntityValid(EntityHandle))
			{
				return;
			}
			if (FC7ApplyMovementFragment* C7ApplyMovementFragment =
				InManager.GetFragmentDataPtr<FC7ApplyMovementFragment>(EntityHandle))
			{
				C7ApplyMovementFragment->bAvailable = bSet;
				C7ApplyMovementFragment->VelocityX = VelocityX;
				C7ApplyMovementFragment->VelocityY = VelocityY;
				C7ApplyMovementFragment->VelocityZ = VelocityZ;
			}
		});
	}
}

void ACrowdNPCCharacter::DoReactingToPlayer()
{
	ChangeStateTreeStateTo(ETargetStateType::ENTER_REACTING);
}

void ACrowdNPCCharacter::FinishReactingToPlayer()
{
	ChangeStateTreeStateTo(ETargetStateType::LEAVE_REACTING);
}

void ACrowdNPCCharacter::SetActorHiddenInGame_L(bool bNewHidden)
{
	if (HiddenFromScript == bNewHidden)
		return;
	
	HiddenFromScript = bNewHidden;
	
	if (HiddenFromScript)
		Super::SetActorHiddenInGame(true);
	else
		Super::SetActorHiddenInGame(HiddenFromMass);
}

void ACrowdNPCCharacter::DestroyMassImmediate() const
{
	const FMassEntityManager* EntityManager = GetMassEntityManager();
	if (!EntityManager) return;
	
	const UMassAgentComponent* AgentComp = FindComponentByClass<UMassAgentComponent>();
	if (!AgentComp) return;
	
	if (UCrowdNpcControlSubsystem* CrowdNpcControlSubsystem = UWorld::GetSubsystem<UCrowdNpcControlSubsystem>(GetWorld()))
	{
		CrowdNpcControlSubsystem->MarkDeleteEntity(AgentComp->GetEntityHandle(), true);
	}
}

void ACrowdNPCCharacter::SetActorHiddenInGame(bool bNewHidden)
{
	if (HiddenFromMass == bNewHidden)
		return;
	
	HiddenFromMass = bNewHidden;
	
	if (HiddenFromScript)
		return;
	
	Super::SetActorHiddenInGame(HiddenFromMass);
}

void ACrowdNPCCharacter::StopStateTreeTasks()
{
	ChangeStateTreeStateTo(ETargetStateType::STOP_STATE_TREE_TASKS);
}

void ACrowdNPCCharacter::ChangeStateTreeStateTo(ETargetStateType TargetState)
{
	// Get subsystems
	const FMassEntityManager* EntityManager = GetMassEntityManager();
	if (!EntityManager) return;
	
	const UMassAgentComponent* AgentComp = FindComponentByClass<UMassAgentComponent>();
	if (!AgentComp) return;
	
	{
		FMassEntityHandle EntityHandle = AgentComp->GetEntityHandle();
		EntityManager->Defer().PushCommand<FMassDeferredSetCommand>([EntityHandle, TargetState](const FMassEntityManager& InManager)
			{
				if (!InManager.IsEntityValid(EntityHandle))
				{
					return;
				}
				if (FC7SwitchSTStateFragment* C7SwitchSTStateFragment =
					InManager.GetFragmentDataPtr<FC7SwitchSTStateFragment>(EntityHandle))
				{
					C7SwitchSTStateFragment->TargetState = TargetState;
				}
			});
	}
}

FMassEntityManager* ACrowdNPCCharacter::GetMassEntityManager() const
{
	UWorld* World = GetWorld();
	if (!World) return nullptr;
	FMassEntityManager* Manager = UE::Mass::Utils::GetEntityManager(World);
	if (!Manager)
	{
		UE_LOG(LogC7Mass, Warning, TEXT("Failed to get MassEntityManager in C7MassNPC") )
	}
	return Manager;
}

void ACrowdNPCCharacter::OnStartInteractWithSceneActor(int64 InsID, int64 SlotNum, float InteractTime) const
{
	ACrowdNPCCharacter* MutableThis = const_cast<ACrowdNPCCharacter*>(this);
	ACTOR_CALL_LUA_ENTITY(MutableThis, "KCB_OnStartInteractWithSceneActor", InsID, SlotNum, InteractTime);
}

void ACrowdNPCCharacter::OnFinishInteractWithSceneActor(int64 InsID) const
{
	ACrowdNPCCharacter* MutableThis = const_cast<ACrowdNPCCharacter*>(this);
	ACTOR_CALL_LUA_ENTITY(MutableThis, "KCB_OnFinishInteractWithSceneActor", InsID);
}

void ACrowdNPCCharacter::OnActorEnterTrigger(const FVector& TriggerPos, float TriggerRadius, const FString& InstanceID, ECrowdOverlapPointType Type) const
{
	ACrowdNPCCharacter* MutableThis = const_cast<ACrowdNPCCharacter*>(this);
	ACTOR_CALL_LUA_ENTITY(MutableThis, "KCB_OnActorEnterTrigger", TriggerPos, TriggerRadius, InstanceID, Type);
}

void ACrowdNPCCharacter::OnActorLeaveTrigger(const FVector& TriggerPos, float TriggerRadius, const FString& InstanceID, ECrowdOverlapPointType Type) const
{
	ACrowdNPCCharacter* MutableThis = const_cast<ACrowdNPCCharacter*>(this);
	ACTOR_CALL_LUA_ENTITY(MutableThis, "KCB_OnActorLeaveTrigger", TriggerPos, TriggerRadius, InstanceID, Type);
}
