// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#include "Fragments/CrowdAgentSyncStaticTransformTrait.h"
#include "MassAgentTraits.h"
#include "MassCommonFragments.h"
#include "MassCommonTypes.h"
#include "MassEntityTemplate.h"
#include "MassEntityTemplateRegistry.h"
#include "GameFramework/Actor.h"
#include "MassEntityView.h"

namespace FC7AgentTraitsHelper 
{
	template<typename T>
	T* AsComponent(UObject& Owner)
	{
		T* Component = nullptr;
		if (AActor* AsActor = Cast<AActor>(&Owner))
		{
			Component = AsActor->FindComponentByClass<T>();
		}
		else
		{
			Component = Cast<T>(&Owner);
		}

		UE_CVLOG_UELOG(Component == nullptr, &Owner, LogMass, Error, TEXT("Trying to extract %s from %s failed")
			, *T::StaticClass()->GetName(), *Owner.GetName());

		return Component;
	}
}

void UCrowdAgentSyncStaticTransformTrait::BuildTemplate(FMassEntityTemplateBuildContext& BuildContext, const UWorld& World) const
{
	BuildContext.AddFragment<FTransformFragment>();
	BuildContext.AddFragment<FAgentRadiusFragment>();
	
	BuildContext.GetMutableObjectFragmentInitializers().Add([Radius = Radius](UObject& Owner, FMassEntityView& EntityView, const EMassTranslationDirection CurrentDirection)
		{
			if (USceneComponent* SceneComponent = FC7AgentTraitsHelper::AsComponent<USceneComponent>(Owner))
			{
				FTransformFragment& TransformFragment = EntityView.GetFragmentData<FTransformFragment>();
				TransformFragment.GetMutableTransform() = SceneComponent->GetComponentTransform();
				FAgentRadiusFragment& RadiusFragment = EntityView.GetFragmentData<FAgentRadiusFragment>();
				if (Radius<0 || Radius>200)
				{
					UE_LOG(LogMass,Error,TEXT("UCrowdAgentSyncStaticTransformTrait Wrong input Radius:Radius=%f"),Radius);
					RadiusFragment.Radius = 40; 
				}else{
					RadiusFragment.Radius = Radius;
				}
			}
		});
}