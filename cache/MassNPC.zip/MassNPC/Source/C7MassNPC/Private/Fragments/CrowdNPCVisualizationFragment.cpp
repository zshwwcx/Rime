// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#include "Fragments/CrowdNPCVisualizationFragment.h"
#include "MassExecutionContext.h"
#include "MassCrowdRepresentationSubsystem.h"
#include "MassRepresentationTypes.h"
#include "MassRepresentationFragments.h"
#include "MassCrowdAnimationTypes.h"
#include "CrowdNPCCharacter.h"
#include "3C/RoleComposite/RoleCompositeManager.h"
#include "3C/Interactor/WorldManager.h"
#include "Engine/SkinnedAssetCommon.h"



UCrowdNPCVisualizationFragmentInitializer::UCrowdNPCVisualizationFragmentInitializer()
	: EntityQuery(*this)
{
	ObservedType = FCrowdNPCVisualizationFragment::StaticStruct();
	Operation = EMassObservedOperation::Add;
}

void UCrowdNPCVisualizationFragmentInitializer::ConfigureQueries() 
{
	EntityQuery.AddRequirement<FCrowdNPCVisualizationFragment>(EMassFragmentAccess::ReadWrite);
	EntityQuery.AddRequirement<FMassRepresentationFragment>(EMassFragmentAccess::ReadWrite);
	EntityQuery.AddRequirement<FCrowdAnimationFragment>(EMassFragmentAccess::ReadWrite);
}

void UCrowdNPCVisualizationFragmentInitializer::Execute(FMassEntityManager& EntityManager, FMassExecutionContext& Context)
{
	UMassCrowdRepresentationSubsystem* RepresentationSubsystem = UWorld::GetSubsystem<UMassCrowdRepresentationSubsystem>(EntityManager.GetWorld());
	TWeakObjectPtr<UMassCrowdRepresentationSubsystem> WeakRepresentationSubsystem = RepresentationSubsystem;
	EntityQuery.ForEachEntityChunk(EntityManager, Context, [WeakRepresentationSubsystem](FMassExecutionContext& Context)
	{
		if (WeakRepresentationSubsystem.IsValid())
		{
			const TArrayView<FCrowdNPCVisualizationFragment> VisualizationList = Context.GetMutableFragmentView<FCrowdNPCVisualizationFragment>();
			const TArrayView<FMassRepresentationFragment> RepresentationList = Context.GetMutableFragmentView<FMassRepresentationFragment>();
			const TArrayView<FCrowdAnimationFragment> AnimationDataList = Context.GetMutableFragmentView<FCrowdAnimationFragment>();
            auto world = WeakRepresentationSubsystem->GetWorld();
			const int32 NumEntities = Context.GetNumEntities();
			for (int32 i = 0; i < NumEntities; ++i)
			{
				if (const TSubclassOf<AActor> TemplateActorClass = WeakRepresentationSubsystem->GetTemplateActorClass(RepresentationList[i].HighResTemplateActorIndex))
				{
					// Try to get the data asset from the crowd character CDO
					if(const ACrowdNPCCharacter* CrowdCharacter = Cast<ACrowdNPCCharacter>(TemplateActorClass->GetDefaultObject()))
					{
						if (UWorldManager* WorldMgr = UWorldManager::GetInstance(world))
						{
							// Set CrowdAnimationFragment's AnimToTextureData From Character's Setting
							AnimationDataList[i].AnimToTextureData = CrowdCharacter->AnimToTextureData;
							// Set FCrowdNPCVisualizationFragment's ColorData From Character's Setting
							TArray<FString> SuitLibData = WorldMgr->RandomCrowdNPCSuitData(CrowdCharacter->Rank, CrowdCharacter->BodyType);
                            auto num = SuitLibData.Num();
						    if (num >= 1)
						    {
						        VisualizationList[i].SuitLibKey = SuitLibData[0];
						        FLinearColor UpperColor = FLinearColor::Gray;
                                FLinearColor LowerColor = FLinearColor::Gray;
						        if (num >= 2)
						        {
                                    auto npcAssetKey = SuitLibData[1];
                                    URoleCompositeMgr::GetInstance(world)->GetNPCUpperAndLowerBodyColor(*npcAssetKey,UpperColor,LowerColor);
                                }
                                constexpr float ScaleRGB = 0.8f;
						        auto bodyColor = UpperColor.ToFColor(true);
						        auto lowerColor = LowerColor.ToFColor(true);
                                bodyColor.R *=ScaleRGB;
                                bodyColor.G *=ScaleRGB;
                                bodyColor.B *=ScaleRGB;
                                lowerColor.R *=ScaleRGB;
                                lowerColor.G *=ScaleRGB;
                                lowerColor.B *=ScaleRGB;
                                VisualizationList[i].SuitLibBodyColor = bodyColor;
                                VisualizationList[i].SuitLibLowerColor = lowerColor;
						    }
						    
						}
					}
				}
			}
		}
	});
}

UAnimToTextureDataAsset* UCrowdNPCVisualizationFragmentInitializer::GetAnimToTextureDataAsset(TSoftObjectPtr<UAnimToTextureDataAsset> SoftPtr)
{
	if (SoftPtr.IsNull())
	{
		return nullptr;
	}

	if (SoftPtr.IsValid())
	{ 
		return SoftPtr.Get();
	}

	{
		QUICK_SCOPE_CYCLE_COUNTER(STAT_CrowdNPCVisualizationFragmentInitializer_GetAnimToTextureDataAsset_LoadSync);
		return SoftPtr.LoadSynchronous();
	}
}
