// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: pengqi05@kuaishou.com
#if WITH_EDITOR
#include "EditorTools/C7MassNPCEditorToolsFuncLibrary.h"
#include "EngineUtils.h"
#include "GameFramework/Actor.h"
#include "CoreMinimal.h"
#include "Engine/World.h"
#include "Editor.h"
#include "ZoneShapeActor.h"
#include "ZoneShapeComponent.h"
#include "Kismet/KismetSystemLibrary.h"

static int32 StikeGroundCvar = 0;
static FAutoConsoleVariableRef C7ZoneShapeStikeGroundCvar(
	TEXT("C7MassNPC.SetZoneShapesStikeGround"),
	StikeGroundCvar,
	TEXT(""),
	FConsoleVariableDelegate::CreateStatic(C7MassNPCEditorTools::SetZoneShapesStickGround)
);

namespace C7MassNPCEditorTools
{
	void SetZoneShapesStickGround(IConsoleVariable* Var)
	{
		UWorld* World = GWorld;
		if (World == nullptr || World->WorldType != EWorldType::Editor)
		{
			FString Message = TEXT("执行失败，游戏已启动，请先退出！");
			FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(Message));
			return;
		}
		TArray<AActor*> ActorsToIgnore;
		const FScopedTransaction transaction(FText::FromString("ZoneShapesStickGround"));
		for (TActorIterator<AActor> ActorItr(World); ActorItr; ++ActorItr)
		{
			AActor* CurrentActor = *ActorItr;
			if (AZoneShape* CurZoneShapeActor = Cast<AZoneShape>(CurrentActor))
			{
				TArray<UActorComponent*> Components = CurZoneShapeActor->K2_GetComponentsByClass(UZoneShapeComponent::StaticClass());
				for (UActorComponent* ActorComp : Components)
				{
					if (UZoneShapeComponent* ZoneShapeComp = Cast<UZoneShapeComponent>(ActorComp))
					{
						ZoneShapeComp->Modify();
						const FTransform& CompTransform = ZoneShapeComp->GetComponentTransform();
						TArray<FZoneShapePoint>& Points = const_cast<UZoneShapeComponent*>(ZoneShapeComp)->GetMutablePoints();
						for (FZoneShapePoint& Point : Points)
						{
							// 只需处理position贴地即可
							FVector PointLocation = CompTransform.TransformPosition(Point.Position);

							FHitResult OutHit;
							// 向下贴地
							bool bResult = UKismetSystemLibrary::LineTraceSingle(
								CurZoneShapeActor, PointLocation, PointLocation - FVector(0, 0, 1000),
								UEngineTypes::ConvertToTraceType(ECC_WorldStatic), false, ActorsToIgnore, EDrawDebugTrace::None, OutHit, true,
								FLinearColor::Red, FLinearColor::Green, 0.2f);
							if (bResult && OutHit.IsValidBlockingHit())
							{
								Point.Position = CompTransform.InverseTransformPosition(OutHit.Location);
							}
						}
						const_cast<UZoneShapeComponent*>(ZoneShapeComp)->UpdateShape();
					}
				}
			}
		}
		GEditor->RedrawLevelEditingViewports(true);
		FString Message = TEXT("执行成功！");
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(Message));
	}
}
#endif

