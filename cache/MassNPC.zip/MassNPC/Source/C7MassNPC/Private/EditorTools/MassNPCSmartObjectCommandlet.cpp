// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: pengqi05@kuaishou.com

#if WITH_EDITOR

#include "EditorTools/MassNPCSmartObjectCommandlet.h"
#include "Interfaces/IPluginManager.h"
#include "AssetRegistry/IAssetRegistry.h"
#include "Engine/AssetManager.h"
#include "FileHelpers.h"
#include "ZoneGraphDelegates.h"
#include "ZoneGraphSubsystem.h"
#include "EditorWorldUtils.h"
#include "SmartObjectSubsystem.h"
#include "SmartObjectPersistentCollection.h"
#include "EngineUtils.h"
#include "SmartObjectZoneAnnotations.h"
#include "WorldPartition/WorldPartitionBuilder.h"
#include "WorldPartitionSmartObjectCollectionBuilder.h"
#include "UObject/GCObjectScopeGuard.h"
#include "ISourceControlModule.h"
#include "UObject/SavePackage.h"
#include "UnrealExporter.h"

DEFINE_LOG_CATEGORY_STATIC(LogMassNPCSmartObjectCommandlet, All, All);

// Param start
const FString UMassNPCSmartObjectCommandlet::PARAM_TARGET_ASSET_PATH = TEXT("TargetAsset");
// Param end

int32 UMassNPCSmartObjectCommandlet::Main(const FString& Params)
{
	// 参数举例：-run=MassNPC -TargetAsset=/Game/Arts/Maps/Startplace/LV_Startplace_P
	if (!SplitParams(ParamsMap, Params))
	{
		UE_LOG(LogMassNPCSmartObjectCommandlet, Error, TEXT("split params error, params = %s"), *Params)
		return 1;
	}
	return RunCommandlet();
}

int32 UMassNPCSmartObjectCommandlet::RunCommandlet()
{
	FString* TargetAssetPath = ParamsMap.Find(PARAM_TARGET_ASSET_PATH);
	if (TargetAssetPath == nullptr)
	{
		UE_LOG(LogMassNPCSmartObjectCommandlet, Error, TEXT("run commandlet error, params %s not exist"), *PARAM_TARGET_ASSET_PATH)
		return 1;
	}

	UPackage* WorldPackage = LoadWorldPackageForEditor(*TargetAssetPath);
	if (WorldPackage == nullptr)
	{
		UE_LOG(LogMassNPCSmartObjectCommandlet, Error, TEXT("load asset error, path = %s"), **TargetAssetPath)
		return 1;
	}

	// Find the world in the given package
	UWorld* NewWorld = UWorld::FindWorldInPackage(WorldPackage);
	if (!NewWorld)
	{
		UE_LOG(LogMassNPCSmartObjectCommandlet, Error, TEXT("No world in specified package %s."), **TargetAssetPath);
		return 1;
	}

	// init world.
	if (GWorld)
	{
		GWorld->DestroyWorld(true, NewWorld);
	}

	TArray<UPackage*> PreSavePackages;

	// 世界分区地图
	if (NewWorld->IsPartitionedWorld())
	{
		if (!BuildWorldPartitionSOCollection(NewWorld) || !BuildWorldPartitionSOZoneAnotation(NewWorld, PreSavePackages))
		{
			for (UPackage* Package : PreSavePackages)
			{
				FSavePackageArgs SaveArgs;
				SaveArgs.TopLevelFlags = RF_Standalone;
				FString PackageFileName = SourceControlHelpers::PackageFilename(Package);
				if (!UPackage::SavePackage(Package, nullptr, *PackageFileName, SaveArgs))
				{
					UE_LOG(LogMassNPCSmartObjectCommandlet, Error, TEXT("Error saving package %s."), *Package->GetName());
					return 1;
				}
			}
			return 0;
		}
		return 1;
	}
	
	// 非世界分区地图
	UWorld::InitializationValues IVS;
	IVS.RequiresHitProxies(false);
	IVS.ShouldSimulatePhysics(false);
	IVS.EnableTraceCollision(false);
	IVS.CreateNavigation(false);
	IVS.CreateAISystem(false);
	IVS.AllowAudioPlayback(false);
	IVS.CreatePhysicsScene(true);

	FScopedEditorWorld ScopeEditorWorld(NewWorld, IVS);
	PreSavePackages.Add(WorldPackage->GetPackage());

	if (!RebuildSmartObjectCollectionInLevel(NewWorld) || !RebuildSOZoneAnotationsInLevel(NewWorld))
	{
		return 1;
	}

	bool bSuccess = UEditorLoadingAndSavingUtils::SavePackages(PreSavePackages, true);
	return !bSuccess;
}

bool UMassNPCSmartObjectCommandlet::SplitParams(TMap<FString, FString>& Map, const FString& Params)
{
	TArray<FString> Tokens;
	Params.ParseIntoArray(Tokens, TEXT(" "), true);
	for (const FString& Token : Tokens)
	{
		FString Key;
		FString Value;
		if (Token.Split(TEXT("="), &Key, &Value))
		{
			Key.RemoveFromStart(TEXT("-"));
			Map.Add(Key, Value);
		}
		else
		{
			// error
			return false;
		}
	}
	return true;
}

bool UMassNPCSmartObjectCommandlet::RebuildSmartObjectCollectionInLevel(UWorld* World)
{
	if (USmartObjectSubsystem* SmartObjectSubsystem = UWorld::GetSubsystem<USmartObjectSubsystem>(World))
	{
		// 找到SmartObjectCollection
		for (TActorIterator<ASmartObjectPersistentCollection> It(World); It; ++It)
		{
			ASmartObjectPersistentCollection* SOCollection = (*It);
			if (SOCollection != nullptr)
			{
				UFunction* Function = SOCollection->FindFunction("RebuildCollection");
				if (Function)
				{
					SOCollection->ProcessEvent(Function, nullptr);
					UE_LOG(LogMassNPCSmartObjectCommandlet, Log, TEXT("rebuild smart object collection success."));
					return true;
				}
			}
		}
		UE_LOG(LogMassNPCSmartObjectCommandlet, Error, TEXT("No smart object collection actor in current world."));
		return false;
	}

	UE_LOG(LogMassNPCSmartObjectCommandlet, Error, TEXT("Smart object subsystem is null."));
	return false;
}

bool UMassNPCSmartObjectCommandlet::RebuildSOZoneAnotationsInLevel(UWorld* World)
{
	for (TActorIterator<AActor> It(World); It; ++It)
	{
		AActor* Actor = (*It);
		if (Actor != nullptr)
		{
			if (USmartObjectZoneAnnotations* SOZoneAnotationsComponent = Actor->GetComponentByClass<USmartObjectZoneAnnotations>())
			{
				SOZoneAnotationsComponent->RebuildForAllGraphs();
				UE_LOG(LogMassNPCSmartObjectCommandlet, Log, TEXT("rebuild SOZoneAnotations success."));
				return true;
			}
		}
	}
	UE_LOG(LogMassNPCSmartObjectCommandlet, Log, TEXT("rebuild SOZoneAnotations fail."));
	return false;
}

bool UMassNPCSmartObjectCommandlet::BuildWorldPartitionSOCollection(UWorld* World)
{
	// 世界分区地图SOCollection用官方提供的builder
	UWorldPartitionBuilder* SOCollectionBuilder = NewObject<UWorldPartitionBuilder>(
		GetTransientPackage(),
		UWorldPartitionSmartObjectCollectionBuilder::StaticClass());
	if (!SOCollectionBuilder)
	{
		UE_LOG(LogMassNPCSmartObjectCommandlet, Error, TEXT("Failed to create builder."));
		return false;
	}
	FGCObjectScopeGuard BuilderGuard(SOCollectionBuilder);
	bool bResult = SOCollectionBuilder->RunBuilder(World);
	if (!bResult)
	{
		UE_LOG(LogMassNPCSmartObjectCommandlet, Error, TEXT("Failed to run builder."));
		return false;
	}
	UE_LOG(LogMassNPCSmartObjectCommandlet, Log, TEXT("Success to run builder."));
	return true;
}

bool UMassNPCSmartObjectCommandlet::BuildWorldPartitionSOZoneAnotation(UWorld* World, TArray<UPackage*>& SavePackages)
{
	for (TActorIterator<AActor> It(World); It; ++It)
	{
		AActor* Actor = (*It);
		if (Actor != nullptr)
		{
			if (USmartObjectZoneAnnotations* SOZoneAnotationsComponent = Actor->GetComponentByClass<USmartObjectZoneAnnotations>())
			{
				SOZoneAnotationsComponent->RebuildForAllGraphs();
				UE_LOG(LogMassNPCSmartObjectCommandlet, Log, TEXT("rebuild SOZoneAnotations success."));
				SavePackages.Add(Actor->GetPackage());
				return true;
			}
		}
	}
	UE_LOG(LogMassNPCSmartObjectCommandlet, Log, TEXT("rebuild SOZoneAnotations fail."));
	return false;
}
#endif