// Fill out your copyright notice in the Description page of Project Settings.


#include "Traits/C7MassStateTreeTrait.h"
#include "MassStateTreeFragments.h"
#include "MassStateTreeSubsystem.h"
#include "MassAIBehaviorTypes.h"
#include "StateTree.h"
#include "VisualLogger/VisualLogger.h"
#include "MassEntityTemplateRegistry.h"
#include "Engine/World.h"
#include "MassEntityUtils.h"
#include "Subsystems/CrowdNpcControlSubsystem.h"


void UC7MassStateTreeTrait::BuildTemplate(FMassEntityTemplateBuildContext& BuildContext, const UWorld& World) const
{
	FMassEntityManager& EntityManager = UE::Mass::Utils::GetEntityManagerChecked(World);

	UMassStateTreeSubsystem* MassStateTreeSubsystem = World.GetSubsystem<UMassStateTreeSubsystem>();
	UCrowdNpcControlSubsystem* CrowdNpcControlSubsystem = World.GetSubsystem<UCrowdNpcControlSubsystem>();
	if (!CrowdNpcControlSubsystem)
	{
		return;
	}
	if (!MassStateTreeSubsystem && !BuildContext.IsInspectingData())
	{
		UE_VLOG(&World, LogMassBehavior, Error, TEXT("Failed to get Mass StateTree Subsystem."));
		return;
	}

	if (!StateTree && !BuildContext.IsInspectingData())
	{
		UE_VLOG(MassStateTreeSubsystem, LogMassBehavior, Error, TEXT("StateTree asset is not set or unavailable."));
		return;
	}
	if (StateTree != nullptr && !BuildContext.IsInspectingData() && !StateTree->IsReadyToRun())
	{
		UE_VLOG(MassStateTreeSubsystem, LogMassBehavior, Error, TEXT("StateTree asset is ready to run."));
		return;
	}

	FMassStateTreeSharedFragment SharedStateTree;
	if (CrowdNpcControlSubsystem->GetUseLowStateTree())
	{
		SharedStateTree.StateTree = LowStateTree;
	}
	else
	{
		SharedStateTree.StateTree = StateTree;
	}

	const FConstSharedStruct StateTreeFragment = EntityManager.GetOrCreateConstSharedFragment(SharedStateTree);
	BuildContext.AddConstSharedFragment(StateTreeFragment);

	BuildContext.AddFragment<FMassStateTreeInstanceFragment>();
}