// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#include "Traits/C7MassAgentCapsuleCollisionSyncTrait.h"

#include "MassEntityTemplateRegistry.h"
#include "MassEntityView.h"
#include "Components/CapsuleComponent.h"
#include "Translators/MassCapsuleComponentTranslators.h"

void UC7MassAgentCapsuleCollisionSyncTrait::BuildTemplate(FMassEntityTemplateBuildContext& BuildContext, const UWorld& World) const
{
	BuildContext.AddFragment<FCapsuleComponentWrapperFragment>();
	BuildContext.AddFragment<FAgentRadiusFragment>();
	if (bSyncTransform || BuildContext.IsInspectingData())
	{
		BuildContext.AddFragment<FTransformFragment>();
	}
	
	BuildContext.GetMutableObjectFragmentInitializers().Add(
		[bSyncTransform = bSyncTransform, ConstRadius = ConstRadius](UObject& Owner, FMassEntityView& EntityView, const EMassTranslationDirection CurrentDirection)
		{
			AActor* Actor = Cast<AActor>(&Owner);
			if (!IsValid(Actor))
				return;
			
			if (UCapsuleComponent* CapsuleComponent = Actor->FindComponentByClass<UCapsuleComponent>())
			{
				FCapsuleComponentWrapperFragment& CapsuleFragment = EntityView.GetFragmentData<FCapsuleComponentWrapperFragment>();
				CapsuleFragment.Component = CapsuleComponent;

				if (bSyncTransform)
				{
					FTransformFragment& TransformFragment = EntityView.GetFragmentData<FTransformFragment>();
					TransformFragment.GetMutableTransform() = CapsuleComponent->GetComponentTransform();
				}
				
				FAgentRadiusFragment& RadiusFragment = EntityView.GetFragmentData<FAgentRadiusFragment>();
				RadiusFragment.Radius = CapsuleComponent->GetScaledCapsuleRadius();
				
				if (ConstRadius > 0)
				{
					RadiusFragment.Radius = ConstRadius;
				}
			}
			
		}
	);
	
	if (bSyncTransform || BuildContext.IsInspectingData())
	{
		if (EnumHasAnyFlags(SyncDirection, EMassTranslationDirection::ActorToMass) || BuildContext.IsInspectingData())
		{
			BuildContext.AddTranslator<UMassCapsuleTransformToMassTranslator>();
		}

		if (EnumHasAnyFlags(SyncDirection, EMassTranslationDirection::MassToActor) || BuildContext.IsInspectingData())
		{
			BuildContext.AddTranslator<UMassTransformToActorCapsuleTranslator>();
		}
	}
	
}
