// Fill out your copyright notice in the Description page of Project Settings.


#include "Traits/C7MassMovementTrait.h"
#include "SubSystems/CrowdNpcControlSubsystem.h"


void UC7MassMovementTrait::BuildTemplate(FMassEntityTemplateBuildContext& BuildContext, const UWorld& World) const
{
	if (UCrowdNpcControlSubsystem* CrowdNpcControlSubsystem = UWorld::GetSubsystem<UCrowdNpcControlSubsystem>(&World))
	{
		const FMassNPCMovementData* MovementData = CrowdNpcControlSubsystem->GetNPCMovementDataByType(Rank + BodyType);
		if (MovementData != nullptr)
		{
			UC7MassMovementTrait* MutableThis = const_cast<UC7MassMovementTrait*>(this);
			MutableThis->Movement.MaxSpeed = MovementData->MaxSpeed;
			MutableThis->Movement.DefaultDesiredSpeed = MovementData->WalkSpeed;
		}
	}
	Super::BuildTemplate(BuildContext, World);
}
