// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#include "Processors/CrowdStuckCheckProcessor.h"
#include "MassCommonTypes.h"
#include "MassNavigationFragments.h"
#include "MassRepresentationFragments.h"
#include "MassActorSubsystem.h"
#include "MassExecutionContext.h"
#include "MassEntityView.h"
#include "CrowdNPCCharacter.h"
#include "MassAgentComponent.h"

namespace UE::MassCrowd
{
	float GCrowdStuckThreshold = 30.f;
	FAutoConsoleVariableRef CVarCrowdStuckThreshold(TEXT("Mass.CrowdStuckThreshold"), GCrowdStuckThreshold, TEXT("movetarget duration threshold that entity will be considered as stucked"));

	float GLTTCrowdStuckThreshold = 60.f;
	FAutoConsoleVariableRef CVarCrowdStuckThresholdForLTT(TEXT("Mass.LongTimeTaskCrowdStuckThreshold"), GLTTCrowdStuckThreshold,
		TEXT("movetarget duration threshold that entity will be considered as stucked with FLongTimeTaskTag"));
}

UCrowdStuckCheckProcessor::UCrowdStuckCheckProcessor()
: EntityQuery(*this)
{
	bAutoRegisterWithProcessingPhases = true;
	bRequiresGameThreadExecution = true;
	ProcessingPhase = EMassProcessingPhase::PostPhysics;
	ExecutionOrder.ExecuteInGroup = UE::Mass::ProcessorGroupNames::Tasks;
	ExecutionOrder.ExecuteAfter.Add(UE::Mass::ProcessorGroupNames::Movement);
}

void UCrowdStuckCheckProcessor::ConfigureQueries()
{
	EntityQuery.AddRequirement<FMassRepresentationFragment>(EMassFragmentAccess::ReadOnly);
	EntityQuery.AddRequirement<FMassMoveTargetFragment>(EMassFragmentAccess::ReadOnly);
	EntityQuery.AddTagRequirement<FMassHighLODTag>(EMassFragmentPresence::Any);
	EntityQuery.AddTagRequirement<FMassMediumLODTag>(EMassFragmentPresence::Any);
}

void UCrowdStuckCheckProcessor::Initialize(UObject& InOwner)
{
	Super::Initialize(InOwner);

	CrowdNpcControlSubsystem = UWorld::GetSubsystem<UCrowdNpcControlSubsystem>(InOwner.GetWorld());
}

void UCrowdStuckCheckProcessor::Execute(FMassEntityManager& EntitySubSystem, FMassExecutionContext& Context)
{
	UCrowdNpcControlSubsystem* CrowdNpcControlSubSys = CrowdNpcControlSubsystem.Get();
	if (!CrowdNpcControlSubSys)
	{
		return;
	}
	
	double TimePassed = Context.GetWorld()->GetTimeSeconds();
	EntityQuery.ForEachEntityChunk(EntitySubSystem, Context, [&EntitySubSystem, &TimePassed, &CrowdNpcControlSubSys](FMassExecutionContext& Context)
	{
		const TConstArrayView<FMassMoveTargetFragment> MoveTargetList = Context.GetFragmentView<FMassMoveTargetFragment>();
		const int32 NumEntities = Context.GetNumEntities();
		TArray<FMassEntityHandle> DeleteEntities;
		for (int32 EntityIdx = 0; EntityIdx < NumEntities; EntityIdx++)
		{
			const FMassEntityHandle MassAgentEntityHandle = Context.GetEntity(EntityIdx);
			FMassEntityView EntityView(EntitySubSystem, MassAgentEntityHandle);
			float StuckCheckThreshold;
			if (EntityView.HasTag<FLongTimeTaskTag>())
				// 这是一个长时间的Task, 给更多的容忍
				StuckCheckThreshold = UE::MassCrowd::GLTTCrowdStuckThreshold;
			else
				StuckCheckThreshold = UE::MassCrowd::GCrowdStuckThreshold;

			FMassMoveTargetFragment MoveTargetFragment = MoveTargetList[EntityIdx];
			const EMassMovementAction CurrentAction = MoveTargetFragment.GetCurrentAction();
			const double CurrentActionStartTime = MoveTargetFragment.GetCurrentActionStartTime();
			if (CurrentAction == EMassMovementAction::Move && CurrentActionStartTime > 0)
			{
				if ((TimePassed - CurrentActionStartTime > StuckCheckThreshold) && MoveTargetFragment.bSteeringFallingBehind)
				{
					const FMassActorFragment& ActorFragment = EntityView.GetFragmentData<FMassActorFragment>();
					if (!ActorFragment.IsOwnedByMass())
					{
						continue;
					}
					if (const ACrowdNPCCharacter* CrowdCharacter = Cast<ACrowdNPCCharacter>(ActorFragment.Get()))
					{
						EntitySubSystem.Defer().AddTag<FCanDirectDeleteTag>(MassAgentEntityHandle);
						DeleteEntities.Add(MassAgentEntityHandle);
						// UE_LOG(LogTemp, Display, TEXT("UCrowdStuckCheckProcessor::DestroyEntity => SuitLibKey:%s"), *CrowdCharacter->SuitLibKey);
					}
				}
			}
		}
		CrowdNpcControlSubSys->MarkDeleteEntities(DeleteEntities);
	});
}
