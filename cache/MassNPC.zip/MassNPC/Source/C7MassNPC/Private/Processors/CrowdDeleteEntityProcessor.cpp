// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#include "Processors/CrowdDeleteEntityProcessor.h"

#include "MassCommonTypes.h"
#include "MassRepresentationFragments.h"
#include "MassRepresentationTypes.h"
#include "MassEntityView.h"
#include "SubSystems/CrowdNpcControlSubsystem.h"
#include "Fragments/C7SwitchSTStateFragment.h"

UCrowdDeleteEntityProcessor::UCrowdDeleteEntityProcessor()
: EntityQuery(*this)
{
	bAutoRegisterWithProcessingPhases = true;
	bRequiresGameThreadExecution = true;
	ProcessingPhase = EMassProcessingPhase::PostPhysics;
	ExecutionOrder.ExecuteInGroup = UE::Mass::ProcessorGroupNames::Tasks;
	ExecutionOrder.ExecuteAfter.Add(UE::Mass::ProcessorGroupNames::Representation);
}

void UCrowdDeleteEntityProcessor::ConfigureQueries()
{
	EntityQuery.AddRequirement<FC7SwitchSTStateFragment>(EMassFragmentAccess::ReadWrite);
	EntityQuery.AddRequirement<FMassRepresentationFragment>(EMassFragmentAccess::ReadOnly);
	EntityQuery.AddTagRequirement<FToBeDeleteTag>(EMassFragmentPresence::All);
}

void UCrowdDeleteEntityProcessor::Initialize(UObject& InOwner)
{
	Super::Initialize(InOwner);

	CrowdDeleteEntitySubsystem = UWorld::GetSubsystem<UCrowdNpcControlSubsystem>(InOwner.GetWorld());
}

void UCrowdDeleteEntityProcessor::Execute(FMassEntityManager& EntitySubSystem, FMassExecutionContext& Context)
{
	UCrowdNpcControlSubsystem* DeleteSubSys = CrowdDeleteEntitySubsystem.Get();
	if (!DeleteSubSys)
	{
		return;
	}
	TSet<FMassEntityHandle>& ToBeDeleteEntities = DeleteSubSys->GetToBeDeleteEntities();
	if (ToBeDeleteEntities.Num()<=0)
	{
		return;
	}
	TArray<FMassEntityHandle> DeleteEntities;
	// Check entities representation, only destroy entity matches EMassRepresentationType::None
	EntityQuery.ForEachEntityChunk(EntitySubSystem, Context, [&DeleteEntities,&ToBeDeleteEntities,&DeleteSubSys,&EntitySubSystem](FMassExecutionContext& Context)
	{
		const TConstArrayView<FMassRepresentationFragment> RepresentationList = Context.GetFragmentView<FMassRepresentationFragment>();
		const TArrayView<FC7SwitchSTStateFragment> C7SwitchSTStateFragment = Context.GetMutableFragmentView<FC7SwitchSTStateFragment>();
		const int32 NumEntities = Context.GetNumEntities();
		
		for (int32 EntityIdx = 0; EntityIdx < NumEntities; EntityIdx++)
		{
			const FMassEntityHandle MassAgentEntityHandle = Context.GetEntity(EntityIdx);
			if (!ToBeDeleteEntities.Contains(MassAgentEntityHandle))
				continue;
			
			FC7SwitchSTStateFragment& C7SwitchSTState = C7SwitchSTStateFragment[EntityIdx];
			FMassEntityView EntityView(EntitySubSystem, MassAgentEntityHandle);
			if (RepresentationList[EntityIdx].CurrentRepresentation == EMassRepresentationType::None || EntityView.HasTag<FCanDirectDeleteTag>())
			{
				DeleteEntities.Add(MassAgentEntityHandle);
			}
			// lizhang@kuaishou.com Find Dead Point性能太差，策划也没配，先禁用
			// else if(!EntityView.HasTag<FGoToDeadZoneTag>())
			// {
			// 	//只能设一次，否则一直发信号给statetree了
			// 	Context.Defer().AddTag<FGoToDeadZoneTag>(MassAgentEntityHandle);
			// 	C7SwitchSTState.TargetState = ETargetStateType::GO_TO_DEAD_POINT;
			// }
		}
	});
	if (DeleteEntities.Num() > 0)
	{
		Context.Defer().DestroyEntities(DeleteEntities);
		DeleteSubSys->OnEntitiesDeleted(DeleteEntities);
	}
}
