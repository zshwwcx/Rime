// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#include "Processors/C7AreaCrowdProportionProcessor.h"

#include "MassCrowdFragments.h"
#include "MassExecutionContext.h"
#include "MassZoneGraphNavigationFragments.h"
#include "ZoneGraphSubsystem.h"
#include "SubSystems/CrowdNpcControlSubsystem.h"
#include "MassSignalSubsystem.h"

UC7AreaCrowdProportionProcessor::UC7AreaCrowdProportionProcessor()
: EntityQuery(*this)
{
	bAutoRegisterWithProcessingPhases = true;
	bRequiresGameThreadExecution = true;
}

void UC7AreaCrowdProportionProcessor::Initialize(UObject& Owner)
{
	Super::Initialize(Owner);

	UWorld* World = Owner.GetWorld();
	if (!ensure(World))
		return;
	
	if (UCrowdNpcControlSubsystem* CrowdNpcControlSubsystem = UWorld::GetSubsystem<UCrowdNpcControlSubsystem>(GetWorld()))
	{
		ValidAreaTag = CrowdNpcControlSubsystem->ValidAreaTags;
	}

	if (UMassSignalSubsystem* SignalSubsystem = UWorld::GetSubsystem<UMassSignalSubsystem>(Owner.GetWorld()))
		SubscribeToSignal(*SignalSubsystem, UE::Mass::Signals::CurrentLaneChanged);
}

void UC7AreaCrowdProportionProcessor::ConfigureQueries()
{
	EntityQuery.AddRequirement<FMassZoneGraphLaneLocationFragment>(EMassFragmentAccess::ReadOnly);
}

void UC7AreaCrowdProportionProcessor::Execute(FMassEntityManager& EntityManager, FMassExecutionContext& Context)
{
	if (DirtyEntities.IsEmpty())
		return;
	
	UCrowdNpcControlSubsystem* CrowdNpcControlSubsystem = UWorld::GetSubsystem<UCrowdNpcControlSubsystem>(GetWorld());
	if (!CrowdNpcControlSubsystem)
		return;

	TArray<FMassArchetypeEntityCollection> EntityCollectionsToTest;
	UE::Mass::Utils::CreateEntityCollections(EntityManager, DirtyEntities, FMassArchetypeEntityCollection::NoDuplicates, EntityCollectionsToTest);
	Context.ClearEntityCollection();
	
	EntityQuery.ForEachEntityChunkInCollections(EntityCollectionsToTest, EntityManager, Context, [this, CrowdNpcControlSubsystem](FMassExecutionContext& Context)
	{
		const TConstArrayView<FMassZoneGraphLaneLocationFragment>& LaneFragments = Context.GetFragmentView<FMassZoneGraphLaneLocationFragment>();
		const UZoneGraphSubsystem* ZoneGraphSubsystem = UWorld::GetSubsystem<UZoneGraphSubsystem>(Context.GetWorld());;
		if (!ZoneGraphSubsystem)
			return;
		
		const int32 NumEntities = Context.GetNumEntities();
		for (int32 EntityIndex = 0; EntityIndex < NumEntities; ++EntityIndex)
		{
			const FZoneGraphLaneHandle& LaneHandle = LaneFragments[EntityIndex].LaneHandle;
			const FZoneGraphStorage* ZoneGraphStorage = ZoneGraphSubsystem->GetZoneGraphStorage(LaneHandle.DataHandle);
			if (!ZoneGraphStorage)
				continue;

			if (ZoneGraphStorage->Lanes.IsValidIndex(LaneHandle.Index))
			{
				const FZoneLaneData& Lane = ZoneGraphStorage->Lanes[LaneHandle.Index];

				const int32 AreaTag = 31 - FMath::CountLeadingZeros(ValidAreaTag & Lane.Tags.GetValue());
				if (AreaTag <= 0)
					continue;

				const FMassEntityHandle& Entity = Context.GetEntity(EntityIndex);
				CrowdNpcControlSubsystem->RecordAreaOnEntityLaneChanged(Entity, AreaTag);
			}
		}
	});

	DirtyEntities.Reset();
}

void UC7AreaCrowdProportionProcessor::OnSignalReceived(FName SignalName, TConstArrayView<FMassEntityHandle> Entities)
{
	if (SignalName == UE::Mass::Signals::CurrentLaneChanged)
	{
		DirtyEntities.Append(Entities);
	}
}
