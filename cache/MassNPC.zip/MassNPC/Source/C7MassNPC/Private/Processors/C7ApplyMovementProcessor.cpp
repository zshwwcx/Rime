// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: luyilong@kuaishou.com

#include "Processors/C7ApplyMovementProcessor.h"
#include "Fragments/C7ApplyMovementFragment.h"
#include "MassCommonTypes.h"
#include "MassMovementFragments.h"
#include "MassRepresentationFragments.h"
#include "MassNavigationUtils.h"


UC7ApplyMovementProcessor::UC7ApplyMovementProcessor()
: EntityQuery(*this)
{
	bAutoRegisterWithProcessingPhases = true;
	bRequiresGameThreadExecution = true;
	ExecutionOrder.ExecuteInGroup = UE::Mass::ProcessorGroupNames::PostMovement;
	ExecutionOrder.ExecuteAfter.Add(UE::Mass::ProcessorGroupNames::Movement);
	ExecutionOrder.ExecuteBefore.Add(UE::Mass::ProcessorGroupNames::UpdateWorldFromMass);
}

void UC7ApplyMovementProcessor::ConfigureQueries()
{
	EntityQuery.AddRequirement<FC7ApplyMovementFragment>(EMassFragmentAccess::ReadWrite);
	EntityQuery.AddRequirement<FMassVelocityFragment>(EMassFragmentAccess::ReadWrite);
	EntityQuery.AddConstSharedRequirement<FMassMovementParameters>(EMassFragmentPresence::All);
}

void UC7ApplyMovementProcessor::Initialize(UObject& InOwner)
{
	Super::Initialize(InOwner);
}

void UC7ApplyMovementProcessor::Execute(FMassEntityManager& EntitySubSystem, FMassExecutionContext& Context)
{
	// Check entities representation, only clear TimedBehaviorFragment.UseTime with Tag FDeActiveC7SmartObjectMassInteractionTag
	EntityQuery.ForEachEntityChunk(EntitySubSystem, Context, [](FMassExecutionContext& Context)
	{
		const int32 NumEntities = Context.GetNumEntities();
		const TArrayView<FC7ApplyMovementFragment> C7ApplyMovementList = Context.GetMutableFragmentView<FC7ApplyMovementFragment>();
		const TArrayView<FMassVelocityFragment> VelocityList = Context.GetMutableFragmentView<FMassVelocityFragment>();
		const FMassMovementParameters& MovementParams = Context.GetConstSharedFragment<FMassMovementParameters>();
		const FVector::FReal MaximumSpeed = MovementParams.MaxSpeed;
		for (int32 EntityIdx = 0; EntityIdx < NumEntities; EntityIdx++)
		{
			const FC7ApplyMovementFragment& C7ApplyMovement = C7ApplyMovementList[EntityIdx];
			if (C7ApplyMovement.bAvailable)
			{
				FMassVelocityFragment& Velocity = VelocityList[EntityIdx];
				Velocity.Value = UE::MassNavigation::ClampVector(
					FVector(C7ApplyMovement.VelocityX, C7ApplyMovement.VelocityY, C7ApplyMovement.VelocityZ),
					MaximumSpeed);
			}
		}
	});
}
