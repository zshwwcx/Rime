// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#include "Processors/UC7DebugEntityProcessor.h"
#include "MassCommonFragments.h"
#include "MassCommonTypes.h"
#include "MassRepresentationFragments.h"
#include "MassEntityView.h"
#include "SubSystems/CrowdNpcControlSubsystem.h"

namespace UE::MassCrowd
{
	extern bool GCrowdEnableDebugDrawOnBigMap;
}

UUC7DebugEntityProcessor::UUC7DebugEntityProcessor()
: EntityQuery(*this)
{
#if !UE_BUILD_SHIPPING
	bAutoRegisterWithProcessingPhases = true;
#else
	if (UE::MassCrowd::GCrowdEnableDebugDrawOnBigMap)
	{
		bAutoRegisterWithProcessingPhases = true;
	}else
	{
		bAutoRegisterWithProcessingPhases = false;
	}
#endif
	
	bRequiresGameThreadExecution = true;
	ProcessingPhase = EMassProcessingPhase::PostPhysics;
	ExecutionOrder.ExecuteInGroup = UE::Mass::ProcessorGroupNames::Tasks;
	ExecutionOrder.ExecuteAfter.Add(UE::Mass::ProcessorGroupNames::Movement);
}

void UUC7DebugEntityProcessor::ConfigureQueries()
{
	EntityQuery.AddRequirement<FTransformFragment>(EMassFragmentAccess::ReadOnly);
	EntityQuery.AddRequirement<FMassRepresentationFragment>(EMassFragmentAccess::ReadOnly);
}

void UUC7DebugEntityProcessor::Initialize(UObject& InOwner)
{
	Super::Initialize(InOwner);

	CrowdNpcControlSubsystem = UWorld::GetSubsystem<UCrowdNpcControlSubsystem>(InOwner.GetWorld());
}

void UUC7DebugEntityProcessor::Execute(FMassEntityManager& EntitySubSystem, FMassExecutionContext& Context)
{
	UCrowdNpcControlSubsystem* CrowdSubSys = CrowdNpcControlSubsystem.Get();
	if (!CrowdSubSys || !CrowdSubSys->IsEnabledDebugDrawOnBigMap() || !CrowdSubSys->IsBigMapOpened())
	{
		return;
	}

	CrowdSubSys->ResetDebugEntityInfo();
	
	// Check entities representation, only destroy entity matches EMassRepresentationType::None
	EntityQuery.ForEachEntityChunk(EntitySubSystem, Context, [&CrowdSubSys,&EntitySubSystem](FMassExecutionContext& Context)
	{
		const TConstArrayView<FMassRepresentationFragment> RepresentationList = Context.GetFragmentView<FMassRepresentationFragment>();
		const TConstArrayView<FTransformFragment> TransformList = Context.GetFragmentView<FTransformFragment>();
		const int32 NumEntities = Context.GetNumEntities();
		
		for (int32 EntityIdx = 0; EntityIdx < NumEntities; EntityIdx++)
		{
			const FMassEntityHandle MassAgentEntityHandle = Context.GetEntity(EntityIdx);
			FMassEntityView EntityView(EntitySubSystem, MassAgentEntityHandle);
			
			CrowdSubSys->AddDebugEntityInfo(RepresentationList[EntityIdx].CurrentRepresentation, TransformList[EntityIdx].GetTransform().GetLocation(), EntityView.HasTag<FToBeDeleteTag>());
		}
	});
}