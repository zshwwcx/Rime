// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#include "Processors/C7MassNpcInitializeProcessor.h"

#include "MassCommonFragments.h"
#include "MassCommonUtils.h"
#include "MassExecutionContext.h"
#include "Fragments/C7MassWanderTagsFragment.h"
#include "Subsystems/CrowdNpcControlSubsystem.h"

UC7MassNpcInitializeProcessor::UC7MassNpcInitializeProcessor()
	: EntityQuery(*this)
{
	bAutoRegisterWithProcessingPhases = false;
	RandomStream.Initialize(UE::Mass::Utils::GenerateRandomSeed());
}

void UC7MassNpcInitializeProcessor::ConfigureQueries()
{
	EntityQuery.AddRequirement<FTransformFragment>(EMassFragmentAccess::ReadWrite);
	EntityQuery.AddRequirement<FC7MassWanderTagsFragment>(EMassFragmentAccess::ReadWrite);
}

void UC7MassNpcInitializeProcessor::Execute(FMassEntityManager& EntityManager, FMassExecutionContext& Context)
{
	// 下面是从 UMassSpawnLocationProcessor 复制的代码
	if (!ensure(Context.ValidateAuxDataType<FC7MassNpcSpawnData>()))
	{
		UE_VLOG_UELOG(this, LogMass, Log, TEXT("Execution context has invalid AuxData or it's not FMassSpawnAuxData. Entity transforms won't be initialized."));
		return;
	}

	const UWorld* World = EntityManager.GetWorld();
	if (!ensure(World)) // 原本是Check
		return;

	FC7MassNpcSpawnData& AuxData = Context.GetMutableAuxData().GetMutable<FC7MassNpcSpawnData>();
	TArray<FTransform>& Transforms = AuxData.Transforms;

	const int32 NumSpawnTransforms = Transforms.Num();
	if (NumSpawnTransforms == 0)
	{
		UE_VLOG_UELOG(this, LogMass, Error, TEXT("No spawn transforms provided. Entity transforms won't be initialized."));
		return;
	}

	int32 NumRequiredSpawnTransforms = 0;
	EntityQuery.ForEachEntityChunk(EntityManager, Context, [&NumRequiredSpawnTransforms](const FMassExecutionContext& Context)
		{
			NumRequiredSpawnTransforms += Context.GetNumEntities();
		});

	const int32 NumToAdd = NumRequiredSpawnTransforms - NumSpawnTransforms;
	if (NumToAdd > 0)
	{
		UE_VLOG_UELOG(this, LogMass, Warning,
			TEXT("Not enough spawn locations provided (%d) for all entities (%d). Existing locations will be reused randomly to fill the %d missing positions."),
			NumSpawnTransforms, NumRequiredSpawnTransforms, NumToAdd);

		Transforms.AddUninitialized(NumToAdd);
		for (int i = 0; i < NumToAdd; ++i)
		{
			Transforms[NumSpawnTransforms + i] = Transforms[RandomStream.RandRange(0, NumSpawnTransforms - 1)];
		}
	}

	if (AuxData.bRandomize && !UE::Mass::Utils::IsDeterministic())
	{
		EntityQuery.ForEachEntityChunk(EntityManager, Context, [&Transforms, this](FMassExecutionContext& Context)
			{
				const TArrayView<FTransformFragment> LocationList = Context.GetMutableFragmentView<FTransformFragment>();
				const int32 NumEntities = Context.GetNumEntities();
				for (int32 i = 0; i < NumEntities; ++i)
				{
					const int32 AuxIndex = RandomStream.RandRange(0, Transforms.Num() - 1);
					LocationList[i].GetMutableTransform() = Transforms[AuxIndex];
					Transforms.RemoveAtSwap(AuxIndex, EAllowShrinking::No);
				}
			});
	}
	else
	{
		int32 NextTransformIndex = 0;
		EntityQuery.ForEachEntityChunk(EntityManager, Context, [&Transforms, &NextTransformIndex, this](FMassExecutionContext& Context)
			{
				const int32 NumEntities = Context.GetNumEntities();
				TArrayView<FTransformFragment> LocationList = Context.GetMutableFragmentView<FTransformFragment>();
				check(NextTransformIndex + NumEntities <= Transforms.Num());
	
				FMemory::Memcpy(LocationList.GetData(), &Transforms[NextTransformIndex], NumEntities * LocationList.GetTypeSize());
				NextTransformIndex += NumEntities;
			});
	}

	// 下面是新增的代码
	// 初始化区域和NPC类型
	if (UCrowdNpcControlSubsystem* CrowdNpcControlSubsystem = UWorld::GetSubsystem<UCrowdNpcControlSubsystem>(GetWorld()))
	{
		EntityQuery.ForEachEntityChunk(EntityManager, Context, [Fragment = AuxData.InitAreaConfigTypeFragment, CrowdNpcControlSubsystem, this](FMassExecutionContext& Context)
		{
			TConstArrayView<FMassEntityHandle> Entities = Context.GetEntities();
			CrowdNpcControlSubsystem->RecordAreaOnEntitiesCreated(Entities, Fragment);
			FZoneGraphTagMask AreaMask = CrowdNpcControlSubsystem->NpcAllowedAreas.FindRef(Fragment.AreaConfigType, FZoneGraphTagMask());

			TArrayView<FC7MassWanderTagsFragment> WanderTagsFragments = Context.GetMutableFragmentView<FC7MassWanderTagsFragment>();
			for (int i = 0; i < WanderTagsFragments.Num(); ++i)
			{
				// 包含这类NPC可行走的区域
				WanderTagsFragments[i].AllowWanderAnnotationTags.AnyTags.Add(AreaMask);
				// // 并且不能包含这类NPC不可行走的区域, 但是策划保证区域不会重叠, 所以这里先注掉, 后续等刷区域工具出来之后再看.
				// WanderTagsFragments[i].AllowWanderAnnotationTags.NotTags.Add(FZoneGraphTagMask(CrowdNpcControlSubsystem->ValidAreaTags ^ AreaMask.GetValue()));
			}
		});
	}
}
