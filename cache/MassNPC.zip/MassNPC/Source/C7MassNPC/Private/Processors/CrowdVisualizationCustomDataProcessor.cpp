// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#include "Processors/CrowdVisualizationCustomDataProcessor.h"
#include "MassCrowdRepresentationSubsystem.h"
#include "MassRepresentationFragments.h"
#include "MassVisualizationComponent.h"
#include "Fragments/CrowdNPCVisualizationFragment.h"
#include "MassCrowdAnimationTypes.h"
#include "MassUpdateISMProcessor.h"
#include "MassCrowdUpdateISMVertexAnimationProcessor.h"
#include "GameFramework/PlayerController.h"
#include "MassLODFragments.h"

namespace UE::CitySampleCrowd
{
	int32 bAllowKeepISMExtraFrameBetweenISM = 1;
	FAutoConsoleVariableRef CVarAllowKeepISMExtraFrameBetweenISM(TEXT("CitySample.crowd.AllowKeepISMExtraFrameBetweenISM"), bAllowKeepISMExtraFrameBetweenISM, TEXT("Allow the frost crowd visulaization to keep previous ISM an extra frame when switching between ISM"), ECVF_Default);

	int32 bAllowKeepISMExtraFrameWhenSwitchingToActor = 0;
	FAutoConsoleVariableRef CVarAllowKeepISMExtraFrameWhenSwitchingToActor(TEXT("CitySample.crowd.AllowKeepISMExtraFrameWhenSwitchingToActor"), bAllowKeepISMExtraFrameWhenSwitchingToActor, TEXT("Allow the frost crowd visulaization to keep ISM an extra frame when switching to spanwed actor"), ECVF_Default);

}

UMassProcessor_CrowdVisualizationCustomData::UMassProcessor_CrowdVisualizationCustomData()
	: EntityQuery_Conditional(*this)
{
	ExecutionFlags = (int32)(EProcessorExecutionFlags::Client | EProcessorExecutionFlags::Standalone);

	ExecutionOrder.ExecuteAfter.Add(UE::Mass::ProcessorGroupNames::Representation);

	// Requires animation system to update vertex animation data first
	ExecutionOrder.ExecuteAfter.Add(TEXT("MassProcessor_Animation"));

	bRequiresGameThreadExecution = true; // due to read-write access to FMassRepresentationSubsystemSharedFragment
}

void UMassProcessor_CrowdVisualizationCustomData::ConfigureQueries()
{
	EntityQuery_Conditional.AddRequirement<FCrowdAnimationFragment>(EMassFragmentAccess::ReadWrite);
	EntityQuery_Conditional.AddRequirement<FCrowdNPCVisualizationFragment>(EMassFragmentAccess::ReadOnly);
	EntityQuery_Conditional.AddRequirement<FTransformFragment>(EMassFragmentAccess::ReadOnly);
	EntityQuery_Conditional.AddRequirement<FMassViewerInfoFragment>(EMassFragmentAccess::ReadOnly);
	EntityQuery_Conditional.AddRequirement<FMassRepresentationFragment>(EMassFragmentAccess::ReadWrite);
	EntityQuery_Conditional.AddRequirement<FMassRepresentationLODFragment>(EMassFragmentAccess::ReadOnly);
	EntityQuery_Conditional.AddChunkRequirement<FMassVisualizationChunkFragment>(EMassFragmentAccess::ReadOnly);
	EntityQuery_Conditional.SetChunkFilter(&FMassVisualizationChunkFragment::AreAnyEntitiesVisibleInChunk);
	EntityQuery_Conditional.AddSharedRequirement<FMassRepresentationSubsystemSharedFragment>(EMassFragmentAccess::ReadWrite);
}

void UMassProcessor_CrowdVisualizationCustomData::Execute(FMassEntityManager& EntityManager, FMassExecutionContext& Context)
{
	EntityQuery_Conditional.ForEachEntityChunk(EntityManager, Context, [this](FMassExecutionContext& Context)
		{
			UMassProcessor_CrowdVisualizationCustomData::UpdateCrowdCustomData(Context);
		});
}

void UMassProcessor_CrowdVisualizationCustomData::Initialize(UObject& Owner)
{
	Super::Initialize(Owner);
	World = Owner.GetWorld();
	check(World);
	LODSubsystem = UWorld::GetSubsystem<UMassLODSubsystem>(World);
}

void UMassProcessor_CrowdVisualizationCustomData::UpdateCrowdCustomData(FMassExecutionContext& Context)
{
	UMassRepresentationSubsystem* RepresentationSubsystem = Context.GetMutableSharedFragment<FMassRepresentationSubsystemSharedFragment>().RepresentationSubsystem;
	check(RepresentationSubsystem);
	FMassInstancedStaticMeshInfoArrayView ISMInfos = RepresentationSubsystem->GetMutableInstancedStaticMeshInfos();

	const int32 NumEntities = Context.GetNumEntities();
	TConstArrayView<FTransformFragment> TransformList = Context.GetFragmentView<FTransformFragment>();
	TArrayView<FMassRepresentationFragment> RepresentationList = Context.GetMutableFragmentView<FMassRepresentationFragment>();
	TConstArrayView<FMassViewerInfoFragment> LODInfoList = Context.GetFragmentView<FMassViewerInfoFragment>();
	TConstArrayView<FMassRepresentationLODFragment> RepresentationLODList = Context.GetFragmentView<FMassRepresentationLODFragment>();
	TConstArrayView<FCrowdNPCVisualizationFragment> CitySampleCrowdVisualizationList = Context.GetFragmentView<FCrowdNPCVisualizationFragment>();
	TArrayView<FCrowdAnimationFragment> AnimationDataList = Context.GetMutableFragmentView<FCrowdAnimationFragment>();

	// BEGIN CHANGE BY lizhang@kuaishou.com 和CitySample的区别，5-10为上身,下身的染色数据
	// 0-4 为动画数据
	// 5-10 为上身和下身的染色数据
	const int NumCustomFloatsPerISM = 11;
	const int ColorVariationIndex = 5;
	
	TArray<float, TInlineAllocator<6>> CustomFloats;
	CustomFloats.AddZeroed(6);
	float& R = CustomFloats[0];
	float& G = CustomFloats[1];
	float& B = CustomFloats[2];
	float& R2 = CustomFloats[3];
	float& G2 = CustomFloats[4];
	float& B2 = CustomFloats[5];
	//END CHANGE BY lizhang@kuaishou.com 和CitySample的区别，5-10为上身,下身的染色数据
	

	for (int32 EntityIdx = 0; EntityIdx < NumEntities; EntityIdx++)
	{
		const FTransformFragment& TransformFragment = TransformList[EntityIdx];
		FMassRepresentationFragment& Representation = RepresentationList[EntityIdx];
		const FMassViewerInfoFragment& LODInfo = LODInfoList[EntityIdx];
		const FMassRepresentationLODFragment& RepresentationLOD = RepresentationLODList[EntityIdx];
		const FCrowdNPCVisualizationFragment& CitySampleCrowdVisualization = CitySampleCrowdVisualizationList[EntityIdx];
		FCrowdAnimationFragment& AnimationData = AnimationDataList[EntityIdx];

		if (Representation.CurrentRepresentation == EMassRepresentationType::StaticMeshInstance || 
			// Keeping an extra frame of ISM when switching to actors as sometime the actor isn't loaded and will not be display on lower hand platform.
		    ( UE::CitySampleCrowd::bAllowKeepISMExtraFrameWhenSwitchingToActor && 
			  Representation.PrevRepresentation == EMassRepresentationType::StaticMeshInstance && 
			 (Representation.CurrentRepresentation == EMassRepresentationType::LowResSpawnedActor || Representation.CurrentRepresentation == EMassRepresentationType::HighResSpawnedActor)) )
		{
			// @todo find a better way to do this
			// Skip instances unseen by ExclusiveInstanceViewerIdx 
			//if (ExclusiveInstanceViewerIdx == INDEX_NONE || LODInfo.bIsVisibleByViewer[ExclusiveInstanceViewerIdx])
			{
				FMassInstancedStaticMeshInfo& ISMInfo = ISMInfos[Representation.StaticMeshDescHandle.ToIndex()];

				const float PrevLODSignificance = UE::CitySampleCrowd::bAllowKeepISMExtraFrameBetweenISM ? Representation.PrevLODSignificance : -1.0f;

				// BEGIN CHANGE BY lizhang@kuaishou.com 5.4升级，UpdateISMTransform接口变更
				const FMassEntityHandle EntityHandle = Context.GetEntity(EntityIdx);
				// Update Transform
				UMassUpdateISMProcessor::UpdateISMTransform(EntityHandle, ISMInfo, TransformFragment.GetTransform()
					, Representation.PrevTransform, RepresentationLOD.LODSignificance, PrevLODSignificance);
				//END CHANGE BY lizhang@kuaishou.com 5.4升级，UpdateISMTransform接口变更
				
				// BEGIN CHANGE BY lizhang@kuaishou.com 和CitySample的区别，5-10为上身,下身的染色数据
				// Custom data layout is 0-4 are anim data, 5-10 are color variations
				// Need 6 floats of padding after anim data
				const int32 CustomDataPaddingAmount = 6;

				// Add Vertex animation custom floats
				UMassCrowdUpdateISMVertexAnimationProcessor::UpdateISMVertexAnimation(ISMInfo, AnimationData, RepresentationLOD.LODSignificance, PrevLODSignificance, CustomDataPaddingAmount);

				// Add color custom floats
				R = CitySampleCrowdVisualization.SuitLibBodyColor.R/255.f;
				G = CitySampleCrowdVisualization.SuitLibBodyColor.G/255.f;
				B = CitySampleCrowdVisualization.SuitLibBodyColor.B/255.f;
				R2 = CitySampleCrowdVisualization.SuitLibLowerColor.R/255.f;
				G2 = CitySampleCrowdVisualization.SuitLibLowerColor.G/255.f;
				B2 = CitySampleCrowdVisualization.SuitLibLowerColor.B/255.f;
				ISMInfo.WriteCustomDataFloatsAtStartIndex(0, CustomFloats, RepresentationLOD.LODSignificance, NumCustomFloatsPerISM, ColorVariationIndex, PrevLODSignificance);
				//END CHANGE BY lizhang@kuaishou.com 和CitySample的区别，5-10为上身,下身的染色数据
			}
		}
		Representation.PrevTransform = TransformFragment.GetTransform();
		Representation.PrevLODSignificance = RepresentationLOD.LODSignificance;
	}
}