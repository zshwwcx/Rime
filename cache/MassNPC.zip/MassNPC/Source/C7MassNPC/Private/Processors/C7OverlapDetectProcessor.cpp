// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: luyilong@kuaishou.com

#include "Processors/C7OverlapDetectProcessor.h"

#include "CrowdNPCCharacter.h"
#include "MassCommonTypes.h"
#include "MassCommonFragments.h"
#include "MassRepresentationFragments.h"
#include "MassRepresentationTypes.h"
#include "MassActorSubsystem.h"
#include "SubSystems/CrowdNpcControlSubsystem.h"

UC7OverlapDetectProcessor::UC7OverlapDetectProcessor()
: EntityQuery(*this)
{
	bAutoRegisterWithProcessingPhases = true;
	bRequiresGameThreadExecution = true;
	ProcessingPhase = EMassProcessingPhase::PostPhysics;
	ExecutionOrder.ExecuteInGroup = UE::Mass::ProcessorGroupNames::Tasks;
	ExecutionOrder.ExecuteAfter.Add(UE::Mass::ProcessorGroupNames::Representation);
}

void UC7OverlapDetectProcessor::ConfigureQueries()
{
	EntityQuery.AddRequirement<FMassActorFragment>(EMassFragmentAccess::ReadOnly);
	EntityQuery.AddRequirement<FTransformFragment>(EMassFragmentAccess::ReadOnly);
	EntityQuery.AddRequirement<FMassRepresentationFragment>(EMassFragmentAccess::ReadOnly);
	EntityQuery.AddTagRequirement<FMassOffLODTag>(EMassFragmentPresence::None);
}

void UC7OverlapDetectProcessor::Initialize(UObject& InOwner)
{
	Super::Initialize(InOwner);
	CrowdDeleteEntitySubsystem = UWorld::GetSubsystem<UCrowdNpcControlSubsystem>(InOwner.GetWorld());
}

void UC7OverlapDetectProcessor::Execute(FMassEntityManager& EntityManager, FMassExecutionContext& Context)
{
	UCrowdNpcControlSubsystem* ControlSubSys = CrowdDeleteEntitySubsystem.Get();
	if (!ControlSubSys)
	{
		return;
	}
	const TArray<ECrowdOverlapPointType> FilterTypes({ ECrowdOverlapPointType::Dead, ECrowdOverlapPointType::Hide, ECrowdOverlapPointType::React });
	TSet<FMassOverlapPointInfo*> TriggerPoints = ControlSubSys->GetInterestTriggerPoints(FilterTypes);
	
	TArray<TPair<const ACrowdNPCCharacter*, const FMassOverlapPointInfo*>> EnterActorToTrigger;
	TArray<TPair<const ACrowdNPCCharacter*, const FMassOverlapPointInfo*>> LeaveActorToTrigger;

	EntityQuery.ForEachEntityChunk(EntityManager, Context,[this, &TriggerPoints, &EnterActorToTrigger, &LeaveActorToTrigger, &EntityManager, &ControlSubSys](FMassExecutionContext& Context)
	{
		const TConstArrayView<FTransformFragment> TransformList = Context.GetFragmentView<FTransformFragment>();
		const TConstArrayView<FMassActorFragment> ActorInfoList = Context.GetFragmentView<FMassActorFragment>();
		const TConstArrayView<FMassRepresentationFragment> RepresentationList = Context.GetFragmentView<FMassRepresentationFragment>();
		const int32 NumEntities = Context.GetNumEntities();
		for (int32 EntityIdx = 0; EntityIdx < NumEntities; EntityIdx++)
		{
			const FMassEntityHandle MassAgentEntityHandle = Context.GetEntity(EntityIdx);
			const FTransformFragment& TransformFragment = TransformList[EntityIdx];
			const FMassActorFragment& ActorFragment = ActorInfoList[EntityIdx];
			const FMassRepresentationFragment& RepresentationFragment = RepresentationList[EntityIdx];
			FVector EntityLoc = TransformFragment.GetTransform().GetLocation();

			if (RepresentationFragment.CurrentRepresentation != EMassRepresentationType::LowResSpawnedActor &&
				RepresentationFragment.CurrentRepresentation != EMassRepresentationType::HighResSpawnedActor)
			{
				continue;	
			}
			for (const FMassOverlapPointInfo* InterestPointInfo : TriggerPoints)
			{
				if (InterestPointInfo->Type == ECrowdOverlapPointType::Dead)
				{
					if (FVector::Distance(EntityLoc, InterestPointInfo->PointPos) < InterestPointInfo->TriggerRadius)
					{
						EntityManager.Defer().AddTag<FCanDirectDeleteTag>(MassAgentEntityHandle);
						ControlSubSys->MarkDeleteEntity(MassAgentEntityHandle);
					}
					continue;
				}
				if (!InterestPointsEnter.Contains(*InterestPointInfo))
				{
					TArray<FMassEntityHandle> EmptyArray;
					InterestPointsEnter.Add(*InterestPointInfo, EmptyArray);
				}
				TArray<FMassEntityHandle>& CurEntityLst = InterestPointsEnter[*InterestPointInfo];
				float DistanceToTrigger = FVector::Distance(EntityLoc, InterestPointInfo->PointPos);
				if (DistanceToTrigger <= InterestPointInfo->TriggerRadius && !CurEntityLst.Contains(MassAgentEntityHandle))
				{
					if (const ACrowdNPCCharacter* CrowdCharacter = Cast<ACrowdNPCCharacter>(ActorFragment.Get()))
					{
						CurEntityLst.Add(MassAgentEntityHandle);
						EnterActorToTrigger.Add(TPair<const ACrowdNPCCharacter*, const FMassOverlapPointInfo*>(CrowdCharacter, InterestPointInfo));
					}
				}
				else if (DistanceToTrigger > InterestPointInfo->TriggerRadius && CurEntityLst.Contains(MassAgentEntityHandle))
				{
					if (const ACrowdNPCCharacter* CrowdCharacter = Cast<ACrowdNPCCharacter>(ActorFragment.Get()))
					{
						CurEntityLst.Remove(MassAgentEntityHandle);
						LeaveActorToTrigger.Add(TPair<const ACrowdNPCCharacter*, const FMassOverlapPointInfo*>(CrowdCharacter, InterestPointInfo));
					}
				}
			}
		}
	});
	for (auto& EnterActorInfo : EnterActorToTrigger)
	{
		const ACrowdNPCCharacter* CrowdCharacter = EnterActorInfo.Key;
		const FMassOverlapPointInfo* InterestPointInfo = EnterActorInfo.Value;
		CrowdCharacter->OnActorEnterTrigger(InterestPointInfo->PointPos, InterestPointInfo->TriggerRadius, InterestPointInfo->InstanceID, InterestPointInfo->Type);
	}
	for (auto& LeaveActorInfo : LeaveActorToTrigger)
	{
		const ACrowdNPCCharacter* CrowdCharacter = LeaveActorInfo.Key;
		const FMassOverlapPointInfo* InterestPointInfo = LeaveActorInfo.Value;
		CrowdCharacter->OnActorLeaveTrigger(InterestPointInfo->PointPos, InterestPointInfo->TriggerRadius, InterestPointInfo->InstanceID, InterestPointInfo->Type);
	}
}
