// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: luyilong@kuaishou.com

#include "Processors/C7CrowdInteractionProcessor.h"
#include "MassCommonTypes.h"
#include "MassRepresentationFragments.h"
#include "MassRepresentationTypes.h"
#include "MassSmartObjectFragments.h"
#include "MassEntityView.h"
#include "MassSmartObjectProcessor.h"

UC7CrowdInteractionProcessor::UC7CrowdInteractionProcessor()
: EntityQuery(*this)
{
	bAutoRegisterWithProcessingPhases = true;
	bRequiresGameThreadExecution = true;
	ExecutionOrder.ExecuteBefore.Add(UMassSmartObjectTimedBehaviorProcessor::StaticClass()->GetFName());
}

void UC7CrowdInteractionProcessor::ConfigureQueries()
{
	EntityQuery.AddRequirement<FMassSmartObjectTimedBehaviorFragment>(EMassFragmentAccess::ReadWrite);
}

void UC7CrowdInteractionProcessor::Initialize(UObject& InOwner)
{
	Super::Initialize(InOwner);
}

void UC7CrowdInteractionProcessor::Execute(FMassEntityManager& EntitySubSystem, FMassExecutionContext& Context)
{
	// Check entities representation, only clear TimedBehaviorFragment.UseTime with Tag FDeActiveC7SmartObjectMassInteractionTag
	EntityQuery.ForEachEntityChunk(EntitySubSystem, Context, [&EntitySubSystem](FMassExecutionContext& Context)
	{
		const int32 NumEntities = Context.GetNumEntities();
		const TArrayView<FMassSmartObjectTimedBehaviorFragment> TimedBehaviorFragments = Context.GetMutableFragmentView<FMassSmartObjectTimedBehaviorFragment>();
		for (int32 EntityIdx = 0; EntityIdx < NumEntities; EntityIdx++)
		{
			const FMassEntityHandle MassAgentEntityHandle = Context.GetEntity(EntityIdx);
			FMassEntityView EntityView(EntitySubSystem, MassAgentEntityHandle);
			// 有Tag的话说明lua侧想要主动结束这次交互
			if (EntityView.HasTag<FDeActiveC7SmartObjectMassInteractionTag>())
			{
				FMassSmartObjectTimedBehaviorFragment& TimedBehaviorFragment = TimedBehaviorFragments[EntityIdx];
				TimedBehaviorFragment.UseTime = 0;
				Context.Defer().RemoveTag<FDeActiveC7SmartObjectMassInteractionTag>(MassAgentEntityHandle);
			}
		}
	});
}
