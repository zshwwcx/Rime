// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: luyilong@kuaishou.com

#include "Processors/C7StateTreeSendEventProcessor.h"
#include "MassCommonTypes.h"
#include "MassRepresentationFragments.h"
#include "MassRepresentationTypes.h"
#include "MassSignalSubsystem.h"
#include "MassSmartObjectTypes.h"
#include "MassStateTreeFragments.h"
#include "NativeGameplayTags.h"
#include "StateTreeInstanceData.h"
#include "Fragments/C7SwitchSTStateFragment.h"

UE_DEFINE_GAMEPLAY_TAG_STATIC(TAG_SO_SWITCHST_ENTERREACTING, "MassAI.SmartObject.SwitchST_EnterReacting");
UE_DEFINE_GAMEPLAY_TAG_STATIC(TAG_SO_SWITCHST_LEAVEREACTING, "MassAI.SmartObject.SwitchST_LeaveReacting");
UE_DEFINE_GAMEPLAY_TAG_STATIC(TAG_SO_SWITCHST_STOPSOTASKS, "MassAI.SmartObject.SwitchST_StopSOTasks");
UE_DEFINE_GAMEPLAY_TAG_STATIC(TAG_SO_SWITCHST_GOTODEADPOINT, "MassAI.SmartObject.SwitchST_GoToDeadPoint");
UE_DEFINE_GAMEPLAY_TAG_STATIC(TAG_SO_SWITCHST_STOPSTATETREETASKS, "MassAI.SmartObject.SwitchST_StopStateTreeTasks");

UC7StateTreeSendEventProcessor::UC7StateTreeSendEventProcessor()
: EntityQuery(*this)
{
	bAutoRegisterWithProcessingPhases = true;
	bRequiresGameThreadExecution = true;
	ProcessingPhase = EMassProcessingPhase::PostPhysics;
	ExecutionOrder.ExecuteInGroup = UE::Mass::ProcessorGroupNames::Tasks;
	ExecutionOrder.ExecuteAfter.Add(UE::Mass::ProcessorGroupNames::Representation);
}

void UC7StateTreeSendEventProcessor::ConfigureQueries()
{
	EntityQuery.AddRequirement<FC7SwitchSTStateFragment>(EMassFragmentAccess::ReadWrite);
	EntityQuery.AddRequirement<FMassStateTreeInstanceFragment>(EMassFragmentAccess::ReadOnly);
	EntityQuery.AddTagRequirement<FMassOffLODTag>(EMassFragmentPresence::None);
}

void UC7StateTreeSendEventProcessor::Initialize(UObject& InOwner)
{
	Super::Initialize(InOwner);
}

void UC7StateTreeSendEventProcessor::Execute(FMassEntityManager& EntityManager, FMassExecutionContext& Context)
{
	const UWorld* CurWorld = GetWorld();
	if (CurWorld == nullptr)
	{
		return;
	}
	UMassStateTreeSubsystem* MassStateTreeSubsystem = CurWorld->GetSubsystem<UMassStateTreeSubsystem>();
	if (MassStateTreeSubsystem == nullptr)
	{
		return;
	}
	UMassSignalSubsystem* SignalSubsystem = CurWorld->GetSubsystem<UMassSignalSubsystem>();
	if (SignalSubsystem == nullptr)
	{
		return;
	}
	
	TArray<FMassEntityHandle> EntitiesToSignalReacting;
	
	EntityQuery.ForEachEntityChunk(EntityManager, Context, [this, &EntitiesToSignalReacting, MassStateTreeSubsystem](FMassExecutionContext& Context)
	{
		const int32 NumEntities = Context.GetNumEntities();
		const TConstArrayView<FMassStateTreeInstanceFragment> StateTreeInstanceList = Context.GetFragmentView<FMassStateTreeInstanceFragment>();
		const TArrayView<FC7SwitchSTStateFragment> C7SwitchSTStateFragment = Context.GetMutableFragmentView<FC7SwitchSTStateFragment>();
		for (int32 EntityIdx = 0; EntityIdx < NumEntities; EntityIdx++)
		{
			FC7SwitchSTStateFragment& C7SwitchSTState = C7SwitchSTStateFragment[EntityIdx];
			if (C7SwitchSTState.TargetState != ETargetStateType::None)
			{
				const FMassEntityHandle Entity = Context.GetEntity(EntityIdx);
				const FMassStateTreeInstanceFragment& StateTreeInstance = StateTreeInstanceList[EntityIdx];
				FStateTreeInstanceData* InstanceData = MassStateTreeSubsystem->GetInstanceData(StateTreeInstance.InstanceHandle);
				if (InstanceData == nullptr)
				{
					continue;
				}
				FStateTreeEventQueue& EventQueue = InstanceData->GetMutableEventQueue();
				if (C7SwitchSTState.TargetState == ETargetStateType::ENTER_REACTING)
				{
					EntitiesToSignalReacting.Add(Entity);
					EventQueue.SendEvent(this, TAG_SO_SWITCHST_ENTERREACTING,
						Context.GetAuxData(), TEXT("C7ReactingProcessor"));
				}
				else if (C7SwitchSTState.TargetState == ETargetStateType::LEAVE_REACTING)
				{
					EntitiesToSignalReacting.Add(Entity);
					EventQueue.SendEvent(this, TAG_SO_SWITCHST_LEAVEREACTING,
						Context.GetAuxData(), TEXT("C7ReactingProcessor"));
				}
				else if (C7SwitchSTState.TargetState == ETargetStateType::STOP_SO_TASKS)
				{
					EntitiesToSignalReacting.Add(Entity);
					EventQueue.SendEvent(this, TAG_SO_SWITCHST_STOPSOTASKS,
						Context.GetAuxData(), TEXT("C7ReactingProcessor"));
				}
				else if (C7SwitchSTState.TargetState == ETargetStateType::GO_TO_DEAD_POINT)
				{
					EntitiesToSignalReacting.Add(Entity);
					EventQueue.SendEvent(this, TAG_SO_SWITCHST_GOTODEADPOINT,
						Context.GetAuxData(), TEXT("C7ReactingProcessor"));
				}
				else if (C7SwitchSTState.TargetState == ETargetStateType::STOP_STATE_TREE_TASKS)
				{
					EntitiesToSignalReacting.Add(Entity);
					EventQueue.SendEvent(this, TAG_SO_SWITCHST_STOPSTATETREETASKS,
						Context.GetAuxData(), TEXT("C7ReactingProcessor"));
				}
				C7SwitchSTState.TargetState = ETargetStateType::None;
			}
		}
	});
	
	if (EntitiesToSignalReacting.Num())
	{
		// 先暂时使用SmartObjectInteractionAborted以避免修改引擎的MassStateTreeProcessor
		SignalSubsystem->SignalEntities(UE::Mass::Signals::SmartObjectInteractionAborted, EntitiesToSignalReacting);
	}
}
