// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: luyilong@kuaishou.com

#include "CrowdMassSpawner.h"
#include "Subsystems/CrowdNpcControlSubsystem.h"
#include "MassSimulationSubsystem.h"
#include "Engine/StreamableManager.h"
#include "Engine/AssetManager.h"
#include "Generators/CrowdMassEntityZoneGraphSpawnPointsGenerator.h"
#include "GeographyClimateSubsystem.h"
#include "MassEntityConfigAsset.h"
#include "Algo/RandomShuffle.h"
#include "Manager/KGCppAssetManager.h"


DEFINE_LOG_CATEGORY(LogC7Mass);


static TAutoConsoleVariable<bool> CVarCrowdMassSpawnerDebug(TEXT("Mass.CrowdMassSpawnerDebug"), false, TEXT("Output Spawner Info"));


ACrowdMassSpawner::ACrowdMassSpawner()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	// Make Sure Spawn Actor Manually
	bAutoSpawnOnBeginPlay = false;
}

void ACrowdMassSpawner::BeginPlay()
{
	CheckTimeArrange();
	bAutoSpawnOnBeginPlay = false;
	Super::BeginPlay();
	if(UCrowdNpcControlSubsystem* CrowdNpcControlSubsystem = UWorld::GetSubsystem<UCrowdNpcControlSubsystem>(GetWorld()))
	{
		CrowdNpcControlSubsystem->OnNotifyEntityDeleted.AddUniqueDynamic(this, &ACrowdMassSpawner::OnNotifyEntityDeleted);
		CrowdNpcControlSubsystem->OnNotifyEntityActive.AddUniqueDynamic(this, &ACrowdMassSpawner::OnNotifyEntityActiveChanged);
		CrowdNpcControlSubsystem->OnNotifyEntityScale.AddUniqueDynamic(this, &ACrowdMassSpawner::OnNotifyClimateScaleRatio);
		
		if (CrowdNpcControlSubsystem->IsAllEntitiesActivated())
			StartDoSpawning();
	}
}

void ACrowdMassSpawner::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if(UCrowdNpcControlSubsystem* CrowdNpcControlSubsystem = UWorld::GetSubsystem<UCrowdNpcControlSubsystem>(GetWorld()))
	{
		CrowdNpcControlSubsystem->OnNotifyEntityDeleted.RemoveDynamic(this, &ACrowdMassSpawner::OnNotifyEntityDeleted);
		CrowdNpcControlSubsystem->OnNotifyEntityActive.RemoveDynamic(this, &ACrowdMassSpawner::OnNotifyEntityActiveChanged);
		CrowdNpcControlSubsystem->OnNotifyEntityScale.RemoveDynamic(this, &ACrowdMassSpawner::OnNotifyClimateScaleRatio);
	}

	Super::EndPlay(EndPlayReason);
}

void ACrowdMassSpawner::OnConstruction(const FTransform& InTransform)
{
	Super::OnConstruction(InTransform);

#if !UE_BUILD_SHIPPING
	for (int i = CrowdAdjustTimes.Num() - 1; i >= 0 ; --i)
	{
		const FCrowdAdjustTime CrowdAdjustTime = CrowdAdjustTimes[i];
		
		// 如果【起始时间】-【结束时间】的差值小于30分钟，则报错，如果跨天则调整到同一天
		if ((CrowdAdjustTime.GetEndTotalMinutes() > CrowdAdjustTime.GetStartTotalMinutes() && CrowdAdjustTime.GetEndTotalMinutes() - CrowdAdjustTime.GetStartTotalMinutes() < 30) || CrowdAdjustTime.GetEndTotalMinutes() + 24 * 60 - CrowdAdjustTime.GetStartTotalMinutes() < 30)
		{
			FString ErrorLog = FString::Printf(TEXT("The time between the start and end time must be greater than half an hour! Start Time : %02d:%02d, End Time : %02d:%02d"), 
											   CrowdAdjustTime.StartTimeHour, 
											   CrowdAdjustTime.StartTimeMinute, 
											   CrowdAdjustTime.EndTimeHour, 
											   CrowdAdjustTime.EndTimeMinute);
			FText Message = FText::FromString(ErrorLog);
			FMessageDialog::Open(EAppMsgType::Ok, Message);
		}
	}

	for (FMassSpawnDataGenerator& Generator : SpawnDataGenerators)
	{
		if (Generator.GeneratorInstance)
		{
			const UCrowdMassEntityZoneGraphSpawnPointsGenerator* ZoneGraphGenerator = Cast<UCrowdMassEntityZoneGraphSpawnPointsGenerator>(Generator.GeneratorInstance.Get());
			if (ZoneGraphGenerator == nullptr)
			{
				FString ErrorLog = FString::Printf(TEXT("Please Use CrowdMassEntityZoneGraphSpawnPointsGenerator!"));
				FText Message = FText::FromString(ErrorLog);
				FMessageDialog::Open(EAppMsgType::Ok, Message);
			}
		}
	}
#endif
}

void ACrowdMassSpawner::Tick(float DeltaTime)
{
	bool bAllDataGenerated = true;
	for (const FMassSpawnDataGenerator& Generator : SpawnDataGenerators)
	{
		if (Generator.GeneratorInstance && !Generator.bDataGenerated)
		{
			bAllDataGenerated = false;
			break;
		}
	}
	if (!bAllDataGenerated)
		return;
	
	const float CurRatio = GetFinalScaleRatio();
	ScaleSpawningCount(CurRatio);
	const int32 TargetCount = GetSpawnCount();
	const int32 CurCount = GetCurrentCount();
#if !UE_BUILD_SHIPPING
	if (CVarCrowdMassSpawnerDebug.GetValueOnAnyThread())
	{
		UE_LOG(LogC7Mass, Log, TEXT("[CrowdMassSpawner] Current Count = %d, Target Count = %d"), CurCount, TargetCount);
	}
#endif
	if (TargetCount != CurCount)
	{
#if !UE_BUILD_SHIPPING
		if (CVarCrowdMassSpawnerDebug.GetValueOnAnyThread())
		{
			UE_LOG(LogC7Mass, Log, TEXT("[CrowdMassSpawner] Count Change! Current Count = %d, Target Count = %d"), CurCount, TargetCount);
		}
#endif
		if (TargetCount > CurCount)
		{
			const int32 AddNum = TargetCount - CurCount;
			if (AddNum > 0)
				SpawnerAddCount(AddNum);
		}
		else
		{
			const int32 ReduceNum = CurCount - TargetCount;
			if (ReduceNum > 0)
				SpawnerReduceCount(ReduceNum);
		}
	}

	CheckSpawnProportionTick -= DeltaTime;
	if (CheckSpawnProportionTick < 0)
	{
		CheckSpawnProportion(TargetCount);
		CheckSpawnProportionTick = CheckSpawnProportionInterval;
	}
}

void ACrowdMassSpawner::StartDoSpawning()
{
	UCrowdNpcControlSubsystem* CrowdNpcControlSubsystem = UWorld::GetSubsystem<UCrowdNpcControlSubsystem>(GetWorld());
	if (CrowdNpcControlSubsystem == nullptr || !CrowdNpcControlSubsystem->IsEnableToSpawnEntities())
	{
		return;
	}

	check(GEngine);

	ScaleSpawningCount(GetFinalScaleRatio());
	const int32 AddCount = GetSpawnCount() - GetCurrentCount();
	if (AddCount <= 0)
		return;

	UE_LOG(LogC7Mass, Log, TEXT("[CrowdMassSpawner] StartDoSpawning in cpp"));

	const ENetMode NetMode = GEngine->GetNetMode(GetWorld());
	if (NetMode != NM_Client)
	{
		const UMassSimulationSubsystem* MassSimulationSubsystem = UWorld::GetSubsystem<UMassSimulationSubsystem>(GetWorld());
		if (MassSimulationSubsystem == nullptr || MassSimulationSubsystem->IsSimulationStarted())
		{
			SpawnerAddCount(AddCount);
		}
		else
		{
			TWeakObjectPtr<ACrowdMassSpawner> WeakThis = this;
			SimulationStartedHandle = UMassSimulationSubsystem::GetOnSimulationStarted().AddLambda([WeakThis, AddCount](UWorld* InWorld)
				{
					if (!WeakThis.IsValid())
						return;

					if (InWorld == WeakThis->GetWorld())
					{
						WeakThis->SpawnerAddCount(AddCount);
					}
				});
		}
	}
}

void ACrowdMassSpawner::DeferOnSpawnDataGenerationFinished(TConstArrayView<FMassEntitySpawnDataGeneratorResult> Results, FMassSpawnDataGenerator* FinishedGenerator)
{
	// @todo: this can be potentially expensive copy for the instanced structs, could there be a way to use move gere instead?
	AllGeneratedResults.Append(Results.GetData(), Results.Num());

	bool bAllSpawnPointsGenerated = true;
	bool bFoundFinishedGenerator = false;
	for (FMassSpawnDataGenerator& Generator : SpawnDataGenerators)
	{
		if (&Generator == FinishedGenerator)
		{
			Generator.bDataGenerated = true;
			bFoundFinishedGenerator = true;
		}

		bAllSpawnPointsGenerated &= Generator.bDataGenerated;
	}

	checkf(bFoundFinishedGenerator, TEXT("Something went wrong, we are receiving a callback on an unknow spawn point generator"));
	
	if (bAllSpawnPointsGenerated)
	{
		if (UWorld* World = GetWorld())
		{
			if (const FMassEntityManager* EntityManager = UE::Mass::Utils::GetEntityManager(World))
			{
				TWeakObjectPtr<ACrowdMassSpawner> WeakThis = this;
				EntityManager->Defer().PushCommand<FMassDeferredCreateCommand>([WeakThis,AllGeneratedResults = AllGeneratedResults, Version = ConfigVersion](const FMassEntityManager& InManager)
				{
					if (WeakThis.IsValid() && !WeakThis->IsPendingKillPending() && Version == WeakThis->ConfigVersion)
					{
						WeakThis->SpawnGeneratedEntities(AllGeneratedResults);
					}
					else
					{
						UE_LOG(LogC7Mass, Warning, TEXT("[CrowdMassSpawner] Deferred spawn was cancelled due to version mismatch or actor is being destroyed"));
					}
				});
			}
		}
		
		AllGeneratedResults.Reset();
	}
}

void ACrowdMassSpawner::CheckTimeArrange()
{
	for (int i = CrowdAdjustTimes.Num() - 1; i >= 0; --i)
	{
		FCrowdAdjustTime CrowdAdjustTime = CrowdAdjustTimes[i];
		// 如果【起始时间】-【结束时间】的差值小于30分钟，则报错，如果跨天则调整到同一天
		if ((CrowdAdjustTime.GetEndTotalMinutes() > CrowdAdjustTime.GetStartTotalMinutes() && CrowdAdjustTime.GetEndTotalMinutes() - CrowdAdjustTime.GetStartTotalMinutes() < 30) || CrowdAdjustTime.GetEndTotalMinutes() + 24 * 60 - CrowdAdjustTime.GetStartTotalMinutes() < 30)
		{
			UE_LOG(LogC7Mass, Error, TEXT("[CrowdMassSpawner] The time between the start and end time must be greater than half an hour! Start Time : %d:%d, End Time : %d:%d"), CrowdAdjustTime.StartTimeHour, CrowdAdjustTime.StartTimeMinute, CrowdAdjustTime.EndTimeHour, CrowdAdjustTime.EndTimeMinute);
			CrowdAdjustTimes.RemoveAt(i);
		}
	}

	for (int i = CrowdAdjustTimes.Num() - 1; i >= 0; --i)
	{
		const FCrowdAdjustTime CrowdAdjustTime = CrowdAdjustTimes[i];
		//判断跨天
		if (CrowdAdjustTime.GetStartTotalMinutes() > CrowdAdjustTime.GetEndTotalMinutes())
		{
			FCrowdAdjustTime NewTime1(CrowdAdjustTime.StartTimeHour, CrowdAdjustTime.StartTimeMinute, 23, 59, CrowdAdjustTime.Scale);
			FCrowdAdjustTime NewTime2(0, 0, CrowdAdjustTime.EndTimeHour, CrowdAdjustTime.EndTimeMinute, CrowdAdjustTime.Scale);
			
			CrowdAdjustTimes.RemoveAt(i);
			
			CrowdAdjustTimes.Add(NewTime1);
			CrowdAdjustTimes.Add(NewTime2);
		}
	}

	// 判断区间是否重叠
	for (int i = 0; i < CrowdAdjustTimes.Num(); ++i)
	{
		for (int j = i + 1; j < CrowdAdjustTimes.Num(); ++j)
		{
			if (CrowdAdjustTimes[i].GetStartTotalMinutes() < CrowdAdjustTimes[j].GetEndTotalMinutes() && CrowdAdjustTimes[i].GetEndTotalMinutes() > CrowdAdjustTimes[j].GetStartTotalMinutes())
			{
				UE_LOG(LogC7Mass, Warning, TEXT("[CrowdMassSpawner] There is overlap between the times!"));
			}
		}
	}

	for (int i = 0; i < CrowdAdjustTimes.Num(); ++i)
	{
		UE_LOG(LogC7Mass, Log, TEXT("[CrowdMassSpawner] Start Time : %d:%d, End Time : %d:%d"), CrowdAdjustTimes[i].StartTimeHour, CrowdAdjustTimes[i].StartTimeMinute, CrowdAdjustTimes[i].EndTimeHour, CrowdAdjustTimes[i].EndTimeMinute);
	}
}

int32 ACrowdMassSpawner::GetCurrentCount()
{
	int FinalRes = 0;
	for (FSpawnedEntities& EntityStruct : AllSpawnedEntities)
	{
		FinalRes += EntityStruct.Entities.Num();
	}
	return FinalRes;
}

void ACrowdMassSpawner::SetAreaTypes(int32 InAreaTag, const TArray<FName>& InAreaConfigTypes)
{
	ConfigVersion ++;
	AreaTag = InAreaTag;
	AreaConfigTypes = InAreaConfigTypes;
}

void ACrowdMassSpawner::SetDeleteEntityParameters(float InOverflowRatioLimit, float InCheckSpawnProportionInterval)
{
	ConfigVersion ++;
	OverflowRatioLimit = InOverflowRatioLimit;
	CheckSpawnProportionTick = InCheckSpawnProportionInterval;
	CheckSpawnProportionInterval = InCheckSpawnProportionInterval;
}

void ACrowdMassSpawner::InitializeSetCount(const int32 NewCount)
{
	ConfigVersion ++;
	Count = NewCount;
}

void ACrowdMassSpawner::InitializeSetEntityTypes(TArray<FMassSpawnedEntityType>&& NewEntityTypes)
{
	ConfigVersion ++;
	EntityTypes = MoveTemp(NewEntityTypes);
}

void ACrowdMassSpawner::InitializeSetSpawnDataGenerators(TArray<FMassSpawnDataGenerator>&& NewSpawnDataGenerators)
{
	ConfigVersion ++;
	SpawnDataGenerators = MoveTemp(NewSpawnDataGenerators);
}

float ACrowdMassSpawner::GetFinalScaleRatio()
{
	float TimeScale = 1.0f;
	if (UGeographyClimateSubsystem *GeographyClimateSystem = GetWorld()->GetSubsystem<UGeographyClimateSubsystem>())
	{
		const auto GeographyInfo = GeographyClimateSystem->GetGeographyInfo();
		const float CurTimeOfMinute = GeographyInfo.Hours * 60 + GeographyInfo.Minutes + GeographyInfo.Seconds / 60.0f;
		for (int i = CrowdAdjustTimes.Num() - 1; i >= 0 ; --i)
		{
			const FCrowdAdjustTime CrowdAdjustTime = CrowdAdjustTimes[i];
			if(CurTimeOfMinute >= CrowdAdjustTime.GetStartTotalMinutes() && CurTimeOfMinute < CrowdAdjustTime.GetEndTotalMinutes())
			{
				TimeScale = CrowdAdjustTime.Scale;
#if !UE_BUILD_SHIPPING
				if (CVarCrowdMassSpawnerDebug.GetValueOnAnyThread())
				{
					UE_LOG(LogC7Mass, Log, TEXT("[CrowdMassSpawner] CurTimeOfMinute = %f, StartTimeOfMinute = %d, EndTimeOfMinute = %d"),
						CurTimeOfMinute, CrowdAdjustTime.GetStartTotalMinutes(), CrowdAdjustTime.GetEndTotalMinutes());
				}
#endif
				break;
			}
		}
	}
#if !UE_BUILD_SHIPPING
	if (CVarCrowdMassSpawnerDebug.GetValueOnAnyThread())
	{
		UE_LOG(LogC7Mass, Log, TEXT("[CrowdMassSpawner] TimeScale = %f, ClimateScale = %f"), TimeScale, ClimateScaleRatio);
	}
#endif
	return ClimateScaleRatio * TimeScale;
}

void ACrowdMassSpawner::SpawnerAddCount(int AddCount)
{
	// no spawn point generators configured. Let user know and fall back to the spawner's location
	if (SpawnDataGenerators.Num() == 0)
	{
		// UE_VLOG_UELOG(this, LogC7Mass, Warning, TEXT("No Spawn Data Generators configured."));
		return;
	}
	
	AllGeneratedResults.Reset();
	float TotalProportion = 0.0f;
	
	for (FMassSpawnDataGenerator& Generator : SpawnDataGenerators)
	{
		if (Generator.GeneratorInstance)
		{
			Generator.bDataGenerated = false;
			TotalProportion += Generator.Proportion;
			// 初始化结束后, 额外添加时需要考虑生成半径
			if (UCrowdMassEntityZoneGraphSpawnPointsGenerator* ZoneGraphGenerator = Cast<UCrowdMassEntityZoneGraphSpawnPointsGenerator>(Generator.GeneratorInstance.Get()))
			{
				ZoneGraphGenerator->SetRadius(GenerateOutRadius);
			}
			else
			{
				UE_LOG(LogC7Mass, Warning, TEXT("[CrowdMassSpawner] ZoneGraphGenerator is not Class UCrowdMassEntityZoneGraphSpawnPointsGenerator"));
			}
		}
	}

	if (TotalProportion <= 0.0f)
	{
		// UE_VLOG_UELOG(this, LogC7Mass, Error, TEXT("The total combined proportion of all the generator needs to be greater than 0."));
		return;
	}
	
	// Check if it needs loading
	if (StreamingHandle.IsValid() && StreamingHandle->IsActive())
	{
		// @todo, instead of blindly canceling, we should remember what was asked to load with that handle and compare if more is needed?
		StreamingHandle->CancelHandle();
	}
	TArray<FSoftObjectPath> AssetsToLoad;
	bool bHasAnyLoaded = false;
	for (const FMassSpawnedEntityType& EntityType : EntityTypes)
	{
		if (!EntityType.IsLoaded())
		{
			if (!EntityType.EntityConfig.IsNull())
				AssetsToLoad.Add(EntityType.EntityConfig.ToSoftObjectPath());
		}
		else
		{
			bHasAnyLoaded = true;
		}
	}
	
	const bool bNeedLoadAsset = AssetsToLoad.Num() > 0;
	const int32 TotalSpawnCount = AddCount;

	TWeakObjectPtr<ACrowdMassSpawner> WeakThis = this;
	auto GenerateSpawningPoints = [WeakThis, TotalSpawnCount, TotalProportion, bNeedLoadAsset, bHasAnyLoaded]()
	{
		if (!WeakThis.IsValid())
			return;
		
		bool bFinalHasAnyLoaded = bHasAnyLoaded;
		if (bNeedLoadAsset)
		{
			// check asset not found
			for (FMassSpawnedEntityType& EntityType : WeakThis->EntityTypes)
			{
				if (!EntityType.IsLoaded() &&
					!FindObject<UMassEntityConfigAsset>(nullptr, *EntityType.EntityConfig.ToSoftObjectPath().GetAssetPathString()))
				{
					UE_LOG(LogC7Mass, Error, TEXT("[CrowdMassSpawner] EntityType EntityConfig is not exist: %s"), *EntityType.EntityConfig.ToString());
					EntityType.EntityConfig.Reset();	
				}
				else
				{
					bFinalHasAnyLoaded = true;
				}
			}
		}
		
		if (!bFinalHasAnyLoaded)
			return;
		
		int32 SpawnCountRemaining = TotalSpawnCount;
		float ProportionRemaining = TotalProportion;
		for (FMassSpawnDataGenerator& Generator : WeakThis->SpawnDataGenerators)
		{
			if (Generator.Proportion == 0.0f || ProportionRemaining <= 0.0f)
			{
				// If there's nothing to spawn, mark the generator done as OnSpawnDataGenerationFinished() will wait for all generators to complete before the actual spawning.
				Generator.bDataGenerated = true;
				continue;
			}

			if (Generator.GeneratorInstance)
			{
				const float ProportionRatio = FMath::Min(Generator.Proportion / ProportionRemaining, 1.0f);
				const int32 SpawnCount = FMath::CeilToInt(SpawnCountRemaining * ProportionRatio);
				
				FFinishedGeneratingSpawnDataSignature Delegate = FFinishedGeneratingSpawnDataSignature::CreateUObject(WeakThis.Get(), &ACrowdMassSpawner::DeferOnSpawnDataGenerationFinished, &Generator);
				Generator.GeneratorInstance->Generate(*WeakThis, WeakThis->EntityTypes, SpawnCount, Delegate);
				SpawnCountRemaining -= SpawnCount;
				ProportionRemaining -= Generator.Proportion;
			}
		} 
	};
	
	if (AssetsToLoad.Num())
	{
		FStreamableManager& StreamableManager = UAssetManager::GetStreamableManager();
		StreamingHandle = StreamableManager.RequestAsyncLoad(AssetsToLoad, GenerateSpawningPoints, static_cast<int32>(EAssetLoadPriority::Default));
	}
	else
	{
		GenerateSpawningPoints();
	}
}

void ACrowdMassSpawner::SpawnerReduceCount(int ReduceCount)
{
	if (UCrowdNpcControlSubsystem* CrowdNpcControlSubsystem = UWorld::GetSubsystem<UCrowdNpcControlSubsystem>(GetWorld()))
	{
		int32 CurReduceNum = 0;
		TMap<int32, int32> EntityCountMap;
		TArray<int32> ShuffledArray;
		TMap<int32, int32> RemainCntInfo;
		
		for (int32 i = 0; i < AllSpawnedEntities.Num(); i++)
		{
			FSpawnedEntities& EntityStruct = AllSpawnedEntities[i];
			if (EntityStruct.Entities.Num() <= 0)
				continue;
			
			const int RemainReduceNum = ReduceCount - CurReduceNum;
			const float EntitiesRatio = static_cast<float>(EntityStruct.Entities.Num()) / static_cast<float>(GetCurrentCount());
			const float ReduceNumPerTemplateFlt = static_cast<float>(ReduceCount) * EntitiesRatio;
			int ReduceNumPerTemplate = FMath::FloorToInt(ReduceNumPerTemplateFlt);
			if (ReduceNumPerTemplate > RemainReduceNum)
				ReduceNumPerTemplate = RemainReduceNum;
			if (ReduceNumPerTemplate >= EntityStruct.Entities.Num())
			{
				// 分到的指标超过了总数, 全部删除
				EntityCountMap.Add(i, EntityStruct.Entities.Num());
				CurReduceNum += EntityStruct.Entities.Num();
			}
			else
			{
				ShuffledArray.Add(i);
				RemainCntInfo.Add(i, EntityStruct.Entities.Num() - ReduceNumPerTemplate);
				EntityCountMap.Add(i, ReduceNumPerTemplate);
				CurReduceNum += ReduceNumPerTemplate;
			}
		}

		int32 RemainCnt = ReduceCount - CurReduceNum;
		if (RemainCnt > 0)
		{
			Algo::RandomShuffle(ShuffledArray);
			if (RemainCnt <= ShuffledArray.Num())
			{
				// 随机分配, 随机到的类型多分配一个名额
				for (const int32 ShuffledIdx : ShuffledArray)
				{
					if (EntityCountMap.Contains(ShuffledIdx))
					{
						EntityCountMap[ShuffledIdx] = EntityCountMap[ShuffledIdx] + 1;
					}
					else
					{
						EntityCountMap.Add(ShuffledIdx, 1);
					}
					RemainCnt -= 1;
					if (RemainCnt <= 0) break;
				}
			}
			else
			{
				// 这里是存在的, 因为存在分到的指标超过了总数而全部删除的case, 所以数量是不准确的
				// 随机分配, 这里不再做二次随机了, 随机到的开始全额扣除
				for (const int32 ShuffledIdx : ShuffledArray)
				{
					int32 deltaValue = 0;
					if (RemainCntInfo[ShuffledIdx] > RemainCnt)
					{
						deltaValue = RemainCnt;
					}
					else
					{
						deltaValue = RemainCntInfo[ShuffledIdx];
					}
					
					if (EntityCountMap.Contains(ShuffledIdx))
					{
						EntityCountMap[ShuffledIdx] = EntityCountMap[ShuffledIdx] + deltaValue;
					}
					else
					{
						EntityCountMap.Add(ShuffledIdx, deltaValue);
					}
					RemainCnt -= deltaValue;
					if (RemainCnt <= 0) break;
				}
			}
		}
		
		for (int32 i = 0; i < AllSpawnedEntities.Num(); i++)
		{
			if (!EntityCountMap.Contains(i))
				continue;

			const int32 TargetNum = EntityCountMap[i];
			if (TargetNum <= 0)
				continue;
			
			FSpawnedEntities& EntityStruct = AllSpawnedEntities[i];
			if (EntityStruct.Entities.Num() <= 0)
				continue;
			
			TArray<FMassEntityHandle> SpecificAmountEntities;
			for (int ii = 0; ii < TargetNum; ++ii)
			{
				SpecificAmountEntities.Add(EntityStruct.Entities.Last(ii));
			}
			CrowdNpcControlSubsystem->MarkDeleteEntities(SpecificAmountEntities);
		}
	}
}

void ACrowdMassSpawner::CheckSpawnProportion(int32 TargetCount)
{
	TRACE_CPUPROFILER_EVENT_SCOPE(ACrowdMassSpawner::CheckSpawnProportion);
	if (!IsControlledByDesigner())
		return;
	
	UCrowdNpcControlSubsystem* CrowdNpcControlSubsystem = UWorld::GetSubsystem<UCrowdNpcControlSubsystem>(GetWorld());
	if (!CrowdNpcControlSubsystem)
		return;

	if (!CrowdNpcControlSubsystem->CachedEntityCountMaps.Contains(AreaTag))
		return;

	if (AreaConfigTypes.Num() < EntityTypes.Num())
		return;
	
	const int32 TypeCount = EntityTypes.Num();
	TMap<FName, int32> AreaNpcCounts = CrowdNpcControlSubsystem->CachedEntityCountMaps[AreaTag];
	TArray<float> InitProportions;
	TArray<float> CurrentProportions;
	float TotalInitProportion = 0;
	float TotalCurrentProportion = 0;
	for (int i = 0; i < TypeCount; i++)
	{
		CurrentProportions.Add(AreaNpcCounts.FindRef(AreaConfigTypes[i], 0));
		InitProportions.Add(EntityTypes[i].Proportion * TargetCount);
		TotalInitProportion += InitProportions[i];
		TotalCurrentProportion += CurrentProportions[i];
	}

	if (TotalInitProportion <= 0 || TotalCurrentProportion <= 0 || TargetCount <= 0)
		return;

	const float TotalOverflowRatio = FMath::Max(1, TotalCurrentProportion / TargetCount);
	TArray<FMassEntityHandle> NeedDeleteEntities;
	TMap<FName, int32> NeedDeleteCount;
	int32 TotalDelete = 0;
	for (int i = 0; i < TypeCount; i++)
	{
		if (InitProportions[i] == 0)
			continue;
		const float InitProportion = InitProportions[i] / TotalInitProportion;
		const float CurrentProportion = CurrentProportions[i] / TotalCurrentProportion * TotalOverflowRatio;
		if ((CurrentProportion * TotalOverflowRatio - InitProportion) / InitProportion> OverflowRatioLimit)
		{
			int32 DeleteCount = TotalCurrentProportion * (CurrentProportion * TotalOverflowRatio - InitProportion) / TotalOverflowRatio;
			NeedDeleteCount.Add(AreaConfigTypes[i], DeleteCount);
			TotalDelete += DeleteCount;
		}
	}

	if (TotalDelete == 0)
		return;

	const FRandomStream RandomStream(TotalDelete);
	NeedDeleteEntities.Reserve(TotalDelete);
	const TMap<FMassEntityHandle, FC7AreaConfigData>& EntityAreas = CrowdNpcControlSubsystem->EntityAreas;
	for (const TPair<FMassEntityHandle, FC7AreaConfigData>& EntityArea : EntityAreas)
	{
		const FC7AreaConfigData& AreaConfigData = EntityArea.Value;
		int32* RemainCount = AreaNpcCounts.Find(AreaConfigData.AreaConfigType);
		int32* RemainDeleteCount = NeedDeleteCount.Find(AreaConfigData.AreaConfigType);
		if (RemainCount && *RemainCount > 0 && RemainDeleteCount && *RemainDeleteCount > 0)
		{
			if (RandomStream.FRand() < *RemainDeleteCount / *RemainCount)
			{
				NeedDeleteEntities.Add(EntityArea.Key);
				(*RemainDeleteCount) -= 1;
			}
			(*RemainCount)--;
		}
	}

	CrowdNpcControlSubsystem->MarkDeleteEntities(NeedDeleteEntities);
}

void ACrowdMassSpawner::OnNotifyEntityDeleted(const TArray<FMassEntityHandle>& TargetEntities)
{
	if (TargetEntities.Num() <= 0)
		return;
	
	for (FSpawnedEntities& SpawnedEntities : AllSpawnedEntities)
	{
		TArray<FMassEntityHandle> DeleteLst;
		for (FMassEntityHandle& SpawnedEntity : SpawnedEntities.Entities)
		{
			const int32 Index = TargetEntities.Find(SpawnedEntity);
			if (Index != INDEX_NONE)
			{
				DeleteLst.Add(SpawnedEntity);
			}	
		}
		for (FMassEntityHandle& DeleteEntity : DeleteLst)
		{
			SpawnedEntities.Entities.RemoveSingle(DeleteEntity);
		}
	}
}

void ACrowdMassSpawner::OnNotifyEntityActiveChanged(const bool bActivate)
{
	if (bActivate)
	{
		StartDoSpawning();
	}
	else
	{
		DoDespawning();
	}
}

void ACrowdMassSpawner::OnNotifyClimateScaleRatio(const float InClimateScaleRatio)
{
	ClimateScaleRatio = InClimateScaleRatio;
#if !UE_BUILD_SHIPPING
	UE_LOG(LogC7Mass, Log, TEXT("[CrowdMassSpawner] OnNotifyClimateScaleRatio ClimateScaleRatio = %f"), ClimateScaleRatio);
#endif
}
