// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#include "C7MassNPC.h"

#if __has_include("CxxReflectionC7MassNPC.h")
#include "CxxReflectionC7MassNPC.h"
#endif

#define LOCTEXT_NAMESPACE "FC7MassNPCModule"

void FC7MassNPCModule::StartupModule()
{
	// This code will execute after your module is loaded into memory; the exact timing is specified in the .uplugin file per-module
#if __has_include("CxxReflectionC7MassNPC.h") && !defined(KG_CXX_REFLECTING)
	REGISTER_LAZY_REGISTER(C7MassNPC);
#endif
}

void FC7MassNPCModule::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module.  For modules that support dynamic reloading,
	// we call this function before unloading the module.
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FC7MassNPCModule, C7MassNPC)