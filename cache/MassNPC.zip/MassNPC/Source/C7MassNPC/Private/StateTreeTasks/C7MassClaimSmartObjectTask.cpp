// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: pengqi05@kuaishou.com

#include "StateTreeTasks/C7MassClaimSmartObjectTask.h"
#include "Fragments/C7SwitchSTStateFragment.h"
#include "CrowdNPCCharacter.h"
#include "MassStateTreeExecutionContext.h"
#include "MassSmartObjectHandler.h"
#include "MassSmartObjectFragments.h"
#include "MassEntityManager.h"
#include "MassSignalSubsystem.h"
#include "MassCommandBuffer.h"
#include "StateTreeLinker.h"

namespace UE::C7Mass
{
	struct FPayload
	{
		FMassEntityHandle EntityHandle;
		TSharedPtr<FMassEntityManager> EntityManager;
	};

	void OnSlotInvalidated(const FSmartObjectClaimHandle& ClaimHandle, const ESmartObjectSlotState State, FPayload Payload)
	{
		FMassEntityManager* EntityManager = Payload.EntityManager.Get();
		FMassEntityHandle EntityHandle = Payload.EntityHandle;
		if (EntityManager != nullptr && EntityManager->IsEntityActive(EntityHandle))
		{
			EntityManager->Defer().PushCommand<FMassDeferredSetCommand>([EntityHandle](const FMassEntityManager& InManager)
				{
					if (FC7SwitchSTStateFragment* C7SwitchSTStateFragment =
						InManager.GetFragmentDataPtr<FC7SwitchSTStateFragment>(EntityHandle))
					{
						C7SwitchSTStateFragment->TargetState = ETargetStateType::STOP_SO_TASKS;
					}
				});
		}
	}
}

bool FC7MassClaimSmartObjectTask::Link(FStateTreeLinker& Linker)
{
	Linker.LinkExternalData(ActorHandle);
	return Super::Link(Linker);
}

EStateTreeRunStatus FC7MassClaimSmartObjectTask::EnterState(FStateTreeExecutionContext& Context, const FStateTreeTransitionResult& Transition) const
{
	const FMassActorFragment& ActorFragment = Context.GetExternalData(ActorHandle);
	if (ActorFragment.IsOwnedByMass())
	{
		if (const ACrowdNPCCharacter* CrowdCharacter = Cast<ACrowdNPCCharacter>(ActorFragment.Get()))
		{
			if (CrowdCharacter->GetIsInIsm())
			{
				return EStateTreeRunStatus::Failed;
			}
		}
		else
		{
			return EStateTreeRunStatus::Failed;
		}
	}
	EStateTreeRunStatus RunStatus = Super::EnterState(Context, Transition);
	if (RunStatus == EStateTreeRunStatus::Running)
	{
		const FMassStateTreeExecutionContext& MassContext = static_cast<FMassStateTreeExecutionContext&>(Context);
		FInstanceDataType& InstanceData = Context.GetInstanceData(*this);
		USmartObjectSubsystem& SmartObjectSubsystem = Context.GetExternalData(SmartObjectSubsystemHandle);

		// 在这绑定相关Slot释放相关回调
		UE::C7Mass::FPayload Payload;
		Payload.EntityHandle = MassContext.GetEntity();
		Payload.EntityManager = MassContext.GetEntityManager().AsShared();
		SmartObjectSubsystem.RegisterSlotInvalidationCallback(
			InstanceData.ClaimedSlot,
			FOnSlotInvalidated::CreateStatic(&UE::C7Mass::OnSlotInvalidated, Payload));
	}
	return RunStatus;
}
