// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: luyilong@kuaishou.com

#include "StateTreeTasks/C7MassFindDeadPointTask.h"
#include "StateTreeLinker.h"
#include "MassAIBehaviorTypes.h"
#include "MassTrafficLaneChange.h"


UE_DISABLE_OPTIMIZATION_SHIP

FC7MassFindDeadPointTask::FC7MassFindDeadPointTask()
{
}

bool FC7MassFindDeadPointTask::Link(FStateTreeLinker& Linker)
{
	Linker.LinkExternalData(LocationHandle);
	Linker.LinkExternalData(ZoneGraphSubsystemHandle);
	Linker.LinkExternalData(CrowdNpcControlSubsystemHandle);

	return true;
}

EStateTreeRunStatus FC7MassFindDeadPointTask::EnterState(FStateTreeExecutionContext& Context, const FStateTreeTransitionResult& Transition) const
{
	const FMassZoneGraphLaneLocationFragment& LaneLocation = Context.GetExternalData(LocationHandle);
	const UZoneGraphSubsystem& ZoneGraphSubsystem = Context.GetExternalData(ZoneGraphSubsystemHandle);
	UCrowdNpcControlSubsystem& CrowdNpcControlSubsystem = Context.GetExternalData(CrowdNpcControlSubsystemHandle);

	// todo 如果后面点很多, 需要做剔除的逻辑
	TSet<FMassOverlapPointInfo>& DeadPoints = CrowdNpcControlSubsystem.GetInterestPoints(ECrowdOverlapPointType::Dead);

	FInstanceDataType& InstanceData = Context.GetInstanceData(*this);

	if (!LaneLocation.LaneHandle.IsValid())
	{
		MASSBEHAVIOR_LOG(Error, TEXT("Invalid lane location."));
		return EStateTreeRunStatus::Failed;
	}
			
	const FZoneGraphStorage* ZoneGraphStorage = ZoneGraphSubsystem.GetZoneGraphStorage(LaneLocation.LaneHandle.DataHandle);
	if (!ZoneGraphStorage)
	{
		MASSBEHAVIOR_LOG(Error, TEXT("Missing ZoneGraph Storage for current lane %s."), *LaneLocation.LaneHandle.ToString());
		return EStateTreeRunStatus::Failed;
	}
	
	EStateTreeRunStatus Status = EStateTreeRunStatus::Failed;

	const FVector CurLocation = UE::MassTraffic::GetLaneEndPoint(LaneLocation.LaneHandle.Index, *ZoneGraphStorage);

	for (int32 LaneIndex = 0; LaneIndex < ZoneGraphStorage->Lanes.Num(); ++LaneIndex)
	{
		const FZoneLaneData& Lane = ZoneGraphStorage->Lanes[LaneIndex];
		
		if (AllowedAnnotationTags.Pass(Lane.Tags))
		{
			float LaneLength = 0.0f;
			UE::ZoneGraph::Query::GetLaneLength(*ZoneGraphStorage, LaneIndex, LaneLength);

			float Distance = 0.0f;
			while (Distance <= LaneLength)
			{
				FZoneGraphLaneLocation TargetLaneLocation;
				UE::ZoneGraph::Query::CalculateLocationAlongLane(*ZoneGraphStorage, LaneIndex, Distance, TargetLaneLocation);
				if (FVector::Distance(CurLocation, TargetLaneLocation.Position) < InstanceData.NearbyRadius && IsPointInDeadPoint(TargetLaneLocation.Position, DeadPoints))
				{
					Status = EStateTreeRunStatus::Running;
					InstanceData.DeadPointLocation.LaneHandle = LaneLocation.LaneHandle;
					InstanceData.DeadPointLocation.NextExitLinkType = EZoneLaneLinkType::None;
					InstanceData.DeadPointLocation.NextLaneHandle.Reset();
					InstanceData.DeadPointLocation.bMoveReverse = false; // true则沿着来路走
					InstanceData.DeadPointLocation.EndOfPathIntent = EMassMovementAction::Stand;
					InstanceData.DeadPointLocation.EndOfPathPosition = TargetLaneLocation.Position;
					InstanceData.DeadPointLocation.TargetDistance = TargetLaneLocation.DistanceAlongLane;
					// 走到消失点的任务续时间很长, 做个标记
					const FMassStateTreeExecutionContext& MassContext = static_cast<FMassStateTreeExecutionContext&>(Context);
					const FMassEntityHandle MyEntity = MassContext.GetEntity();
					MassContext.GetEntityManager().Defer().AddTag<FLongTimeTaskTag>(MyEntity);
					break;
				}
				Distance += 100.0f;
			}
		}
	}

	return Status;
}

// 函数检查一个点是否在出生点范围
bool FC7MassFindDeadPointTask::IsPointInDeadPoint(const FVector& Point, TSet<FMassOverlapPointInfo>& DeadPoints) const
{
	bool bInBornPoint = false;
	for (const FMassOverlapPointInfo& DeadPointInfo : DeadPoints)
	{
		float NowDis = FVector::Distance(Point, DeadPointInfo.PointPos);
		if (NowDis <= DeadPointInfo.TriggerRadius)
		{
			bInBornPoint = true;
			break;	
		}
	}
	return bInBornPoint;
}

UE_ENABLE_OPTIMIZATION_SHIP
