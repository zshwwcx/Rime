// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: pengqi05@kuaishou.com


#include "StateTreeTasks/C7MassUseSmartObjectTask.h"
#include "MassStateTreeExecutionContext.h"
#include "MassEntityView.h"
#include "MassActorSubsystem.h"
#include "CrowdNPCCharacter.h"
#include "StateTreeLinker.h"

bool FC7MassUseSmartObjectTask::Link(FStateTreeLinker& Linker)
{
	Linker.LinkExternalData(ActorHandle);
	return Super::Link(Linker);
}

EStateTreeRunStatus FC7MassUseSmartObjectTask::EnterState(FStateTreeExecutionContext& Context, const FStateTreeTransitionResult& Transition) const
{
	// ISM 状态下不允许和smart object交互
	const FMassActorFragment& ActorFragment = Context.GetExternalData(ActorHandle);
	if (ActorFragment.IsOwnedByMass())
	{
		if (const ACrowdNPCCharacter* CrowdCharacter = Cast<ACrowdNPCCharacter>(ActorFragment.Get()))
		{
			if (CrowdCharacter->GetIsInIsm())
			{
				return EStateTreeRunStatus::Failed;
			}
		}
		else
		{
			return EStateTreeRunStatus::Failed;
		}
	}
	return Super::EnterState(Context, Transition);
}
