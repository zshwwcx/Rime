// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: luyilong@kuaishou.com

#include "StateTreeTasks/C7MassForceDeadTask.h"


FC7MassForceDeadTask::FC7MassForceDeadTask()
{
}

bool FC7MassForceDeadTask::Link(FStateTreeLinker& Linker)
{
	Linker.LinkExternalData(CrowdNpcControlSubsystemHandle);
	return true;
}

EStateTreeRunStatus FC7MassForceDeadTask::EnterState(FStateTreeExecutionContext& Context, const FStateTreeTransitionResult& Transition) const
{
	UCrowdNpcControlSubsystem& CrowdNpcControlSubsystem = Context.GetExternalData(CrowdNpcControlSubsystemHandle);
	const FMassStateTreeExecutionContext& MassContext = static_cast<FMassStateTreeExecutionContext&>(Context);
	const FMassEntityHandle MyEntity = MassContext.GetEntity();
	CrowdNpcControlSubsystem.MarkDeleteEntity(MyEntity);
	MassContext.GetEntityManager().Defer().AddTag<FCanDirectDeleteTag>(MyEntity);
	return EStateTreeRunStatus::Running;
}
