// Fill out your copyright notice in the Description page of Project Settings.


#include "StateTreeTasks/C7MassZoneGraphFindWanderTarget.h"
#include "MassStateTreeExecutionContext.h"
#include "StateTreeLinker.h"

bool FC7MassZoneGraphFindWanderTarget::Link(FStateTreeLinker& Linker)
{
	Linker.LinkExternalData(C7MassWanderTagsFragmentHandle);
	return Super::Link(Linker);
}

EStateTreeRunStatus FC7MassZoneGraphFindWanderTarget::EnterState(FStateTreeExecutionContext& Context, const FStateTreeTransitionResult& Transition) const
{
	FC7MassZoneGraphFindWanderTarget* MutableThis = const_cast<FC7MassZoneGraphFindWanderTarget*>(this);
	MutableThis->AllowedAnnotationTags = Context.GetExternalData(C7MassWanderTagsFragmentHandle).AllowWanderAnnotationTags;
	return Super::EnterState(Context, Transition);
}
