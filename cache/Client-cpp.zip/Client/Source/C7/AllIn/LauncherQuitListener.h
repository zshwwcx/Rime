// Fill out your copyright notice in the Description page of Project Settings.

#pragma once
#include "CoreMinimal.h"



/// <summary>
/// PC端独有：
///	PC端目前启动器和游戏通信 ：游戏和Launcher建立NamePipeLine，Launcher那边作为Server(Launcher会在客户端发起退出请求的前提下创建server)，
///	客户端一旦和Server连接成功，则表示需要退出游戏
/// </summary>


class  LauncherQuitListener;

class FPipeListenerThread : public FRunnable
{
private:
	FString PipeName;
	bool bIsQuitting;
	bool isRunning;

	FRunnableThread* Thread;
	TWeakPtr<LauncherQuitListener> Owner;


public:
	FPipeListenerThread(FString InPipeLineName, TWeakPtr<LauncherQuitListener> InOwner) :bIsQuitting(false)
	{
		PipeName = InPipeLineName;
		Owner = InOwner;
	}
	~FPipeListenerThread()
	{
		StopThread();
	}


	void StartThread();
	void StopThread();

	virtual uint32 Run() override;

	
};



class C7_API LauncherQuitListener
{
private:
	FPipeListenerThread* ListenerThread;

public:
	LauncherQuitListener() {}
	~LauncherQuitListener()
	{
		StopListening();
	}

	void StartListening(FString InPipeLineName, TWeakPtr<LauncherQuitListener> InOwner);
	void StopListening();


	//退出游戏回调
	 void OnLauncherQuitGame();
	
};




