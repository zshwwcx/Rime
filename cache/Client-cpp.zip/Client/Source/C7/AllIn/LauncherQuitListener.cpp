// Fill out your copyright notice in the Description page of Project Settings.

#include "AllIn/LauncherQuitListener.h"
#include "AllInManager.h"

#if PLATFORM_WINDOWS && !WITH_EDITOR
#include "Windows/WindowsHWrapper.h" 
#endif


uint32 FPipeListenerThread::Run()
{
#if PLATFORM_WINDOWS && !WITH_EDITOR

	while (isRunning)
	{
		// UE_LOG(LogAllInManager, Log, TEXT("StartNamedPipeLIneListening... !"));
		if (WaitNamedPipeW(*PipeName, 100)) 
		{
			HANDLE PipeHandle = CreateFileW(
				*PipeName,
				GENERIC_READ,
				0,
				nullptr,
				OPEN_EXISTING,
				0,
				nullptr
			);

			if (PipeHandle != INVALID_HANDLE_VALUE)
			{
				CloseHandle(PipeHandle);
				UE_LOG(LogAllInManager, Log, TEXT("Need Quit GameFrom Launcher!"));

				bIsQuitting = true;
				TWeakPtr<LauncherQuitListener> WeakOwner = this->Owner;


				AsyncTask(ENamedThreads::GameThread, [WeakOwner]()
					{
						if (WeakOwner.IsValid())
						{
							WeakOwner.Pin()->OnLauncherQuitGame();
						}
					});
				break; 
			}
		}
		FPlatformProcess::Sleep(0.1f);
	}
#endif

	return  0;
}

void FPipeListenerThread::StartThread()
{
	UE_LOG(LogAllInManager, Log, TEXT("FPipeListenerThread: StartThread  Thread... !"));
	isRunning = true;
	Thread = FRunnableThread::Create(this, TEXT("PipeQuitListenerThread"));
}


void FPipeListenerThread::StopThread()
{
	isRunning = false;
	if(Thread)
	{
		UE_LOG(LogAllInManager, Log, TEXT("FPipeListenerThread:StopPipeLine Thread... !"));

		Thread->WaitForCompletion();

		delete Thread;
		Thread = nullptr;
	}
}


void LauncherQuitListener::StartListening(FString InPipeLineName, TWeakPtr<LauncherQuitListener> InOwner)
{
	ListenerThread = new FPipeListenerThread(InPipeLineName, InOwner);
	ListenerThread->StartThread();
}

void LauncherQuitListener::StopListening()
{
	if (ListenerThread)
	{
		ListenerThread->StopThread();

		delete ListenerThread;
		ListenerThread = nullptr;
	}
}


void LauncherQuitListener::OnLauncherQuitGame()
{
	UE_LOG(LogAllInManager, Log, TEXT("LauncherQuitListener  :QuitFromGameLauncher !"));
	StopListening();

	RequestEngineExit("QuitFromGameLauncher");
}


