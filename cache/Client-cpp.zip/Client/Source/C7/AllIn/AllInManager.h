#pragma once

#include "CoreMinimal.h"
#include "Manager/KGBasicManager.h"

#include "AllInManager.generated.h"

DECLARE_LOG_CATEGORY_EXTERN(LogAllInManager, All, All);

DECLARE_DYNAMIC_DELEGATE_OneParam(FReceiveAllInSDKMessage, FString, jsonString);

UCLASS(BlueprintType, Blueprintable)
class C7_API UAllInManager : public UKGBasicManager
{
	GENERATED_BODY()

public:

	virtual void NativeInit() override;

	virtual void NativeUninit() override;
	
	virtual EManagerType GetManagerType() override { return EManagerType::EMT_AllInSdkManager; }
	
	UFUNCTION(BlueprintCallable)
	void RegisterCallbackEvent();

	UFUNCTION(BlueprintCallable)
	void UnregisterCallbackEvent();

	void ReceiveAllInSDKMessage(const FString& jsonString) const;

	UFUNCTION(BlueprintCallable)
	static bool IsAllInSDKEnabled();

	UFUNCTION(BlueprintCallable)
	void TrackAllInSDKReceiveProxyMessage(const FString& ModuleName, const FString& FuncName, const FString& Parameters);

	UPROPERTY()
	FReceiveAllInSDKMessage OnReceiveAllInSDKMessage;
};