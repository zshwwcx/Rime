#include "AllInManager.h"
#if !defined DISABLE_ALLIN_SDK
#include "AllInSDK.h"
#endif

#include "PakUpdateSubsystem.h"

#if PLATFORM_WINDOWS && !WITH_EDITOR
#include "Windows/WindowsHWrapper.h"
#endif

DEFINE_LOG_CATEGORY(LogAllInManager);

void UAllInManager::NativeInit()
{
	Super::NativeInit();
	RegisterCallbackEvent();
}

void UAllInManager::NativeUninit()
{
	Super::NativeUninit();
	UnregisterCallbackEvent();
}

void UAllInManager::RegisterCallbackEvent()
{
#if !defined DISABLE_ALLIN_SDK
	FAllInSDKModule::OnRecieveAllInSDKMessageEvent.AddUObject(this, &UAllInManager::ReceiveAllInSDKMessage);
#endif

	
	UPakUpdateSubsystem* Sub = GEngine->GetEngineSubsystem<UPakUpdateSubsystem>();
	if (Sub != nullptr)
	{
		Sub->FOnTrackToAllSDKReceiveProxyMessageEvent.AddDynamic(this, &UAllInManager::TrackAllInSDKReceiveProxyMessage);
	}
}


void UAllInManager::TrackAllInSDKReceiveProxyMessage(const FString& ModuleName, const FString& FuncName, const FString& Parameters)
{
	FGenericAllInPtr GenericAllInPtr = FAllInSDKModule::Get().GetAllIn();
	if(GenericAllInPtr.IsValid())
	{
		GenericAllInPtr->ReceiveProxyMessage(ModuleName, FuncName, Parameters);
	}
}


void UAllInManager::UnregisterCallbackEvent()
{
#if !defined DISABLE_ALLIN_SDK
	FAllInSDKModule::OnRecieveAllInSDKMessageEvent.RemoveAll(this);
#endif


	UPakUpdateSubsystem* Sub = GEngine->GetEngineSubsystem<UPakUpdateSubsystem>();
	if(Sub != nullptr)
	{
		Sub->FOnTrackToAllSDKReceiveProxyMessageEvent.RemoveDynamic(this, &UAllInManager::TrackAllInSDKReceiveProxyMessage);
	}
}

void UAllInManager::ReceiveAllInSDKMessage(const FString& jsonString) const
{
	OnReceiveAllInSDKMessage.ExecuteIfBound(jsonString);
}

bool UAllInManager::IsAllInSDKEnabled()
{
#if defined DISABLE_ALLIN_SDK
	return false;
#else
	return true;
#endif
}
