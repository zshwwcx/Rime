#include "AssetManager/C7PrimaryAssetLabel.h"
#include "AssetManager/C7AssetManager.h"
#include "AssetRegistry/IAssetRegistry.h"
#include "Engine/AssetManager.h"

#if WITH_EDITOR
#include "Settings/ProjectPackagingSettings.h"
#include "JsonUtilities.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"
#endif

#include "Misc/ConfigCacheIni.h"
#include "Internationalization/Regex.h"

const FName UC7PrimaryAssetLabel::TableAndLuaReferencedBundle = FName("TableAndLuaReferenced");
const FName UC7PrimaryAssetLabel::AlwaysCookBundle = FName("AlwaysCook");
const FName UC7PrimaryAssetLabel::CompositionLevelBundle = FName("CompositionLevel");
const FName UC7PrimaryAssetLabel::ExplicitDirectoryBundle = FName("ExplicitDirectory");
const FName UC7PrimaryAssetLabel::ExplicitAssetBundle = FName("Explicit");

UC7PrimaryAssetLabel::UC7PrimaryAssetLabel()
{
	bLabelAssetsReferencedInTableAndLua = false;
	bLabelAlwaysCookDirectories = false;
	bLableWorldCompositionLevel = false;
}

#if WITH_EDITOR

// Blueprint
void UC7PrimaryAssetLabel::CheckUpdateAssetBundleData()
{
	UpdateAssetBundleData();
}

#endif

#if WITH_EDITORONLY_DATA

void UC7PrimaryAssetLabel::UpdateLuaCollectAssets()
{
	if (UAssetManager* Manager = UAssetManager::GetIfInitialized())
	{
		if (UC7AssetManager* AssetManager = Cast<UC7AssetManager>(Manager))
		{
			TArray<FName> Packages;
			TArray<FName> NeverCookPackages;
			AssetManager->GetLuaReferencedAssets(Packages, NeverCookPackages, ChunkName);
			const IAssetRegistry& AssetRegistry = AssetManager->GetAssetRegistry();
			TArray<FTopLevelAssetPath> NewPaths;
			for (const FName Package : Packages)
			{
				const FString PackagePath = FPaths::SetExtension(Package.ToString(), TEXT(""));
				TArray<FAssetData> Assets;
				AssetRegistry.GetAssetsByPackageName(*PackagePath, Assets, true);
				for (const FAssetData& AssetData : Assets)
				{
					NewPaths.Add(FTopLevelAssetPath(AssetData.PackageName, AssetData.AssetName));
				}
			}
			AssetBundleData.SetBundleAssets(TableAndLuaReferencedBundle, MoveTemp(NewPaths));
		}
	}
}

void UC7PrimaryAssetLabel::UpdateAlwaysCook()
{
	if (UAssetManager* Manager = UAssetManager::GetIfInitialized())
	{
		TArray<FTopLevelAssetPath> NewPaths;

		FConfigFile GameConfig;
		FConfigCacheIni::LoadLocalIniFile(GameConfig, TEXT("Game"), true);

		FString CurrentChangelist;
		TArray<FString> CookFilePaths;
		GameConfig.GetArray(TEXT("/Script/UnrealEd.ProjectPackagingSettings"), TEXT("DirectoriesToAlwaysCook"), CookFilePaths);

		for (int i = 0; i < CookFilePaths.Num(); ++i)
		{
			TArray<FAssetData> DirectoryAssets;
			FString CookPath = CookFilePaths[i].Right(CookFilePaths[i].Len() - 7);
			CookPath = CookPath.Left(CookPath.Len() - 2);
			Manager->GetAssetRegistry().GetAssetsByPath(*CookPath, DirectoryAssets, true, true);
			for (const FAssetData& AssetData : DirectoryAssets)
			{
				NewPaths.Add(FTopLevelAssetPath(AssetData.PackageName, AssetData.AssetName));
			}
		}
		AssetBundleData.SetBundleAssets(AlwaysCookBundle, MoveTemp(NewPaths));
	}
}

void UC7PrimaryAssetLabel::UpdateAssetBundleData()
{
	bool bSuccess = false;
	if (ConfigFrom == EConfigFrom::JSON)
	{
		bSuccess = UpdateByJson();
	}
	if (!bSuccess)
	{
		UE_LOG(LogTemp, Display, TEXT("ChunkName = %s, read setting by ChunkLabel."), *ChunkName);
		Super::UpdateAssetBundleData();
		
		if (UAssetManager* Manager = UAssetManager::GetIfInitialized())
		{
			TArray<FTopLevelAssetPath> NewPaths;
			for (const FDirectoryPath& Directory : ExplicitDirectories)
			{
				TArray<FAssetData> DirectoryAssets;
				Manager->GetAssetRegistry().GetAssetsByPath(*Directory.Path, DirectoryAssets, true, true);
				for (const FAssetData& AssetData : DirectoryAssets)
				{
					NewPaths.Add(FTopLevelAssetPath(AssetData.PackageName, AssetData.AssetName));
				}
			}
			if (NewPaths.Num() > 0)
			{
				AssetBundleData.SetBundleAssets(ExplicitDirectoryBundle, MoveTemp(NewPaths));
			}
		}

		if (C7ExplicitAssets.Num() > 0)
		{
			TArray<FTopLevelAssetPath> NewPaths;
			for (auto& C7ExplicitAsset : C7ExplicitAssets)
			{
				NewPaths.Add(C7ExplicitAsset.GetAssetPath());
			}
			AssetBundleData.SetBundleAssets(ExplicitAssetBundle, MoveTemp(NewPaths));
		}
	}

	//[guoyi06]:概率会出现分包资源不正确，主动刷新下
	if (UAssetManager::IsInitialized())
	{
		UE_LOG(LogTemp, Display, TEXT("ChunkName = %s, Refresh Asset Data."), *ChunkName);
		UAssetManager::Get().RefreshAssetData(this);
	}
}

void UC7PrimaryAssetLabel::CollectAssetPaths(const FString& InAssetPath, TArray<FTopLevelAssetPath>& OutPaths)
{
	FSoftObjectPath SOP(InAssetPath);

	// map path format: /Game/A/B
	// the other asset format is : /Game/A/B.B
	int32 Idx = -1;
	if (InAssetPath.FindChar('.', Idx) == false)
	{
		const FString PackageName = FPackageName::GetShortName(InAssetPath);
		const FString FullPathName = InAssetPath + FString(TEXT(".")) + PackageName;
		SOP = FSoftObjectPath(FullPathName);
	}

	FTopLevelAssetPath TLAP = SOP.GetAssetPath();
	OutPaths.Add(TLAP);
}

void UC7PrimaryAssetLabel::AddAsset(TArray<TSharedPtr<FJsonValue>> Assetes, TArray<FTopLevelAssetPath>& NewAssetPaths)
{
	TSet<FString> AssetList;
	for (auto& Asset : Assetes)
	{
		FString OutString = TEXT("");
		if (Asset->TryGetString(OutString))
		{
			AssetList.Add(OutString);
		}
	}
			
	for (const FString& Asset : AssetList)
	{
		CollectAssetPaths(Asset, NewAssetPaths);
	}
}

void UC7PrimaryAssetLabel::AddDirectory(TArray<TSharedPtr<FJsonValue>> Directories,TArray<FTopLevelAssetPath>& NewDirectoryPaths)
{
	TSet<FString> DirectoryList;
	for (auto& Directory : Directories)
	{
		FString OutString = TEXT("");
		if (Directory->TryGetString(OutString))
		{
			DirectoryList.Add(OutString);
		}
	}
	
	if (UAssetManager* Manager = UAssetManager::GetIfInitialized())
	{
		for (const FString& Directory : DirectoryList)
		{
			TArray<FAssetData> DirectoryAssets;
			Manager->GetAssetRegistry().GetAssetsByPath(*Directory, DirectoryAssets, true, true);
			for (const FAssetData& AssetData : DirectoryAssets)
			{
				NewDirectoryPaths.Add(FTopLevelAssetPath(AssetData.PackageName, AssetData.AssetName));
			}
		}
	}
}

bool UC7PrimaryAssetLabel::UpdateByJson()
{
	Super::UpdateAssetBundleData();
	AssetBundleData.Reset();
	
#if WITH_EDITOR
	UE_LOG(LogTemp, Display, TEXT("ChunkName = %s, read setting by JSON."), *ChunkName);
#endif
	AssetBundleData.Reset();
	// Always cook
	if(bIsBaseChunk)
	{
#if WITH_EDITOR
		UE_LOG(LogTemp, Display, TEXT("ChunkName = %s, Always cook."), *ChunkName);
#endif
		UpdateAlwaysCook(); 
	}
	// collect lua
	UpdateLuaCollectAssets();
	return true;
}

#endif
