// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"

#if PLATFORM_WINDOWS && !WITH_EDITOR
#include "AllIn/LauncherQuitListener.h"
#endif

class FC7Module : public IModuleInterface
{
public:
	//~BEGIN: IModuleInterface interface
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
	//~END: IModuleInterface interface
private:
	//记录游戏运行状态的mutex ,用于和Launcher之间的通信,目前Launcher会通过该值判断游戏是否存活
	void StartupMutex();
	void ShutdownMutex();
	void StartupPipe();
	void ShutdownPipe();

	void* GameProductMutexHandle = nullptr;
#if PLATFORM_WINDOWS && !WITH_EDITOR
	//启动器和游戏退出的PipeLine
	TSharedPtr<LauncherQuitListener> QuitFromLauncherListener;
#endif
};
