#pragma once
#include "CoreMinimal.h"
#include "UMG/Components/KGMapTagLayer.h"

#include "C7MapTagInfoManager.generated.h"


// 格子坐标结构体
struct FGridCoord
{
    int32 X;
    int32 Y;
    
    FGridCoord(int32 InX = 0, int32 InY = 0) : X(InX), Y(InY) {}
    
    bool operator==(const FGridCoord& Other) const
    {
        return X == Other.X && Y == Other.Y;
    }
    
    // 用于TMap的哈希函数
    friend uint32 GetTypeHash(const FGridCoord& Coord)
    {
        return HashCombine(GetTypeHash(Coord.X), GetTypeHash(Coord.Y));
    }
};

// 重命名后的格子管理类
UCLASS()
class UC7MapTagInfoManager : public UObject
{
	GENERATED_BODY()
public:
    void Initialize(float InGridSize, TMap<FString, FMapTagInfo>* InMapTagInfoData, TArray<FString>* InFollowUpdateList);
	void AddSingleTag(const FString& TaskID);
	void AddSingleTagInternal(const FString& TaskID, const FGridCoord& GridCoord);
    void RemoveSingleTag(const FString& TaskID);
    void UpdateTagLocation(const FString& TaskID, const FVector& NewLocation);
    void UpdateCharacterPosition(const FVector& CharacterLocation);
	void ClearAllTags();

	// 更新动态图标（FollowUpdateList）对应格子位置
	void UpdateFollowTagInfo();
    
    // 获取当前九宫格内的所有TaskID
    TArray<FString> GetCurrentTaskIDs() const;
    
    // 通过TaskID获取FMapTagInfo
    FMapTagInfo* GetMapTagInfo(const FString& TaskID);

private:
    FGridCoord WorldToGrid(const FVector& WorldLocation) const;
    TArray<FGridCoord> GetSurroundingGrids(const FGridCoord& CenterGrid) const;
    void LoadGrid(const FGridCoord& GridCoord);
    void UnloadGrid(const FGridCoord& GridCoord);

private:
	// 格子大小
	float GridSize;
    
	// 格子到TaskID数组的映射
	TMap<FGridCoord, TArray<FString>> GridToTaskIDsMap;
    
	// TaskID到格子的映射（用于快速查找）
	TMap<FString, FGridCoord> TaskIDToGridMap;
    
	// 当前加载的九宫格格子
	TSet<FGridCoord> CurrentLoadedGrids;
    
	// 当前角色所在的格子坐标
	FGridCoord CurrentCharacterGrid;
    
	// 引用外部的 MapTagInfoData, FollowUpdateList
	TMap<FString, FMapTagInfo>* MapTagInfoData = nullptr;
	TArray<FString>* FollowUpdateList = nullptr;
};