#include "C7MapTagInfoManager.h"

#include "3C/Util/KGUtils.h"


void UC7MapTagInfoManager::Initialize(float InGridSize, TMap<FString, FMapTagInfo>* InMapTagInfoData, TArray<FString>* InFollowUpdateList)
{
    GridSize = InGridSize;
	MapTagInfoData = InMapTagInfoData;
	FollowUpdateList = InFollowUpdateList;
    CurrentCharacterGrid = FGridCoord(INT32_MAX - 1, INT32_MAX - 1);
}

FGridCoord UC7MapTagInfoManager::WorldToGrid(const FVector& WorldLocation) const
{
    return FGridCoord(
        FMath::FloorToInt(WorldLocation.X / GridSize),
        FMath::FloorToInt(WorldLocation.Y / GridSize)
    );
}

void UC7MapTagInfoManager::AddSingleTag(const FString& TaskID)
{
	if (!MapTagInfoData)
	{
		return;
	}
	
	// TODO. 可以不用 AddSingleTag 而改成一次性对 MapTagInfoData 设置好映射关系
    // 从MapTagInfoData获取位置信息
    if (FMapTagInfo* TagInfo = MapTagInfoData->Find(TaskID))
    {
        FGridCoord GridCoord = WorldToGrid(TagInfo->StaticLocation);
        
    	AddSingleTagInternal(TaskID, GridCoord);
    }
}

void UC7MapTagInfoManager::AddSingleTagInternal(const FString& TaskID, const FGridCoord& GridCoord)
{
	// 添加到格子映射
	if (!GridToTaskIDsMap.Contains(GridCoord))
	{
		GridToTaskIDsMap.Add(GridCoord, TArray<FString>());
	}
	if (!GridToTaskIDsMap[GridCoord].Contains(TaskID))
	{
		GridToTaskIDsMap[GridCoord].Add(TaskID);
	}
        
	// 添加到反向映射
	TaskIDToGridMap.Add(TaskID, GridCoord);
}

void UC7MapTagInfoManager::RemoveSingleTag(const FString& TaskID)
{
    if (FGridCoord* GridCoord = TaskIDToGridMap.Find(TaskID))
    {
        // 从格子映射中移除
        if (TArray<FString>* TaskIDs = GridToTaskIDsMap.Find(*GridCoord))
        {
            TaskIDs->Remove(TaskID);
            if (TaskIDs->Num() == 0)
            {
                GridToTaskIDsMap.Remove(*GridCoord);
            }
        }
        
        // 从反向映射中移除
        TaskIDToGridMap.Remove(TaskID);
    }
}

void UC7MapTagInfoManager::UpdateTagLocation(const FString& TaskID, const FVector& NewLocation)
{
	if (!MapTagInfoData)
	{
		return;
	}
	
    // 先移除旧的格子映射
    RemoveSingleTag(TaskID);
    
    // 更新MapTagInfoData中的位置
    if (FMapTagInfo* TagInfo = MapTagInfoData->Find(TaskID))
    {
        TagInfo->StaticLocation = NewLocation;
    }
	
    // 重新添加到新的格子
    AddSingleTag(TaskID);
}

TArray<FGridCoord> UC7MapTagInfoManager::GetSurroundingGrids(const FGridCoord& CenterGrid) const
{
    TArray<FGridCoord> SurroundingGrids;
    
    for (int32 x = -1; x <= 1; x++)
    {
        for (int32 y = -1; y <= 1; y++)
        {
            SurroundingGrids.Add(FGridCoord(CenterGrid.X + x, CenterGrid.Y + y));
        }
    }
    
    return SurroundingGrids;
}

void UC7MapTagInfoManager::UpdateCharacterPosition(const FVector& CharacterLocation)
{
    FGridCoord NewCharacterGrid = WorldToGrid(CharacterLocation);
    
    // 如果角色还在同一个格子，不需要更新
    if (NewCharacterGrid == CurrentCharacterGrid)
    {
        return;
    }
    
    // 获取新旧九宫格范围
    TArray<FGridCoord> NewSurroundingGrids = GetSurroundingGrids(NewCharacterGrid);
    TArray<FGridCoord> OldSurroundingGrids = GetSurroundingGrids(CurrentCharacterGrid);
    
    TSet<FGridCoord> NewGridSet(NewSurroundingGrids);
    TSet<FGridCoord> OldGridSet(OldSurroundingGrids);
    
    // 找出需要卸载的格子
    for (const FGridCoord& OldGrid : OldGridSet)
    {
        if (!NewGridSet.Contains(OldGrid))
        {
            UnloadGrid(OldGrid);
        }
    }
    
    // 找出需要加载的格子
    for (const FGridCoord& NewGrid : NewGridSet)
    {
        if (!CurrentLoadedGrids.Contains(NewGrid))
        {
            LoadGrid(NewGrid);
        }
    }
    
    // 更新当前格子
    CurrentCharacterGrid = NewCharacterGrid;
}

void UC7MapTagInfoManager::UpdateFollowTagInfo()
{
	if (!MapTagInfoData || !FollowUpdateList || FollowUpdateList->IsEmpty())
    {
        return;
    }

	// 每 LowFrequencyUpdateInterval 帧更新一次九宫格外的图标格子状态
	constexpr int32 LowFrequencyUpdateInterval = 5;
	bool bShouldDoLowFrequencyUpdate = false;
	static int32 LowFrequencyUpdateCounter = 0;
	LowFrequencyUpdateCounter = LowFrequencyUpdateCounter % LowFrequencyUpdateInterval;
    if (LowFrequencyUpdateCounter == 0)
    {
    	bShouldDoLowFrequencyUpdate = true;
    }
    LowFrequencyUpdateCounter++;
    
    // 遍历所有需要跟随更新的标签
    for (const FString& TaskID : *FollowUpdateList)
    {
        // 获取标签信息
        FMapTagInfo* TagInfo = MapTagInfoData->Find(TaskID);
        if (!TagInfo)
        {
            continue;
        }
        
        // 计算新的格子坐标
        FGridCoord NewGridCoord;
    	if (TagInfo->MapTagType == EMapTagType::Static)
    	{
    		NewGridCoord = WorldToGrid(TagInfo->StaticLocation);
    	}
    	else if (TagInfo->MapTagType == EMapTagType::FollowActor)
    	{
    		AActor* Follower = KGUtils::GetActorByID(TagInfo->FollowerID);
    		if (IsValid(Follower))
    		{
    			NewGridCoord = WorldToGrid(Follower->K2_GetActorLocation());
    		}
    	}
	    else
	    {
		    UE_LOG(LogTemp, Log, TEXT("%s Invalid MapTagType: %d"), *TaskID, TagInfo->MapTagType);
	    	continue;
	    }
        
        // 检查标签是否在当前九宫格内
        const bool bIsInCurrentGrids = CurrentLoadedGrids.Contains(NewGridCoord);
        
        // 决定是否更新这个标签
        bool bShouldUpdateThisTag = false;
        if (bIsInCurrentGrids || bShouldDoLowFrequencyUpdate)
        {
            // 九宫格内的标签：每帧都更新
            // 九宫格外的标签：只在低频更新时处理
            bShouldUpdateThisTag = true;
        }
        
        if (!bShouldUpdateThisTag)
        {
            continue; // 跳过这个标签
        }
        
        // 获取任务在格子映射中的旧坐标
        FGridCoord* CurrentGridCoordPtr = TaskIDToGridMap.Find(TaskID);
    	
        // 如果任务在格子映射中的位置也需要更新
        if (CurrentGridCoordPtr && *CurrentGridCoordPtr != NewGridCoord)
        {
            // 从旧格子中移除
            RemoveSingleTag(TaskID);

        	AddSingleTagInternal(TaskID, NewGridCoord);
        }
        else if (!CurrentGridCoordPtr)
        {
            // 这是一个新标签，还没有添加到格子映射中
        	AddSingleTagInternal(TaskID, NewGridCoord);
        }
    }
}

void UC7MapTagInfoManager::ClearAllTags()
{
	GridToTaskIDsMap.Empty();
	TaskIDToGridMap.Empty();
	CurrentLoadedGrids.Empty();
	CurrentCharacterGrid = FGridCoord(INT32_MAX - 1, INT32_MAX - 1);
}

void UC7MapTagInfoManager::LoadGrid(const FGridCoord& GridCoord)
{
	if (!MapTagInfoData)
	{
		return;
	}
	
    // if (TArray<FString>* TaskIDs = GridToTaskIDsMap.Find(GridCoord))
    // {
    //     for (const FString& TaskID : *TaskIDs)
    //     {
    //         // 在这里实现图标的加载逻辑
    //         if (FMapTagInfo* TagInfo = MapTagInfoData->Find(TaskID))
    //         {
    //             // 创建小地图图标UI，设置位置等
    //             UE_LOG(LogTemp, Log, TEXT("Loading tag: %s at grid (%d, %d)"), 
    //                    *TaskID, GridCoord.X, GridCoord.Y);
    //         }
    //     }
    // }
    
    CurrentLoadedGrids.Add(GridCoord);
}

void UC7MapTagInfoManager::UnloadGrid(const FGridCoord& GridCoord)
{
    // if (TArray<FString>* TaskIDs = GridToTaskIDsMap.Find(GridCoord))
    // {
    //     for (const FString& TaskID : *TaskIDs)
    //     {
    //         // 在这里实现图标的卸载逻辑
    //         UE_LOG(LogTemp, Log, TEXT("Unloading tag: %s from grid (%d, %d)"), 
    //                *TaskID, GridCoord.X, GridCoord.Y);
    //     }
    // }
    
    CurrentLoadedGrids.Remove(GridCoord);
}

TArray<FString> UC7MapTagInfoManager::GetCurrentTaskIDs() const
{
    TArray<FString> CurrentTaskIDs;
    
    for (const FGridCoord& Grid : CurrentLoadedGrids)
    {
        if (const TArray<FString>* TaskIDs = GridToTaskIDsMap.Find(Grid))
        {
            CurrentTaskIDs.Append(*TaskIDs);
        }
    }
    
    return CurrentTaskIDs;
}

FMapTagInfo* UC7MapTagInfoManager::GetMapTagInfo(const FString& TaskID)
{
	if (!MapTagInfoData)
	{
		return nullptr;
	}

    return MapTagInfoData->Find(TaskID);
}
