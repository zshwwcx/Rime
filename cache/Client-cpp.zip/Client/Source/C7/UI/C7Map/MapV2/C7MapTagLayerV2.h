#pragma once
#include "CoreMinimal.h"
#include "Blueprint/UserWidgetPool.h"
#include "Components/CanvasPanel.h"
#include "Misc/CommonDefines.h"
#include "UMG/Components/KGMapTagLayer.h"
#include "C7MapTagInfoManager.h"

#include "C7MapTagLayerV2.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_FourParams(FOnMapTagInitializedDynamic, UUserWidget*, Widget, int32, TypeID, FString, TaskID, bool, bInEdge);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FOnMapTagRemovedDynamic, UUserWidget*, Widget, int32, TypeID, FString, TaskID);

UCLASS(meta = (ShortTooltip = "Specialized for calculate transform of Map Tags, should only be used in MapSystem"))
class UC7MapTagLayerV2 : public UCanvasPanel, public FTickableGameObject
{
	GENERATED_BODY()
public:
	UC7MapTagLayerV2(const FObjectInitializer& Initializer);

	UFUNCTION(BlueprintCallable)
	void InitMapTagInfoManager();

    bool bCanTick = false;;
    bool bNeedUpdateTagAfterWidgetRendered = false;
	bool bViewportStatChanged = false;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector CameraLocation;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FRotator CameraRotation;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector2D CameraViewportSize;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float ViewportScale = 1.0f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector2D CurrentCenterLocation;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float CurrentRotationByClockWise = .0f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float ConstraintRadius;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector4 ConstraintRectangle;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	EMapShowTypeOnEdge PanelMapEdgeType = EMapShowTypeOnEdge::ShowOnEdgeByRectangle;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bMiniMap = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    bool bSameWithMapTexture = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int32 MapTextureWidth = 2048;
    
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int32 MapTextureHeight = 2048;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FVector2D TagUniformScale;
    
	UFUNCTION()
	void SetCameraLocation(FVector& _CameraLocation) {
		if (!(CameraLocation - _CameraLocation).IsNearlyZero())
		{
			bViewportStatChanged = true;
		}
		CameraLocation = _CameraLocation;
	}
	UFUNCTION()
	FVector GetCameraLocation() const {
		return CameraLocation;
	}
	UFUNCTION()
	void SetCameraRotation(FRotator& _CameraRotation) {
		if (!(CameraRotation - _CameraRotation).IsNearlyZero())
		{
			bViewportStatChanged = true;
		}
		CameraRotation = _CameraRotation;
	}
	UFUNCTION()
	FRotator GetCameraRotation() const {
		return CameraRotation;
	}
	UFUNCTION()
	void SetCameraViewportSize(FVector2D& _CameraViewportSize) {
		if (!(CameraViewportSize - _CameraViewportSize).IsNearlyZero())
		{
			bViewportStatChanged = true;
		}
		CameraViewportSize = _CameraViewportSize;
	}
	UFUNCTION()
	FVector2D GetCameraViewportSize() const {
		return CameraViewportSize;
	}

	UFUNCTION()
	void SetViewportScale(float _ViewportScale);
	UFUNCTION()
	float GetViewportScale() const {
		return ViewportScale;
	}
	UFUNCTION()
	void SetCurrentCenterLocation(FVector2D _CurrentCenterLocation);
	UFUNCTION()
	FVector2D GetCurrentCenterLocation() const {
		return CurrentCenterLocation;
	}

    UFUNCTION()
    bool CanTick() const { return bCanTick; }
    UFUNCTION()
    void SetCanTick(bool bInCanTick) { bCanTick = bInCanTick; }
private:

	void AdaptOverlappingCircles();

	virtual void Tick(float DeltaTime) override;

	virtual bool IsTickable() const override 
	{
		return !HasAnyFlags(RF_BeginDestroyed | RF_ClassDefaultObject | RF_ArchetypeObject) && IsValidChecked(this) && bCanTick;
	}

	virtual TStatId GetStatId() const override {
		return GetStatID();
	}

	UPROPERTY(Transient)
	FUserWidgetPool EntryWidgetPool;

public:
	//UFUNCTION()
	TObjectPtr<UUserWidget> GetWidgetFromPool(TSubclassOf<UUserWidget> WidgetType);

	//UFUNCTION()
	void ReturnWidgetToPool(TObjectPtr<UUserWidget> UserWidget);

	virtual void ReleaseSlateResources(bool  bReleaseChildren) override;


	//几个上下文之间的关系：WidgetOffset [0,1]x[0,1],只是CanvasPanel上Slot的范围
	//WorldOffset, 在相机平面上的Offset, 值域CameraViewportSize
	//WorldLocation，原本的世界位置[-\Infinity, \Infinity]^3
	UFUNCTION(BlueprintCallable)
	virtual FVector2D GetWidgetOffsetByMapTagInfo(FMapTagInfo MapTagInfo);

	UFUNCTION(BlueprintCallable)
	virtual FVector2D GetWidgetPosByMapTagInfo(FMapTagInfo MapTagInfo);

	UFUNCTION(BlueprintCallable)
	FVector2D GetWidgetOffsetByWorldLocation(FVector Location);
	UFUNCTION(BlueprintCallable)
	FVector2D GetWorldOffsetByWorldLocation(FVector Location);
	UFUNCTION(BlueprintCallable)
	virtual FVector2D DeprojectWidgetOffsetToWorldLocation(FVector2D WidgetOffset);

	UFUNCTION(BlueprintCallable)
	FVector2D GetWidgetOffsetByCenterAndWorldLocation(FVector& Location);

    UFUNCTION(BlueprintCallable)
    void GetWidgetOffsetByCenterAndWorldLocationPlain(float WorldPosX, float WorldPosY, float WorldPosZ, float& X, float& Y);
    
	UFUNCTION(BlueprintCallable)
	TArray<FString> ReqTaskNearByByTaskID(FString TaskID, float ToleranceDistance);
    UFUNCTION(BlueprintCallable)
    TArray<FString> ReqInteractableTaskNearByByTaskID(FString TaskID, float ToleranceDistance, bool bRequireCenter = true);

	UFUNCTION(BlueprintCallable)
	float GetWidgetShearByWorldRotation(const FRotator& Rotation);
	UFUNCTION(BlueprintCallable)
	float GetWidgetShearByTaskID(FString TaskID);

	UFUNCTION(BlueprintCallable)
	FVector2D GetWidgetPosByTaskID(FString TaskID);

    UFUNCTION(BlueprintCallable)
    void SetTagUniformScale(float InScaleX, float InScaleY);

	UFUNCTION(BlueprintCallable)
	FVector2D CircleConvert(FVector2D WidgetOffset)
	{
		FVector2D Origin(0.5f, 0.5f);
		FVector2D ConvertedOffset = ConstraintRadius * (WidgetOffset - Origin).GetSafeNormal() + Origin;
		return ConvertedOffset;
	}
	UFUNCTION(BlueprintCallable)
	FVector2D RectangleConvert(FVector2D WidgetOffset)
	{
		FVector2D Origin(0.5f, 0.5f);
		FVector2D DirectionVec = (WidgetOffset - Origin).GetSafeNormal();
		DirectionVec = DirectionVec.X < (-0.5f + ConstraintRectangle.X) ? (-0.5f + ConstraintRectangle.X) / DirectionVec.X * DirectionVec :
			DirectionVec.Y >(0.5f - ConstraintRectangle.Y) ? (0.5f - ConstraintRectangle.Y) / DirectionVec.Y * DirectionVec :
			DirectionVec.X > (0.5f - ConstraintRectangle.Z) ? (0.5f - ConstraintRectangle.Z) / DirectionVec.X * DirectionVec :
			(-0.5f + ConstraintRectangle.W) / DirectionVec.Y * DirectionVec;
		FVector2D ConvertedOffset = DirectionVec + Origin;
		return ConvertedOffset;
	}
	UFUNCTION(BlueprintCallable)
	void SetData(TMap<FString, FMapTagInfo> _MapTagInfoData);

	UFUNCTION(BlueprintCallable)
	void SetTaskShowEdgeType(const FString& TaskID, EMapEdgeType ShowOnEdgeType);

	UFUNCTION(BlueprintCallable)
	void RetargetTagLocation(const FString& TaskID, const FVector& Location);

	UFUNCTION(BlueprintCallable)
	void ReSetTaskTypeToFollowActor(const FString& TaskID, int64 ActorID);

	UFUNCTION(BlueprintCallable)
	void ReSetTaskTypeToStatic(const FString& TaskID);

    UFUNCTION(BlueprintCallable)
    void SetTaskInteractable(const FString& TaskID, bool bInteractable);

	UFUNCTION(BlueprintCallable)
	void AddSingleTag(FMapTagInfo _MapTagInfo);

	UFUNCTION(BlueprintCallable)
	void ClearAllTags();

	UFUNCTION(BlueprintCallable)
	void BatchAddTags(TMap<FString, FMapTagInfo> _MapTagInfos);

	UFUNCTION(BlueprintCallable)
	void BatckRemoveTags(TArray<FString> TaskIDs);

	UFUNCTION(BlueprintCallable)
	void RemoveSingleTag(const FString& TaskID);
    
	void UpdateSingleTagByID(const FString& TaskID);

	UPROPERTY(Transient)
	TMap <FString, FMapTagInfo> MapTagInfoData;

	UPROPERTY(Transient)
	UC7MapTagInfoManager* C7MapTagInfoManager;

	UPROPERTY(Transient)
	TArray<FString> EdgeList;

	UPROPERTY(Transient)
	TArray<FString> PendingUpdateList;

	UPROPERTY(Transient)
	TArray<FString> PendingRemoveList;

	UPROPERTY(Transient)
	TArray<FString> FollowUpdateList;

	UPROPERTY(Transient)
	TArray<FString> TempIterateList;

	UPROPERTY(Transient)
	TMap<FString, FMapEdgeRotateInfo> RotateWidgetList;

	UPROPERTY(Transient)
	int64 CenterActorID = 0;//小地图中使用，中心位置由Actor位置决定

	UFUNCTION(BlueprintCallable)
	void SetCenterActor(int64 _CenterActorID);

	UFUNCTION(BlueprintCallable)
	void ResetCenterActor();

	UFUNCTION(BlueprintCallable)
	void RegisterWidgetRotateInEdge(const FString& TaskID, UWidget* Widget, float Offset);

	UFUNCTION(BlueprintCallable)
	void UnRegisterWidgetRotateInEdge(const FString& TaskID);

	void ResetEdgeWidgetShear(const FMapEdgeRotateInfo& MapEdgeRotateInfo);

	UPROPERTY(BlueprintAssignable, Category = Events)
	FOnMapTagInitializedDynamic OnMapTagInitializedDynamic;
	UPROPERTY(BlueprintAssignable, Category = Events)
	FOnMapTagRemovedDynamic OnMapTagRemovedDynamic;

	bool InRectangle(FVector2D WidgetOffset)
	{
		return WidgetOffset.X > ConstraintRectangle.X && WidgetOffset.Y > ConstraintRectangle.Y && WidgetOffset.X < (1.0f - ConstraintRectangle.Z) && WidgetOffset.Y < (1.0f - ConstraintRectangle.W);
	}

	bool InCircle(FVector2D WidgetOffset)
	{
		const float aspectRatio = CameraViewportSize.X / CameraViewportSize.Y;
		if (aspectRatio == 1)
		{
			return (WidgetOffset - FVector2D(0.5f, 0.5f)).Length() < ConstraintRadius;
		}

		const float xOffset = WidgetOffset.X - 0.5f;
		const float yOffset = WidgetOffset.Y - 0.5f;
		const float yConstraint = ConstraintRadius * aspectRatio;
		return (xOffset * xOffset) / (ConstraintRadius * ConstraintRadius) + (yOffset * yOffset) / (yConstraint * yConstraint) < 1;
	}
	bool static InCenter(FVector2D WidgetOffset)
	{
		return WidgetOffset.X > 0.0f && WidgetOffset.Y > 0.0f && WidgetOffset.X < 1.0f && WidgetOffset.Y < 1.0f;
	}

	EMapDisplayState GetNewMapDisplayState(const FMapTagInfo& MapTagInfoData);
private:
    UFUNCTION()
    void OnMapTagClassLoaded(int InLoadID, UObject* Asset);
    UObject* AsyncLoad(const FString& InWidgetSoftClassPath, const FString& InTaskID);
    FVector2D AdjustForNoneSameWithMapTexture(FVector2D& InRes);
private:
    struct FLoadingHandle
    {
        int32 LoadID;
        FString Path;
        TArray<FString> TaskIDs;
    };
    TMap<int32, FLoadingHandle> AssetsInLoading;
};