#include "C7WorldMapTagLayer.h"

#include "3C/Util/KGUtils.h"

#pragma optimize("", off)

UC7WorldMapTagLayer::UC7WorldMapTagLayer(const FObjectInitializer& Initializer)
    : Super(Initializer)
{
}

void UC7WorldMapTagLayer::SetCityMapInfoData(const TMap<int32, FCityMapInfo>& _CityMapInfoData)
{
	CityMapInfoData = _CityMapInfoData;
}

void UC7WorldMapTagLayer::ClearCityMapInfoData()
{
	CityMapInfoData.Empty();
}

void UC7WorldMapTagLayer::SetTagCityMapData(const TMap<FString, int32>& _TagCityMapData)
{
	TagCityMapData = _TagCityMapData;
}

void UC7WorldMapTagLayer::AddSingleTagCityMap(FString TaskID, int32 MapID)
{
	if (TagCityMapData.Find(TaskID))
	{
		TagCityMapData[TaskID] = MapID;
	}
	else
	{
		TagCityMapData.Add(TaskID, MapID);
	}
}

void UC7WorldMapTagLayer::RemoveSingleTagCityMap(FString TaskID)
{
	if (TagCityMapData.Find(TaskID))
	{
		TagCityMapData.Remove(TaskID);
	}
}

void UC7WorldMapTagLayer::ClearTagCityMapData()
{
	TagCityMapData.Empty();
}

void UC7WorldMapTagLayer::SetCountryMapInfoData(const TMap<int32, FCountryMapInfo>& _CountryMapInfoData)
{
	CountryMapInfoData = _CountryMapInfoData;
}

void UC7WorldMapTagLayer::ClearCountryMapInfoData()
{
	CountryMapInfoData.Empty();
}

void UC7WorldMapTagLayer::SetCityCountryMapData(const TMap<int32, int32>& _CityCountryMapData)
{
	CityCountryMapData = _CityCountryMapData;
}

void UC7WorldMapTagLayer::ClearCityCountryMapData()
{
	TagCityMapData.Empty();
}

FVector2D UC7WorldMapTagLayer::GetWidgetOffsetByMapTagInfo(FMapTagInfo MapTagInfo)
{
	int32* CityMapIDIt = TagCityMapData.Find(MapTagInfo.TaskID);
	FCityMapInfo* CityMapInfoIt = CityMapIDIt != nullptr ? CityMapInfoData.Find(*CityMapIDIt) : nullptr;
	int32* CountryMapIDIt = CityMapIDIt != nullptr ? CityCountryMapData.Find(*CityMapIDIt) : nullptr;
	FCountryMapInfo* CountryMapInfoIt = CountryMapIDIt != nullptr ? CountryMapInfoData.Find(*CountryMapIDIt) : nullptr;
	FVector2D OriginOffset = GetWidgetOffsetByWorldLocation(GetWorldLocation(MapTagInfo), CityMapInfoIt, CountryMapInfoIt);

	const FVector2D CenterVector = FVector2D(0.5f, 0.5f);
	FVector2D ScaledOffset = CenterVector + (OriginOffset - CenterVector) * ViewportScale;
	FVector2D CenterOffset = (CenterVector - CurrentCenterLocation / CameraViewportSize) * ViewportScale;
	return ScaledOffset + CenterOffset;
}

FVector2D UC7WorldMapTagLayer::GetWidgetPosByMapTagInfo(FMapTagInfo MapTagInfo)
{
	int32* CityMapIDIt = TagCityMapData.Find(MapTagInfo.TaskID);
	FCityMapInfo* CityMapInfoIt = CityMapIDIt != nullptr ? CityMapInfoData.Find(*CityMapIDIt) : nullptr;
	if (CityMapInfoIt == nullptr)
	{
		return Super::GetWidgetPosByMapTagInfo(MapTagInfo);
	}

	int32* CountryMapIDIt = CityMapIDIt != nullptr ? CityCountryMapData.Find(*CityMapIDIt) : nullptr;
	FCountryMapInfo* CountryMapInfoIt = CountryMapIDIt != nullptr ? CountryMapInfoData.Find(*CountryMapIDIt) : nullptr;
	FVector2D OriginOffset = GetWidgetOffsetByWorldLocation(GetWorldLocation(MapTagInfo), CityMapInfoIt, CountryMapInfoIt);
	return OriginOffset * CameraViewportSize;
}

FVector2D UC7WorldMapTagLayer::DeprojectWidgetOffsetToWorldLocation(FVector2D WidgetOffset)
{
	FVector2D WorldOffset = (WidgetOffset - FVector2D(0.5, 0.5)) * CameraViewportSize;
	FVector4 LHS(WorldOffset.X, WorldOffset.Y, .0f, .0f);
	FVector Right = CameraRotation.RotateVector(FVector(0, 1, 0));
	FVector Up = CameraRotation.RotateVector(FVector(0, 0, -1));
	FVector Forward = CameraRotation.RotateVector(FVector(-1, 0, 0));
	FMatrix Mat;
	Mat.SetIdentity();
	Mat.SetColumn(0, Right);
	Mat.SetColumn(1, Up);
	Mat.SetColumn(2, Forward);
	FVector4 RHS = Mat.GetTransposed().TransformFVector4(LHS); //正交矩阵，转置就是逆
	FVector RHS3(RHS.X, RHS.Y, RHS.Z);
	RHS3 += CameraLocation;

	return FVector2D(RHS3.X, RHS3.Y);
}

float UC7WorldMapTagLayer::GetWidgetShearByWorldRotationAndTaskID(const FRotator& Rotation, const FString& TaskID)
{
	int32* CityMapIDIt = TagCityMapData.Find(TaskID);
	FCityMapInfo* CityMapInfoIt = CityMapIDIt != nullptr ? CityMapInfoData.Find(*CityMapIDIt) : nullptr;
	if (CityMapInfoIt == nullptr)
	{
		return GetWidgetShearByWorldRotation(Rotation);
	}

	FVector ForwardVector = Rotation.Vector() * 1000;
	// 计算角度只需要到城市地图层级即可，场景相关参数是和城市地图关联的
	FVector2D Triangle = GetWidgetOffsetByWorldLocation(ForwardVector, CityMapInfoIt, nullptr) - GetWidgetOffsetByWorldLocation(FVector::ZeroVector, CityMapInfoIt, nullptr);
	Triangle.Normalize();
	if (Triangle.X > .0f)
	{
		return FMath::Acos(Triangle.Y);
	}
	else // if(Triangle.X < .0f)
	{
		return 2 * UE_DOUBLE_PI - FMath::Acos(Triangle.Y);
	}
	// return .0f;
}

FVector UC7WorldMapTagLayer::GetWorldLocation(const FMapTagInfo& MapTagInfo)
{
	if (MapTagInfo.MapTagType == EMapTagType::Static)
	{
		return MapTagInfo.StaticLocation;
	}
	else if (MapTagInfo.MapTagType == EMapTagType::FollowActor)
	{
		AActor* Follower = KGUtils::GetActorByID(MapTagInfo.FollowerID);
		if (IsValid(Follower))
		{
			return Follower->K2_GetActorLocation();
		}
	}

	return FVector::ZeroVector;
}

FVector2D UC7WorldMapTagLayer::GetWidgetOffsetByWorldLocation(const FVector& WorldLocation, const FCityMapInfo* CityMapInfo, const FCountryMapInfo* CountryMapInfo)
{
	if (CityMapInfo == nullptr)
	{
		return GetWidgetOffsetByWorldLocation(WorldLocation);
	}

	if (CountryMapInfo == nullptr)
	{
		return GetWidgetOffsetByWorldLocation(WorldLocation, *CityMapInfo);
	}

	return GetWidgetOffsetByWorldLocation(WorldLocation, *CityMapInfo, *CountryMapInfo);
}

FVector2D UC7WorldMapTagLayer::GetWidgetOffsetByWorldLocation(const FVector& WorldLocation)
{
	FVector2D WorldOffset = GetWorldOffsetByWorldLocation(WorldLocation, CameraLocation, CameraRotation, CameraViewportSize);
	return WorldOffset / CameraViewportSize;
}

FVector2D UC7WorldMapTagLayer::GetWidgetOffsetByWorldLocation(const FVector& WorldLocation, const FCityMapInfo& CityMapInfo)
{
	FVector2D WorldOffset = GetWorldOffsetByWorldLocation(WorldLocation, CityMapInfo.CameraLocation, CityMapInfo.CameraRotation, CityMapInfo.CameraViewportSize);
	FVector2D OriginOffset = WorldOffset / CityMapInfo.CameraViewportSize;
	return OriginOffset * CityMapInfo.MapScale + CityMapInfo.MapOffset;
}

FVector2D UC7WorldMapTagLayer::GetWidgetOffsetByWorldLocation(const FVector& WorldLocation, const FCityMapInfo& CityMapInfo, const FCountryMapInfo& countryMapInfo)
{
	FVector2D OriginOffset = GetWidgetOffsetByWorldLocation(WorldLocation, CityMapInfo);
	return OriginOffset * countryMapInfo.MapScale + countryMapInfo.MapOffset;
}

FVector2D UC7WorldMapTagLayer::GetWorldOffsetByWorldLocation(const FVector& WorldLocation, const FVector& CameraLocation, const FRotator& CameraRotation, const FVector2D& CameraViewportSize)
{
	//相机以Z轴负方向为Up，Y轴正方向为Right
	FVector Up = CameraRotation.RotateVector(FVector(0, 0, -1));
	//FVector Forward = CameraRotation.RotateVector(FVector(1,0,0));
	FVector Right = CameraRotation.RotateVector(FVector(0, 1, 0));
	FVector WorldVec = WorldLocation - CameraLocation;
	return FVector2D(WorldVec.Dot(Right), WorldVec.Dot(Up)) + CameraViewportSize * 0.5f;
}

#pragma optimize("", on)
