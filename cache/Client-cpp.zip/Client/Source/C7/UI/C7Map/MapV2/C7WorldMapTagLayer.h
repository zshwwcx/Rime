#pragma once
#include "C7MapTagLayerV2.h"

#include "C7WorldMapTagLayer.generated.h"

USTRUCT(BlueprintType)
struct FCityMapInfo
{
	GENERATED_BODY()

	UPROPERTY(EditAnyWhere, BlueprintReadWrite)
	int32 MapID = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector CameraLocation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FRotator CameraRotation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector2D CameraViewportSize;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector2D MapScale;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector2D MapOffset;
};

USTRUCT(BlueprintType)
struct FCountryMapInfo
{
	GENERATED_BODY()

	UPROPERTY(EditAnyWhere, BlueprintReadWrite)
	int32 MapID = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector2D MapScale;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector2D MapOffset;
};

UCLASS(meta = (ShortTooltip = "Specialized for calculate transform of World Map Tags, should only be used in MapSystem"))
class UC7WorldMapTagLayer : public UC7MapTagLayerV2
{
	GENERATED_BODY()

public:
	UC7WorldMapTagLayer(const FObjectInitializer& Initializer);

public:
	UFUNCTION(BlueprintCallable)
	void SetCityMapInfoData(const TMap<int32, FCityMapInfo>& _CityMapInfoData);

	UFUNCTION(BlueprintCallable)
	void ClearCityMapInfoData();

	UPROPERTY(Transient)
	TMap<int32, FCityMapInfo> CityMapInfoData;

	UFUNCTION(BlueprintCallable)
	void SetTagCityMapData(const TMap<FString, int32>& _TagCityMapData);

	UFUNCTION(BlueprintCallable)
	void AddSingleTagCityMap(FString TaskID, int32 MapID);

	UFUNCTION(BlueprintCallable)
	void RemoveSingleTagCityMap(FString TaskID);

	UFUNCTION(BlueprintCallable)
	void ClearTagCityMapData();

	UPROPERTY(Transient)
	TMap<FString, int32> TagCityMapData;

public:
	UFUNCTION(BlueprintCallable)
	void SetCountryMapInfoData(const TMap<int32, FCountryMapInfo>& _CountryMapInfoData);

	UFUNCTION(BlueprintCallable)
	void ClearCountryMapInfoData();

	UPROPERTY(Transient)
	TMap<int32, FCountryMapInfo> CountryMapInfoData;

	UFUNCTION(BlueprintCallable)
	void SetCityCountryMapData(const TMap<int32, int32>& _CityCountryMapData);

	UFUNCTION(BlueprintCallable)
	void ClearCityCountryMapData();

	UPROPERTY(Transient)
	TMap<int32, int32> CityCountryMapData;

public:
	virtual FVector2D GetWidgetOffsetByMapTagInfo(FMapTagInfo MapTagInfo) override;
	virtual FVector2D GetWidgetPosByMapTagInfo(FMapTagInfo MapTagInfo) override;
	virtual FVector2D DeprojectWidgetOffsetToWorldLocation(FVector2D WidgetOffset) override;

	UFUNCTION(BlueprintCallable)
	float GetWidgetShearByWorldRotationAndTaskID(const FRotator& Rotation, const FString& TaskID);

protected:
	FVector GetWorldLocation(const FMapTagInfo& MapTagInfo);
	FVector2D GetWidgetOffsetByWorldLocation(const FVector& WorldLocation, const FCityMapInfo* CityMapInfo, const FCountryMapInfo* CountryMapInfo);

	FVector2D GetWidgetOffsetByWorldLocation(const FVector& WorldLocation);
	static FVector2D GetWidgetOffsetByWorldLocation(const FVector& WorldLocation, const FCityMapInfo& CityMapInfo);
	static FVector2D GetWidgetOffsetByWorldLocation(const FVector& WorldLocation, const FCityMapInfo& CityMapInfo, const FCountryMapInfo& countryMapInfo);

	static FVector2D GetWorldOffsetByWorldLocation(const FVector& WorldLocation, const FVector& CameraLocation, const FRotator& CameraRotation, const FVector2D& CameraViewportSize);
};
