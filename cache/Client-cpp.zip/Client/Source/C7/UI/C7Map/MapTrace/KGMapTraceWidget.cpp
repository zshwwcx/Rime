#include "KGMapTraceWidget.h"
#include "SKGMapTraceWidget.h"

UKGMapTraceWidget::UKGMapTraceWidget(const FObjectInitializer& ObjectInitializer)
    : Super(ObjectInitializer)
{}

TSharedRef<SWidget> UKGMapTraceWidget::RebuildWidget()
{
    MyTraceWidget = SNew(SKGMapTraceWidget).DesiredSizeOverride(DesiredSizeOverride).
        PointSizeOverride(PointSizeOverride).TracePoints(&TracePoints).TraceImage(&Brush)
        .PointDistanceOverride(PointDistanceOverride);
    return MyTraceWidget.ToSharedRef();
}

C7_API void UKGMapTraceWidget::ReleaseSlateResources(bool bReleaseChildren)
{
    Super::ReleaseSlateResources(bReleaseChildren);
    MyTraceWidget.Reset();
}


void UKGMapTraceWidget::SetTracePointIndex(const int32 Index)
{
    if (Index < 0)
    {
        UE_LOG(LogTemp, Warning, TEXT("%s: index is negative: Index = %d"), ANSI_TO_TCHAR(__FUNCTION__), Index);
        return;
    }
    
    TracePointIndex = Index;
    if (MyTraceWidget.IsValid())
    {
        MyTraceWidget->SetTracePointIndex(Index);
    }
}

void UKGMapTraceWidget::SetDesiredSizeOverride(const FVector2f& DesiredSize)
{
    DesiredSizeOverride = DesiredSize;
    if (MyTraceWidget.IsValid())
    {
        MyTraceWidget->SetDesiredSizeOverride(DesiredSizeOverride);
    }
}