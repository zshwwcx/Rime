#if !UE_BUILD_SHIPPING

#include "LuaInsightTracer.h"
#include "GenericPlatform/GenericPlatformFile.h"
#include "HAL/PlatformFile.h"
#include "HAL/PlatformMisc.h"
#include "Containers/UnrealString.h"
#include "Misc/CString.h"

#include <string>
#include <time.h>
#include <chrono>
#include <list>

#if ENABLE_LOW_LEVEL_MEM_TRACKER
LLM_DEFINE_TAG(C7LuaMem);
#endif

using namespace C7;

// 简易对象缓存池
template<typename T>
class SimpleObjectCache 
{
protected:
	int CacheSize = 0;
	int CacheIncrCount = 1000;
	int CacheFree = -1;
	T** Objects = nullptr;
public:
	static SimpleObjectCache& GetInstance()
	{
		static SimpleObjectCache inst;
		return inst;
	}
	T* New()
	{
		if (CacheFree < 0)
		{
			return new T();
		}
		auto ret = Objects[CacheFree];
		ret->OnNew();
		CacheFree--;
		return ret;
	}
	void Free(T* obj)
	{
		obj->OnFree();
		if (CacheFree + 1 >= CacheSize || CacheSize == 0)
		{
			int newCount = CacheSize + CacheIncrCount;
			T** newObj = new T*[newCount];
			if (Objects != nullptr) {
				FMemory::Memcpy(newObj, Objects, CacheSize * sizeof(T*));
			}
			CacheSize = newCount;
			delete[] Objects;
			Objects = newObj;
		}
		CacheFree++;
		Objects[CacheFree] = obj;
	}
	void ResetAll()
	{
		for (int i = 0;i <= CacheFree; ++i)
		{
			delete Objects[i];
		}
		CacheSize = 0;
		CacheFree = -1;
		if (Objects != nullptr) delete[] Objects;
		Objects = nullptr;
	}
};

void LuaInsightTraceNode::OnRet()
{
#if ENABLE_LOW_LEVEL_MEM_TRACKER
	if (LLMTracer != nullptr)
	{
		delete LLMTracer;
		LLMTracer = nullptr;
	}
#endif
#if CPUPROFILERTRACE_ENABLED
	FCpuProfilerTrace::OutputEndEvent();
#endif
}
void LuaInsightTraceNode::OnNew()
{
	ParentNode = nullptr;
	FunctionAddress = nullptr;
	// FunctionName;
	// SourceInfo;
	LineNumber = 0;

#if ENABLE_LOW_LEVEL_MEM_TRACKER
	LLMTracer = nullptr;
#endif

	bTailCall = false;
}
void LuaInsightTraceNode::OnFree()
{
	
}
void LuaInsightTraceNode::OnMalloc(void* Ptr, int nSize)
{
	
}

void LuaInsightTraceNode::ResetObject()
{
	// 重置，可能放入对象池，把自己的tracker也清空一下，这个不能用对象池，因为依赖于析构去调用底层函数
#if ENABLE_LOW_LEVEL_MEM_TRACKER
	if (LLMTracer != nullptr)
	{
		delete LLMTracer;
		LLMTracer = nullptr;
	}
#endif
#if CPUPROFILERTRACE_ENABLED
	FCpuProfilerTrace::OutputEndEvent();
#endif
}

////////////////////// LuaTrace begin
void LuaInsightTracer::Init()
{
	RootNode = new LuaInsightTraceNode();
	CurrentNode = RootNode;
}

void LuaInsightTracer::DeInit()
{
	while (CurrentNode != RootNode && CurrentNode != nullptr)
	{
		auto node = CurrentNode;
		CurrentNode = CurrentNode->GetParent();
		node->ResetObject();
		delete node;
	}
	delete RootNode;
	RootNode = nullptr;
	CurrentNode = nullptr;
	SimpleObjectCache<LuaInsightTraceNode>::GetInstance().ResetAll();
}

void LuaInsightTracer::NextFrame()
{
	// 释放一下内存
	while (CurrentNode != RootNode && CurrentNode != nullptr)
	{
		auto node = CurrentNode;
		CurrentNode = CurrentNode->GetParent();
		node->ResetObject();
		SimpleObjectCache<LuaInsightTraceNode>::GetInstance().Free(node);
	}
}

void LuaInsightTracer::OnMalloc(void* Ptr, int nSize)
{
	if (CurrentNode)
	{
		CurrentNode->OnMalloc(Ptr, nSize);
	}
}

void LuaInsightTracer::OnHookCall(lua_State* L, lua_Debug* ar, bool bTailCall)
{
	static constexpr int BufferSize = 512;
	static TCHAR Buffer[BufferSize];

	lua_getinfo(L, "Sf", ar);
	void* fun_ptr = const_cast<void*>(lua_topointer(L, -1));
	lua_pop(L, 1);

	// C function won't emit return events, ignore all
	if (ar->what[0] == 'C') {
		if (CurrentNode != RootNode && bTailCall) {
			ProcessRet();
		}
		return;
	}

	if (UNLIKELY(fun_ptr == nullptr))
	{
		return;
	}

	uint32 SpecId = 0;
	if (auto SpecIdPtr = SpecIdMap.Find(fun_ptr))
	{
		SpecId = *SpecIdPtr;
	}
	else
	{
		lua_getinfo(L, "ntl", ar);
		if (ar->name) {
			   FCString::Snprintf(Buffer, BufferSize, TEXT("[C7LUA] %s [%s:%d:%d]"), UTF8_TO_TCHAR(ar->name),
								  UTF8_TO_TCHAR(ar->short_src),
								  ar->linedefined, ar->currentline);
		}
		else
		{
			   FCString::Snprintf(Buffer, BufferSize, TEXT("[C7LUA] %s [%s:%d:%d]"), TEXT("N/A"),
								  UTF8_TO_TCHAR(ar->short_src),
								  ar->linedefined, ar->currentline);
		}

		SpecId = FCpuProfilerTrace::OutputEventType(Buffer, "", 0);
		SpecIdMap.Add(fun_ptr, SpecId);
	}

	LuaInsightTraceNode *Node = SimpleObjectCache<LuaInsightTraceNode>::GetInstance().New();
	Node->SetParent(CurrentNode);
	Node->SetFun(fun_ptr);
	Node->bTailCall = bTailCall;

	CurrentNode = Node;
	CurrentNode->OnCall(SpecId);
}

void LuaInsightTracer::OnHookReturn(lua_State* L, lua_Debug* ar)
{
	lua_getinfo(L, "f", ar);
	void* fun_ptr = const_cast<void*>(lua_topointer(L, -1));
	lua_pop(L, 1);

	if (fun_ptr == nullptr)
	{
		return;
	}

	check(CurrentNode);
	if (CurrentNode->GetFun() != fun_ptr)
	{
		return;
	}
	
	ProcessRet();
}
void LuaInsightTracer::OnHookSampling(lua_State* L, lua_Debug* ar)
{

}

void LuaInsightTracer::ProcessRet()
{
	if (CurrentNode == RootNode) {
		return;
	}

	bool bTailCall = CurrentNode->bTailCall;

	CurrentNode->OnRet();
	auto node = CurrentNode;
	CurrentNode = CurrentNode->GetParent();
	SimpleObjectCache<LuaInsightTraceNode>::GetInstance().Free(node);

	if (bTailCall) {
		ProcessRet();
	}
}
#endif

