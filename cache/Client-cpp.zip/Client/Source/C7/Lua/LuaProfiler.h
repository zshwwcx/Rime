#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Tickable.h"
#include "Misc/CoreDelegates.h"
#include "lua.hpp"

#include "LuaProfiler.generated.h"

#define MAX_FRAMES_CAPTURE 18000


class LuaMemoryTrace;

UCLASS()
class C7_API ULuaProfiler : public UObject
{
	GENERATED_BODY()

public:
	UFUNCTION()
	void Report(int InNum);

	UFUNCTION()
	void StartHookLuaMemoryAllcation();

	UFUNCTION()
	void StopHookLuaMemoryAllcation(int InNum = 500);
	
	UFUNCTION()
	void StartHookLuaMemoryNewGCObject();

	UFUNCTION()
	void StopHookLuaMemoryNewGCObject(int InNum = 500);


	UFUNCTION()
	void C7AddToRoot() { this->AddToRoot(); }

	UFUNCTION()
	void C7RemoveFromRoot() { this->RemoveFromRoot(); }

	void OnFrameBegin();

	//统计对象信息
	UFUNCTION()
	void DumpObjectGraph(int InTopNum = 300);


private:
	void DumpLuaMemoryAllocationReport(FString filename, LuaMemoryTrace* memoryTrack, int InNum = 100);

	lua_State* GetLuaState();

	bool bRunning = false;

	bool bHook = false;

	class LuaTrace* LuaTracer = nullptr;
};
