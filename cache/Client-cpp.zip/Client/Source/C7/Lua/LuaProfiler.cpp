#include "Lua/LuaProfiler.h"
#include "Misc/FileHelper.h"
#include "HAL/PlatformMisc.h"
#include "HAL/FileManager.h"
#include "Kismet/KismetSystemLibrary.h"

#include "Lua/LuaUtils.h"

#if !UE_BUILD_SHIPPING
#include "LuaTraceData.h"
#include "DoraSDK.h"

#include "lua.hpp"

namespace NS_SLUA {
extern SLUA_UNREAL_API void (*GLuaMallocCallBack)(lua_State* L, void* Prev, void* InAddr, int InSize, int Tag);
extern SLUA_UNREAL_API void (*GSluaPushCallBack)(lua_State* L, FName Name);
}

LuaTrace* LT = nullptr;
LuaMemoryTrace* LMT = nullptr;
LuaMemoryTrace* LMT_NEWGCO = nullptr;
FName NameContext;

static void LuaMallocCallBack(lua_State* L, void *Prev, void* InAddr, int InSize, int Tag)
{
    if (LMT)
    {
        LMT->OnMalloc(L, InAddr, InSize, NameContext);
    }
    if (LMT_NEWGCO && Prev == nullptr && Tag)
    {
        LMT_NEWGCO->OnMalloc(L, InAddr, InSize, NameContext);
    }
}

static void SluaPushCallback(lua_State* L, FName Name)
{
    NameContext = Name;
}

static void DoraSDKLuaContextUpdate(FName Name)
{
    NameContext = Name;
}

#endif

void ULuaProfiler::Report(int InNum)
{
#if !UE_BUILD_SHIPPING
    FString TimeString = FPlatformTime::StrTimestamp();
    TimeString.ReplaceCharInline(' ', '_');
    TimeString.ReplaceCharInline('\\', '_');
    TimeString.ReplaceCharInline('/', '_');
    TimeString.ReplaceCharInline(':', '_');

    FString PathToSave = FPaths::ProfilingDir() + FString::Printf(TEXT("lua_profile_%s.log"), *TimeString);

    FArchive* Writer = IFileManager::Get().CreateFileWriter(*PathToSave, EFileWrite::FILEWRITE_EvenIfReadOnly);
    if (Writer == nullptr)
    {
        UE_LOG(LogTemp, Warning, TEXT("Can not create file :%s"), *PathToSave);
        return;
    }

    LuaTracer->SaveData(Writer, InNum);

    Writer->Close();
    delete Writer;
#endif
}

void ULuaProfiler::OnFrameBegin()
{
#if !UE_BUILD_SHIPPING
    if (bRunning)
    {
        LuaTracer->NewFrame();
    }
#endif
}

void ULuaProfiler::StartHookLuaMemoryAllcation()
{
#if !UE_BUILD_SHIPPING
	NS_SLUA::GLuaMallocCallBack = &LuaMallocCallBack;
	NS_SLUA::GSluaPushCallBack = &SluaPushCallback;

    if (LMT == nullptr)
    {
        LMT = new LuaMemoryTrace(GetLuaState());
    }
#endif
}

void ULuaProfiler::StopHookLuaMemoryAllcation(int InNum)
{
#if !UE_BUILD_SHIPPING
    if (LMT)
    {
        DumpLuaMemoryAllocationReport("lua_mem", LMT, InNum);
        LMT->Reset();
        delete LMT;
        LMT = nullptr;
    }

    if (LMT_NEWGCO == nullptr) {
		NS_SLUA::GLuaMallocCallBack = nullptr;
		NS_SLUA::GSluaPushCallBack = nullptr;
    }
#endif
}

void ULuaProfiler::StartHookLuaMemoryNewGCObject()
{
#if !UE_BUILD_SHIPPING
	NS_SLUA::GLuaMallocCallBack = &LuaMallocCallBack;
	NS_SLUA::GSluaPushCallBack = &SluaPushCallback;

    if (LMT_NEWGCO == nullptr)
    {
        LMT_NEWGCO = new LuaMemoryTrace(GetLuaState());
        UDoraSDK::BindLuaContextUpdateCallback(DoraSDKLuaContextUpdate);
	}
#endif
}

void ULuaProfiler::StopHookLuaMemoryNewGCObject(int InNum)
{
#if !UE_BUILD_SHIPPING
    if (LMT_NEWGCO)
    {
        DumpLuaMemoryAllocationReport("lua_mem_newgcobject",LMT_NEWGCO,InNum);
        LMT_NEWGCO->Reset();
        delete LMT_NEWGCO;
        LMT_NEWGCO = nullptr;
        UDoraSDK::BindLuaContextUpdateCallback(nullptr);
    }

    if (LMT == nullptr) {
		NS_SLUA::GLuaMallocCallBack = nullptr;
		NS_SLUA::GSluaPushCallBack = nullptr;
    }
#endif
}

lua_State* ULuaProfiler::GetLuaState()
{
    UGameInstance* GI = NS_SLUA::LuaState::getObjectGameInstance(this);
    if (GI)
    {
        NS_SLUA::LuaState* LS = NS_SLUA::LuaState::get(GI);
        if (LS)
        {
            return LS->getLuaState();
        }
    }

    return nullptr;
}

#if !UE_BUILD_SHIPPING
static void writeFile(FString InPathToSave, std::unordered_map<uint64, LuaMemoryNode*> InMallocList, int InNum, LuaMemoryTrace* memoryTrack)
{
	FArchive* Writer = IFileManager::Get().CreateFileWriter(*InPathToSave, EFileWrite::FILEWRITE_EvenIfReadOnly);
	if (Writer == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can not create file :%s"), *InPathToSave);
		return;
	}

	memoryTrack->SaveData(Writer, InNum, InMallocList);

	Writer->Close();
	delete Writer;
}
#endif

void ULuaProfiler::DumpLuaMemoryAllocationReport(FString filename, LuaMemoryTrace* memoryTrack, int InNum)
{
#if !UE_BUILD_SHIPPING
    if (memoryTrack)
    {
        FString TimeString = FPlatformTime::StrTimestamp();
        TimeString.ReplaceCharInline(' ', '_');
        TimeString.ReplaceCharInline('\\', '_');
        TimeString.ReplaceCharInline('/', '_');
        TimeString.ReplaceCharInline(':', '_');

    	writeFile(FPaths::ProfilingDir() + FString::Printf(TEXT("%s_%s.csv"), *filename, *TimeString), memoryTrack->MallocList, InNum, memoryTrack);
    	writeFile(FPaths::ProfilingDir() + FString::Printf(TEXT("%s_traceback_%s.csv"), *filename, *TimeString), memoryTrack->TracebackMallocList, InNum, memoryTrack);
    }
#endif
}


void ULuaProfiler::DumpObjectGraph(int InTopNum)
{
#if !UE_BUILD_SHIPPING

    FObjectsCollector* NOCollector = new FObjectsCollector();

    FString TimeString = FPlatformTime::StrTimestamp();
    TimeString.ReplaceCharInline(' ', '_');
    TimeString.ReplaceCharInline('\\', '_');
    TimeString.ReplaceCharInline('/', '_');
    TimeString.ReplaceCharInline(':', '_');

    FString PathToSave = FPaths::ProfilingDir() + FString::Printf(TEXT("ObjectCreationInfo_%s.csv"), *TimeString);

    FArchive* Writer = IFileManager::Get().CreateFileWriter(*PathToSave, EFileWrite::FILEWRITE_EvenIfReadOnly);
    if (Writer == nullptr)
    {
        UE_LOG(LogTemp, Warning, TEXT("Can not create file :%s"), *PathToSave);

        NOCollector->Clean();

        delete NOCollector;
        NOCollector = nullptr;

        return;
    }

    NOCollector->Dump(Writer, InTopNum);

    Writer->Close();
    delete Writer;

    NOCollector->Clean();

    delete NOCollector;
    NOCollector = nullptr;
#endif
}
