// Copyright Epic Games, Inc. All Rights Reserved.

#include "C7.h"

#include "Blueprint/UserWidget.h"
#include "Modules/ModuleManager.h"
#include "HAL/ExceptionHandling.h"

#if PLATFORM_WINDOWS && !WITH_EDITOR
#include "Windows/WindowsHWrapper.h"
#endif

IMPLEMENT_PRIMARY_GAME_MODULE(FC7Module, C7, "C7");

#if __has_include("CxxReflectionC7.h")
#include "CxxReflectionC7.h"
#endif

void FC7Module::StartupModule()
{
	// 关闭CrashReportClient，只用crashsight收录崩溃
#if UE_BUILD_SHIPPING
	GUseCrashReportClient = false;
#endif

#if __has_include("CxxReflectionC7.h") && !defined(KG_CXX_REFLECTING)
	REGISTER_LAZY_REGISTER(C7);
#endif

#if WITH_EDITOR
#else
#if defined(C7_ENABLE_ASAN) || defined(__SANITIZE_ADDRESS__) || USING_ADDRESS_SANITISER
	UE_LOG(LogTemp, Log, TEXT("ASan. Enabled=1"));	
#else
	UE_LOG(LogTemp, Log, TEXT("ASan. Enabled=0"));		
#endif
#endif

	StartupMutex();
	StartupPipe();
}

void FC7Module::ShutdownModule()
{
	ShutdownMutex();
	ShutdownPipe();
}

void FC7Module::StartupMutex()
{
#if PLATFORM_WINDOWS  && !WITH_EDITOR
	//创建mutex ,外部和Launcher之间通信用
	if (GConfig)
	{
		FString ProjectId;
		FString ProjectName;

		GConfig->GetString(TEXT("/Script/EngineSettings.GeneralProjectSettings"), TEXT("ProjectID"), ProjectId, GGameIni);
		GConfig->GetString(TEXT("/Script/EngineSettings.GeneralProjectSettings"), TEXT("ProjectName"), ProjectName, GGameIni);

		FString MutexName = FString::Printf(TEXT("%s?%s"), *ProjectName, *ProjectId);
		GameProductMutexHandle = CreateMutex(nullptr, true, *MutexName);

		if (GameProductMutexHandle)
		{
			if (GetLastError() == ERROR_ALREADY_EXISTS)
			{
				// 如果互斥体已经存在，则说明另一个进程正在运行
				UE_LOG(LogTemp, Log, TEXT("KG Mutex, Already Had Mutex! '%s'"), *MutexName);
			}
			else
			{
				UE_LOG(LogTemp, Log, TEXT("KG Mutex, Create Succ! '%s'"), *MutexName);
			}
		}
		else
		{
			UE_LOG(LogTemp, Log, TEXT("KG Mutex, Create Failed! '%s'"), *MutexName);
		}
	}
#endif
	UE_LOG(LogTemp, Log, TEXT("KG Mutex, StartupMutex done"));
}

void FC7Module::ShutdownMutex()
{
#if PLATFORM_WINDOWS && !WITH_EDITOR
	if (GameProductMutexHandle != nullptr)
	{
		ReleaseMutex(GameProductMutexHandle);
		CloseHandle(GameProductMutexHandle);
		GameProductMutexHandle = nullptr;
		UE_LOG(LogTemp, Log, TEXT("KG Mutex, ShutdownMutex"));
	}
#endif
	UE_LOG(LogTemp, Log, TEXT("KG Mutex, ShutdownMutex done"));
}

void FC7Module::StartupPipe()
{
#if PLATFORM_WINDOWS  && !WITH_EDITOR
	//创建pipe ,外部和Launcher之间通信用
	if (GConfig)
	{
		FString ProjectId;
		FString ProjectName;

		GConfig->GetString(TEXT("/Script/EngineSettings.GeneralProjectSettings"), TEXT("ProjectID"), ProjectId, GGameIni);
		GConfig->GetString(TEXT("/Script/EngineSettings.GeneralProjectSettings"), TEXT("ProjectName"), ProjectName, GGameIni);

		//Launcher和游戏交互，执行退出逻辑
		if (!QuitFromLauncherListener.IsValid())
		{
			QuitFromLauncherListener = MakeShared<LauncherQuitListener>();
		}
		if (QuitFromLauncherListener.IsValid())
		{
			FString QuitPipeName = FString::Printf(TEXT("\\\\.\\pipe\\%s?%s?Quit"), *ProjectName, *ProjectId);
			QuitFromLauncherListener->StartListening(QuitPipeName, QuitFromLauncherListener.ToWeakPtr());
			UE_LOG(LogTemp, Log, TEXT("KG Pipe, StartupPipe:%s"), *QuitPipeName);
		}
	}
#endif
	UE_LOG(LogTemp, Log, TEXT("KG Pipe, StartupPipe done"));
}

void FC7Module::ShutdownPipe()
{
#if PLATFORM_WINDOWS && !WITH_EDITOR
	if (QuitFromLauncherListener.IsValid())
	{
		UE_LOG(LogTemp, Log, TEXT("KG Pipe, ShutdownPipe begin"));
		QuitFromLauncherListener->StopListening();
		QuitFromLauncherListener = nullptr;
		UE_LOG(LogTemp, Log, TEXT("KG Pipe, ShutdownPipe end"));
	}

#endif
	UE_LOG(LogTemp, Log, TEXT("KG Pipe, ShutdownPipe done"));
}
