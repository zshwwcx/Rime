/**
* Auth :   liubo
 * Date :   2026-02-07 15:21
 * Comment: 实验功能，有很多临时代码，不要正式使用
 */

#include "AIAnimCtrlComponent.h"

#include "C7Define.h"
#include "Engine.h"
#include "Misc/FileHelper.h" // 用于文件读取
#include "Serialization/JsonReader.h" // JSON读取
#include "Serialization/JsonSerializer.h"

#include "Dom/JsonObject.h"
#include "JsonObjectConverter.h"
#include "ProfileDataDefine.h"
#include "Dom/JsonObject.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonWriter.h"
#include "3C/Audio/KGAudioInputComponent.h"
#include "Engine/AssetManager.h"

DECLARE_LOG_CATEGORY_EXTERN(LogAI3DNPC, Log, All);
DEFINE_LOG_CATEGORY(LogAI3DNPC);

const char* IDLE_ANIM = "idle";
static TSharedPtr<FJsonObject> LoadJsonObject(const FString& FilePath, bool bLog = true)
{
	TSharedPtr<FJsonObject> JsonObject;
	
	FString JsonString;
	
	if (!FFileHelper::LoadFileToString(JsonString, *FilePath))
	{
		if(bLog)
		{
			UE_LOG(LogAI3DNPC, Warning, TEXT("liubo, ai3dnpc, LoadSmplJson, Failed to load JSON file: %s"), *FilePath);			
		}
		return JsonObject;
	}
	
	{
		TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(JsonString);

		if (!FJsonSerializer::Deserialize(Reader, JsonObject) || !JsonObject.IsValid())
		{
			if(bLog)
			{
				UE_LOG(LogAI3DNPC, Warning, TEXT("liubo, ai3dnpc, LoadSmplJson, Failed to parse JSON:%s"), *FilePath);			
			}
			return JsonObject;
		}		
	}
	
	return JsonObject;
}

// 步进一次动画，并返回步进后，新的动画idx
template<class T, class FUNC>
static int StepAnims(TArray<T>& AnimList, float DeltaTime, float& LastPlayTime, int LastAnimIdx, FUNC GetStartTime)
{
	int Idx = -1;
	LastPlayTime += DeltaTime;
	if (AnimList.Num() > 0)
	{
		for (int i = FMath::Max<int>(0, LastAnimIdx); i < AnimList.Num(); i++)
		{
			if (LastPlayTime < GetStartTime(AnimList, i))
			{
				Idx = i - 1;
				break;
			}
		}
		if (Idx == -1)
		{
			Idx = AnimList.Num() - 1;
		}
	}
	return Idx;
}
static FString ToPackageName(const FString& AssetFileName)
{
	int LastIdx = -1;
	FString ShortName("None");
	if(AssetFileName.FindLastChar('/', LastIdx) && LastIdx >= 0)
	{
		ShortName = AssetFileName.Mid(LastIdx + 1); 
	}
	FString Ret = AssetFileName + FString(".") + ShortName;
	return Ret;
}

template <typename StructType>
static bool MyJsonToUStruct(StructType& Data, const FString& JsonContent)
{
	TSharedPtr<FJsonObject> JsonPreset = MakeShared<FJsonObject>();
	TSharedRef< TJsonReader<> > JsonReader = TJsonReaderFactory<>::Create(JsonContent);
	if ( !FJsonSerializer::Deserialize(JsonReader, JsonPreset) )
	{
		return false;
	}
	
	if ( FJsonObjectConverter::JsonObjectToUStruct(JsonPreset.ToSharedRef(), &Data, 0, 0) )
	{
		return true;
	}

	return false;
}


// Sets default values for this component's properties
UAIAnimCtrlComponent::UAIAnimCtrlComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// ...
}

// AI ControlRig索引，定死的
enum class EAIDataIdx : uint8
{
	CTRL_C_eye_translateX,
	CTRL_C_eye_translateY,
	CTRL_C_eye_parallelLook_translateY,
	CTRL_C_jaw_translateX,
	CTRL_C_jaw_translateY,
	CTRL_C_jaw_fwdBack_translateY,
	CTRL_C_jaw_openExtreme_translateY,
	CTRL_C_mouth_translateX,
	CTRL_C_mouth_translateY,
	CTRL_C_mouth_lipShiftD_translateY,
	CTRL_C_mouth_lipShiftU_translateY,
	CTRL_C_mouth_stickyD_translateY,
	CTRL_C_mouth_stickyU_translateY,
	CTRL_C_neck_swallow_translateY,
	CTRL_C_teethD_translateX,
	CTRL_C_teethD_translateY,
	CTRL_C_teethU_translateX,
	CTRL_C_teethU_translateY,
	CTRL_C_teeth_fwdBackD_translateY,
	CTRL_C_teeth_fwdBackU_translateY,
	CTRL_C_tongue_translateX,
	CTRL_C_tongue_translateY,
	CTRL_C_tongue_inOut_translateY,
	CTRL_C_tongue_narrowWide_translateY,
	CTRL_C_tongue_press_translateY,
	CTRL_C_tongue_roll_translateX,
	CTRL_C_tongue_roll_translateY,
	CTRL_C_tongue_tip_translateX,
	CTRL_C_tongue_tip_translateY,
	CTRL_L_brow_down_translateY,
	CTRL_L_brow_lateral_translateY,
	CTRL_L_brow_raiseIn_translateY,
	CTRL_L_brow_raiseOut_translateY,
	CTRL_L_ear_up_translateY,
	CTRL_L_eye_translateX,
	CTRL_L_eye_translateY,
	CTRL_L_eye_blink_translateY,
	CTRL_L_eye_cheekRaise_translateY,
	CTRL_L_eye_eyelidD_translateY,
	CTRL_L_eye_eyelidU_translateY,
	CTRL_L_eye_faceScrunch_translateY,
	CTRL_L_eye_lidPress_translateY,
	CTRL_L_eye_pupil_translateY,
	CTRL_L_eye_squintInner_translateY,
	CTRL_L_eyelashes_tweakerIn_translateY,
	CTRL_L_eyelashes_tweakerOut_translateY,
	CTRL_L_jaw_ChinRaiseD_translateY,
	CTRL_L_jaw_ChinRaiseU_translateY,
	CTRL_L_jaw_chinCompress_translateY,
	CTRL_L_jaw_clench_translateY,
	CTRL_L_mouth_corner_translateX,
	CTRL_L_mouth_corner_translateY,
	CTRL_L_mouth_cornerDepress_translateY,
	CTRL_L_mouth_cornerPull_translateY,
	CTRL_L_mouth_cornerSharpnessD_translateY,
	CTRL_L_mouth_cornerSharpnessU_translateY,
	CTRL_L_mouth_dimple_translateY,
	CTRL_L_mouth_funnelD_translateY,
	CTRL_L_mouth_funnelU_translateY,
	CTRL_L_mouth_lipBiteD_translateY,
	CTRL_L_mouth_lipBiteU_translateY,
	CTRL_L_mouth_lipSticky_translateY,
	CTRL_L_mouth_lipsBlow_translateY,
	CTRL_L_mouth_lipsPressU_translateY,
	CTRL_L_mouth_lipsRollD_translateY,
	CTRL_L_mouth_lipsRollU_translateY,
	CTRL_L_mouth_lipsTogetherD_translateY,
	CTRL_L_mouth_lipsTogetherU_translateY,
	CTRL_L_mouth_lipsTowardsTeethD_translateY,
	CTRL_L_mouth_lipsTowardsTeethU_translateY,
	CTRL_L_mouth_lowerLipDepress_translateY,
	CTRL_L_mouth_pressD_translateY,
	CTRL_L_mouth_pressU_translateY,
	CTRL_L_mouth_purseD_translateY,
	CTRL_L_mouth_purseU_translateY,
	CTRL_L_mouth_pushPullD_translateY,
	CTRL_L_mouth_pushPullU_translateY,
	CTRL_L_mouth_sharpCornerPull_translateY,
	CTRL_L_mouth_stickyInnerD_translateY,
	CTRL_L_mouth_stickyInnerU_translateY,
	CTRL_L_mouth_stickyOuterD_translateY,
	CTRL_L_mouth_stickyOuterU_translateY,
	CTRL_L_mouth_stretch_translateY,
	CTRL_L_mouth_stretchLipsClose_translateY,
	CTRL_L_mouth_suckBlow_translateY,
	CTRL_L_mouth_thicknessD_translateY,
	CTRL_L_mouth_thicknessU_translateY,
	CTRL_L_mouth_tightenD_translateY,
	CTRL_L_mouth_tightenU_translateY,
	CTRL_L_mouth_towardsD_translateY,
	CTRL_L_mouth_towardsU_translateY,
	CTRL_L_mouth_upperLipRaise_translateY,
	CTRL_L_neck_mastoidContract_translateY,
	CTRL_L_neck_stretch_translateY,
	CTRL_L_nose_translateX,
	CTRL_L_nose_translateY,
	CTRL_L_nose_nasolabialDeepen_translateY,
	CTRL_L_nose_wrinkleUpper_translateY,
	CTRL_R_brow_down_translateY,
	CTRL_R_brow_lateral_translateY,
	CTRL_R_brow_raiseIn_translateY,
	CTRL_R_brow_raiseOut_translateY,
	CTRL_R_ear_up_translateY,
	CTRL_R_eye_translateX,
	CTRL_R_eye_translateY,
	CTRL_R_eye_blink_translateY,
	CTRL_R_eye_cheekRaise_translateY,
	CTRL_R_eye_eyelidD_translateY,
	CTRL_R_eye_eyelidU_translateY,
	CTRL_R_eye_faceScrunch_translateY,
	CTRL_R_eye_lidPress_translateY,
	CTRL_R_eye_pupil_translateY,
	CTRL_R_eye_squintInner_translateY,
	CTRL_R_eyelashes_tweakerIn_translateY,
	CTRL_R_eyelashes_tweakerOut_translateY,
	CTRL_R_jaw_ChinRaiseD_translateY,
	CTRL_R_jaw_ChinRaiseU_translateY,
	CTRL_R_jaw_chinCompress_translateY,
	CTRL_R_jaw_clench_translateY,
	CTRL_R_mouth_corner_translateX,
	CTRL_R_mouth_corner_translateY,
	CTRL_R_mouth_cornerDepress_translateY,
	CTRL_R_mouth_cornerPull_translateY,
	CTRL_R_mouth_cornerSharpnessD_translateY,
	CTRL_R_mouth_cornerSharpnessU_translateY,
	CTRL_R_mouth_dimple_translateY,
	CTRL_R_mouth_funnelD_translateY,
	CTRL_R_mouth_funnelU_translateY,
	CTRL_R_mouth_lipBiteD_translateY,
	CTRL_R_mouth_lipBiteU_translateY,
	CTRL_R_mouth_lipSticky_translateY,
	CTRL_R_mouth_lipsBlow_translateY,
	CTRL_R_mouth_lipsPressU_translateY,
	CTRL_R_mouth_lipsRollD_translateY,
	CTRL_R_mouth_lipsRollU_translateY,
	CTRL_R_mouth_lipsTogetherD_translateY,
	CTRL_R_mouth_lipsTogetherU_translateY,
	CTRL_R_mouth_lipsTowardsTeethD_translateY,
	CTRL_R_mouth_lipsTowardsTeethU_translateY,
	CTRL_R_mouth_lowerLipDepress_translateY,
	CTRL_R_mouth_pressD_translateY,
	CTRL_R_mouth_pressU_translateY,
	CTRL_R_mouth_purseD_translateY,
	CTRL_R_mouth_purseU_translateY,
	CTRL_R_mouth_pushPullD_translateY,
	CTRL_R_mouth_pushPullU_translateY,
	CTRL_R_mouth_sharpCornerPull_translateY,
	CTRL_R_mouth_stickyInnerD_translateY,
	CTRL_R_mouth_stickyInnerU_translateY,
	CTRL_R_mouth_stickyOuterD_translateY,
	CTRL_R_mouth_stickyOuterU_translateY,
	CTRL_R_mouth_stretch_translateY,
	CTRL_R_mouth_stretchLipsClose_translateY,
	CTRL_R_mouth_suckBlow_translateY,
	CTRL_R_mouth_thicknessD_translateY,
	CTRL_R_mouth_thicknessU_translateY,
	CTRL_R_mouth_tightenD_translateY,
	CTRL_R_mouth_tightenU_translateY,
	CTRL_R_mouth_towardsD_translateY,
	CTRL_R_mouth_towardsU_translateY,
	CTRL_R_mouth_upperLipRaise_translateY,
	CTRL_R_neck_mastoidContract_translateY,
	CTRL_R_neck_stretch_translateY,
	CTRL_R_nose_translateX,
	CTRL_R_nose_translateY,
	CTRL_R_nose_nasolabialDeepen_translateY,
	CTRL_R_nose_wrinkleUpper_translateY,
	CTRL_lookAtSwitch_translateY,
	CTRL_neckCorrectivesMultiplyerD_translateY,
	CTRL_neckCorrectivesMultiplyerM_translateY,
	CTRL_neckCorrectivesMultiplyerU_translateY,
	CTRL_neck_digastricUpDown_translateY,
	CTRL_neck_throatExhaleInhale_translateY,
	CTRL_neck_throatUpDown_translateY,
	Max
};

static FVector2D ToValue(const TArray<float>& AnimData, EAIDataIdx X, EAIDataIdx Y)
{
	if(!AnimData.IsValidIndex((int)X) || !AnimData.IsValidIndex((int)Y))
	{
		return FVector2D::Zero();
	}
	return FVector2D(AnimData[(int)X], AnimData[(int)Y]);
}
static float ToValue(const TArray<float>& AnimData, EAIDataIdx Idx)
{
	if(!AnimData.IsValidIndex((int)Idx))
	{
		return 0;
	}
	return AnimData[(int)Idx];
}

static void SetData(FAIFaceAnimData& Dst, const TArray<float>& AnimData)
{
	if (AnimData.Num() > (int)EAIDataIdx::Max)
	{
		return;
	}

	Dst.CTRL_C_eye = ToValue(AnimData, EAIDataIdx::CTRL_C_eye_translateX, EAIDataIdx::CTRL_C_eye_translateY);
	Dst.CTRL_C_eye_parallelLook = ToValue(AnimData, EAIDataIdx::CTRL_C_eye_parallelLook_translateY);
	Dst.CTRL_C_jaw = ToValue(AnimData, EAIDataIdx::CTRL_C_jaw_translateX, EAIDataIdx::CTRL_C_jaw_translateY);
	Dst.CTRL_C_jaw_fwdBack = ToValue(AnimData, EAIDataIdx::CTRL_C_jaw_fwdBack_translateY);
	Dst.CTRL_C_jaw_openExtreme = ToValue(AnimData, EAIDataIdx::CTRL_C_jaw_openExtreme_translateY);
	Dst.CTRL_C_mouth = ToValue(AnimData, EAIDataIdx::CTRL_C_mouth_translateX, EAIDataIdx::CTRL_C_mouth_translateY);
	Dst.CTRL_C_mouth_lipShiftD = ToValue(AnimData, EAIDataIdx::CTRL_C_mouth_lipShiftD_translateY);
	Dst.CTRL_C_mouth_lipShiftU = ToValue(AnimData, EAIDataIdx::CTRL_C_mouth_lipShiftU_translateY);
	Dst.CTRL_C_mouth_stickyD = ToValue(AnimData, EAIDataIdx::CTRL_C_mouth_stickyD_translateY);
	Dst.CTRL_C_mouth_stickyU = ToValue(AnimData, EAIDataIdx::CTRL_C_mouth_stickyU_translateY);
	Dst.CTRL_C_neck_swallow = ToValue(AnimData, EAIDataIdx::CTRL_C_neck_swallow_translateY);
	Dst.CTRL_C_teethD = ToValue(AnimData, EAIDataIdx::CTRL_C_teethD_translateX, EAIDataIdx::CTRL_C_teethD_translateY);
	Dst.CTRL_C_teethU = ToValue(AnimData, EAIDataIdx::CTRL_C_teethU_translateX, EAIDataIdx::CTRL_C_teethU_translateY);
	Dst.CTRL_C_teeth_fwdBackD = ToValue(AnimData, EAIDataIdx::CTRL_C_teeth_fwdBackD_translateY);
	Dst.CTRL_C_teeth_fwdBackU = ToValue(AnimData, EAIDataIdx::CTRL_C_teeth_fwdBackU_translateY);
	//Dst.CTRL_C_tongue = ToValue(AnimData, EAIDataIdx::CTRL_C_tongue_translateY);
	//Dst.CTRL_C_tongue = ToValue(AnimData, EAIDataIdx::CTRL_C_tongue_translateY);
	//Dst.CTRL_C_tongue_inOut = ToValue(AnimData, EAIDataIdx::CTRL_C_tongue_inOut_translateY);
	//Dst.CTRL_C_tongue_narrowWide = ToValue(AnimData, EAIDataIdx::CTRL_C_tongue_narrowWide_translateY);
	//Dst.CTRL_C_tongue_press = ToValue(AnimData, EAIDataIdx::CTRL_C_tongue_press_translateY);
	//Dst.CTRL_C_tongue_roll = ToValue(AnimData, EAIDataIdx::CTRL_C_tongue_roll_translateY);
	//Dst.CTRL_C_tongue_roll = ToValue(AnimData, EAIDataIdx::CTRL_C_tongue_roll_translateY);
	//Dst.CTRL_C_tongue_tip = ToValue(AnimData, EAIDataIdx::CTRL_C_tongue_tip_translateY);
	//Dst.CTRL_C_tongue_tip = ToValue(AnimData, EAIDataIdx::CTRL_C_tongue_tip_translateY);
	Dst.CTRL_L_brow_down = ToValue(AnimData, EAIDataIdx::CTRL_L_brow_down_translateY);
	Dst.CTRL_L_brow_lateral = ToValue(AnimData, EAIDataIdx::CTRL_L_brow_lateral_translateY);
	Dst.CTRL_L_brow_raiseIn = ToValue(AnimData, EAIDataIdx::CTRL_L_brow_raiseIn_translateY);
	Dst.CTRL_L_brow_raiseOut = ToValue(AnimData, EAIDataIdx::CTRL_L_brow_raiseOut_translateY);
	Dst.CTRL_L_ear_up = ToValue(AnimData, EAIDataIdx::CTRL_L_ear_up_translateY);
	Dst.CTRL_L_eye = ToValue(AnimData, EAIDataIdx::CTRL_L_eye_translateX, EAIDataIdx::CTRL_L_eye_translateY);
	Dst.CTRL_L_eye_blink = ToValue(AnimData, EAIDataIdx::CTRL_L_eye_blink_translateY);
	Dst.CTRL_L_eye_cheekRaise = ToValue(AnimData, EAIDataIdx::CTRL_L_eye_cheekRaise_translateY);
	Dst.CTRL_L_eye_eyelidD = ToValue(AnimData, EAIDataIdx::CTRL_L_eye_eyelidD_translateY);
	Dst.CTRL_L_eye_eyelidU = ToValue(AnimData, EAIDataIdx::CTRL_L_eye_eyelidU_translateY);
	Dst.CTRL_L_eye_faceScrunch = ToValue(AnimData, EAIDataIdx::CTRL_L_eye_faceScrunch_translateY);
	Dst.CTRL_L_eye_lidPress = ToValue(AnimData, EAIDataIdx::CTRL_L_eye_lidPress_translateY);
	Dst.CTRL_L_eye_pupil = ToValue(AnimData, EAIDataIdx::CTRL_L_eye_pupil_translateY);
	Dst.CTRL_L_eye_squintInner = ToValue(AnimData, EAIDataIdx::CTRL_L_eye_squintInner_translateY);
	Dst.CTRL_L_eyelashes_tweakerIn = ToValue(AnimData, EAIDataIdx::CTRL_L_eyelashes_tweakerIn_translateY);
	Dst.CTRL_L_eyelashes_tweakerOut = ToValue(AnimData, EAIDataIdx::CTRL_L_eyelashes_tweakerOut_translateY);
	Dst.CTRL_L_jaw_ChinRaiseD = ToValue(AnimData, EAIDataIdx::CTRL_L_jaw_ChinRaiseD_translateY);
	Dst.CTRL_L_jaw_ChinRaiseU = ToValue(AnimData, EAIDataIdx::CTRL_L_jaw_ChinRaiseU_translateY);
	Dst.CTRL_L_jaw_chinCompress = ToValue(AnimData, EAIDataIdx::CTRL_L_jaw_chinCompress_translateY);
	Dst.CTRL_L_jaw_clench = ToValue(AnimData, EAIDataIdx::CTRL_L_jaw_clench_translateY);
	Dst.CTRL_L_mouth_corner = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_corner_translateX, EAIDataIdx::CTRL_L_mouth_corner_translateY);
	Dst.CTRL_L_mouth_cornerDepress = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_cornerDepress_translateY);
	Dst.CTRL_L_mouth_cornerPull = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_cornerPull_translateY);
	Dst.CTRL_L_mouth_cornerSharpnessD = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_cornerSharpnessD_translateY);
	Dst.CTRL_L_mouth_cornerSharpnessU = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_cornerSharpnessU_translateY);
	Dst.CTRL_L_mouth_dimple = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_dimple_translateY);
	Dst.CTRL_L_mouth_funnelD = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_funnelD_translateY);
	Dst.CTRL_L_mouth_funnelU = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_funnelU_translateY);
	Dst.CTRL_L_mouth_lipBiteD = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_lipBiteD_translateY);
	Dst.CTRL_L_mouth_lipBiteU = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_lipBiteU_translateY);
	Dst.CTRL_L_mouth_lipSticky = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_lipSticky_translateY);
	Dst.CTRL_L_mouth_lipsBlow = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_lipsBlow_translateY);
	Dst.CTRL_L_mouth_lipsPressU = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_lipsPressU_translateY);
	Dst.CTRL_L_mouth_lipsRollD = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_lipsRollD_translateY);
	Dst.CTRL_L_mouth_lipsRollU = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_lipsRollU_translateY);
	Dst.CTRL_L_mouth_lipsTogetherD = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_lipsTogetherD_translateY);
	Dst.CTRL_L_mouth_lipsTogetherU = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_lipsTogetherU_translateY);
	Dst.CTRL_L_mouth_lipsTowardsTeethD = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_lipsTowardsTeethD_translateY);
	Dst.CTRL_L_mouth_lipsTowardsTeethU = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_lipsTowardsTeethU_translateY);
	Dst.CTRL_L_mouth_lowerLipDepress = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_lowerLipDepress_translateY);
	Dst.CTRL_L_mouth_pressD = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_pressD_translateY);
	Dst.CTRL_L_mouth_pressU = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_pressU_translateY);
	Dst.CTRL_L_mouth_purseD = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_purseD_translateY);
	Dst.CTRL_L_mouth_purseU = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_purseU_translateY);
	Dst.CTRL_L_mouth_pushPullD = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_pushPullD_translateY);
	Dst.CTRL_L_mouth_pushPullU = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_pushPullU_translateY);
	Dst.CTRL_L_mouth_sharpCornerPull = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_sharpCornerPull_translateY);
	Dst.CTRL_L_mouth_stickyInnerD = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_stickyInnerD_translateY);
	Dst.CTRL_L_mouth_stickyInnerU = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_stickyInnerU_translateY);
	Dst.CTRL_L_mouth_stickyOuterD = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_stickyOuterD_translateY);
	Dst.CTRL_L_mouth_stickyOuterU = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_stickyOuterU_translateY);
	Dst.CTRL_L_mouth_stretch = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_stretch_translateY);
	Dst.CTRL_L_mouth_stretchLipsClose = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_stretchLipsClose_translateY);
	Dst.CTRL_L_mouth_suckBlow = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_suckBlow_translateY);
	Dst.CTRL_L_mouth_thicknessD = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_thicknessD_translateY);
	Dst.CTRL_L_mouth_thicknessU = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_thicknessU_translateY);
	Dst.CTRL_L_mouth_tightenD = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_tightenD_translateY);
	Dst.CTRL_L_mouth_tightenU = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_tightenU_translateY);
	Dst.CTRL_L_mouth_towardsD = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_towardsD_translateY);
	Dst.CTRL_L_mouth_towardsU = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_towardsU_translateY);
	Dst.CTRL_L_mouth_upperLipRaise = ToValue(AnimData, EAIDataIdx::CTRL_L_mouth_upperLipRaise_translateY);
	Dst.CTRL_L_neck_mastoidContract = ToValue(AnimData, EAIDataIdx::CTRL_L_neck_mastoidContract_translateY);
	Dst.CTRL_L_neck_stretch = ToValue(AnimData, EAIDataIdx::CTRL_L_neck_stretch_translateY);
	Dst.CTRL_L_nose = ToValue(AnimData, EAIDataIdx::CTRL_L_nose_translateX, EAIDataIdx::CTRL_L_nose_translateY);
	Dst.CTRL_L_nose_nasolabialDeepen = ToValue(AnimData, EAIDataIdx::CTRL_L_nose_nasolabialDeepen_translateY);
	Dst.CTRL_L_nose_wrinkleUpper = ToValue(AnimData, EAIDataIdx::CTRL_L_nose_wrinkleUpper_translateY);
	Dst.CTRL_R_brow_down = ToValue(AnimData, EAIDataIdx::CTRL_R_brow_down_translateY);
	Dst.CTRL_R_brow_lateral = ToValue(AnimData, EAIDataIdx::CTRL_R_brow_lateral_translateY);
	Dst.CTRL_R_brow_raiseIn = ToValue(AnimData, EAIDataIdx::CTRL_R_brow_raiseIn_translateY);
	Dst.CTRL_R_brow_raiseOut = ToValue(AnimData, EAIDataIdx::CTRL_R_brow_raiseOut_translateY);
	Dst.CTRL_R_ear_up = ToValue(AnimData, EAIDataIdx::CTRL_R_ear_up_translateY);
	Dst.CTRL_R_eye = ToValue(AnimData, EAIDataIdx::CTRL_R_eye_translateX, EAIDataIdx::CTRL_R_eye_translateY);
	Dst.CTRL_R_eye_blink = ToValue(AnimData, EAIDataIdx::CTRL_R_eye_blink_translateY);
	Dst.CTRL_R_eye_cheekRaise = ToValue(AnimData, EAIDataIdx::CTRL_R_eye_cheekRaise_translateY);
	Dst.CTRL_R_eye_eyelidD = ToValue(AnimData, EAIDataIdx::CTRL_R_eye_eyelidD_translateY);
	Dst.CTRL_R_eye_eyelidU = ToValue(AnimData, EAIDataIdx::CTRL_R_eye_eyelidU_translateY);
	Dst.CTRL_R_eye_faceScrunch = ToValue(AnimData, EAIDataIdx::CTRL_R_eye_faceScrunch_translateY);
	Dst.CTRL_R_eye_lidPress = ToValue(AnimData, EAIDataIdx::CTRL_R_eye_lidPress_translateY);
	Dst.CTRL_R_eye_pupil = ToValue(AnimData, EAIDataIdx::CTRL_R_eye_pupil_translateY);
	Dst.CTRL_R_eye_squintInner = ToValue(AnimData, EAIDataIdx::CTRL_R_eye_squintInner_translateY);
	Dst.CTRL_R_eyelashes_tweakerIn = ToValue(AnimData, EAIDataIdx::CTRL_R_eyelashes_tweakerIn_translateY);
	Dst.CTRL_R_eyelashes_tweakerOut = ToValue(AnimData, EAIDataIdx::CTRL_R_eyelashes_tweakerOut_translateY);
	Dst.CTRL_R_jaw_ChinRaiseD = ToValue(AnimData, EAIDataIdx::CTRL_R_jaw_ChinRaiseD_translateY);
	Dst.CTRL_R_jaw_ChinRaiseU = ToValue(AnimData, EAIDataIdx::CTRL_R_jaw_ChinRaiseU_translateY);
	Dst.CTRL_R_jaw_chinCompress = ToValue(AnimData, EAIDataIdx::CTRL_R_jaw_chinCompress_translateY);
	Dst.CTRL_R_jaw_clench = ToValue(AnimData, EAIDataIdx::CTRL_R_jaw_clench_translateY);
	Dst.CTRL_R_mouth_corner = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_corner_translateX, EAIDataIdx::CTRL_R_mouth_corner_translateY);
	Dst.CTRL_R_mouth_cornerDepress = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_cornerDepress_translateY);
	Dst.CTRL_R_mouth_cornerPull = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_cornerPull_translateY);
	Dst.CTRL_R_mouth_cornerSharpnessD = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_cornerSharpnessD_translateY);
	Dst.CTRL_R_mouth_cornerSharpnessU = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_cornerSharpnessU_translateY);
	Dst.CTRL_R_mouth_dimple = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_dimple_translateY);
	Dst.CTRL_R_mouth_funnelD = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_funnelD_translateY);
	Dst.CTRL_R_mouth_funnelU = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_funnelU_translateY);
	Dst.CTRL_R_mouth_lipBiteD = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_lipBiteD_translateY);
	Dst.CTRL_R_mouth_lipBiteU = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_lipBiteU_translateY);
	Dst.CTRL_R_mouth_lipSticky = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_lipSticky_translateY);
	Dst.CTRL_R_mouth_lipsBlow = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_lipsBlow_translateY);
	Dst.CTRL_R_mouth_lipsPressU = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_lipsPressU_translateY);
	Dst.CTRL_R_mouth_lipsRollD = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_lipsRollD_translateY);
	Dst.CTRL_R_mouth_lipsRollU = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_lipsRollU_translateY);
	Dst.CTRL_R_mouth_lipsTogetherD = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_lipsTogetherD_translateY);
	Dst.CTRL_R_mouth_lipsTogetherU = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_lipsTogetherU_translateY);
	Dst.CTRL_R_mouth_lipsTowardsTeethD = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_lipsTowardsTeethD_translateY);
	Dst.CTRL_R_mouth_lipsTowardsTeethU = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_lipsTowardsTeethU_translateY);
	Dst.CTRL_R_mouth_lowerLipDepress = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_lowerLipDepress_translateY);
	Dst.CTRL_R_mouth_pressD = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_pressD_translateY);
	Dst.CTRL_R_mouth_pressU = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_pressU_translateY);
	Dst.CTRL_R_mouth_purseD = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_purseD_translateY);
	Dst.CTRL_R_mouth_purseU = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_purseU_translateY);
	Dst.CTRL_R_mouth_pushPullD = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_pushPullD_translateY);
	Dst.CTRL_R_mouth_pushPullU = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_pushPullU_translateY);
	Dst.CTRL_R_mouth_sharpCornerPull = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_sharpCornerPull_translateY);
	Dst.CTRL_R_mouth_stickyInnerD = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_stickyInnerD_translateY);
	Dst.CTRL_R_mouth_stickyInnerU = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_stickyInnerU_translateY);
	Dst.CTRL_R_mouth_stickyOuterD = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_stickyOuterD_translateY);
	Dst.CTRL_R_mouth_stickyOuterU = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_stickyOuterU_translateY);
	Dst.CTRL_R_mouth_stretch = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_stretch_translateY);
	Dst.CTRL_R_mouth_stretchLipsClose = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_stretchLipsClose_translateY);
	Dst.CTRL_R_mouth_suckBlow = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_suckBlow_translateY);
	Dst.CTRL_R_mouth_thicknessD = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_thicknessD_translateY);
	Dst.CTRL_R_mouth_thicknessU = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_thicknessU_translateY);
	Dst.CTRL_R_mouth_tightenD = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_tightenD_translateY);
	Dst.CTRL_R_mouth_tightenU = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_tightenU_translateY);
	Dst.CTRL_R_mouth_towardsD = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_towardsD_translateY);
	Dst.CTRL_R_mouth_towardsU = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_towardsU_translateY);
	Dst.CTRL_R_mouth_upperLipRaise = ToValue(AnimData, EAIDataIdx::CTRL_R_mouth_upperLipRaise_translateY);
	Dst.CTRL_R_neck_mastoidContract = ToValue(AnimData, EAIDataIdx::CTRL_R_neck_mastoidContract_translateY);
	Dst.CTRL_R_neck_stretch = ToValue(AnimData, EAIDataIdx::CTRL_R_neck_stretch_translateY);
	Dst.CTRL_R_nose = ToValue(AnimData, EAIDataIdx::CTRL_R_nose_translateX, EAIDataIdx::CTRL_R_nose_translateY);
	Dst.CTRL_R_nose_nasolabialDeepen = ToValue(AnimData, EAIDataIdx::CTRL_R_nose_nasolabialDeepen_translateY);
	Dst.CTRL_R_nose_wrinkleUpper = ToValue(AnimData, EAIDataIdx::CTRL_R_nose_wrinkleUpper_translateY);
	Dst.CTRL_lookAtSwitch = ToValue(AnimData, EAIDataIdx::CTRL_lookAtSwitch_translateY);
	//Dst.CTRL_neckCorrectivesMultiplyerD = ToValue(AnimData, EAIDataIdx::CTRL_neckCorrectivesMultiplyerD_translateY);
	//Dst.CTRL_neckCorrectivesMultiplyerM = ToValue(AnimData, EAIDataIdx::CTRL_neckCorrectivesMultiplyerM_translateY);
	//Dst.CTRL_neckCorrectivesMultiplyerU = ToValue(AnimData, EAIDataIdx::CTRL_neckCorrectivesMultiplyerU_translateY);
	Dst.CTRL_neck_digastricUpDown = ToValue(AnimData, EAIDataIdx::CTRL_neck_digastricUpDown_translateY);
	Dst.CTRL_neck_throatExhaleInhale = ToValue(AnimData, EAIDataIdx::CTRL_neck_throatExhaleInhale_translateY);
	Dst.CTRL_neck_throatUpDown = ToValue(AnimData, EAIDataIdx::CTRL_neck_throatUpDown_translateY);
}

static FString GetAIFaceRootDir()
{
	return FPaths::Combine(*FPaths::ProjectSavedDir(), TEXT("ai_anim"));
}

// Called when the game starts
void UAIAnimCtrlComponent::BeginPlay()
{
	Super::BeginPlay();

	FTimerHandle Handle;
	GetWorld()->GetTimerManager().SetTimer(Handle,  this, &UAIAnimCtrlComponent::UnitTest, 0.1f, false);
}

void UAIAnimCtrlComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
	if(EndPlayReason != EEndPlayReason::RemovedFromWorld)
	{
		CancalAllAsyncLoad();
	}
}


// Called every frame
void UAIAnimCtrlComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// ...
	bool bOldValidAnimFaceData = bValidFaceAnimData;

	bValidFaceAnimData = false;
	if (bDebugMode)
	{
		if (CtrlRigFaceAnimDataList.Num() > 0)
		{
			if (CtrlRigFaceAnimDataList.IsValidIndex(AnimFrameIdx))
			{
				LastAnimData = CtrlRigFaceAnimDataList[AnimFrameIdx].FaceAnimData;
				SetBodyAnim(CtrlRigFaceAnimDataList[AnimFrameIdx].BodyAnimId);
				bValidFaceAnimData = true;

				if (bOldValidAnimFaceData != bValidFaceAnimData)
				{
					SetFaceAnim(true);
				}
			}
		}
	}
	else if (AnimTotalTime > 0 && OneFrameTime > 0 && CtrlRigFaceAnimDataList.Num() > 0)
	{
		int idx = -1;
		{	
			idx = StepAnims(CtrlRigFaceAnimDataList, DeltaTime, LastFaceTime, LastFaceAnimIdx,
				[InOneFrameTime=OneFrameTime](const TArray<FAIAnimCtrlData>& Datas, int i)
				{
					return i * InOneFrameTime;
				});
			if(idx >= 0)
			{
				LastFaceAnimIdx = idx;			
			}
			if (bDebugLoopAnim)
			{
				while (LastFaceTime > AnimTotalTime)
				{
					LastFaceTime -= AnimTotalTime;
					LastFaceAnimIdx = 0;
					idx = 0;
				}
			}
			else
			{
				if(LastFaceTime > AnimTotalTime)
				{
					idx = -1;
				}
			}
		}
		if (idx >= 0 && idx < CtrlRigFaceAnimDataList.Num())
		{
			// 设置数据
			LastAnimData = CtrlRigFaceAnimDataList[idx].FaceAnimData;
			SetBodyAnim(CtrlRigFaceAnimDataList[idx].BodyAnimId);
			bValidFaceAnimData = true;
		}
	}

	if (bOldValidAnimFaceData != bValidFaceAnimData)
	{
		if (!bValidFaceAnimData)
		{
			OnFaceAnimEnd();
		}
	}
	
	TickBodyAnim(DeltaTime);
}

void UAIAnimCtrlComponent::TickBodyAnim(float DeltaTime)
{
	if (BodyAnimList.Num() > 0)
	{
		auto Idx = StepAnims(BodyAnimList, DeltaTime, LastBodyTime, LastBodyAnimIdx,
			[](const TArray<FAIBodyAnimCtrlData>& Datas, int i)
			{
				return Datas[i].Time;
			});
		if (LastBodyAnimIdx != Idx)
		{
			SetBodyAnimNew(Idx);
		}
	}
}

void UAIAnimCtrlComponent::ReqAI(const FString& Msg)
{
	bValidFaceAnimData = false;
	bDebugLoopAnim = false;
	TArray<UKGAudioInputComponent*> Comps;
	GetOwner()->GetComponents(Comps);
	if (Comps.Num() > 0)
	{
		Comps[0]->StopAudioInputEvent();
	}

	// 后续再异步处理
	if(bControlRigData)
	{
		DoLoadCtrlRigJson(Msg);		
	}

	if(bSkeletalBoneData)
	{
		DoLoadFaceBoneJson(Msg);		
		for (auto& It : AnimInstList)
		{
			if (It)
			{
				It->SetWebSequenceAsset(SkeletalFaceAnimData, 0);
			}
		}
	}
}


static int GAI3DNPCFPS = 0;
static FAutoConsoleVariableRef CVarGAI3DNPCFPS(
	TEXT("ai3dnpc.fps"),
	GAI3DNPCFPS,
	TEXT("ai3dnpc.fps"),
	ECVF_Default);

void UAIAnimCtrlComponent::UnitTest()
{
	// ...
	if (bDebugOnBegin)
	{
		auto OldValue = bDebugLoopAnim;
		ReqAI("");
		bDebugLoopAnim = OldValue;
	}
}

void UAIAnimCtrlComponent::ReqAsyncLoadAsset(const FName Asset)
{
	TArray<FSoftObjectPath> ToLoadPathList;
	ToLoadPathList.Add(Asset.ToString());

	int32 InPriority = 0;
	int ReqId = LastReqId++;
	FStreamableManager& StreamableManager = UAssetManager::GetStreamableManager();
	const TSharedPtr<FStreamableHandle> HandleHolder = StreamableManager.RequestAsyncLoad(
			ToLoadPathList,
			FStreamableDelegate::CreateUObject(this, &UAIAnimCtrlComponent::OnCompleteAsyncLoadAsset, ReqId),
			InPriority
		);
	
	auto ReqInfo = MakeShared<FAsyncAssetInfo>();
	ReqInfo->Id = ReqId;
	ReqInfo->Handle = HandleHolder;
	ReqInfo->Asset = Asset;
	AsyncLoadMap.Add(ReqId, ReqInfo);
}

void UAIAnimCtrlComponent::CancalAllAsyncLoad()
{
	for(auto& It : AsyncLoadMap)
	{
		if(It.Value.IsValid() && It.Value->Handle.IsValid())
		{
			It.Value->Handle->CancelHandle();			
		}
	}
	AsyncLoadMap.Empty();
}

void UAIAnimCtrlComponent::OnCompleteAsyncLoadAsset(int Id)
{
	auto Ptr = AsyncLoadMap.Find(Id);
	if(Ptr != nullptr)
	{
		auto One = *Ptr;
		if(One->Handle.IsValid() && One->Handle->HasLoadCompleted())
		{
			for(int i=0; i<BodyAnimList.Num(); i++)
			{
				if(BodyAnimList[i].AnimPath == One->Asset)
				{
					BodyAnimList[i].Anim = One->Handle->GetLoadedAsset<UAnimSequence>();
					if(BodyAnimList[i].Anim == nullptr)
					{
						UE_LOG(LogAI3DNPC, Warning, TEXT("failed load anim:%s"), *BodyAnimList[i].AnimPath.ToString());
					}
				}
			}	
		}
		
		AsyncLoadMap.Remove(Id);
	}
}

void UAIAnimCtrlComponent::DoLoadCtrlRigJson(const FString& InFileName)
{
	if (!bControlRigData)
	{
		return;
	}

	{
		FString JsonString;
		//FString InputJsonFile(TEXT("char_A_20260105_223426.json"));
		FString InputJsonFile(TEXT("ai3dnpc_1768816000.json"));
		if (InFileName.EndsWith(".json"))
		{
			InputJsonFile = InFileName;
		}
		FString FilePath = GetAIFaceRootDir() / InputJsonFile;
		TSharedPtr<FJsonObject> JsonObject = LoadJsonObject(FilePath);
		if(!JsonObject)
		{
			return;
		}

		TArray<TArray<float>> JsonResponseAnims;
		float JsonResponseFrameRate = 0;
		TArray<FJsonRawStructAction> JsonResponseActions;
		FString audioBase64;
		
		{			
			for (const auto& Entry : JsonObject->Values)
			{
				FString KeyName = Entry.Key;
				if (KeyName == "face_anim" || KeyName == "emotion")
				{
					const auto& RotationArray = Entry.Value->AsArray();
					for (const TSharedPtr<FJsonValue>& Value : RotationArray)
					{
						JsonResponseAnims.AddDefaulted();
						auto& Top = JsonResponseAnims[JsonResponseAnims.Num() - 1];
						const auto& ItArr = Value->AsArray();
						for (const TSharedPtr<FJsonValue>& V2 : ItArr)
						{
							float FV2 = V2->AsNumber();
							Top.Add(FV2);
						}
					}
				}
			}

			for (const auto& Entry : JsonObject->Values)
			{
				FString KeyName = Entry.Key;
				if (KeyName == "action")
				{
					/*
					"action": [
					  {
						"id": "wave_hello",
						"start_frame": 0,
						"frame_len": 120
					  },...
					]
					 */
					const auto& RotationArray = Entry.Value->AsArray();
					for (const TSharedPtr<FJsonValue>& Value : RotationArray)
					{						
						const TSharedPtr<FJsonObject>* OneActionPtr = nullptr;
						if(Value.Get()->TryGetObject(OneActionPtr) && OneActionPtr->Get())
						{
							FJsonRawStructAction one;
							for(const auto& V2It : OneActionPtr->Get()->Values)
							{
								if(V2It.Key == "id")
								{
									one.Id = V2It.Value->AsString();
								}
								if(V2It.Key == "start_frame")
								{
									one.StartFrame = (int)V2It.Value->AsNumber();
								}
								if(V2It.Key == "frame_len")
								{
									one.FrameLen = (int)V2It.Value->AsNumber();
								}
							}
							if(one.FrameLen > 0 && !one.Id.IsEmpty())
							{
								JsonResponseActions.Add(one);								
							}
						}
					}
				}
			}		
			JsonObject->TryGetNumberField(TEXT("fps"), JsonResponseFrameRate);
			
			if (JsonObject->TryGetStringField(TEXT("audio_wave"), audioBase64)
				|| JsonObject->TryGetStringField(TEXT("audio"), audioBase64))
			{
			
			}
		}
		
		if (JsonResponseFrameRate <= 0)
		{
			JsonResponseFrameRate = 30;
		}
		if (GAI3DNPCFPS > 0)
		{
			JsonResponseFrameRate = GAI3DNPCFPS;
		}

		OneFrameTime = 1 / JsonResponseFrameRate;

		CtrlRigFaceAnimDataList.Empty();
		for (int i = 0; i < JsonResponseAnims.Num(); i++)
		{
			const auto& OneAnim = JsonResponseAnims[i];
			CtrlRigFaceAnimDataList.AddDefaulted();
			auto& Top = CtrlRigFaceAnimDataList[CtrlRigFaceAnimDataList.Num() - 1];
			SetData(Top.FaceAnimData, OneAnim);
		}
		AnimTotalTime = OneFrameTime * CtrlRigFaceAnimDataList.Num();
		
		{
			// 伪造调试数据
			int LastBodyAnimId = 0;
			for (int i = 0; i < CtrlRigFaceAnimDataList.Num() && JsonResponseFrameRate > 0; i++)
			{
				// 每隔2秒，更改一下肢体动作
				if (i % (2*int(JsonResponseFrameRate)) == 0)
				{
					auto NewBodyId = FMath::RandRange(1, 3);
					while (NewBodyId == LastBodyAnimId)
					{
						NewBodyId = FMath::RandRange(1, 3);
					}
					LastBodyAnimId = NewBodyId;
				}

				CtrlRigFaceAnimDataList[i].BodyAnimId = LastBodyAnimId;
			}			
		}
		
		// 设置第一帧数据
		if (CtrlRigFaceAnimDataList.Num() > 0)
		{
			SetBodyAnim(CtrlRigFaceAnimDataList[0].BodyAnimId);
		}

		if(audioBase64.Len() > 0)
		{
			TArray<uint8> Audio;
			FBase64::Decode(audioBase64, Audio);

			if(bDebugSoundData)
			{
				FFileHelper::SaveArrayToFile(Audio, *(GetAIFaceRootDir() / (InputJsonFile + TEXT(".wav"))));	
			}

			TArray<UKGAudioInputComponent*> Comps;
			GetOwner()->GetComponents(Comps);

			if (Comps.Num() == 0)
			{
				auto AudioComp = Cast<UKGAudioInputComponent>(GetOwner()->AddComponentByClass(UKGAudioInputComponent::StaticClass(), false, FTransform::Identity, false));
				if (AudioComp)
				{
					AudioComp->SetWorldTransform(GetOwner()->GetActorTransform());
				}
				GetOwner()->GetComponents(Comps);
			}

			if (Comps.Num() > 0 && Audio.Num() > 0)
			{
				//Comps[0]->PlayAudioInputEvent(Audio, bDebugLoopAnim, true);
				Comps[0]->PlayAudioInputEvent(Audio);
			}
		}
		
		SetFaceAnim(true);

		LastTime = 0;
		LastFaceTime = 0;
	}
}

FTransform ConvertMayaTransformToUE(
	float MayaLocX, float MayaLocY, float MayaLocZ,
	float MayaRotX, float MayaRotY, float MayaRotZ,
	float MayaScaleX, float MayaScaleY, float MayaScaleZ)
{

	FVector Loc(MayaLocX, -MayaLocY, MayaLocZ);
	FVector Rot(MayaRotX, -MayaRotY, -MayaRotZ);
	FVector Scale(MayaScaleX, MayaScaleY, MayaScaleZ);
	FTransform BoneTrans(FQuat::MakeFromEuler(Rot), Loc, Scale);
	return BoneTrans;
}

static int DistRoot(const TMap<FString, FString>& BoneTree, const FString& Root, const FString& Bone)
{
	int Ret = 0;
	auto Ptr = BoneTree.Find((Bone));
	while(Ptr != nullptr)
	{
		Ret++;
		if(*Ptr == Root)
		{
			return Ret;
		}
		auto ParentBone = *Ptr;
		Ptr = BoneTree.Find(ParentBone);
	}
	return Ret;
}
static void CalcWorldSpace(TArray<FTransform>& InOut, TArray<FString>& Bones, const TMap<FString, FString>& BoneTree)
{
	if(BoneTree.Num() == 0)
	{
		return;
	}

	TArray<FString> TempBones;
	if(Bones.Num() != BoneTree.GetKeys(TempBones))
	{
		return;
	}

	TArray<FTransform> OldData = InOut;

	// 转成世界坐标
	FString Root("face_root");
	TMap<int, TArray<FString>> BoneTreeNew;	
	for(const auto& It : BoneTree)
	{
		auto DistV = DistRoot(BoneTree, Root, It.Key);
		auto& Arr = BoneTreeNew.FindOrAdd(DistV);
		Arr.Add(It.Key);
	}

	int MaxKey = 0;
	for(const auto& It : BoneTreeNew)
	{
		MaxKey = FMath::Max<int>(It.Key, MaxKey);
	}
	
	for(int i=2; i<=MaxKey; i++)
	{
		auto Ptr = BoneTreeNew.Find(i);
		if(Ptr != nullptr)
		{
			for(const auto& V : *Ptr)
			{
				auto Me = V;
				auto Parent = BoneTree[V];

				auto MeIdx = Bones.IndexOfByKey(Me);
				auto ParentIdx = Bones.IndexOfByKey(Parent);
				if(InOut.IsValidIndex(MeIdx) && InOut.IsValidIndex(ParentIdx))
				{
					InOut[MeIdx] = InOut[ParentIdx] * InOut[MeIdx];					
				}
			}
		}
	}
}
FVector StringToFVector(const FString& VectorString)
{
	FVector Result = FVector::ZeroVector;
    
	// 尝试标准解析
	if (Result.InitFromString(VectorString))
	{
		return Result;
	}
    
	// 如果失败，尝试手动解析
	FString CleanStr = VectorString.TrimStartAndEnd().TrimChar('(').TrimChar(')');
    
	TArray<FString> Parts;
	CleanStr.ParseIntoArray(Parts, TEXT(","));
    
	for (const FString& Part : Parts)
	{
		TArray<FString> KeyValue;
		Part.ParseIntoArray(KeyValue, TEXT("="));
        
		if (KeyValue.Num() == 2)
		{
			float Value = FCString::Atof(*KeyValue[1]);
            
			if (KeyValue[0].Equals(TEXT("X"), ESearchCase::IgnoreCase))
				Result.X = Value;
			else if (KeyValue[0].Equals(TEXT("Y"), ESearchCase::IgnoreCase))
				Result.Y = Value;
			else if (KeyValue[0].Equals(TEXT("Z"), ESearchCase::IgnoreCase))
				Result.Z = Value;
		}
	}
    
	return Result;
}
FRotator ParseStringToFRotator(const FString& RotatorString)
{
	FRotator Result = FRotator::ZeroRotator;
    
	// 去除括号
	FString CleanStr = RotatorString.TrimStartAndEnd().TrimChar('(').TrimChar(')');
    
	TArray<FString> Parts;
	CleanStr.ParseIntoArray(Parts, TEXT(","));
    
	for (const FString& Part : Parts)
	{
		TArray<FString> KeyValue;
		Part.ParseIntoArray(KeyValue, TEXT("="));
        
		if (KeyValue.Num() == 2)
		{
			float Value = FCString::Atof(*KeyValue[1]);
            
			if (KeyValue[0].Equals(TEXT("Pitch"), ESearchCase::IgnoreCase))
				Result.Pitch = Value;
			else if (KeyValue[0].Equals(TEXT("Yaw"), ESearchCase::IgnoreCase))
				Result.Yaw = Value;
			else if (KeyValue[0].Equals(TEXT("Roll"), ESearchCase::IgnoreCase))
				Result.Roll = Value;
		}
	}
    
	return Result;
}

// AI服务返回的数据
bool UAIAnimCtrlComponent::DoLoadFaceBoneJsonUseAIAnimV2(const FString& InFileName)
{
	if (!bSkeletalBoneData_AIReq)
	{
		return false;
	}

	FString JsonString;
	FString JsonString2;
	FString InputJsonFile("ai3dnpc_1770175930.json"); // ai3dnpc_1770175930 ai3dnpc_1770111056
	if (InFileName.EndsWith(".json"))
	{
		InputJsonFile = InFileName;
	}
	FString FilePath = GetAIFaceRootDir() / InputJsonFile;

	TSharedPtr<FJsonObject> JsonObject = LoadJsonObject(FilePath);
	if(!JsonObject)
	{
		return false;
	}
	
	FString FilePath2 = GetAIFaceRootDir() / FString("bone_v1.json");
	TSharedPtr<FJsonObject> JsonObject2 = LoadJsonObject(FilePath2);
	if(!JsonObject2)
	{
		UE_LOG(LogAI3DNPC, Warning, TEXT("缺少骨骼信息，无法播放脸部动画"));
		return false;
	}

	TMap<FString, FString> BoneTree;
	TArray<FString> JsonJointNames;
	{
		
		for (const auto& Entry : JsonObject2->Values)
		{
			FString KeyName = Entry.Key;
			if (KeyName == "joint_names")
			{
				const auto& RotationArray = Entry.Value->AsArray();
				for (const TSharedPtr<FJsonValue>& Value : RotationArray)
				{
					FString BoneName = Value->AsString();
					TArray<FString> BoneNames;
					BoneName.ParseIntoArray(BoneNames, TEXT("|"));
					JsonJointNames.Add(BoneNames.Num() > 0 ? BoneNames.Last() : BoneName);
					if(BoneNames.Num() > 1)
					{
						BoneTree.Add(BoneNames.Last(), BoneNames[BoneNames.Num()-2]);
					}
				}
			}
		}
	}
	if(JsonJointNames.Num() == 0)
	{
		return false;
	}

	// 解析json
	TArray<TArray<FTransform>> FaceAnims;
	TArray<int> Frames;
	FString audioBase64;
	float JsonResponseFrameRate = 0;
	TArray<FJsonRawStructActionV2> JsonResponseActions;
	TArray<int> EmotionShape;
	{
		for (const auto& Entry : JsonObject->Values)
		{
			FString KeyName = Entry.Key;
			if (KeyName == "emotion_shape")
			{
				const auto& emotion_shape = Entry.Value->AsArray();
				for (const TSharedPtr<FJsonValue>& Value : emotion_shape)
				{
					float v = Value->AsNumber();
					EmotionShape.Add((int)v);
				}
			}
		}
		if(EmotionShape.Num() != 3)
		{
			UE_LOG(LogAI3DNPC, Warning, TEXT("数据错误, EmotionShape.Num=%d"), EmotionShape.Num());
			return false;
		}
		int FrameCnt = EmotionShape[0];
		int RigCnt = EmotionShape[1];
		int TransDataCnt = EmotionShape[2];
		if(TransDataCnt <= 0 || RigCnt <= 0 || FrameCnt <= 0)
		{
			UE_LOG(LogAI3DNPC, Warning, TEXT("数据错误, TransDataCnt=%d, RigCnt=%d, FrameCnt=%d"),
				TransDataCnt, RigCnt, FrameCnt);
			return false;
		}
		if(RigCnt != JsonJointNames.Num())
		{
			UE_LOG(LogAI3DNPC, Warning, TEXT("数据错误, 骨骼数目错误！RigCnt=%d, joint_name.Num=%d"), RigCnt, JsonJointNames.Num());
			return false;
		}
		
		FString emotionBase64;
		if (JsonObject->TryGetStringField(TEXT("emotion"), emotionBase64))
		{			
			TArray<uint8> emotionBytes;
			FBase64::Decode(emotionBase64, emotionBytes);
			if(emotionBytes.Num() > 0 && emotionBytes.Num() % 4 == 0)
			{
				TArray<float> floatArr;
				floatArr.Reserve(emotionBytes.Num()/4);
				for(int i=0; i<emotionBytes.Num(); i+=4)
				{
					uint8* ptr = &emotionBytes[i];
					float v = 0;
					FMemory::Memcpy(&v, ptr, 4);
					floatArr.Add(v);
				}

				if(floatArr.Num() != (FrameCnt*RigCnt*TransDataCnt))
				{
					// 数据不对
					UE_LOG(LogAI3DNPC, Warning, TEXT("数据错误, emotion.Num=%d, deserve=%d"),
						floatArr.Num(), (FrameCnt*RigCnt*TransDataCnt));
					return false;
				}
				// 是不是9的倍数
				if(floatArr.Num() % (RigCnt*TransDataCnt) == 0)
				{
					FaceAnims.Empty();
					FaceAnims.Reserve(floatArr.Num() / (RigCnt*TransDataCnt));
					int Idx = 0;
					for(int f=0; f<FrameCnt; f++)
					{
						FaceAnims.AddDefaulted();
						Frames.Add(Frames.Num());
						TArray<FTransform>& OneFrameTransRef = FaceAnims.Last();
						for(int R=0; R<RigCnt; R++)
						{		
							if((Idx+TransDataCnt) >= floatArr.Num())
							{
								break;
							}					
							float* RawTransformValue = &floatArr[Idx];
							FTransform BoneTrans = FTransform::Identity;
							if(TransDataCnt == 9)
							{
								BoneTrans = ConvertMayaTransformToUE(RawTransformValue[0], RawTransformValue[1], RawTransformValue[2],
							RawTransformValue[3], RawTransformValue[4], RawTransformValue[5],
							RawTransformValue[6], RawTransformValue[7], RawTransformValue[8]);
								
							}
							else if(TransDataCnt == 6)
							{
								BoneTrans = ConvertMayaTransformToUE(RawTransformValue[0], RawTransformValue[1], RawTransformValue[2],
							RawTransformValue[3], RawTransformValue[4], RawTransformValue[5],
							1, 1, 1);								
							}
							else if(TransDataCnt == 3)
							{
								BoneTrans = ConvertMayaTransformToUE(0, 0, 0,
									FMath::RadiansToDegrees(RawTransformValue[0]), 
									FMath::RadiansToDegrees(RawTransformValue[1]), 
									FMath::RadiansToDegrees(RawTransformValue[2]),
							1, 1, 1);							
							}
							OneFrameTransRef.Add(BoneTrans);

							Idx += TransDataCnt;
						}
						if((Idx+TransDataCnt) >= floatArr.Num())
						{
							break;
						}						
					}
				}
			}			
		}

		JsonObject->TryGetNumberField(TEXT("fps"), JsonResponseFrameRate);
		
		if (JsonObject->TryGetStringField(TEXT("audio_wave"), audioBase64)
			|| JsonObject->TryGetStringField(TEXT("audio"), audioBase64))
		{
			
		}
		for (const auto& Entry : JsonObject->Values)
		{
			FString KeyName = Entry.Key;
			if (KeyName == "action")
			{
				/*
				"action":[{"path":"/Game/Arts/Character/Animation/Common/Female/Performance/Stand/A_F_Salute_02","offset":0.0},
					{"path":"/Game/Arts/Character/Animation/Common/Female/Performance/Stand/A_F_Talk_NodHead","offset":0.5}]
				 */
				const auto& RotationArray = Entry.Value->AsArray();
				for (const TSharedPtr<FJsonValue>& Value : RotationArray)
				{						
					const TSharedPtr<FJsonObject>* OneActionPtr = nullptr;
					if(Value.Get()->TryGetObject(OneActionPtr) && OneActionPtr->Get())
					{
						FJsonRawStructActionV2 one;
						for(const auto& V2It : OneActionPtr->Get()->Values)
						{
							if(V2It.Key == "path")
							{
								one.path = V2It.Value->AsString();
							}
							if(V2It.Key == "offset")
							{
								one.offset = (int)V2It.Value->AsNumber();
							}
						}
						if(!one.path.IsEmpty())
						{
							JsonResponseActions.Add(one);								
						}
					}
				}
			}
		}	
	}
	if (Frames.Num() == 0 || JsonJointNames.Num() == 0)
	{
		return false;
	}
	if (JsonResponseFrameRate <= 0)
	{
		JsonResponseFrameRate = 60;
	}

	OneFrameTime = 1 / JsonResponseFrameRate;
	AnimTotalTime = OneFrameTime * Frames.Num();


	// 必要的检查
	if (FaceAnims.Num() != Frames.Num())
	{
		UE_LOG(LogAI3DNPC, Warning, TEXT("数据对不上！%d != %d"), FaceAnims.Num(), Frames.Num());
		return false;
	}
	
	TMap<FString, FString> TPoseInfo = {};

#if false
	// 测试数据
	TPoseInfo = {
		{"cn_mouth_root", "(X=0.902143,Y=8.545412,Z=0.118848)(Pitch=-89.268208,Yaw=90.588262,Roll=-5.783649)"},
		{"cn_mouth_root|cn_downlip_root", "(X=0.001664,Y=0.569473,Z=-0.726283)(Pitch=-0.000003,Yaw=-0.000000,Roll=0.000456)"},
		{"cn_mouth_root|cn_uplip_root", "(X=0.001664,Y=-0.370453,Z=-0.355764)(Pitch=-0.000003,Yaw=-0.000000,Roll=0.000456)"},
		{"cn_nose_root", "(X=4.580915,Y=8.459032,Z=0.116530)(Pitch=-89.268170,Yaw=90.587068,Roll=-5.782099)"},
		{"lf_ear_root", "(X=4.548492,Y=-0.449991,Z=-5.765545)(Pitch=-89.268182,Yaw=90.588275,Roll=-4.895328)"},
		{"lf_eye_root|lf_downeyelid_root", "(X=-0.000001,Y=0.110947,Z=0.163769)(Pitch=-0.000009,Yaw=-0.000008,Roll=0.000014)"},
		{"lf_eye_root|lf_upeyelid_root", "(X=-0.000003,Y=-0.115097,Z=0.160029)(Pitch=-0.000009,Yaw=-0.000008,Roll=0.000014)"},
		{"lf_eyebrow_root", "(X=8.377592,Y=7.299829,Z=-2.984608)(Pitch=-89.268182,Yaw=90.588275,Roll=-4.895328)"},
		{"rt_ear_root", "(X=4.548111,Y=-0.611896,Z=5.750917)(Pitch=-89.268181,Yaw=90.589647,Roll=171.532701)"},
		{"rt_eye_root", "(X=6.596724,Y=6.265017,Z=2.630182)(Pitch=-89.268181,Yaw=90.589647,Roll=171.532701)"},
		{"rt_eye_root|rt_downeyelid_root", "(X=-0.000001,Y=-0.120911,Z=-0.156565)(Pitch=0.000027,Yaw=-0.000000,Roll=-0.000902)"},
		{"rt_eye_root|rt_upeyelid_root", "(X=-0.000003,Y=0.105865,Z=-0.166939)(Pitch=0.000027,Yaw=-0.000000,Roll=-0.000902)"},
		{"rt_eyebrow_root", "(X=8.379210,Y=7.221172,Z=3.167330)(Pitch=-89.268181,Yaw=90.589647,Roll=171.532701)"},
	};
#endif
	
	TMap<FString, FTransform> TPoseTransform;
	for (const auto& It : TPoseInfo)
	{
		auto Key = It.Key;
		auto V = It.Value;
		TArray<FString> Bones;
		Key.ParseIntoArray(Bones, TEXT("|"));
		if (Bones.Num() == 0)
		{
			continue;
		}

		auto Idx = V.Find(TEXT("(Pitch="));
		FString LocStr, RotStr;
		if (Idx >= 0)
		{
			LocStr = V.Mid(0, Idx);
			RotStr = V.Mid(Idx);
		}
		else
		{
			continue;
		}
		auto RotV = ParseStringToFRotator(RotStr);
		auto LocV = StringToFVector(LocStr);
		FTransform Trans(RotV, LocV, FVector::One());
		TPoseTransform.Add(Bones.Last(), Trans);
	}
	TArray<FString> TPoseBones;
	TPoseTransform.GetKeys(TPoseBones);

	// 解析
	float DeltaSecond = OneFrameTime;
	SkeletalFaceAnimData.bLooping = false;
	SkeletalFaceAnimData.Duration = DeltaSecond * Frames.Last();
	SkeletalFaceAnimData.BoneTracks.Empty();
	SkeletalFaceAnimData.BoneTracks.Reserve(JsonJointNames.Num() + TPoseBones.Num());
	for (const auto& It : JsonJointNames)
	{
		FC7BoneAnimationTrack One;
		One.BoneName = It;
		One.Keyframes.Reserve(Frames.Num());
		SkeletalFaceAnimData.BoneTracks.Add(One);
	}
	for (int iFrame = 0; iFrame < FaceAnims.Num(); iFrame++)
	{
		const auto& OneFrameData = FaceAnims[iFrame];
		if (OneFrameData.Num() != JsonJointNames.Num())
		{
			UE_LOG(LogAI3DNPC, Warning, TEXT("数据对不上！i=%d, %d != %d"), iFrame, OneFrameData.Num(), JsonJointNames.Num());
			continue;
		}

		float Time = Frames[iFrame] * DeltaSecond;
		for (int boneId = 0; boneId < OneFrameData.Num(); boneId++)
		{
			if(!SkeletalFaceAnimData.BoneTracks.IsValidIndex(boneId))
			{
				continue;
			}
			
			const auto& Trans = OneFrameData[boneId];

			FBoneKeyframe One;
			One.Time = Time;
			One.Location = Trans.GetLocation();
			One.Rotation = Trans.GetRotation().Rotator();
			One.Scale = Trans.GetScale3D();
			SkeletalFaceAnimData.BoneTracks[boneId].Keyframes.Add(One);
		}
	}
	if (SkeletalFaceAnimData.BoneTracks.Num() > 0)
	{
		int FrameCnt = SkeletalFaceAnimData.BoneTracks[0].Keyframes.Num();
		for (int i = 0; i < TPoseBones.Num(); i++)
		{
			const auto& TPoseBone = TPoseBones[i];
			auto Trans = TPoseTransform[TPoseBone];
			SkeletalFaceAnimData.BoneTracks.AddDefaulted();
			auto& TopRef = SkeletalFaceAnimData.BoneTracks.Last();
			TopRef.BoneName = TPoseBone;
			TopRef.Keyframes.Reserve(FrameCnt);
			for (int j = 0; j < FrameCnt; j++)
			{
				const auto& Other = SkeletalFaceAnimData.BoneTracks[0].Keyframes[j];
				FBoneKeyframe One;
				One.Time = Other.Time;
				One.Location = Trans.GetLocation();
				One.Rotation = Trans.GetRotation().Rotator();
				One.Scale = Trans.GetScale3D();
				TopRef.Keyframes.Add(One);
			}
		}
	}

	// 设置身体动画
	BodyAnimList.Empty();
	for(const auto& It : JsonResponseActions)
	{
		float LastAnimTime = 0;
		if(BodyAnimList.Num() > 0)
		{
			LastAnimTime = BodyAnimList.Last().Time + BodyAnimList.Last().AnimLength;
		}
		
		FAIBodyAnimCtrlData One;
		One.Time = LastAnimTime + It.offset;
		One.AnimLength = 0;
		// file: /Game/Arts/Character/Animation/Common/Female/Performance/Stand/A_F_Talk_NodHead
		FString PackageName = ToPackageName(It.path);
		One.AnimPath = TCHAR_TO_UTF8(*PackageName);
		One.Anim = nullptr;		
		auto Anim = LoadObject<UAnimSequence>(nullptr, *One.AnimPath.ToString());
		if(Anim)
		{
			One.Anim = Anim;
			One.AnimLength = Anim->GetPlayLength();
		}
		BodyAnimList.Add(One);
	}
	BodyAnimList.Sort([](const FAIBodyAnimCtrlData& A, const FAIBodyAnimCtrlData& B)
	{
		return A.Time < B.Time;
	});
	for(int i=0; i<BodyAnimList.Num()-1; i++)
	{
		if(BodyAnimList[i].AnimLength == 0)
		{
			continue;
		}
		float GapTime = BodyAnimList[i+1].Time - BodyAnimList[i].Time - BodyAnimList[i].AnimLength;
		if(GapTime > AnimBlendTime)
		{
			FAIBodyAnimCtrlData One;
			One.Time = BodyAnimList[i].Time + BodyAnimList[i].AnimLength;
			One.AnimLength = GapTime;
			One.AnimPath = IDLE_ANIM;
			BodyAnimList.Insert(One, i+1);
			i++;
		}
	}
	// 补充idle动作（最后一个一定是idle动作）
	if(BodyAnimList.Num() == 0)
	{
		FAIBodyAnimCtrlData One;
		One.Time = 0;
		One.AnimLength = AnimTotalTime;
		One.AnimPath = IDLE_ANIM;
		BodyAnimList.Add(One);		
	}
	else
	{
		auto LastAnim = BodyAnimList.Last();
		auto DeltaTime = AnimTotalTime - (LastAnim.Time + LastAnim.AnimLength); 
		FAIBodyAnimCtrlData One;
		One.Time = LastAnim.Time + LastAnim.AnimLength;
		One.AnimLength = DeltaTime;
		One.AnimPath = IDLE_ANIM;
		BodyAnimList.Add(One);
	}

	// 加载body资产
	{
		TSet<FName> PendingLoadAsset;
		for(int i=1; i<BodyAnimList.Num(); i++)
		{
			if(BodyAnimList[i].AnimPath != IDLE_ANIM)
			{
				PendingLoadAsset.Add(BodyAnimList[i].AnimPath);
			}
		}
		
		// 第一个同步加载，之后的都异步加载。后续再全部改成异步加载。
		auto PtrTop = &BodyAnimList[0];
		auto Anim = LoadObject<UAnimSequence>(nullptr, *PtrTop->AnimPath.ToString());
		if(Anim)
		{
			PtrTop->Anim = Anim;
		}
		for(const auto& It : PendingLoadAsset)
		{
			ReqAsyncLoadAsset(It);	
		}
	}
	
	
	LastBodyTime = 0;
	LastBodyAnimIdx = -1;
	SetBodyAnimNew(0);
	
	if(audioBase64.Len() > 0)
	{
		TArray<uint8> Audio;
		FBase64::Decode(audioBase64, Audio);

		if(bDebugSoundData)
		{
			FFileHelper::SaveArrayToFile(Audio, *(GetAIFaceRootDir() / (InputJsonFile + TEXT(".wav"))));			
		}

		TArray<UKGAudioInputComponent*> Comps;
		GetOwner()->GetComponents(Comps);

		if (Comps.Num() == 0)
		{
			auto AudioComp = Cast<UKGAudioInputComponent>(GetOwner()->AddComponentByClass(UKGAudioInputComponent::StaticClass(), false, FTransform::Identity, false));
			if (AudioComp)
			{
				AudioComp->SetWorldTransform(GetOwner()->GetActorTransform());
			}
			GetOwner()->GetComponents(Comps);
		}

		if (Comps.Num() > 0 && Audio.Num() > 0)
		{
			// Comps[0]->PlayAudioInputEvent(Audio, bDebugLoopAnim, true);
			Comps[0]->PlayAudioInputEvent(Audio);
		}
	}

	return true;
}
bool UAIAnimCtrlComponent::DoLoadFaceBoneJsonUseAIAnim(const FString& InFileName)
{	
	if (!bSkeletalBoneData_OldV1)
	{
		return false;
	}

	FString JsonString;
	FString InputJsonFile("aaa.json");
	if (InFileName.EndsWith(".json"))
	{
		InputJsonFile = InFileName;
	}
	FString FilePath = GetAIFaceRootDir() / InputJsonFile;
	TSharedPtr<FJsonObject> JsonObject = LoadJsonObject(FilePath);
	if(!JsonObject)
	{
		return false;
	}
	

	// 解析json
	TArray<FString> JsonJointNames;
	TArray<TArray<FTransform>> FaceAnims;
	TArray<int> Frames;
	TMap<FString,FString> BoneTree;
	{
		for (const auto& Entry : JsonObject->Values)
		{
			FString KeyName = Entry.Key;
			if (KeyName == "joint_names")
			{
				const auto& RotationArray = Entry.Value->AsArray();
				for (const TSharedPtr<FJsonValue>& Value : RotationArray)
				{
					FString BoneName = Value->AsString();
					TArray<FString> BoneNames;
					BoneName.ParseIntoArray(BoneNames, TEXT("|"));
					JsonJointNames.Add(BoneNames.Num() > 0 ? BoneNames.Last() : BoneName);
					if(BoneNames.Num() > 1)
					{
						BoneTree.Add(BoneNames.Last(), BoneNames[BoneNames.Num()-2]);
					}
				}
			}
			if (KeyName == "anim_data")
			{
				const auto& RotationArray = Entry.Value->AsArray();
				FaceAnims.Empty();
				FaceAnims.Reserve(RotationArray.Num());
				for (const TSharedPtr<FJsonValue>& Value : RotationArray)
				{
					FaceAnims.AddDefaulted();
					TArray<FTransform>& OneFrameTransRef = FaceAnims.Last();
					
					const auto& RotationArray2 = Value->AsArray();
					OneFrameTransRef.Reserve(RotationArray2.Num());
					for (const TSharedPtr<FJsonValue>& Value2 : RotationArray2)
					{
						const auto& RotationArray3 = Value2->AsArray();
						TArray<float> RawTransformValue;
						for (const TSharedPtr<FJsonValue>& Value3 : RotationArray3)
						{
							RawTransformValue.Add(Value3->AsNumber());
						}
						if(RawTransformValue.Num() == 9)
						{
							/*
								[
									7.844174385070801,
									-8.280083656311035,
									0.11632313579320908,
									-0.05103183910250664,
									-0.7299366593360901,
									-86.58631896972656,
									1.0,
									1.0,
									1.0
								]
							 */
							//FVector Loc(RawTransformValue[0], RawTransformValue[2], RawTransformValue[1]);
							//FVector Rot(RawTransformValue[3], -RawTransformValue[4], RawTransformValue[5]);
							//FVector Scale(RawTransformValue[6], RawTransformValue[7], RawTransformValue[8]);
							//FTransform BoneTrans(FQuat::MakeFromEuler(Rot), Loc, Scale);
							FTransform BoneTrans = ConvertMayaTransformToUE(RawTransformValue[0], RawTransformValue[1], RawTransformValue[2],
								RawTransformValue[3], RawTransformValue[4], RawTransformValue[5],
								RawTransformValue[6], RawTransformValue[7], RawTransformValue[8]);
							OneFrameTransRef.Add(BoneTrans);
						}
						else
						{
							UE_LOG(LogAI3DNPC, Warning, TEXT("数据错误, anim_data数据格式不对：%d"), RawTransformValue.Num());
						}
					}
					//CalcWorldSpace(OneFrameTransRef, JsonJointNames, BoneTree);
				}				
			}
			
			if (KeyName == "frames")
			{
				const auto& RotationArray = Entry.Value->AsArray();
				for (const TSharedPtr<FJsonValue>& Value : RotationArray)
				{
					Frames.Add((int)Value->AsNumber());
				}
			}
		}
	}
	if (Frames.Num() == 0 || JsonJointNames.Num() == 0)
	{
		UE_LOG(LogAI3DNPC, Warning, TEXT("数据错误, Frames.Num=%d, JsonJointNames.Num=%d"), Frames.Num(), JsonJointNames.Num());
		return false;
	}


	// 必要的检查
	if(FaceAnims.Num() != Frames.Num())
	{
		UE_LOG(LogAI3DNPC, Warning, TEXT("数据对不上！%d != %d"), FaceAnims.Num(), Frames.Num());
		return false;
	}
	// 补充数据
	TMap<FString, FString> TPoseInfo = {};

#if false
	TPoseInfo =
	{
		{"cn_mouth_root", "(X=0.902143,Y=8.545412,Z=0.118848)(Pitch=-89.268208,Yaw=90.588262,Roll=-5.783649)"},
		{"cn_mouth_root|cn_downlip_root", "(X=0.001664,Y=0.569473,Z=-0.726283)(Pitch=-0.000003,Yaw=-0.000000,Roll=0.000456)"},
		{"cn_mouth_root|cn_uplip_root", "(X=0.001664,Y=-0.370453,Z=-0.355764)(Pitch=-0.000003,Yaw=-0.000000,Roll=0.000456)"},
		{"cn_nose_root", "(X=4.580915,Y=8.459032,Z=0.116530)(Pitch=-89.268170,Yaw=90.587068,Roll=-5.782099)"},
		{"lf_ear_root", "(X=4.548492,Y=-0.449991,Z=-5.765545)(Pitch=-89.268182,Yaw=90.588275,Roll=-4.895328)"},
		{"lf_eye_root|lf_downeyelid_root", "(X=-0.000001,Y=0.110947,Z=0.163769)(Pitch=-0.000009,Yaw=-0.000008,Roll=0.000014)"},
		{"lf_eye_root|lf_upeyelid_root", "(X=-0.000003,Y=-0.115097,Z=0.160029)(Pitch=-0.000009,Yaw=-0.000008,Roll=0.000014)"},
		{"lf_eyebrow_root", "(X=8.377592,Y=7.299829,Z=-2.984608)(Pitch=-89.268182,Yaw=90.588275,Roll=-4.895328)"},
		{"rt_ear_root", "(X=4.548111,Y=-0.611896,Z=5.750917)(Pitch=-89.268181,Yaw=90.589647,Roll=171.532701)"},
		{"rt_eye_root", "(X=6.596724,Y=6.265017,Z=2.630182)(Pitch=-89.268181,Yaw=90.589647,Roll=171.532701)"},
		{"rt_eye_root|rt_downeyelid_root", "(X=-0.000001,Y=-0.120911,Z=-0.156565)(Pitch=0.000027,Yaw=-0.000000,Roll=-0.000902)"},
		{"rt_eye_root|rt_upeyelid_root", "(X=-0.000003,Y=0.105865,Z=-0.166939)(Pitch=0.000027,Yaw=-0.000000,Roll=-0.000902)"},
		{"rt_eyebrow_root", "(X=8.379210,Y=7.221172,Z=3.167330)(Pitch=-89.268181,Yaw=90.589647,Roll=171.532701)"},
	};
#endif

	TMap<FString, FTransform> TPoseTransform;
	for(const auto& It : TPoseInfo)
	{
		auto Key = It.Key;
		auto V = It.Value;
		TArray<FString> Bones;
		Key.ParseIntoArray(Bones, TEXT("|"));
		if(Bones.Num() == 0)
		{
			continue;
		}
		
		auto Idx = V.Find(TEXT("(Pitch="));
		FString LocStr, RotStr;
		if(Idx >= 0)
		{
			LocStr = V.Mid(0, Idx);
			RotStr = V.Mid(Idx);
		}
		else
		{
			continue;
		}
		auto RotV = ParseStringToFRotator(RotStr);
		auto LocV = StringToFVector(LocStr);
		FTransform Trans(RotV, LocV, FVector::One());
		TPoseTransform.Add(Bones.Last(), Trans);
	}
	TArray<FString> TPoseBones;
	TPoseTransform.GetKeys(TPoseBones);

	// 解析
	int FPS = 60; // 测试数据，固定是60帧
	float DeltaSecond = 1.0f / FPS;
	SkeletalFaceAnimData.bLooping = false;
	SkeletalFaceAnimData.Duration = DeltaSecond * Frames.Last();
	SkeletalFaceAnimData.BoneTracks.Empty();
	SkeletalFaceAnimData.BoneTracks.Reserve(JsonJointNames.Num() + TPoseBones.Num());
	for(const auto& It : JsonJointNames)
	{
		FC7BoneAnimationTrack One;
		One.BoneName = It;
		One.Keyframes.Reserve(Frames.Num());
		SkeletalFaceAnimData.BoneTracks.Add(One);
	}
	for(int iFrame=0; iFrame<FaceAnims.Num(); iFrame++)
	{
		const auto& OneFrameData = FaceAnims[iFrame];
		if(OneFrameData.Num() != JsonJointNames.Num())
		{
			UE_LOG(LogAI3DNPC, Warning, TEXT("数据对不上！i=%d, %d != %d"), iFrame, OneFrameData.Num(), JsonJointNames.Num());
			continue;
		}
		
		float Time = Frames[iFrame] * DeltaSecond;
		for(int boneId=0; boneId<OneFrameData.Num(); boneId++)
		{
			if(!SkeletalFaceAnimData.BoneTracks.IsValidIndex(boneId))
			{
				continue;
			}
			const auto& Trans = OneFrameData[boneId];
			
			FBoneKeyframe One;
			One.Time = Time;
			One.Location = Trans.GetLocation();
			One.Rotation = Trans.GetRotation().Rotator();
			One.Scale = Trans.GetScale3D();
			SkeletalFaceAnimData.BoneTracks[boneId].Keyframes.Add(One);			
		}		
	}
	if(SkeletalFaceAnimData.BoneTracks.Num() > 0)
	{
		int FrameCnt = SkeletalFaceAnimData.BoneTracks[0].Keyframes.Num();
		for(int i=0; i<TPoseBones.Num(); i++)
		{
			const auto& TPoseBone = TPoseBones[i];
			auto Trans = TPoseTransform[TPoseBone];
			SkeletalFaceAnimData.BoneTracks.AddDefaulted();
			auto& TopRef = SkeletalFaceAnimData.BoneTracks.Last();
			TopRef.BoneName = TPoseBone;
			TopRef.Keyframes.Reserve(FrameCnt);
			for(int j=0; j<FrameCnt; j++)
			{
				const auto& Other = SkeletalFaceAnimData.BoneTracks[0].Keyframes[j];
				FBoneKeyframe One;
				One.Time = Other.Time;
				One.Location = Trans.GetLocation();
				One.Rotation = Trans.GetRotation().Rotator();
				One.Scale = Trans.GetScale3D();
				TopRef.Keyframes.Add(One);
			}
		}		
	}
	
	return true;
}
void UAIAnimCtrlComponent::DoLoadFaceBoneJson(const FString& InFileName)
{
	if (!bSkeletalBoneData)
	{
		return;
	}
	
	if(DoLoadFaceBoneJsonUseAIAnimV2(InFileName))
	{
		return;
	}
	
	if(DoLoadFaceBoneJsonUseUEAnim(InFileName))
	{
		return;
	}
	
	if(DoLoadFaceBoneJsonUseAIAnim(InFileName))
	{
		return;
	}
	
	FString InputJsonFile(TEXT("debug_bone_anim_aodaili.json"));
	DoLoadFaceBoneJsonUseAIAnim(InputJsonFile);
}


// 使用UE资产的数据（非AI的）
bool UAIAnimCtrlComponent::DoLoadFaceBoneJsonUseUEAnim(const FString& InFileName)
{
	if (!bSkeletalBoneData_UEAnim)
	{
		return false;
	}
	FString JsonString;
	FString InputJsonFile(TEXT("liubo_anim_test_audaili.json"));
	if (InFileName.EndsWith(".json"))
	{
		InputJsonFile = InFileName;
	}
	FString FilePath = GetAIFaceRootDir() / InputJsonFile;

	if (!FFileHelper::LoadFileToString(JsonString, *FilePath))
	{
		UE_LOG(LogAI3DNPC, Warning, TEXT("liubo, ai3dnpc, LoadSmplJson, Failed to load JSON file: %s"), *FilePath);
		return false;
	}

	FAnimExportOneAnim ExportData;
	if(!MyJsonToUStruct(ExportData, JsonString))
	{
		return false;
	}
	if (ExportData.AnimName.IsEmpty() 
		|| ExportData.TotalLength <= 0
		|| ExportData.NumFrames <= 0)
	{
		return false;
	}
	
	SkeletalFaceAnimData.bLooping = false;
	SkeletalFaceAnimData.Duration = ExportData.TotalLength;
	SkeletalFaceAnimData.BoneTracks.Empty();
	SkeletalFaceAnimData.BoneTracks.Reserve(ExportData.Bones.Num());
	for(const auto& It : ExportData.Bones)
	{
		FC7BoneAnimationTrack One;
		One.BoneName = It;
		One.Keyframes.Reserve(ExportData.Frames.Num());

		for(const auto& OneFrameData : ExportData.Frames)
		{
			int Idx = -1;
			for(int i=0; i<OneFrameData.BoneNameList.Num(); i++)
			{
				if(OneFrameData.BoneNameList[i] == One.BoneName)
				{
					Idx = i;
					break;
				}
			}
			if(Idx == -1)
			{
				continue;
			}
			auto Trans = OneFrameData.BoneTransforms[Idx];
			FBoneKeyframe OneFrame;
			OneFrame.Time = OneFrameData.Time;
			OneFrame.Location = Trans.GetLocation();
			OneFrame.Rotation = Trans.GetRotation().Rotator();
			OneFrame.Scale = Trans.GetScale3D();
			
			One.Keyframes.Add(OneFrame);		
		}
		
		SkeletalFaceAnimData.BoneTracks.Add(One);
	}
	
	return true;	
}
void UAIAnimCtrlComponent::SetAnimBp(const TArray<UAnimInstance*>& InAnimInstList)
{
	AnimInstList.Empty();
	for (const auto& It : InAnimInstList)
	{
		auto AiAnim = Cast<UAIFaceAnimInstance>(It);
		if (AiAnim)
		{
			AnimInstList.Add(AiAnim);
		}
	}

	C7AnimInstList.Empty();
	for (const auto& It : InAnimInstList)
	{
		auto C7AnimInst = Cast<UBaseAnimInstance>(It);
		if (C7AnimInst)
		{
			C7AnimInstList.Add(C7AnimInst);
		}
	}
}
void UAIAnimCtrlComponent::InitBodyAnimMap(UAnimInstance* BodyAnimInstance)
{

}

void UAIAnimCtrlComponent::SyncFaceAnimData()
{
	for (const auto& It : AnimInstList)
	{
		if (It)
		{
			It->FaceAnimAIData = LastAnimData;
		}
	}
}

void UAIAnimCtrlComponent::SetBodyAnim(int idx)
{
	for (auto& It : AnimInstList)
	{
		if (It)
		{
			It->BodyAnimIdx = idx;
		}
	}
}
void UAIAnimCtrlComponent::SetBodyAnimNew(int idx)
{
	if(LastBodyAnimIdx == idx)
	{
		return;
	}
	
	if(BodyAnimList.IsValidIndex(idx))
	{
		const auto& One = BodyAnimList[idx];
		LastBodyAnimIdx = idx;
		for (auto& It : AnimInstList)
		{
			if (It)
			{
				It->BodyAnimBlendChange(One.Anim);
			}
		}
	}
}
void UAIAnimCtrlComponent::SetFaceAnim(bool b)
{
	for (auto& It : AnimInstList)
	{
		if (It)
		{
			It->SetEnableFaceAnim(b);
		}
	}
}
void UAIAnimCtrlComponent::SetFaceAnimWeight(float w)
{
	for (auto& It : AnimInstList)
	{
		if (It)
		{
			It->FaceAnimWeight = w;
		}
	}
}
void UAIAnimCtrlComponent::OnFaceAnimEnd()
{
	SetFaceAnim(false);
	SetBodyAnim(0);
}