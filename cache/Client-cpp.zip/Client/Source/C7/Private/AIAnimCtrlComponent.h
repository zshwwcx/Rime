/**
 * Auth :   liubo
 * Date :   2026-02-07 15:21
 * Comment: 实验功能，有很多临时代码，不要正式使用
 */

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "3C/Animation/AIFaceAnimInstance.h"
#include "3C/Animation/BaseAnimInstance.h"
#include "Engine/StreamableManager.h"
#include "AIAnimCtrlComponent.generated.h"

USTRUCT(BlueprintType, Blueprintable)
struct FAIAnimCtrlData
{
	GENERATED_BODY();

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FAIFaceAnimData FaceAnimData;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	int BodyAnimId = 0;
};

USTRUCT(BlueprintType, Blueprintable)
struct FAIBodyAnimCtrlData
{
	GENERATED_BODY();

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float Time = 0;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float AnimLength = 0;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FName AnimPath;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TObjectPtr<UAnimSequence> Anim;
	
};

struct FJsonRawStructAction
{
	FString Id;
	FName AnimName;
	int StartFrame = 0;
	int FrameLen = 0;
};
struct FJsonRawStructActionV2
{
	FString path;
	float offset;
};

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent), Experimental )
class UAIAnimCtrlComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UAIAnimCtrlComponent();

protected:
	// Called when the game starts
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason);

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	

	UFUNCTION(BlueprintCallable)
	void ReqAI(const FString& Msg);
	
	UFUNCTION(BlueprintCallable)
	void SetAnimBp(const TArray<UAnimInstance*>& AnimInstList);
	
	UFUNCTION(BlueprintCallable)
	void InitBodyAnimMap(UAnimInstance* BodyAnimInstance);

	UFUNCTION(BlueprintCallable)
	void SyncFaceAnimData();

	UPROPERTY(BlueprintReadOnly, VisibleAnywhere)
		FAIFaceAnimData LastAnimData;
	UPROPERTY(BlueprintReadOnly, VisibleAnywhere)
		bool bValidFaceAnimData = false; // 是否有面部动画
	UPROPERTY(BlueprintReadOnly, EditAnywhere)
		bool bControlRigData = false; // 面部是否支持ControlRig数据
	UPROPERTY(BlueprintReadOnly, EditAnywhere)
		bool bSkeletalBoneData = true; // 面部是否支持骨骼数据
	UPROPERTY(BlueprintReadOnly, EditAnywhere)
		bool bSkeletalBoneData_AIReq = true; // 使用请求AI服务的数据
	UPROPERTY(BlueprintReadOnly, EditAnywhere)
		bool bSkeletalBoneData_OldV1 = true; // 昊洲给的临时json
	UPROPERTY(BlueprintReadOnly, EditAnywhere)
		bool bSkeletalBoneData_UEAnim = false; // 使用UE动画导出的数据
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		bool bDebugOnBegin = true;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		bool bDebugLoopAnim = true;
	UPROPERTY(BlueprintReadOnly, VisibleAnywhere)
		bool bDebugMode = false;
	UPROPERTY(BlueprintReadOnly, VisibleAnywhere)
		bool bDebugSoundData = false;
	UPROPERTY(BlueprintReadOnly, VisibleAnywhere)
		int AnimFrameIdx = 0;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float AnimBlendTime = 0.2f;

	UPROPERTY(Transient, VisibleAnywhere)
		TArray<UAIFaceAnimInstance*> AnimInstList;
	UPROPERTY(Transient, VisibleAnywhere)
		TArray<UBaseAnimInstance*> C7AnimInstList;

protected:
	UFUNCTION()
	void UnitTest();
	
	void ReqAsyncLoadAsset(const FName Asset);
	void CancalAllAsyncLoad();
	UFUNCTION()
		void OnCompleteAsyncLoadAsset(int Id);
	struct FAsyncAssetInfo
	{
		int Id = 0;
		FName Asset;
		TSharedPtr<FStreamableHandle> Handle;
	};
	TMap<int, TSharedPtr<FAsyncAssetInfo>> AsyncLoadMap;
	int LastReqId = 0;
	
private:
	void DoLoadCtrlRigJson(const FString& InFileName);
	void DoLoadFaceBoneJson(const FString& InFileName);
	bool DoLoadFaceBoneJsonUseUEAnim(const FString& InFileName);
	bool DoLoadFaceBoneJsonUseAIAnim(const FString& InFileName);
	bool DoLoadFaceBoneJsonUseAIAnimV2(const FString& InFileName);
	void SetBodyAnim(int idx);
	void SetBodyAnimNew(int idx);
	void SetFaceAnim(bool b);
	void SetFaceAnimWeight(float w);
	void OnFaceAnimEnd();
	void TickBodyAnim(float DeltaTime);
	
private:
	TArray<FAIAnimCtrlData> CtrlRigFaceAnimDataList; //CtrlRig格式的面部动画
	float LastTime = 0;
	float AnimTotalTime = 0;
	float OneFrameTime = 0;
	float LastFaceTime = 0;
	int LastFaceAnimIdx = 0;
		
	FCustomAnimationData SkeletalFaceAnimData; // 骨骼动画模式的面部动画

	// 角色身体动画，只支持一层
	TArray<FAIBodyAnimCtrlData> BodyAnimList;	
	float LastBodyTime = 0;
	int LastBodyAnimIdx = 0;
};
