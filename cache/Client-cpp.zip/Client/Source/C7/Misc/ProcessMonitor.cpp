/**
 * Copyright KuaiShou Games, Inc. All Right Reserved
 * Auth :   liubo11@kuaishou.com
 * Date :
 * Comment: 进程监控
 */


#include "ProcessMonitor.h"
#include "Misc/App.h"

#if PLATFORM_WINDOWS
#include "Windows/AllowWindowsPlatformTypes.h"
#include <Windows.h>
#include "Windows/HideWindowsPlatformTypes.h"
#pragma comment(lib, "version.lib")
#endif



void FProcessMonitor::SetEnv(bool bInAllowZombies, int InThreadId)
{
	bAllowZombies = bInAllowZombies;
	ThreadId = ENamedThreads::Type(InThreadId);
}

bool FProcessMonitor::IsProcessRunning(uint32 InProcessID)
{
#if PLATFORM_WINDOWS
	FProcHandle Handle = FPlatformProcess::OpenProcess(InProcessID);
	if (FPlatformProcess::IsProcRunning(Handle))
	{
		return true;
	}
#endif
	return false;
}
FString FProcessMonitor::GetVersionString(const FString& FullFilename, const FString& StrName)
{
	FString Result;

#if PLATFORM_WINDOWS
	DWORD Dummy = 0;
	DWORD Size = GetFileVersionInfoSizeW(*FullFilename, &Dummy);

	if (Size == 0)
	{
		return Result;
	}

	TArray<uint8> VersionInfo;
	VersionInfo.Empty(Size);
	if (!GetFileVersionInfoW(*FullFilename, 0, Size, VersionInfo.GetData()))
	{
		return Result;
	}

	// 1. 先获取翻译表
	struct LANGANDCODEPAGE {
		WORD language;
		WORD codePage;
	} *lpTranslate;

	UINT cbTranslate = 0;
	if (!VerQueryValueW(VersionInfo.GetData(), TEXT("\\VarFileInfo\\Translation"),
		(LPVOID*)&lpTranslate, &cbTranslate))
	{
		return Result;
	}

	// 2. 为每个语言代码页组合尝试获取字符串
	for (UINT i = 0; i < (cbTranslate / sizeof(LANGANDCODEPAGE)); i++)
	{
		// 构建查询路径：\StringFileInfo\{语言}{代码页}\{字符串名}
		TCHAR SubBlock[256];
		FCString::Sprintf(SubBlock, TEXT("\\StringFileInfo\\%04x%04x\\%s"),
			lpTranslate[i].language, lpTranslate[i].codePage,
			*StrName);
		SubBlock[255] = '\0';

		TCHAR* TempValue = nullptr;
		UINT TempValueLen = 0;

		if (VerQueryValueW(VersionInfo.GetData(), SubBlock, (LPVOID*)&TempValue, &TempValueLen)
			&& TempValue != nullptr)
		{
			return FString(TempValue);
		}
	}
#endif

	return Result;
}

FString FProcessMonitor::GetIdx(const FProcessInfo& Info, EProcessInfo N)
{
	switch (N)
	{
	case EProcessInfo::ExeName:
		return Info.ExeName;

	case EProcessInfo::FileDescription:
		return Info.FileDescription;

	case EProcessInfo::ProductName:
		return Info.ProductName;

	case EProcessInfo::CompanyName:
		return Info.CompanyName;

	case EProcessInfo::OriginalFilename:
		if (!Info.OriginalFilename.IsEmpty())
		{
			return Info.OriginalFilename;
		}
		return Info.ExeName;
	}

	return Info.ExeName;
}

FProcessInfo FProcessMonitor::GetProcessInfo(const FString& FullFilename)
{
	FProcessInfo Result;
	Result.ExeName = FPaths::GetCleanFilename(FullFilename);
	Result.FileDescription = GetVersionString(FullFilename, TEXT("FileDescription"));
	Result.ProductName = GetVersionString(FullFilename, TEXT("ProductName"));
	Result.CompanyName = GetVersionString(FullFilename, TEXT("CompanyName"));
	Result.OriginalFilename = GetVersionString(FullFilename, TEXT("OriginalFilename"));
	return Result;
}
TArray<FProcessInfo> FProcessMonitor::GetProcessList()
{
	TArray<FProcessInfo> Results;

#if PLATFORM_WINDOWS
	FPlatformProcess::FProcEnumerator ProcIter;
	TSet<FString> FullFileNameList;
	while (ProcIter.MoveNext())
	{
		FPlatformProcess::FProcEnumInfo ProcInfo = ProcIter.GetCurrent();
		auto FullFilename = ProcInfo.GetFullPath();
		if (FullFileNameList.Contains(FullFilename))
		{
			continue;
		}

		if (bAllowZombies || IsProcessRunning(ProcInfo.GetPID()))
		{
			Results.Add(GetProcessInfo(FullFilename));
			FullFileNameList.Add(FullFilename);
		}
	}
#endif
	return Results;
}

void FProcessMonitor::GetProcessList(FProcessListCallback Callback)
{
	auto ProcessList = GetProcessList();
	Callback.ExecuteIfBound(ProcessList);
}
void FProcessMonitor::AsyncGetProcessList(FProcessListCallback Callback)
{
	AsyncTask(ThreadId, [Callback]()
		{
			auto ProcessList = GetProcessList();
			AsyncTask(ENamedThreads::GameThread, [Callback, ProcessList]()
				{
					Callback.ExecuteIfBound(ProcessList);
				});
		});
}
void FProcessMonitor::GetProcessListAuto(FProcessListCallback Callback)
{
	if (ThreadId == ENamedThreads::GameThread)
	{
		GetProcessList(Callback);
	}
	else
	{
		AsyncGetProcessList(Callback);
	}
}
FString FProcessMonitor::Find(EProcessInfo N, const TArray<FString>& PendingProcessList)
{
	auto ProcessList = GetProcessList();
	FString FindStr;
	for (const auto& It : ProcessList)
	{
		// 数量少，就不做find优化了
		auto Key = GetIdx(It, N);
		if (!Key.IsEmpty() && PendingProcessList.Contains(Key))
		{
			FindStr = Key;
			break;
		}
	}
	return FindStr;
}
void FProcessMonitor::CheckHasProcess(EProcessInfo N, const TArray<FString>& PendingProcessList, FProcessCheckCallback Callback)
{
	auto FindStr = Find(N, PendingProcessList);
	Callback.ExecuteIfBound(FindStr);
}
void FProcessMonitor::AsyncCheckHasProcess(EProcessInfo N, const TArray<FString>& PendingProcessList, FProcessCheckCallback Callback)
{
	AsyncTask(ThreadId, [N, PendingProcessList, Callback]()
		{
			auto FindStr = Find(N, PendingProcessList);

			AsyncTask(ENamedThreads::GameThread, [FindStr, Callback]()
				{
					Callback.ExecuteIfBound(FindStr);
				});
		});
}
void FProcessMonitor::CheckHasProcessAuto(EProcessInfo N, const TArray<FString>& PendingProcessList, FProcessCheckCallback Callback)
{
	if (ThreadId == ENamedThreads::GameThread)
	{
		CheckHasProcess(N, PendingProcessList, Callback);
	}
	else
	{
		AsyncCheckHasProcess(N, PendingProcessList, Callback);
	}
}

bool FProcessMonitor::bAllowZombies = false;
ENamedThreads::Type FProcessMonitor::ThreadId = ENamedThreads::AnyHiPriThreadHiPriTask;



FAutoConsoleCommand CmdC7ProcessList(TEXT("c7.Process.list"), TEXT("c7.Process.list"),
	FConsoleCommandWithWorldArgsAndOutputDeviceDelegate::CreateLambda([](const TArray<FString>& Args, UWorld* InWorld, FOutputDevice& Ar)
		{
			auto StartTime = FPlatformTime::Cycles();
			auto ProcessList = FProcessMonitor::GetProcessList();
			auto EndTime = FPlatformTime::Cycles();
			auto Cost = FPlatformTime::ToMilliseconds(EndTime - StartTime);
			UE_LOG(LogTemp, Warning, TEXT("花费时间：%.2f(ms)"), Cost);
			for (const auto& It : ProcessList)
			{
				UE_LOG(LogTemp, Warning, TEXT("ProcessMonitory, proc: %s,%s,%s,%s,%s"),
					*It.ExeName,
					*It.FileDescription,
					*It.ProductName,
					*It.CompanyName,
					*It.OriginalFilename);
			}
		}));

FAutoConsoleCommand CmdC7ProcessList2(TEXT("c7.process.asynclist"), TEXT("c7.process.asynclist"),
	FConsoleCommandWithWorldArgsAndOutputDeviceDelegate::CreateLambda([](const TArray<FString>& Args, UWorld* InWorld, FOutputDevice& Ar)
		{
			FProcessListCallback Callback;
			Callback.BindLambda([](const TArray<FProcessInfo>& Results)
				{
					for (const auto& It : Results)
					{
						UE_LOG(LogTemp, Warning, TEXT("ProcessMonitory, proc: %s,%s,%s,%s,%s"),
							*It.ExeName,
							*It.FileDescription,
							*It.ProductName,
							*It.CompanyName,
							*It.OriginalFilename);
					}
				});
			FProcessMonitor::GetProcessListAuto(Callback);
		}));

FAutoConsoleCommand CmdC7ProcessList3(TEXT("c7.process.check"), TEXT("c7.process.check"),
	FConsoleCommandWithWorldArgsAndOutputDeviceDelegate::CreateLambda([](const TArray<FString>& Args, UWorld* InWorld, FOutputDevice& Ar)
		{
			int N = 0;
			TArray<FString> Pending;
			if (Args.Num() > 0)
			{
				N = FCString::Atoi(*Args[0]);
			}
			if (Args.Num() > 1)
			{
				Pending.Append(&Args[1], Args.Num() - 1);
			}
			FProcessCheckCallback Callback;
			Callback.BindLambda([](FString Result)
				{
					UE_LOG(LogTemp, Warning, TEXT("ProcessMonitory, find proc: %s"), *Result);
				});
			FProcessMonitor::CheckHasProcessAuto(EProcessInfo(N), Pending, Callback);
		}));