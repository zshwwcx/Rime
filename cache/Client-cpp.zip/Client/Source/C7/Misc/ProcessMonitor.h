/**
 * Copyright KuaiShou Games, Inc. All Right Reserved
 * Auth :   liubo11@kuaishou.com
 * Date :
 * Comment: 进程监控
 */

#pragma once

#include "CoreMinimal.h"
#include "Tasks/Task.h"
#include "ProcessMonitor.generated.h"

UENUM()
enum class EProcessInfo : uint8
{
	ExeName,
	FileDescription,
	ProductName,
	CompanyName,
	OriginalFilename,
	Unknown,
};

USTRUCT(BlueprintType)
struct FProcessInfo
{
	GENERATED_BODY()

	FProcessInfo() {}

	// 譬如C7.exe
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	FString ExeName;

	// 以下各个字段，有可能是空的（取决于exe文件的信息）
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	FString FileDescription;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	FString ProductName;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	FString CompanyName;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	FString OriginalFilename;
};

DECLARE_DELEGATE_OneParam(FProcessListCallback, const TArray<FProcessInfo>&);
DECLARE_DELEGATE_OneParam(FProcessCheckCallback, const FString&);

DECLARE_DYNAMIC_DELEGATE_OneParam(FProcessListDynCallback, const TArray<FProcessInfo>&, Result);
DECLARE_DYNAMIC_DELEGATE_OneParam(FProcessCheckDynCallback, const FString&, Result);
class FProcessMonitor
{
public:

	static void SetEnv(bool bAllowZombies, int ThreadId);

	static void GetProcessList(FProcessListCallback Callback);
	static void AsyncGetProcessList(FProcessListCallback Callback);
	static void GetProcessListAuto(FProcessListCallback Callback);

	static void CheckHasProcess(EProcessInfo N, const TArray<FString>& PendingProcessList, FProcessCheckCallback Callback);
	static void AsyncCheckHasProcess(EProcessInfo N, const TArray<FString>& PendingProcessList, FProcessCheckCallback Callback);
	static void CheckHasProcessAuto(EProcessInfo N, const TArray<FString>& PendingProcessList, FProcessCheckCallback Callback);

	static TArray<FProcessInfo> GetProcessList();
private:
	static FProcessInfo GetProcessInfo(const FString& FullFilename);
	static bool IsProcessRunning(uint32 InProcessID);
	static FString GetVersionString(const FString& FullFilename, const FString& stringName);
	static FString GetIdx(const FProcessInfo& Info, EProcessInfo N);
	static FString Find(EProcessInfo N, const TArray<FString>& PendingProcessList);


	static bool bAllowZombies;
	static ENamedThreads::Type ThreadId;
};
