#pragma once

#include "CoreMinimal.h"
#include "C7Define.generated.h"


USTRUCT(BlueprintType)
struct FBitmarkArray
{
	GENERATED_BODY()

public:
	UPROPERTY(BlueprintReadWrite)
	TArray<uint8> BitArray;
};


USTRUCT(BlueprintType)
struct FDumpClassInfo_Method
{
	GENERATED_BODY()	
public:
	UPROPERTY(BlueprintReadWrite)
	FString Expression;
	UPROPERTY(BlueprintReadWrite)
	FString Name;
	UPROPERTY(BlueprintReadWrite)
	FString ReturnType;

	UPROPERTY(BlueprintReadWrite)
	TArray<FString> Parameters;

	UPROPERTY(BlueprintReadWrite)
	FString CantBindReason;

	UPROPERTY(BlueprintReadWrite)
	FString CantInjectReason;
	UPROPERTY(BlueprintReadWrite)
	FString InjectLable;

	UPROPERTY(BlueprintReadWrite)
	bool IsBindable = true;
	UPROPERTY(BlueprintReadWrite)
	bool IsInjectable = false;
};

USTRUCT(BlueprintType)
struct FDumpClassInfo_Field
{
	GENERATED_BODY()	
public:
	UPROPERTY(BlueprintReadWrite)
	FString Expression;
	UPROPERTY(BlueprintReadWrite)
	FString Name;
	UPROPERTY(BlueprintReadWrite)
	FString Type;
	UPROPERTY(BlueprintReadWrite)
	FString CantBindReason;
	UPROPERTY(BlueprintReadWrite)
	bool IsBindable = true;
};

USTRUCT(BlueprintType)
struct FDumpClassInfo_Class
{
	GENERATED_BODY()	
public:
	UPROPERTY(BlueprintReadWrite)
	FString Name;

	UPROPERTY(BlueprintReadWrite)
	TArray<FString> Bases;
	UPROPERTY(BlueprintReadWrite)
	TArray<FString> Classes;
	
	UPROPERTY(BlueprintReadWrite)
	TArray<FDumpClassInfo_Method> Methods;
	
	UPROPERTY(BlueprintReadWrite)
	TArray<FDumpClassInfo_Field> Fields;
	
	UPROPERTY(BlueprintReadWrite)
	FString ClsCategory;
	UPROPERTY(BlueprintReadWrite)
	FString CantBindReason;
	UPROPERTY(BlueprintReadWrite)
	bool IsBindable = true;
};

USTRUCT(BlueprintType)
struct FDumpClassInfo_Namespace
{
	GENERATED_BODY()	
public:
	UPROPERTY(BlueprintReadWrite)
	FString Name;
	UPROPERTY(BlueprintReadWrite)
	FString Namespaces;
	
	UPROPERTY(BlueprintReadWrite)
	TArray<FDumpClassInfo_Class> Classes;
	UPROPERTY(BlueprintReadWrite)
	TArray<FDumpClassInfo_Method> Methods;
	UPROPERTY(BlueprintReadWrite)
	TArray<FDumpClassInfo_Field> Fields;	
};

USTRUCT(BlueprintType)
struct FDumpClassInfo_NestedNamespace
{
	GENERATED_BODY()	
public:
	UPROPERTY(BlueprintReadWrite)
	FString Name;

	UPROPERTY(BlueprintReadWrite)
	TArray<FDumpClassInfo_Namespace> Namespaces;
	
	UPROPERTY(BlueprintReadWrite)
	TArray<FDumpClassInfo_Class> Classes;
	UPROPERTY(BlueprintReadWrite)
	TArray<FDumpClassInfo_Method> Methods;
	UPROPERTY(BlueprintReadWrite)
	TArray<FDumpClassInfo_Field> Fields;	
};

USTRUCT(BlueprintType)
struct FDumpClassInfo_All
{
	GENERATED_BODY()	
public:
	UPROPERTY(BlueprintReadWrite)
	FDumpClassInfo_NestedNamespace RootNamespace;
	UPROPERTY(BlueprintReadWrite)
	TMap<FString, FDumpClassInfo_NestedNamespace> UnbindableContent;
	UPROPERTY(BlueprintReadWrite)
	FDumpClassInfo_NestedNamespace MultiInherent;
	UPROPERTY(BlueprintReadWrite)
	FDumpClassInfo_NestedNamespace DiamondInherent;
	UPROPERTY(BlueprintReadWrite)
	FDumpClassInfo_NestedNamespace FOIWithUStruct;
};


USTRUCT(BlueprintType)
struct FAnimExportOneFrame
{
	GENERATED_BODY()	
public:
	UPROPERTY(BlueprintReadWrite)
		int FrameId = 0;
	UPROPERTY(BlueprintReadWrite)
		float Time = 0;
	UPROPERTY(BlueprintReadWrite)
		TArray<FString> BoneNameList;
	UPROPERTY(BlueprintReadWrite)
		TArray<FTransform> BoneTransforms;
};

USTRUCT(BlueprintType)
struct FAnimExportOneAnim
{
	GENERATED_BODY()	
public:
	UPROPERTY(BlueprintReadWrite)
		FString AnimName;
	UPROPERTY(BlueprintReadWrite)
	float TotalLength = 0;
	UPROPERTY(BlueprintReadWrite)
	int NumFrames = 0;
	UPROPERTY(BlueprintReadWrite)
	int FrameRate = 0;
	UPROPERTY(BlueprintReadWrite)
		TArray<FString> Bones;
	UPROPERTY(BlueprintReadWrite)
		TArray<FAnimExportOneFrame> Frames;
	
	UPROPERTY(BlueprintReadWrite)
		TArray<FTransform> LocalPose;
	UPROPERTY(BlueprintReadWrite)
	TArray<FTransform> RetargetLocalPose;
	UPROPERTY(BlueprintReadWrite)
	TArray<FTransform> RetargetDeltaPose;
};
