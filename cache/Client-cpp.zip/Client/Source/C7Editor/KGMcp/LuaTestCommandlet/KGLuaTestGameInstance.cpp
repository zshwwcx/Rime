#include "KGLuaTestGameInstance.h"
#include "Engine/Engine.h"
#include "Framework/Application/SlateApplication.h"

// 定义专用的日志分类
DEFINE_LOG_CATEGORY_STATIC(LogKGLuaTestGameInstance, Log, All);

UKGLuaTestGameInstance::UKGLuaTestGameInstance()
{
	ActiveUIWidgets.Empty();
	LastErrorMessage.Empty();
}

UKGLuaTestGameInstance::~UKGLuaTestGameInstance()
{
	// 确保在销毁时清理所有UI
	CleanupAllUI();
}

#pragma region UI Management

bool UKGLuaTestGameInstance::AddUI(UUserWidget* Widget)
{
	if (!Widget)
	{
		SetLastError(TEXT("Widget is null"));
		return false;
	}

	// 检查是否已经添加过
	if (ActiveUIWidgets.Contains(Widget))
	{
		SetLastError(TEXT("Widget is already active"));
		return false;
	}

	if (AddUIToViewport(Widget))
	{
		ActiveUIWidgets.Add(Widget);
		ClearErrorMessage();
		return true;
	}

	return false;
}

bool UKGLuaTestGameInstance::RemoveUI(UUserWidget* Widget)
{
	if (!Widget)
	{
		SetLastError(TEXT("Widget is null"));
		return false;
	}

	// 检查是否在活动列表中
	if (!ActiveUIWidgets.Contains(Widget))
	{
		SetLastError(TEXT("Widget is not active"));
		return false;
	}

	if (RemoveUIFromViewport(Widget))
	{
		ActiveUIWidgets.Remove(Widget);
		ClearErrorMessage();
		return true;
	}

	return false;
}

FVector2D UKGLuaTestGameInstance::GetViewportSize() const
{
	// 不会真的执行
	return FVector2D(1920, 1080);
}

#pragma endregion UI Management

#pragma region Test Support

void UKGLuaTestGameInstance::CleanupAllUI()
{
	// 逆序移除所有UI（避免数组修改问题）
	for (int32 i = ActiveUIWidgets.Num() - 1; i >= 0; --i)
	{
		if (ActiveUIWidgets[i]->IsValidLowLevel())
		{
			RemoveUIFromViewport(ActiveUIWidgets[i].Get());
		}
	}
	
	ActiveUIWidgets.Empty();
	ClearErrorMessage();
}

int32 UKGLuaTestGameInstance::GetActiveUICount() const
{
	return ActiveUIWidgets.Num();
}

bool UKGLuaTestGameInstance::IsUIActive(UUserWidget* Widget) const
{
	return ActiveUIWidgets.Contains(Widget);
}

#pragma endregion Test Support

#pragma region Error Handling

FString UKGLuaTestGameInstance::GetLastErrorMessage() const
{
	return LastErrorMessage;
}

void UKGLuaTestGameInstance::ClearErrorMessage()
{
	LastErrorMessage.Empty();
}

#pragma endregion Error Handling

#pragma region Private Methods

bool UKGLuaTestGameInstance::AddUIToViewport(UUserWidget* Widget)
{
	return true;// 并不会真的添加！
}

bool UKGLuaTestGameInstance::RemoveUIFromViewport(UUserWidget* Widget)
{
	return true;
}

void UKGLuaTestGameInstance::SetLastError(const FString& ErrorMessage)
{
	LastErrorMessage = ErrorMessage;
	
	// 同时输出到日志
	UE_LOG(LogKGLuaTestGameInstance, Warning, TEXT("KGLuaTestGameInstance Error: %s"), *ErrorMessage);
}

#pragma endregion Private Methods 