#pragma once

#include "CoreMinimal.h"
#include "KGCore/Public/Lua/LuaEnv.h"
#include "LevelEditor.h"
#include "SLevelViewport.h"
#include "Blueprint/UserWidget.h"
#include "Slate/SceneViewport.h"
#include "KGLuaTestGameInstance.generated.h"

/**
 * Lua测试专用的GameInstance
 * 提供UI操作和测试相关的功能支持
 */
UCLASS(BlueprintType, Blueprintable)
class C7EDITOR_API UKGLuaTestGameInstance : public UEditorLuaGameInstanceBase
{
	GENERATED_BODY()

public:
	UKGLuaTestGameInstance();
	virtual ~UKGLuaTestGameInstance();

#pragma region LuaGameInstance Interface
	
	/**
	 * 重写GetLuaFilePath_Implementation，返回测试相关的Lua脚本路径
	 */
	FString GetLuaFilePath_Implementation() const override
	{
		return TEXT("Editor.LuaTestGameInstance");
	}
	
#pragma endregion LuaGameInstance Interface

#pragma region UI Management
	
	/**
	 * 在编辑器视口中添加UI Widget
	 * @param Widget 要添加的Widget
	 * @return 是否成功添加
	 */
	UFUNCTION(BlueprintCallable)
	bool AddUI(UUserWidget* Widget);

	/**
	 * 从编辑器视口中移除UI Widget
	 * @param Widget 要移除的Widget
	 * @return 是否成功移除
	 */
	UFUNCTION(BlueprintCallable)
	bool RemoveUI(UUserWidget* Widget);

	/**
	 * 获取当前视口大小
	 * @return 视口尺寸
	 */
	UFUNCTION(BlueprintCallable)
	FVector2D GetViewportSize() const;
	
#pragma endregion UI Management

#pragma region Test Support
	
	/**
	 * 清理所有已添加的UI元素（测试结束时调用）
	 */
	UFUNCTION(BlueprintCallable)
	void CleanupAllUI();

	/**
	 * 获取当前已添加的UI元素数量
	 * @return UI元素数量
	 */
	UFUNCTION(BlueprintCallable)
	int32 GetActiveUICount() const;

	/**
	 * 检查指定的Widget是否已被添加
	 * @param Widget 要检查的Widget
	 * @return 是否已被添加
	 */
	UFUNCTION(BlueprintCallable)
	bool IsUIActive(UUserWidget* Widget) const;


#pragma endregion Test Support

#pragma region Error Handling

	/**
	 * 获取最后一次操作的错误信息
	 * @return 错误信息，如果没有错误则返回空字符串
	 */
	UFUNCTION(BlueprintCallable)
	FString GetLastErrorMessage() const;

	/**
	 * 清除错误信息
	 */
	UFUNCTION(BlueprintCallable)
	void ClearErrorMessage();

#pragma endregion Error Handling

private:
	// 已添加的UI Widget追踪
	UPROPERTY()
	TArray<TObjectPtr<UUserWidget>> ActiveUIWidgets;

	// 最后一次操作的错误信息
	FString LastErrorMessage;

	// 内部辅助方法
	bool AddUIToViewport(UUserWidget* Widget);
	bool RemoveUIFromViewport(UUserWidget* Widget);
	void SetLastError(const FString& ErrorMessage);
}; 