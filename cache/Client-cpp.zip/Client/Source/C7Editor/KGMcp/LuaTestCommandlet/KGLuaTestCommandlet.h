// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Engine/Engine.h"
#include "Misc/AutomationTest.h"
#include "Commandlets/Commandlet.h"
#include "LuaObject.h"
#include "SluaUtil.h"

// KG Lua Test GameInstance support
#include "KGLuaTestGameInstance.h"

#include "KGLuaTestCommandlet.generated.h"

// Forward declarations
namespace slua
{
	class LuaState;
}
class UKGLuaTestCommandlet;
class UKGLuaTestGameInstance;

// === 新增：Describe范围结构体 ===
struct FDescribeScope
{

	// Describe的名称
	FString Name;

	// 这个Describe范围的BeforeEach函数引用
	int32 BeforeEachFunctionRef;

	// 这个Describe范围的AfterEach函数引用
	int32 AfterEachFunctionRef;

	// === 新增：生命周期标记，控制BeforeEach/AfterEach执行顺序 ===
	// 当前测试用例是否已开始生命周期（BeforeEach已执行）
	bool bLifecycleStarted;

	// 子Describe范围
	TArray<TSharedPtr<FDescribeScope>> ChildScopes;

	// 父Describe范围（弱引用避免循环引用）
	TWeakPtr<FDescribeScope> ParentScope;

	FDescribeScope()
		: Name(TEXT(""))
		, BeforeEachFunctionRef(LUA_NOREF)
		, AfterEachFunctionRef(LUA_NOREF)
		, bLifecycleStarted(false)
	{
	}

	FDescribeScope(const FString& InName)
		: Name(InName)
		, BeforeEachFunctionRef(LUA_NOREF)
		, AfterEachFunctionRef(LUA_NOREF)
		, bLifecycleStarted(false)
	{
	}
};

// 测试执行类型枚举
UENUM(BlueprintType)
enum class ELuaTestExecutionType : uint8
{
	Sync		UMETA(DisplayName = "Synchronous"),
	Async		UMETA(DisplayName = "Asynchronous")
};

// Lua测试定义结构体
USTRUCT(BlueprintType)
struct FLuaTestDefinition
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly)
	FString TestName;

	UPROPERTY(BlueprintReadOnly)
	FString Description;

	UPROPERTY(BlueprintReadOnly)
	ELuaTestExecutionType ExecutionType;

	UPROPERTY(BlueprintReadOnly)
	float TimeoutSeconds;

	// Lua函数引用（保持函数存活）
	int32 LuaFunctionRef;

	// 是否启用错误时跳过
	bool bSkipIfErrored;

	// === 新增：测试用例所属的完整Describe路径 ===
	TArray<TSharedPtr<FDescribeScope>> ScopeChain;

	// === 新增：测试用例执行结果跟踪 ===
	mutable bool bTestExecuted;
	mutable bool bTestSucceeded;
	mutable TArray<FAutomationExecutionEntry> ExecutionEntries;

	FLuaTestDefinition()
		: TestName(TEXT(""))
		, Description(TEXT(""))
		, ExecutionType(ELuaTestExecutionType::Sync)
		, TimeoutSeconds(30.0f)
		, LuaFunctionRef(LUA_NOREF)
		, bSkipIfErrored(true)
		, bTestExecuted(false)
		, bTestSucceeded(false)
	{
	}
};

// Lua延迟测试命令类 - 增强版本
class FLuaLatentCommand : public IAutomationLatentCommand
{
public:
	enum class ELatentState : uint8
	{
		NotStarted,
		ExecutingBeforeEach,
		Running,
		Completed,
		Failed,
		Timeout,
		Cancelled
	};

	FLuaLatentCommand(
		lua_State* InLuaState,
		int32 InFunctionRef,
		FTimespan InTimeout,
		class FKGLuaAutomationTest* InTestContext,
		const FLuaTestDefinition& InTestDefinition
	);

	virtual ~FLuaLatentCommand();
	virtual bool Update() override;

	// 新增：状态查询和控制方法
	ELatentState GetCurrentState() const { return CurrentState; }
	bool IsCompleted() const { return CurrentState == ELatentState::Completed; }
	bool HasFailed() const { return CurrentState == ELatentState::Failed; }
	FString GetErrorDetails() const { return ErrorMessage; }
	void Cancel() { CurrentState = ELatentState::Cancelled; }

private:
	int32 FunctionRef;
	FTimespan Timeout;
	class FKGLuaAutomationTest* TestContext;
	
	// === 新增：测试定义引用，用于正确执行BeforeEach/AfterEach ===
	const FLuaTestDefinition& TestDefinition;
	
	// 增强的状态管理
	lua_State* LuaStatePtr;
	ELatentState CurrentState;
	FString ErrorMessage;
	FDateTime StartTime;

	// Done回调函数，用于Lua端标记完成
	static int lua_Done(lua_State* L);
	static int lua_Error(lua_State* L);  // 新增：错误回调
	static FLuaLatentCommand* CurrentLatentCommand;

	// 内部状态管理
	void SetError(const FString& Error);
	void LogStateChange(ELatentState NewState);
};

// === 增强的FKGLuaAutomationTest类 ===
class FKGLuaAutomationTest : public FAutomationTestBase
{
public:
	FKGLuaAutomationTest(
		const FString& InTestName,
		const FString& InLuaScriptPath, lua_State* InLuaState,
		bool bInComplexTask = false
	);

	virtual ~FKGLuaAutomationTest();

	// FAutomationTestBase override
	virtual EAutomationTestFlags GetTestFlags() const override;
	virtual FString GetBeautifiedTestName() const override;
	virtual uint32 GetRequiredDeviceNum() const override;

	// 动态测试用例支持
	virtual void GetTests(TArray<FString>& OutBeautifiedNames, TArray<FString>& OutTestCommands) const override;
	virtual bool RunTest(const FString& Parameters) override;

	bool RunAllTest();
	FString GetTestResults() const;

	// 公共接口，供Lua调用
	void AddTestCase(const FLuaTestDefinition& TestDef);
	bool HasTestCase(const FString& TestName) const;
	const FLuaTestDefinition* FindTestCase(const FString& TestName) const;
	FString GetLuaScriptPath() const { return LuaScriptPath; }

	// 静态实例管理（供Lua API使用）
	static FKGLuaAutomationTest* GetCurrentTestInstance() { return CurrentTestInstance; }

	// === 新增：测试用例统计方法 ===
	int32 GetTotalTestCaseCount() const { return TestCases.Num(); }
	int32 GetExecutedTestCaseCount() const;
	int32 GetSucceededTestCaseCount() const;
	int32 GetFailedTestCaseCount() const;

	// === BeforeEach/AfterEach链式执行（需要被FLuaLatentCommand访问）===
	bool ExecuteBeforeEachChain(const TArray<TSharedPtr<FDescribeScope>>& ScopeChain);
	bool ExecuteAfterEachChain(const TArray<TSharedPtr<FDescribeScope>>& ScopeChain);

protected:
	// 测试相关成员
	FString LuaScriptPath;
	lua_State* LuaStatePtr;
	TArray<FLuaTestDefinition> TestCases;

	// === 新增：Describe层次管理 ===
	// 根Describe范围
	TSharedPtr<FDescribeScope> RootDescribeScope;
	// 当前Describe范围栈（用于管理嵌套）
	TArray<TSharedPtr<FDescribeScope>> CurrentScopeStack;

	// 静态实例指针（用于Lua回调）
	static FKGLuaAutomationTest* CurrentTestInstance;

	// 初始化和清理
	bool InitializeTestEnvironment();
	void CleanupTestEnvironment();

	// === 新增：Describe范围清理 ===
	void CleanupDescribeScope(TSharedPtr<FDescribeScope> Scope);

	// Lua脚本解析
	bool ParseLuaTestDefinitions();
	void RegisterLuaTestAPI(lua_State* L);

	// 测试执行
	void ExecuteSyncTest(const FLuaTestDefinition& TestDef);
	void ExecuteAsyncTest(const FLuaTestDefinition& TestDef);

	// === 内部BeforeEach/AfterEach执行方法 ===
	bool ExecuteSingleBeforeEach(int32 FunctionRef);
	bool ExecuteSingleAfterEach(int32 FunctionRef);

	// BeforeEach和AfterEach执行（需要被FLuaLatentCommand访问）
	bool ExecuteBeforeEach();
	bool ExecuteAfterEach();

	// === Lua API 实现 ===
	
	// TestSuite API - 用于注册测试用例
	static int lua_AddTest(lua_State* L);
	static int lua_AddAsyncTest(lua_State* L);
	
	// 新增：BDD风格测试API（FAutomationSpecBase风格）
	static int lua_Describe(lua_State* L);
	static int lua_It(lua_State* L);
	static int lua_AsyncIt(lua_State* L);
	static int lua_BeforeEach(lua_State* L);
	static int lua_AfterEach(lua_State* L);

	// 继承原有的TestContext API（增强的FAutomationTestBase功能）
	static int lua_TestTrue(lua_State* L);
	static int lua_TestFalse(lua_State* L);
	static int lua_TestEqual(lua_State* L);
	static int lua_TestNotEqual(lua_State* L);
	static int lua_TestNearlyEqual(lua_State* L);
	static int lua_TestNull(lua_State* L);
	static int lua_TestNotNull(lua_State* L);
	static int lua_AddInfo(lua_State* L);
	static int lua_AddWarning(lua_State* L);
	static int lua_AddError(lua_State* L);
	static int lua_GetTestName(lua_State* L);
	static int lua_HasAnyErrors(lua_State* L);
};

/**
 * KG Lua测试命令行工具
 * 专门用于执行多个Lua单元测试，集成slua_unreal插件和FAutomationTestBase
 * 
 * 使用方法: -Run=KGLuaTest [参数]
 * 参数:
 *   -LogLevel=<级别>    指定日志级别 (例如: normal, verbose, minimal)
 *   -OutputPath=<路径>  指定输出路径
 *   -LuaScript=<脚本>   指定要执行的lua测试脚本路径（可多个，用分号分隔）
 *   -JsonOutput         启用JSON格式输出
 */
UCLASS()
class UKGLuaTestCommandlet : public UCommandlet
{
	GENERATED_BODY()

public:
	UKGLuaTestCommandlet(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	//~ Begin UCommandlet Interface
	virtual int32 Main(const FString& Params) override;
	//~ End UCommandlet Interface

	// 获取当前实例
	static UKGLuaTestCommandlet* GetCurrentInstance() { return CurrentInstance; }

private:
	// 命令行参数
	FString LogLevel;
	FString OutputPath;
	TArray<FString> LuaScriptPaths;
	bool bVerboseOutput;
	bool bJsonOutput;

	// Lua状态管理
	lua_State* LuaStatePtr;
    UEditorLuaEnv *LuaEnv;

	// GameInstance管理 - 用于支持UI测试
	UPROPERTY()
	TObjectPtr<UKGLuaTestGameInstance> TestGameInstance;

	// 测试实例管理
	TArray<FKGLuaAutomationTest*> TestInstances;

	// 静态实例指针
	static UKGLuaTestCommandlet* CurrentInstance;

	// 方法实现
	bool ParseParams(const FString& Params);
	bool RunAllLuaTests();
	FKGLuaAutomationTest* RunSingleLuaTest(const FString& LuaScriptPath);
	bool InitializeLuaState();
	void CleanupLuaState();

	// GameInstance管理
	UKGLuaTestGameInstance* GetTestGameInstance() const { return TestGameInstance; }

	// 报告生成
	void OutputTestReport(const TArray<FKGLuaAutomationTest*>& TestResults);
	TSharedPtr<FJsonObject> GenerateJsonReport(const TArray<FKGLuaAutomationTest*>& TestResults);
	FString GenerateTextReport(const TArray<FKGLuaAutomationTest*>& TestResults);

	// 全局Lua API注册
	void RegisterLuaTestAPI(lua_State* L);

	// Lua API函数声明
	static int lua_GetTestGameInstance(lua_State* L);
}; 