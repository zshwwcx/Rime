// Copyright Epic Games, Inc. All Rights Reserved.

#include "KGLuaTestCommandlet.h"
#include "KGLuaTestGameInstance.h"
#include "Engine/Engine.h"
#include "HAL/FileManager.h"
#include "Misc/FileHelper.h"
#include "Misc/DateTime.h"
#include "Engine/World.h"
#include "GameFramework/Actor.h"
#include "LuaObject.h"
#include "SluaUtil.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonWriter.h"
#include "LuaState.h"
#include "lua.hpp"

#include UE_INLINE_GENERATED_CPP_BY_NAME(KGLuaTestCommandlet)

// 定义专用的日志分类
DEFINE_LOG_CATEGORY_STATIC(LogKGLuaTest, Log, All);

// === FLuaLatentCommand 实现 ===

FLuaLatentCommand* FLuaLatentCommand::CurrentLatentCommand = nullptr;

FLuaLatentCommand::FLuaLatentCommand(lua_State* InLuaState,
                                     int32 InFunctionRef,
                                     FTimespan InTimeout,
                                     class FKGLuaAutomationTest* InTestContext,
                                     const FLuaTestDefinition& InTestDefinition
)
	: FunctionRef(InFunctionRef)
	, Timeout(InTimeout)
	, TestContext(InTestContext)
	, TestDefinition(InTestDefinition)
	, LuaStatePtr(InLuaState)
	, CurrentState(ELatentState::NotStarted)
	, ErrorMessage(TEXT(""))
{
}

FLuaLatentCommand::~FLuaLatentCommand()
{
	if (LuaStatePtr && FunctionRef != LUA_NOREF)
	{
		luaL_unref(LuaStatePtr, LUA_REGISTRYINDEX, FunctionRef);
	}
}

bool FLuaLatentCommand::Update()
{
	if (CurrentState == ELatentState::NotStarted)
	{
		// === 使用TestDefinition的ScopeChain执行BeforeEach ===
		if (TestContext && !TestContext->ExecuteBeforeEachChain(TestDefinition.ScopeChain))
		{
			SetError(TEXT("BeforeEach链执行失败，跳过延迟测试"));
			LogStateChange(ELatentState::Failed);
			// 执行AfterEach清理
			if (TestContext)
			{
				TestContext->ExecuteAfterEachChain(TestDefinition.ScopeChain);
			}
			return true; // 任务完成（失败）
		}

		LogStateChange(ELatentState::Running);
		StartTime = FDateTime::Now();
		CurrentLatentCommand = this;

		if (LuaStatePtr && FunctionRef != LUA_NOREF)
		{
			// 在真正开始执行该异步/延迟用例之前，清空上一轮收集到的执行信息，避免跨用例串扰
			TestContext->ClearExecutionInfo();

			lua_State* L = LuaStatePtr;
			
			// 获取Lua函数
			lua_rawgeti(L, LUA_REGISTRYINDEX, FunctionRef);
			
			// 传入Done和Error回调函数
			lua_pushcfunction(L, lua_Done);
			lua_pushcfunction(L, lua_Error);
			TestContext->AddInfo(FString::Printf(TEXT("执行Async测试用例函数: %d"), FunctionRef));
			// 调用Lua函数
			if (lua_pcall(L, 2, 0, 0) != LUA_OK)
			{
				const char* error = lua_tostring(L, -1);
				SetError(FString::Printf(TEXT("Lua延迟测试执行错误: %s"), UTF8_TO_TCHAR(error)));
				lua_pop(L, 1);
				LogStateChange(ELatentState::Failed);
			}

			TestDefinition.bTestSucceeded = !TestContext->HasAnyErrors();
			FAutomationTestExecutionInfo tmp;
			TestContext->GetExecutionInfo(tmp);
			TestDefinition.ExecutionEntries = tmp.GetEntries();
		}
		else
		{
			SetError(TEXT("无效的Lua状态或函数引用"));
			LogStateChange(ELatentState::Failed);
		}
	}

	// 检查是否被取消
	if (CurrentState == ELatentState::Cancelled)
	{
		// 执行AfterEach清理
		if (TestContext)
		{
			TestContext->ExecuteAfterEachChain(TestDefinition.ScopeChain);
		}
		CurrentLatentCommand = nullptr;
		return true;
	}

	// 检查超时
	if (CurrentState == ELatentState::Running && (FDateTime::Now() - StartTime) > Timeout)
	{
		SetError(FString::Printf(TEXT("延迟测试超时 (%.2f秒)"), Timeout.GetTotalSeconds()));
		LogStateChange(ELatentState::Timeout);
		// 执行AfterEach清理
		if (TestContext)
		{
			TestContext->ExecuteAfterEachChain(TestDefinition.ScopeChain);
		}
		CurrentLatentCommand = nullptr;
		return true;
	}

	// 检查完成状态
	if (CurrentState == ELatentState::Completed || CurrentState == ELatentState::Failed)
	{
		// === 新增：记录延迟测试用例的执行结果 ===
		if (TestContext)
		{
			// 找到对应的测试用例并更新结果
			FLuaTestDefinition* MutableTestDef = const_cast<FLuaTestDefinition*>(&TestDefinition);
			if (MutableTestDef)
			{
				MutableTestDef->bTestExecuted = true;

				// 成功条件: 状态为Completed 且 当前测试上下文没有记录任何错误
				const bool bHadErrors = TestContext ? TestContext->HasAnyErrors() : true;
				const bool bSucceeded   = (CurrentState == ELatentState::Completed) && !bHadErrors;

				MutableTestDef->bTestSucceeded = bSucceeded;

				if (bSucceeded)
				{
					TestContext->AddInfo(FString::Printf(TEXT("✓ 延迟测试用例执行成功: %s"), *TestDefinition.Description));
				}
			}
			
			// 执行AfterEach清理
			TestContext->ExecuteAfterEachChain(TestDefinition.ScopeChain);
		}
		CurrentLatentCommand = nullptr;
		return true;
	}

	return false;
}

int FLuaLatentCommand::lua_Done(lua_State* L)
{
	if (CurrentLatentCommand)
	{
		CurrentLatentCommand->LogStateChange(ELatentState::Completed);
	}
	return 0;
}

int FLuaLatentCommand::lua_Error(lua_State* L)
{
	if (CurrentLatentCommand)
	{
		const char* errorMsg = lua_tostring(L, 1);
		FString ErrorText = errorMsg ? UTF8_TO_TCHAR(errorMsg) : TEXT("未知错误");
		CurrentLatentCommand->SetError(ErrorText);
		CurrentLatentCommand->LogStateChange(ELatentState::Failed);
	}
	return 0;
}

void FLuaLatentCommand::SetError(const FString& Error)
{
	ErrorMessage = Error;
	if (TestContext)
	{
		TestContext->AddError(Error);
	}
}

void FLuaLatentCommand::LogStateChange(ELatentState NewState)
{
	ELatentState OldState = CurrentState;
	CurrentState = NewState;
	
	if (TestContext)
	{
		FString StateChangeMsg = FString::Printf(TEXT("延迟测试状态变更: %d -> %d"), 
			(int32)OldState, (int32)NewState);
		TestContext->AddInfo(StateChangeMsg);
	}
}

// === FKGLuaAutomationTest 实现 ===

// 静态变量定义
FKGLuaAutomationTest* FKGLuaAutomationTest::CurrentTestInstance = nullptr;

FKGLuaAutomationTest::FKGLuaAutomationTest(
	const FString& InTestName,
	const FString& InLuaScriptPath, lua_State* InLuaState,
	bool bInComplexTask
)
	: FAutomationTestBase(InTestName, bInComplexTask)
	, LuaScriptPath(InLuaScriptPath)
	, LuaStatePtr(InLuaState)
{
	// === 新增：初始化Describe层次结构 ===
	RootDescribeScope.Reset();
	CurrentScopeStack.Empty();

	// 在构造函数中解析Lua脚本，收集测试定义
	if (!ParseLuaTestDefinitions())
	{
		UE_LOG(LogKGLuaTest, Warning, TEXT("解析Lua测试定义失败: %s"), *LuaScriptPath);
	}
}

FKGLuaAutomationTest::~FKGLuaAutomationTest()
{
	CleanupTestEnvironment();
	
	// 清理Lua函数引用
	if (LuaStatePtr)
	{
		lua_State* L = LuaStatePtr;
		
		// 清理测试用例函数引用
		for (const auto& TestDef : TestCases)
		{
			if (TestDef.LuaFunctionRef != LUA_NOREF)
			{
				luaL_unref(L, LUA_REGISTRYINDEX, TestDef.LuaFunctionRef);
			}
		}

		// === 新增：清理Describe树中的所有函数引用 ===
		if (RootDescribeScope.IsValid())
		{
			CleanupDescribeScope(RootDescribeScope);
		}
	}
}

EAutomationTestFlags FKGLuaAutomationTest::GetTestFlags() const
{
	return EAutomationTestFlags::EditorContext | EAutomationTestFlags::CommandletContext | EAutomationTestFlags::EngineFilter | EAutomationTestFlags::ClientContext;
}

FString FKGLuaAutomationTest::GetBeautifiedTestName() const
{
	FString FileName = FPaths::GetBaseFilename(LuaScriptPath);
	return FString::Printf(TEXT("KG.Lua.%s"), *FileName);
}

uint32 FKGLuaAutomationTest::GetRequiredDeviceNum() const
{
	return 1;
}

void FKGLuaAutomationTest::GetTests(TArray<FString>& OutBeautifiedNames, TArray<FString>& OutTestCommands) const
{
	for (const auto& TestDef : TestCases)
	{
		OutBeautifiedNames.Add(TestDef.Description);
		OutTestCommands.Add(TestDef.TestName);
	}
}

FString FKGLuaAutomationTest::GetTestResults() const
{
	FStringBuilderBase Builder;
	for (const auto& TestCase : TestCases)
	{
		Builder << TEXT("START case: ") << TestCase.TestName << TEXT("---") << TestCase.Description << TEXT("\n");
		for (const FAutomationExecutionEntry& Entry : TestCase.ExecutionEntries)
		{
			Builder << Entry.Event.Message << TEXT("\n");
		}
		Builder << TEXT(" end case with (") << TestCase.bTestExecuted << TEXT(" | ") << TestCase.bTestSucceeded << TEXT(")\n");
	}

	return Builder.ToString();
}

bool FKGLuaAutomationTest::RunAllTest()
{
	bool result = true;

	for (const auto& TestDef : TestCases)
	{
		if (!RunTest(TestDef.TestName))
		{
			result = false;
		}
	}
	return result;
}

bool FKGLuaAutomationTest::RunTest(const FString& Parameters)
{
	FLuaTestDefinition* TestCase = const_cast<FLuaTestDefinition*>(FindTestCase(Parameters));
	if (!TestCase)
	{
		AddError(FString::Printf(TEXT("测试用例未找到: %s"), *Parameters));
		return false;
	}

	// === 新增：标记测试用例开始执行 ===
	TestCase->bTestExecuted = true;
	TestCase->bTestSucceeded = false; // 默认为失败，成功时再设置

	AddInfo(FString::Printf(TEXT("开始执行测试: %s"), *TestCase->Description));

	// 设置当前测试实例
	CurrentTestInstance = this;

	// 初始化测试环境
	if (!InitializeTestEnvironment())
	{
		AddError(TEXT("测试环境初始化失败"));
		return false;
	}

	// 根据执行类型选择相应的执行方式
	switch (TestCase->ExecutionType)
	{
	case ELuaTestExecutionType::Sync:
		ExecuteSyncTest(*TestCase);
		break;
	case ELuaTestExecutionType::Async:
		ExecuteAsyncTest(*TestCase);
		break;
	default:
		AddError(TEXT("未支持的测试执行类型"));
		break;
	}

	// 清理当前实例
	CurrentTestInstance = nullptr;
	return true;
}

void FKGLuaAutomationTest::AddTestCase(const FLuaTestDefinition& TestDef)
{
	AddInfo(FString::Printf(TEXT("注册: %s"), *TestDef.Description));
	TestCases.Add(TestDef);
}

bool FKGLuaAutomationTest::HasTestCase(const FString& InTestName) const
{
	return FindTestCase(InTestName) != nullptr;
}

const FLuaTestDefinition* FKGLuaAutomationTest::FindTestCase(const FString& InTestName) const
{
	for (const auto& TestDef : TestCases)
	{
		if (TestDef.TestName == InTestName)
		{
			return &TestDef;
		}
	}
	return nullptr;
}

// === 新增：测试用例统计方法实现 ===
int32 FKGLuaAutomationTest::GetExecutedTestCaseCount() const
{
	int32 Count = 0;
	for (const auto& TestDef : TestCases)
	{
		if (TestDef.bTestExecuted)
		{
			Count++;
		}
	}
	return Count;
}

int32 FKGLuaAutomationTest::GetSucceededTestCaseCount() const
{
	int32 Count = 0;
	for (const auto& TestDef : TestCases)
	{
		if (TestDef.bTestExecuted && TestDef.bTestSucceeded)
		{
			Count++;
		}
	}
	return Count;
}

int32 FKGLuaAutomationTest::GetFailedTestCaseCount() const
{
	int32 Count = 0;
	for (const auto& TestDef : TestCases)
	{
		if (TestDef.bTestExecuted && !TestDef.bTestSucceeded)
		{
			Count++;
		}
	}
	return Count;
}

bool FKGLuaAutomationTest::InitializeTestEnvironment()
{
	// 注册测试Context API
	if (LuaStatePtr)
	{
		RegisterLuaTestAPI(LuaStatePtr);
	}

	// 初始化AutomationDriver（如果需要UI测试）
	//return InitializeAutomationDriver();
	return true;
}

void FKGLuaAutomationTest::CleanupTestEnvironment()
{
}

// === 新增：递归清理Describe范围 ===
void FKGLuaAutomationTest::CleanupDescribeScope(TSharedPtr<FDescribeScope> Scope)
{
	if (!Scope.IsValid() || !LuaStatePtr)
	{
		return;
	}
		
	lua_State* L = LuaStatePtr;
	
	// 清理BeforeEach/AfterEach函数引用
	if (Scope->BeforeEachFunctionRef != LUA_NOREF)
	{
		luaL_unref(L, LUA_REGISTRYINDEX, Scope->BeforeEachFunctionRef);
		Scope->BeforeEachFunctionRef = LUA_NOREF;
	}
	
	if (Scope->AfterEachFunctionRef != LUA_NOREF)
	{
		luaL_unref(L, LUA_REGISTRYINDEX, Scope->AfterEachFunctionRef);
		Scope->AfterEachFunctionRef = LUA_NOREF;
	}
	
	// 递归清理子Scope
	for (auto& ChildScope : Scope->ChildScopes)
	{
		CleanupDescribeScope(ChildScope);
	}
	
	Scope->ChildScopes.Empty();
}

// === 新增：BeforeEach/AfterEach链式执行方法 ===
bool FKGLuaAutomationTest::ExecuteBeforeEachChain(const TArray<TSharedPtr<FDescribeScope>>& ScopeChain)
{
	// 从外到内执行BeforeEach
	for (const auto& Scope : ScopeChain)
	{
		if (Scope.IsValid() && Scope->BeforeEachFunctionRef != LUA_NOREF)
		{
			// === 新增：只有当生命周期未开始时才能执行BeforeEach ===
			if (Scope->bLifecycleStarted)
			{
				AddInfo(FString::Printf(TEXT("跳过已开始生命周期的BeforeEach在Describe: %s"), *Scope->Name));
				continue;
			}
			
			if (!ExecuteSingleBeforeEach(Scope->BeforeEachFunctionRef))
			{
				AddError(FString::Printf(TEXT("BeforeEach执行失败在Describe: %s"), *Scope->Name));
				return false;
			}
			
			// === 新增：标记生命周期已开始 ===
			Scope->bLifecycleStarted = true;
		}
	}
	return true;
}

bool FKGLuaAutomationTest::ExecuteAfterEachChain(const TArray<TSharedPtr<FDescribeScope>>& ScopeChain)
{
	// 从内到外执行AfterEach
	for (int32 i = ScopeChain.Num() - 1; i >= 0; i--)
	{
		const auto& Scope = ScopeChain[i];
		if (Scope.IsValid() && Scope->AfterEachFunctionRef != LUA_NOREF)
		{
			// === 新增：只有当生命周期已开始时才能执行AfterEach ===
			if (!Scope->bLifecycleStarted)
			{
				AddInfo(FString::Printf(TEXT("跳过未开始生命周期的AfterEach在Describe: %s"), *Scope->Name));
				continue;
			}
			
			ExecuteSingleAfterEach(Scope->AfterEachFunctionRef); // 即使失败也继续
			
			// === 新增：AfterEach执行后重置生命周期标记，为下一个测试做准备 ===
			Scope->bLifecycleStarted = false;
		}
	}
	return true;
}

bool FKGLuaAutomationTest::ExecuteSingleBeforeEach(int32 FunctionRef)
{
	if (!LuaStatePtr || FunctionRef == LUA_NOREF)
	{
		return true; // 没有BeforeEach函数，直接返回成功
	}

	lua_State* L = LuaStatePtr;
	
	// 获取并调用BeforeEach函数
	lua_rawgeti(L, LUA_REGISTRYINDEX, FunctionRef);
	
	if (lua_pcall(L, 0, 0, 0) != LUA_OK)
	{
		const char* error = lua_tostring(L, -1);
		AddError(FString::Printf(TEXT("BeforeEach执行错误: %s"), UTF8_TO_TCHAR(error)));
		lua_pop(L, 1);
		return false;
	}
	
	return true;
}

bool FKGLuaAutomationTest::ExecuteSingleAfterEach(int32 FunctionRef)
{
	if (!LuaStatePtr || FunctionRef == LUA_NOREF)
	{
		return true; // 没有AfterEach函数，直接返回成功
	}

	lua_State* L = LuaStatePtr;
	
	// 获取并调用AfterEach函数
	lua_rawgeti(L, LUA_REGISTRYINDEX, FunctionRef);
	
	if (lua_pcall(L, 0, 0, 0) != LUA_OK)
	{
		const char* error = lua_tostring(L, -1);
		AddWarning(FString::Printf(TEXT("AfterEach执行警告: %s"), UTF8_TO_TCHAR(error)));
		lua_pop(L, 1);
		return false;
	}
	
	return true;
}

bool FKGLuaAutomationTest::ParseLuaTestDefinitions()
{
	if (!LuaStatePtr)
	{
		UE_LOG(LogKGLuaTest, Error, TEXT("Lua状态无效"));
		return false;
	}

	// 设置当前测试实例
	CurrentTestInstance = this;

	// 注册TestSuite API
	RegisterLuaTestAPI(LuaStatePtr);

	// 处理默认测试或文件测试
	if (LuaScriptPath == TEXT("DefaultLuaTest"))
	{
		// 添加默认测试用例
		FLuaTestDefinition DefaultTest;
		DefaultTest.TestName = TEXT("DefaultTest");
		DefaultTest.Description = TEXT("默认Lua测试");
		DefaultTest.ExecutionType = ELuaTestExecutionType::Sync;
		DefaultTest.LuaFunctionRef = LUA_NOREF; // 特殊标记，表示使用内置默认测试
		TestCases.Add(DefaultTest);
		return true;
	}

	// 执行Lua脚本文件
	FString FullPath = FPaths::Combine(FPaths::ProjectDir(), LuaScriptPath);
	if (FPaths::FileExists(FullPath))
	{
		FString LuaCode;
		if (FFileHelper::LoadFileToString(LuaCode, *FullPath))
		{
			slua::LuaState* stateWrapper = slua::LuaState::get(LuaStatePtr);
			if (stateWrapper != nullptr)
			{
				stateWrapper->doString(TCHAR_TO_UTF8(*LuaCode));
				UE_LOG(LogKGLuaTest, Log, TEXT("成功解析Lua测试定义: %s，共%d个测试用例"), *LuaScriptPath, TestCases.Num());
				return true;
			}
			else
			{
				UE_LOG(LogKGLuaTest, Error, TEXT("stateWrapper == nullptr,执行测试失败: %s"), *FullPath);
			}
		}
		else
		{
			UE_LOG(LogKGLuaTest, Error, TEXT("读取Lua文件失败: %s"), *FullPath);
		}
	}
	else
	{
		UE_LOG(LogKGLuaTest, Error, TEXT("Lua文件不存在: %s"), *FullPath);
	}

	return false;
}

// 测试执行方法实现
void FKGLuaAutomationTest::ExecuteSyncTest(const FLuaTestDefinition& TestDef)
{
	// === 执行BeforeEach链 ===
	if (!ExecuteBeforeEachChain(TestDef.ScopeChain))
	{
		AddError(TEXT("BeforeEach链执行失败，跳过测试"));
		ExecuteAfterEachChain(TestDef.ScopeChain); // 即使BeforeEach失败也尝试执行AfterEach
		return;
	}

	
	if (LuaStatePtr != nullptr && TestDef.LuaFunctionRef != LUA_NOREF)
	{
		// 在每个测试用例开始前清空历史执行信息，确保错误统计仅针对当前用例
		ClearExecutionInfo();

		lua_State* L = LuaStatePtr;
		
		// 获取并调用Lua函数
		lua_rawgeti(L, LUA_REGISTRYINDEX, TestDef.LuaFunctionRef);
		AddInfo(FString::Printf(TEXT("执行测试用例函数: %d"), TestDef.LuaFunctionRef));
		if (lua_pcall(L, 0, 0, 0) != LUA_OK)
		{
			const char* error = lua_tostring(L, -1);
			AddError(FString::Printf(TEXT("Lua同步测试执行错误: %s"), UTF8_TO_TCHAR(error)));
			lua_pop(L, 1);
		}

		TestDef.bTestSucceeded = !HasAnyErrors();
		TestDef.ExecutionEntries = ExecutionInfo.GetEntries();
	}

	// === 修改：执行AfterEach链 ===
	ExecuteAfterEachChain(TestDef.ScopeChain);
}

void FKGLuaAutomationTest::ExecuteAsyncTest(const FLuaTestDefinition& TestDef)
{
	if (!LuaStatePtr || TestDef.LuaFunctionRef == LUA_NOREF)
	{
		return;
	}

	// === 修改：创建延迟命令时传递TestDefinition，确保BeforeEach/AfterEach只执行一次 ===
	FTimespan Timeout = FTimespan::FromSeconds(TestDef.TimeoutSeconds);
	ADD_LATENT_AUTOMATION_COMMAND(FLuaLatentCommand(LuaStatePtr, TestDef.LuaFunctionRef, Timeout, this, TestDef));
}

void FKGLuaAutomationTest::RegisterLuaTestAPI(lua_State* L)
{
	// 检查TestSuite是否已经注册，避免重复注册
	lua_getglobal(L, "TestSuite");
	if (lua_isnil(L, -1))
	{
		lua_pop(L, 1); // 移除nil值
		
		// 创建TestSuite表
		lua_newtable(L);
		
		// 注册基础TestSuite API
		lua_pushcfunction(L, lua_AddTest);
		lua_setfield(L, -2, "AddTest");
		
		lua_pushcfunction(L, lua_AddAsyncTest);
		lua_setfield(L, -2, "AddAsyncTest");
		
		// 注册BDD风格API
		lua_pushcfunction(L, lua_Describe);
		lua_setfield(L, -2, "Describe");
		
		lua_pushcfunction(L, lua_It);
		lua_setfield(L, -2, "It");
		
		lua_pushcfunction(L, lua_AsyncIt);
		lua_setfield(L, -2, "AsyncIt");
		
		lua_pushcfunction(L, lua_BeforeEach);
		lua_setfield(L, -2, "BeforeEach");
		
		lua_pushcfunction(L, lua_AfterEach);
		lua_setfield(L, -2, "AfterEach");
		
		// 设置TestSuite为全局变量
		lua_setglobal(L, "TestSuite");
		
		UE_LOG(LogKGLuaTest, Log, TEXT("TestSuite API 已注册"));
	}
	
	// 检查TestContext是否已经注册
	lua_getglobal(L, "TestContext");
	if (lua_isnil(L, -1))
	{
		lua_pop(L, 1); // 移除nil值
		
		// 创建TestContext表
		lua_newtable(L);
		
		// 注册TestContext API
		lua_pushcfunction(L, lua_TestTrue);
		lua_setfield(L, -2, "TestTrue");
		
		lua_pushcfunction(L, lua_TestFalse);
		lua_setfield(L, -2, "TestFalse");
		
		lua_pushcfunction(L, lua_TestEqual);
		lua_setfield(L, -2, "TestEqual");
		
		lua_pushcfunction(L, lua_TestNotEqual);
		lua_setfield(L, -2, "TestNotEqual");
		
		lua_pushcfunction(L, lua_TestNearlyEqual);
		lua_setfield(L, -2, "TestNearlyEqual");
		
		lua_pushcfunction(L, lua_TestNull);
		lua_setfield(L, -2, "TestNull");
		
		lua_pushcfunction(L, lua_TestNotNull);
		lua_setfield(L, -2, "TestNotNull");
		
		lua_pushcfunction(L, lua_AddInfo);
		lua_setfield(L, -2, "AddInfo");
		
		lua_pushcfunction(L, lua_AddWarning);
		lua_setfield(L, -2, "AddWarning");
		
		lua_pushcfunction(L, lua_AddError);
		lua_setfield(L, -2, "AddError");
		
		lua_pushcfunction(L, lua_GetTestName);
		lua_setfield(L, -2, "GetTestName");
		
		lua_pushcfunction(L, lua_HasAnyErrors);
		lua_setfield(L, -2, "HasAnyErrors");
		
		// 设置TestContext为全局变量
		lua_setglobal(L, "TestContext");
		
		UE_LOG(LogKGLuaTest, Log, TEXT("TestContext API 已注册"));
	}
}

// === TestSuite Lua API 实现 ===
int FKGLuaAutomationTest::lua_AddTest(lua_State* L)
{
	// 参数: testName (string), testFunction (function)
	const char* testName = luaL_checkstring(L, 1);
	luaL_checktype(L, 2, LUA_TFUNCTION);
	
	if (CurrentTestInstance)
	{
		FLuaTestDefinition TestDef;
		TestDef.TestName = UTF8_TO_TCHAR(testName);
		TestDef.Description = TestDef.TestName; // 默认使用测试名作为描述
		TestDef.ExecutionType = ELuaTestExecutionType::Sync;
		TestDef.TimeoutSeconds = 30.0f;
		TestDef.bSkipIfErrored = true;
		
		// 保存Lua函数引用
		lua_pushvalue(L, 2); // 复制函数到栈顶
		TestDef.LuaFunctionRef = luaL_ref(L, LUA_REGISTRYINDEX);
		
		CurrentTestInstance->AddTestCase(TestDef);
		
		UE_LOG(LogKGLuaTest, Log, TEXT("注册同步测试: %s"), *TestDef.TestName);
	}
	
	return 0;
}

int FKGLuaAutomationTest::lua_AddAsyncTest(lua_State* L)
{
	// 参数: testName (string), testFunction (function)
	const char* testName = luaL_checkstring(L, 1);
	luaL_checktype(L, 2, LUA_TFUNCTION);
	
	if (CurrentTestInstance)
	{
		FLuaTestDefinition TestDef;
		TestDef.TestName = UTF8_TO_TCHAR(testName);
		TestDef.Description = TestDef.TestName;
		TestDef.ExecutionType = ELuaTestExecutionType::Async;
		TestDef.TimeoutSeconds = 60.0f;
		TestDef.bSkipIfErrored = true;
		
		// 保存Lua函数引用
		lua_pushvalue(L, 2);
		TestDef.LuaFunctionRef = luaL_ref(L, LUA_REGISTRYINDEX);
		
		CurrentTestInstance->AddTestCase(TestDef);
		
		UE_LOG(LogKGLuaTest, Log, TEXT("注册异步测试: %s"), *TestDef.TestName);
	}
	
	return 0;
}

// === 新增：BDD风格测试API实现（FAutomationSpecBase风格）===

int FKGLuaAutomationTest::lua_Describe(lua_State* L)
{
	// 参数: description (string), testFunction (function)
	const char* description = luaL_checkstring(L, 1);
	luaL_checktype(L, 2, LUA_TFUNCTION);
	
	if (CurrentTestInstance)
	{
		// === 新实现：创建新的DescribeScope并管理嵌套栈 ===
		auto NewScope = MakeShared<FDescribeScope>(UTF8_TO_TCHAR(description));
		
		// 添加到父scope或设置为根scope
		if (CurrentTestInstance->CurrentScopeStack.Num() > 0)
		{
			// 有父scope，添加为子scope
			auto ParentScope = CurrentTestInstance->CurrentScopeStack.Last();
			ParentScope->ChildScopes.Add(NewScope);
			NewScope->ParentScope = ParentScope;
		}
		else
		{
			// 没有父scope，设置为根scope
			if (!CurrentTestInstance->RootDescribeScope.IsValid())
			{
				CurrentTestInstance->RootDescribeScope = NewScope;
			}
			else
			{
				// 如果已经有根scope，将新scope添加为根scope的子scope
				CurrentTestInstance->RootDescribeScope->ChildScopes.Add(NewScope);
				NewScope->ParentScope = CurrentTestInstance->RootDescribeScope;
			}
		}
		
		CurrentTestInstance->AddInfo(FString::Printf(TEXT("进入Describe范围: %s"), UTF8_TO_TCHAR(description)));
		
		// 推入scope栈
		CurrentTestInstance->CurrentScopeStack.Add(NewScope);
		
		// 调用Describe函数，收集内部的BeforeEach/AfterEach/It
		if (lua_pcall(L, 0, 0, 0) != LUA_OK)
		{
			const char* error = lua_tostring(L, -1);
			CurrentTestInstance->AddError(FString::Printf(TEXT("Describe执行错误: %s"), UTF8_TO_TCHAR(error)));
			lua_pop(L, 1);
		}
		
		// 弹出scope栈
		CurrentTestInstance->CurrentScopeStack.RemoveAt(CurrentTestInstance->CurrentScopeStack.Num() - 1);
		
		CurrentTestInstance->AddInfo(FString::Printf(TEXT("退出Describe范围: %s"), UTF8_TO_TCHAR(description)));
	}
	
	return 0;
}

int FKGLuaAutomationTest::lua_It(lua_State* L)
{
	// 参数: testName (string), testFunction (function)
	const char* testName = luaL_checkstring(L, 1);
	luaL_checktype(L, 2, LUA_TFUNCTION);
	
	if (CurrentTestInstance)
	{
		FLuaTestDefinition TestDef;
		TestDef.TestName = UTF8_TO_TCHAR(testName);
		TestDef.Description = FString::Printf(TEXT("It: %s"), UTF8_TO_TCHAR(testName));
		TestDef.ExecutionType = ELuaTestExecutionType::Sync;
		TestDef.TimeoutSeconds = 30.0f;
		TestDef.bSkipIfErrored = true;
		
		// === 新增：复制完整的ScopeChain ===
		TestDef.ScopeChain = CurrentTestInstance->CurrentScopeStack;
		
		// 如果没有在Describe中，创建默认根scope
		if (TestDef.ScopeChain.Num() == 0)
		{
			if (!CurrentTestInstance->RootDescribeScope.IsValid())
			{
				CurrentTestInstance->RootDescribeScope = MakeShared<FDescribeScope>(TEXT("默认根Describe"));
			}
			TestDef.ScopeChain.Add(CurrentTestInstance->RootDescribeScope);
		}
		
		// 保存Lua函数引用
		lua_pushvalue(L, 2);
		TestDef.LuaFunctionRef = luaL_ref(L, LUA_REGISTRYINDEX);
		
		CurrentTestInstance->AddTestCase(TestDef);
		
		UE_LOG(LogKGLuaTest, Log, TEXT("注册BDD同步测试: %s (ScopeChain长度: %d)"), *TestDef.TestName, TestDef.ScopeChain.Num());
	}
	
	return 0;
}

int FKGLuaAutomationTest::lua_AsyncIt(lua_State* L)
{
	// 参数: testName (string), testFunction (function), timeout (number, 可选)
	const char* testName = luaL_checkstring(L, 1);
	luaL_checktype(L, 2, LUA_TFUNCTION);
	float timeout = 60.0f;
	if (lua_gettop(L) >= 3)
	{
		timeout = (float)luaL_checknumber(L, 3);
	}
	
	if (CurrentTestInstance)
	{
		FLuaTestDefinition TestDef;
		TestDef.TestName = UTF8_TO_TCHAR(testName);
		TestDef.Description = FString::Printf(TEXT("AsyncIt: %s"), UTF8_TO_TCHAR(testName));
		TestDef.ExecutionType = ELuaTestExecutionType::Async;
		TestDef.TimeoutSeconds = timeout;
		TestDef.bSkipIfErrored = true;
		
		// 保存Lua函数引用
		lua_pushvalue(L, 2);
		TestDef.LuaFunctionRef = luaL_ref(L, LUA_REGISTRYINDEX);
		
		CurrentTestInstance->AddTestCase(TestDef);
		
		UE_LOG(LogKGLuaTest, Log, TEXT("注册BDD延迟测试: %s (%.1fs)"), *TestDef.TestName, timeout);
	}
	
	return 0;
}

int FKGLuaAutomationTest::lua_BeforeEach(lua_State* L)
{
	// 参数: setupFunction (function)
	luaL_checktype(L, 1, LUA_TFUNCTION);
	
	if (CurrentTestInstance)
	{
		// === 新实现：将BeforeEach保存到当前Describe范围 ===
		TSharedPtr<FDescribeScope> CurrentScope;
		
		if (CurrentTestInstance->CurrentScopeStack.Num() > 0)
		{
			CurrentScope = CurrentTestInstance->CurrentScopeStack.Last();
		}
		else
		{
			// 如果没有在Describe中，使用或创建根scope
			if (!CurrentTestInstance->RootDescribeScope.IsValid())
			{
				CurrentTestInstance->RootDescribeScope = MakeShared<FDescribeScope>(TEXT("默认根Describe"));
			}
			CurrentScope = CurrentTestInstance->RootDescribeScope;
		}
		
		if (CurrentScope.IsValid())
		{
			// 清理之前的BeforeEach函数引用
			if (CurrentScope->BeforeEachFunctionRef != LUA_NOREF)
			{
				luaL_unref(L, LUA_REGISTRYINDEX, CurrentScope->BeforeEachFunctionRef);
			}
			
			// 保存新的BeforeEach函数引用
			lua_pushvalue(L, 1);
			CurrentScope->BeforeEachFunctionRef = luaL_ref(L, LUA_REGISTRYINDEX);
			
			CurrentTestInstance->AddInfo(FString::Printf(TEXT("BeforeEach函数已注册到Describe: %s"), *CurrentScope->Name));
			UE_LOG(LogKGLuaTest, Log, TEXT("BeforeEach函数已注册到Describe: %s"), *CurrentScope->Name);
		}
	}
	
	return 0;
}

int FKGLuaAutomationTest::lua_AfterEach(lua_State* L)
{
	// 参数: cleanupFunction (function)
	luaL_checktype(L, 1, LUA_TFUNCTION);
	
	if (CurrentTestInstance)
	{
		// === 新实现：将AfterEach保存到当前Describe范围 ===
		TSharedPtr<FDescribeScope> CurrentScope;
		
		if (CurrentTestInstance->CurrentScopeStack.Num() > 0)
		{
			CurrentScope = CurrentTestInstance->CurrentScopeStack.Last();
		}
		else
		{
			// 如果没有在Describe中，使用或创建根scope
			if (!CurrentTestInstance->RootDescribeScope.IsValid())
			{
				CurrentTestInstance->RootDescribeScope = MakeShared<FDescribeScope>(TEXT("默认根Describe"));
			}
			CurrentScope = CurrentTestInstance->RootDescribeScope;
		}
		
		if (CurrentScope.IsValid())
		{
			// 清理之前的AfterEach函数引用
			if (CurrentScope->AfterEachFunctionRef != LUA_NOREF)
			{
				luaL_unref(L, LUA_REGISTRYINDEX, CurrentScope->AfterEachFunctionRef);
			}
			
			// 保存新的AfterEach函数引用
			lua_pushvalue(L, 1);
			CurrentScope->AfterEachFunctionRef = luaL_ref(L, LUA_REGISTRYINDEX);
			
			CurrentTestInstance->AddInfo(FString::Printf(TEXT("AfterEach函数已注册到Describe: %s"), *CurrentScope->Name));
			UE_LOG(LogKGLuaTest, Log, TEXT("AfterEach函数已注册到Describe: %s"), *CurrentScope->Name);
		}
	}
	
	return 0;
}

// === TestContext API 实现（增强的FAutomationTestBase功能）===
int FKGLuaAutomationTest::lua_TestTrue(lua_State* L)
{
	// 参数: description (string), condition (boolean)
	const char* description = luaL_checkstring(L, 1);
	bool condition = lua_toboolean(L, 2) != 0;
	
	if (CurrentTestInstance)
	{
		CurrentTestInstance->TestTrue(UTF8_TO_TCHAR(description), condition);
	}
	
	return 0;
}

int FKGLuaAutomationTest::lua_TestFalse(lua_State* L)
{
	// 参数: description (string), condition (boolean)
	const char* description = luaL_checkstring(L, 1);
	bool condition = lua_toboolean(L, 2) != 0;
	
	if (CurrentTestInstance)
	{
		CurrentTestInstance->TestFalse(UTF8_TO_TCHAR(description), condition);
	}
	
	return 0;
}

// fg：根据lua stack的值类型来分别处理
// Forward declaration for recursive calls
static bool CompareLuaValues(lua_State* L, int idx1, int idx2, int visited_idx);

static bool CompareTables(lua_State* L, int idx1, int idx2, int visited_idx)
{
	// Ensure indices are absolute to avoid confusion during stack manipulation
	const int abs_idx1 = lua_absindex(L, idx1);
	const int abs_idx2 = lua_absindex(L, idx2);

	// Trivial case: the tables are the same object
	if (lua_topointer(L, abs_idx1) == lua_topointer(L, abs_idx2))
	{
		return true;
	}

	// Cycle detection: check if we are already comparing this table pair
	lua_pushvalue(L, abs_idx1);
	lua_rawget(L, visited_idx);
	if (!lua_isnil(L, -1))
	{
		lua_pop(L, 1);
		return true; // Already in the process of comparing this table, assume equal to break cycle
	}
	lua_pop(L, 1);

	// Mark table as visited
	lua_pushvalue(L, abs_idx1);
	lua_pushboolean(L, true);
	lua_rawset(L, visited_idx);

	// Function to count keys in a table
	auto countKeys = [](lua_State* sL, int idx) -> int
	{
		int count = 0;
		const int abs_idx = lua_absindex(sL, idx);
		lua_pushnil(sL);
		while (lua_next(sL, abs_idx) != 0)
		{
			count++;
			lua_pop(sL, 1); // Pop value, keep key for next iteration
		}
		return count;
	};

	if (countKeys(L, abs_idx1) != countKeys(L, abs_idx2))
	{
		return false;
	}
	
	bool bTablesAreEqual = true;
	lua_pushnil(L); // First key
	while (lua_next(L, abs_idx1) != 0)
	{
		// key is at -2, value is at -1
		lua_pushvalue(L, -2); // Duplicate key
		lua_rawget(L, abs_idx2); // Get value from second table

		// Recursively compare the values
		if (!CompareLuaValues(L, -2, -1, visited_idx))
		{
			bTablesAreEqual = false;
			lua_pop(L, 3); // Pop value from t2, value from t1, and key
			break;
		}
		lua_pop(L, 2); // Pop value from t2 and value from t1
	}

	return bTablesAreEqual;
}

static bool CompareLuaValues(lua_State* L, int idx1, int idx2, int visited_idx)
{
	const int type1 = lua_type(L, idx1);
	const int type2 = lua_type(L, idx2);

	if (type1 != type2)
	{
		return false;
	}

	switch (type1)
	{
	case LUA_TNIL:
		return true;
	case LUA_TSTRING:
		return strcmp(lua_tostring(L, idx1), lua_tostring(L, idx2)) == 0;
	case LUA_TNUMBER:
		return lua_tonumber(L, idx1) == lua_tonumber(L, idx2);
	case LUA_TBOOLEAN:
		return lua_toboolean(L, idx1) == lua_toboolean(L, idx2);
	case LUA_TLIGHTUSERDATA:
		return lua_touserdata(L, idx1) == lua_touserdata(L, idx2);
	case LUA_TTABLE:
		return CompareTables(L, idx1, idx2, visited_idx);
	case LUA_TUSERDATA:
		// Attempt to use the __eq metamethod
		if (luaL_getmetafield(L, idx1, "__eq"))
		{
			lua_pushvalue(L, idx1);
			lua_pushvalue(L, idx2);
			lua_call(L, 2, 1);
			bool bResult = lua_toboolean(L, -1) == 1;
			lua_pop(L, 1);
			return bResult;
		}
		// Fallback to pointer comparison if __eq is not available
		return lua_touserdata(L, idx1) == lua_touserdata(L, idx2);
	default:
		// For other types like functions or threads, equality is ambiguous.
		// Fallback to a raw check which compares pointers for most types.
		return lua_rawequal(L, idx1, idx2) != 0;
	}
}

int FKGLuaAutomationTest::lua_TestEqual(lua_State* L)
{
	// 参数: description (string), actual (any), expected (any)
	const char* description = luaL_checkstring(L, 1);
	
	if (CurrentTestInstance)
	{
		lua_settop(L, 3); // Ensure only description, actual, expected are on stack
		lua_newtable(L);  // Create 'visited' table for cycle detection in table comparisons
		const int visited_idx = lua_gettop(L);

		const bool bAreEqual = CompareLuaValues(L, 2, 3, visited_idx);
		
		if (bAreEqual)
		{
			// PASS: Report success by providing identical string values to the framework.
			FString valueStr = UTF8_TO_TCHAR(luaL_tolstring(L, 2, nullptr));
			CurrentTestInstance->TestEqual(UTF8_TO_TCHAR(description), valueStr, valueStr);
		}
		else
		{
			// FAIL: Report failure by providing the different string values for a rich error message.
			FString actual = UTF8_TO_TCHAR(luaL_tolstring(L, 2, nullptr));
			FString expected = UTF8_TO_TCHAR(luaL_tolstring(L, 3, nullptr));
			CurrentTestInstance->TestEqual(UTF8_TO_TCHAR(description), actual, expected);
		}
	}
	
	return 0;
}

int FKGLuaAutomationTest::lua_TestNotEqual(lua_State* L)
{
	// 参数: description (string), actual (any), expected (any)
	const char* description = luaL_checkstring(L, 1);
	
	if (CurrentTestInstance)
	{
		lua_settop(L, 3);
		lua_newtable(L);
		const int visited_idx = lua_gettop(L);

		const bool bAreEqual = CompareLuaValues(L, 2, 3, visited_idx);

		if (bAreEqual)
		{
			// FAIL: The values are equal, so TestNotEqual must fail.
			// Provide identical values to the framework to guarantee failure.
			FString valueStr = UTF8_TO_TCHAR(luaL_tolstring(L, 2, nullptr));
			CurrentTestInstance->TestNotEqual(UTF8_TO_TCHAR(description), valueStr, valueStr);
		}
		else
		{
			// PASS: The values are not equal, so TestNotEqual must pass.
			// Provide any two different strings to guarantee a pass.
			CurrentTestInstance->TestNotEqual(UTF8_TO_TCHAR(description), 0, 1);
		}
	}
	
	return 0;
}

int FKGLuaAutomationTest::lua_TestNearlyEqual(lua_State* L)
{
	// 参数: description (string), actual (number), expected (number), tolerance (number, 可选)
	const char* description = luaL_checkstring(L, 1);
	float actual = (float)luaL_checknumber(L, 2);
	float expected = (float)luaL_checknumber(L, 3);
	float tolerance = 0.001f;
	if (lua_gettop(L) >= 4)
	{
		tolerance = (float)luaL_checknumber(L, 4);
	}
	
	if (CurrentTestInstance)
	{
		CurrentTestInstance->TestNearlyEqual(UTF8_TO_TCHAR(description), actual, expected, tolerance);
	}
	
	return 0;
}

int FKGLuaAutomationTest::lua_TestNull(lua_State* L)
{
	// 参数: description (string), pointer (any)
	const char* description = luaL_checkstring(L, 1);
	
	if (CurrentTestInstance)
	{
		bool isNull = lua_isnil(L, 2);
		CurrentTestInstance->TestTrue(FString::Printf(TEXT("%s (空值检查)"), UTF8_TO_TCHAR(description)), isNull);
	}
	
	return 0;
}

int FKGLuaAutomationTest::lua_TestNotNull(lua_State* L)
{
	// 参数: description (string), pointer (any)
	const char* description = luaL_checkstring(L, 1);
	
	if (CurrentTestInstance)
	{
		bool isNotNull = !lua_isnil(L, 2);
		CurrentTestInstance->TestTrue(FString::Printf(TEXT("%s (非空值检查)"), UTF8_TO_TCHAR(description)), isNotNull);
	}
	
	return 0;
}

int FKGLuaAutomationTest::lua_AddInfo(lua_State* L)
{
	// 参数: message (string)
	const char* message = luaL_checkstring(L, 1);
	
	if (CurrentTestInstance)
	{
		CurrentTestInstance->AddInfo(UTF8_TO_TCHAR(message));
	}
	
	return 0;
}

int FKGLuaAutomationTest::lua_AddWarning(lua_State* L)
{
	// 参数: message (string)
	const char* message = luaL_checkstring(L, 1);
	
	if (CurrentTestInstance)
	{
		CurrentTestInstance->AddWarning(UTF8_TO_TCHAR(message));
	}
	
	return 0;
}

int FKGLuaAutomationTest::lua_AddError(lua_State* L)
{
	// 参数: message (string)
	const char* message = luaL_checkstring(L, 1);
	
	if (CurrentTestInstance)
	{
		CurrentTestInstance->AddError(UTF8_TO_TCHAR(message));
	}
	
	return 0;
}

int FKGLuaAutomationTest::lua_GetTestName(lua_State* L)
{
	if (CurrentTestInstance)
	{
		FString testName = CurrentTestInstance->GetTestName();
		lua_pushstring(L, TCHAR_TO_UTF8(*testName));
	}
	else
	{
		lua_pushstring(L, "未知测试");
	}
	
	return 1;
}

int FKGLuaAutomationTest::lua_HasAnyErrors(lua_State* L)
{
	if (CurrentTestInstance)
	{
		bool hasErrors = CurrentTestInstance->HasAnyErrors();
		lua_pushboolean(L, hasErrors);
	}
	else
	{
		lua_pushboolean(L, false);
	}
	
	return 1;
}

// === UKGLuaTestCommandlet 实现 ===
// 静态变量定义
UKGLuaTestCommandlet* UKGLuaTestCommandlet::CurrentInstance = nullptr;

UKGLuaTestCommandlet::UKGLuaTestCommandlet(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, LogLevel(TEXT("normal"))
	, OutputPath(TEXT(""))
	, bVerboseOutput(false)
	, bJsonOutput(false)
	, LuaStatePtr(nullptr)
{
	// 设置commandlet的基本属性
	IsClient = false;
	IsEditor = false;
	LogToConsole = true;
	ShowErrorCount = true;
	ShowProgress = true;
}

int32 UKGLuaTestCommandlet::Main(const FString& Params)
{
	UE_LOG(LogKGLuaTest, Log, TEXT("KGLuaTestCommandlet 开始执行多Lua文件测试（使用 FAutomationTestBase）..."));
	UE_LOG(LogKGLuaTest, Log, TEXT("参数: %s"), *Params);

	// 设置当前实例
	CurrentInstance = this;

	// 解析命令行参数
	if (!ParseParams(Params))
	{
		UE_LOG(LogKGLuaTest, Error, TEXT("参数解析失败"));
		return 1;
	}

	// 注意：目前再UED里面执行，不需要这个
	//RequestEngineExit(TEXT("KGLuaTestCommandlet Main"));

	// 执行所有Lua测试
	bool bAllTestsSuccess = RunAllLuaTests();

	// 清理资源
	CleanupLuaState();
	
	// 清理测试实例
	for (FKGLuaAutomationTest* TestInstance : TestInstances)
	{
		delete TestInstance;
	}
	TestInstances.Empty();

	// 返回适当的退出代码
	return bAllTestsSuccess ? 0 : 1;
}

bool UKGLuaTestCommandlet::ParseParams(const FString& Params)
{
	// 解析 LogLevel 参数
	FString LogLevelValue;
	if (FParse::Value(*Params, TEXT("LogLevel="), LogLevelValue))
	{
		LogLevel = LogLevelValue;
	}

	// 解析 OutputPath 参数
	FString OutputPathValue;
	if (FParse::Value(*Params, TEXT("OutputPath="), OutputPathValue))
	{
		OutputPath = OutputPathValue;
	}

	// 解析 LuaScript 参数（支持多个，用分号分隔）
	FString LuaScriptValue;
	if (FParse::Value(*Params, TEXT("LuaScript="), LuaScriptValue))
	{
		// 分割字符串
		LuaScriptValue.ParseIntoArray(LuaScriptPaths, TEXT(";"), true);
	}

	// 检查是否有 JsonOutput 标志
	bJsonOutput = FParse::Param(*Params, TEXT("JsonOutput"));

	// 检查是否有 Verbose 标志
	bVerboseOutput = FParse::Param(*Params, TEXT("Verbose"));

	// 根据日志级别设置详细输出
	if (LogLevel.Equals(TEXT("verbose"), ESearchCase::IgnoreCase))
	{
		bVerboseOutput = true;
	}

	if (bVerboseOutput)
	{
		UE_LOG(LogKGLuaTest, Log, TEXT("解析的参数:"));
		UE_LOG(LogKGLuaTest, Log, TEXT("  LogLevel: %s"), *LogLevel);
		UE_LOG(LogKGLuaTest, Log, TEXT("  OutputPath: %s"), *OutputPath);
		UE_LOG(LogKGLuaTest, Log, TEXT("  JsonOutput: %s"), bJsonOutput ? TEXT("true") : TEXT("false"));
		UE_LOG(LogKGLuaTest, Log, TEXT("  VerboseOutput: %s"), bVerboseOutput ? TEXT("true") : TEXT("false"));
		UE_LOG(LogKGLuaTest, Log, TEXT("  LuaScripts (%d):"), LuaScriptPaths.Num());
		for (int32 i = 0; i < LuaScriptPaths.Num(); i++)
		{
			UE_LOG(LogKGLuaTest, Log, TEXT("    [%d] %s"), i, *LuaScriptPaths[i]);
		}
	}

	return true;
}

bool UKGLuaTestCommandlet::RunAllLuaTests()
{
	UE_LOG(LogKGLuaTest, Log, TEXT("开始运行所有Lua测试（基于 FAutomationTestBase）..."));

	// 初始化lua状态
	if (!InitializeLuaState())
	{
		UE_LOG(LogKGLuaTest, Error, TEXT("初始化 Lua 状态失败"));
		return false;
	}

	TArray<FKGLuaAutomationTest*> TestResults;

	// 如果没有指定脚本，使用默认测试
	if (LuaScriptPaths.Num() == 0)
	{
		UE_LOG(LogKGLuaTest, Log, TEXT("未指定Lua脚本，运行默认测试"));
		LuaScriptPaths.Add(TEXT("DefaultLuaTest"));
	}

	// 逐个执行每个测试文件
	for (int32 i = 0; i < LuaScriptPaths.Num(); i++)
	{
		const FString& ScriptPath = LuaScriptPaths[i];
		FKGLuaAutomationTest* TestResult = RunSingleLuaTest(ScriptPath);
		
		if (TestResult)
		{
			TestResults.Add(TestResult);

			TestResult->ClearExecutionInfo();
			TestResult->RunAllTest(); // 不再依赖返回值，而是通过测试用例统计判断
		}
	}

	// === 修改：根据测试用例统计计算总体成功状态 ===
	int32 TotalExecutedTestCases = 0;
	int32 TotalFailedTestCases = 0;
	
	for (const FKGLuaAutomationTest* Test : TestResults)
	{
		if (Test)
		{
			TotalExecutedTestCases += Test->GetExecutedTestCaseCount();
			TotalFailedTestCases += Test->GetFailedTestCaseCount();
		}
	}
	
	bool bAllTestsSuccess = (TotalExecutedTestCases > 0) && (TotalFailedTestCases == 0);

	// 输出测试结果报告
	OutputTestReport(TestResults);

	UE_LOG(LogKGLuaTest, Log, TEXT("所有Lua测试完成，结果: %s (执行用例: %d, 失败用例: %d)"), 
		bAllTestsSuccess ? TEXT("成功") : TEXT("失败"),
		TotalExecutedTestCases,
		TotalFailedTestCases);

	return bAllTestsSuccess;
}

FKGLuaAutomationTest* UKGLuaTestCommandlet::RunSingleLuaTest(const FString& LuaScriptPath)
{
	// 生成测试名称
	FString TestName = FPaths::GetBaseFilename(LuaScriptPath);
	if (TestName.IsEmpty())
	{
		TestName = FString::Printf(TEXT("LuaTest_%d"), FMath::Rand());
	}

	// 创建测试实例（这会自动注册到UE5自动化测试框架）
	FKGLuaAutomationTest* TestInstance = new FKGLuaAutomationTest(
		FString::Printf(TEXT("KG.Lua.%s"), *TestName),
		LuaScriptPath,
		LuaStatePtr,
		false // 不是复杂任务
	);

	if (!TestInstance)
	{
		UE_LOG(LogKGLuaTest, Error, TEXT("无法创建测试实例"));
		return nullptr;
	}

	// 添加到实例列表以便后续清理
	TestInstances.Add(TestInstance);
	
	return TestInstance;
}

bool UKGLuaTestCommandlet::InitializeLuaState()
{
	if (LuaStatePtr)
	{
		// 已经初始化过了
		return true;
	}
    
    // 创建新的lua状态
    LuaEnv = UEditorLuaEnv::CreateLuaEnv(GEditor->GetEditorWorldContext().World(), UKGLuaTestGameInstance::StaticClass());
    LuaStatePtr = LuaEnv->GetLuaState(); // new LuaState("KGTestState");
    if (!LuaStatePtr)
    {
        UE_LOG(LogKGLuaTest, Error, TEXT("创建 LuaState 失败"));
        UEditorLuaEnv::DestroyLuaEnv(LuaEnv);
        LuaEnv = nullptr;
        return false;
    }

	TestGameInstance = Cast<UKGLuaTestGameInstance>(LuaEnv->GetLuaGameInstance());

    // 注册全局测试API
    RegisterLuaTestAPI(LuaStatePtr);

    if (bVerboseOutput)
    {
        UE_LOG(LogKGLuaTest, Log, TEXT("Lua 状态和测试环境初始化成功"));
    }

    return true;
}

void UKGLuaTestCommandlet::CleanupLuaState()
{	
	if (LuaEnv)
	{
        UEditorLuaEnv::DestroyLuaEnv(LuaEnv);
        LuaEnv = nullptr;
		LuaStatePtr = nullptr;
		
		if (bVerboseOutput)
		{
			UE_LOG(LogKGLuaTest, Log, TEXT("Lua 状态和测试环境已清理"));
		}
	}
}

void UKGLuaTestCommandlet::OutputTestReport(const TArray<FKGLuaAutomationTest*>& TestResults)
{
	if (bJsonOutput)
	{
		// 生成JSON报告
		TSharedPtr<FJsonObject> JsonReport = GenerateJsonReport(TestResults);
		
		FString JsonString;
		TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&JsonString);
		FJsonSerializer::Serialize(JsonReport.ToSharedRef(), Writer);
		
		// 输出到控制台
		UE_LOG(LogKGLuaTest, Log, TEXT("JSON测试报告:\n%s"), *JsonString);
		
		// 如果指定了输出路径，则写入JSON文件
		if (!OutputPath.IsEmpty())
		{
			FDateTime CurrentTime = FDateTime::Now();
			FString FileName = FString::Printf(TEXT("KGLuaTestReport_%s.json"), 
				*CurrentTime.ToString(TEXT("%Y%m%d_%H%M%S")));
			FString FullPath = FPaths::Combine(OutputPath, FileName);

			if (FFileHelper::SaveStringToFile(JsonString, *FullPath))
			{
				UE_LOG(LogKGLuaTest, Log, TEXT("JSON测试报告已保存到: %s"), *FullPath);
			}
			else
			{
				UE_LOG(LogKGLuaTest, Error, TEXT("无法保存JSON测试报告到: %s"), *FullPath);
			}
		}
	}
	else
	{
		// 生成传统文本报告
		FString TextReport = GenerateTextReport(TestResults);
		
		// 输出到控制台
		UE_LOG(LogKGLuaTest, Log, TEXT("\n%s"), *TextReport);
		
		// 如果指定了输出路径，则写入文本文件
		if (!OutputPath.IsEmpty())
		{
			FDateTime CurrentTime = FDateTime::Now();
			FString FileName = FString::Printf(TEXT("KGLuaTestReport_%s.txt"), 
				*CurrentTime.ToString(TEXT("%Y%m%d_%H%M%S")));
			FString FullPath = FPaths::Combine(OutputPath, FileName);

			if (FFileHelper::SaveStringToFile(TextReport, *FullPath))
			{
				UE_LOG(LogKGLuaTest, Log, TEXT("测试报告已保存到: %s"), *FullPath);
			}
			else
			{
				UE_LOG(LogKGLuaTest, Error, TEXT("无法保存测试报告到: %s"), *FullPath);
			}
		}
	}
}

TSharedPtr<FJsonObject> UKGLuaTestCommandlet::GenerateJsonReport(const TArray<FKGLuaAutomationTest*>& TestResults)
{
	TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject);
	FDateTime CurrentTime = FDateTime::Now();
	
	// === 修改：计算测试用例统计信息，而非测试文件统计 ===
	int32 TotalTestCases = 0;
	int32 ExecutedTestCases = 0;
	int32 SucceededTestCases = 0;
	int32 FailedTestCases = 0;
	
	for (const FKGLuaAutomationTest* Test : TestResults)
	{
		if (Test)
		{
			TotalTestCases += Test->GetTotalTestCaseCount();
			ExecutedTestCases += Test->GetExecutedTestCaseCount();
			SucceededTestCases += Test->GetSucceededTestCaseCount();
			FailedTestCases += Test->GetFailedTestCaseCount();
		}
	}
	
	// 基本信息
	JsonObject->SetStringField(TEXT("reportTime"), CurrentTime.ToString());
	JsonObject->SetStringField(TEXT("testFramework"), TEXT("FAutomationTestBase"));
	JsonObject->SetStringField(TEXT("logLevel"), LogLevel);
	JsonObject->SetNumberField(TEXT("totalTestFiles"), TestResults.Num());
	JsonObject->SetNumberField(TEXT("totalTestCases"), TotalTestCases);
	JsonObject->SetNumberField(TEXT("executedTestCases"), ExecutedTestCases);
	JsonObject->SetNumberField(TEXT("succeededTestCases"), SucceededTestCases);
	JsonObject->SetNumberField(TEXT("failedTestCases"), FailedTestCases);
	JsonObject->SetBoolField(TEXT("allTestsPassed"), FailedTestCases == 0 && ExecutedTestCases > 0);
	
	if (ExecutedTestCases > 0)
	{
		float SuccessRate = (float)SucceededTestCases / ExecutedTestCases * 100.0f;
		JsonObject->SetNumberField(TEXT("successRate"), SuccessRate);
	}
	else
	{
		JsonObject->SetNumberField(TEXT("successRate"), 0.0f);
	}
	
	// 添加每个测试的详细结果
	TArray<TSharedPtr<FJsonValue>> TestArray;
	for (const FKGLuaAutomationTest* Test : TestResults)
	{
		if (Test)
		{
			TSharedPtr<FJsonObject> TestObj = MakeShareable(new FJsonObject);
			TestObj->SetStringField(TEXT("testName"), Test->GetTestName());
			TestObj->SetStringField(TEXT("beautifiedName"), Test->GetBeautifiedTestName());
			TestObj->SetStringField(TEXT("scriptPath"), *Test->GetLuaScriptPath());
			TestObj->SetBoolField(TEXT("passed"), !Test->HasAnyErrors());
			TestObj->SetNumberField(FString("testFlags"), (int)Test->GetTestFlags());
			TestObj->SetStringField(TEXT("content"), *Test->GetTestResults());
			
			TestArray.Add(MakeShareable(new FJsonValueObject(TestObj)));
		}
	}
	JsonObject->SetArrayField(TEXT("testResults"), TestArray);
	
	return JsonObject;
}

FString UKGLuaTestCommandlet::GenerateTextReport(const TArray<FKGLuaAutomationTest*>& TestResults)
{
	FStringBuilderBase ReportContent;
	FDateTime CurrentTime = FDateTime::Now();
	
	// === 修改：计算测试用例统计信息 ===
	int32 TotalTestCases = 0;
	int32 ExecutedTestCases = 0;
	int32 SucceededTestCases = 0;
	int32 FailedTestCases = 0;
	
	for (const FKGLuaAutomationTest* Test : TestResults)
	{
		if (Test)
		{
			TotalTestCases += Test->GetTotalTestCaseCount();
			ExecutedTestCases += Test->GetExecutedTestCaseCount();
			SucceededTestCases += Test->GetSucceededTestCaseCount();
			FailedTestCases += Test->GetFailedTestCaseCount();
		}
	}
	
	// 生成报告内容
	ReportContent << TEXT("=== KG Lua 自动化测试报告（基于 FAutomationTestBase）===\n");
	ReportContent << TEXT("时间: ") << CurrentTime.ToString() << TEXT("\n");
	ReportContent << TEXT("测试框架: FAutomationTestBase\n");
	ReportContent << TEXT("测试文件数: ") << TestResults.Num() << TEXT("\n");
	ReportContent << TEXT("总测试用例数: ") << TotalTestCases << TEXT("\n");
	ReportContent << TEXT("已执行用例数: ") << ExecutedTestCases << TEXT("\n");
	ReportContent << TEXT("成功用例数: ") << SucceededTestCases << TEXT("\n");
	ReportContent << TEXT("失败用例数: ") << FailedTestCases << TEXT("\n");
	
	if (ExecutedTestCases > 0)
	{
		float SuccessRate = (float)SucceededTestCases / ExecutedTestCases * 100.0f;
		ReportContent << TEXT("成功率: ") << SuccessRate << TEXT("%%\n");
	}
	else
	{
		ReportContent << TEXT("成功率: 0%\n");
	}
	
	ReportContent << TEXT("整体结果: ");
	if (FailedTestCases == 0 && ExecutedTestCases > 0)
	{
		ReportContent << TEXT("成功\n");
	}
	else
	{
		ReportContent << TEXT("失败\n");
	}
	
	ReportContent << TEXT("日志级别: ") << LogLevel << TEXT("\n");
	ReportContent << TEXT("========================\n\n");
	
	// === 修改：添加每个测试文件的详细信息，包括测试用例统计 ===
	for (int32 i = 0; i < TestResults.Num(); i++)
	{
		const FKGLuaAutomationTest* Test = TestResults[i];
		if (Test)
		{
			ReportContent << TEXT("测试文件 ") << (i + 1) << TEXT(": ") << Test->GetBeautifiedTestName() << TEXT("\n");
			ReportContent << TEXT("  内部名称: ") << Test->GetTestName() << TEXT("\n");
			ReportContent << TEXT("  脚本: ") << Test->GetLuaScriptPath() << TEXT("\n");
			ReportContent << TEXT("  测试用例统计:\n");
			ReportContent << TEXT("    总用例数: ") << Test->GetTotalTestCaseCount() << TEXT("\n");
			ReportContent << TEXT("    执行用例数: ") << Test->GetExecutedTestCaseCount() << TEXT("\n");
			ReportContent << TEXT("    成功用例数: ") << Test->GetSucceededTestCaseCount() << TEXT("\n");
			ReportContent << TEXT("    失败用例数: ") << Test->GetFailedTestCaseCount() << TEXT("\n");
			ReportContent << TEXT("  文件结果: ");
			if (Test->GetFailedTestCaseCount() == 0 && Test->GetExecutedTestCaseCount() > 0)
			{
				ReportContent << TEXT("通过\n");
			}
			else if (Test->GetExecutedTestCaseCount() == 0)
			{
				ReportContent << TEXT("未执行\n");
			}
			else
			{
				ReportContent << TEXT("失败\n");
			}
			ReportContent << TEXT("  执行过程:\n") << Test->GetTestResults();
			ReportContent << TEXT("\n");
		}
	}
	
	return ReportContent.ToString();
}

// === 全局 Lua API 实现 ===

void UKGLuaTestCommandlet::RegisterLuaTestAPI(lua_State* L)
{
	// 创建KGTest表（全局工具函数）
	lua_newtable(L);
	
	// 注册GameInstance访问函数
	lua_pushcfunction(L, lua_GetTestGameInstance);
	lua_setfield(L, -2, "GetGameInstance");
	
	// 将KGTest表设置为全局变量
	lua_setglobal(L, "KGTest");
}

// === Lua API函数实现 ===

int UKGLuaTestCommandlet::lua_GetTestGameInstance(lua_State* L)
{
	UKGLuaTestCommandlet* CommandletInstance = GetCurrentInstance();
	if (!CommandletInstance)
	{
		lua_pushnil(L);
		return 1;
	}
	
	UKGLuaTestGameInstance* GameInstance = CommandletInstance->GetTestGameInstance();
	if (!GameInstance)
	{
		lua_pushnil(L);
		return 1;
	}
	
	// 将GameInstance推送到Lua栈
	slua::LuaObject::push(L, GameInstance);
	return 1;
}
