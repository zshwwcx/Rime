#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "KGMcpUtility.generated.h"

// Forward declare UWidgetBlueprint if its header is heavy or to avoid circular dependencies.
class UWidgetBlueprint;

UCLASS()
class C7EDITOR_API UKGMcpUtility : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	/**
	 * Generates UI Lua code for the given Widget Blueprint asset.
	 * Calls KGLuaTemplateGenerator::GeneratorLua internally.
	 * @param WidgetBlueprint The Widget Blueprint asset to generate Lua code for.
	 * @param OutSuccess True if successful, false otherwise.
	 * @param OutGeneratedPath The file path of the generated Lua file if successful.
	 */
	UFUNCTION(BlueprintCallable, Category = "KGMcp Utility|Lua Generation", meta = (DisplayName = "Generate UI Lua Code from WBP"))
	static void GenerateUILuaCodeFromWBP(UWidgetBlueprint* WidgetBlueprint, bool& OutSuccess, FString& OutGeneratedPath);

	/**
	 * Generates specified system code files (System, Sender, Receiver, Model) using KGLuaTemplateGenerator.
	 * If a file is successfully generated or already exists, its path is added to the output list.
	 * @param SystemName The name of the system for which to generate code.
	 * @param bCreateSystemFile If true, attempts to generate the system file.
	 * @param bCreateSenderFile If true, attempts to generate the sender file.
	 * @param bCreateReceiverFile If true, attempts to generate the receiver file.
	 * @param bCreateModelFile If true, attempts to generate the model file.
	 * @param OutSuccess True if at least one file was successfully processed or found, false otherwise.
	 * @param OutGeneratedFilePaths A list of file paths for successfully generated or existing files.
	 */
	UFUNCTION(BlueprintCallable, Category = "KGMcp Utility|Lua Generation", meta = (DisplayName = "Generate KG System Code Files"))
	static void GenerateKGSystemCodeFiles(
		const FString& SystemName,
		bool bCreateSystemFile,
		bool bCreateSenderFile,
		bool bCreateReceiverFile,
		bool bCreateModelFile,
		bool& OutSuccess,
		TArray<FString>& OutGeneratedFilePaths
	);

	/**
	 * Checks if Perforce (P4) is fully connected and available for source control operations.
	 * This function verifies that the source control provider is enabled, available, and properly connected.
	 * @param OutSuccess True if Perforce is fully connected and ready for operations, false otherwise.
	 * @param OutErrorMessage If not connected, contains a descriptive error message explaining the issue.
	 */
	UFUNCTION(BlueprintCallable, Category = "KGMcp Utility|Source Control", meta = (DisplayName = "Is Perforce Fully Connected"))
	static void IsPerforceFullyConnected(bool& OutSuccess, FString& OutErrorMessage);

	/**
	 * Gets the WidgetTree object from a UWidgetBlueprint and provides an error message if retrieval fails.
	 * This allows Python to directly access and parse the WidgetTree structure using its exposed UFunctions and UProperties.
	 * Note: The WidgetBlueprint must be compiled for its GeneratedClass and WidgetTree to be accessible.
	 * @param WidgetBlueprint The Widget Blueprint asset to query.
	 * @param OutSuccess True if the WidgetTree was successfully retrieved, false otherwise.
	 * @param OutWidgetTree The retrieved UWidgetTree object if successful, nullptr otherwise.
	 * @param OutErrorMessage An error message if retrieval failed, empty otherwise.
	 */
	UFUNCTION(BlueprintCallable, Category = "KGMcp Utility|UMG Query", meta = (DisplayName = "Get WidgetTree From WBP with Error Message"))
	static void GetWidgetTreeFromWBP(UWidgetBlueprint* WidgetBlueprint, bool& OutSuccess, class UWidgetTree*& OutWidgetTree, FString& OutErrorMessage);

	/**
	 * Gets all widgets from the given UWidgetTree.
	 * This function traverses the entire widget tree and collects all widget instances for Python access.
	 * @param WidgetTree The WidgetTree to extract widgets from.
	 * @param OutSuccess True if the operation was successful, false otherwise.
	 * @param OutWidgets Array containing all widgets found in the tree.
	 * @param OutErrorMessage An error message if the operation failed, empty otherwise.
	 */
	UFUNCTION(BlueprintCallable, Category = "KGMcp Utility|UMG Query", meta = (DisplayName = "Get All Widgets From Widget Tree"))
	static void GetAllWidgets(class UWidgetTree* WidgetTree, bool& OutSuccess, TArray<class UWidget*>& OutWidgets, FString& OutErrorMessage);

	/**
	 * Safely gets the bIsVariable property from a UWidget.
	 * This function provides safe access to the widget's variable flag for Python scripts.
	 * @param Widget The UWidget to check.
	 * @param OutSuccess True if the operation was successful, false otherwise.
	 * @param OutIsVariable True if the widget is marked as a variable, false otherwise.
	 * @param OutErrorMessage An error message if the operation failed, empty otherwise.
	 */
	UFUNCTION(BlueprintCallable, Category = "KGMcp Utility|UMG Query", meta = (DisplayName = "Get Widget Is Variable"))
	static void GetWidgetIsVariable(class UWidget* Widget, bool& OutSuccess, bool& OutIsVariable, FString& OutErrorMessage);

	/**
	 * Safely checks if a UWidget is programmer-controlled by examining its code reference flag.
	 * This function provides safe access to the widget's programmer control status for Python scripts.
	 * @param Widget The UWidget to check.
	 * @param OutSuccess True if the operation was successful, false otherwise.
	 * @param OutIsProgrammerControlled True if the widget is programmer-controlled, false otherwise.
	 * @param OutErrorMessage An error message if the operation failed, empty otherwise.
	 */
	UFUNCTION(BlueprintCallable, Category = "KGMcp Utility|UMG Query", meta = (DisplayName = "Get Widget Is Programmer Controlled"))
	static void GetWidgetIsProgrammerControlled(class UWidget* Widget, bool& OutSuccess, bool& OutIsProgrammerControlled, FString& OutErrorMessage);

	/**
	 * Gets all Blueprint functions from the given Widget Blueprint.
	 * @param WidgetBlueprint The Widget Blueprint to extract functions from.
	 * @param OutSuccess True if the operation was successful, false otherwise.
	 * @param OutFunctions Array containing all functions found in the Blueprint.
	 * @param OutErrorMessage An error message if the operation failed, empty otherwise.
	 */
	UFUNCTION(BlueprintCallable, Category = "KGMcp Utility|UMG Query", meta = (DisplayName = "Get All Blueprint Functions"))
	static void GetAllBlueprintFunctions(UWidgetBlueprint* WidgetBlueprint, bool& OutSuccess, TArray<UFunction*>& OutFunctions, FString& OutErrorMessage);

	/**
	 * Gets all Blueprint variables from the given Widget Blueprint for the default category.
	 * @param WidgetBlueprint The Widget Blueprint to extract variables from.
	 * @param OutSuccess True if the operation was successful, false otherwise.
	 * @param OutVariables Array containing all variables found in the Blueprint for the default category.
	 * @param OutErrorMessage An error message if the operation failed, empty otherwise.
	 */
	UFUNCTION(BlueprintCallable, Category = "KGMcp Utility|UMG Query", meta = (DisplayName = "Get Default Category Blueprint Variables"))
	static void GetDefaultCategoryBlueprintVariables(UWidgetBlueprint* WidgetBlueprint, bool& OutSuccess, TArray<FString>& OutVariables, FString& OutErrorMessage);

	/**
	 * Gets all Blueprint variables from the given Widget Blueprint for the animation category.
	 * @param WidgetBlueprint The Widget Blueprint to extract variables from.
	 * @param OutSuccess True if the operation was successful, false otherwise.
	 * @param OutVariables Array containing all variables found in the Blueprint for the animation category.
	 * @param OutErrorMessage An error message if the operation failed, empty otherwise.
	 */
	UFUNCTION(BlueprintCallable, Category = "KGMcp Utility|UMG Query", meta = (DisplayName = "Get Animation Category Blueprint Variables"))
	static void GetAnimationCategoryBlueprintVariables(UWidgetBlueprint* WidgetBlueprint, bool& OutSuccess, TArray<FString>& OutVariables, FString& OutErrorMessage);

	// ==============================
	// Lua Testing Utility APIs
	// ==============================
	
	/**
	 * Executes Lua code in commandlet environment and captures the output for testing purposes.
	 * This function runs the provided Lua code and returns the execution result along with any output or error messages.
	 * @param LuaCode The Lua code string to execute.
	 * @param OutSuccess True if the Lua code executed successfully, false if there were syntax or runtime errors.
	 * @param OutOutput The captured output from the Lua execution (including print statements).
	 * @param OutErrorMessage If execution failed, contains the error message; empty otherwise.
	 */
	UFUNCTION(BlueprintCallable, Category = "KGMcp Utility|Lua Testing", meta = (DisplayName = "Execute Lua Code In Commandlet"))
	static void ExecuteLuaCodeInCommandlet(const FString& LuaCode, bool& OutSuccess, FString& OutOutput, FString& OutErrorMessage);

	/**
	 * Executes multiple Lua files in commandlet environment and captures the output for testing purposes.
	 * This function runs the provided Lua files using UKGLuaTestCommandlet and returns the execution result along with any output or error messages.
	 * @param LuaFilePaths Array of absolute paths to Lua files to execute.
	 * @param OutSuccess True if all Lua files executed successfully, false if there were any errors.
	 * @param OutOutput The captured output from the Lua execution (including print statements and test results).
	 * @param OutErrorMessage If execution failed, contains the error message; empty otherwise.
	 */
	UFUNCTION(BlueprintCallable, Category = "KGMcp Utility|Lua Testing", meta = (DisplayName = "Execute Lua Files In Commandlet"))
	static void ExecuteLuaFilesInCommandlet(const TArray<FString>& LuaFilePaths, bool& OutSuccess, FString& OutOutput, FString& OutErrorMessage);

	/**
	 * Checks the current Play In Editor (PIE) status.
	 * This function determines whether PIE is currently active and running.
	 * @param OutSuccess True if the status check was performed successfully, false if there was an error during the check.
	 * @param OutIsPieActive True if PIE is currently active and running, false otherwise.
	 * @param OutErrorMessage If the status check failed, contains the error message; empty otherwise.
	 */
	UFUNCTION(BlueprintCallable, Category = "KGMcp Utility|Lua Testing", meta = (DisplayName = "Check PIE Status"))
	static void CheckPieStatus(bool& OutSuccess, bool& OutIsPieActive, FString& OutErrorMessage);

	/**
	 * Starts Play In Editor (PIE) mode programmatically.
	 * This function attempts to launch PIE session for testing purposes.
	 * @param OutSuccess True if PIE was started successfully, false if the start operation failed.
	 * @param OutErrorMessage If PIE start failed, contains the error message explaining why; empty otherwise.
	 */
	UFUNCTION(BlueprintCallable, Category = "KGMcp Utility|Lua Testing", meta = (DisplayName = "Start PIE"))
	static void StartPie(bool& OutSuccess, FString& OutErrorMessage);

	/**
	 * Stops Play In Editor (PIE) mode programmatically.
	 * This function attempts to end the current PIE session for testing purposes.
	 * @param OutSuccess True if PIE was stopped successfully, false if the stop operation failed.
	 * @param OutErrorMessage If PIE stop failed, contains the error message explaining why; empty otherwise.
	 */
	UFUNCTION(BlueprintCallable, Category = "KGMcp Utility|Lua Testing", meta = (DisplayName = "Stop PIE"))
	static void StopPie(bool& OutSuccess, FString& OutErrorMessage);

	/**
	 * Reloads the Lua scripting system.
	 * This function performs a hot reload of the Lua environment, reloading all Lua scripts.
	 * @param OutSuccess True if Lua reload was successful, false if the reload operation failed.
	 * @param OutErrorMessage If Lua reload failed, contains the error message explaining why; empty otherwise.
	 */
	UFUNCTION(BlueprintCallable, Category = "KGMcp Utility|Lua Testing", meta = (DisplayName = "Reload Lua"))
	static void ReloadLua(bool& OutSuccess, FString& OutErrorMessage);

private:
	/**
	 * Internal helper method to execute UKGLuaTestCommandlet with specified Lua script paths.
	 * This method contains the core logic for running the commandlet and capturing output.
	 * @param LuaScriptPaths Array of Lua script paths to execute (can be file paths or script names).
	 * @param OutSuccess True if commandlet execution was successful, false otherwise.
	 * @param OutOutput The captured output from the commandlet execution.
	 * @param OutErrorMessage If execution failed, contains the error message; empty otherwise.
	 */
	static void ExecuteCommandletWithLuaScripts(const TArray<FString>& LuaScriptPaths, bool& OutSuccess, FString& OutOutput, FString& OutErrorMessage);
};
