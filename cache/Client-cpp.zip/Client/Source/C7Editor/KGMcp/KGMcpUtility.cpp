#include "KGMcpUtility.h"
#include "WidgetBlueprint.h" // Required for UWidgetBlueprint
#include "UMG/Blueprint/KGUserWidget.h" // Required for UKGUserWidget
#include "KGUISettings.h"           // Required for UKGUISettings
#include "HAL/FileManager.h"            // Required for IFileManager
#include "Misc/Paths.h"                 // Required for FPaths
#include "Logging/LogMacros.h"         // For UE_LOG
#include "Editor.h"                    // Required for GEditor
#include "Subsystems/EditorAssetSubsystem.h" // Required for UEditorAssetSubsystem if you need to load assets by path string

// Source Control includes
#include "ISourceControlModule.h"      // Required for source control operations
#include "ISourceControlProvider.h"    // Required for source control provider interface

// Correct include path for KGLuaTemplateGenerator
// This path needs to be accurate based on your project structure.
// For example, if KGLuaTemplateGenerator is in KGUIEditor module, in a subdirectory LuaGenerator:
#include "KGUIEditor/Public/LuaGenerator/KGLuaTemplateGenerator.h"
#include "Kismet2/KismetEditorUtilities.h"

#include "Blueprint/WidgetTree.h" // Required for UWidgetTree
#include "Blueprint/UserWidget.h" // Required for UUserWidget and CreateWidget
#include "Engine/World.h"         // Required for GetWorld via GEditor
#include "Editor/EditorEngine.h"  // Required for GEditor

// PIE and Play Session includes for Lua Testing APIs
#include "LuaState.h"
#include "Editor/UnrealEdEngine.h"
#include "EditorExtenders/ToolsLibrary.h"
#include "Settings/LevelEditorPlaySettings.h" // Required for ULevelEditorPlaySettings
#include "Engine/Engine.h"        // Required for GEngine and world contexts

// KGLuaTestCommandlet include for ExecuteLuaCodeInCommandlet
#include "KGMcp/LuaTestCommandlet/KGLuaTestCommandlet.h"
#include "Misc/FileHelper.h"       // Required for FFileHelper
#include "HAL/PlatformFilemanager.h" // Required for platform file operations
#include "UObject/GCObjectScopeGuard.h" // Required for FGCObjectScopeGuard

// Define a log category for this utility, if you want specific logging
// DEFINE_LOG_CATEGORY_STATIC(LogKGMcpUtility, Log, All);

void UKGMcpUtility::GenerateUILuaCodeFromWBP(UWidgetBlueprint* WidgetBlueprint, bool& OutSuccess, FString& OutGeneratedPath)
{
	OutGeneratedPath.Empty();
	OutSuccess = false;

	if (!WidgetBlueprint)
	{
		UE_LOG(LogTemp, Warning, TEXT("UKGMcpUtility::GenerateUILuaCodeFromWBP: WidgetBlueprint is null."));
		return;
	}

	// 确保蓝图已编译
	if (!WidgetBlueprint->GeneratedClass)
	{
		UE_LOG(LogTemp, Warning, TEXT("UKGMcpUtility::GenerateUILuaCodeFromWBP: WidgetBlueprint's GeneratedClass is null for %s."), *WidgetBlueprint->GetPathName());
		return;
	}

	// 从GeneratedClass获取DefaultObject，然后转换为KGUserWidget
	UObject* DefaultObject = WidgetBlueprint->GeneratedClass->GetDefaultObject();
	if (!DefaultObject)
	{
		UE_LOG(LogTemp, Warning, TEXT("UKGMcpUtility::GenerateUILuaCodeFromWBP: GeneratedClass DefaultObject is null for %s"), *WidgetBlueprint->GetPathName());
		return;
	}

	UKGUserWidget* KGUserWidget = Cast<UKGUserWidget>(DefaultObject);
	if (!KGUserWidget)
	{
		UE_LOG(LogTemp, Warning, TEXT("UKGMcpUtility::GenerateUILuaCodeFromWBP: DefaultObject is not a UKGUserWidget. Asset: %s, DefaultObject Class: %s"),
			*WidgetBlueprint->GetPathName(),
			DefaultObject->GetClass() ? *DefaultObject->GetClass()->GetName() : TEXT("Unknown"));
		return;
	}

	// 处理WidgetTree为空的问题
	if (!KGUserWidget->WidgetTree)
	{
		UE_LOG(LogTemp, Warning, TEXT("UKGMcpUtility::GenerateUILuaCodeFromWBP: KGUserWidget WidgetTree is null for %s, attempting to create temporary instance"), *WidgetBlueprint->GetPathName());

		// 检查蓝图生成类是否继承自UKGUserWidget
		if (!WidgetBlueprint->GeneratedClass->IsChildOf<UKGUserWidget>())
		{
			UE_LOG(LogTemp, Warning, TEXT("UKGMcpUtility::GenerateUILuaCodeFromWBP: WidgetBlueprint GeneratedClass is not a child of UKGUserWidget: %s"), *WidgetBlueprint->GetPathName());
			return;
		}

		// 创建实例，然后转换
		if (UWorld* EditorWorld = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr)
		{
			UWidgetBlueprintGeneratedClass* WidgetClass = Cast<UWidgetBlueprintGeneratedClass>(WidgetBlueprint->GeneratedClass);
			UKGUserWidget* TempKGWidget = CreateWidget<UKGUserWidget>(EditorWorld, WidgetClass, WidgetClass->GetFName());
			if (TempKGWidget && TempKGWidget->WidgetTree)
			{
				UE_LOG(LogTemp, Log, TEXT("UKGMcpUtility::GenerateUILuaCodeFromWBP: Successfully created temporary widget instance for WidgetTree access"));
				KGUserWidget = TempKGWidget;
			}
			else
			{
				UE_LOG(LogTemp, Warning, TEXT("UKGMcpUtility::GenerateUILuaCodeFromWBP: Temporary widget creation failed or WidgetTree is still null"));
				return;
			}
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("UKGMcpUtility::GenerateUILuaCodeFromWBP: No valid editor world found for widget creation"));
			return;
		}
	}

	// 现在可以安全地调用生成器
	KGLuaTemplateGenerator GeneratorInstance;
	FName LuaRequirePathName = GeneratorInstance.GeneratorLua(KGUserWidget);

	if (LuaRequirePathName.IsNone())
	{
		UE_LOG(LogTemp, Warning, TEXT("UKGMcpUtility::GenerateUILuaCodeFromWBP: KGLuaTemplateGenerator::GeneratorLua failed for %s (returned None path)."), *WidgetBlueprint->GetName());
		return;
	}

	// 生成文件路径
	FString RelativeLuaPath = LuaRequirePathName.ToString();
	RelativeLuaPath.ReplaceInline(TEXT("."), TEXT("/"));
	OutGeneratedPath = GetDefault<UKGUISettings>()->LuaRootDir() / RelativeLuaPath + TEXT(".lua");
	FPaths::NormalizeFilename(OutGeneratedPath);
	OutGeneratedPath = FPaths::ConvertRelativePathToFull(OutGeneratedPath);

	if (!IFileManager::Get().FileExists(*OutGeneratedPath))
	{
		UE_LOG(LogTemp, Warning, TEXT("UKGMcpUtility::GenerateUILuaCodeFromWBP: Generated Lua file not found at %s"), *OutGeneratedPath);
		return;
	}

	UE_LOG(LogTemp, Log, TEXT("UKGMcpUtility::GenerateUILuaCodeFromWBP: Successfully generated Lua code for %s at %s"),
		*WidgetBlueprint->GetName(), *OutGeneratedPath);
	OutSuccess = true;
}

void UKGMcpUtility::GenerateKGSystemCodeFiles(
	const FString& SystemName,
	bool bCreateSystemFileFlag, // Renamed to avoid conflict with KGLuaTemplateGenerator's CreateSystemFile method name
	bool bCreateSenderFileFlag,
	bool bCreateReceiverFileFlag,
	bool bCreateModelFileFlag,
	bool& OutSuccess,
	TArray<FString>& OutGeneratedFilePaths)
{
	OutGeneratedFilePaths.Empty();
	OutSuccess = false;
	bool bAtLeastOneSucceeded = false;

	if (SystemName.IsEmpty())
	{
		UE_LOG(LogTemp, Warning, TEXT("UKGMcpUtility::GenerateKGSystemCodeFiles: SystemName is empty."));
		return;
	}

	UE_LOG(LogTemp, Log, TEXT("UKGMcpUtility::GenerateKGSystemCodeFiles: Processing system '%s'."), *SystemName);

	KGLuaTemplateGenerator GeneratorInstance;
	FString SystemFilesBaseDir = GeneratorInstance.GetSystemFileOutPath(SystemName); // This gets .../SystemName/System

	if (bCreateSystemFileFlag)
	{
		// Determine bCreateNet and bCreateModel arguments for KGLuaTemplateGenerator::CreateSystemFile
		bool bShouldCreateNetForSystemFile = bCreateSenderFileFlag || bCreateReceiverFileFlag;
		bool bShouldCreateModelForSystemFile = bCreateModelFileFlag;
		GeneratorInstance.CreateSystemFile(SystemName, bShouldCreateNetForSystemFile, bShouldCreateModelForSystemFile);

		FString ExpectedFilePath = SystemFilesBaseDir / (SystemName + TEXT("System.lua"));
		FPaths::NormalizeFilename(ExpectedFilePath);
		ExpectedFilePath = FPaths::ConvertRelativePathToFull(ExpectedFilePath);
		if (IFileManager::Get().FileExists(*ExpectedFilePath))
		{
			OutGeneratedFilePaths.Add(ExpectedFilePath);
			bAtLeastOneSucceeded = true;
			UE_LOG(LogTemp, Log, TEXT("System file for '%s' processed/found: %s"), *SystemName, *ExpectedFilePath);
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("System file for '%s' was requested but not found after generation attempt at: %s"), *SystemName, *ExpectedFilePath);
		}
	}

	if (bCreateSenderFileFlag)
	{
		GeneratorInstance.CreateSenderFile(SystemName);
		FString ExpectedFilePath = SystemFilesBaseDir / (SystemName + TEXT("Sender.lua"));
		FPaths::NormalizeFilename(ExpectedFilePath);
		ExpectedFilePath = FPaths::ConvertRelativePathToFull(ExpectedFilePath);
		if (IFileManager::Get().FileExists(*ExpectedFilePath))
		{
			OutGeneratedFilePaths.Add(ExpectedFilePath);
			bAtLeastOneSucceeded = true;
			UE_LOG(LogTemp, Log, TEXT("Sender file for '%s' processed/found: %s"), *SystemName, *ExpectedFilePath);
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("Sender file for '%s' was requested but not found after generation attempt at: %s"), *SystemName, *ExpectedFilePath);
		}
	}

	if (bCreateReceiverFileFlag)
	{
		GeneratorInstance.CreateReceiverFile(SystemName); // Note: Implementation in KGLuaTemplateGenerator.cpp is commented out
		FString ExpectedFilePath = SystemFilesBaseDir / (SystemName + TEXT("Receiver.lua"));
		FPaths::NormalizeFilename(ExpectedFilePath);
		ExpectedFilePath = FPaths::ConvertRelativePathToFull(ExpectedFilePath);
		if (IFileManager::Get().FileExists(*ExpectedFilePath))
		{
			OutGeneratedFilePaths.Add(ExpectedFilePath);
			bAtLeastOneSucceeded = true;
			UE_LOG(LogTemp, Log, TEXT("Receiver file for '%s' processed/found: %s"), *SystemName, *ExpectedFilePath);
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("Receiver file for '%s' was requested. (Generator function might be commented out or failed) Not found at: %s"), *SystemName, *ExpectedFilePath);
		}
	}

	if (bCreateModelFileFlag)
	{
		GeneratorInstance.CreateModelFile(SystemName);
		FString ExpectedFilePath = SystemFilesBaseDir / (SystemName + TEXT("Model.lua"));
		FPaths::NormalizeFilename(ExpectedFilePath);
		ExpectedFilePath = FPaths::ConvertRelativePathToFull(ExpectedFilePath);
		if (IFileManager::Get().FileExists(*ExpectedFilePath))
		{
			OutGeneratedFilePaths.Add(ExpectedFilePath);
			bAtLeastOneSucceeded = true;
			UE_LOG(LogTemp, Log, TEXT("Model file for '%s' processed/found: %s"), *SystemName, *ExpectedFilePath);
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("Model file for '%s' was requested but not found after generation attempt at: %s"), *SystemName, *ExpectedFilePath);
		}
	}

	OutSuccess = bAtLeastOneSucceeded;
	return;
}

void UKGMcpUtility::IsPerforceFullyConnected(bool& OutSuccess, FString& OutErrorMessage)
{
	OutSuccess = false;
	OutErrorMessage.Empty();

	// Load the source control module
	ISourceControlModule& SourceControlModule = FModuleManager::LoadModuleChecked<ISourceControlModule>("SourceControl");

	// Check if source control is enabled
	if (!SourceControlModule.IsEnabled())
	{
		OutErrorMessage = TEXT("Source control is not enabled in the editor. Please enable source control in Editor Preferences.");
		UE_LOG(LogTemp, Warning, TEXT("UKGMcpUtility::IsPerforceFullyConnected: %s"), *OutErrorMessage);
		return;
	}

	// Get the source control provider
	ISourceControlProvider& SourceControlProvider = SourceControlModule.GetProvider();

	// Check if the provider is available
	if (!SourceControlProvider.IsAvailable())
	{
		OutErrorMessage = TEXT("Source control provider is not available. Please check your source control configuration.");
		UE_LOG(LogTemp, Warning, TEXT("UKGMcpUtility::IsPerforceFullyConnected: %s"), *OutErrorMessage);
		return;
	}

	// Check if the provider is enabled
	if (!SourceControlProvider.IsEnabled())
	{
		OutErrorMessage = TEXT("Source control provider is not enabled. Please enable the source control provider in Editor Preferences.");
		UE_LOG(LogTemp, Warning, TEXT("UKGMcpUtility::IsPerforceFullyConnected: %s"), *OutErrorMessage);
		return;
	}

	// Get provider name to verify it's Perforce
	FString ProviderName = SourceControlProvider.GetName().ToString();
	if (!ProviderName.Contains(TEXT("Perforce")) && !ProviderName.Contains(TEXT("P4")))
	{
		OutErrorMessage = FString::Printf(TEXT("Current source control provider is '%s', not Perforce. Please configure Perforce as your source control provider."), *ProviderName);
		UE_LOG(LogTemp, Warning, TEXT("UKGMcpUtility::IsPerforceFullyConnected: %s"), *OutErrorMessage);
		return;
	}

	// If we've made it this far, Perforce is fully connected
	OutSuccess = true;
	UE_LOG(LogTemp, Log, TEXT("UKGMcpUtility::IsPerforceFullyConnected: Perforce is fully connected and ready for operations."));
	return;
}

void UKGMcpUtility::GetWidgetTreeFromWBP(UWidgetBlueprint* WidgetBlueprint, bool& OutSuccess, UWidgetTree*& OutWidgetTree, FString& OutErrorMessage)
{
	OutSuccess = false;
	OutWidgetTree = nullptr;
	OutErrorMessage.Empty();

	if (!WidgetBlueprint)
	{
		OutErrorMessage = TEXT("GetWidgetTreeFromWBP: WidgetBlueprint is null.");
		UE_LOG(LogTemp, Warning, TEXT("%s"), *OutErrorMessage);
		return;
	}

	const FString WBPName = WidgetBlueprint->GetPathName();

	// Ensure the blueprint is compiled and has a GeneratedClass
	if (!WidgetBlueprint->GeneratedClass)
	{
		UE_LOG(LogTemp, Warning, TEXT("GetWidgetTreeFromWBP: WidgetBlueprint '%s' has no GeneratedClass. Attempting to compile."), *WBPName);
		FKismetEditorUtilities::CompileBlueprint(WidgetBlueprint);
		if (!WidgetBlueprint->GeneratedClass)
		{
			OutErrorMessage = FString::Printf(TEXT("GetWidgetTreeFromWBP: Failed to compile WidgetBlueprint '%s' or it still has no GeneratedClass."), *WBPName);
			UE_LOG(LogTemp, Error, TEXT("%s"), *OutErrorMessage);
			return;
		}
	}

	UClass* GeneratedClass = WidgetBlueprint->GeneratedClass;
	if (!GeneratedClass)
	{
		OutErrorMessage = FString::Printf(TEXT("GetWidgetTreeFromWBP: WidgetBlueprint '%s' GeneratedClass is unexpectedly null after compile check."), *WBPName);
		UE_LOG(LogTemp, Error, TEXT("%s"), *OutErrorMessage);
		return;
	}

	// Try to get WidgetTree from the Class Default Object (CDO)
	if (UUserWidget* DefaultWidget = Cast<UUserWidget>(GeneratedClass->GetDefaultObject()))
	{
		if (DefaultWidget->WidgetTree)
		{
			UE_LOG(LogTemp, Log, TEXT("GetWidgetTreeFromWBP: Successfully retrieved WidgetTree from CDO for '%s'."), *WBPName);
			OutWidgetTree = DefaultWidget->WidgetTree;
			OutSuccess = true;
			return;
		}
		UE_LOG(LogTemp, Warning, TEXT("GetWidgetTreeFromWBP: WidgetTree on CDO is null for '%s'. Attempting to create a temporary instance."), *WBPName);
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("GetWidgetTreeFromWBP: CDO of GeneratedClass for '%s' is not a UUserWidget. Attempting to create a temporary instance."), *WBPName);
	}

	if (GEditor)
	{
		UWorld* World = GEditor->GetEditorWorldContext().World();
		if (World)
		{
			if (GeneratedClass->IsChildOf(UUserWidget::StaticClass()))
			{
				UUserWidget* TempWidget = CreateWidget<UUserWidget>(World, GeneratedClass);
				if (TempWidget && TempWidget->WidgetTree)
				{
					UE_LOG(LogTemp, Log, TEXT("GetWidgetTreeFromWBP: Successfully retrieved WidgetTree from temporary instance for '%s'."), *WBPName);
					OutWidgetTree = TempWidget->WidgetTree;
					OutSuccess = true;
					return;
				}
				else
				{
					OutErrorMessage = FString::Printf(TEXT("GetWidgetTreeFromWBP: Failed to create temporary widget or its WidgetTree is null for '%s'."), *WBPName);
					UE_LOG(LogTemp, Error, TEXT("%s"), *OutErrorMessage);
					return;
				}
			}
			else
			{
				OutErrorMessage = FString::Printf(TEXT("GetWidgetTreeFromWBP: GeneratedClass for '%s' is not a subclass of UUserWidget, cannot create temporary instance for WidgetTree retrieval."), *WBPName);
				UE_LOG(LogTemp, Error, TEXT("%s"), *OutErrorMessage);
				return;
			}
		}
		else
		{
			OutErrorMessage = FString::Printf(TEXT("GetWidgetTreeFromWBP: GEditor World is null, cannot create temporary widget for '%s'."), *WBPName);
			UE_LOG(LogTemp, Error, TEXT("%s"), *OutErrorMessage);
			return;
		}
	}
	else
	{
		OutErrorMessage = FString::Printf(TEXT("GetWidgetTreeFromWBP: GEditor is null, cannot create temporary widget for '%s'."), *WBPName);
		UE_LOG(LogTemp, Error, TEXT("%s"), *OutErrorMessage);
		return;
	}

	// Fallback error message if all methods failed and no specific error was set.
	if (OutErrorMessage.IsEmpty())
	{
		OutErrorMessage = FString::Printf(TEXT("GetWidgetTreeFromWBP: Failed to retrieve WidgetTree for '%s' through all available methods."), *WBPName);
	}
	UE_LOG(LogTemp, Error, TEXT("%s"), *OutErrorMessage); // Log the final error if not successful
}

void UKGMcpUtility::GetAllWidgets(UWidgetTree* WidgetTree, bool& OutSuccess, TArray<UWidget*>& OutWidgets, FString& OutErrorMessage)
{
	OutSuccess = false;
	OutWidgets.Empty();
	OutErrorMessage.Empty();

	if (!WidgetTree)
	{
		OutErrorMessage = TEXT("GetAllWidgets: WidgetTree is null.");
		UE_LOG(LogTemp, Warning, TEXT("%s"), *OutErrorMessage);
		return;
	}

	UE_LOG(LogTemp, Log, TEXT("GetAllWidgets: Starting to collect all widgets from WidgetTree."));

	// Use UWidgetTree's built-in GetAllWidgets method - this is the most reliable way
	WidgetTree->GetAllWidgets(OutWidgets);

	if (OutWidgets.Num() > 0)
	{
		OutSuccess = true;
		UE_LOG(LogTemp, Log, TEXT("GetAllWidgets: Successfully collected %d widgets from WidgetTree."), OutWidgets.Num());
	}
	else
	{
		// This is not necessarily an error - the widget tree might just be empty
		OutSuccess = true; // Consider empty tree as success but log for debugging
		UE_LOG(LogTemp, Log, TEXT("GetAllWidgets: WidgetTree contains no widgets (empty tree)."));
	}
}

void UKGMcpUtility::GetWidgetIsVariable(UWidget* Widget, bool& OutSuccess, bool& OutIsVariable, FString& OutErrorMessage)
{
	OutSuccess = false;
	OutIsVariable = false;
	OutErrorMessage.Empty();

	if (!Widget)
	{
		OutErrorMessage = TEXT("GetWidgetIsVariable: Widget is null.");
		UE_LOG(LogTemp, Warning, TEXT("%s"), *OutErrorMessage);
		return;
	}

	// UWidget has a bIsVariable property that we can access directly
	OutIsVariable = Widget->bIsVariable;
	OutSuccess = true;
	UE_LOG(LogTemp, VeryVerbose, TEXT("GetWidgetIsVariable: Successfully retrieved bIsVariable=%s for widget '%s'."),
		OutIsVariable ? TEXT("true") : TEXT("false"), *Widget->GetName());
}

void UKGMcpUtility::GetWidgetIsProgrammerControlled(UWidget* Widget, bool& OutSuccess, bool& OutIsProgrammerControlled, FString& OutErrorMessage)
{
	OutSuccess = false;
	OutIsProgrammerControlled = false;
	OutErrorMessage.Empty();

	if (!Widget)
	{
		OutErrorMessage = TEXT("GetWidgetIsProgrammerControlled: Widget is null.");
		UE_LOG(LogTemp, Warning, TEXT("%s"), *OutErrorMessage);
		return;
	}

	// Direct access to CodeRefFlag property
	// ECodeRefFlag enum values: NoRef = 0, BlueprintRef = 1, CodeRef = 2
	uint8 CodeRefFlagValue = Widget->CodeRefFlag;
	const uint8 CodeRef = 2;

	// Check if CodeRef flag is set (value = 2)
	OutIsProgrammerControlled = (CodeRefFlagValue & CodeRef) == CodeRef;
	OutSuccess = true;

	UE_LOG(LogTemp, VeryVerbose, TEXT("GetWidgetIsProgrammerControlled: Successfully retrieved CodeRefFlag=%d (IsProgrammerControlled=%s) for widget '%s'."),
		CodeRefFlagValue, OutIsProgrammerControlled ? TEXT("true") : TEXT("false"), *Widget->GetName());
}

void UKGMcpUtility::GetAllBlueprintFunctions(UWidgetBlueprint* WidgetBlueprint, bool& OutSuccess, TArray<UFunction*>& OutFunctions, FString& OutErrorMessage)
{
	OutSuccess = false;
	OutFunctions.Empty();
	OutErrorMessage.Empty();

	if (!WidgetBlueprint)
	{
		OutErrorMessage = TEXT("WidgetBlueprint is null.");
		UE_LOG(LogTemp, Warning, TEXT("%s"), *OutErrorMessage);
		return;
	}

	UClass* GeneratedClass = WidgetBlueprint->GeneratedClass;
	if (!GeneratedClass)
	{
		OutErrorMessage = TEXT("GeneratedClass is null.");
		UE_LOG(LogTemp, Warning, TEXT("%s"), *OutErrorMessage);
		return;
	}

	for (TFieldIterator<UFunction> FuncIt(GeneratedClass, EFieldIteratorFlags::IncludeSuper); FuncIt; ++FuncIt)
	{
		UFunction* Function = *FuncIt;
		if (Function->HasAllFunctionFlags(FUNC_BlueprintCallable | FUNC_BlueprintEvent))
		{
			OutFunctions.Add(Function);
		}
	}

	OutSuccess = true;
	UE_LOG(LogTemp, Log, TEXT("Successfully retrieved blueprint functions."));
}

void UKGMcpUtility::GetDefaultCategoryBlueprintVariables(UWidgetBlueprint* WidgetBlueprint, bool& OutSuccess, TArray<FString>& OutVariables, FString& OutErrorMessage)
{
	OutSuccess = false;
	OutVariables.Empty();
	OutErrorMessage.Empty();

	if (!WidgetBlueprint)
	{
		OutErrorMessage = TEXT("WidgetBlueprint is null.");
		UE_LOG(LogTemp, Warning, TEXT("%s"), *OutErrorMessage);
		return;
	}

	UClass* GeneratedClass = WidgetBlueprint->GeneratedClass;
	if (!GeneratedClass)
	{
		OutErrorMessage = TEXT("GeneratedClass is null.");
		UE_LOG(LogTemp, Warning, TEXT("%s"), *OutErrorMessage);
		return;
	}

	for (TFieldIterator<FProperty> PropIt(GeneratedClass, EFieldIteratorFlags::IncludeSuper); PropIt; ++PropIt)
	{
		FProperty* Property = *PropIt;
		if (Property->HasAnyPropertyFlags(CPF_BlueprintVisible) && Property->GetMetaData(TEXT("Category")) == TEXT("Default"))
		{
			OutVariables.Add(Property->GetName());
		}
	}

	OutSuccess = true;
	UE_LOG(LogTemp, Log, TEXT("Successfully retrieved Default category blueprint variables."));
}

void UKGMcpUtility::GetAnimationCategoryBlueprintVariables(UWidgetBlueprint* WidgetBlueprint, bool& OutSuccess, TArray<FString>& OutVariables, FString& OutErrorMessage)
{
	OutSuccess = false;
	OutVariables.Empty();
	OutErrorMessage.Empty();

	if (!WidgetBlueprint)
	{
		OutErrorMessage = TEXT("WidgetBlueprint is null.");
		UE_LOG(LogTemp, Warning, TEXT("%s"), *OutErrorMessage);
		return;
	}

	UClass* GeneratedClass = WidgetBlueprint->GeneratedClass;
	if (!GeneratedClass)
	{
		OutErrorMessage = TEXT("GeneratedClass is null.");
		UE_LOG(LogTemp, Warning, TEXT("%s"), *OutErrorMessage);
		return;
	}

	for (TFieldIterator<FProperty> PropIt(GeneratedClass, EFieldIteratorFlags::IncludeSuper); PropIt; ++PropIt)
	{
		FProperty* Property = *PropIt;
		if (Property->HasAnyPropertyFlags(CPF_BlueprintVisible) && Property->GetMetaData(TEXT("Category")) == TEXT("Animations"))
		{
			OutVariables.Add(Property->GetName());
		}
	}

	OutSuccess = true;
	UE_LOG(LogTemp, Log, TEXT("Successfully retrieved Animation category blueprint variables."));
}

// ==============================
// Lua Testing Utility APIs Implementation
// ==============================

void UKGMcpUtility::ExecuteLuaCodeInCommandlet(const FString& LuaCode, bool& OutSuccess, FString& OutOutput, FString& OutErrorMessage)
{
	OutSuccess = false;
	OutOutput.Empty();
	OutErrorMessage.Empty();

	if (LuaCode.IsEmpty())
	{
		OutErrorMessage = TEXT("ExecuteLuaCodeInCommandlet: Lua code is empty.");
		UE_LOG(LogTemp, Warning, TEXT("%s"), *OutErrorMessage);
		return;
	}

	UE_LOG(LogTemp, Log, TEXT("ExecuteLuaCodeInCommandlet: Attempting to execute Lua code via UKGLuaTestCommandlet (length: %d characters)."), LuaCode.Len());

	// 创建临时的Lua文件来存储要执行的代码
	FString TempLuaFilePath, TempLuaRelativeFilePath;
	FString TempFileContent = LuaCode;
	
	// 生成临时文件路径
	FString TempDir = FPaths::ProjectIntermediateDir() / TEXT("KGMcpTemp");
	FString TempFileName = FString::Printf(TEXT("TempLuaCode_%d.lua"), FMath::Rand());
	TempLuaFilePath = TempDir / TempFileName;
	
	// 确保临时目录存在
	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	if (!PlatformFile.DirectoryExists(*TempDir))
	{
		if (!PlatformFile.CreateDirectoryTree(*TempDir))
		{
			OutErrorMessage = FString::Printf(TEXT("ExecuteLuaCodeInCommandlet: Failed to create temporary directory: %s"), *TempDir);
			UE_LOG(LogTemp, Error, TEXT("%s"), *OutErrorMessage);
			return;
		}
	}

	// 写入临时Lua文件
	if (!FFileHelper::SaveStringToFile(TempFileContent, *TempLuaFilePath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM))
	{
		OutErrorMessage = FString::Printf(TEXT("ExecuteLuaCodeInCommandlet: Failed to write temporary Lua file: %s"), *TempLuaFilePath);
		UE_LOG(LogTemp, Error, TEXT("%s"), *OutErrorMessage);
		return;
	}

	TempLuaRelativeFilePath = TempLuaFilePath;
	FPaths::MakePathRelativeTo(TempLuaRelativeFilePath, *FPaths::ProjectDir());
	UE_LOG(LogTemp, Log, TEXT("ExecuteLuaCodeInCommandlet: Created temporary Lua file: %s, Run path: %s"), *TempLuaFilePath, *TempLuaRelativeFilePath);

	// 使用辅助方法执行Commandlet
	TArray<FString> LuaScriptPaths;
	LuaScriptPaths.Add(TempLuaRelativeFilePath);
	
	ExecuteCommandletWithLuaScripts(LuaScriptPaths, OutSuccess, OutOutput, OutErrorMessage);

	// 清理临时文件
	if (PlatformFile.FileExists(*TempLuaFilePath))
	{
		if (!PlatformFile.DeleteFile(*TempLuaFilePath))
		{
			UE_LOG(LogTemp, Warning, TEXT("ExecuteLuaCodeInCommandlet: Failed to delete temporary file: %s"), *TempLuaFilePath);
		}
		else
		{
			UE_LOG(LogTemp, VeryVerbose, TEXT("ExecuteLuaCodeInCommandlet: Cleaned up temporary file: %s"), *TempLuaFilePath);
		}
	}

	// 更新输出摘要以反映这是从代码字符串执行的
	if (!OutOutput.IsEmpty())
	{
		FStringBuilderBase UpdatedSummary;
		UpdatedSummary << OutOutput << TEXT("\n");
		UpdatedSummary << TEXT("=== Lua Code Execution Summary ===\n");
		UpdatedSummary << TEXT("Code Length: ") <<  LuaCode.Len() << TEXT(" characters\n");
		UpdatedSummary << TEXT("Temporary File: ") << TempLuaFilePath;
		OutOutput = UpdatedSummary.ToString();
	}
}

void UKGMcpUtility::ExecuteLuaFilesInCommandlet(const TArray<FString>& LuaFilePaths, bool& OutSuccess, FString& OutOutput, FString& OutErrorMessage)
{
	OutSuccess = false;
	OutOutput.Empty();
	OutErrorMessage.Empty();

	if (LuaFilePaths.Num() == 0)
	{
		OutErrorMessage = TEXT("ExecuteLuaFilesInCommandlet: No Lua file paths provided.");
		UE_LOG(LogTemp, Warning, TEXT("%s"), *OutErrorMessage);
		return;
	}

	UE_LOG(LogTemp, Log, TEXT("ExecuteLuaFilesInCommandlet: Attempting to execute %d Lua file(s) via UKGLuaTestCommandlet."), LuaFilePaths.Num());

	// 验证所有文件路径是否存在
	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	TArray<FString> ValidFilePaths;
	TArray<FString> MissingFiles;

	for (const FString& FilePath : LuaFilePaths)
	{
		if (PlatformFile.FileExists(*FilePath))
		{
			ValidFilePaths.Add(FilePath);
			UE_LOG(LogTemp, VeryVerbose, TEXT("ExecuteLuaFilesInCommandlet: Found Lua file: %s"), *FilePath);
		}
		else
		{
			MissingFiles.Add(FilePath);
			UE_LOG(LogTemp, Warning, TEXT("ExecuteLuaFilesInCommandlet: Missing Lua file: %s"), *FilePath);
		}
	}

	// 检查是否有有效的文件
	if (ValidFilePaths.Num() == 0)
	{
		OutErrorMessage = FString::Printf(TEXT("ExecuteLuaFilesInCommandlet: No valid Lua files found. Missing files: %s"), 
			*FString::Join(MissingFiles, TEXT(", ")));
		UE_LOG(LogTemp, Error, TEXT("%s"), *OutErrorMessage);
		return;
	}

	// 如果有缺失的文件，记录警告但继续执行
	if (MissingFiles.Num() > 0)
	{
		FString WarningMessage = FString::Printf(TEXT("ExecuteLuaFilesInCommandlet: %d file(s) missing, executing %d valid file(s). Missing: %s"), 
			MissingFiles.Num(), ValidFilePaths.Num(), *FString::Join(MissingFiles, TEXT(", ")));
		UE_LOG(LogTemp, Warning, TEXT("%s"), *WarningMessage);
	}

	// 使用辅助方法执行Commandlet
	ExecuteCommandletWithLuaScripts(ValidFilePaths, OutSuccess, OutOutput, OutErrorMessage);

	// 在输出中添加文件信息
	if (!OutOutput.IsEmpty())
	{
		FString UpdatedSummary = OutOutput;
		
		// 添加文件详细信息
		FString FileDetails = TEXT("=== File Details ===\n");
		FileDetails += FString::Printf(TEXT("Total Files Requested: %d\n"), LuaFilePaths.Num());
		FileDetails += FString::Printf(TEXT("Valid Files Executed: %d\n"), ValidFilePaths.Num());
		if (MissingFiles.Num() > 0)
		{
			FileDetails += FString::Printf(TEXT("Missing Files: %d\n"), MissingFiles.Num());
			FileDetails += FString::Printf(TEXT("Missing File Paths: %s\n"), *FString::Join(MissingFiles, TEXT(", ")));
		}
		FileDetails += TEXT("Valid File Paths:\n");
		for (int32 i = 0; i < ValidFilePaths.Num(); i++)
		{
			FileDetails += FString::Printf(TEXT("  %d. %s\n"), i + 1, *ValidFilePaths[i]);
		}
		FileDetails += TEXT("=== End of File Details ===\n\n");
		
		// 将文件详细信息插入到摘要之后
		int32 SummaryEndIndex = UpdatedSummary.Find(TEXT("=== End of Summary ===\n\n"));
		if (SummaryEndIndex != INDEX_NONE)
		{
			SummaryEndIndex += FString(TEXT("=== End of Summary ===\n\n")).Len();
			UpdatedSummary.InsertAt(SummaryEndIndex, FileDetails);
		}
		else
		{
			UpdatedSummary = FileDetails + UpdatedSummary;
		}
		
		OutOutput = UpdatedSummary;
	}
}

void UKGMcpUtility::CheckPieStatus(bool& OutSuccess, bool& OutIsPieActive, FString& OutErrorMessage)
{
	OutSuccess = false;
	OutIsPieActive = false;
	OutErrorMessage.Empty();

	UE_LOG(LogTemp, Log, TEXT("CheckPieStatus: Checking Play In Editor status."));

	// 检查GEditor是否可用
	if (!GEditor)
	{
		OutErrorMessage = TEXT("CheckPieStatus: GEditor is null. Cannot check PIE status.");
		UE_LOG(LogTemp, Warning, TEXT("%s"), *OutErrorMessage);
		return;
	}

	// 检查是否有活跃的PIE世界
	UWorld* PlayWorld = nullptr;
	
	// 方法1：检查GEditor的PlayWorld
	if (GEditor->PlayWorld)
	{
		PlayWorld = GEditor->PlayWorld;
		UE_LOG(LogTemp, VeryVerbose, TEXT("CheckPieStatus: Found PlayWorld via GEditor->PlayWorld."));
	}
	
	// 方法2：通过世界上下文查找PIE世界
	if (!PlayWorld)
	{
		for (const FWorldContext& WorldContext : GEngine->GetWorldContexts())
		{
			if (WorldContext.WorldType == EWorldType::PIE)
			{
				PlayWorld = WorldContext.World();
				UE_LOG(LogTemp, VeryVerbose, TEXT("CheckPieStatus: Found PIE world via world contexts."));
				break;
			}
		}
	}

	// 验证找到的世界是否有效且正在运行
	if (PlayWorld && IsValid(PlayWorld))
	{
		// 进一步检查世界是否真正在运行
		bool bWorldInitialized = PlayWorld->bIsWorldInitialized;
		bool bWorldBegunPlay = PlayWorld->GetBegunPlay();
		
		OutIsPieActive = bWorldInitialized && bWorldBegunPlay;
		OutSuccess = true;
		
		UE_LOG(LogTemp, Log, TEXT("CheckPieStatus: PIE status check completed. PIE Active: %s (WorldInitialized: %s, BegunPlay: %s)"),
			OutIsPieActive ? TEXT("true") : TEXT("false"),
			bWorldInitialized ? TEXT("true") : TEXT("false"),
			bWorldBegunPlay ? TEXT("true") : TEXT("false"));
	}
	else
	{
		// 没有找到有效的PIE世界
		OutIsPieActive = false;
		OutSuccess = true;
		
		UE_LOG(LogTemp, Log, TEXT("CheckPieStatus: No active PIE world found. PIE is not running."));
	}
}

void UKGMcpUtility::StartPie(bool& OutSuccess, FString& OutErrorMessage)
{
	OutSuccess = false;
	OutErrorMessage.Empty();

	// 检查GEditor是否可用
	if (!GEditor)
	{
		OutErrorMessage = TEXT("StartPie: GEditor is null. Cannot start PIE.");
		UE_LOG(LogTemp, Error, TEXT("%s"), *OutErrorMessage);
		return;
	}

	// 检查是否已经有PIE在运行
	bool bCurrentlyActive = false;
	FString CheckErrorMessage;
	CheckPieStatus(OutSuccess, bCurrentlyActive, CheckErrorMessage);
	
	if (bCurrentlyActive)
	{
		OutErrorMessage = TEXT("StartPie: PIE is already active. Cannot start another PIE session.");
		UE_LOG(LogTemp, Warning, TEXT("%s"), *OutErrorMessage);
		return;
	}
	FToolsLibrary::StartPIEFromLogin();
	OutSuccess = true;
	UE_LOG(LogTemp, Log, TEXT("StartPie: PIE start request sent successfully."));
}

void UKGMcpUtility::StopPie(bool& OutSuccess, FString& OutErrorMessage)
{
	OutSuccess = false;
	OutErrorMessage.Empty();

	// 检查GEditor是否可用
	if (!GEditor)
	{
		OutErrorMessage = TEXT("StopPie: GEditor is null. Cannot stop PIE.");
		UE_LOG(LogTemp, Error, TEXT("%s"), *OutErrorMessage);
		return;
	}

	// 检查PIE是否正在运行
	bool bCurrentlyActive = false;
	bool bCheckSuccess = false;
	FString CheckErrorMessage;
	CheckPieStatus(bCheckSuccess, bCurrentlyActive, CheckErrorMessage);
	
	if (!bCheckSuccess)
	{
		OutErrorMessage = FString::Printf(TEXT("StopPie: Failed to check PIE status: %s"), *CheckErrorMessage);
		UE_LOG(LogTemp, Warning, TEXT("%s"), *OutErrorMessage);
		return;
	}
	
	if (!bCurrentlyActive)
	{
		OutErrorMessage = TEXT("StopPie: PIE is not currently active. Cannot stop inactive PIE session.");
		UE_LOG(LogTemp, Warning, TEXT("%s"), *OutErrorMessage);
		return;
	}

	// 尝试停止PIE
	UE_LOG(LogTemp, Log, TEXT("StopPie: Attempting to stop PIE session."));
	
	// 使用UE5的标准方法停止PIE
	GEditor->RequestEndPlayMap();
	
	OutSuccess = true;
	UE_LOG(LogTemp, Log, TEXT("StopPie: PIE stop request sent successfully."));
}

void UKGMcpUtility::ReloadLua(bool& OutSuccess, FString& OutErrorMessage)
{
	OutSuccess = false;
	OutErrorMessage.Empty();

	UE_LOG(LogTemp, Log, TEXT("ReloadLua: Attempting to reload Lua scripting system."));
	// 检查PIE状态，确保在合适的时机进行重载
	bool bCheckSuccess = false;
	bool bPieActive = false;
	FString CheckErrorMessage;
	CheckPieStatus(bCheckSuccess, bPieActive, CheckErrorMessage);

	if (bCheckSuccess)
	{
		UUnrealEdEngine* engine = Cast<UUnrealEdEngine>(GEngine);
		if (engine && engine->PlayWorld)
		{
			auto gameInstance = engine->PlayWorld->GetGameInstance();
			NS_SLUA::LuaState* ls = NS_SLUA::LuaState::get(gameInstance);
			ls->call("ReloadAllLua");
		}
		OutSuccess = true;
		UE_LOG(LogTemp, Log, TEXT("ReloadLua: PIE status check successful. PIE Active: %s"), bPieActive ? TEXT("true") : TEXT("false"));
	}
	else
	{
		OutSuccess = false;
		OutErrorMessage = FString::Printf(TEXT("Could not verify PIE status: %s"), *CheckErrorMessage);
		UE_LOG(LogTemp, Warning, TEXT("ReloadLua: %s"), *OutErrorMessage);
	}
}

// ==============================
// Private Helper Methods Implementation
// ==============================

void UKGMcpUtility::ExecuteCommandletWithLuaScripts(const TArray<FString>& LuaScriptPaths, bool& OutSuccess, FString& OutOutput, FString& OutErrorMessage)
{
	OutSuccess = false;
	OutOutput.Empty();
	OutErrorMessage.Empty();

	if (LuaScriptPaths.Num() == 0)
	{
		OutErrorMessage = TEXT("ExecuteCommandletWithLuaScripts: No Lua script paths provided.");
		UE_LOG(LogTemp, Warning, TEXT("%s"), *OutErrorMessage);
		return;
	}

	UE_LOG(LogTemp, Log, TEXT("ExecuteCommandletWithLuaScripts: Attempting to execute %d Lua script(s) via UKGLuaTestCommandlet."), LuaScriptPaths.Num());

	// 创建KGLuaTestCommandlet实例并执行
	UKGLuaTestCommandlet* Commandlet = NewObject<UKGLuaTestCommandlet>();
	if (!Commandlet)
	{
		OutErrorMessage = TEXT("ExecuteCommandletWithLuaScripts: Failed to create UKGLuaTestCommandlet instance.");
		UE_LOG(LogTemp, Error, TEXT("%s"), *OutErrorMessage);
		return;
	}

	// 使用GC保护确保Commandlet不会被垃圾回收
	FGCObjectScopeGuard CommandletScopeGuard(Commandlet);

	// 构建Commandlet参数，指定要执行的Lua脚本
	FString LuaScriptsParam = FString::Join(LuaScriptPaths, TEXT(";"));
	FString CommandletParams = FString::Printf(TEXT("-LuaScript=\"%s\" -LogLevel=verbose"), *LuaScriptsParam);

	UE_LOG(LogTemp, Log, TEXT("ExecuteCommandletWithLuaScripts: Executing commandlet with params: %s"), *CommandletParams);

	// 捕获日志输出
	class FScopedLogCapture
	{
	private:
		class FLogOutputDevice : public FOutputDevice
		{
		public:
			FString CapturedOutput;
			
			virtual void Serialize(const TCHAR* V, ELogVerbosity::Type Verbosity, const class FName& Category) override
			{
				// 格式化日志消息
				FString LogLevelStr;
				switch (Verbosity)
				{
					case ELogVerbosity::Fatal:     LogLevelStr = TEXT("Fatal"); break;
					case ELogVerbosity::Error:     LogLevelStr = TEXT("Error"); break;
					// BEGIN ADD BY liubo11@kuaishou.com: release log enum
					case ELogVerbosity::ReleaseLog:LogLevelStr = TEXT("ReleaseLog"); break;
					// END ADD BY liubo11@kuaishou.com
					case ELogVerbosity::Warning:   LogLevelStr = TEXT("Warning"); break;
					case ELogVerbosity::Display:   LogLevelStr = TEXT("Display"); break;
					case ELogVerbosity::Log:       LogLevelStr = TEXT("Log"); break;
					case ELogVerbosity::Verbose:   LogLevelStr = TEXT("Verbose"); break;
					case ELogVerbosity::VeryVerbose: LogLevelStr = TEXT("VeryVerbose"); break;
					default: LogLevelStr = TEXT("Unknown"); break;
				}
				
				// 将日志消息附加到捕获的输出中
				CapturedOutput += FString::Printf(TEXT("[%s][%s]: %s\n"), *Category.ToString(), *LogLevelStr, V);
			}
		};
		
		FLogOutputDevice LogDevice;
		
	public:
		FScopedLogCapture()
		{
			if (GLog)
			{
				GLog->AddOutputDevice(&LogDevice);
			}
		}
		
		~FScopedLogCapture()
		{
			if (GLog)
			{
				GLog->RemoveOutputDevice(&LogDevice);
			}
		}
		
		FString GetCapturedLogs() const
		{
			return LogDevice.CapturedOutput;
		}
	};

	// 开始日志捕获并执行Commandlet
	FScopedLogCapture LogCapture;
	int32 CommandletExitCode = Commandlet->Main(CommandletParams);

	// 获取捕获的日志
	FString CapturedLogs = LogCapture.GetCapturedLogs();

	// 处理执行结果
	if (CommandletExitCode == 0)
	{
		OutSuccess = true;
		OutOutput = CapturedLogs;
		UE_LOG(LogTemp, Log, TEXT("ExecuteCommandletWithLuaScripts: Commandlet execution completed successfully (exit code: %d)."), CommandletExitCode);
	}
	else
	{
		OutSuccess = false;
		OutErrorMessage = FString::Printf(TEXT("Commandlet execution failed with exit code: %d"), CommandletExitCode);
		OutOutput = CapturedLogs; // 即使失败也提供日志输出
		UE_LOG(LogTemp, Warning, TEXT("ExecuteCommandletWithLuaScripts: %s"), *OutErrorMessage);
	}

	// 在输出中添加执行摘要
	FString ExecutionSummary = FString::Printf(TEXT("=== Lua Scripts Execution Summary ===\n"));
	ExecutionSummary += FString::Printf(TEXT("Scripts Count: %d\n"), LuaScriptPaths.Num());
	ExecutionSummary += FString::Printf(TEXT("Success: %s\n"), OutSuccess ? TEXT("true") : TEXT("false"));
	ExecutionSummary += FString::Printf(TEXT("Exit Code: %d\n"), CommandletExitCode);
	ExecutionSummary += FString::Printf(TEXT("Scripts: %s\n"), *LuaScriptsParam);
	ExecutionSummary += TEXT("=== End of Summary ===\n\n");
	
	OutOutput = ExecutionSummary + OutOutput;

	// === 新增：分析测试结果，确定真正的成功状态 ===
	if (OutSuccess && CommandletExitCode == 0)
	{
		// 通过分析输出内容来确定是否真正成功
		bool bHasFailedTestCases = false;
		bool bHasExecutedTestCases = false;
		
		// 在日志中查找失败用例数和执行用例数的信息
		if (CapturedLogs.Contains(TEXT("失败用例数:")))
		{
			// 提取失败用例数
			FString SearchPattern = TEXT("失败用例数:");
			int32 FailedCasesIndex = CapturedLogs.Find(SearchPattern);
			if (FailedCasesIndex != INDEX_NONE)
			{
				int32 NumberStart = FailedCasesIndex + SearchPattern.Len();
				int32 NumberEnd = CapturedLogs.Find(TEXT("\n"), ESearchCase::IgnoreCase, ESearchDir::FromStart, NumberStart);
				if (NumberEnd == INDEX_NONE) NumberEnd = CapturedLogs.Len();
				
				FString FailedCountStr = CapturedLogs.Mid(NumberStart, NumberEnd - NumberStart).TrimStartAndEnd();
				int32 FailedCount = FCString::Atoi(*FailedCountStr);
				bHasFailedTestCases = (FailedCount > 0);
			}
		}
		
		if (CapturedLogs.Contains(TEXT("已执行用例数:")))
		{
			// 提取执行用例数
			FString SearchPattern = TEXT("已执行用例数:");
			int32 ExecutedCasesIndex = CapturedLogs.Find(SearchPattern);
			if (ExecutedCasesIndex != INDEX_NONE)
			{
				int32 NumberStart = ExecutedCasesIndex + SearchPattern.Len();
				int32 NumberEnd = CapturedLogs.Find(TEXT("\n"), ESearchCase::IgnoreCase, ESearchDir::FromStart, NumberStart);
				if (NumberEnd == INDEX_NONE) NumberEnd = CapturedLogs.Len();
				
				FString ExecutedCountStr = CapturedLogs.Mid(NumberStart, NumberEnd - NumberStart).TrimStartAndEnd();
				int32 ExecutedCount = FCString::Atoi(*ExecutedCountStr);
				bHasExecutedTestCases = (ExecutedCount > 0);
			}
		}
		
		// 根据测试用例执行结果确定最终成功状态
		// 只有当有执行的测试用例且没有失败的测试用例时才算成功
		OutSuccess = bHasExecutedTestCases && !bHasFailedTestCases;
		
		if (!OutSuccess && CommandletExitCode == 0)
		{
			if (!bHasExecutedTestCases)
			{
				OutErrorMessage = TEXT("测试执行完成但没有执行任何测试用例");
			}
			else if (bHasFailedTestCases)
			{
				OutErrorMessage = TEXT("测试执行完成但有失败的测试用例");
			}
		}
	}
}
