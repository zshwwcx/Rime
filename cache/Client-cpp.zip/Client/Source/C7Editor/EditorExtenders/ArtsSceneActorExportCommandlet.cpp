// Copyright KuaiShou Games, Inc. All Rights Reserved.

#include "ArtsSceneActorExportCommandlet.h"

#include "EditorWorldUtils.h"
#include "Engine/ObjectLibrary.h"
#include "FileAsset/GPEditorAssetHelper.h"
#include "ISourceControlModule.h"
#include "ISourceControlProvider.h"
#include "ReferenceCluster.h"
#include "StaticMeshCompiler.h"
#include "WorldPartition/WorldPartition.h"
#include "WorldPartition/WorldPartitionBuilder.h"
#include "WorldPartition/WorldPartitionEditorLoaderAdapter.h"
#include "WorldPartition/WorldPartitionHelpers.h"
#include "WorldPartition/WorldPartitionRuntimeSpatialHash.h"
#include "WorldPersistentFolders.h"

DEFINE_LOG_CATEGORY(LogArtsSceneActorExportCommandlet);

// NOTICE: Commandlet返回0外部也会得到1，其余值正常，所以从第二位开始使用
int FLAG_ARTS_SCENE_ACTOR_FAILED = 2;

int32 UArtsSceneActorExportCommandlet::Main(const FString& InCommandline)
{
    UE_LOG(LogArtsSceneActorExportCommandlet, Display, TEXT("commandlet start."));

    ParseCommandLine(*InCommandline, Tokens, Switches, Params);
    
    int Succ = 0;
    int Result = 0;
    TArray<FString> MapPacakges;
    if (Params.Contains("ArtsTemplate"))
    {
        if (GEditor->GetEditorWorldContext().World())
        {
            const FString ConfigKey = Params["ArtsTemplate"];
            if (ConfigKey.IsEmpty())
            {
                UE_LOG(LogArtsSceneActorExportCommandlet, Warning, TEXT("Has empty config key."));
                return FLAG_ARTS_SCENE_ACTOR_FAILED;
            }
            GPEditorAssetHelper::ExportTemplateDataByConfigKey(ConfigKey);
            UE_LOG(LogArtsSceneActorExportCommandlet, Display, TEXT("commandlet finish, exported arts template"));
            return Result;
        }
        else
        {
            UE_LOG(LogArtsSceneActorExportCommandlet, Warning, TEXT("Export ArtsTemplate can not found world "));
            return FLAG_ARTS_SCENE_ACTOR_FAILED;
        }
    }
    else if (Params.Contains("MapName"))
    {
        const FString MapName = Params["MapName"];
        if (MapName.IsEmpty())
        {
            UE_LOG(LogArtsSceneActorExportCommandlet, Warning, TEXT("Has empty mapname."));
            return FLAG_ARTS_SCENE_ACTOR_FAILED;
        }

        auto ObjectLibrary = UObjectLibrary::CreateLibrary(UWorld::StaticClass(), false, true);
        ObjectLibrary->LoadAssetDataFromPath(TEXT("/Game/Arts/Maps"));
        TArray<FString> MapFiles;
        FString SubPath = TEXT("Arts/Maps");
        FString FullPath = FPaths::Combine(FPaths::ProjectContentDir(), SubPath);
        IFileManager::Get().FindFilesRecursive(MapFiles, *FullPath, TEXT("*.umap"), true, false, false);
        TMap<FString, TSet<FString>> AllMaps;
        for (int32 i = 0; i < MapFiles.Num(); i++)
        {
            int32 lastSlashIndex = -1;
            FString FullMapFile = MapFiles[i];
            if (FullMapFile.FindLastChar('/', lastSlashIndex))
            {
                FString pureMapName;

                // length - 5 because of the ".umap" suffix
                for (int32 j = lastSlashIndex + 1; j < FullMapFile.Len() - 5; j++)
                {
                    pureMapName.AppendChar(FullMapFile[j]);
                }
                int32 mapsIndex = -1;
                mapsIndex = FullMapFile.Find(SubPath);
                FString pureMapPath;
                for (int32 j = mapsIndex + SubPath.Len() + 1; j < FullMapFile.Len() - 5; j++)
                {
                    pureMapPath.AppendChar(FullMapFile[j]);
                }
                AllMaps.FindOrAdd(pureMapName).Add(pureMapPath);
            }
        }

        if (!AllMaps.Contains(MapName))
        {
            UE_LOG(LogArtsSceneActorExportCommandlet, Warning, TEXT("MapName[%s] not found!!!"), *MapName);
            return FLAG_ARTS_SCENE_ACTOR_FAILED;
        }

        int Total = AllMaps.Find(MapName)->Num();
        UE_LOG(LogArtsSceneActorExportCommandlet, Display, TEXT("MapName[%s] found [%d] numbers!!!"), *MapName, Total);

        for (FString& FullName : *AllMaps.Find(MapName))
        {
            FString LevelAssetPath = FPaths::Combine(TEXT("/Game/Arts/Maps/"), FullName);
            UE_LOG(LogArtsSceneActorExportCommandlet, Display, TEXT("The Map's full path is [%s] "), *LevelAssetPath);

            MapPacakges.Add(LevelAssetPath);
        }
    }
    else if (Params.Contains("MapPackage"))
    {
        MapPacakges.Add(Params["MapPackage"]);
    }
    else
    {
        UE_LOG(LogArtsSceneActorExportCommandlet, Error, TEXT("Not found -MapName or -MapPacakge."));
        return FLAG_ARTS_SCENE_ACTOR_FAILED;
    }
    
    for (const FString& MapPackage : MapPacakges)
    {
        UE_LOG(LogArtsSceneActorExportCommandlet, Display, TEXT("Export Arts Scene Actor build begin - Map : [%s] "), *MapPackage);

        // 跳过不需要导出的地图
        if (!GPEditorAssetHelper::IsWorldNeedLoadForFurtherExport(MapPackage))
        {
            UE_LOG(LogArtsSceneActorExportCommandlet, Display, TEXT("Export Arts Scene Actor MAP[%s] LevelAssetPath will not export, skip load"), *MapPackage);
            continue;
        }
        
        UWorld* World = LoadWorld(MapPackage);
        if (World == nullptr)
        {
            UE_LOG(LogArtsSceneActorExportCommandlet, Warning, TEXT("MAP[%s] LevelAssetPath load Failed!!!"), *MapPackage);
            Result |= FLAG_ARTS_SCENE_ACTOR_FAILED;
            continue;
        }

        UWorld::InitializationValues IVS;
        {
            IVS.RequiresHitProxies(false);
            IVS.ShouldSimulatePhysics(false);
            IVS.EnableTraceCollision(false);
            IVS.CreateNavigation(false);
            IVS.CreateAISystem(false);
            IVS.AllowAudioPlayback(false);
            IVS.CreatePhysicsScene(true);
        }

        TUniquePtr<FScopedEditorWorld> EditorSourceWorld;
        if (World->bIsWorldInitialized == false)
        {
            EditorSourceWorld = MakeUnique<FScopedEditorWorld>(World, IVS);
        }
        
        TArray<FWorldPartitionReference> ActorReferences;
        if (UWorldPartition* WorldPartition = World->GetWorldPartition())
        {
            if (WorldPartition->GetActorDescContainerCount() > 1)
            {
                UE_LOG(LogArtsSceneActorExportCommandlet, Error, TEXT("Unsupported on WorldPartition using more than 1 ExternalActor Folder of World."));
                return FLAG_ARTS_SCENE_ACTOR_FAILED;
            }

            TArray<TPair<FGuid, TArray<FGuid>>> ActorsWithRefs;
            for (FActorDescContainerInstanceCollection::TIterator<> Iterator(WorldPartition); Iterator; ++Iterator)
            {
                ActorsWithRefs.Emplace(Iterator->GetGuid(), Iterator->GetReferences());
            }

            TArray<TArray<FGuid>> ActorClusters = GenerateObjectsClusters(ActorsWithRefs);

            for (const TArray<FGuid>& ActorCluster : ActorClusters)
            {
                for (const FGuid& ActorGuid : ActorCluster)
                {
                    FWorldPartitionReference ActorReference(WorldPartition, ActorGuid);
                    if (ActorReference.IsValid() == false)
                        continue;

                    AActor* Actor = ActorReference.GetActor();
                    if (Actor == nullptr)
                        continue;

                    ActorReferences.Add(ActorReference);
                }
            }
        }
        
        // Make sure static meshes have compiled before generating navigation data
        FStaticMeshCompilingManager::Get().FinishAllCompilation();
        FWorldPartitionHelpers::FakeEngineTick(World);

        // 如果p4没连接的话，需要重新连接一下
        ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
        if (TEXT("Perforce") != SourceControlProvider.GetName())
        {
            ISourceControlModule::Get().SetProvider(TEXT("Perforce"));
        }

        bAutoCheckOut = false;
        
        if (GPEditorAssetHelper::ExportSceneActorDataNew())
        {
            Succ++;
        }
        else
        {
            // 这里失败的话，前面已经打印了原因，直接返回
            return FLAG_ARTS_SCENE_ACTOR_FAILED;
        }


        CollectGarbage(RF_NoFlags);

        UE_LOG(LogArtsSceneActorExportCommandlet, Display, TEXT("Export Arts Scene Actor build end - Map : [%s] "), *MapPackage);
    }

    UE_LOG(LogArtsSceneActorExportCommandlet, Display, TEXT("commandlet finish, total[%d], success[%d], result[%d]"), MapPacakges.Num(), Succ, Result);
    return Result;
}

UWorld* UArtsSceneActorExportCommandlet::LoadWorld(const FString& InWorldPackageName)
{
    // This will convert incomplete package name to a fully qualified path
    FString WorldLongPackageName;
    FString WorldFilename;
    if (!FPackageName::SearchForPackageOnDisk(InWorldPackageName, &WorldLongPackageName, &WorldFilename))
    {
        UE_LOG(LogArtsSceneActorExportCommandlet, Error, TEXT("Package '%s' not found"), *InWorldPackageName);
        return nullptr;
    }

    // Load the world package
    UPackage* WorldPackage = LoadWorldPackageForEditor(WorldLongPackageName);
    if (!WorldPackage)
    {
        UE_LOG(LogArtsSceneActorExportCommandlet, Error, TEXT("Couldn't load package %s."), *WorldLongPackageName);
        return nullptr;
    }

    // Find the world in the given package
    UWorld* World = UWorld::FindWorldInPackage(WorldPackage);
    if (!World)
    {
        UE_LOG(LogArtsSceneActorExportCommandlet, Error, TEXT("No world in specified package %s."), *WorldLongPackageName);
        return nullptr;
    }

    // Load configuration file
    FString WorldConfigFilename = FPackageName::LongPackageNameToFilename(World->GetPackage()->GetName(), TEXT(".ini"));
    if (FPlatformFileManager::Get().GetPlatformFile().FileExists(*WorldConfigFilename))
    {
        LoadConfig(GetClass(), *WorldConfigFilename);
    }

    return World;
}