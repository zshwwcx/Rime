// Copyright KuaiShou Games, Inc. All Rights Reserved.

#pragma once

#include "Commandlets/Commandlet.h"
#include "Commandlets/ResavePackagesCommandlet.h"
#include "CoreMinimal.h"

#include "C7NavmeshAndVoxBuildCommandlet.generated.h"

struct FKConvexElem;
DECLARE_LOG_CATEGORY_EXTERN(LogC7NavmeshAndVoxBuildCommandlet, All, All);

class FPackageSourceControlHelper;

/*
./Engine/Binaries/Win64/UnrealEditor.exe "../../../Client/C7.uproject" -Run=C7NavmeshAndVoxBuildCommandlet -MapName=LV_Tiengen_P -AllowPartitionedBuild
./Engine/Binaries/Win64/UnrealEditor.exe "../../../Client/C7.uproject" -Run=C7NavmeshAndVoxBuildCommandlet -MapName=LV_Tiengen_P -AllowPartitionedBuild -OnlyClient
./Engine/Binaries/Win64/UnrealEditor.exe "../../../Client/C7.uproject" -Run=C7NavmeshAndVoxBuildCommandlet -MapPackage="/Game/Arts/Maps/Tiengen_New/LV_Tiengen_P.umap" -AllowPartitionedBuild -OnlyClient
./Engine/Binaries/Win64/UnrealEditor.exe "../../../Client/C7.uproject" -Run=C7NavmeshAndVoxBuildCommandlet -MapPackage="/Game/Caileyuan/PCG/PCGMap" -AllowPartitionedBuild -OnlyClient
./Engine/Binaries/Win64/UnrealEditor.exe "../../../Client/C7.uproject" -Run=C7NavmeshAndVoxBuildCommandlet -MapPackage="/Game/Arts/CookMaps/Desktop/Tiengen_New/LV_Tiengen_P.umap" -AllowPartitionedBuild -OnlyClient -AllowDynamicModify
*/
UCLASS()
class UC7NavmeshAndVoxBuildCommandlet : public UResavePackagesCommandlet
{
    GENERATED_BODY()

public:
    UC7NavmeshAndVoxBuildCommandlet(const FObjectInitializer& ObjectInitializer);

public:
    virtual int32 Main(const FString& InCommandline) override;

public:
    bool PreProcessClientNavmeshWC(UWorld* World, const FString& LevelAssetPath);

    bool ExportClientNavMesh(UWorld* World, const FString& LevelAssetPath);

    bool ExportClientNavMeshWP(UWorld* World, const FString& LevelAssetPath);

    bool ExportClientNavMeshDataChunks(UWorld* World, FPackageSourceControlHelper& PackageHelper);

    bool ExportClientNavMeshWC(UWorld* World, const FString& LevelAssetPath);

public:
    UWorld* LoadWorld(const FString& InWorldPackageName);
    void LoadDataLayers(UWorld* InWorld);

public:
    static bool SavePackages(const TArray<UPackage*>& Packages, FPackageSourceControlHelper& PackageHelper, bool bErrorsAsWarnings = false);
    static bool DeletePackages(const TArray<UPackage*>& Packages, FPackageSourceControlHelper& PackageHelper, bool bErrorsAsWarnings = false);
    static bool DeletePackages(const TArray<FString>& PackageNames, FPackageSourceControlHelper& PackageHelper, bool bErrorsAsWarnings = false);
    void PreExport(UWorld* World);
    static bool ConvexDecomposeStaticMeshToHulls(const UStaticMesh* InStaticMesh, TArray<FKConvexElem>& OutHulls, int32 LODIndex = 0, uint32 RequestedHullCount = 4, int32 MaxHullVerts = 16, uint32 Resolution = 100000);
    void PostExport(UWorld* World);

private:
    TArray<FString> Tokens;
    TArray<FString> Switches;
    TMap<FString, FString> Params;

    TArray<AStaticMeshActor*> NavModifierActors;
};