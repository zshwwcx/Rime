// Copyright KuaiShou Games, Inc. All Rights Reserved.

#pragma once

#include "Commandlets/Commandlet.h"
#include "Commandlets/ResavePackagesCommandlet.h"
#include "CoreMinimal.h"

#include "ArtsSceneActorExportCommandlet.generated.h"

DECLARE_LOG_CATEGORY_EXTERN(LogArtsSceneActorExportCommandlet, All, All);

class FPackageSourceControlHelper;

UCLASS()
class UArtsSceneActorExportCommandlet : public UResavePackagesCommandlet
{
    GENERATED_BODY()

public: 
    UArtsSceneActorExportCommandlet() {}

public:
    virtual int32 Main(const FString& InCommandline) override;

public:
    UWorld* LoadWorld(const FString& InWorldPackageName);

private:
    TArray<FString> Tokens;
    TMap<FString, FString> Params;
};