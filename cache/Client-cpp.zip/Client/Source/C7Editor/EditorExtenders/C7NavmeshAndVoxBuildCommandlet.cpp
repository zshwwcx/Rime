// Copyright KuaiShou Games, Inc. All Rights Reserved.

#include "C7NavmeshAndVoxBuildCommandlet.h"

#include "AI/Navigation/NavigationDataChunk.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "AssetToolsModule.h"
#include "ConvexDecompTool.h"
#include "EditorExtenders/ToolsLibrary.h"
#include "EditorWorldUtils.h"
#include "Engine/MapBuildDataRegistry.h"
#include "Engine/ObjectLibrary.h"
#include "EngineUtils.h"
#include "FileAsset/GPEditorAssetHelper.h"
#include "FileHelpers.h"
#include "ISourceControlModule.h"
#include "ISourceControlProvider.h"
#include "LevelEditorSubsystem.h"
#include "LevelInstance/LevelInstanceActor.h"
#include "NavAreas/NavArea_Null.h"
#include "NavModifierComponent.h"
#include "NavigationData.h"
#include "NavigationSystem.h"
#include "Navmesh/RecastNavMeshGenerator.h"
#include "PhysicsEngine/BodySetup.h"
#include "PhysicsEngine/ConvexElem.h"
#include "RecastApi.h"
#include "RecastVoxelNavMesh.h"
#include "ReferenceCluster.h"
#include "StaticMeshCompiler.h"
#include "UObject/SavePackage.h"
#include "WorldPartition/DataLayer/DataLayerManager.h"
#include "WorldPartition/LoaderAdapter/LoaderAdapterShape.h"
#include "WorldPartition/NavigationData/NavigationDataChunkActor.h"
#include "WorldPartition/WorldPartition.h"
#include "WorldPartition/WorldPartitionBuilder.h"
#include "WorldPartition/WorldPartitionCommonSourceControlHelper.h"
#include "WorldPartition/WorldPartitionEditorLoaderAdapter.h"
#include "WorldPartition/WorldPartitionHelpers.h"
#include "WorldPartition/WorldPartitionRuntimeSpatialHash.h"
#include "WorldPersistentFolders.h"

DEFINE_LOG_CATEGORY(LogC7NavmeshAndVoxBuildCommandlet);

// NOTICE: 使用非系统错误码的段
int FLAG_CLIENT_NAVMESH_FAILED = (1 << 16);
int FLAG_VOXEL_FAILED = (1 << 17);
int FLAG_SERVER_NAVMESH_FAILED = (1 << 18);

int RESULT_ALL_FAILED = FLAG_CLIENT_NAVMESH_FAILED + FLAG_VOXEL_FAILED + FLAG_SERVER_NAVMESH_FAILED;

// World Partition Navmesh Global Config
static FName WorldPartitionNavmeshGridName = TEXT("NavmeshGrid");
static int32 WorldPartitionNavmeshCellSize = 6400;
static int32 WorldPartitionNavmeshLoadingRange = 12800;
static int32 WorldPartitionNavmeshPriority = -1;

UC7NavmeshAndVoxBuildCommandlet::UC7NavmeshAndVoxBuildCommandlet(const FObjectInitializer& ObjectInitializer)
    : Super(ObjectInitializer)
{
    bAutoCheckOut = true;
}

int32 UC7NavmeshAndVoxBuildCommandlet::Main(const FString& InCommandline)
{
    UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("commandlet start."));

    bool BuildClient;
    bool BuildServer;
    ParseCommandLine(*InCommandline, Tokens, Switches, Params);

    if (Switches.Contains("OnlyClient"))
    {
        BuildClient = true;
        BuildServer = false;
    }
    else if (Switches.Contains("OnlyServer"))
    {
        BuildClient = false;
        BuildServer = true;
    }
    else
    {
        BuildClient = true;
        BuildServer = true;
    }

    TArray<FString> MapPacakges;
    if (Params.Contains("MapName"))
    {
        const FString MapName = Params["MapName"];
        if (MapName.IsEmpty())
        {
            UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Warning, TEXT("Has empty mapname."));
            return RESULT_ALL_FAILED;
        }

        auto ObjectLibrary = UObjectLibrary::CreateLibrary(UWorld::StaticClass(), false, true);
        ObjectLibrary->LoadAssetDataFromPath(TEXT("/Game/Arts/Maps"));
        TArray<FString> MapFiles;
        FString SubPath = TEXT("Arts/Maps");
        FString FullPath = FPaths::Combine(FPaths::ProjectContentDir(), SubPath);
        IFileManager::Get().FindFilesRecursive(MapFiles, *FullPath, TEXT("*.umap"), true, false, false);
        TMap<FString, TSet<FString>> AllMaps;
        for (int32 i = 0; i < MapFiles.Num(); i++)
        {
            int32 lastSlashIndex = -1;
            FString FullMapFile = MapFiles[i];
            if (FullMapFile.FindLastChar('/', lastSlashIndex))
            {
                FString pureMapName;

                // length - 5 because of the ".umap" suffix
                for (int32 j = lastSlashIndex + 1; j < FullMapFile.Len() - 5; j++)
                {
                    pureMapName.AppendChar(FullMapFile[j]);
                }
                int32 mapsIndex = -1;
                mapsIndex = FullMapFile.Find(SubPath);
                FString pureMapPath;
                for (int32 j = mapsIndex + SubPath.Len() + 1; j < FullMapFile.Len() - 5; j++)
                {
                    pureMapPath.AppendChar(FullMapFile[j]);
                }
                AllMaps.FindOrAdd(pureMapName).Add(pureMapPath);
            }
        }

        if (!AllMaps.Contains(MapName))
        {
            UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Warning, TEXT("MapName[%s] not found!!!"), *MapName);
            return RESULT_ALL_FAILED;
        }

        int Total = AllMaps.Find(MapName)->Num();
        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("MapName[%s] found [%d] numbers!!!"), *MapName, Total);

        for (FString& FullName : *AllMaps.Find(MapName))
        {
            FString LevelAssetPath = FPaths::Combine(TEXT("/Game/Arts/Maps/"), FullName);
            UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("The Map's full path is [%s] "), *LevelAssetPath);

            MapPacakges.Add(LevelAssetPath);
        }
    }
    else if (Params.Contains("MapPackage"))
    {
        MapPacakges.Add(Params["MapPackage"]);
    }
    else
    {
        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("Not found -MapName or -MapPacakge."));
        return RESULT_ALL_FAILED;
    }

    int Succ = 0;
    int Result = 0;
    for (const FString& MapPackage : MapPacakges)
    {
        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("Navmesh build begin - Map : [%s] "), *MapPackage);

        // Pre process and delete unused navmesh actor
        if (BuildClient)
        {
            UWorld* World = LoadWorld(MapPackage);
            if (World == nullptr)
            {
                UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Warning, TEXT("MAP[%s] LevelAssetPath load Failed!!!"), *MapPackage);
                Result |= RESULT_ALL_FAILED;
                continue;
            }

            if (World->IsPartitionedWorld() == false)
            {
                UWorld::InitializationValues IVS;
                {
                    IVS.RequiresHitProxies(false);
                    IVS.ShouldSimulatePhysics(false);
                    IVS.EnableTraceCollision(false);
                    IVS.CreateNavigation(true);
                    IVS.CreateAISystem(false);
                    IVS.AllowAudioPlayback(false);
                    IVS.CreatePhysicsScene(true);
                }

                TUniquePtr<FScopedEditorWorld> EditorSourceWorld;
                if (World->bIsWorldInitialized == false)
                {
                    EditorSourceWorld = MakeUnique<FScopedEditorWorld>(World, IVS);
                }

                if (PreProcessClientNavmeshWC(World, MapPackage) == false)
                {
                    UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("Pre process navmesh actor failed."));
                    Result |= FLAG_CLIENT_NAVMESH_FAILED;
                }
            }
        }

        CollectGarbage(RF_NoFlags);

        // Process and build navmesh
        {
            UWorld* World = LoadWorld(MapPackage);
            if (World == nullptr)
            {
                UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Warning, TEXT("MAP[%s] LevelAssetPath load Failed!!!"), *MapPackage);
                Result |= RESULT_ALL_FAILED;
                continue;
            }

            UWorld::InitializationValues IVS;
            {
                IVS.RequiresHitProxies(false);
                IVS.ShouldSimulatePhysics(false);
                IVS.EnableTraceCollision(false);
                IVS.CreateNavigation(true);
                IVS.CreateAISystem(false);
                IVS.AllowAudioPlayback(false);
                IVS.CreatePhysicsScene(true);
            }

            TUniquePtr<FScopedEditorWorld> EditorSourceWorld;
            if (World->bIsWorldInitialized == false)
            {
                EditorSourceWorld = MakeUnique<FScopedEditorWorld>(World, IVS);
            }

            TUniquePtr<FLoaderAdapterShape> LoaderAdapterShape;
            if (UWorldPartition* WorldPartition = World->GetWorldPartition())
            {
                LoadDataLayers(World);

                static const FBox BoxEntireWorld = FBox(FVector(-HALF_WORLD_MAX, -HALF_WORLD_MAX, -HALF_WORLD_MAX), FVector(HALF_WORLD_MAX, HALF_WORLD_MAX, HALF_WORLD_MAX));
                LoaderAdapterShape = MakeUnique<FLoaderAdapterShape>(World, BoxEntireWorld, TEXT("Loaded Region"));
                LoaderAdapterShape->Load();
            }

            FNavigationSystem::AddNavigationSystemToWorld(*World, FNavigationSystemRunMode::EditorWorldPartitionBuildMode);

            UNavigationSystemV1* NavSys = FNavigationSystem::GetCurrent<UNavigationSystemV1>(World);
            if (!NavSys)
            {
                UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Warning, TEXT("MAP[%s] NavigationSystem is null"), *MapPackage);
                Result |= RESULT_ALL_FAILED;
                continue;
            }

            // Make sure static meshes have compiled before generating navigation data
            FStaticMeshCompilingManager::Get().FinishAllCompilation();
            FWorldPartitionHelpers::FakeEngineTick(World);
            if (!NavSys->GetNavOctree())
            {
                UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Warning, TEXT("MAP[%s] GetNavOctree failed"), *MapPackage);
                Result |= RESULT_ALL_FAILED;
                continue;
            }

            if (Switches.Contains(TEXT("AllowPartitionedBuild")))
            {
                NavSys->SetBuildBounds(NavSys->GetNavigableWorldBounds());
            }

            // 如果p4没连接的话，需要重新连接一下
            ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
            if (TEXT("Perforce") != SourceControlProvider.GetName())
            {
                ISourceControlModule::Get().SetProvider(TEXT("Perforce"));
            }

            FPackageSourceControlHelper SCCHelper;
            {
                for (ANavigationData* NavData : NavSys->NavDataSet)
                {
                    if (ARecastNavMesh* RecastNavMesh = Cast<ARecastNavMesh>(NavData))
                    {
                        bool bNeedSave = false;
                        if (Switches.Contains(TEXT("AllowPartitionedBuild")))
                        {
                            if (RecastNavMesh->bIsWorldPartitioned == false)
                            {
                                RecastNavMesh->bIsWorldPartitioned = true;
                                bNeedSave = true;
                            }
                        }
                        else
                        {
                            if (RecastNavMesh->bIsWorldPartitioned == true)
                            {
                                RecastNavMesh->bIsWorldPartitioned = false;
                                bNeedSave = true;
                            }
                        }

                        ARecastVoxelNavMesh* RecasVoxelNavMesh = Cast<ARecastVoxelNavMesh>(NavData);
                        if (Switches.Contains(TEXT("AllowDynamicModify")) && RecasVoxelNavMesh == nullptr)
                        {
                            if (RecastNavMesh->GetRuntimeGenerationMode() != ERuntimeGenerationType::DynamicModifiersOnly)
                            {
                                RecastNavMesh->SetRuntimeGenerationMode(ERuntimeGenerationType::DynamicModifiersOnly);
                                bNeedSave = true;
                            }
                        }
                        else
                        {
                            if (RecastNavMesh->GetRuntimeGenerationMode() != ERuntimeGenerationType::Static)
                            {
                                RecastNavMesh->SetRuntimeGenerationMode(ERuntimeGenerationType::Static);
                                bNeedSave = true;
                            }
                        }

                        if (bNeedSave)
                        {
                            SavePackages({RecastNavMesh->GetPackage()}, SCCHelper);
                        }
                    }
                }

                PreExport(World);

                if (BuildClient)
                {
                    if (!ExportClientNavMesh(World, MapPackage))
                    {
                        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("Export client navmesh failed."));
                        Result |= FLAG_CLIENT_NAVMESH_FAILED;
                    }
                }
                if (BuildServer)
                {
                    if (!RecastExportVoxel())
                    {
                        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("Export server voxel failed."));
                        Result |= FLAG_VOXEL_FAILED;
                    }
                    if (!RecastExportNavmesh())
                    {
                        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("Export server navmesh failed."));
                        Result |= FLAG_SERVER_NAVMESH_FAILED;
                    }
                }
                if (BuildClient)
                {
                    if (ExportClientNavMeshDataChunks(World, SCCHelper) == false)
                    {
                        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("Export client navmesh data chunks failed."));
                        Result |= FLAG_CLIENT_NAVMESH_FAILED;
                    }
                }

                PostExport(World);

                UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("MAP[%s] export voxel and server navmesh succeed"), *MapPackage);

                LoaderAdapterShape.Reset();

                // Clean up early than world destroyed to avoid producing log by UCrowdManager::CreateCrowdManager
                NavSys->CleanUp(FNavigationSystem::ECleanupMode::CleanupWithWorld);
            }
        }

        Succ++;

        CollectGarbage(RF_NoFlags);

        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("Navmesh build end - Map : [%s] "), *MapPackage);
    }

    UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("commandlet finish, total[%d], success[%d], result[%d]"), MapPacakges.Num(), Succ, Result);
    return Result;
}

bool UC7NavmeshAndVoxBuildCommandlet::PreProcessClientNavmeshWC(UWorld* World, const FString& LevelAssetPath)
{
    FString WorldPackageName;
    if (!FPackageName::DoesPackageExist(World->GetOutermost()->GetName(), &WorldPackageName))
    {
        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("Map[%s] package is not existed: %s"), *LevelAssetPath, *World->GetOutermost()->GetName());
        return false;
    }
    UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("Map[%s] get WorldPackageName: %s"), *LevelAssetPath, *WorldPackageName);

    UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("------ Map[%s] pre process client navmesh begin."), *LevelAssetPath, *WorldPackageName);

    FString LeftStr;
    FString RightStr;
    WorldPackageName.Split("_P.umap", &LeftStr, &RightStr);
    FString NavmeshMapName = LeftStr + "_NavMesh";
    TArray<FString> ParseResults;
    NavmeshMapName.ParseIntoArray(ParseResults, TEXT("/"));
    NavmeshMapName = ParseResults.Last();

    for (ULevel* Level : World->GetLevels())
    {
        if (Level == nullptr)
        {
            continue;
        }

        UPackage* Package = Level->GetPackage();
        if (Package == nullptr)
        {
            continue;
        }

        FString PackageName = Package->GetName();
        PackageName.ParseIntoArray(ParseResults, TEXT("/"));
        FString MapName = ParseResults.Last();

        // Remove all RecastActor which not is navmesh map
        if (NavmeshMapName != MapName)
        {
            for (UNavigationDataChunk* NavDataChunk : Level->NavDataChunks)
            {
                if (NavDataChunk != nullptr)
                {
                    Level->MarkPackageDirty();
                    NavDataChunk->MarkAsGarbage();
                }
            }

            if (Level->NavDataChunks.IsEmpty() == false)
            {
                Level->MarkPackageDirty();
                Level->NavDataChunks.Empty();
                UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("------ SubLevel[%s] found NavDataChunks in level and delete it"), *PackageName);
            }

            for (AActor* Actor : Level->Actors)
            {
                if (Actor == nullptr)
                    continue;

                if (Actor->GetClass()->IsChildOf(ARecastNavMesh::StaticClass()) ||
                    Actor->GetClass()->IsChildOf(ARecastVoxelNavMesh::StaticClass()))
                {
                    UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("------ SubLevel[%s] found navmesh actor: %s."), *PackageName, *Actor->GetActorLabel());

                    if (Actor->GetPackage() &&
                        Actor->GetPackage() != GetTransientPackage())
                    {
                        Level->MarkPackageDirty();
                        World->DestroyActor(Actor);
                        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("------ SubLevel[%s] destroy navmesh actor: %s."), *PackageName, *Actor->GetPathName());
                    }
                }
            }

            if (Package->IsDirty())
            {
                if (!CheckoutFile(MapName))
                {
                    UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("------ SubLevel[%s] check out navmesh failed."), *PackageName);
                    return false;
                }

                TArray<FString> CheckedOutPackagesFilenames;
                CheckoutAndSavePackage(Package, CheckedOutPackagesFilenames, bSkipCheckedOutFiles);
                UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("------ SubLevel[%s] save level succeed."), *PackageName);
            }
        }
    }

    UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("------ Map[%s] pre process client navmesh end."), *LevelAssetPath);

    return true;
}

bool UC7NavmeshAndVoxBuildCommandlet::ExportClientNavMesh(UWorld* World, const FString& LevelAssetPath)
{
    FNavigationSystem::Build(*World);
    UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("MAP[%s] build client navmesh succeed"), *LevelAssetPath);

    if (World->IsPartitionedWorld())
    {
        return ExportClientNavMeshWP(World, LevelAssetPath);
    }
    else
    {
        return ExportClientNavMeshWC(World, LevelAssetPath);
    }
}

bool UC7NavmeshAndVoxBuildCommandlet::ExportClientNavMeshWP(UWorld* World, const FString& LevelAssetPath)
{
    if (!World->PersistentLevel)
    {
        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("PersistentLevel is null"));
        return false;
    }

    bool bFoundRecastActor = false;
    for (UPackage* ExternalPackage : World->PersistentLevel->GetLoadedExternalObjectPackages())
    {
        UObject* FoundAsset = nullptr;
        ForEachObjectWithPackage(
            ExternalPackage,
            [&FoundAsset](UObject* InnerObject) {
                if (InnerObject->IsAsset())
                {
                    if (FAssetData::IsUAsset(InnerObject))
                    {
                        // If we found the primary asset, use it
                        FoundAsset = InnerObject;
                        return false;
                    }
                    // Otherwise, keep the first found asset but keep looking for a primary asset
                    if (!FoundAsset)
                    {
                        FoundAsset = InnerObject;
                    }
                }
                return true;
            },
            /*bIncludeNestedObjects*/ false);

        if (!FoundAsset)
        {
            continue;
        }

        FAssetToolsModule& AssetToolsModule = FModuleManager::LoadModuleChecked<FAssetToolsModule>(TEXT("AssetTools"));
        TWeakPtr<IAssetTypeActions> AssetTypeActions = AssetToolsModule.Get().GetAssetTypeActionsForClass(FoundAsset->GetClass());
        FName AssetName = AssetTypeActions.IsValid() ? *AssetTypeActions.Pin()->GetObjectDisplayName(FoundAsset) : FoundAsset->GetFName();

        if (AssetName.ToString().Find("RecastNavMesh") == INDEX_NONE)
        {
            continue;
        }

        if (ExternalPackage->IsDirty())
        {
            if (!UEditorLoadingAndSavingUtils::SavePackages({ExternalPackage}, true))
            {
                UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("check out RecastNavMesh failed: %s"), *ExternalPackage->GetName());
                return false;
            }
        }

        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("check out RecastNavMesh success: %s"), *ExternalPackage->GetName());
        bFoundRecastActor = true;
    }

    if (bFoundRecastActor == false)
    {
        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("can not find RecastNavMesh actor"));
        return false;
    }

    return true;
}

bool UC7NavmeshAndVoxBuildCommandlet::ExportClientNavMeshDataChunks(UWorld* World, FPackageSourceControlHelper& PackageHelper)
{
    if (World == nullptr || World->IsPartitionedWorld() == false)
    {
        // Skip
        return true;
    }

    UNavigationSystemV1* NavSystem = Cast<UNavigationSystemV1>(World->GetNavigationSystem());
    if (NavSystem == nullptr)
    {
        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("No navigation system to generate navigation data."));
        return false;
    }

    AWorldSettings* WorldSettings = World->GetWorldSettings();
    if (WorldSettings == nullptr)
    {
        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("Not found world settings - Map : %s."), *World->GetPathName());
        return false;
    }

    UWorldPartition* WorldPartition = World->GetWorldPartition();
    check(WorldPartition);

    TSet<UObject*> TrackedObjects;
    TSet<UPackage*> PackagesToSave;
    TSet<UPackage*> PackagesToDelete;

    // Gather all packages before any navigation data chunk actors are deleted
    for (TActorIterator<ANavigationDataChunkActor> It(World); It; ++It)
    {
        ANavigationDataChunkActor* Actor = *It;
        if (Actor)
        {
            PackagesToDelete.Add(Actor->GetPackage());
            if (World->DestroyActor(Actor) == false)
            {
                UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Warning, TEXT("Could not be destroy %s."), *Actor->GetPathName());
            }
        }
    }

    // Generate partitioned navmesh chunk data actor
    if (Switches.Contains(TEXT("AllowPartitionedBuild")))
    {
        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("Generate navmesh data chunks actor begin."));

        // Check world settings
        {
            if (WorldSettings->NavigationDataChunkGridSize != WorldPartitionNavmeshCellSize ||
                WorldSettings->NavigationDataBuilderLoadingCellSize != WorldPartitionNavmeshCellSize * 4)
            {
                WorldSettings->NavigationDataChunkGridSize = WorldPartitionNavmeshCellSize;
                WorldSettings->NavigationDataBuilderLoadingCellSize = WorldPartitionNavmeshCellSize * 4;

                PackagesToSave.Add(World->GetPackage());
            }
        }

        // Check navmesh grid config
        {
            UWorldPartitionRuntimeSpatialHash* RuntimeSpatialHash = Cast<UWorldPartitionRuntimeSpatialHash>(WorldPartition->RuntimeHash);
            if (RuntimeSpatialHash == nullptr)
            {
                UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Warning, TEXT("World partition runtime hash is not class of UWorldPartitionRuntimeSpatialHash."));
                return false;
            }

            TArray<FSpatialHashRuntimeGrid>& Grids = RuntimeSpatialHash->GetGrids();

            bool bFound = false;
            {
                for (FSpatialHashRuntimeGrid& Grid : Grids)
                {
                    if (Grid.GridName == WorldPartitionNavmeshGridName)
                    {
                        if (Grid.CellSize != WorldPartitionNavmeshCellSize ||
                            Grid.LoadingRange != WorldPartitionNavmeshLoadingRange ||
                            Grid.Priority != WorldPartitionNavmeshPriority)
                        {
                            Grid.CellSize = WorldPartitionNavmeshCellSize;
                            Grid.LoadingRange = WorldPartitionNavmeshLoadingRange;
                            Grid.Priority = WorldPartitionNavmeshPriority;

                            PackagesToSave.Add(World->GetPackage());
                        }
                        bFound = true;
                    }
                }
            }
            if (bFound == false)
            {
                FSpatialHashRuntimeGrid Grid;
                {
                    Grid.GridName = WorldPartitionNavmeshGridName;
                    Grid.CellSize = WorldPartitionNavmeshCellSize;
                    Grid.LoadingRange = WorldPartitionNavmeshLoadingRange;
                }
                Grids.Add(Grid);

                PackagesToSave.Add(World->GetPackage());
            }
        }

        // Spawn new navmesh chunk data actor
        {
            uint32 GridSize = WorldSettings->NavigationDataChunkGridSize;
            GridSize = FMath::Max(GridSize, 1u);

            const FBox NavDataBounds = NavSystem->ComputeNavDataBounds();
            const FBox WorldBounds = NavSystem->GetNavigableWorldBounds();

            if (!NavDataBounds.IsValid)
            {
                UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("Nav data bounds is invalid."));
                return false;
            }
            UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("Nav data bounds: (%.6f, %.6f, %.6f) - (%.6f, %.6f, %.6f)"),
                   NavDataBounds.Min.X, NavDataBounds.Min.Y, NavDataBounds.Min.Z,
                   NavDataBounds.Max.X, NavDataBounds.Max.Y, NavDataBounds.Max.Z);

            const FWorldBuilderCellCoord MinCellCoords = FCellInfo::GetCellCoord(WorldBounds.Min, GridSize);
            const FWorldBuilderCellCoord NumCellsIterations = FCellInfo::GetCellCount(WorldBounds, GridSize);
            const FWorldBuilderCellCoord BeginCellCoords = MinCellCoords;
            const FWorldBuilderCellCoord EndCellCoords = BeginCellCoords + NumCellsIterations;

            int64 IterationIndex = 0;
            const int64 IterationCount = NumCellsIterations.Y * NumCellsIterations.X;
            for (int64 y = BeginCellCoords.Y; y < EndCellCoords.Y; y++)
            {
                for (int64 x = BeginCellCoords.X; x < EndCellCoords.X; x++)
                {
                    IterationIndex++;

                    UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("[%lld / %lld] Processing cells..."), IterationIndex, IterationCount);

                    double MinX = static_cast<double>(x * GridSize);
                    double MinY = static_cast<double>(y * GridSize);

                    FVector Min(MinX, MinY, 0);
                    FVector Max = Min + FVector(GridSize, GridSize, 0);

                    constexpr float HalfHeight = HALF_WORLD_MAX;
                    const FBox QueryBounds(FVector(Min.X, Min.Y, -HalfHeight), FVector(Max.X, Max.Y, HalfHeight));

                    if (!NavDataBounds.IsValid || !NavDataBounds.Intersect(QueryBounds))
                    {
                        // Skip if there is no navdata for this cell
                        continue;
                    }

                    // Spawn actor and fill data
                    {
                        FActorSpawnParameters SpawnParams;
                        {
                            SpawnParams.bDeferConstruction = true;
                            SpawnParams.bCreateActorPackage = true;
                        }

                        ANavigationDataChunkActor* DataChunkActor = World->SpawnActor<ANavigationDataChunkActor>(SpawnParams);
                        check(DataChunkActor);
                        {
                            DataChunkActor->SetGridSize(GridSize);
                            DataChunkActor->SetActorLocation((Min + Max) * 0.5f);
                            DataChunkActor->SetFolderPath(TEXT("NavDataChunkActors"));
                            DataChunkActor->SetRuntimeGrid(WorldPartitionNavmeshGridName);
                            {
                                FFolder Folder = DataChunkActor->GetFolder();
                                UActorFolder* ActorFolder = FWorldPersistentFolders::GetActorFolder(Folder, World);
                                if (ActorFolder)
                                {
                                    UPackage* FolderPackage = ActorFolder->GetPackage();
                                    check(FolderPackage);

                                    TrackedObjects.Add(ActorFolder);
                                    PackagesToSave.Add(FolderPackage);
                                }
                            }

                            FBox TilesBounds(EForceInit::ForceInit);
                            DataChunkActor->CollectNavData(QueryBounds, TilesBounds);

                            FBox ChunkActorBounds(FVector(QueryBounds.Min.X, QueryBounds.Min.Y, TilesBounds.Min.Z), FVector(QueryBounds.Max.X, QueryBounds.Max.Y, TilesBounds.Max.Z));
                            ChunkActorBounds = ChunkActorBounds.ExpandBy(FVector(-1.f, -1.f, 1.f)); //reduce XY by 1cm to avoid precision issues causing potential overflow on neighboring cell, add 1cm in Z to have a minimum of volume.
                            UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, VeryVerbose, TEXT("Setting ChunkActorBounds to %s"), *ChunkActorBounds.ToString());
                            DataChunkActor->SetDataChunkActorBounds(ChunkActorBounds);

                            FName CellName;
                            {
                                const FString PackageName = FPackageName::GetShortName(WorldPartition->GetPackage());
                                const FString PackageNameNoPIEPrefix = UWorld::RemovePIEPrefix(PackageName);
                                CellName = FName(*FString::Printf(TEXT("%s_%lld_%lld"), *PackageNameNoPIEPrefix, x, y));
                            }
                            DataChunkActor->SetActorLabel(FString::Printf(TEXT("NavDataChunkActor_%s"), *CellName.ToString()));
                            UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, VeryVerbose, TEXT("Setting ChunkActorName is %s"), *DataChunkActor->GetActorLabel());
                        }

                        TrackedObjects.Add(DataChunkActor);
                        PackagesToSave.Add(DataChunkActor->GetPackage());
                    }
                }
            }
        }

        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("Generate navmesh data chunks actor end."));
    }

    if (DeletePackages(PackagesToDelete.Array(), PackageHelper) == false)
    {
        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("Error Deleting Packages."));
        return false;
    }

    if (SavePackages(PackagesToSave.Array(), PackageHelper) == false)
    {
        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("Error Saving Packages."));
        return false;
    }

    return true;
}

bool UC7NavmeshAndVoxBuildCommandlet::ExportClientNavMeshWC(UWorld* World, const FString& LevelAssetPath)
{
    FString WorldPackageName;
    if (!FPackageName::DoesPackageExist(World->GetOutermost()->GetName(), &WorldPackageName))
    {
        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("MAP[%s] package is not existed: %s"), *LevelAssetPath, *World->GetOutermost()->GetName());
        return false;
    }
    UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("MAP[%s] get WorldPackageName: %s"), *LevelAssetPath, *WorldPackageName);

    FString LeftStr;
    FString RightStr;
    WorldPackageName.Split("_P.umap", &LeftStr, &RightStr);
    FString NavMeshUMap = LeftStr + "_NavMesh.umap";
    TArray<FString> ParseResults;
    NavMeshUMap.ParseIntoArray(ParseResults, TEXT("/"));
    FString NavMeshName;
    ParseResults.Last().Split(".umap", &NavMeshName, &RightStr);

    // 找到Navmesh对应的umap并保存
    for (ULevelStreaming* StreamingLevel : World->GetStreamingLevels())
    {
        if (!StreamingLevel)
        {
            continue;
        }
        FString PackageName = StreamingLevel->GetWorldAssetPackageName();
        PackageName.ParseIntoArray(ParseResults, TEXT("/"));
        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("MAP[%s] PackageName[%s], NavMeshName[%s], LastName[%s]"), *LevelAssetPath, *PackageName, *NavMeshName, *ParseResults.Last());

        if (NavMeshName != ParseResults.Last())
        {
            continue;
        }

        UPackage* Package = FindPackage(nullptr, *PackageName);
        if (!Package)
        {
            Package = LoadPackage(nullptr, *PackageName, LOAD_None);
            if (!Package)
            {
                UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("MAP[%s] can not load package: %s"), *LevelAssetPath, *PackageName);
                continue;
            }
        }

        if (!CheckoutFile(NavMeshName))
        {
            UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("MAP[%s] check out navmesh failed, the path is: %s"), *LevelAssetPath, *NavMeshName);
            return false;
        }

        TArray<FString> CheckedOutPackagesFilenames;
        CheckoutAndSavePackage(Package, CheckedOutPackagesFilenames, bSkipCheckedOutFiles);
        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("MAP[%s] export navmesh succeed, the path is: %s"), *LevelAssetPath, *NavMeshName);
        return true;
    }

    UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("MAP[%s] find navmesh file [%s.umap] failed"), *LevelAssetPath, *NavMeshName);
    return false;
}

UWorld* UC7NavmeshAndVoxBuildCommandlet::LoadWorld(const FString& InWorldPackageName)
{
    // This will convert incomplete package name to a fully qualified path
    FString WorldLongPackageName;
    FString WorldFilename;
    if (!FPackageName::SearchForPackageOnDisk(InWorldPackageName, &WorldLongPackageName, &WorldFilename))
    {
        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("Package '%s' not found"), *InWorldPackageName);
        return nullptr;
    }

    // Load the world package
    UPackage* WorldPackage = LoadWorldPackageForEditor(WorldLongPackageName);
    if (!WorldPackage)
    {
        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("Couldn't load package %s."), *WorldLongPackageName);
        return nullptr;
    }

    // Find the world in the given package
    UWorld* World = UWorld::FindWorldInPackage(WorldPackage);
    if (!World)
    {
        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("No world in specified package %s."), *WorldLongPackageName);
        return nullptr;
    }

    // Load configuration file
    FString WorldConfigFilename = FPackageName::LongPackageNameToFilename(World->GetPackage()->GetName(), TEXT(".ini"));
    if (FPlatformFileManager::Get().GetPlatformFile().FileExists(*WorldConfigFilename))
    {
        LoadConfig(GetClass(), *WorldConfigFilename);
    }

    return World;
}

void UC7NavmeshAndVoxBuildCommandlet::LoadDataLayers(UWorld* InWorld)
{
    if (UWorldPartition* WorldPartition = InWorld->GetWorldPartition())
    {
        // Properly Setup DataLayers for Builder
        UDataLayerManager* DataLayerManager = WorldPartition->GetDataLayerManager();

        // Load Data Layers
        bool bUpdateEditorCells = false;
        DataLayerManager->ForEachDataLayerInstance([&bUpdateEditorCells, this](UDataLayerInstance* DataLayer) {
            const FName DataLayerShortName(DataLayer->GetDataLayerShortName());

            // Load all Non Excluded Data Layers + Non DynamicallyLoaded Data Layers + Initially Active Data Layers + Data Layers provided by builder
            const bool bLoadedInEditor = DataLayer->IsRuntime() == false ||
                                         DataLayer->GetInitialRuntimeState() == EDataLayerRuntimeState::Activated;
            if (DataLayer->IsLoadedInEditor() != bLoadedInEditor)
            {
                bUpdateEditorCells = true;
                DataLayer->SetIsLoadedInEditor(bLoadedInEditor, /*bFromUserChange*/ false);
            }

            UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("DataLayer '%s' Loaded: %d"), *UDataLayerInstance::GetDataLayerText(DataLayer).ToString(), bLoadedInEditor ? 1 : 0);

            return true;
        });

        if (bUpdateEditorCells)
        {
            UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("DataLayer load state changed refreshing editor cells"));
            FDataLayersEditorBroadcast::StaticOnActorDataLayersEditorLoadingStateChanged(false);
        }
    }
}

bool UC7NavmeshAndVoxBuildCommandlet::SavePackages(const TArray<UPackage*>& Packages, FPackageSourceControlHelper& PackageHelper, bool bErrorsAsWarnings)
{
    if (Packages.IsEmpty())
    {
        return true;
    }
    UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("Saving %d packages..."), Packages.Num());

    const TArray<FString> PackageFilenames = SourceControlHelpers::PackageFilenames(Packages);

    TArray<FString> PackagesToCheckout;
    TArray<FString> PackagesToAdd;
    TArray<FString> PackageNames;

    PackageNames.Reserve(Packages.Num());
    Algo::Transform(Packages, PackageNames, [](UPackage* InPackage) { return InPackage->GetName(); });
    bool bSuccess = PackageHelper.GetDesiredStatesForModification(PackageNames, PackagesToCheckout, PackagesToAdd, bErrorsAsWarnings);
    if (!bSuccess && !bErrorsAsWarnings)
    {
        return false;
    }

    if (PackagesToCheckout.Num())
    {
        if (!PackageHelper.Checkout(PackagesToCheckout, bErrorsAsWarnings))
        {
            bSuccess = false;
            if (!bErrorsAsWarnings)
            {
                return false;
            }
        }
    }

    ResetLoaders(TArray<UObject*>(Packages));

    for (int PackageIndex = 0; PackageIndex < Packages.Num(); ++PackageIndex)
    {
        const FString& PackageFilename = PackageFilenames[PackageIndex];
        // Check read-only flag in case some checkouts failed
        if (!IPlatformFile::GetPlatformPhysical().IsReadOnly(*PackageFilename))
        {
            // Save package
            FSavePackageArgs SaveArgs;
            SaveArgs.TopLevelFlags = RF_Standalone;
            if (!UPackage::SavePackage(Packages[PackageIndex], nullptr, *PackageFilenames[PackageIndex], SaveArgs))
            {
                bSuccess = false;
                UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Error, TEXT("%s"), *FString::Printf(TEXT("Error saving package %s."), *Packages[PackageIndex]->GetName()));
                if (!bErrorsAsWarnings)
                {
                    return false;
                }
            }
        }
        else
        {
            check(bErrorsAsWarnings);
        }
    }

    if (PackagesToAdd.Num())
    {
        if (!PackageHelper.AddToSourceControl(PackagesToAdd, bErrorsAsWarnings))
        {
            return false;
        }
    }

    return bSuccess;
}

bool UC7NavmeshAndVoxBuildCommandlet::DeletePackages(const TArray<UPackage*>& Packages, FPackageSourceControlHelper& PackageHelper, bool bErrorsAsWarnings)
{
    TArray<FString> PackagesNames;
    Algo::Transform(Packages, PackagesNames, [](UPackage* InPackage) {
        ResetLoaders(InPackage);
        return InPackage->GetName();
    });
    return DeletePackages(PackagesNames, PackageHelper, bErrorsAsWarnings);
}

bool UC7NavmeshAndVoxBuildCommandlet::DeletePackages(const TArray<FString>& PackageNames, FPackageSourceControlHelper& PackageHelper, bool bErrorsAsWarnings)
{
    if (PackageNames.Num() > 0)
    {
        UE_LOG(LogC7NavmeshAndVoxBuildCommandlet, Display, TEXT("Deleting %d packages..."), PackageNames.Num());
        return PackageHelper.Delete(PackageNames, bErrorsAsWarnings);
    }

    return true;
}

void UC7NavmeshAndVoxBuildCommandlet::PreExport(UWorld* World)
{
    NavModifierActors.Empty();

    for (TActorIterator<ALevelInstance> It(World); It; ++It)
    {
        ALevelInstance* LevelInstance = *It;
        if (!LevelInstance || !Cast<UBlueprintGeneratedClass>(LevelInstance->GetClass())) continue;

        TArray<UStaticMeshComponent*> StaticMeshComponents;
        LevelInstance->GetComponents<UStaticMeshComponent>(StaticMeshComponents);

        for (UStaticMeshComponent* StaticMeshComponent : StaticMeshComponents)
        {
            if (!StaticMeshComponent || StaticMeshComponent->GetClass() != UStaticMeshComponent::StaticClass() || StaticMeshComponent->GetName() != TEXT("NavModifierProxyComponent")) continue;

            UStaticMesh* NavModifierMesh = StaticMeshComponent->GetStaticMesh();
            if (!NavModifierMesh) continue;

            FActorSpawnParameters SpawnParameters;
            SpawnParameters.OverrideLevel = World->GetCurrentLevel();
            AStaticMeshActor* NewActor = World->SpawnActor<AStaticMeshActor>(AStaticMeshActor::StaticClass(), LevelInstance->GetActorTransform(), SpawnParameters);
            if (!NewActor) continue;
            NewActor->SetIsSpatiallyLoaded(true);
            NewActor->SetActorLabel(FString::Printf(TEXT("NavModifierActor_%s"), *LevelInstance->GetActorLabel()));

            UStaticMeshComponent* NewSMC = NewActor->GetStaticMeshComponent();
            NewSMC->SetStaticMesh(NavModifierMesh);

            if (UNavModifierComponent* NavMod = NewObject<UNavModifierComponent>(NewActor))
            {
                NewActor->AddInstanceComponent(NavMod);
                NavMod->RegisterComponent();
                NavMod->SetAreaClass(UNavArea_Null::StaticClass());
            }

            NavModifierActors.Add(NewActor);
        }
    }
}

bool UC7NavmeshAndVoxBuildCommandlet::ConvexDecomposeStaticMeshToHulls(const UStaticMesh* InStaticMesh, TArray<FKConvexElem>& OutHulls, int32 LODIndex, uint32 RequestedHullCount, int32 MaxHullVerts, uint32 Resolution)
{
    OutHulls.Reset();

    if (!InStaticMesh || !InStaticMesh->GetRenderData() || InStaticMesh->GetRenderData()->LODResources.Num() == 0)
    {
        UE_LOG(LogTemp, Error, TEXT("ConvexDecomposeStaticMeshToHulls: Invalid StaticMesh or no render data."));
        return false;
    }

    LODIndex = FMath::Clamp(LODIndex, 0, InStaticMesh->GetRenderData()->LODResources.Num() - 1);

    const FStaticMeshLODResources& LODResources = InStaticMesh->GetRenderData()->LODResources[LODIndex];

    const FPositionVertexBuffer& PositionVertexBuffer = LODResources.VertexBuffers.PositionVertexBuffer;
    const int32 NumVerts = PositionVertexBuffer.GetNumVertices();
    if (NumVerts == 0)
    {
        UE_LOG(LogTemp, Error, TEXT("ConvexDecomposeStaticMeshToHulls: LOD has no vertices."));
        return false;
    }

    TArray<FVector3f> Vertices;
    Vertices.Reserve(NumVerts);
    for (int32 Vid = 0; Vid < NumVerts; ++Vid)
    {
        const FVector3f Pos = PositionVertexBuffer.VertexPosition(Vid);
        Vertices.Add(FVector3f(Pos));
    }

    const FRawStaticIndexBuffer& IndexBuffer = LODResources.IndexBuffer;
    FIndexArrayView IndexView = IndexBuffer.GetArrayView();
    if (IndexView.Num() == 0)
    {
        UE_LOG(LogTemp, Error, TEXT("ConvexDecomposeStaticMeshToHulls: LOD has no indices."));
        return false;
    }

    TArray<uint32> Indices;
    Indices.Reserve(IndexView.Num());
    for (int32 i = 0; i < IndexView.Num(); ++i)
    {
        Indices.Add(IndexView[i]);
    }

    UBodySetup* TempBodySetup = NewObject<UBodySetup>(GetTransientPackage(), NAME_None, RF_Transient);
    TempBodySetup->AggGeom.ConvexElems.Empty();

    DecomposeMeshToHulls(TempBodySetup, Vertices, Indices, RequestedHullCount, MaxHullVerts, Resolution);

    if (TempBodySetup->AggGeom.ConvexElems.Num() == 0)
    {
        UE_LOG(LogTemp, Warning, TEXT("ConvexDecomposeStaticMeshToHulls: Decomposition produced 0 convex hulls."));
        return false;
    }

    OutHulls = TempBodySetup->AggGeom.ConvexElems;

    return true;
}

void UC7NavmeshAndVoxBuildCommandlet::PostExport(UWorld* World)
{
    for (AStaticMeshActor* Actor : NavModifierActors)
    {
        Actor->Destroy();
    }
}
