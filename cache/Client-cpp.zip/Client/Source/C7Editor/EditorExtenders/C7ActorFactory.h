//// Copyright Epic Games, Inc. All Rights Reserved.
//
//
//#pragma once
//
//#include "CoreMinimal.h"
//#include "UObject/ObjectMacros.h"
//#include "ActorFactories/ActorFactory.h"
//#include "C7ActorFactory.generated.h"
//
//UCLASS(MinimalAPI, config=Editor, collapsecategories, hidecategories=Object)
//class UActorFactoryC7TriggerBox : public UActorFactory
//{
//	GENERATED_UCLASS_BODY()
//};
//
//
//
