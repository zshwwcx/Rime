#include "CoreMinimal.h"
#include "Internationalization/Regex.h"

#if WITH_EDITOR
static void FocusViewportAtCoordinates(const TArray<FString> &Args)
{
	if (Args.Num() < 1)
	{
		UE_LOG(LogTemp, Warning, TEXT("Please provide coordinates in the format: (X=Value,Y=Value,Z=Value)"));
		return;
	}

	FString PosString = Args[0];

	FVector Coordinates(0.f, 0.f, 0.f);
	FRegexPattern Pattern(TEXT("X=(-?\\d+\\.\\d+),Y=(-?\\d+\\.\\d+),Z=(-?\\d+\\.\\d+)"));
	FRegexMatcher Matcher(Pattern, PosString);

	if (Matcher.FindNext())
	{
		Coordinates.X = FCString::Atof(*Matcher.GetCaptureGroup(1));
		Coordinates.Y = FCString::Atof(*Matcher.GetCaptureGroup(2));
		Coordinates.Z = FCString::Atof(*Matcher.GetCaptureGroup(3));

		UEditorEngine *EditorEngine = Cast<UEditorEngine>(GEngine);
		if (EditorEngine != nullptr)
		{
			const FVector BoxExtent(100.f, 100.f, 100.f);
			const FBox BoundingBox(Coordinates - BoxExtent, Coordinates + BoxExtent);
			EditorEngine->MoveViewportCamerasToBox(BoundingBox, true);

			UE_LOG(LogTemp, Warning, TEXT("Focus at:(X:%f, Y:%f, Z:%f)"), Coordinates.X, Coordinates.Y, Coordinates.Z);
		}
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("Invalid coordinates format, should be (X=Value,Y=Value,Z=Value)"));
	}
}

static FAutoConsoleCommand FocusPosCommand(TEXT("DebugPos"), TEXT("Focus the viewport at the specified coordinates. Usage: DebugPos (X=Value,Y=Value,Z=Value)"), FConsoleCommandWithArgsDelegate::CreateStatic(FocusViewportAtCoordinates));
#endif