#include "KGPyUnreal/PythonSlateHelpers.h"

#include "KGPyTypeNameDefinitions.h"

namespace UE::Python::Internal
{
	SLATE_IMPLEMENT_WIDGET(SUserWidget)

	void SUserWidget::PrivateRegisterAttributes(FSlateAttributeInitializer& AttributeInitializer)
	{
	}
}
