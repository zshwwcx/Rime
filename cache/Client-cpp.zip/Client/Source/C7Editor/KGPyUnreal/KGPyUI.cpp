#include "KGPyUnreal.h"

#include "KGPyTypeNameDefinitions.h"
#include "KGUIEditor.h"
#include "WidgetBlueprint.h"

namespace UE::Python::Internal
{
	class FKGUIEditorModuleRef
	{
	public:
		FKGUIEditorModuleRef(FKGUIEditorModule& KGUIEditorModule) : Ref(KGUIEditorModule) {}

		static int ReplaceWidget(UWidgetBlueprint* InWidgetBlueprint, UClass* OriginalClass, UClass* NewClass, bool bTest)
		{
			return FKGUIEditorModule::ReplaceWidget(InWidgetBlueprint, OriginalClass, NewClass, bTest);
		}

		static UWidgetTree* GetWidgetTreeFromBlueprint(UWidgetBlueprint* WidgetBlueprint)
		{
			if (WidgetBlueprint == nullptr)
			{
				return nullptr;
			}
			return WidgetBlueprint->WidgetTree;
		}

		static TArray<UWidget*> GetAllWidgetsFromWidgetTree(UWidgetTree* WidgetTree)
		{
			TArray<UWidget*> Result;
			if (WidgetTree != nullptr)
			{
				WidgetTree->GetAllWidgets(Result);
			}
			return Result;
		}

		FKGUIEditorModule& Ref;
	};
}

PYBIND11_UNREAL_REGISTER_TYPE_NAME(UE::Python::Internal::FKGUIEditorModuleRef);

void KGPyUnreal::Initialize_KGUI(py::module_& Module)
{
	py::unreal_class<UE::Python::Internal::FKGUIEditorModuleRef>(Module, "KGUIEditorModule")
		.def_static_auto_naming(UE::Python::Internal::FKGUIEditorModuleRef, ReplaceWidget)
		.def_static_auto_naming(UE::Python::Internal::FKGUIEditorModuleRef, GetWidgetTreeFromBlueprint)
		.def_static_auto_naming(UE::Python::Internal::FKGUIEditorModuleRef, GetAllWidgetsFromWidgetTree)
	;
}