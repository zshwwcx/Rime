#pragma once

#include "ContentBrowserModule.h"
#include "DesktopPlatformModule.h"
#include "IContentBrowserSingleton.h"
#include "KGPyUnreal.h"
#include "Widgets/Input/SNumericEntryBox.h"

namespace UE::Python::Internal
{
	class SUserWidget : public SCompoundWidget
	{
		SLATE_DECLARE_WIDGET(SUserWidget, SCompoundWidget)

	public:
		SLATE_BEGIN_ARGS(SUserWidget) {}
			SLATE_ARGUMENT(py::object, Object)
		SLATE_END_ARGS()

		void Construct(const FArguments& Arguments)
		{
		}

		void SetContent(TSharedRef<SWidget> InContent)
		{
			ChildSlot[InContent];
		}
	};

	class FPythonObject : public TSharedFromThis<FPythonObject>
	{
	public:
		FPythonObject()
		{
		}

		FPythonObject(const py::object& InObject) : Object(InObject)
		{
		}

		py::object GetObject() const { return Object; }

	private:
		py::object Object;
	};

	class SPythonListView : public SListView<TSharedRef<FPythonObject>>
	{
	public:
		using Super = SListView<TSharedRef<FPythonObject>>;
		using ItemType = TSharedRef<FPythonObject>;

		void Construct(const typename SListView<ItemType>::FArguments& InArgs)
		{
			const_cast<SListView<ItemType>::FArguments&>(InArgs).ListItemsSource(&PythonItemsSourceCache);
			Super::Construct(InArgs);
		}

		void SetItemsSource(py::list InPythonItemsSource)
		{
			PythonItemsSource = InPythonItemsSource;
			MigrateCache();
		}

		virtual void RequestListRefresh() override
		{
			MigrateCache();
			Super::RequestListRefresh();
		}

	private:
		void MigrateCache()
		{
			PythonItemsSourceCache.Empty();
			for (auto& Item : PythonItemsSource)
			{
				PythonItemsSourceCache.Add(MakeShared<FPythonObject>(Item.cast<py::object>()));
			}
			Super::SetItemsSource(&PythonItemsSourceCache);
		}

		py::list PythonItemsSource;
		TArray<ItemType> PythonItemsSourceCache;
	};

	class SPythonTableRow : public STableRow<TSharedRef<FPythonObject>>
	{
	public:
		void Construct(const typename SPythonTableRow::FArguments& InArgs, const TSharedRef<STableViewBase>& InOwnerTableView)
		{
			STableRow<TSharedRef<FPythonObject>>::Construct(InArgs, InOwnerTableView);
		}
	};

	struct FOnGenerateRowLambda
	{
		FOnGenerateRowLambda(py::object InTableRowType, py::function InFunction)
			: Function(InFunction)
			, TableRowType(InTableRowType)
		{
		}

		TSharedRef<ITableRow> operator()(TSharedRef<FPythonObject> Item, const TSharedRef<STableViewBase>& TableViewBase)
		{
			FKGPythonScriptSubModuleHelper::FPyScopedGIL GIL;
			pybind11::object result;
			try
			{
				result = Function(Item->GetObject(), StaticCastSharedRef<SPythonListView>(TableViewBase));
			}
			catch (...)
			{
				pybind11::detail::try_translate_exceptions();
			}
			if (result.ptr() == nullptr || result.is_none() || !py::isinstance(result, TableRowType))
			{
				return SNew(SPythonTableRow, TableViewBase)
					.Content()
					[
						SNew(STextBlock)
						.Text(FText::FromString(TEXT("The return value of the on_generate_row function needs to be of type STableRow.")))
					];
			}
			else
			{
				auto TableRow = py::cast<TSharedPtr<SPythonTableRow>>(result);
				return StaticCastSharedRef<ITableRow>(TableRow.ToSharedRef());
			}
		}

		py::function Function;
		py::object TableRowType;
	};

	template <typename T, typename ThisType>
	class TPythonImage : public T, public FGCObject
	{
	public:
		ThisType& SetImage(const FSlateBrush& InImage)
		{
			Image = InImage;
			T::SetImage(&Image);
			return static_cast<ThisType&>(*this);
		}

		const FSlateBrush& GetImage() const
		{
			return Image;
		}

		virtual void AddReferencedObjects(FReferenceCollector& Collector) override
		{
			TWeakObjectPtr<UObject> ReferencedObject = Image.GetResourceObject();
			Collector.AddReferencedObject(ReferencedObject);
		}

		virtual FString GetReferencerName() const override { return TEXT("TPythonImage"); }

	private:
		FSlateBrush Image;
	};

	template <typename T, typename ThisType>
	class TPythonBorder : public T, public FGCObject
	{
	public:
		ThisType& SetBorderImage(const FSlateBrush& InBorderImage)
		{
			BorderImage = InBorderImage;
			T::SetBorderImage(&BorderImage);
			return static_cast<ThisType&>(*this);
		}

		const FSlateBrush& GetBorderImage() const
		{
			return BorderImage;
		}

		virtual void AddReferencedObjects(FReferenceCollector& Collector) override
		{
			TWeakObjectPtr<UObject> ReferencedObject = BorderImage.GetResourceObject();
			Collector.AddReferencedObject(ReferencedObject);
		}

		virtual FString GetReferencerName() const override { return TEXT("TPythonBorder"); }

	private:
		FSlateBrush BorderImage;
	};

	template <typename T, typename ThisType>
	class TPythonDockTab : public T, public FGCObject
	{
	public:
		ThisType& SetTabIcon(const FSlateBrush& InTabIcon)
		{
			TabIcon = InTabIcon;
			T::SetTabIcon(&TabIcon);
			return static_cast<ThisType&>(*this);
		}

		const FSlateBrush& GetTabIcon() const
		{
			return TabIcon;
		}

		virtual void AddReferencedObjects(FReferenceCollector& Collector) override
		{
			TWeakObjectPtr<UObject> ReferencedObject = TabIcon.GetResourceObject();
			Collector.AddReferencedObject(ReferencedObject);
		}

		virtual FString GetReferencerName() const override { return TEXT("TPythonDockTab"); }

	private:
		FSlateBrush TabIcon;
	};

	template <typename T, typename ThisType>
	class TPythonButton : public TPythonBorder<T, ThisType>
	{
	public:
		ThisType& SetButtonStyle(const FButtonStyle& InButtonStyle)
		{
			ButtonStyle = InButtonStyle;
			T::SetButtonStyle(&ButtonStyle);
			return static_cast<ThisType&>(*this);
		}

		const FButtonStyle& GetButtonStyle() const
		{
			return ButtonStyle;
		}

		virtual void AddReferencedObjects(FReferenceCollector& Collector) override
		{
			TPythonBorder<T, ThisType>::AddReferencedObjects(Collector);
			{
				TWeakObjectPtr<UObject> ReferencedObject = ButtonStyle.Normal.GetResourceObject();
				Collector.AddReferencedObject(ReferencedObject);
			}
			{
				TWeakObjectPtr<UObject> ReferencedObject = ButtonStyle.Hovered.GetResourceObject();
				Collector.AddReferencedObject(ReferencedObject);
			}
			{
				TWeakObjectPtr<UObject> ReferencedObject = ButtonStyle.Pressed.GetResourceObject();
				Collector.AddReferencedObject(ReferencedObject);
			}
			{
				TWeakObjectPtr<UObject> ReferencedObject = ButtonStyle.Disabled.GetResourceObject();
				Collector.AddReferencedObject(ReferencedObject);
			}
			{
				TWeakObjectPtr<UObject> ReferencedObject = ButtonStyle.PressedSlateSound.GetResourceObject();
				Collector.AddReferencedObject(ReferencedObject);
			}
			{
				TWeakObjectPtr<UObject> ReferencedObject = ButtonStyle.HoveredSlateSound.GetResourceObject();
				Collector.AddReferencedObject(ReferencedObject);
			}
		}

		virtual FString GetReferencerName() const override { return TEXT("TPythonButton"); }

	private:
		FButtonStyle ButtonStyle;
	};

	class SPythonImage : public TPythonImage<SImage, SPythonImage>
	{
	public:
		void Construct(const FArguments& InArgs) { SImage::Construct(InArgs); }
	};

	class SPythonBorder : public TPythonBorder<SBorder, SPythonBorder>
	{
	public:
		void Construct(const FArguments& InArgs) { SBorder::Construct(InArgs); }
	};

	class SPythonButton : public TPythonButton<SButton, SPythonButton>
	{
	public:
		void Construct(const FArguments& InArgs) { SButton::Construct(InArgs); }
	};

	class SPythonDockTab : public TPythonDockTab<SDockTab, SPythonDockTab>
	{
	public:
		void Construct(const FArguments& InArgs) { SDockTab::Construct(InArgs); }
	};

	using SFloatNumericEntryBox = SNumericEntryBox<float>;

	class IContentBrowserSingletonRef
	{
	public:
		IContentBrowserSingletonRef(IContentBrowserSingleton& ContentBrowserSingleton) : Ref(ContentBrowserSingleton)
		{
		}

		void SyncBrowserToAssets(const TArray<UObject*>& AssetList, bool bAllowLockedBrowsers = false, bool bFocusContentBrowser = true, const FName& InstanceName = FName(), bool bNewSpawnBrowser = false)
		{
			Ref.SyncBrowserToAssets(AssetList, bAllowLockedBrowsers, bFocusContentBrowser, InstanceName, bNewSpawnBrowser);
		}

	private:
		IContentBrowserSingleton& Ref;
	};

	class FContentBrowserModuleRef
	{
	public:
		FContentBrowserModuleRef(FContentBrowserModule& ContentBrowserModule) : Ref(ContentBrowserModule) {}

		auto& GetAllAssetViewContextMenuExtenders()
		{
			return Ref.GetAllAssetViewContextMenuExtenders();
		}

		auto AddAssetViewContextMenuExtender(const FContentBrowserMenuExtender_SelectedAssets& Extender)
		{
			GetAllAssetViewContextMenuExtenders().Add(Extender);
			return Extender.GetHandle();
		}

		void RemoveAssetViewContextMenuExtender(const FDelegateHandle& DelegateHandle)
		{
			GetAllAssetViewContextMenuExtenders().RemoveAll([DelegateHandle](const auto& Extender) { return Extender.GetHandle() == DelegateHandle; });
		}

		void RemoveAllAssetViewContextMenuExtenders()
		{
			GetAllAssetViewContextMenuExtenders().Reset();
		}

		IContentBrowserSingletonRef Get()
		{
			return IContentBrowserSingletonRef(Ref.Get());
		}

		FContentBrowserModule& Ref;
	};

	class IDesktopPlatformRef
	{
	public:
		IDesktopPlatformRef(IDesktopPlatform* DesktopPlatform) : Ref(DesktopPlatform) {}

		bool OpenFileDialog(const void* ParentWindowHandle, const FString& DialogTitle, const FString& DefaultPath, const FString& DefaultFile, const FString& FileTypes, uint32 Flags, TArray<FString>& OutFilenames, int32& outFilterIndex)
		{
			if (!Ref)
			{
				return false;
			}
			return Ref->OpenFileDialog(ParentWindowHandle, DialogTitle, DefaultPath, DefaultFile, FileTypes, Flags, OutFilenames, outFilterIndex);
		}

		bool SaveFileDialog(const void* ParentWindowHandle, const FString& DialogTitle, const FString& DefaultPath, const FString& DefaultFile, const FString& FileTypes, uint32 Flags, TArray<FString>& OutFilenames)
		{
			if (!Ref)
			{
				return false;
			}
			return Ref->SaveFileDialog(ParentWindowHandle, DialogTitle, DefaultPath, DefaultFile, FileTypes, Flags, OutFilenames);
		}

		IDesktopPlatform* Ref;
	};

	class FDesktopPlatformModuleRef
	{
	public:
		FDesktopPlatformModuleRef(FDesktopPlatformModule& DesktopPlatformModule): Ref(DesktopPlatformModule) {}

		IDesktopPlatformRef Get()
		{
			return IDesktopPlatformRef(Ref.Get());
		}

		FDesktopPlatformModule& Ref;
	};
}