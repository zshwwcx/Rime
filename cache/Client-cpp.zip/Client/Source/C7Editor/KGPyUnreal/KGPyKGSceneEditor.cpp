#include "Misc/CommonDefines.h"
#include "KGPyUnreal.h"
#include "KGPyTypeNameDefinitions.h"
#include "KGSceneRuntime/KGSceneRuntimeEditorManager.h"
#include "KGSceneEditor/Private/Operate/GPOperateUtils.h"
#include "3C/Core/KGUEActorManager.h"
#include "FileAsset/LuaSerializeHelper.h"
#include "3C/Util/KGUtils.h"
#include "Editor/UnrealEd/Classes/Editor/EditorEngine.h"
#include "EditorProxy/LevelLuaEditorProxy.h"
#include "Misc/KGGameInstanceBase.h"


namespace UE::Python::Internal
{
	struct KGSceneEditor
	{
	public:
		KGSceneEditor() { }
		
		TWeakObjectPtr<UObject> get_actor_by_entity_id(KGEntityID EntityID) const
		{
			if (!GEngine) return nullptr;

			const TIndirectArray<FWorldContext>& WorldContexts = GEngine->GetWorldContexts();
			for (const FWorldContext& Context : WorldContexts)
			{
				if (Context.WorldType == EWorldType::PIE && Context.World())
				{
					if (UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(Context.World()))
					{
						KGActorID ActorID = ActorManager->GetActorIDByEntityID(EntityID);
						return KGUtils::GetObjectByID(ActorID);
					}
				}
			}
			return nullptr;
		}

		KGActorID get_actor_id_by_entity_id(KGEntityID EntityID) const
		{
			if (!GEngine) return KG_INVALID_ACTOR_ID;

			const TIndirectArray<FWorldContext>& WorldContexts = GEngine->GetWorldContexts();
			for (const FWorldContext& Context : WorldContexts)
			{
				if (Context.WorldType == EWorldType::PIE && Context.World())
				{
					if (UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(Context.World()))
					{
						KGActorID ActorID = ActorManager->GetActorIDByEntityID(EntityID);
						return ActorID;
					}
				}
			}
			return KG_INVALID_ACTOR_ID;
		}

		TWeakObjectPtr<AActor> get_actor_by_actor_id(KGActorID ActorID) const
		{
			return KGUtils::GetActorByID(ActorID);
		}

		KGActorID get_actor_id_by_actor(TWeakObjectPtr<AActor> Actor) const
		{
			if(UObject* ActorObject = Cast<UObject>(Actor))
				return KGUtils::GetIDByObject(ActorObject);
			return KG_INVALID_ACTOR_ID;
		}
		
		bool is_in_play_in_editor() const
		{
			if (GEditor && GEditor->IsPlaySessionInProgress())
			{
				return true;
			}
			return false;
		}
		
		void excute_gm_command(FString Command, FString Data) const
		{
			UKGSceneRuntimeEditorManager* SceneManager = GetSceneRuntimeEditorManager();
			if(SceneManager)
			{
				SceneManager->ExcuteGMCommand(Command, Data);
			}
		}

		void do_fill_scene_actor_property(KGEntityID EntityID, UObject* EpActor, int TemplateType, int64 TemplateID) const
		{
			UKGSceneRuntimeEditorManager* SceneManager = GetSceneRuntimeEditorManager();
			if(SceneManager)
			{
				SceneManager->DoFillSceneActorPropertyWithTemplateID(EntityID, EpActor, TemplateType, TemplateID);
			}
		}

		FString get_lua_data(FString Command) const
		{
			UKGSceneRuntimeEditorManager* SceneManager = GetSceneRuntimeEditorManager();
			if(SceneManager)
			{
				return SceneManager->GetLuaData(Command);
			}
			return "";
		}
		
		FString get_property_str_by_actor_id(KGActorID ActorID, const TMap<FString, FString>* ExProps) const
		{
			AActor* SceneActor = KGUtils::GetActorByID(ActorID);
			if(!SceneActor)
				return "";
			FString LuaStr = FLuaSerializeHelper::ExportActorToLuaStr(SceneActor, ExProps);
			return LuaStr;
		}
		
		void fill_actor_property_by_lua_str(TWeakObjectPtr<UObject> Target, FString LuaStr) const
		{
			if(!Target.IsValid())
				return;
			UGameInstance* GI = UGameplayStatics::GetGameInstance(Target.Get());
			if (GI)
			{
				UKGGameInstanceBase* KGGI = Cast<UKGGameInstanceBase>(GI);
				if (KGGI == nullptr)
					return;
				
				ULuaGameInstance* LGI = KGGI->GetLuaGameInstance();
				if (LGI == nullptr)
					return;
				
				if(AActor* TargetActor = Cast<AActor>(Target))
				{
					FLuaSerializeHelper::FillActorWithLuaStr(LGI->GetLuaState(), TargetActor, LuaStr);
				}
			}
		}
		
		TWeakObjectPtr<UObject> spawn_actor_by_blueprint(TWeakObjectPtr<UWorld> CurrentWorld, FString Path) const
		{
			// 没有指定World的话 取PIE的默认的World
			if(!CurrentWorld.IsValid())
			{
				if (!GEngine)
					return nullptr;
				const TIndirectArray<FWorldContext>& WorldContexts = GEngine->GetWorldContexts();
				for (const FWorldContext& Context : WorldContexts)
				{
					if (Context.WorldType == EWorldType::PIE && Context.World())
						CurrentWorld = Context.World();
				}
			}
			if(!CurrentWorld.IsValid())
				return nullptr;
			UClass* LoadedBPClass = LoadClass<AActor>(nullptr, *Path);
			AActor* Actor = CurrentWorld->SpawnActor<AActor>(LoadedBPClass, FVector(), FRotator());
			return Actor;
		}

		
		// 修改之前C7自定义的Struct蓝图的指定属性 python内无法直接修改
		void set_object_struct_transform(TWeakObjectPtr<UObject> TargetObject, FString StructPropertyName, FString TargetPosName, FVector PosValue, FString TargetRotateName, FRotator NewRotate) const
		{
			if (!TargetObject.IsValid())
			{
				return;
			}
			FProperty* FoundProperty = TargetObject->GetClass()->FindPropertyByName(*StructPropertyName);
			if (!FoundProperty)
			{
				return;
			}

			FStructProperty* StructProp = CastField<FStructProperty>(FoundProperty);
			if (!StructProp)
			{
				return;
			}
			
			void* StructInstancePtr = StructProp->ContainerPtrToValuePtr<void>(TargetObject.Get());
			UStruct* StructType = StructProp->Struct;

			if (!StructInstancePtr || !StructType)
			{
				return;
			}
			
			for (TFieldIterator<FProperty> It(StructType); It; ++It)
			{
				FProperty* InnerProp = *It;
				if (FStructProperty* VectorProp = CastField<FStructProperty>(InnerProp))
				{
					if (VectorProp->Struct == TBaseStructure<FVector>::Get() && VectorProp->GetName().Contains(TargetPosName))
					{
						void* VectorPtr = VectorProp->ContainerPtrToValuePtr<void>(StructInstancePtr);
						FVector* VectorValue = static_cast<FVector*>(VectorPtr);
						*VectorValue = PosValue;
					}
					else if(VectorProp->Struct == TBaseStructure<FRotator>::Get() && VectorProp->GetName().Contains(TargetRotateName))
					{
						void* RotatePtr = VectorProp->ContainerPtrToValuePtr<void>(StructInstancePtr);
						FRotator* RotateValue = static_cast<FRotator*>(RotatePtr);
						*RotateValue = NewRotate;
					}
				}
			}
		}

		void update_floder_info(FString FilePath, const TArray<FString>& NewAddLayers, const TArray<FString>& DeleteLayers)const
		{
			UKGSceneRuntimeEditorManager* SceneManager = GetSceneRuntimeEditorManager();
			if(SceneManager)
			{
				SceneManager->UpdateFloderInfo(FilePath, NewAddLayers, DeleteLayers);
			}
		}

		void update_head_info(KGActorID ActorID, TWeakObjectPtr<UObject> EpObject, FString HeadInfo)const
		{
			UKGSceneRuntimeEditorManager* SceneManager = GetSceneRuntimeEditorManager();
			if(SceneManager)
			{
				SceneManager->RefreshHeadInfo(ActorID, EpObject, HeadInfo);
			}
		}

		void set_anim_asset_id(KGActorID ActorID)const
		{
			AActor* TargetActor = KGUtils::GetActorByID(ActorID);
			if(TargetActor)
			{
				GPOperateUtils::SetAnimAssetIDForAnimQueue(TargetActor, false);
			}
		}


		void set_pie_or_sie(bool IsPIE)const
		{
			if(UEditorEngine* EditorEngine = Cast<UEditorEngine>(GEngine))
			{
				if((EditorEngine->bIsSimulatingInEditor && IsPIE) || !(EditorEngine->bIsSimulatingInEditor or IsPIE))
				{
					EditorEngine->RequestToggleBetweenPIEandSIE();
				}
			}
		}
		
		void select_actor_in_pie(KGActorID ActorID)const
		{
			AActor* Actor = KGUtils::GetActorByID(ActorID);
			if (GEditor && Actor)
			{
				GEditor->SelectNone(false, true);
				GEditor->SelectActor(Actor, true, false, true);
				GEditor->NoteSelectionChange();
			}
		}
		
		ULuaGameInstance* GetPIELuaGameInstance()const
		{
			const TIndirectArray<FWorldContext>& WorldContexts = GEngine->GetWorldContexts();
			for (const FWorldContext& Context : WorldContexts)
			{
				if (Context.WorldType == EWorldType::PIE && Context.World())
				{
					UGameInstance* GI = UGameplayStatics::GetGameInstance(Context.World());
					if (GI)
					{
						UKGGameInstanceBase* KGGI = Cast<UKGGameInstanceBase>(GI);
						if (KGGI == nullptr)
							return nullptr;
				
						ULuaGameInstance* LGI = KGGI->GetLuaGameInstance();
						return LGI;
					}
				}
			}
			return nullptr;
		}
		
		UKGSceneRuntimeEditorManager* GetSceneRuntimeEditorManager()const
		{
			const TIndirectArray<FWorldContext>& WorldContexts = GEngine->GetWorldContexts();
			for (const FWorldContext& Context : WorldContexts)
			{
				if (Context.WorldType == EWorldType::PIE && Context.World())
				{
					if (UKGSceneRuntimeEditorManager* SceneManager = UKGSceneRuntimeEditorManager::GetInstance(Context.World()))
					{
						return SceneManager;
					}
				}
			}
			return nullptr;
		}
	};
}

PYBIND11_UNREAL_REGISTER_TYPE_NAME(UE::Python::Internal::KGSceneEditor)

void KGPyUnreal::Initialize_KGSceneEditor(py::module_& Module)
{
	using KGSceneEditor = UE::Python::Internal::KGSceneEditor;

	auto Test_ = py::unreal_class<KGSceneEditor, TSharedPtr<KGSceneEditor>>(Module, "KGSceneEditor")
		.def(py::init())
		.def("get_actor_by_entity_id", &KGSceneEditor::get_actor_by_entity_id)
		.def("get_actor_id_by_entity_id", &KGSceneEditor::get_actor_id_by_entity_id)
		.def("get_actor_by_actor_id", &KGSceneEditor::get_actor_by_actor_id)
		.def("is_in_play_in_editor", &KGSceneEditor::is_in_play_in_editor)
		.def("excute_gm_command", &KGSceneEditor::excute_gm_command)
		.def("do_fill_scene_actor_property", &KGSceneEditor::do_fill_scene_actor_property)
		.def("get_property_str_by_actor_id", &KGSceneEditor::get_property_str_by_actor_id)
		.def("fill_actor_property_by_lua_str", &KGSceneEditor::fill_actor_property_by_lua_str)
		.def("get_lua_data", &KGSceneEditor::get_lua_data)
		.def("spawn_actor_by_blueprint", &KGSceneEditor::spawn_actor_by_blueprint)
		.def("get_actor_id_by_actor", &KGSceneEditor::get_actor_id_by_actor)
		.def("set_object_struct_transform", &KGSceneEditor::set_object_struct_transform)
		.def("update_floder_info", &KGSceneEditor::update_floder_info)
		.def("update_head_info", &KGSceneEditor::update_head_info)
		.def("set_pie_or_sie", &KGSceneEditor::set_pie_or_sie)
		.def("select_actor_in_pie", &KGSceneEditor::select_actor_in_pie)
		.def("set_anim_asset_id", &KGSceneEditor::set_anim_asset_id)
		;

}