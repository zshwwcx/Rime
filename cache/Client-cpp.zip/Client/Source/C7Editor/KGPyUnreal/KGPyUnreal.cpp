#include "KGPyUnreal.h"

#include "ContentBrowserModule.h"
#include "IImageWrapper.h"
#include "ImageUtils.h"
#include "KGPythonScriptSubModuleHelper.h"

#include "KGPyTypeNameDefinitions.h"
#include "TextureCompiler.h"
#include "pybind11/cast.h"
#include "Slate/WidgetTransform.h"

struct FUtilities
{
	static auto Package__IsDirty(UPackage* Package)
	{
		if (Package == nullptr)
		{
			return false;
		}
		return Package->IsDirty();
	}

	static auto PointerEvent__GetScreenSpacePosition(const FPointerEvent& PointerEvent)
	{
		return PointerEvent.GetScreenSpacePosition();
	}

	static auto Geometry__AbsoluteToLocal(const FGeometry& Geometry, const FVector2D& AbsoluteCoordinate)
	{
		return Geometry.AbsoluteToLocal(AbsoluteCoordinate);
	}

	static auto Geometry__LocalToAbsolute(const FGeometry& Geometry, const FVector2D& LocalCoordinate)
	{
		return Geometry.LocalToAbsolute(LocalCoordinate);
	}

	static auto WidgetTransform__ToSlateRenderTransform(const FWidgetTransform& WidgetTransform)
	{
		return WidgetTransform.ToSlateRenderTransform();
	}

	static bool Texture2D__GetPixelColor(UTexture2D* Texture, int X, int Y, FColor& OutColor)
	{
		FImage Image;
		if (!Texture->Source.GetMipImage(Image, 0, 0, 0))
		{
			return false;
		}

		if (ERawImageFormat::BGRA8 == Image.Format)
		{
			OutColor.B = Image.RawData[4 * (Image.SizeX * Y + X) + 0];
			OutColor.G = Image.RawData[4 * (Image.SizeX * Y + X) + 1];
			OutColor.R = Image.RawData[4 * (Image.SizeX * Y + X) + 2];
			OutColor.A = Image.RawData[4 * (Image.SizeX * Y + X) + 3];
			return true;
		}

		return false;
	}

	static void TextureCompilingManager__FinishCompilation(UTexture* Texture)
	{
		FTextureCompilingManager::Get().FinishCompilation(TArray<UTexture*> {Texture});
	}
};

PYBIND11_UNREAL_REGISTER_TYPE_NAME(FUtilities);

PRAGMA_DISABLE_DEPRECATION_WARNINGS
PYBIND11_MODULE(kg, Module)
{
	Module.doc() = "unreal python module exported with pybind11";

	py::class_<FUtilities>(Module, "Utilities")
		.def_static_auto_naming(FUtilities, Package__IsDirty)
		.def_static_auto_naming(FUtilities, PointerEvent__GetScreenSpacePosition)
		.def_static_auto_naming(FUtilities, Geometry__AbsoluteToLocal)
		.def_static_auto_naming(FUtilities, Geometry__LocalToAbsolute)
		.def_static_auto_naming(FUtilities, WidgetTransform__ToSlateRenderTransform)
		.def_static_auto_naming(FUtilities, TextureCompilingManager__FinishCompilation)
		.def_static(
			pybind11::convert_camel_to_underline("Texture2D__GetPixelColor").c_str(),
			[](UTexture2D* Texture, int X, int Y) -> py::handle
			{
				FColor Color;
				if (!FUtilities::Texture2D__GetPixelColor(Texture, X, Y, Color))
				{
					return py::none();
				}
#pragma push_macro("cast")
#undef cast
				return py::detail::make_caster<FColor>::cast(Color, py::return_value_policy::move, py::handle());
#pragma pop_macro("cast")
			}
		)
		.def_static_auto_naming(FUtilities, Texture2D__GetPixelColor)
		;

	py::unreal_enum<EWindowType>(Module, "WindowType")
		.value_auto_naming(EWindowType, Normal)
		.value_auto_naming(EWindowType, Menu)
		.value_auto_naming(EWindowType, ToolTip)
		.value_auto_naming(EWindowType, Notification)
		.value_auto_naming(EWindowType, CursorDecorator)
		.value_auto_naming(EWindowType, GameWindow)
		;

	py::unreal_enum<EAppReturnType::Type>(Module, "AppReturnType")
		.value_auto_naming(EAppReturnType::Type, No)
		.value_auto_naming(EAppReturnType::Type, Yes)
		.value_auto_naming(EAppReturnType::Type, YesAll)
		.value_auto_naming(EAppReturnType::Type, NoAll)
		.value_auto_naming(EAppReturnType::Type, Cancel)
		.value_auto_naming(EAppReturnType::Type, Ok)
		.value_auto_naming(EAppReturnType::Type, Retry)
		.value_auto_naming(EAppReturnType::Type, Continue)
		;

	py::unreal_enum<EAppMsgCategory>(Module, "AppMsgCategory")
		.value_auto_naming(EAppMsgCategory, Warning)
		.value_auto_naming(EAppMsgCategory, Error)
		.value_auto_naming(EAppMsgCategory, Success)
		.value_auto_naming(EAppMsgCategory, Info)
		;

	py::unreal_enum<EAppMsgType::Type>(Module, "AppMsgType")
		.value_auto_naming(EAppMsgType::Type, Ok)
		.value_auto_naming(EAppMsgType::Type, YesNo)
		.value_auto_naming(EAppMsgType::Type, OkCancel)
		.value_auto_naming(EAppMsgType::Type, YesNoCancel)
		.value_auto_naming(EAppMsgType::Type, CancelRetryContinue)
		.value_auto_naming(EAppMsgType::Type, YesNoYesAllNoAll)
		.value_auto_naming(EAppMsgType::Type, YesNoYesAllNoAllCancel)
		.value_auto_naming(EAppMsgType::Type, YesNoYesAll)
		;

	#pragma region FModuleManager
	py::unreal_class<FModuleManager>(Module, "ModuleManager")
		.def_static(
			pybind11::convert_camel_to_underline("LoadContentBrowser").c_str(),
			[]() { return UE::Python::Internal::FContentBrowserModuleRef(FModuleManager::LoadModuleChecked<FContentBrowserModule>(TEXT("ContentBrowser"))); }
		)
		.def_static(
			pybind11::convert_camel_to_underline("LoadDesktopPlatform").c_str(),
			[]() { return UE::Python::Internal::FDesktopPlatformModuleRef(FModuleManager::LoadModuleChecked<FDesktopPlatformModule>(TEXT("DesktopPlatform"))); }
		)
		;
	#pragma endregion
	
	#pragma region FContentBrowserModule
	py::unreal_class<UE::Python::Internal::FContentBrowserModuleRef>(Module, "ContentBrowserModule")
		.def_auto_naming(UE::Python::Internal::FContentBrowserModuleRef, AddAssetViewContextMenuExtender)
		.def_auto_naming(UE::Python::Internal::FContentBrowserModuleRef, RemoveAssetViewContextMenuExtender)
		.def_auto_naming(UE::Python::Internal::FContentBrowserModuleRef, RemoveAllAssetViewContextMenuExtenders)
		.def_auto_naming(UE::Python::Internal::FContentBrowserModuleRef, Get)
		;
	#pragma endregion
	
	#pragma region IContentBrowserSingleton
	py::unreal_class<UE::Python::Internal::IContentBrowserSingletonRef>(Module, "ContentBrowserSingleton")
		.def_auto_naming(UE::Python::Internal::IContentBrowserSingletonRef, SyncBrowserToAssets,
			py::arg(), py::arg("bAllowLockedBrowsers") = false, py::arg("bFocusContentBrowser") = true, py::arg("InstanceName") = FName(), py::arg("bNewSpawnBrowser") = false)
		;
	#pragma endregion
	
	#pragma region FDesktopPlatformModule
	py::unreal_class<UE::Python::Internal::FDesktopPlatformModuleRef>(Module, "DesktopPlatformModule")
		.def_auto_naming(UE::Python::Internal::FDesktopPlatformModuleRef, Get)
		;
	#pragma endregion
	
	#pragma region IDesktopPlatform
	py::unreal_class<UE::Python::Internal::IDesktopPlatformRef>(Module, "DesktopPlatform")
		.def(
			pybind11::convert_camel_to_underline("OpenFileDialog").c_str(),
			[](UE::Python::Internal::IDesktopPlatformRef& DesktopPlatform, py::object _0, const FString& DialogTitle, const FString& DefaultPath, const FString& DefaultFile, const FString& FileTypes, uint32 Flags, py::list OutFilenames, int32& OutFilterIndex)
			{
				TArray<FString> Filenames;
				if (!DesktopPlatform.OpenFileDialog(nullptr, DialogTitle, DefaultPath, DefaultFile, FileTypes, Flags, Filenames, OutFilterIndex))
				{
					return false;
				}
				for (auto Filename : Filenames)
				{
					OutFilenames.append(Filename);
				}
				return true;
			}
		)
		.def(
			pybind11::convert_camel_to_underline("SaveFileDialog").c_str(),
			[](UE::Python::Internal::IDesktopPlatformRef& DesktopPlatform, py::object _0, const FString& DialogTitle, const FString& DefaultPath, const FString& DefaultFile, const FString& FileTypes, uint32 Flags, py::list OutFilenames)
			{
				TArray<FString> Filenames;
				if (!DesktopPlatform.SaveFileDialog(nullptr, DialogTitle, DefaultPath, DefaultFile, FileTypes, Flags, Filenames))
				{
					return false;
				}
				for (auto Filename : Filenames)
				{
					OutFilenames.append(Filename);
				}
				return true;
			}
		)
		;
	#pragma endregion

	#pragma region FMessageDialog
	py::unreal_class<FMessageDialog>(Module, "MessageDialog")
		.def_static_overloaded_auto_naming(FMessageDialog, Debugf, void(*)(const FText&))
		.def_static_overloaded_auto_naming(FMessageDialog, Debugf, void(*)(const FText&, const FText&))
		.def_static_overloaded_auto_naming(FMessageDialog, Open, EAppReturnType::Type(*)(EAppMsgType::Type, const FText&))
		.def_static_overloaded_auto_naming(FMessageDialog, Open, EAppReturnType::Type(*)(EAppMsgType::Type, const FText&, const FText&))
		.def_static_overloaded_auto_naming(FMessageDialog, Open, EAppReturnType::Type(*)(EAppMsgCategory, EAppMsgType::Type, const FText&))
		.def_static_overloaded_auto_naming(FMessageDialog, Open, EAppReturnType::Type(*)(EAppMsgCategory, EAppMsgType::Type, const FText&, const FText&))
		.def_static_overloaded_auto_naming(FMessageDialog, Open, EAppReturnType::Type(*)(EAppMsgType::Type, EAppReturnType::Type, const FText&))
		.def_static_overloaded_auto_naming(FMessageDialog, Open, EAppReturnType::Type(*)(EAppMsgType::Type, EAppReturnType::Type, const FText&, const FText&))
		.def_static_overloaded_auto_naming(FMessageDialog, Open, EAppReturnType::Type(*)(EAppMsgCategory, EAppMsgType::Type, EAppReturnType::Type, const FText&))
		.def_static_overloaded_auto_naming(FMessageDialog, Open, EAppReturnType::Type(*)(EAppMsgCategory, EAppMsgType::Type, EAppReturnType::Type, const FText&, const FText&))
		;
	#pragma endregion
	
	#pragma region FDelegateHandle
	py::unreal_class<FDelegateHandle>(Module, "DelegateHandle")
		.def(py::init())
		.def(py::self == py::self)
		.def(py::self != py::self)
		.def_auto_naming(FDelegateHandle, IsValid)
		.def_auto_naming(FDelegateHandle, Reset)
		;
	#pragma endregion
	
	#pragma region FAssetData
	py::unreal_class<FAssetData>(Module, "AssetData")  /* TODO: 没有导出完全 */
#if WITH_EDITORONLY_DATA
		.def_readwrite_auto_naming(FAssetData, ObjectPath)
#endif
		.def_readwrite_auto_naming(FAssetData, PackageName)
		.def_readwrite_auto_naming(FAssetData, PackagePath)
		.def_readwrite_auto_naming(FAssetData, AssetName)
		.def_readwrite_auto_naming(FAssetData, AssetClass)
		.def_readwrite_auto_naming(FAssetData, AssetClassPath)
		;
	#pragma endregion

	KGPyUnreal::Initialize_BindingTest(Module);
	KGPyUnreal::Initialize_Slate(Module);
	KGPyUnreal::Initialize_KGCore(Module);
	KGPyUnreal::Initialize_KGSceneEditor(Module);
	KGPyUnreal::Initialize_KGUI(Module);
}
PRAGMA_ENABLE_DEPRECATION_WARNINGS

void KGPyUnreal::Initialize()
{
	FKGPythonScriptSubModuleHelper::FPyScopedGIL GIL;
	PyObject* SysModules = PyImport_GetModuleDict();
	PyDict_SetItemString(SysModules, "kg", PyInit_kg());
}