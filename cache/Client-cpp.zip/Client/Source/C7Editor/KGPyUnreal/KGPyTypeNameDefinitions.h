#pragma once

#include "pybind11/unreal.h"
#include "Widgets/Layout/SScaleBox.h"
#include "KGPyUnreal/PythonSlateHelpers.h"
#include "ContentBrowserModule.h"

#pragma region Helpers

namespace pybind11::unreal
{
	template <typename T1, typename T2>
	struct logical_and : std::conditional<T1::value, T2, std::false_type>::type {};
}

template <typename T>
struct ::pybind11::unreal::type_name<
	T,
	std::enable_if_t<
		::pybind11::unreal::logical_and<
			::pybind11::detail::is_unreal_base_structure<T>,
			std::is_same<T, std::remove_reference_t<std::remove_const_t<T>>>
		>::value
	>
>
{
	static std::string get() { return TCHAR_TO_UTF8(*TBaseStructure<T>::Get()->GetName()); }
};

template <typename T>
struct ::pybind11::unreal::type_name<T, std::enable_if_t<::pybind11::detail::is_unreal_object_type<T>::value>>
{
	static std::string get() { return TCHAR_TO_UTF8(*T::StaticClass()->GetName()); }
};

template <typename T>
struct ::pybind11::unreal::type_name<TObjectPtr<T>>
{
	static std::string get() { return std::string("TObjectPtr<") + ::pybind11::unreal::typeid_<T>::get().name() + std::string(">"); }
};

template <typename T>
struct ::pybind11::unreal::type_name<TWeakObjectPtr<T>>
{
	static std::string get() { return std::string("TWeakObjectPtr<") + ::pybind11::unreal::typeid_<T>::get().name() + std::string(">"); }
};

template <typename T>
struct ::pybind11::unreal::type_name<TOptional<T>>
{
	static std::string get() { return std::string("TOptional<") + ::pybind11::unreal::typeid_<T>::get().name() + std::string(">"); }
};

template <typename T>
struct ::pybind11::unreal::type_name<TAttribute<T>>
{
	static std::string get() { return std::string("TAttribute<") + ::pybind11::unreal::typeid_<T>::get().name() + std::string(">"); }
};

template <typename T>
struct ::pybind11::unreal::type_name<TSharedPtr<T>>
{
	static std::string get() { return std::string("TSharedPtr<") + ::pybind11::unreal::typeid_<T>::get().name() + std::string(">"); }
};

template <typename T>
struct ::pybind11::unreal::type_name<TWeakPtr<T>>
{
	static std::string get() { return std::string("TWeakPtr<") + ::pybind11::unreal::typeid_<T>::get().name() + std::string(">"); }
};

template <typename T>
struct ::pybind11::unreal::type_name<TSharedRef<T>>
{
	static std::string get() { return std::string("TSharedRef<") + ::pybind11::unreal::typeid_<T>::get().name() + std::string(">"); }
};

template <typename T>
struct ::pybind11::unreal::type_name<T*>
{
	static std::string get() { return ::pybind11::unreal::typeid_<T>::get().name() + std::string("*"); }
};

template <typename T>
struct ::pybind11::unreal::type_name<const T>
{
	static std::string get() { return std::string("const ") + ::pybind11::unreal::typeid_<T>::get().name(); }
};

template <typename T>
struct ::pybind11::unreal::type_name<T&>
{
	static std::string get() { return ::pybind11::unreal::typeid_<T>::get().name() + std::string("&"); }
};

template <typename T>
struct ::pybind11::unreal::type_name<TArray<T>>
{
	static std::string get() { return std::string("TArray<") + ::pybind11::unreal::typeid_<T>::get().name() + std::string(">"); }
};

namespace pybind11::unreal
{
	template <typename... ArgumentTypes>
	struct arguments_type_name
	{
		static std::string get() { return ""; }
	};

	template <typename FirstArgumentType, typename... RestArgumentTypes>
	struct arguments_type_name<FirstArgumentType, RestArgumentTypes...>
	{
		static std::string get()
		{
			std::string first = ::pybind11::unreal::typeid_<FirstArgumentType>::get().name();
			std::string rest = arguments_type_name<RestArgumentTypes...>::get();
			return first + (rest.empty() ? "" : ", ") + rest;
		}
	};
}

template <typename ReturnType, typename... ArgumentTypes>
struct ::pybind11::unreal::type_name<TDelegate<ReturnType(ArgumentTypes...)>>
{
	static std::string get()
	{
		return std::string("TDelegate<") + ::pybind11::unreal::typeid_<ReturnType>::get().name() + "(" + pybind11::unreal::arguments_type_name<ArgumentTypes...>::get() + ")>";
	}
};

template <typename ReturnType, typename... ArgumentTypes>
struct ::pybind11::unreal::type_name<TMulticastDelegate<ReturnType(ArgumentTypes...)>>
{
	static std::string get()
	{
		return std::string("TMulticastDelegate<") + ::pybind11::unreal::typeid_<ReturnType>::get().name() + "(" + pybind11::unreal::arguments_type_name<ArgumentTypes...>::get() + ")>";
	}
};

template <typename ReturnType, typename... ArgumentTypes>
struct ::pybind11::unreal::type_name<TFunction<ReturnType(ArgumentTypes...)>>
{
	static std::string get()
	{
		return std::string("TFunction<") + ::pybind11::unreal::typeid_<ReturnType>::get().name() + "(" + pybind11::unreal::arguments_type_name<ArgumentTypes...>::get() + ")>";
	}
};

#pragma endregion

#pragma region String

PYBIND11_UNREAL_REGISTER_TYPE_NAME(FString);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FText);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FName);

#pragma endregion

#pragma region Math

PYBIND11_UNREAL_REGISTER_TYPE_NAME(FVector2f);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FIntRect);

#pragma endregion

PYBIND11_UNREAL_REGISTER_TYPE_NAME(INumericTypeInterface<float>);

PYBIND11_UNREAL_REGISTER_TYPE_NAME(EWindowType);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(EVisibility);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(EWidgetUpdateFlags);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(EInvalidateWidgetReason);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(EMouseCursor::Type);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(EWindowActivationPolicy);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(EHorizontalAlignment);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(EVerticalAlignment);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(EButtonClickMethod::Type);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(EButtonTouchMethod::Type);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(EButtonPressMethod::Type);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(EOrientation);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(EWidgetClipping);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(EWidgetPixelSnapping);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(EFlowDirectionPreference);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(EFocusCause);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(ETextTransformPolicy);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(ETextFlowDirection);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(ETextShapingMethod);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(ETextJustify::Type);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(ETextOverflowPolicy);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(ETextWrappingPolicy);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(EStretchDirection::Type);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(EStretch::Type);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(EWindowAction::Type);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(EWindowMode::Type);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(EWindowZone::Type);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(ETextCommit::Type);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(ECheckBoxState);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(ESlateTickType);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(EUINavigationAction);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(EShouldThrottle);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(EWindowTransparency);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(ENavigationSource);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(EUINavigation);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(ESlateParentWindowSearchMethod);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(EPopupMethod);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(EAutoCenter);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(ESizingRule);
PYBIND11_UNREAL_REGISTER_ENUM_TYPE_NAME(ENavigationGenesis);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(ESplitterResizeMode::Type);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SSplitter::ESizeRule);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(EGuidFormats);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(ETabRole);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(ETabActivationCause);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FTabManager::ESearchPreference::Type);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(EExtensionHook::Position);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(EUserInterfaceActionType);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(EUIActionRepeatMode);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(EAppMsgType::Type);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(EAppMsgCategory);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(EAppReturnType::Type);

PYBIND11_UNREAL_REGISTER_TYPE_NAME(FSlateApplication);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FSlateApplication::FSlateTickEvent);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FSlateApplication::FUserRegisteredEvent);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FSlateApplication::FOnWindowBeingDestroyed);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FSlateApplication::FOnApplicationPreInputKeyDownListener);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FSlateApplication::FOnApplicationMousePreInputButtonDownListener);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FSlateApplication::FOnWindowDPIScaleChanged);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FSlateApplication::FOnModalLoopTickEvent);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FAppStyle);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FDelegateHandle);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(GenericApplication);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FWidgetStyle);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FSlateWindowElementList);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FWindowTransparency);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FWindowActivateEvent);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FOptionalSize);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FMenuBuilder);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FWindowTitleBarArgs);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FSlateLayoutTransform);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FCurveSequence);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FWindowDrawAttentionParameters);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FNavigationConfig);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FInputDeviceId);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FPopupLayer);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FWeakWidgetPath);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FPlatformUserId);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FWidgetPath);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FCursorReply);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FSlateApplication::FSlateLastUserInteractionTimeUpdateEvent);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FSlateApplication::FApplicationActivationStateChangedEvent);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FGenericWindow);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FDragDropOperation);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FPopupSupport);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FDisplayMetrics);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FModifierKeysState);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FSlateRenderer);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FGlobalTabmanager);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FPopupTransitionEffect);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FReply);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FSlateWidgetPersistentState);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FWidgetProxyHandle);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FSlateRect);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FSlotBase);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FArrangedChildren);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FChildren);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FSlateClippingState);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FSlateRenderTransform);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FTextLayout::FLineView);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FHittestGrid);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FWindowSizeLimits);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(UE::Slate::FDeprecateVector2DParameter);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FTabManager);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FTabSpawnerEntry);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FProxyTabmanager);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FTabManager::FLayoutNode);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FTabManager::FTab);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FTabManager::FStack);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FTabManager::FSplitter);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FTabManager::FArea);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FTabManager::FLayout);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FSpawnTabArgs);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FTabId);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FAccessibleWidgetData);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FCoreStyle);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FContentBrowserModule);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FBaseMenuBuilder);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FModuleManager);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FMenuEntryParams);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FExtender);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FAssetData);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FUICommandList);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FMenuBarBuilder);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FToolBarBuilder);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FUIAction);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FSlateIcon);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FUICommandInfo);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(FMessageDialog);

PYBIND11_UNREAL_REGISTER_TYPE_NAME(IToolTip);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(IMenuHost);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(IMenu);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(IVirtualKeyboardEntry);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(IWindowTitleBar);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(ISlateInputManager);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(ISlateViewport);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(ITableRow);

PYBIND11_UNREAL_REGISTER_TYPE_NAME(SViewport);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(STableViewBase);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SCompoundWidget);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SWidget);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SHorizontalBox);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SHorizontalBox::FArguments);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SHorizontalBox::FScopedWidgetSlotArguments);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SHorizontalBox::FSlot);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SVerticalBox);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SVerticalBox::FArguments);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SVerticalBox::FScopedWidgetSlotArguments);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SVerticalBox::FSlot);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SOverlay);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SOverlay::FArguments);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SOverlay::FScopedWidgetSlotArguments);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SOverlay::FOverlaySlot);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SSplitter);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SSplitter::FArguments);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SSplitter::FScopedWidgetSlotArguments);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SSplitter::FSlot);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SButton);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SButton::FArguments);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SBorder);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SBorder::FArguments);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(STextBlock);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(STextBlock::FArguments);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SWindow);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SWindow::FArguments);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SImage);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SImage::FArguments);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SScaleBox);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SScaleBox::FArguments);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SBox);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SBox::FArguments);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SDockTab);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SDockTab::FArguments);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SToolTip);

PYBIND11_UNREAL_REGISTER_TYPE_NAME(UE::Python::Internal::FPythonObject);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(UE::Python::Internal::SUserWidget);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(UE::Python::Internal::SUserWidget::FArguments);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(UE::Python::Internal::SPythonListView);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(UE::Python::Internal::SPythonListView::FArguments);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(UE::Python::Internal::SPythonTableRow);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(UE::Python::Internal::SPythonTableRow::FArguments);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(UE::Python::Internal::SPythonImage);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(UE::Python::Internal::SPythonBorder);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(UE::Python::Internal::SPythonButton);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(UE::Python::Internal::SPythonDockTab);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(UE::Python::Internal::FContentBrowserModuleRef);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(UE::Python::Internal::IContentBrowserSingletonRef);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(UE::Python::Internal::FDesktopPlatformModuleRef);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(UE::Python::Internal::IDesktopPlatformRef);

PYBIND11_UNREAL_REGISTER_TYPE_NAME(SNumericEntryBox<float>);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SNumericEntryBox<float>::FArguments);
PYBIND11_UNREAL_REGISTER_TYPE_NAME(SNumericEntryBox<float>::ELabelLocation);

// PYBIND11_UNREAL_REGISTER_TYPE_NAME(FKGEditorLua);
