// Fill out your co// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: guoyi06@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "EditorUtilityObject.h"
#include "UObject/Object.h"
#include "NiagaraSystem.h"
#include "NiagaraActor.h"
#include "Engine/SceneCapture2D.h"
#include "Engine/TextureRenderTarget2D.h"
#include "NiagaraVideoRecorder.generated.h"

/**
 * 
 */
UCLASS(BlueprintType, Blueprintable)
class C7EDITOR_API UNiagaraVideoRecorder : public UEditorUtilityObject
{
	GENERATED_BODY()
	
public:

	UFUNCTION(CallInEditor, BlueprintCallable,Category = "Niagara Video Recorder")
	void RecordAllNiagaraSystems();


private:
	void ProcessNext(const TArray<FAssetData>& NiagaraAssets, int Index);
	float RecordSingleSystem(class UNiagaraSystem* NiagaraAsset, const FString& OutputPath);



	void RunAfterDelay(float DelaySeconds, TFunction<void()> Callback);


	FString GetTargetNiagaraFolderFromCmd();


private:
	void SaveNiagaraAssets(const TArray<FAssetData>& NiagaraAssets);
	void LoadNiagaraAssets(TArray<FString>& OutAssetPaths);


public:

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara Video Recorder")
	int VideoSizeWidth = 1600;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara Video Recorder")
	int VideoSizeHight = 1400;


	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara Video Recorder")
	int videoOffsetX = 10;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara Video Recorder")
	int videoOffsetY = 10;


	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara Video Recorder")
	int videoRecordTime = 21;



	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara Video Recorder")
	int videoWaitTime = 25;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara Video Recorder")
	int videoOpenWaitTime = 5;


	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara Video Recorder", meta = (ContentDir, ToolTip = "target folder,if null ,it will handle all Niagara"))
	FDirectoryPath TargetFolder;


private:
	const FString OutPutFolder = TEXT("");

};
