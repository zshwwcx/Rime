// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: guoyi06@kuaishou.com
// Purpose: Generate MP4 for AI 

#include "NiagaraTools/NiagaraVideoRecorder.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "NiagaraSystem.h"
#include "Engine/World.h"
#include "Misc/Paths.h"
#include "HAL/PlatformProcess.h"

#include "Misc/Paths.h"
#include "HAL/PlatformProcess.h"
#include "Engine/World.h"
#include "TimerManager.h"
#include "Editor.h"
#include "Editor/EditorEngine.h"
#include "CoreMinimal.h"

#include "Framework/Application/SlateApplication.h"
#include "Widgets/SWindow.h"


void UNiagaraVideoRecorder::RecordAllNiagaraSystems()
{
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	FARFilter Filter;
	Filter.ClassPaths.Add(UNiagaraSystem::StaticClass()->GetClassPathName());
	Filter.bRecursiveClasses = true;


	FString FolderFromCmd = GetTargetNiagaraFolderFromCmd();


	//
	TArray<FAssetData> NiagaraAssets;


	//1. Read Record
	TArray<FString> LoadedAssetPaths;
	LoadNiagaraAssets(LoadedAssetPaths);

	if(LoadedAssetPaths.Num() > 0)
	{
		for (const FString& Path : LoadedAssetPaths)
		{
			FSoftObjectPath SoftPath(Path);
			FAssetData Asset = AssetRegistryModule.Get().GetAssetByObjectPath(SoftPath,true);
			if (Asset.IsValid())
			{
				NiagaraAssets.Add(Asset);
			}
		}
	}

	//2. Use Last Record first
	bool IsUseLastRecord = NiagaraAssets.Num() > 0;
	if(IsUseLastRecord)
	{
		UE_LOG(LogTemp, Log, TEXT("[NiagaraVideoRecorder]: Use Last Record file  "));
	}

	//3.Load Folder Asset 
	else if (!FolderFromCmd.IsEmpty())
	{
		Filter.PackagePaths.Add(*FolderFromCmd);
		AssetRegistryModule.Get().ScanPathsSynchronous({ *FolderFromCmd });

		UE_LOG(LogTemp, Log, TEXT("[NiagaraVideoRecorder]: Recording NiagaraSystems in folder (from cmd): %s"), *FolderFromCmd);
	}

	else if (!TargetFolder.Path.IsEmpty())
	{
		Filter.PackagePaths.Add(*TargetFolder.Path);
		AssetRegistryModule.Get().ScanPathsSynchronous({ *TargetFolder.Path });

		UE_LOG(LogTemp, Log, TEXT("[NiagaraVideoRecorder]: Recording NiagaraSystems in folder: %s"), *TargetFolder.Path);
	}
	else
	{
		AssetRegistryModule.Get().ScanPathsSynchronous({ TEXT("/Game") });
		UE_LOG(LogTemp, Log, TEXT("[NiagaraVideoRecorder]: Recording all NiagaraSystems in project."));
	}


	//
	if(!IsUseLastRecord)
	{
		AssetRegistryModule.Get().WaitForCompletion();

		Filter.bRecursivePaths = true;
		AssetRegistryModule.Get().GetAssets(Filter, NiagaraAssets);
	}


	if (NiagaraAssets.Num() == 0)
	{
		UE_LOG(LogTemp, Warning, TEXT("[NiagaraVideoRecorder]: No NiagaraSystem assets found."));
		return;
	}

	//record
	if(!IsUseLastRecord)
	{
		SaveNiagaraAssets(NiagaraAssets);
	}

	int index = 0;
	ProcessNext(NiagaraAssets, index);
}



float UNiagaraVideoRecorder::RecordSingleSystem(UNiagaraSystem* NiagaraAsset, const FString& OutputPath)
{
	float TotalWaitTime = 0.0f;
	if (!NiagaraAsset) return TotalWaitTime;

	// 1. OpenNiagara Window
	UAssetEditorSubsystem* AssetEditorSubsystem = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>();
	AssetEditorSubsystem->OpenEditorForAsset(NiagaraAsset);

	//
	TotalWaitTime += videoOpenWaitTime;
	TotalWaitTime += videoWaitTime; //25.0f;//record 21s

	//2. wait 5s to compile Niagara
	RunAfterDelay(videoOpenWaitTime, [ this , OutputPath , NiagaraAsset ]()
	{
		// FString FFmpegPath = TEXT("D:/workdir/2025-0826/bin/ffmpeg.exe");

		FString FFmpegPath = FPaths::RootDir() / TEXT("Tools") / TEXT("ffmpeg") / TEXT("ffmpeg.exe");
		FString Command = FString::Printf(
			TEXT("-y -f gdigrab -framerate 30  -t %d  -offset_x %d -offset_y %d -video_size %dx%d -i desktop -c:v libx264 -preset veryfast -crf 18 -pix_fmt yuv420p \"%s\""),
			videoRecordTime,
			videoOffsetX,videoOffsetY,VideoSizeWidth,VideoSizeHight,
			*OutputPath
		);

		UE_LOG(LogTemp, Log, TEXT("[NiagaraVideoRecorder]: Record Niagara with  Command : %s %s"),*FFmpegPath , *Command);
		TSharedPtr<FProcHandle> FFmpegProc = MakeShared<FProcHandle>(FPlatformProcess::CreateProc(*FFmpegPath, *Command, true, false, false, nullptr, 0, nullptr, nullptr));

		//3. start record .Record Time
		RunAfterDelay(videoWaitTime, [FFmpegProc, NiagaraAsset]()
		{
			//-t no need force close
			if (FFmpegProc.IsValid() && FFmpegProc->IsValid())
			{
				FPlatformProcess::TerminateProc(*FFmpegProc);
				FPlatformProcess::CloseProc(*FFmpegProc);
			}
			GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->CloseAllEditorsForAsset(NiagaraAsset);	//
		});
	});
	TotalWaitTime += 1.0f;

	return TotalWaitTime;

}


void UNiagaraVideoRecorder::ProcessNext(const TArray<FAssetData>& NiagaraAssets, int Index)
{
	if (Index >= NiagaraAssets.Num())
	{
		UE_LOG(LogTemp, Log, TEXT("[NiagaraVideoRecorder]: All  Niagara Record finish"));
		return;
	}


	UNiagaraSystem* NiagaraAsset = Cast<UNiagaraSystem>(NiagaraAssets[Index].GetAsset());
	float WaitNextTime = 1;
	if (NiagaraAsset)
	{

		FString AssetPath = NiagaraAssets[Index].GetAsset()->GetPathName(); // /Game/SomeFolder/MyNiagaraSystem
		FString AssetDir;
		FString AssetName;
		FString AssetExt;
		FPaths::Split(AssetPath, AssetDir, AssetName, AssetExt);


		FString RelativePath = AssetDir;
		RelativePath.RemoveFromStart(TEXT("/Game/")); //
		FString OutputDir = FPaths::ProjectSavedDir() / TEXT("NiagaraVideos") / RelativePath;



		UE_LOG(LogTemp, Log, TEXT("[NiagaraVideoRecorder]: ProcessNext AssetPath: %s :%s"), *AssetPath, *OutputDir);
		UE_LOG(LogTemp, Log, TEXT("[NiagaraVideoRecorder]: ProcessNext Progress: %d :%d ,current Niagara is :  %s"), Index, NiagaraAssets.Num() , *AssetPath);


		//
		if (!IFileManager::Get().DirectoryExists(*OutputDir))
		{
			IFileManager::Get().MakeDirectory(*OutputDir, true);
		}

		//end
		FString OutputVideo = OutputDir / (AssetName + TEXT(".mp4"));
		WaitNextTime += RecordSingleSystem(NiagaraAsset, OutputVideo);
	}

	RunAfterDelay(WaitNextTime, [this,NiagaraAssets,Index]()
		{
			this->ProcessNext(NiagaraAssets ,Index + 1);
		});
}



void UNiagaraVideoRecorder::RunAfterDelay(float DelaySeconds, TFunction<void()> Callback)
{
	double StartTime = FPlatformTime::Seconds();

	FTSTicker::GetCoreTicker().AddTicker(FTickerDelegate::CreateLambda([StartTime, DelaySeconds, Callback](float) -> bool {
		double CurrentTime = FPlatformTime::Seconds();

		if (CurrentTime - StartTime >= DelaySeconds) {
		

			Callback();
			return false; 
		}
		return true;
	
	}), 0.01f); 
}



FString UNiagaraVideoRecorder::GetTargetNiagaraFolderFromCmd()
{
	FString FolderPath;
	if (FParse::Value(FCommandLine::Get(), TEXT("-TargetNiagaraFolder="), FolderPath))
	{
		if (FolderPath.StartsWith(TEXT("/Game")))
		{
			return FolderPath;
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("[NiagaraVideoRecorder]: Invalid folder path: %s. Must start with /Game"), *FolderPath);
		}
	}
	return TEXT(""); 

}



void UNiagaraVideoRecorder::SaveNiagaraAssets(const TArray<FAssetData>& NiagaraAssets)
{
	TArray<FString> Lines;
	for (const FAssetData& Asset : NiagaraAssets)
	{
		Lines.Add(Asset.GetObjectPathString());
	}

	FString OutputDir = FPaths::ProjectSavedDir() / TEXT("NiagaraVideos");
	if (!IFileManager::Get().DirectoryExists(*OutputDir))
	{
		IFileManager::Get().MakeDirectory(*OutputDir, true);
	}
	FString SavePath = OutputDir / TEXT("NiagaraAssetList.txt");

	if (FFileHelper::SaveStringArrayToFile(Lines, *SavePath))
	{
		UE_LOG(LogTemp, Log, TEXT("[NiagaraVideoRecorder]: Saved %d Niagara assets to: %s"), Lines.Num(), *SavePath);
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("[NiagaraVideoRecorder]: Failed to save Niagara assets to: %s"), *SavePath);
	}
}


void UNiagaraVideoRecorder::LoadNiagaraAssets(TArray<FString>& OutAssetPaths)
{
	FString SavePath = FPaths::ProjectSavedDir() / TEXT("NiagaraVideos") / TEXT("NiagaraAssetList.txt");
	if (FFileHelper::LoadFileToStringArray(OutAssetPaths, *SavePath))
	{
		UE_LOG(LogTemp, Log, TEXT("[NiagaraVideoRecorder]: Loaded %d asset paths from: %s"), OutAssetPaths.Num(), *SavePath);
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("[NiagaraVideoRecorder]: Failed to load file: %s"), *SavePath);
	}
}
