// Copyright KuaiShou Games, Inc. All Rights Reserved.

#include "UMGDependencyAnalyzer.h"

#include "DesktopPlatformModule.h"
#include "Engine/Blueprint.h"
#include "Blueprint/UserWidget.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Views/SHeaderRow.h"
#include "Widgets/Views/SListView.h"
#include "EditorStyleSet.h"
#include "WidgetBlueprint.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Misc/FileHelper.h"
#include "Framework/Application/SlateApplication.h"
#include "Styling/SlateTypes.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"

TSharedPtr<FUMGDependencyAnalyzer> FUMGDependencyAnalyzer::Instance;

FUMGDependencyAnalyzer* FUMGDependencyAnalyzer::GetInstance()
{
    if (!Instance.IsValid())
    {
        Instance = MakeShareable(new FUMGDependencyAnalyzer());
    }
    
    return Instance.Get();
}

void FUMGDependencyAnalyzer::Initialize()
{
    // 初始化代码，可以为空
}

void FUMGDependencyAnalyzer::AnalyzeUMGDependency(const FString& SourcePath, const FString& TargetPath)
{
    // 保存当前路径用于方向切换时重新分析
    CurrentSourcePath = SourcePath;
    CurrentTargetPath = TargetPath;
    
    // 清空之前的结果
    DependencyResults.Empty();
    
    // 扫描源路径和目标路径中的所有UMG蓝图
    TArray<FName> SourceBlueprints = ScanUMGBlueprints(SourcePath);
    TArray<FName> TargetBlueprints = ScanUMGBlueprints(TargetPath);
    
    if (bIsForwardDependency)
    {
        // 正向依赖：分析B路径下的资源被A路径下资源引用的情况
        // 对于每个目标蓝图，检查源路径下有多少蓝图引用了它
        for (const FName& TargetBP : TargetBlueprints)
        {
            int32 TotalReferenceCount = 0;
            TArray<FName> ReferencingSources;
            
            for (const FName& SourceBP : SourceBlueprints)
            {
                int32 ReferenceCount = 0;
                if (CheckDependency(SourceBP, TargetBP, ReferenceCount) && ReferenceCount > 0)
                {
                    TotalReferenceCount += ReferenceCount;
                    ReferencingSources.Add(SourceBP);
                }
            }
            
            if (TotalReferenceCount > 0)
            {
                TSharedPtr<FDependencyInfo> Info = MakeShared<FDependencyInfo>(
                    TargetBP,                   // 被引用的资产路径
                    TotalReferenceCount,        // 总引用次数
                    ReferencingSources          // 引用它的源资产列表
                );
                
                DependencyResults.Add(Info);
            }
        }
    }
    else
    {
        // 反向依赖：分析A路径下的资源引用了B路径下多少资源
        // 对于每个源蓝图，检查它引用了目标路径下多少蓝图
        for (const FName& SourceBP : SourceBlueprints)
        {
            int32 TotalReferenceCount = 0;
            TArray<FName> ReferencedTargets;
            
            for (const FName& TargetBP : TargetBlueprints)
            {
                int32 ReferenceCount = 0;
                if (CheckDependency(SourceBP, TargetBP, ReferenceCount) && ReferenceCount > 0)
                {
                    TotalReferenceCount += ReferenceCount;
                    ReferencedTargets.Add(TargetBP);
                }
            }
            
            if (TotalReferenceCount > 0)
            {
                TSharedPtr<FDependencyInfo> Info = MakeShared<FDependencyInfo>(
                    SourceBP,                   // 引用其他资产的源资产路径
                    TotalReferenceCount,        // 总引用次数
                    ReferencedTargets           // 被它引用的目标资产列表
                );
                
                DependencyResults.Add(Info);
            }
        }
    }
    
    // 按引用计数降序排列结果
    DependencyResults.Sort([](const TSharedPtr<FDependencyInfo>& A, const TSharedPtr<FDependencyInfo>& B) {
        return A->ReferenceCount > B->ReferenceCount;
    });

	ExportToExcel();
}
// 导出依赖分析结果到Excel(CSV)文件
bool FUMGDependencyAnalyzer::ExportToExcel()
{
    if (DependencyResults.Num() == 0)
    {
        // 如果没有结果，返回失败
        return false;
    }

    // 生成文件名
    FString TimeStamp = FDateTime::Now().ToString(TEXT("%Y%m%d_%H%M%S"));
    FString FileName = FString::Printf(TEXT("UMGDependency_%s_%s.csv"), 
        bIsForwardDependency ? TEXT("Forward") : TEXT("Reverse"), 
        *TimeStamp);
        
    // 获取Saved目录路径
    FString SavedDirPath = FPaths::ProjectSavedDir() / TEXT("UMGDependencyAnalysis");
    
    // 确保目录存在
    IFileManager::Get().MakeDirectory(*SavedDirPath, true);
    
    // 完整文件路径
    FString FilePath = SavedDirPath / FileName;
    
    // 创建CSV内容
    FString CSVContent;
    
    // 添加标题行
    if (bIsForwardDependency)
    {
        CSVContent += TEXT("被引用的公共组件,被引用次数,引用资产列表\n");
    }
    else
    {
        CSVContent += TEXT("引用公共组件的资产,引用次数,被引用的公共组件列表\n");
    }
    
    // 添加每行数据
    for (const TSharedPtr<FDependencyInfo>& Info : DependencyResults)
    {
        // 路径和引用次数
        FString Line = FString::Printf(TEXT("\"%s\",%d,\""), 
            *Info->BlueprintPath.ToString(), 
            Info->ReferenceCount);
            
    	// 相关资产列表
    	FStringBuilderBase StringBuilder;
    	for (auto referenceBy : Info->ReferencedBy)
    	{
    		StringBuilder.Append(referenceBy.ToString()).Append("\n");
    	}
        
        Line += StringBuilder.ToString();
    	Line += TEXT("\"\n");
        CSVContent += Line;
    }
    
    // 写入文件
    bool bSuccess = FFileHelper::SaveStringToFile(CSVContent, *FilePath, FFileHelper::EEncodingOptions::ForceUTF8);
    
    if (bSuccess)
    {
        // 显示成功消息
        FString Message = FString::Printf(TEXT("依赖分析报告已导出到:\n%s"), *FilePath);
        FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(Message));
        
        // 可选：在系统文件浏览器中显示文件
        FPlatformProcess::ExploreFolder(*SavedDirPath);
    }
    
    return bSuccess;
}
// FDependencyInfo结构体定义
struct FDependencyInfo
{
    FString AssetPath;                  // 被引用的资产路径
    int32 ReferenceCount;               // 引用次数
    TArray<FString> ReferencingSources; // 引用它的源资产列表
    
    FDependencyInfo(const FString& InPath, int32 InCount, const TArray<FString>& InSources = TArray<FString>())
        : AssetPath(InPath), ReferenceCount(InCount), ReferencingSources(InSources)
    {
    }
};

// 扫描指定路径下所有UMG蓝图
TArray<FName> FUMGDependencyAnalyzer::ScanUMGBlueprints(const FString& Path)
{
    TArray<FName> Results;
    
    // 获取资产注册表
    FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
    IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();
    
    // 确保资产数据已加载
    AssetRegistry.SearchAllAssets(true);
    
    // 设置过滤器
    FARFilter Filter;
    Filter.PackagePaths.Add(*Path);
    Filter.bRecursivePaths = true;
    //Filter.ClassNames.Add(UWidgetBlueprint::StaticClass()->GetFName());
	Filter.ClassPaths.Add(UWidgetBlueprint::StaticClass()->GetClassPathName());
    
    // 获取所有匹配的资产
    TArray<FAssetData> AssetList;
    AssetRegistry.GetAssets(Filter, AssetList);
    
    // 提取资产路径
    for (const FAssetData& Asset : AssetList)
    {
        // Results.Add(Asset.GetObjectPathString());
    	Results.Add(Asset.PackageName);
    }
    
    return Results;
}

// 检查源蓝图是否依赖目标蓝图
bool FUMGDependencyAnalyzer::CheckDependency(const FName& SourcePath, const FName& TargetPath, int32& OutReferenceCount)
{
    OutReferenceCount = 0;
    
    // 加载源蓝图
    UWidgetBlueprint* SourceBP = LoadObject<UWidgetBlueprint>(nullptr, *SourcePath.ToString());
    if (!SourceBP)
    {
        return false;
    }
	auto SourcePackagePath = SourceBP->GetPackage()->GetFName();
    
    // 获取资产注册表
    FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
    IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();
    
    // 获取依赖关系
    TArray<FName> Dependencies;
    AssetRegistry.GetDependencies(SourcePackagePath, Dependencies);
    
    // 检查目标路径是否在依赖列表中
    bool bFound = Dependencies.Contains(TargetPath);
    
    if (bFound)
    {
        // 分析源蓝图以获取引用计数
        // 这部分需要根据实际情况实现，可能需要遍历蓝图的所有节点
        // 此处简化为1
        OutReferenceCount = 1;
    }
    
    return bFound;
}

void FUMGDependencyAnalyzer::ShowDependencyResults()
{
    // 创建并显示结果窗口
    TSharedRef<SWindow> ResultWindow = SNew(SWindow)
        .Title(FText::FromString(TEXT("UMG依赖分析结果")))
        .ClientSize(FVector2D(800, 600))
        .SupportsMaximize(true)
        .SupportsMinimize(true);
    
    ResultWindow->SetContent(CreateResultTableWidget());
    
    FSlateApplication::Get().AddWindow(ResultWindow);
}

TSharedRef<SWidget> FUMGDependencyAnalyzer::CreateResultTableWidget()
{
    TSharedPtr<SListView<TSharedPtr<FDependencyInfo>>> ResultListView;
    
    return SNew(SVerticalBox)
        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(10)
        [
            SNew(SHorizontalBox)
            + SHorizontalBox::Slot()
            .AutoWidth()
            .VAlign(VAlign_Center)
            [
                SNew(STextBlock)
                .Text(FText::FromString(FString::Printf(TEXT("依赖分析结果 - 共 %d 项"), DependencyResults.Num())))
                .Font(FCoreStyle::GetDefaultFontStyle("Bold", 14))
            ]
            + SHorizontalBox::Slot()
            .FillWidth(1.0f)
            + SHorizontalBox::Slot()
            .AutoWidth()
            .Padding(10, 0)
            .VAlign(VAlign_Center)
            [
                SNew(SButton)
                .Text(this, &FUMGDependencyAnalyzer::GetDependencyDirectionText)
                .ToolTipText(FText::FromString("切换依赖分析方向"))
                .OnClicked(this, &FUMGDependencyAnalyzer::OnToggleDependencyDirection)
            ]
        ]
        + SVerticalBox::Slot()
        .FillHeight(1.0f)
        [
            SNew(SBorder)
            .BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
            .Padding(FMargin(0.0f, 0.0f))
            [
                SAssignNew(ResultListView, SListView<TSharedPtr<FDependencyInfo>>)
                .ItemHeight(24.0f)
                .ListItemsSource(&DependencyResults)
                .SelectionMode(ESelectionMode::Single)
                .OnGenerateRow(this, &FUMGDependencyAnalyzer::GenerateResultRow)
                .HeaderRow
                (
                    SNew(SHeaderRow)
                    + SHeaderRow::Column("AssetPath")
                    .DefaultLabel(this, &FUMGDependencyAnalyzer::GetAssetPathColumnLabel)
                    .FillWidth(0.3f)
					+ SHeaderRow::Column("AssetRefs")
					.DefaultLabel(FText::FromString(TEXT("资产引用")))
					.FillWidth(0.4f)
                    + SHeaderRow::Column("ReferenceCount")
                    .DefaultLabel(this, &FUMGDependencyAnalyzer::GetReferenceCountColumnLabel)
                    .FillWidth(0.3f)
                )
            ]
        ];
}
// 获取依赖方向按钮文本
FText FUMGDependencyAnalyzer::GetDependencyDirectionText() const
{
    return bIsForwardDependency ? 
        FText::FromString(TEXT("正向依赖(公共组件被引用)")): 
        FText::FromString(TEXT("反向依赖(引用公共组件)"));
}

// 获取资产路径列标题
FText FUMGDependencyAnalyzer::GetAssetPathColumnLabel() const
{
    return bIsForwardDependency ? 
        FText::FromString(TEXT("被引用的公共组件")) : 
        FText::FromString(TEXT("引用公共组件的资产"));
}

// 获取引用计数列标题
FText FUMGDependencyAnalyzer::GetReferenceCountColumnLabel() const
{
    return bIsForwardDependency ? 
        FText::FromString(TEXT("被引用次数")) : 
        FText::FromString(TEXT("引用次数"));
}

// 切换依赖方向并重新分析
FReply FUMGDependencyAnalyzer::OnToggleDependencyDirection()
{
    ToggleDependencyDirection();
    
    // 使用已保存的路径重新分析
    if (!CurrentSourcePath.IsEmpty())
    {
        AnalyzeUMGDependency(CurrentSourcePath);
    }
    
    return FReply::Handled();
}

TSharedRef<ITableRow> FUMGDependencyAnalyzer::GenerateResultRow(TSharedPtr<FDependencyInfo> Item, const TSharedRef<STableViewBase>& OwnerTable)
{
	FStringBuilderBase StringBuilder;
	for (auto referenceBy : Item->ReferencedBy)
	{
		StringBuilder.Append(referenceBy.ToString()).Append("\n");
	}
    return SNew(STableRow<TSharedPtr<FDependencyInfo>>, OwnerTable)
        [
            SNew(SHorizontalBox)
            + SHorizontalBox::Slot()
            .FillWidth(0.7f)
            .VAlign(VAlign_Center)
            .Padding(5.0f, 0.0f)
            [
                SNew(STextBlock)
                .Text(FText::FromString(Item->BlueprintPath.ToString()))
                // .ToolTipText(FText::FromString(FString::Join(Item->ReferencedBy, TEXT("\n"))))
            ]
			+ SHorizontalBox::Slot()
			.FillWidth(0.3f)
			.VAlign(VAlign_Center)
			.HAlign(HAlign_Center)
			[
				SNew(STextBlock)
				.Text(FText::FromString(StringBuilder.ToString()))
			]
            + SHorizontalBox::Slot()
            .FillWidth(0.3f)
            .VAlign(VAlign_Center)
            .HAlign(HAlign_Center)
            [
                SNew(STextBlock)
                .Text(FText::AsNumber(Item->ReferenceCount))
            ]
        ];
}