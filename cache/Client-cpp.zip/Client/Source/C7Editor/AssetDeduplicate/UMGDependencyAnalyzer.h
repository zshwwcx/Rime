#pragma once

#include "CoreMinimal.h"
#include "Widgets/SWidget.h"
#include "Widgets/Views/STableViewBase.h"
#include "Widgets/Views/STableRow.h"
#include "Widgets/Views/SListView.h"

/**
 * UMG蓝图依赖分析工具
 * 用于分析某一个UMG蓝图对特定目录下UMG蓝图的依赖情况
 */
class FUMGDependencyAnalyzer : public TSharedFromThis<FUMGDependencyAnalyzer>
{
public:
	// 存储依赖信息的结构体
	struct FDependencyInfo
	{
		FName BlueprintPath;	// 依赖的蓝图路径
		int32 ReferenceCount;	// 引用次数
		TArray<FName> ReferencedBy;	// 引用该蓝图的蓝图路径
		
		FDependencyInfo(const FName& InPath, int32 InCount, const TArray<FName>& InReferencedBy)
			: BlueprintPath(InPath), ReferenceCount(InCount), ReferencedBy(InReferencedBy)
		{}
		
		bool operator<(const FDependencyInfo& Other) const
		{
			return ReferenceCount > Other.ReferenceCount; // 按引用次数降序排列
		}
	};
	
	// 获取单例实例
	static FUMGDependencyAnalyzer* GetInstance();
	
	// 初始化工具
	void Initialize();
    
    // 添加方向切换方法
    void ToggleDependencyDirection()
    {
        bIsForwardDependency = !bIsForwardDependency;
    }
    
    // 获取当前方向
    bool IsForwardDependency() const { return bIsForwardDependency; }

	// 文本显示
	FText GetDependencyDirectionText() const;
	FText GetAssetPathColumnLabel() const;
	FText GetReferenceCountColumnLabel() const;
	FReply OnToggleDependencyDirection();
	
	// 分析指定UMG蓝图的依赖
	void AnalyzeUMGDependency(const FString& SourcePath = TEXT("/Game/Arts/UI_2/Blueprint/"), const FString& TargetPath = TEXT("/Game/Arts/UI_2/Blueprint/Common"));
	
	// 显示依赖分析结果
	void ShowDependencyResults();
	
private:
    FUMGDependencyAnalyzer() : bIsForwardDependency(true) {}
	static TSharedPtr<FUMGDependencyAnalyzer> Instance;

	// 到处Excel到Saved目录
	bool ExportToExcel();
	
	// 扫描目标目录中的所有UMG蓝图
	TArray<FName> ScanUMGBlueprints(const FString& Directory);
	
	// 检查源蓝图是否依赖目标蓝图
	bool CheckDependency(const FName& SourcePath, const FName& TargetPath, int32& OutReferenceCount);
	
	// 存储分析结果
    TArray<TSharedPtr<FDependencyInfo>> DependencyResults;
    bool bIsForwardDependency; // true=正向依赖(B被A引用)，false=反向依赖(A引用B)
	// 缓存的路径
	FString CurrentSourcePath;
	FString CurrentTargetPath;
	
	// 创建结果表格视图
	TSharedRef<SWidget> CreateResultTableWidget();
	
	// 生成表格行
	TSharedRef<ITableRow> GenerateResultRow(TSharedPtr<FDependencyInfo> InInfo, const TSharedRef<STableViewBase>& OwnerTable);
};
