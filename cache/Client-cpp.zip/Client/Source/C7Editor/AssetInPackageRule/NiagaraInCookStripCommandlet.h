// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Commandlets/Commandlet.h"
#include "NiagaraInCookStripCommandlet.generated.h"

/**
 * 
 */
UCLASS()
class C7EDITOR_API UNiagaraInCookStripCommandlet : public UCommandlet
{
	GENERATED_BODY()



public:
	virtual int32 Main(const FString& Params) override;


private:


	static bool StripNiagaraByEmitters(const FAssetData& NiagaraAssetData, const TArray<FString>& EmitterNames);
	static FString GetFileMD5(const FString FilePath);

	static FString GetStringArrayHash(const TArray<FString>& InArray);
};
