// Fill out your copyright notice in the Description page of Project Settings.


#include "AssetInPackageRuleCommandlet.h"


int32 UAssetInPackageRuleCommandlet::Main(const FString& Params)
{
    InitLuaEnv();

	UninitLuaEnv();

	return 0;
}


void UAssetInPackageRuleCommandlet::InitLuaEnv()
{
	LuaEnv = UEditorLuaEnv::CreateLuaEnv(UAssetInPackagRuleLuaObjGameInstance::StaticClass());
	if (UAssetInPackagRuleLuaObjGameInstance *_GameInstance =
            Cast<UAssetInPackagRuleLuaObjGameInstance>(LuaEnv->GetLuaGameInstance()))
	{

		EditorLuaObj = _GameInstance;
		EditorLuaObj->Inner_OnStart();
	}
}

void UAssetInPackageRuleCommandlet::UninitLuaEnv()
{

	if (LuaEnv)
	{
        if (UAssetInPackagRuleLuaObjGameInstance *_GameInstance =
                Cast<UAssetInPackagRuleLuaObjGameInstance>(LuaEnv->GetLuaGameInstance()))
		{
			_GameInstance->Inner_OnShutdown();
		}

		UEditorLuaEnv::DestroyLuaEnv(LuaEnv);
        LuaEnv = nullptr;
	}

	EditorLuaObj = nullptr;
}


