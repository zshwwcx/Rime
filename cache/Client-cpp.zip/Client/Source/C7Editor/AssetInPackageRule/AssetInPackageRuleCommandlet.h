// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Lua/LuaEnv.h"
#include "Commandlets/Commandlet.h"
#include "AssetInPackageRuleCommandlet.generated.h"


UCLASS()
class UAssetInPackagRuleLuaObjGameInstance : public UEditorLuaGameInstanceBase
{
	GENERATED_BODY()

public:
	virtual  FString GetLuaFilePath_Implementation() const override { return  TEXT("Editor.AssetInPackageRule.AssetRuleMain"); };



public:
	//lua端逻辑
	UFUNCTION(BlueprintImplementableEvent)
	void Inner_OnStart();


	UFUNCTION(BlueprintImplementableEvent)
	void Inner_OnShutdown();



	UFUNCTION(BlueprintCallable)
	UObject* GetOwner() {
		return GetOuter();
	};
};


/**
 * 
 */
UCLASS()
class C7EDITOR_API UAssetInPackageRuleCommandlet : public UCommandlet
{
	GENERATED_BODY()

	virtual int32 Main(const FString& Params) override;


private:

	TWeakObjectPtr<UAssetInPackagRuleLuaObjGameInstance> EditorLuaObj = nullptr;
	
	UPROPERTY(Transient)
    UEditorLuaEnv *LuaEnv = nullptr;

	void InitLuaEnv();
    void UninitLuaEnv();

};




