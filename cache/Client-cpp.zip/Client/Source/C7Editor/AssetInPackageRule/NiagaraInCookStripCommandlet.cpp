// Fill out your copyright notice in the Description page of Project Settings.


#include "AssetInPackageRule/NiagaraInCookStripCommandlet.h"

#include "NiagaraSystem.h"
#include "NiagaraEditorDataBase.h"
#include "NiagaraEmitter.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "UObject/Package.h"
#include "Misc/PackageName.h"
#include "UObject/SavePackage.h"
#include "UObject/Package.h"
#include "Misc/FileHelper.h"
#include "Misc/SecureHash.h"
#include "Exts/NiagaraEditorUtilitiesExt.h"


int32 UNiagaraInCookStripCommandlet::Main(const FString& Params)
{



	FString StripJsonFile = TEXT("");

	//init Params
	FString InStripJsonFile;
	if (FParse::Value(*Params, TEXT("StripJsonFile="), InStripJsonFile))
	{
		StripJsonFile = InStripJsonFile;
	}
	UE_LOG(LogTemp, Display, TEXT("StripJsonFile = %s"), *StripJsonFile);



	//
	FString InBackUpFolder;
	FString BackUpFolder;
	if (FParse::Value(*Params, TEXT("BackUpFolder="), InBackUpFolder))
	{
		BackUpFolder = InBackUpFolder;
		UE_LOG(LogTemp, Display, TEXT("StripRecordFile: %s"), *BackUpFolder);
	}

	//
	if (!IFileManager::Get().FileExists(*StripJsonFile))
	{
		UE_LOG(LogTemp, Display, TEXT("UNiagaraInCookStripCommandlet::Main StripJsonFile  %s  : File Not Exist ! So Return "),*StripJsonFile);
		return 0;
	}

	//1. Get All Directory
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	TArray<FString> ContentPaths;
	ContentPaths.Add(TEXT("/Game/"));
	AssetRegistryModule.Get().ScanPathsSynchronous(ContentPaths, true);

	IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();


	//
	FString JsonString;
	if (FFileHelper::LoadFileToString(JsonString, *StripJsonFile))
	{
		TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(JsonString);
		TSharedPtr<FJsonObject> JsonObject;
		if (FJsonSerializer::Deserialize(Reader, JsonObject) && JsonObject.IsValid())
		{
			int index = 0;
			int totalIndex = JsonObject->Values.Num();


			for (const auto& Pair : JsonObject->Values)
			{
				index++;

				//记录所有Emitters 
				const TArray<TSharedPtr<FJsonValue>>* ValueArray;
				TArray<FString> EmitterNames;

				if (Pair.Value->TryGetArray(ValueArray))
				{
					for (const TSharedPtr<FJsonValue>& Val : *ValueArray)
					{
						FString EmitterName = Val->AsString();
						EmitterNames.Add(EmitterName);
					}
				}

				//
				FString NiagaraPath = Pair.Key;
				
				FString NiagaraContentPath = NiagaraPath.Replace(TEXT("/Game"), TEXT("/Content"));
				FString NiagaraOriFilePath = FPaths::ProjectDir() / NiagaraContentPath + TEXT(".uasset");


				if(!IFileManager::Get().FileExists(*NiagaraOriFilePath) )
				{
					UE_LOG(LogTemp, Log, TEXT("[NiagaraInCookStripCommandlet] Continue Because NiagaraOriFilePath  : %s Not Exist !"), *NiagaraOriFilePath);
					continue;
				}

				//
				FString NiagaraOriFileMd5 = GetFileMD5(NiagaraOriFilePath);
				if(NiagaraOriFileMd5 == "")
				{
					UE_LOG(LogTemp, Log, TEXT("[NiagaraInCookStripCommandlet] Continue Because NiagaraOriFilePath  : %s Not Exist !"), *NiagaraOriFilePath);
					continue;
				}

				//算法哈希
				FString NiagaraEmitterMd5 = GetStringArrayHash(EmitterNames);

				//哈希记录，如果文件存在则使用
				FString NiagaraBackUPFilePath = BackUpFolder / NiagaraContentPath + TEXT(".uasset")  + TEXT("_") + NiagaraOriFileMd5  + TEXT("_") +  NiagaraEmitterMd5;
				if (IFileManager::Get().FileExists(*NiagaraBackUPFilePath))
				{
					FPlatformFileManager::Get().GetPlatformFile().SetReadOnly(*NiagaraOriFilePath, false);
					IFileManager::Get().Copy(*NiagaraOriFilePath, *NiagaraBackUPFilePath);
					UE_LOG(LogTemp, Log, TEXT("[NiagaraInCookStripCommandlet]  %s  Use History  BackUp File :%s !"), *NiagaraOriFilePath ,*NiagaraBackUPFilePath);
					continue;
				}
	
	

		
				if (EmitterNames.Num() > 0) {

					FString AssetName = FPaths::GetBaseFilename(NiagaraPath);
					FString NiagaraObjectPath = NiagaraPath + TEXT(".") + AssetName;


					const FAssetData& AssetData = AssetRegistry.GetAssetByObjectPath(NiagaraObjectPath);
					UObject* Object = Cast<UNiagaraSystem>(AssetData.GetAsset());
					if(Object == nullptr)
					{
						UE_LOG(LogTemp, Warning, TEXT("[NiagaraInCookStripCommandlet] Strip  Niagara Failed ,Because  NiagaraPath : %s "), *NiagaraObjectPath);
						continue;
					}

					bool isSuccess = StripNiagaraByEmitters(AssetData, EmitterNames);
					//backup
					if(isSuccess)
					{
						FString BackTargetFolder = FPaths::GetPath(NiagaraBackUPFilePath);
						if (!IFileManager::Get().DirectoryExists(*BackTargetFolder))
						{
							IFileManager::Get().MakeDirectory(*BackTargetFolder, true);
						}
						IFileManager::Get().Copy( *NiagaraBackUPFilePath, *NiagaraOriFilePath);


						//need BackUpLatest: 
						FString NiagaraLatestFilePath = BackUpFolder / NiagaraContentPath + TEXT(".uasset");
						IFileManager::Get().Copy(*NiagaraLatestFilePath, *NiagaraOriFilePath,1);

					}

					UE_LOG(LogTemp, Log, TEXT("[NiagaraInCookStripCommandlet] Strip  Niagara : %s , Emitters : %s ,index/totalIndex:  %d/%d"), *NiagaraPath, *FString::Join(EmitterNames, TEXT(",")), index, totalIndex);
				}
			}

		}else
		{
			UE_LOG(LogTemp, Error, TEXT("Failed to parse json StripJsonFile: %s"), *StripJsonFile);
		}

	}else
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to read json StripJsonFile: %s"), *StripJsonFile);
		return -1;
	}

	return 0;
}


bool UNiagaraInCookStripCommandlet::StripNiagaraByEmitters(const FAssetData& NiagaraAssetData, const TArray<FString>& EmitterNames)
{

	UNiagaraSystem* NiagaraSystem = Cast<UNiagaraSystem>(NiagaraAssetData.GetAsset());

	if (!NiagaraSystem)
	{

		return false;;
	}

	UNiagaraEffectType* EffectType = NiagaraSystem->GetEffectType();
	if (!EffectType)
	{
		return false;
	}

	TSet<FGuid> RemoveEmitterIds;

	//剔除
	for (const FNiagaraEmitterHandle& Handle : NiagaraSystem->GetEmitterHandles())
    {
        FString EmitterName = Handle.GetName().ToString();
		if(EmitterNames.Contains(EmitterName))
		{
			FGuid EmitterId = Handle.GetId();
			RemoveEmitterIds.Add(EmitterId);
		}
    }
	if(RemoveEmitterIds.Num() > 0)
	{
		//去除readonly
		UPackage* Package = NiagaraSystem->GetOutermost();
		FString FilePath = FPackageName::LongPackageNameToFilename(Package->GetName(), FPackageName::GetAssetPackageExtension());
		FPlatformFileManager::Get().GetPlatformFile().SetReadOnly(*FilePath, false);


		NiagaraSystem->Modify();
		FNiagaraEditorUtilitiesExt::RemoveEmittersFromSystemByEmitterHandleIdExt(*NiagaraSystem, MoveTemp(RemoveEmitterIds));
		NiagaraSystem->RequestCompile(true);
		NiagaraSystem->WaitForCompilationComplete();



		//
		FSavePackageArgs SaveArgs;
		SaveArgs.TopLevelFlags = RF_Public | RF_Standalone;
		SaveArgs.SaveFlags = SAVE_NoError;
		SaveArgs.bWarnOfLongFilename = false;

		//
		FSavePackageResultStruct PackageSaveResult = UPackage::Save(Package, NiagaraSystem, *FilePath, SaveArgs);
		if (PackageSaveResult.Result == ESavePackageResult::Success)
		{
			UE_LOG(LogTemp, Display, TEXT("UNiagaraInCookStripCommandlet::StripNiagaraByEmitters:[SAVE] %s -> %s"), *NiagaraSystem->GetName(), *FilePath);
		}
		//
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("UNiagaraInCookStripCommandlet::StripNiagaraByEmitters:[SAVE FAILED] %s"), *NiagaraSystem->GetName());
			return false;
		}
	}

	return true;
}


FString UNiagaraInCookStripCommandlet::GetFileMD5(const FString FilePath)
{
	TArray<uint8> FileData;

	// 读取文件到字节数组
	if (!FFileHelper::LoadFileToArray(FileData, *FilePath))
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to read file: %s"), *FilePath);
		return TEXT("");
	}

	// 计算 MD5
	FMD5 MD5;
	MD5.Update(FileData.GetData(), FileData.Num());

	uint8 Digest[16];
	MD5.Final(Digest);

	FString MD5Str = BytesToHex(Digest, 16);

	return MD5Str;
}

FString UNiagaraInCookStripCommandlet::GetStringArrayHash(const TArray<FString>& InArray)
{
	uint32 Hash = 0;
	for (const FString& Str : InArray) 
	{
		Hash = FCrc::StrCrc32(*Str, Hash);
	}

	return FString::Printf(TEXT("%u"), Hash);
}

