#pragma once

#include "ToolMenuContext.h"

struct FAkEventRefStruct
{
	FString AkAudioBankNamesStr;
	FString ReferencerNamesStr;
	FString FlowChartNamesStr;
	FString LuaNamesStr;
	FString ExcelNamesStr;

	bool HasRef() const;
};

class KGAudioRefHelper
{
public:
	static void AkEventReferencesExecuteActionFunc(const FToolMenuContext& InContext);
	static bool AkEventReferencesIsActionVisibleFunc(const FToolMenuContext& InContext);

	static void GenerateAllAkEventReferences();
private:
	static void GetAkEventsRefStruct(const TArray<FAssetData>& AkEventAssetDataList, TMap<FString, FAkEventRefStruct>& OutAkEvent2RefStruct);

	static void AppendStrToCSVContent(FString& CSVContent, const FString& AppendStr);
};
