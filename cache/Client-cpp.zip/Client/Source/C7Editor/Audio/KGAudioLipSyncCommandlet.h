// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Commandlets/Commandlet.h"
#include "KGAudioLipSyncCommandlet.generated.h"

class UAnimSequence;
class USkeletalMesh;

UENUM()
enum class EGenderType : uint8
{
	Male,
	Female,
	Default,
};

struct FAssetToSave
{
	UAnimSequence* Anim;
	FString PackageFileName;
	FString AssetName;
};

UCLASS()
class C7EDITOR_API UKGAudioLipSyncCommandlet : public UCommandlet
{
	GENERATED_BODY()

public:
	virtual int32 Main(const FString& Params) override;

private:
	void ProcessLipSyncGroup(bool bReimportAll, const FString& SourceSubDir, const FString& TargetAssetBasePath, int32 SubDirComponentIndex, const FString& AssetNamePrefix, bool bUpdateLuaAssetFile);

	/**
	-	 * @brief Import fbx to animation sequence
	 * @param InFbxPath The fbx file path
	 * @param InPackagePath The package path to create asset
	 * @param InAssetName The asset name
	 * @return The created animation sequence
	 */
	UAnimSequence* ImportFbxToAnimSequence(const FString& InFbxPath, const FString& InPackagePath, const FString& InAssetName);

	/**
	 * @brief Set Retarget Source for animation sequence
	 * @param InAnimSequence The animation sequence to set
	 * @param InGenderType The gender type
	 */
	void SetRetargetSource(UAnimSequence* InAnimSequence, EGenderType InGenderType);

	/**
	 * @brief Get gender type from file name
	 * @param InFileName The file name
	 * @return The gender type
	 */
	EGenderType GetGenderType(const FString& InFileName) const;
};