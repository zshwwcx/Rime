#include "KGAudioLipSyncCommandlet.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "AssetToolsModule.h"
#include "Factories/FbxAnimSequenceImportData.h"
#include "Factories/FbxImportUI.h"
#include "AssetImportTask.h"
#include "Animation/AnimSequence.h"
#include "HAL/FileManager.h"
#include "ObjectTools.h"
#include "UObject/SavePackage.h"
#include "Animation/Skeleton.h"
#include "Misc/FileHelper.h"
#include "Internationalization/Regex.h"
#include "SourceControlHelpers.h"
#include "FileAsset/Serialization/GPLuaSerializeHelper.h"

int32 UKGAudioLipSyncCommandlet::Main(const FString& Params)
{
	UE_LOG(LogTemp, Log, TEXT("[LipSync] UKGAudioLipSyncCommandlet::Main Begin"));

	TArray<FString> Tokens;
	TArray<FString> Switches;
	UCommandlet::ParseCommandLine(*Params, Tokens, Switches);

	const bool bReimportAll = Switches.Contains(TEXT("ReimportAll"));
	if (Switches.Contains(TEXT("RunningFromUnrealEd")))
	{
		UseCommandletResultAsExitCode = true;
		FastExit = true;
	}

	// Process regular dialog lip-sync
	ProcessLipSyncGroup(bReimportAll, TEXT("AI_Dialog"), TEXT("/Game/Arts/Character/Animation/LipSync"), 2, TEXT(""), true);

	// Process cutscene lip-sync
	ProcessLipSyncGroup(bReimportAll, TEXT("AI_CutScene"), TEXT("/Game/Arts/Cinematics/Design/MainStory/FaceAni"), 1, TEXT("A_F_"), false);

	UE_LOG(LogTemp, Log, TEXT("[LipSync] LipSync process finished"));
	return 0;
}

void UKGAudioLipSyncCommandlet::ProcessLipSyncGroup(bool bReimportAll, const FString& SourceSubDir, const FString& TargetAssetBasePath, int32 SubDirComponentIndex, const FString& AssetNamePrefix, bool bUpdateLuaAssetFile)
{
	UE_LOG(LogTemp, Log, TEXT("[LipSync] Processing group: Source='%s', Target='%s', Prefix='%s'"), *SourceSubDir, *TargetAssetBasePath, *AssetNamePrefix);

	TMap<FString, FString> LipSyncAssets;
	FString LipSyncAssetLuaPath = FPaths::ProjectContentDir() / TEXT("Script/Data/Config/LipSync/LipSyncAsset.lua");
	LipSyncAssetLuaPath = FPaths::ConvertRelativePathToFull(LipSyncAssetLuaPath);

	if (bUpdateLuaAssetFile && !bReimportAll)
	{
		FString FileContent;
		if (FFileHelper::LoadFileToString(FileContent, *LipSyncAssetLuaPath))
		{
			const FRegexPattern Pattern(TEXT("\\[\"([^\"]+)\"\\]\\s*=\\s*\"([^\"]+)\""));
			FRegexMatcher Matcher(Pattern, FileContent);
			while (Matcher.FindNext())
			{
				LipSyncAssets.Add(Matcher.GetCaptureGroup(1), Matcher.GetCaptureGroup(2));
			}
		}
	}

	const FString SourceDir = FPaths::ProjectSavedDir() / SourceSubDir;

	IAssetRegistry& AssetRegistry = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry").Get();
	AssetRegistry.SearchAllAssets(true);

	IFileManager& FileManager = IFileManager::Get();

	TArray<FString> FbxFiles;
	FileManager.FindFilesRecursive(FbxFiles, *SourceDir, TEXT("*.fbx"), true, false);
	TSet<FString> FbxFileNames;
	for (const FString& FbxFile : FbxFiles)
	{
		FbxFileNames.Add(FPaths::GetBaseFilename(FbxFile));
	}

	if (bReimportAll && SourceSubDir != TEXT("AI_CutScene"))
	{
		UE_LOG(LogTemp, Log, TEXT("[LipSync] ReimportAll is true. Syncing assets in %s..."), *TargetAssetBasePath);

		TArray<FAssetData> ExistingAssets;
		AssetRegistry.GetAssetsByPath(FName(*TargetAssetBasePath), ExistingAssets, true);
		TArray<UObject*> ObjectsToDelete;

		for (const FAssetData& AssetData : ExistingAssets)
		{
			if (UAnimSequence* Anim = Cast<UAnimSequence>(AssetData.GetAsset()))
			{
				FString AssetName = Anim->GetName();
				if (!AssetNamePrefix.IsEmpty() && AssetName.StartsWith(AssetNamePrefix))
				{
					AssetName.RightChopInline(AssetNamePrefix.Len());
				}

				if (!FbxFileNames.Contains(AssetName))
				{
					UE_LOG(LogTemp, Log, TEXT("[LipSync] Source for asset %s not found. Marking for deletion."), *Anim->GetName());
					ObjectsToDelete.Add(Anim);
				}
			}
		}

		if (ObjectsToDelete.Num() > 0)
		{
			UE_LOG(LogTemp, Log, TEXT("[LipSync] Deleting %d assets whose source files are missing."), ObjectsToDelete.Num());
			ObjectTools::ForceDeleteObjects(ObjectsToDelete, false);
		}
	}

	TArray<FAssetToSave> AssetsToSave;

	for (const FString& FbxPath : FbxFiles)
	{
		FString RelativePath = FbxPath;
		FPaths::MakePathRelativeTo(RelativePath, *SourceDir);
		RelativePath.ReplaceInline(TEXT("\\"), TEXT("/"));
		if (RelativePath.StartsWith(TEXT("/")))
		{
			RelativePath.RightChopInline(1, EAllowShrinking::No);
		}

		const FString DirPath = FPaths::GetPath(RelativePath);
		TArray<FString> DirComponents;
		DirPath.ParseIntoArray(DirComponents, TEXT("/"));

		FString SubDirForAsset;
		if (DirComponents.Num() > SubDirComponentIndex)
		{
			SubDirForAsset = DirComponents[SubDirComponentIndex];
		}
		else
		{
			UE_LOG(LogTemp, Log, TEXT("[LipSync] Path %s does not have the expected directory structure for %s. Skipping file."), *FbxPath, *SourceSubDir);
			continue;
		}

		const FString OriginalAssetName = FPaths::GetBaseFilename(FbxPath);
		const FString PrefixedAssetName = AssetNamePrefix + OriginalAssetName;
		const FString PackagePath = FPaths::Combine(TargetAssetBasePath, SubDirForAsset);
		const FString AssetPath = FPaths::Combine(PackagePath, PrefixedAssetName + TEXT(".") + PrefixedAssetName);

		FAssetData FoundAsset = AssetRegistry.GetAssetByObjectPath(FSoftObjectPath(AssetPath));
		if (FoundAsset.IsValid() && !bReimportAll)
		{
			UE_LOG(LogTemp, Log, TEXT("[LipSync] Asset %s already exists, skipping import."), *AssetPath);
			if (bUpdateLuaAssetFile)
			{
				LipSyncAssets.Add(OriginalAssetName, FoundAsset.GetObjectPathString());
			}
			continue;
		}

		UE_LOG(LogTemp, Log, TEXT("[LipSync] Importing %s to %s"), *FbxPath, *PackagePath);
		if (UAnimSequence* NewAnim = ImportFbxToAnimSequence(FbxPath, PackagePath, PrefixedAssetName))
		{
			NewAnim->CompressionErrorThresholdScale = 0.01f;

			const EGenderType Gender = GetGenderType(OriginalAssetName);
			SetRetargetSource(NewAnim, Gender);

			NewAnim->CacheDerivedDataForCurrentPlatform();
			NewAnim->MarkPackageDirty();

			FString PackageFileName;
			if (FPackageName::TryConvertLongPackageNameToFilename(PackagePath + TEXT("/") + PrefixedAssetName, PackageFileName))
			{
				PackageFileName += FPackageName::GetAssetPackageExtension();
				AssetsToSave.Add({ NewAnim, PackageFileName, OriginalAssetName });
			}
			else
			{
				UE_LOG(LogTemp, Error, TEXT("[LipSync] Failed to convert package name to filename for %s"), *PrefixedAssetName);
			}
		}
	}

	for (const FAssetToSave& Asset : AssetsToSave)
	{
		const FString FullPath = FPaths::ConvertRelativePathToFull(Asset.PackageFileName);
		if (!USourceControlHelpers::CheckOutOrAddFile(FullPath))
		{
			UE_LOG(LogTemp, Warning, TEXT("[LipSync] Failed to check out or add asset file, source control may be unavailable. Attempting to save anyway. %s"), *FullPath);
		}

		FSavePackageArgs SaveArgs;
		SaveArgs.TopLevelFlags = RF_Public | RF_Standalone;
		SaveArgs.SaveFlags = SAVE_NoError;
		if (UPackage::Save(Asset.Anim->GetPackage(), Asset.Anim, *Asset.PackageFileName, SaveArgs).Result == ESavePackageResult::Success)
		{
			UE_LOG(LogTemp, Log, TEXT("[LipSync] Successfully saved asset to %s"), *Asset.PackageFileName);
			if (bUpdateLuaAssetFile)
			{
				LipSyncAssets.Add(Asset.AssetName, Asset.Anim->GetPathName());
			}
		}
		else
		{
			UE_LOG(LogTemp, Error, TEXT("[LipSync] Failed to save asset %s"), *Asset.AssetName);
		}
	}

	if (bUpdateLuaAssetFile && (AssetsToSave.Num() > 0 || bReimportAll))
	{
		const FString NewFileContent = FGPLuaSerializeHelper::ExportBaseContainerToLuaStr(LipSyncAssets);
		const FString LipSyncAssetDir = FPaths::GetPath(LipSyncAssetLuaPath);
		if (!IFileManager::Get().DirectoryExists(*LipSyncAssetDir))
		{
			IFileManager::Get().MakeDirectory(*LipSyncAssetDir, true);
		}

		const bool bSCCCheckout = USourceControlHelpers::CheckOutOrAddFile(LipSyncAssetLuaPath);
		if (!bSCCCheckout)
		{
			UE_LOG(LogTemp, Warning, TEXT("[LipSync] Failed to check out or add file, source control may be unavailable. Saving file directly. %s"), *LipSyncAssetLuaPath);
		}

		if (FFileHelper::SaveStringToFile(NewFileContent, *LipSyncAssetLuaPath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), FILEWRITE_EvenIfReadOnly))
		{
			if (bSCCCheckout)
			{
				USourceControlHelpers::RevertUnchangedFile(LipSyncAssetLuaPath);
			}
		}
		else
		{
			UE_LOG(LogTemp, Error, TEXT("[LipSync] Failed to save file: %s"), *LipSyncAssetLuaPath);
		}
	}
}

UAnimSequence* UKGAudioLipSyncCommandlet::ImportFbxToAnimSequence(const FString& InFbxPath, const FString& InPackagePath, const FString& InAssetName)
{
	IAssetTools& AssetTools = FModuleManager::LoadModuleChecked<FAssetToolsModule>("AssetTools").Get();
	UAssetImportTask* ImportTask = NewObject<UAssetImportTask>();
	ImportTask->Filename = InFbxPath;
	ImportTask->DestinationPath = InPackagePath;
	ImportTask->DestinationName = InAssetName;
	ImportTask->bSave = false;
	ImportTask->bReplaceExisting = true;
	ImportTask->bAutomated = true;

	// We no longer need to set detailed options here, as KAutoImportSubsystem will handle it,just need to provide a skeleton.
	UFbxImportUI* Options = NewObject<UFbxImportUI>();
	const FString SkeletonPath = TEXT("/Game/Arts/Character/Model/Player/Avatar/M_Avatar/SKEL_3C.SKEL_3C");
	Options->Skeleton = Cast<USkeleton>(StaticLoadObject(USkeleton::StaticClass(), nullptr, *SkeletonPath));
	if (Options->Skeleton == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("[LipSync] Import Animation Failed - Skeleton is invalid: '%s'"), *SkeletonPath);
		return nullptr;
	}
	ImportTask->Options = Options;

	AssetTools.ImportAssetTasks({ ImportTask });

	if (ImportTask->GetObjects().Num() > 0)
	{
		for (UObject* ImportedObject : ImportTask->GetObjects())
		{
			if (UAnimSequence* AnimSequence = Cast<UAnimSequence>(ImportedObject))
			{
				UE_LOG(LogTemp, Log, TEXT("[LipSync] Successfully imported animation: %s"), *AnimSequence->GetName());
				FAssetRegistryModule::AssetCreated(AnimSequence);
				AnimSequence->MarkPackageDirty();
				return AnimSequence;
			}
		}
	}

	UE_LOG(LogTemp, Warning, TEXT("[LipSync] Failed to import animation from: %s"), *InFbxPath);
	return nullptr;
}

void UKGAudioLipSyncCommandlet::SetRetargetSource(UAnimSequence* InAnimSequence, EGenderType InGenderType)
{
	if (!InAnimSequence)
	{
		return;
	}

	FName RetargetSourceName;
	switch (InGenderType)
	{
	case EGenderType::Male:
		RetargetSourceName = FName(TEXT("SK_Base_M"));
		break;
	case EGenderType::Female:
		RetargetSourceName = FName(TEXT("SK_Base_F"));
		break;
	default:
		RetargetSourceName = FName(TEXT("SK_Base_M"));
		break;
	}

	InAnimSequence->RetargetSource = RetargetSourceName;
}

EGenderType UKGAudioLipSyncCommandlet::GetGenderType(const FString& InFileName) const
{
	if (InFileName.EndsWith(TEXT("_Male"), ESearchCase::IgnoreCase))
	{
		return EGenderType::Male;
	}
	if (InFileName.EndsWith(TEXT("_Female"), ESearchCase::IgnoreCase))
	{
		return EGenderType::Female;
	}
	// Default case or add more logic
	return EGenderType::Male;
}