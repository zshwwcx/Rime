#include "KGAudioRefHelper.h"

#include "AkAudioBank.h"
#include "AkAudioEvent.h"
#include "ContentBrowserMenuContexts.h"
#include "AssetRegistry/AssetRegistryModule.h"

bool FAkEventRefStruct::HasRef() const
{
	return !ReferencerNamesStr.IsEmpty() || !FlowChartNamesStr.IsEmpty()
			|| !LuaNamesStr.IsEmpty() || !ExcelNamesStr.IsEmpty();
}

void KGAudioRefHelper::AkEventReferencesExecuteActionFunc(const FToolMenuContext& InContext)
{
	if (UContentBrowserAssetContextMenuContext* Context = InContext.FindContext<UContentBrowserAssetContextMenuContext>())
	{
		bool bGenerateFile = false;
		const FString FolderPath = FPaths::ProjectIntermediateDir() + "C7AudioRef";
		FAssetRegistryModule& AssetRegistryModule = FModuleManager::GetModuleChecked<FAssetRegistryModule>("AssetRegistry");

		TMap<FString, FAkEventRefStruct> AkEvent2RefStruct;
		GetAkEventsRefStruct(Context->SelectedAssets, AkEvent2RefStruct);

		for (const auto& [AkEventName, AkEventRefStruct] : AkEvent2RefStruct)
		{
			// Define CSV content
			FString CSVContent;
			CSVContent.Append(TEXT("AkEvent,关联的Bank,UE资产,FlowChart,Lua,Excel\n"));  // Headers
			// Add AssetName
			CSVContent.Append(AkEventName);
			CSVContent.Append(TEXT(","));

			AppendStrToCSVContent(CSVContent, AkEventRefStruct.AkAudioBankNamesStr);
			AppendStrToCSVContent(CSVContent, AkEventRefStruct.ReferencerNamesStr);
			AppendStrToCSVContent(CSVContent, AkEventRefStruct.FlowChartNamesStr);
			AppendStrToCSVContent(CSVContent, AkEventRefStruct.LuaNamesStr);
			AppendStrToCSVContent(CSVContent, AkEventRefStruct.ExcelNamesStr);

			// 生成 excel
			FString FilePath = FolderPath + "/" + AkEventName + TEXT("_Ref.csv");
			FFileHelper::SaveStringToFile(CSVContent, *FilePath, FFileHelper::EEncodingOptions::ForceUTF8);
			bGenerateFile = true;
		}
		if (bGenerateFile)
		{
			FPlatformProcess::ExploreFolder(*FPaths::ConvertRelativePathToFull(FolderPath));
		}
	}
}

bool KGAudioRefHelper::AkEventReferencesIsActionVisibleFunc(const FToolMenuContext& InContext)
{
	if (UContentBrowserAssetContextMenuContext* Context = InContext.FindContext<UContentBrowserAssetContextMenuContext>())
	{
		bool bAkAudioEvent = false;
		for(auto& AssetData : Context->SelectedAssets)
		{
			FString AssetClassPathString = AssetData.AssetClassPath.ToString();
			const UClass* AssetClass = LoadObject<UClass>(nullptr, *AssetClassPathString);
			if (!AssetClass) return false;
			if (AssetClass->IsChildOf(UAkAudioEvent::StaticClass()))
			{
				bAkAudioEvent = true;
			}
			else
			{
				return false;
			}
		}
		return bAkAudioEvent;
	}
	return false;
}

void KGAudioRefHelper::GenerateAllAkEventReferences()
{
	// 获取资产注册表模块
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();

	// 设置筛选器以查找特定类类型的资产
	FARFilter Filter;
	Filter.ClassPaths.Add(UAkAudioEvent::StaticClass()->GetClassPathName());
	Filter.bRecursiveClasses = true; // 确保包括子类

	// 存储结果的数组
	TArray<FAssetData> AssetDataList;
	AssetRegistry.GetAssets(Filter, AssetDataList);

	// 遍历并打印每个找到的UAkAudioEvent资产
	TMap<FString, FAkEventRefStruct> AkEvent2RefStruct;
	GetAkEventsRefStruct(AssetDataList, AkEvent2RefStruct);

	const FString FolderPath = FPaths::ProjectIntermediateDir() + "C7AudioRef/AllEventRef";
	// 有引用的汇总表格
	{
		// Define CSV content
		FString CSVContent;
		CSVContent.Append(TEXT("AkEvent,关联的Bank,UE资产,FlowChart,Lua,Excel\n"));  // Headers
		for (const auto& [AkEventName, AkEventRefStruct] : AkEvent2RefStruct)
		{
			if (!AkEventRefStruct.HasRef()) continue;

			// Add AssetName
			CSVContent.Append(AkEventName);
			CSVContent.Append(TEXT(","));
			AppendStrToCSVContent(CSVContent, AkEventRefStruct.AkAudioBankNamesStr);
			AppendStrToCSVContent(CSVContent, AkEventRefStruct.ReferencerNamesStr);
			AppendStrToCSVContent(CSVContent, AkEventRefStruct.FlowChartNamesStr);
			AppendStrToCSVContent(CSVContent, AkEventRefStruct.LuaNamesStr);
			AppendStrToCSVContent(CSVContent, AkEventRefStruct.ExcelNamesStr);
			CSVContent.Append(TEXT("\n"));
		}
		// 生成 excel
		const FString FilePath = FolderPath + "/" + TEXT("AllEvent_Ref.csv");
		FFileHelper::SaveStringToFile(CSVContent, *FilePath, FFileHelper::EEncodingOptions::ForceUTF8);
		FPlatformProcess::ExploreFolder(*FPaths::ConvertRelativePathToFull(FolderPath));
	}
	// 没有引用的表格
	{
		// 特定后缀视为有用的，没有引用的表格需要过滤掉这些资产
		const TArray<FString> SuffixesToFilter = {"_1P", "_2P", "_3P"};
		// Define CSV content
		FString CSVContent;
		CSVContent.Append(TEXT("AkEvent\n"));  // Headers
		for (const auto& [AkEventName, AkEventRefStruct] : AkEvent2RefStruct)
		{
			if (!AkEventRefStruct.HasRef())
			{
				bool bShouldFilter = false;
				for (const FString& Suffix : SuffixesToFilter)
				{
					if (AkEventName.EndsWith(Suffix))
					{
						bShouldFilter = true;
						break;
					}
				}
				if (bShouldFilter) continue;
				
				CSVContent.Append(AkEventName);
				CSVContent.Append(TEXT("\n"));
			}
		}
		// 生成 excel
		const FString FilePath = FolderPath + "/" + TEXT("AllEvent_WithoutRef.csv");
		FFileHelper::SaveStringToFile(CSVContent, *FilePath, FFileHelper::EEncodingOptions::ForceUTF8);
		FPlatformProcess::ExploreFolder(*FPaths::ConvertRelativePathToFull(FolderPath));
	}
}

void KGAudioRefHelper::GetAkEventsRefStruct(const TArray<FAssetData>& AkEventAssetDataList, TMap<FString, FAkEventRefStruct>& OutAkEvent2RefStruct)
{
	// 获取资产注册表模块
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();

	// 所有资产的引用 lua 列表，audio 单独处理过 flowchart
	TArray<FString> AssetRefLines;
	const FString LuaAssetListCSVFilePath = FPaths::Combine(FPaths::ProjectContentDir(), TEXT("../../Tools/CIConfig/LuaAsset/LuaAssetList_10000.csv"));
	FString LuaAssetListCSVContent;
	if (FFileHelper::LoadFileToString(LuaAssetListCSVContent, *LuaAssetListCSVFilePath))
	{
		LuaAssetListCSVContent.ParseIntoArrayLines(AssetRefLines);
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("Failed to load CSV file: %s"), *LuaAssetListCSVFilePath);
		return;
	}

	// 引用 lua 的白名单，白名单内文件不算做被引用
	// TODO. 应该加载某处的白名单配置，这里暂时只记录 AkAudioEventData
	const TArray<FString> WhiteList = {
		"AkAudioEventData.lua"
	};

	TMap<FString, TArray<FString>> AssetPackageName2RefFiles;
	for (const FString& Line : AssetRefLines)
	{
		TArray<FString> Columns;
		Line.ParseIntoArray(Columns, TEXT(","));

		if (Columns.Num() >= 2)
		{
			FString FirstColumn = Columns[0].TrimStartAndEnd();
			if (!FirstColumn.IsEmpty())
			{
				TArray<FString> RefFiles = Columns;
				RefFiles.RemoveAt(0);
				AssetPackageName2RefFiles.Add(FirstColumn, RefFiles);
			}
		}
	}

	// Excel 信息从相关 lua 文件里单独提取
	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	const FString ScriptDataExcelFolderPath = FPaths::Combine(FPaths::ProjectContentDir(), TEXT("Script/Data/Excel"));
	TMap<FString, FString> ExcelLuaFileName2FilePath;
	// 检查文件夹是否存在
	if (PlatformFile.DirectoryExists(*ScriptDataExcelFolderPath))
	{
		TArray<FString> Files;
		PlatformFile.FindFilesRecursively(Files, *ScriptDataExcelFolderPath, TEXT(".lua"));

		for (const FString& FilePath : Files)
		{
			ExcelLuaFileName2FilePath.Add(FPaths::GetCleanFilename(FilePath), FilePath);
		}
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("Directory does not exist: %s"), *ScriptDataExcelFolderPath);
		return;
	}

	for (const FAssetData& AkEventAssetData : AkEventAssetDataList)
	{
		FString AkEventAssetClassPathString = AkEventAssetData.AssetClassPath.ToString();
		const UClass* AkEventAssetClass = LoadObject<UClass>(nullptr, *AkEventAssetClassPathString);
		if (!AkEventAssetClass || !AkEventAssetClass->IsChildOf(UAkAudioEvent::StaticClass())) continue;

		const FString AssetName = AkEventAssetData.AssetName.ToString();
		if (!OutAkEvent2RefStruct.Contains(AssetName)) OutAkEvent2RefStruct.Add(AssetName, {});
		FAkEventRefStruct& AkEventRefStruct = OutAkEvent2RefStruct[AssetName];

		// 1. AkAudioBankNamesStr
		TArray<FName> DependencyNames;
		AssetRegistry.GetDependencies(AkEventAssetData.PackageName, DependencyNames);

		FString AkAudioBankNamesStr;
		for (const FName& DependencyName : DependencyNames)
		{
			TArray<FAssetData> DependencyAssetData;
			AssetRegistryModule.Get().GetAssetsByPackageName(DependencyName, DependencyAssetData);
			if (DependencyAssetData.Num() > 0)
			{
				FString AssetClassPathString = DependencyAssetData[0].AssetClassPath.ToString();
				const UClass* AssetClass = LoadObject<UClass>(nullptr, *AssetClassPathString);
				if (AssetClass && AssetClass->IsChildOf(UAkAudioBank::StaticClass()))
				{
					if (!AkAudioBankNamesStr.IsEmpty()) AkAudioBankNamesStr += TEXT("\n");
					AkAudioBankNamesStr += DependencyAssetData[0].AssetName.ToString();
				}
			}
		}
		AkEventRefStruct.AkAudioBankNamesStr = AkAudioBankNamesStr;

		// 2. ReferencerNamesStr
		TArray<FName> ReferencerNames;
		AssetRegistryModule.Get().GetReferencers(AkEventAssetData.PackageName, ReferencerNames);

		// Add ReferencerNames, each on a new line within the same cell
		FString ReferencerNamesStr;
		for (int32 i = 0; i < ReferencerNames.Num(); ++i)
		{
			ReferencerNamesStr += ReferencerNames[i].ToString();
			if (i < ReferencerNames.Num() - 1)
			{
				ReferencerNamesStr += TEXT("\n"); // Newline within the same cell
			}
		}
		AkEventRefStruct.ReferencerNamesStr = ReferencerNamesStr;

		// 3. flowchart, lua, excel
		FString AkEventPackageName = AkEventAssetData.PackageName.ToString();
		if (AssetPackageName2RefFiles.Contains(AkEventPackageName))
		{
			for (const FString& RefFile : AssetPackageName2RefFiles[AkEventPackageName])
			{
				bool bSkip = false;
				for (const FString& SkipFileName : WhiteList)
				{
					if (RefFile.Contains(SkipFileName))
					{
						bSkip = true;
						break;
					}
				}
				if (!bSkip)
				{
					if (RefFile.EndsWith(".json"))
					{
						if (!AkEventRefStruct.FlowChartNamesStr.IsEmpty()) AkEventRefStruct.FlowChartNamesStr += TEXT("\n");
						AkEventRefStruct.FlowChartNamesStr += RefFile;
					}
					else
					{
						if (ExcelLuaFileName2FilePath.Contains(RefFile))
						{
							FString FileContent;
							if (FFileHelper::LoadFileToString(FileContent, *ExcelLuaFileName2FilePath[RefFile]))
							{
								TArray<FString> FileLines;
								FileContent.ParseIntoArrayLines(FileLines);
								for (const FString& FileLine : FileLines)
								{
									if (FileLine.Contains(TEXT("表名")))
									{
										if (!AkEventRefStruct.ExcelNamesStr.IsEmpty()) AkEventRefStruct.ExcelNamesStr += TEXT("\n");
										AkEventRefStruct.ExcelNamesStr += FileLine;
										break;
									}
								}
							}
							else
							{
								UE_LOG(LogTemp, Warning, TEXT("Cant load file %s to string."), *ExcelLuaFileName2FilePath[RefFile]);
							}
						}
						else
						{
							if (!AkEventRefStruct.LuaNamesStr.IsEmpty()) AkEventRefStruct.LuaNamesStr += TEXT("\n");
							AkEventRefStruct.LuaNamesStr += RefFile;
						}
					}
				}
			}
		}
	}
}

void KGAudioRefHelper::AppendStrToCSVContent(FString& CSVContent, const FString& AppendStr)
{
	CSVContent.Append(TEXT("\"")); // Start of a quoted field
	CSVContent.Append(AppendStr);
	CSVContent.Append(TEXT("\",")); // End of a quoted field
}
