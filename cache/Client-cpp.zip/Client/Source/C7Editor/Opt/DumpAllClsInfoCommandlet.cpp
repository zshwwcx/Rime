// DumpAllClsInfoCommandlet.cpp
#include "DumpAllClsInfoCommandlet.h"

#include "JsonObjectConverter.h"
#include "HAL/FileManager.h"
#include "Misc/C7Define.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "UObject/Class.h"
#include "UObject/UnrealType.h"
#include "UObject/UObjectIterator.h"


static FString GetPropertyCPPType(FProperty* Prop, uint32 AdditionalFlags = 0)
{
	uint32 ExportFlags = AdditionalFlags;

	// 处理输出参数标志
	if (Prop->HasAnyPropertyFlags(CPF_OutParm))
	{
		ExportFlags |= CPPF_ArgumentOrReturnValue;
	}

	// 获取基础类型名称
	FString TypeName = Prop->GetCPPType(nullptr, ExportFlags);

	// 处理const输入参数
	if (Prop->HasAnyPropertyFlags(CPF_ConstParm) && !Prop->HasAnyPropertyFlags(CPF_OutParm))
	{
		TypeName = "const " + TypeName;
	}

	return TypeName;
}

// 在MyReflectionDumpCommandlet.cpp中添加属性处理辅助函数
static FString GetPropertyDeclaration(FDumpClassInfo_Field& Top, const FProperty* Prop, const UClass* OwnerClass)
{
	FString Declaration;

	// 1. 处理访问修饰符
	//if (Prop->HasAnyPropertyFlags(CPF_NativeAccessSpecifiers)) {
	//	Declaration += FString::Printf(TEXT("%s:\n    "),
	//		Prop->HasAnyPropertyFlags(CPF_Protected) ? TEXT("protected") :
	//		Prop->HasAnyPropertyFlags(CPF_Private) ? TEXT("private") : TEXT("public"));
	//}

	// 2. 生成UPROPERTY宏
	TArray<FString> Specifiers;

	// 基本修饰符
	if (Prop->HasAnyPropertyFlags(CPF_Edit)) Specifiers.Add(TEXT("EditAnywhere"));
	if (Prop->HasAnyPropertyFlags(CPF_BlueprintVisible)) Specifiers.Add(TEXT("BlueprintReadWrite"));
	if (Prop->HasAnyPropertyFlags(CPF_BlueprintReadOnly)) Specifiers.Add(TEXT("BlueprintReadOnly"));
	if (Prop->HasAnyPropertyFlags(CPF_Transient)) Specifiers.Add(TEXT("Transient"));

	// 高级修饰符
	if (Prop->HasAnyPropertyFlags(CPF_Config)) Specifiers.Add(TEXT("Config"));
	if (Prop->HasAnyPropertyFlags(CPF_SaveGame)) Specifiers.Add(TEXT("SaveGame"));

	// 元数据处理
	TArray<FString> MetaData;
	if (Prop->GetMetaDataMap())
	{
		TArray<FName> OutKeys;
		Prop->GetMetaDataMap()->GetKeys(OutKeys);
		for (const auto& MetaKey : OutKeys)
		{
			//const FName& MetaKey = It.Key;
			MetaData.Add(FString::Printf(TEXT("%s=\"%s\""), *MetaKey.ToString(), *Prop->GetMetaData(MetaKey)));
		}
	}

	// 组合UPROPERTY
#if false
	if (Specifiers.Num() > 0 || MetaData.Num() > 0) {
		Declaration += TEXT("UPROPERTY(");
		TArray<FString> AllParams;
		AllParams.Append(Specifiers);
		AllParams.Append(MetaData);
		Declaration += FString::Join(AllParams, TEXT(", "));
		Declaration += TEXT(")\n    ");
	}
#endif

	// 3. 生成类型修饰符
	// CPF_ReferenceParm
	TArray<FString> TypeModifiers;
	if (Prop->HasAnyPropertyFlags(CPF_ConstParm)) TypeModifiers.Add(TEXT("const"));
	if (Prop->HasAnyPropertyFlags(CPF_OutParm) || Prop->HasAnyPropertyFlags(CPF_ReferenceParm)) TypeModifiers.Add(TEXT("mutable"));
#if false
	if (OwnerClass->HasAnyClassFlags(CLASS_Native) && Prop->IsNative()) TypeModifiers.Add(TEXT("native"));
#endif

	// 4. 生成类型名称
	FString TypeName = Prop->GetCPPType();

	// 处理容器类型
	if (const FArrayProperty* ArrayProp = CastField<FArrayProperty>(Prop))
	{
		TypeName = FString::Printf(TEXT("TArray<%s>"), *ArrayProp->Inner->GetCPPType());
	}
	else if (const FMapProperty* MapProp = CastField<FMapProperty>(Prop))
	{
		TypeName = FString::Printf(TEXT("TMap<%s, %s>"), *MapProp->KeyProp->GetCPPType(), *MapProp->ValueProp->GetCPPType());
	}
	else if (const FSetProperty* SetProp = CastField<FSetProperty>(Prop))
	{
		TypeName = FString::Printf(TEXT("TSet<%s>"), *SetProp->ElementProp->GetCPPType());
	}

	// 处理特殊类型
	if (TypeName.Contains(TEXT("TSubclassOf<")))
	{
		TypeName = TypeName.Replace(TEXT("class "), TEXT(""));
	}

	// 5. 生成变量名和附加信息
	FString VarName = Prop->GetName();
	FString Postfix;

	// 处理位域
	//if (Prop->HasAnyPropertyFlags(CPF_BitMask)) {
	//	Postfix += FString::Printf(TEXT(" : %d"), Prop->GetSize() * 8);
	//}

	// 处理静态成员
	//if (Prop->HasAnyPropertyFlags(CPF_Static)) {
	//	Declaration += TEXT("static ");
	//}

	// 组合最终声明
	Declaration += FString::Printf(TEXT("%s %s %s%s;"), *FString::Join(TypeModifiers, TEXT(" ")), *TypeName, *VarName, *Postfix);

	Top.Name = VarName;
	Top.Type = TypeName;
	Top.Expression = FString::Printf(TEXT("%s %s %s%s"), *FString::Join(TypeModifiers, TEXT(" ")), *TypeName, *VarName, *Postfix);

#if false
	// 6. 添加注释信息
	TArray<FString> Comments;
	if (Prop->HasAnyPropertyFlags(CPF_Net)) {
		Comments.Add(FString::Printf(TEXT("Replicated[%d]"), Prop->RepIndex));
	}
	if (Prop->GetOffset_ForGC() != 0) {
		Comments.Add(FString::Printf(TEXT("Offset: 0x%X"), Prop->GetOffset_ForGC()));
	}

	if (Comments.Num() > 0) {
		Declaration += TEXT(" // ") + FString::Join(Comments, TEXT(", "));
	}
#endif

	return Declaration;
}

static FString MyGetClassName(UClass* Class)
{
	if (Class->IsChildOf(AActor::StaticClass()))
	{
		return FString("A") + Class->GetName();
	}
	else
	{
		return FString("U") + Class->GetName();
	}
}

static int DumpAllCls(FDumpClassInfo_NestedNamespace& Out)
{
	// 准备输出路径
	const FString OutputDir = FPaths::ProjectSavedDir() / TEXT("ReflectionDump");
	IFileManager::Get().MakeDirectory(*OutputDir, true);

	const FString Filename = OutputDir / TEXT("ReflectionInfo.txt");
	FString OutputContent;

	// 遍历所有UClass对象
	for (TObjectIterator<UClass> ClassIt; ClassIt; ++ClassIt)
	{
		UClass* Class = *ClassIt;

		// 过滤蓝图生成的类（新增过滤条件）
		if (Class->HasAnyClassFlags(CLASS_CompiledFromBlueprint) || // 蓝图编译生成的类
			Class->GetName().StartsWith(TEXT("SKEL_")) || // 蓝图骨架类
			Class->GetOuter()->GetName().StartsWith(TEXT("/Script/BlueprintGeneratedCode"))) // 蓝图生成代码
		{
			continue;
		}

		// 过滤以Blueprint为前缀的临时类（可选）
		if (false && Class->GetName().StartsWith(TEXT("Blueprint")))
		{
			continue;
		}

		if (!Class->IsNative())
		{
			continue;
		}

		Out.Classes.AddDefaulted();
		auto& Top = Out.Classes.Top();
		Top.Name = MyGetClassName(Class);
		Top.ClsCategory = "UOBJECT";

		// 基本类信息
		OutputContent += FString::Printf(TEXT("Class: %s\n"), *Class->GetName());
		OutputContent += FString::Printf(TEXT("  ParentClass: %s\n"), *GetNameSafe(Class->GetSuperClass()));
		OutputContent += FString::Printf(TEXT("  Package: %s\n\n"), *Class->GetOutermost()->GetName());
		if (Class->GetSuperClass())
		{
			Top.Bases.Add(MyGetClassName(Class->GetSuperClass()));
		}

		// 导出属性
		OutputContent += TEXT("  Properties:\n");
		for (TFieldIterator<FProperty> PropIt(Class, EFieldIteratorFlags::ExcludeSuper); PropIt; ++PropIt)
		{
			FProperty* Property = *PropIt;

			Top.Fields.AddDefaulted();
			auto& TopField = Top.Fields.Top();

			OutputContent += FString::Printf(TEXT("    %s\n"), *GetPropertyDeclaration(TopField, Property, Class));
		}

		// 导出函数
		OutputContent += TEXT("\n  Functions:\n");
		for (TFieldIterator<UFunction> FuncIt(Class, EFieldIteratorFlags::ExcludeSuper); FuncIt; ++FuncIt)
		{
			UFunction* Function = *FuncIt;

			Top.Methods.AddDefaulted();
			auto& TopMethod = Top.Methods.Top();
			TopMethod.CantBindReason = "EngineCode";

			// 构建函数签名
			FString Signature;

			// 1. 处理返回值
			FString ReturnType = "void";
			if (FProperty* ReturnProp = Function->GetReturnProperty())
			{
				ReturnType = GetPropertyCPPType(ReturnProp, CPPF_None);
			}
			TopMethod.ReturnType = ReturnType;
			TopMethod.Name = Function->GetName();

			// 2. 处理参数列表
			TArray<FString> ParamEntries;
			for (TFieldIterator<FProperty> ParamIt(Function); ParamIt; ++ParamIt)
			{
				FProperty* Param = *ParamIt;
				if (Param->HasAnyPropertyFlags(CPF_ReturnParm)) continue;

				// 获取参数类型和名称
				FString ParamType = GetPropertyCPPType(Param);
				FString ParamName = Param->GetName();

				// 处理输出参数修饰符
				if (Param->HasAnyPropertyFlags(CPF_OutParm))
				{
					if (Param->HasAnyPropertyFlags(CPF_ReferenceParm))
					{
						ParamType += "&";
					}
					else if (!ParamType.EndsWith("*"))
					{
						ParamType += "*";
					}
				}
				TopMethod.Parameters.Add(ParamType);

				ParamEntries.Add(FString::Printf(TEXT("%s %s"), *ParamType, *ParamName));
			}

			// 3. 组合参数列表
			FString Parameters = ParamEntries.Num() > 0 ? FString::Join(ParamEntries, TEXT(", ")) : TEXT("");

			// 4. 处理函数修饰符
			FString Modifiers;
			if (Function->HasAnyFunctionFlags(FUNC_Static))
			{
				Modifiers += "static ";
			}
			//if (Function->HasAnyFunctionFlags(FUNC_Virtual)) {
			//	Modifiers += "virtual ";
			//}
			//if (Function->HasAnyFunctionFlags(FUNC_Exec)) {
			//	Modifiers += "UFUNCTION() ";
			//}

			// 5. 处理const限定符
			FString ConstQualifier = Function->HasAnyFunctionFlags(FUNC_Const) ? " const" : "";

			// 最终组合函数签名
			Signature = FString::Printf(TEXT("%s%s %s(%s)%s"), *Modifiers, *ReturnType, *Function->GetName(), *Parameters, *ConstQualifier);

			TopMethod.Expression = FString::Printf(TEXT("%s%s %s(%s)%s"), *Modifiers, *ReturnType, *Function->GetName(), *Parameters, *ConstQualifier);

			OutputContent += FString::Printf(TEXT("    %s\n"), *Signature);

			// 显示函数元数据
			//if (Function->HasMetaData(TEXT("Category"))) {
			//	OutputContent += FString::Printf(TEXT("      // Category: %s\n"),
			//		*Function->GetMetaData(TEXT("Category")));
			//}
		}

		OutputContent += TEXT("\n----------------------------------------\n\n");
	}

	// 写入文件
	if (FFileHelper::SaveStringToFile(OutputContent, *Filename))
	{
		UE_LOG(LogTemp, Display, TEXT("Reflection dump saved to: %s"), *Filename);
		return 0;
	}

	UE_LOG(LogTemp, Error, TEXT("Failed to save reflection dump!"));
	return -1;
}

// 结构体声明生成辅助函数
static FString GenerateStructDeclaration(FDumpClassInfo_Class& OutValue, UScriptStruct* Struct)
{
	FString Output;

	// 1. 生成USTRUCT宏
	TArray<FString> StructMetaData;
	if (Struct->HasMetaData(TEXT("BlueprintType")))
	{
		StructMetaData.Add(TEXT("BlueprintType"));
	}

	// 收集所有结构体标志
	if (Struct->StructFlags & STRUCT_Atomic)
	{
		StructMetaData.Add(TEXT("Atomic"));
	}
	if (Struct->StructFlags & STRUCT_Immutable)
	{
		StructMetaData.Add(TEXT("Immutable"));
	}

#if false
	Output += FString::Printf(TEXT("USTRUCT(%s)\n"),
		*FString::Join(StructMetaData, TEXT(", ")));
#endif

	// 2. 结构体定义
	Output += FString::Printf(TEXT("struct %s\n"), *Struct->GetName());
	OutValue.Name = FString("F") + Struct->GetName();

	// 处理父结构体
	if (Struct->GetSuperStruct())
	{
		Output += FString::Printf(TEXT("    : public %s\n"), *Struct->GetSuperStruct()->GetName());
		OutValue.Bases.Add(FString("F") + *Struct->GetSuperStruct()->GetName());
	}

	Output += TEXT("{\n");
	//Output += TEXT("    GENERATED_BODY()\n\n");

	// 3. 生成成员变量
	for (TFieldIterator<FProperty> PropIt(Struct); PropIt; ++PropIt)
	{
		FProperty* Property = *PropIt;

		// 生成UPROPERTY宏
#if false
		TArray<FString> PropertyMeta;
		if (Property->HasAnyPropertyFlags(CPF_Edit)) {
			PropertyMeta.Add(TEXT("EditAnywhere"));
		}
		if (Property->HasAnyPropertyFlags(CPF_BlueprintVisible)) {
			PropertyMeta.Add(TEXT("BlueprintReadWrite"));
		}

		// 处理元数据
		if (Property->HasMetaData(TEXT("Category"))) {
			PropertyMeta.Add(FString::Printf(TEXT("Category=\"%s\""),
				*Property->GetMetaData(TEXT("Category"))));
		}

		if (PropertyMeta.Num() > 0) {
			Output += FString::Printf(TEXT("    UPROPERTY(%s)\n"),
				*FString::Join(PropertyMeta, TEXT(", ")));
		}
#endif

		// 生成变量声明
		FString TypeName = Property->GetCPPType();
		if (Property->ArrayDim > 1)
		{
			TypeName += FString::Printf(TEXT("[%d]"), Property->ArrayDim);
		}

		Output += FString::Printf(TEXT("    %s %s;\n"), *TypeName, *Property->GetName());

		OutValue.Fields.AddDefaulted();
		auto& TopField = OutValue.Fields.Top();
		TopField.Name = Property->GetName();
		TopField.Type = TypeName;
		TopField.Expression = FString::Printf(TEXT("%s %s"), *TypeName, *Property->GetName());
	}

	Output += TEXT("};\n\n");
	return Output;
}

int32 DumpStruct(FDumpClassInfo_NestedNamespace& Out)
{
	const FString OutputDir = FPaths::ProjectSavedDir() / TEXT("ReflectionDump");
	IFileManager::Get().MakeDirectory(*OutputDir, true);

	const FString Filename = OutputDir / TEXT("Structs.h");
	FString OutputContent = TEXT("// Auto-generated struct declarations\n\n");

	// 遍历所有USTRUCT
	int32 StructCount = 0;
	for (TObjectIterator<UScriptStruct> StructIt; StructIt; ++StructIt)
	{
		UScriptStruct* Struct = *StructIt;

		// 过滤条件
		if (Struct->GetName().StartsWith(TEXT("STRUCT_")) // 过滤引擎模板结构体
			//|| Struct->GetOutermost()->GetName().StartsWith(TEXT("/Script/Blueprint")) || // 过滤蓝图生成
			//|| Struct->HasAnyFlags(RF_Transient)  // 过滤临时结构体
		)
		{
			continue;
		}
		if (!Struct->IsNative())
		{
			continue;
		}

		Out.Classes.AddDefaulted();
		auto& Top = Out.Classes.Top();
		Top.ClsCategory = "USTRUCT";

		OutputContent += GenerateStructDeclaration(Top, Struct);
		StructCount++;
	}

	// 写入文件
	if (FFileHelper::SaveStringToFile(OutputContent, *Filename))
	{
		UE_LOG(LogTemp, Display, TEXT("Exported %d structs to: %s"), StructCount, *Filename);
		return 0;
	}

	UE_LOG(LogTemp, Error, TEXT("Failed to save struct dump!"));
	return -1;
}

FString GenerateEnumDeclaration(FDumpClassInfo_Class& Out, UEnum* Enum)
{
	FString Output;

	// 1. 生成UENUM宏
	TArray<FString> MetaData;
	if (Enum->GetCppForm() == UEnum::ECppForm::EnumClass)
	{
		MetaData.Add(TEXT("BlueprintType"));
	}

	// 收集元数据
	if (Enum->HasMetaData(TEXT("DisplayName")))
	{
		MetaData.Add(FString::Printf(TEXT("DisplayName=\"%s\""), *Enum->GetMetaData(TEXT("DisplayName"))));
	}

	Output += FString::Printf(TEXT("UENUM(%s)\n"), *FString::Join(MetaData, TEXT(", ")));

	// 2. 生成枚举类型声明
	// GetUnderlyingProperty()->GetCPPType()
#if false
	const FString EnumType = Enum->GetCppForm() == UEnum::ECppForm::Regular ?
		TEXT("") : FString::Printf(TEXT(" : %s"), TEXT("class"));// *Enum->GetCppType());
#else
	const FString EnumType;
#endif

	Output += FString::Printf(TEXT("%s%s\n{\n"), *Enum->GetName(), *EnumType);

	Out.Name = Enum->GetName();

	// 3. 生成枚举值
	for (int32 i = 0; i < Enum->NumEnums() - 1; ++i) // 排除_MAX项
	{
		const FString EntryName = Enum->GetNameStringByIndex(i);
		const int64 Value = Enum->GetValueByIndex(i);


		// 生成元数据
		TArray<FString> EntryMeta;
#if false
		const FText DisplayName = Enum->GetDisplayNameTextByIndex(i);
		if (!DisplayName.IsEmpty() && DisplayName.ToString() != EntryName) {
			EntryMeta.Add(FString::Printf(TEXT("DisplayName=\"%s\""),
				*DisplayName.ToString()));
		}

		// 生成位标记
		if (Enum->HasMetaData(TEXT("Bitflags"), i)) {
			EntryMeta.Add(TEXT("Bitflags"));
		}
#endif

		// 组合条目
		Output += FString::Printf(TEXT("    %s = %d"), *EntryName, Value);
		if (EntryMeta.Num() > 0)
		{
			Output += FString::Printf(TEXT(" UMETA(%s)"), *FString::Join(EntryMeta, TEXT(", ")));
		}
		Output += TEXT(",\n");

		Out.Fields.AddDefaulted();
		auto& TopField = Out.Fields.Top();

		TopField.Name = EntryName;
		TopField.Type = "int";
		TopField.Expression = FString::Printf(TEXT("%s = %d"), *EntryName, Value);
	}

	Output += TEXT("};\n\n");
	return Output;
}

int32 DumpEnum(FDumpClassInfo_NestedNamespace& Out)
{
	const FString OutputDir = FPaths::ProjectSavedDir() / TEXT("ReflectionDump");
	IFileManager::Get().MakeDirectory(*OutputDir, true);

	const FString Filename = OutputDir / TEXT("Enums.h");
	FString OutputContent = TEXT("// Auto-generated enum declarations\n\n");

	int32 EnumCount = 0;
	for (TObjectIterator<UEnum> EnumIt; EnumIt; ++EnumIt)
	{
		UEnum* Enum = *EnumIt;

		// 过滤蓝图生成的枚举
		if (
			//Enum->GetOutermost()->GetName().StartsWith(TEXT("/Script/Blueprint")) ||
			Enum->GetName().StartsWith(TEXT("__")) || // 过滤内部临时枚举
			Enum->GetName().EndsWith(TEXT("_MAX")))
		{
			continue;
		}
		if (!Enum->IsNative())
		{
			continue;
		}

		// 过滤没有反射值的枚举
		if (Enum->NumEnums() <= 1)
		{
			continue;
		}

		Out.Classes.AddDefaulted();
		auto& TopOne = Out.Classes.Top();
		TopOne.ClsCategory = "UENUM";

		OutputContent += GenerateEnumDeclaration(TopOne, Enum);
		EnumCount++;
	}

	if (FFileHelper::SaveStringToFile(OutputContent, *Filename))
	{
		UE_LOG(LogTemp, Display, TEXT("Exported %d enums to: %s"), EnumCount, *Filename);
		return 0;
	}

	UE_LOG(LogTemp, Error, TEXT("Failed to save enum dump!"));
	return -1;
}

template <typename StructType>
bool MySaveStructToJsonFile(const StructType& Data, const FString& Filename)
{
	// 生成JSON对象
	TSharedRef<FJsonObject> JsonObject = MakeShareable(new FJsonObject);
	if (!FJsonObjectConverter::UStructToJsonObject(StructType::StaticStruct(), &Data, JsonObject, 0, 0, nullptr, EJsonObjectConversionFlags::SkipStandardizeCase))
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to convert struct to JSON"));
		return false;
	}

	// 序列化为字符串
	FString OutputString;
	TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&OutputString);
	FJsonSerializer::Serialize(JsonObject, Writer);

	// 保存文件
	return FFileHelper::SaveStringToFile(OutputString, *Filename);
}

class FMyJsonSerializer
{
public:
	static bool UStructToJson(const UStruct* StructDefinition, const void* StructPtr, TSharedPtr<FJsonObject>& OutJsonObject);

	template<typename T>
	static bool UStructToJson(const T& StructValue, TSharedPtr<FJsonObject>& OutJsonObject)
	{
		return UStructToJson(TBaseStructure<T>::Get(), &StructValue, OutJsonObject);
	}

	static bool SaveJsonToFile(const TSharedPtr<FJsonObject>& JsonObject, const FString& Filename);

private:
	static TSharedPtr<FJsonValue> PropertyToJsonValue(
		FProperty* Property,
		const void* ContainerPtr,
		int32 ArrayIndex = 0);
};

bool FMyJsonSerializer::UStructToJson(const UStruct* StructDefinition, const void* StructPtr, TSharedPtr<FJsonObject>& OutJsonObject)
{
	OutJsonObject = MakeShareable(new FJsonObject());

	for (TFieldIterator<FProperty> PropIt(StructDefinition); PropIt; ++PropIt)
	{
		FProperty* Property = *PropIt;
		const FString PropertyName = Property->GetName();

		if (Property->ArrayDim > 1)
		{
			TArray<TSharedPtr<FJsonValue>> ArrayValues;
			for (int32 i = 0; i < Property->ArrayDim; ++i)
			{
				const void* PropertyAddress = Property->ContainerPtrToValuePtr<void>(StructPtr, i);
				TSharedPtr<FJsonValue> Value = PropertyToJsonValue(Property, PropertyAddress, i);
				ArrayValues.Add(Value);
			}
			OutJsonObject->SetArrayField(PropertyName, ArrayValues);
		}
		else
		{
			const void* PropertyAddress = Property->ContainerPtrToValuePtr<void>(StructPtr);
			TSharedPtr<FJsonValue> Value = PropertyToJsonValue(Property, PropertyAddress);
			OutJsonObject->SetField(PropertyName, Value);
		}
	}
	return true;
}

TSharedPtr<FJsonValue> FMyJsonSerializer::PropertyToJsonValue(
	FProperty* Property,
	const void* ContainerPtr,
	int32 ArrayIndex)
{
	if (FArrayProperty* ArrayProperty = CastField<FArrayProperty>(Property))
	{
		TArray<TSharedPtr<FJsonValue>> JsonArray;
		FScriptArrayHelper ArrayHelper(ArrayProperty, ContainerPtr);

		for (int32 i = 0; i < ArrayHelper.Num(); ++i)
		{
			TSharedPtr<FJsonValue> ElementValue = PropertyToJsonValue(
				ArrayProperty->Inner,
				ArrayHelper.GetRawPtr(i));
			JsonArray.Add(ElementValue);
		}
		return MakeShareable(new FJsonValueArray(JsonArray));
	}
	else if (FStructProperty* StructProperty = CastField<FStructProperty>(Property))
	{
		TSharedPtr<FJsonObject> JsonObject;

		UStructToJson((StructProperty->Struct), ContainerPtr, JsonObject);
		return MakeShareable(new FJsonValueObject(JsonObject));
	}
	// 基础类型处理
	else if (FNumericProperty* NumericProperty = CastField<FNumericProperty>(Property))
	{
		if (NumericProperty->IsFloatingPoint())
		{
			double Value = NumericProperty->GetFloatingPointPropertyValue(ContainerPtr);
			return MakeShareable(new FJsonValueNumber(Value));
		}
		else
		{
			int64 Value = NumericProperty->GetSignedIntPropertyValue(ContainerPtr);
			return MakeShareable(new FJsonValueNumber(Value));
		}
	}
	else if (FStrProperty* StringProperty = CastField<FStrProperty>(Property))
	{
		FString Value = StringProperty->GetPropertyValue(ContainerPtr);
		return MakeShareable(new FJsonValueString(Value));
	}
	else if (FBoolProperty* BoolProperty = CastField<FBoolProperty>(Property))
	{
		bool Value = BoolProperty->GetPropertyValue(ContainerPtr);
		return MakeShareable(new FJsonValueBoolean(Value));
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("暂时未处理的类型：%s"), *Property->GetName());
	}

	// 添加其他类型支持...

	return MakeShareable(new FJsonValueNull());
}

bool FMyJsonSerializer::SaveJsonToFile(const TSharedPtr<FJsonObject>& JsonObject, const FString& Filename)
{
	if (!JsonObject.IsValid()) return false;

	FString OutputString;
	TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&OutputString);
	FJsonSerializer::Serialize(JsonObject.ToSharedRef(), Writer);

	return FFileHelper::SaveStringToFile(OutputString, *Filename);
}

static int DoAction()
{
	FDumpClassInfo_All AllInfo;
	DumpAllCls(AllInfo.RootNamespace);
	DumpStruct(AllInfo.RootNamespace);
	DumpEnum(AllInfo.RootNamespace);

	const FString FilePath = FPaths::ProjectSavedDir() / TEXT("ReflectionDump/engine_bind.json");
#if false
	if (MySaveStructToJsonFile(RootNamespace, FilePath))
	{
		UE_LOG(LogTemp, Display, TEXT("Data saved to: %s"), *FilePath);
		return 0;
	}
#else
	TSharedPtr<FJsonObject> JsonObject;
	if (FMyJsonSerializer::UStructToJson(AllInfo, JsonObject))
	{
		if (FMyJsonSerializer::SaveJsonToFile(JsonObject, FilePath))
		{
			UE_LOG(LogTemp, Display, TEXT("Data saved to: %s"), *FilePath);
			return 0;
		}
	}
#endif
	return -1;
}


int32 UDumpAllClsInfoCommandlet::Main(const FString& Params)
{
	return DoAction();
}


FAutoConsoleCommand C7DumpAllCls(TEXT("c7.dumpallcls"), TEXT("c7.dumpallcls"), FConsoleCommandWithWorldArgsAndOutputDeviceDelegate::CreateLambda([](const TArray<FString>& Args, UWorld* InWorld, FOutputDevice& Ar)
{
	DoAction();
}));
