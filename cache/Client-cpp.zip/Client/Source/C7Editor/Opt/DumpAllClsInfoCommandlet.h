// DumpAllClsInfoCommandlet.h
#pragma once

#include "Commandlets/Commandlet.h"
#include "DumpAllClsInfoCommandlet.generated.h"

UCLASS()
class UDumpAllClsInfoCommandlet : public UCommandlet
{
	GENERATED_BODY()

public:
	virtual int32 Main(const FString& Params) override;
};