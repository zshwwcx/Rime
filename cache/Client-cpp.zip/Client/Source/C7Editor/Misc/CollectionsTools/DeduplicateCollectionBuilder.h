// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "EditorUtilityObject.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "CollectionManagerModule.h"
#include "ICollectionManager.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "DeduplicateCollectionBuilder.generated.h"

/**
 * 
 */
UCLASS()
class C7EDITOR_API UDeduplicateCollectionBuilder : public UEditorUtilityObject
{
	GENERATED_BODY()
	
public:
	
	UFUNCTION(CallInEditor, BlueprintCallable)
	void DoDuplicateCollection();

public:

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString CSVPath = "";


};
