#include "Misc/CollectionsTools/DeduplicateCollectionBuilder.h"
#include "CollectionManagerModule.h"
#include "ICollectionManager.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "CollectionManagerTypes.h"




void UDeduplicateCollectionBuilder::DoDuplicateCollection()
{
	if (CSVPath.IsEmpty())
	{
		UE_LOG(LogTemp, Error, TEXT("CSVPath is empty!"));
		return;
	}

	TArray<FString> Lines;
	if (!FFileHelper::LoadFileToStringArray(Lines, *CSVPath))
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to load CSV: %s"), *CSVPath);
		return;
	}

	ICollectionManager& CollectionManager = FCollectionManagerModule::GetModule().Get();
	//跳过第一行标题
	for (int32 LineIdx = 1; LineIdx < Lines.Num(); ++LineIdx)
	{
		const FString& Line = Lines[LineIdx];

		TArray<FString> Fields;
		Line.ParseIntoArray(Fields, TEXT(","), true);

		if (Fields.Num() < 3)
			continue;

		FString CollectionName = FPaths::GetBaseFilename(Fields[0]);
		TSet<FName> UniqueAssetPaths;

		for (int32 i = 2; i < Fields.Num(); ++i)
		{
			FString Path = Fields[i].TrimStartAndEnd();
			if (!Path.IsEmpty())
			{
				FString AssetPath = Path;

				// 只处理 .uasset 文件
				if (AssetPath.EndsWith(TEXT(".uasset")))
				{
					// 统一斜杠，去除多余的 //
					AssetPath = AssetPath.Replace(TEXT("\\"), TEXT("/"));
					while (AssetPath.Contains(TEXT("//")))
					{
						AssetPath = AssetPath.Replace(TEXT("//"), TEXT("/"));
					}

					int32 ContentIdx = AssetPath.Find(TEXT("/Content/"));
					if (ContentIdx != INDEX_NONE)
					{
						// 截取 /Content/ 后面的部分
						FString RelativePath = AssetPath.Mid(ContentIdx + 8); // 8是"/Content/"长度
						AssetPath = FString::Printf(TEXT("/Game%s"), *RelativePath.LeftChop(7)); // 去掉 .uasset
					}
					else
					{
						// 如果没有 /Content/，直接去掉 .uasset
						AssetPath = AssetPath.LeftChop(7);
					}

					// 自动补全对象名
					if (!AssetPath.Contains(TEXT(".")))
					{
						FString AssetName = FPaths::GetBaseFilename(AssetPath);
						AssetPath = FString::Printf(TEXT("%s.%s"), *AssetPath, *AssetName);
					}
				}else
				{
					//跳过非.uasset文件
					continue;
				}

				UniqueAssetPaths.Add(FName(*AssetPath));
			}
		}

		if (UniqueAssetPaths.Num() > 0)
		{
			if (!CollectionManager.CollectionExists(*CollectionName, ECollectionShareType::CST_Local))
			{
				CollectionManager.CreateCollection(*CollectionName, ECollectionShareType::CST_Local, ECollectionStorageMode::Static);
			}
			CollectionManager.AddToCollection(*CollectionName, ECollectionShareType::CST_Local, UniqueAssetPaths.Array());
			UE_LOG(LogTemp, Log, TEXT("Collection %s created with %d assets."), *CollectionName, UniqueAssetPaths.Num());
		}
	}
}

